import express from "express"
import { setReqHeaderParams, AuthMiddleware, sendResponse } from "./config/apiconfig.js"
import _Signup from "./api/V1/Authentication/Signup.js"
import _SeriesMaster from "./api/V1/SeriesMaster.js"
import _ForgotPassword from "./api/V1/Authentication/ForgotPassword.js"
import _DeleteMaster from './api/V1/masters/DeleteMaster.js'

// 2FA
import _TwoFactorAuth from "./api/V1/Authentication/2_Factor_Auth/2FA.js"

//onboarding
import _Customer from './api/V1/Onboarding/Customer.js'
import _Employee from './api/V1/Onboarding/Employee.js'
import _Gatekeeper from './api/V1/Onboarding/Gatekeeper.js'
import _VendorBooking from './api/V1/masters/Booking/VendorBooking.js'
import _Dailyhelp from './api/V1/Onboarding/DailyHelp.js'

//Master
import _VendorMaster from './api/V1/Onboarding/Vendor.js'
import _VendorStaffMaster from './api/V1/Onboarding/VendorStaff.js'
import _CategoryMaster from './api/V1/masters/VisitorCategoryMaster.js'
import _DeliveryCompanyMaster from './api/V1/masters/DeliveryCompanyMaster.js'
import _CountryMaster from './api/V1/masters/CountryMaster.js'
import _CityMaster from './api/V1/masters/CityMaster.js'
import _StateMaster from './api/V1/masters/StatesMaster.js'
import _PincodeMaster from './api/V1/masters/PincodeMaster.js'
import _Gender from './api/V1/masters/GenderMaster.js'
import _Areatypemaster from './api/V1/masters/Property/AreatypeMaster.js'
import _BusinessStructureMaster from './api/V1/masters/BusinessStructureMaster.js'
import _DeliveryTypeMaster from './api/V1/masters/DeliveryTypeMaster.js'
import _DesignationMaster from './api/V1/masters/DesignationMaster.js'
import _Appversion from './api/V1/APP/AppVersion.js'
import _CheckListTypeMaster from './api/V1/masters/ChecklistTypeMaster.js'
import _CheckList from './api/V1/Checklist.js'
import _SurveyForm from './api/V1/masters/Survey/SurveyForm.js'
import _Survey from './api/V1/masters/Survey/Survey.js'
import _SurveyType from './api/V1/masters/Survey/SurveyType.js'
import _Alert from './api/V1/masters/AlertsMaster.js'
import _Seriestype from './api/V1/masters/SeriesType.js'
import _SeriesElement from './api/V1/masters/SeriesElement.js'
import _NoticeMaster from './api/V1/masters/NoticeMaster.js'
import _IncidentMaster from './api/V1/masters/IncidentMaster.js'
import _KnowledgebaseMaster from './api/V1/masters/Knowledgebase.js'
import _Committee from './api/V1/masters/Committee.js'
import _Emergencydir from './api/V1/masters/EmergencyDir.js'
import _EventMaster from './api/V1/masters/EventMaster.js'
import _EventCategoryMaster from './api/V1/masters/EventCategoryMaster.js'
import _GstTreatmentMaster from './api/V1/masters/GstTreatmentMaster.js'
import _channelMaster from './api/V1/masters/ChannelMaster.js'
import _MsmeRegTypeMaster from './api/V1/masters/MsmeRegType.js'
import _SourceofSupplyMaster from './api/V1/masters/SourceofSupply.js'
import _DepartmentMaster from './api/V1/masters/DepartmentMaster.js'
import _PetTypeMaster from './api/V1/masters/PetTypeMaster.js'
import _RelationMaster from './api/V1/masters/RelationMaster.js'
import _ParkingMaster from './api/V1/masters/ParkingZoneMaster.js'
import _BreedMaster from './api/V1/masters/BreedMaster.js'
import _DailyhelpCategoryMaster from './api/V1/masters/DailyhelpCategory.js'
import _GuestMaster from './api/V1/masters/Guest.js'
import _AvailabilityMaster from './api/V1/masters/Availability.js'
import _AssetTypeMaster from './api/V1/masters/Asset/assettype.js'
import _AssetCapacityUnitMaster from './api/V1/masters/Asset/AssetCapacityUnitMaster.js'
import _AssetCategoryMaster from './api/V1/masters/Asset/assetcategory.js'
import _AssetMaster from './api/V1/masters/Asset/Asset.js'
import _AssetStatusMaster from './api/V1/masters/Asset/Assetstatus.js'
import _AssetConditionmaster from './api/V1/masters/Asset/Assetcondition.js'
import _ItemMaster from './api/V1/masters/Asset/Item.js'
import _EmergencyCategory from './api/V1/masters/EmergencyCategory.js'
import _LocalDir from './api/V1/masters/LocalDir.js'
import _Amenitiestype from './api/V1/masters/AmenitiesType.js'
import _OccupancyMaster from './api/V1/masters/OccupancyStatus.js'
import _FlatTypeMaster from './api/V1/masters/FlattypeMaster.js'
import _VendorStaffdesignationMaster from './api/V1/masters/Vendorstaffdesignation.js'
import _Vehicletypemaster from './api/V1/masters/VehicleType.js'
import _Petmaster from './api/V1/masters/PetMaster.js'
import _Vehiclemaster from './api/V1/masters/VehicleMaster.js'
import _Lost from './api/V1/masters/LostAndFound/Lost.js'
import _Found from './api/V1/masters/LostAndFound/Found.js'
import _LostAndFoundPriority from './api/V1/masters/LostAndFound/LostandfoundPriority.js'
import _LostAndFoundComments from './api/V1/masters/LostAndFound/LostandfoundComments.js'
import _PolicyMaster from './api/V1/masters/PolicyMaster.js'
import _QRcodeMaster from './api/V1/masters/Patrolling/QRcodeMaster.js'
import _Patrolling from './api/V1/masters/Patrolling/Patrolling.js'
import _SOS from './api/V1/masters/SosMaster.js'
import _KeyMaster from './api/V1/masters/KeyMangement/KeyMaster.js'
import _KeyBunchMaster from './api/V1/masters/KeyMangement/KeyBunch.js'
import _ParcelMaster from './api/V1/masters/Parcel/ParcelMaster.js'
import _CabMaster from './api/V1/masters/Cab/Cab.js'
import _Task from './api/V1/masters/Task/Task.js'
import _TaskStatus from './api/V1/masters/Task/TaskstatusMaster.js'

//visitor
import _Visitor from './api/V1/masters/Visitor.js'

import _IconMaster from "./api/V1/masters/Menu/IconMaster.js"
import _FieldOrder from "./api/V1/FieldOrder.js"
import _MenuMaster from "./api/V1/masters/Menu/MenuMaster.js"
import _ModuleMaster from "./api/V1/masters/Menu/ModuleMaster.js"
import _ModuleTypeMaster from "./api/V1/masters/Menu/ModuleTypeMaster.js"
import _UserroleMaster from "./api/V1/masters/UserManagement/UserroleMaster.js"
import _UserRoleHierarchy from "./api/V1/masters/UserManagement/UserRoleHierarchy.js"
import _Userrights from "./api/V1/masters/UserManagement/UserRights.js"
import _UserRightTemplateMaster from './api/V1/masters/UserManagement/UserRightsTemplate.js'
import _MenuAssignMaster from "./api/V1/masters/Menu/MenuAssignMaster.js"
import _MenuDesignMaster from "./api/V1/masters/Menu/MenuDesignMaster.js"

//complaint
import _ComplaintCategoryMaster from './api/V1/Complaint/ComplaintCategory.js'
import _Complaintflow from './api/V1/Complaint/ComplaintFlowMaster.js'
import _ComplaintStageflow from './api/V1/Complaint/ComplaintStageFlow.js'
import _ComplaintStage from './api/V1/Complaint/ComplaintStage.js'
import _ComplaintType from './api/V1/Complaint/ComplaintType.js'
import _Complaintcomments from './api/V1/Complaint/ComplaintComments.js'
import _Complainttimelog from './api/V1/Complaint/ComplaintTimelog.js'
import _ComplaintPriority from './api/V1/Complaint/Complaintpriority.js'
import _CategroyTrain from './api/V1/Complaint/CategoryTrain.js'

//payroll
import _Logmanage from './api/V1/masters/Payroll/LogManageMaster.js'

//PROPERTY
import _PropertyMaster from './api/V1/masters/Property/PropertyMaster.js'
import _Facilitybooking from './api/V1/masters/Booking/FacilityBooking.js'

//dailyhelp
import _DailyhelpBooking from './api/V1/masters/Booking/DailyhelpBooking.js'

//Testcase
import _ExecuteTestcase from './RunTestCase.js'

// Email Configuration
import _EmailSMTP from "./api/V1/masters/Configurations/EmailSMTP.js"

import { Config } from "./config/Init.js"
import DB from "./config/DB.js"
import _Device from "./api/V1/APP/Device.js"

// Zoho
import _ZohoServices from "./api/V1/Zoho/ZohoService.js"
import _ZohoPropertySync from "./api/V1/Zoho/ZohoPropertySync.js"
import _ZohoAuth from "./api/V1/Zoho/ZohoAuth.js"

import _POC from "./api/V1/POC/POC.js"

// checklist
import _Checklist from "./api/V1/Checklist.js"

import _Complaint from "./api/V1/Complaint/Complaint.js"
import _ComplaintChat from "./api/V1/Complaint/Complaint_Chat/ComplaintChat.js"

import _TaskCategory from "./api/V1/Task/TaskCategory.js"
import _TaskCategoryConfiguration from "./api/V1/Task/CategoryConfiguration.js"

import _complaintschedular from './api/V1/cronjob/ComplaintAcceptNotify.js'
import _complaintsolve from './api/V1/cronjob/ComplaintSolveNotify.js'

import _NationalityMaster from './api/V1/masters/NationalityMaster.js'
import _CustomerTypeMaster from './api/V1/masters/customertypemaster.js'
import _CommitteeMembersMaster from './api/V1/masters/CommitteeMembersMaster.js'


var router = express.Router()
router.all("*", setReqHeaderParams)


// Class Objects of API
const Apisignup = new _Signup()
const Apiforgotpassword = new _ForgotPassword()
const Apiappversion = new _Appversion()

//auth
const ApiemployeeAuth = new _Employee()
const ApicustomerAuth = new _Customer()
const ApigatekeeperAuth = new _Gatekeeper()


//master
const Apivendorstaffmaster = new _VendorStaffMaster()
const Apivendormaster = new _VendorMaster()
const Apicategorymaster = new _CategoryMaster()
const Apideliverycompnaymaster = new _DeliveryCompanyMaster()
const Apicountrymaster = new _CountryMaster()
const ApicityMaster = new _CityMaster()
const ApistateMaster = new _StateMaster()
const ApipincodeMaster = new _PincodeMaster()
const ApidesignationMaster = new _DesignationMaster()
const Apiproperty = new _PropertyMaster()
const ApigenderMaster = new _Gender()
const Apiareamaster = new _Areatypemaster()
const Apibusinessstructuremaster = new _BusinessStructureMaster()
const Apideliverytypemaster = new _DeliveryTypeMaster()
const Apichecklisttypemaster = new _CheckListTypeMaster()
const Apichecklist = new _CheckList()
const Apisurveyform = new _SurveyForm()
const Apisurvey = new _Survey()
const Apisurveytype = new _SurveyType()
const Apideletemaster = new _DeleteMaster()
const Apialertmaster = new _Alert()
const Apiseriestypemaster = new _Seriestype()
const Apigsttreatmentmaster = new _GstTreatmentMaster()
const Apichannelmaster = new _channelMaster()
const Apimsmeregtypemaster = new _MsmeRegTypeMaster()
const Apisourceofsupplymaster = new _SourceofSupplyMaster()
const Apidepartmentmaster = new _DepartmentMaster()
const Apiavailabilitymaster = new _AvailabilityMaster()
const Apiassettypemaster = new _AssetTypeMaster()
const AssetCapacityUnitMaster = new _AssetCapacityUnitMaster()
const Apiassetcategorymaster = new _AssetCategoryMaster()
const Apiassetmaster = new _AssetMaster()
const Apiassetstatusmaster = new _AssetStatusMaster()
const Apiitemmaster = new _ItemMaster()
const Apiassetconditionmaster = new _AssetConditionmaster()
const Apiemergencycategory = new _EmergencyCategory()
const Apilocaldir = new _LocalDir()
const ApiAmenitiestype = new _Amenitiestype()
const Apioccupationmaster = new _OccupancyMaster()
const Apiflattypemaster = new _FlatTypeMaster()
const Apivendorstaffdesignationmaster = new _VendorStaffdesignationMaster()
const Apivehicletypemaster = new _Vehicletypemaster()
const Apipetmaster = new _Petmaster()
const Apivehiclemaster = new _Vehiclemaster()
const Apifoundmaster = new _Found()
const Apilostmaster = new _Lost()
const Apilostandfoundprioritymaster = new _LostAndFoundPriority()
const Apilostandfoundcommentsmaster = new _LostAndFoundComments()
const Apipolicymaster = new _PolicyMaster()
const Apiqrcodemaster = new _QRcodeMaster()
const Apipatrolling = new _Patrolling()
const Apisosmaster = new _SOS()
const Apikeymaster = new _KeyMaster()
const Apikeybunchmaster = new _KeyBunchMaster()
const Apiparcelmaster = new _ParcelMaster()
const Apicabmaster = new _CabMaster()
const Apitaskmaster = new _Task()
const Apitaskstatusmaster = new _TaskStatus()

//getkeeper
const Apinoticemaster = new _NoticeMaster()
const Apiincidentmaster = new _IncidentMaster()
const Apiknowledgebasemaster = new _KnowledgebaseMaster()
const Apicommitteemaster = new _Committee()
const Apiemergencydir = new _Emergencydir()
const Apieventmaster = new _EventMaster()
const Apieventcategorymaster = new _EventCategoryMaster()

//customer
const Apirelationmaster = new _RelationMaster()
const Apipettypemaster = new _PetTypeMaster()
const Apiparkingmaster = new _ParkingMaster()
const Apibreedmaster = new _BreedMaster()
const Apidailyhelpmaster = new _DailyhelpCategoryMaster()
const Apiguestmaster = new _GuestMaster()


const Apiiconmaster = new _IconMaster()
const Apifieldorder = new _FieldOrder()
const Apimenumaster = new _MenuMaster()
const Apimodulemaster = new _ModuleMaster()
const Apimoduletypemaster = new _ModuleTypeMaster()
const Apiuserrolemaster = new _UserroleMaster()
const Apiuserrolehierarchy = new _UserRoleHierarchy()
const Apimenuassignmaster = new _MenuAssignMaster()
const Apimenudesignmaster = new _MenuDesignMaster()
const Apiuserrightsmaster = new _Userrights()
const Apiseriesmaster = new _SeriesMaster()
const ApiUserRightsTemplate = new _UserRightTemplateMaster()
const Apiserieselement = new _SeriesElement()

//payroll
const Apilogmanage = new _Logmanage()

//visitor
const Apivisitor = new _Visitor()

//complaint
const Apicomplaintcategorymaster = new _ComplaintCategoryMaster()
const Apicomplaintflow = new _Complaintflow()
const Apicomplaintstageflow = new _ComplaintStageflow()
const Apicomplaintstage = new _ComplaintStage()
const Apicomplainttype = new _ComplaintType()
const Apicomplaintcomments = new _Complaintcomments()
const Apicomplainttimelog = new _Complainttimelog()
const Apicomplaintpriority = new _ComplaintPriority()
const ApiComplaint = new _Complaint()
const ApiComplaintChat = new _ComplaintChat()
const ApiCategorytrain = new _CategroyTrain()
//facilitybooking
const Apifacilitybooking = new _Facilitybooking()
//dailyhelp 
const Apidailyhelp = new _Dailyhelp()
const Apidailyhelpbooking = new _DailyhelpBooking()
//vendor
const ApivendorBooking = new _VendorBooking()
//Testcase
const Apiexecutetestcase = new _ExecuteTestcase()
// 2FA
const Apitwofactorauth = new _TwoFactorAuth()

// SETTINGS
const Apiemailsmtp = new _EmailSMTP()
const Apidevice = new _Device()

// ZOHO
const Apizohoservices = new _ZohoServices()
const Apizohopropertysync = new _ZohoPropertySync()
const Apizohoauth = new _ZohoAuth()

const Apipoc = new _POC()
const ApiChecklist = new _Checklist()

const ApiTaskCategory = new _TaskCategory()
const ApiTaskCategoryConfiguration = new _TaskCategoryConfiguration()

const apicomplaintaccept = new _complaintschedular()
const apicomplaintresolve = new _complaintsolve()

const apiNationalityMaster = new _NationalityMaster()
const apiCustomerTypeMaster = new _CustomerTypeMaster()
const apiCommitteeMembersMaster = new _CommitteeMembersMaster()

// ==================================================================================================================================================================================== //
// ============================================================================= AUTHENTICATIONS ===================================================================================== //
// ==================================================================================================================================================================================== //


router.get(Config.endpointv1 + "/healthcheck", Apisignup.health)
router.get(Config.endpointv1 + "/complaintsolve", apicomplaintresolve.ComplaintTicketSolveNotify)

router.post(Config.endpointv1 + "/bodydata", Apisignup.addBody, sendResponse)

router.get(Config.endpointv1 + "/testcase/report", Apisignup.reportdownload, sendResponse)


// Login
router.post(Config.endpointv1 + "/getaccesstoken", Apisignup.GetaccessToken, sendResponse)
router.post(Config.endpointv1 + "/logout", AuthMiddleware("", true), Apisignup.logout, sendResponse)
// router.post(Config.endpointv1 + "/getnewaccesstoken", Apisignup.GetNewaccessToken, sendResponse)
// router.post(Config.endpointv1 + "/checkdomain", AuthMiddleware(Config.userauthactions.login, true, true), Apisignup.CheckDomain, sendResponse)

router.post(Config.endpointv1 + "/logindata", AuthMiddleware("", true), Apisignup.LoginData, sendResponse)
router.post(Config.endpointv1 + "/device/token/add", AuthMiddleware("", true), Apidevice.InsertDeviceToken, sendResponse)


/* ---------------------------------------------- employee ---------------------------------------------- */

router.post(Config.endpointv1 + "/employee/login", AuthMiddleware(Config.userauthactions.login), Apisignup.EmployeeLogin, sendResponse)
router.post(Config.endpointv1 + "/employee/changepassword", AuthMiddleware(Config.userauthactions.resetpassword), Apisignup.EmployeeChangePassword, sendResponse)

// Forgot Password
router.post(Config.endpointv1 + "/employee/forgotpasswordrequest", AuthMiddleware(Config.userauthactions.forgotpassword), Apiforgotpassword.EmployeeForgotPasswordReq, sendResponse)
router.post(Config.endpointv1 + "/employee/forgotpasswordreset", AuthMiddleware(Config.userauthactions.forgotpassword), Apiforgotpassword.EmployeeForgotPasswordReset, sendResponse)


// Start employee 
router.post(Config.endpointv1 + "/employee", ApiemployeeAuth.ListEmployee, sendResponse)
router.post(Config.endpointv1 + "/employee/add", AuthMiddleware(), ApiemployeeAuth.InsertEmployee, sendResponse)
router.post(Config.endpointv1 + "/employee/update", AuthMiddleware(), ApiemployeeAuth.UpdateEmployee, sendResponse)
router.delete(Config.endpointv1 + "/employee/delete", AuthMiddleware(), ApiemployeeAuth.DeleteEmployee, sendResponse)
// End employee 

router.post(Config.endpointv1 + "/employee/reportingperson", AuthMiddleware("", false, false, false, false), ApiemployeeAuth.ListReportingPerson, sendResponse)

/* ---------------------------------------------- employee ---------------------------------------------- */



/* ---------------------------------------------- Customer ---------------------------------------------- */

router.post(Config.endpointv1 + "/customer/getloginotp", AuthMiddleware(Config.userauthactions.login), Apisignup.GetCustomerLoginOTP, sendResponse)
router.post(Config.endpointv1 + "/customer/login", AuthMiddleware(Config.userauthactions.login), Apisignup.CustomerLogin, sendResponse)

// Start customer 
router.post(Config.endpointv1 + "/customer", AuthMiddleware(), ApicustomerAuth.ListCustomer, sendResponse)
router.post(Config.endpointv1 + "/customer/add", AuthMiddleware(), ApicustomerAuth.InsertCustomer, sendResponse)
router.post(Config.endpointv1 + "/customer/update", AuthMiddleware(), ApicustomerAuth.UpdateCustomer, sendResponse)
router.delete(Config.endpointv1 + "/customer/delete", AuthMiddleware(), ApicustomerAuth.DeleteCustomer, sendResponse)
router.post(Config.endpointv1 + "/kidsapprove", AuthMiddleware(), ApicustomerAuth.ApprovekidsMaster, sendResponse)
router.post(Config.endpointv1 + "/customer/unit", AuthMiddleware(), ApicustomerAuth.ListCustomerUnit, sendResponse)
// End customer 

/* ---------------------------------------------- Customer ---------------------------------------------- */



/* ---------------------------------------------- gatekeeper ---------------------------------------------- */

router.post(Config.endpointv1 + "/gatekeeper/login", AuthMiddleware(Config.userauthactions.login), Apisignup.GatekeeperLogin, sendResponse)
router.post(Config.endpointv1 + "/gatekeeper/logout", AuthMiddleware("", true), Apisignup.GatekeeperLogout, sendResponse)
router.post(Config.endpointv1 + "/gatekeeper/changepassword", AuthMiddleware(Config.userauthactions.resetpassword), Apisignup.GatekeeperChangePassword, sendResponse)

// Forgot Password
router.post(Config.endpointv1 + "/gatekeeper/forgotpasswordrequest", AuthMiddleware(Config.userauthactions.forgotpassword), Apiforgotpassword.GatekeeperForgotPasswordReq, sendResponse)
router.post(Config.endpointv1 + "/gatekeeper/forgotpasswordreset", AuthMiddleware(Config.userauthactions.forgotpassword), Apiforgotpassword.GatekeeperForgotPasswordReset, sendResponse)

// Start gatekeeper 
router.post(Config.endpointv1 + "/gatekeeper", AuthMiddleware(), ApigatekeeperAuth.ListGateKeeper, sendResponse)
router.post(Config.endpointv1 + "/gatekeeper/add", AuthMiddleware(), ApigatekeeperAuth.InsertGateKeeper, sendResponse)
router.post(Config.endpointv1 + "/gatekeeper/update", AuthMiddleware(), ApigatekeeperAuth.UpdateGateKeeper, sendResponse)
router.delete(Config.endpointv1 + "/gatekeeper/delete", AuthMiddleware(), ApigatekeeperAuth.DeleteGateKeeper, sendResponse)
// End gatekeeper 

//visitor mobile verification
router.post(Config.endpointv1 + "/visitor/otp", AuthMiddleware(Config.userauthactions.login), Apisignup.GetVisitorOTP, sendResponse)
router.post(Config.endpointv1 + "/visitorotp/verify", AuthMiddleware(Config.userauthactions.forgotpassword), Apisignup.GetVisitorOTPVerify, sendResponse)

/* ---------------------------------------------- gatekeeper ---------------------------------------------- */

/* ---------------------------------------------- 2FA ---------------------------------------------- */

// Enable 2FA
router.post(Config.endpointv1 + "/2FA/enable", Apitwofactorauth.Enable2FA, sendResponse)
router.post(Config.endpointv1 + "/2FA/verifyenable", Apitwofactorauth.VerifyEnable2FA, sendResponse)
router.post(Config.endpointv1 + "/2FA/disable", AuthMiddleware(), Apitwofactorauth.Disable2FA, sendResponse)
router.post(Config.endpointv1 + "/2FA/recoverycode", AuthMiddleware(), Apitwofactorauth.GenerateRecoveryCode, sendResponse)
router.post(Config.endpointv1 + "/2FA/recoverycode/verify", AuthMiddleware(Config.userauthactions.login), Apitwofactorauth.VerifyRecoveryCode, sendResponse)
router.post(Config.endpointv1 + "/2FA/login", AuthMiddleware(Config.userauthactions.login), Apitwofactorauth.login2FA, sendResponse)

/* ---------------------------------------------- 2FA ---------------------------------------------- */

//app version
router.post(Config.endpointv1 + "/appversion", AuthMiddleware(), Apiappversion.AppVersion, sendResponse);



// ==================================================================================================================================================================================== //
// ============================================================================= AUTHENTICATIONS ===================================================================================== //
// ==================================================================================================================================================================================== //







// ==================================================================================================================================================================================== //
// ============================================================================= MASTER ===================================================================================== //
// ==================================================================================================================================================================================== //

//  Start category master
router.post(Config.endpointv1 + '/deletemaster', AuthMiddleware(), Apideletemaster.DeleteMaster, sendResponse)
//  End category master

//  Start vendor master
router.post(Config.endpointv1 + "/vendor", AuthMiddleware(), Apivendormaster.ListVendorMaster, sendResponse)
router.post(Config.endpointv1 + "/vendor/add", AuthMiddleware(), Apivendormaster.InsertVendorMaster, sendResponse)
router.post(Config.endpointv1 + "/vendor/update", AuthMiddleware(), Apivendormaster.UpdateVendorMaster, sendResponse)
router.delete(Config.endpointv1 + "/vendor/delete", AuthMiddleware(), Apivendormaster.DeleteVendorMaster, sendResponse)


//  Start vendor staff master
router.post(Config.endpointv1 + "/vendorstaff", AuthMiddleware(), Apivendorstaffmaster.ListVendorStaffMaster, sendResponse)
router.post(Config.endpointv1 + "/vendorstaff/add", AuthMiddleware(), Apivendorstaffmaster.InsertVendorStaffMaster, sendResponse)
router.post(Config.endpointv1 + "/vendorstaff/update", AuthMiddleware(), Apivendorstaffmaster.UpdateVendorStaffMaster, sendResponse)
router.delete(Config.endpointv1 + "/vendorstaff/delete", AuthMiddleware(), Apivendorstaffmaster.DeleteVendorStaffMaster, sendResponse)
router.post(Config.endpointv1 + "/vendor/allow", AuthMiddleware(), Apivendorstaffmaster.VendorstaffAllow, sendResponse)
//  End vendor master

router.post(Config.endpointv1 + "/vendorbooking", AuthMiddleware(), ApivendorBooking.ListVendorBooking, sendResponse)
router.post(Config.endpointv1 + "/vendorbooking/add", AuthMiddleware(), ApivendorBooking.InsertVendorBooking, sendResponse)
router.post(Config.endpointv1 + "/vendorbooking/update", AuthMiddleware(), ApivendorBooking.UpdateVendorBooking, sendResponse)
router.post(Config.endpointv1 + "/vendor/rating", AuthMiddleware(), ApivendorBooking.ListVendorRating, sendResponse)
router.post(Config.endpointv1 + "/vendor/rating/add", AuthMiddleware(), ApivendorBooking.InsertVendorRating, sendResponse)

//  Start gender master
router.post(Config.endpointv1 + "/gender", AuthMiddleware(), ApigenderMaster.ListGender, sendResponse)

//  Start category master
router.post(Config.endpointv1 + "/visitorcategory", AuthMiddleware(), Apicategorymaster.ListCategoryMaster, sendResponse)
router.post(Config.endpointv1 + "/visitorcategory/add", AuthMiddleware(), Apicategorymaster.InsertCategoryMaster, sendResponse)
router.post(Config.endpointv1 + "/visitorcategory/update", AuthMiddleware(), Apicategorymaster.UpdateCategoryMaster, sendResponse)
router.delete(Config.endpointv1 + "/visitorcategory/delete", AuthMiddleware(), Apicategorymaster.DeleteCategoryMaster, sendResponse)
//  End category master


//  Start deliverycompany master
router.post(Config.endpointv1 + "/deliverycompany", AuthMiddleware(), Apideliverycompnaymaster.ListDeliveryCompanyMaster, sendResponse)
router.post(Config.endpointv1 + "/deliverycompany/add", AuthMiddleware(), Apideliverycompnaymaster.InsertDeliveryCompanyMaster, sendResponse)
router.post(Config.endpointv1 + "/deliverycompany/update", AuthMiddleware(), Apideliverycompnaymaster.UpdateDeliveryCompanyMaster, sendResponse)
router.delete(Config.endpointv1 + "/deliverycompany/delete", AuthMiddleware(), Apideliverycompnaymaster.DeleteDeliveryCompanyMaster, sendResponse)
//  End deliverycompany master

//  Start committee master
router.post(Config.endpointv1 + "/committee", AuthMiddleware(), Apicommitteemaster.ListCommitteeMaster, sendResponse)
router.post(Config.endpointv1 + "/committee/add", AuthMiddleware(), Apicommitteemaster.InsertCommitteeMaster, sendResponse)
router.post(Config.endpointv1 + "/committee/update", AuthMiddleware(), Apicommitteemaster.UpdateCommitteeMaster, sendResponse)
router.delete(Config.endpointv1 + "/committee/delete", AuthMiddleware(), Apicommitteemaster.DeleteCommitteeMaster, sendResponse)
//  End committee master

//start guest master 
router.post(Config.endpointv1 + "/guest", AuthMiddleware(), Apiguestmaster.ListGuestMaster, sendResponse)
router.post(Config.endpointv1 + "/guest/add", AuthMiddleware(), Apiguestmaster.InsertGuestMaster, sendResponse)
router.post(Config.endpointv1 + "/guest/update", AuthMiddleware(), Apiguestmaster.UpdateGuestMaster, sendResponse)
router.delete(Config.endpointv1 + "/guest/delete", AuthMiddleware(), Apiguestmaster.DeleteGuestMaster, sendResponse)
//  End guest master


//  Start Relation master
router.post(Config.endpointv1 + "/relation", AuthMiddleware(), Apirelationmaster.ListRelation, sendResponse)
router.post(Config.endpointv1 + "/relation/add", AuthMiddleware(), Apirelationmaster.InsertRelation, sendResponse)
router.post(Config.endpointv1 + "/relation/update", AuthMiddleware(), Apirelationmaster.UpdateRelation, sendResponse)
router.delete(Config.endpointv1 + "/relation/delete", AuthMiddleware(), Apirelationmaster.DeleteRelation, sendResponse)
//  End Relation master

//  Start pettype master
router.post(Config.endpointv1 + "/pettype", AuthMiddleware(), Apipettypemaster.ListPetType, sendResponse)
router.post(Config.endpointv1 + "/pettype/add", AuthMiddleware(), Apipettypemaster.InsertPetType, sendResponse)
router.post(Config.endpointv1 + "/pettype/update", AuthMiddleware(), Apipettypemaster.UpdatePetType, sendResponse)
router.delete(Config.endpointv1 + "/pettype/delete", AuthMiddleware(), Apipettypemaster.DeletePetType, sendResponse)
//  End pettype master

//  Start pettype master
router.post(Config.endpointv1 + "/pets", AuthMiddleware(), Apipetmaster.ListPetMaster, sendResponse)
router.post(Config.endpointv1 + "/pets/add", AuthMiddleware(), Apipetmaster.InsertPetMaster, sendResponse)
router.post(Config.endpointv1 + "/petsapprove", AuthMiddleware(), Apipetmaster.ApprovePetMaster, sendResponse)
router.post(Config.endpointv1 + "/pets/update", AuthMiddleware(), Apipetmaster.UpdatePetMaster, sendResponse)
router.delete(Config.endpointv1 + "/pets/delete", AuthMiddleware(), Apipetmaster.DeletePetMaster, sendResponse)
//  End pettype master


//  Start alerts master
router.post(Config.endpointv1 + "/alert", AuthMiddleware(), Apialertmaster.ListAlertsMaster, sendResponse)
router.post(Config.endpointv1 + "/alert/add", AuthMiddleware(), Apialertmaster.InsertAlertsMaster, sendResponse)
router.post(Config.endpointv1 + "/alert/update", AuthMiddleware(), Apialertmaster.UpdateAlertsMaster, sendResponse)
router.delete(Config.endpointv1 + "/alert/delete", AuthMiddleware(), Apialertmaster.DeleteAlertsMaster, sendResponse)
//  End alerts master

//  Start seriestype master
router.post(Config.endpointv1 + "/seriestype", AuthMiddleware(), Apiseriestypemaster.ListSeriesType, sendResponse)
router.post(Config.endpointv1 + "/seriestype/add", AuthMiddleware(), Apiseriestypemaster.InsertSeriesType, sendResponse)
router.post(Config.endpointv1 + "/seriestype/update", AuthMiddleware(), Apiseriestypemaster.UpdateSeriesType, sendResponse)
router.delete(Config.endpointv1 + "/seriestype/delete", AuthMiddleware(), Apiseriestypemaster.DeleteSeriesType, sendResponse)

router.post(Config.endpointv1 + "/serieselement", AuthMiddleware(), Apiserieselement.ListSeriesElement, sendResponse)
//  End seriestype master


// //  Start parking master
// router.post(Config.endpointv1 + "/parking", AuthMiddleware(), Apiparkingmaster.ListParking, sendResponse)
// router.post(Config.endpointv1 + "/parking/add", AuthMiddleware(), Apiparkingmaster.InsertParking, sendResponse)
// router.post(Config.endpointv1 + "/parking/update", AuthMiddleware(), Apiparkingmaster.UpdateParking, sendResponse)
// router.delete(Config.endpointv1 + "/parking/delete", AuthMiddleware(), Apiparkingmaster.DeleteParking, sendResponse)
// //  End parking master

//  Start emergency master
router.post(Config.endpointv1 + "/emergencydir", AuthMiddleware(), Apiemergencydir.ListEmergencyMaster, sendResponse)
router.post(Config.endpointv1 + "/emergencydir/add", AuthMiddleware(), Apiemergencydir.InsertEmergencydirMaster, sendResponse)
router.post(Config.endpointv1 + "/emergencydir/update", AuthMiddleware(), Apiemergencydir.UpdateEmergencydirMaster, sendResponse)
router.delete(Config.endpointv1 + "/emergencydir/delete", AuthMiddleware(), Apiemergencydir.DeleteEmergencydirMaster, sendResponse)
//  End emergency master


//  Start emergency master
router.post(Config.endpointv1 + "/localdir", AuthMiddleware(), Apilocaldir.ListlocalDirMaster, sendResponse)
router.post(Config.endpointv1 + "/localdir/add", AuthMiddleware(), Apilocaldir.InsertlocalDirMaster, sendResponse)
router.post(Config.endpointv1 + "/localdir/update", AuthMiddleware(), Apilocaldir.UpdatelocalDirMaster, sendResponse)
router.delete(Config.endpointv1 + "/localdir/delete", AuthMiddleware(), Apilocaldir.DeletelocalDirMaster, sendResponse)
//  End emergency master

// //  Start emergency master
// router.post(Config.endpointv1 + "/localdir", AuthMiddleware(), ApiLocaldir.ListLocalMaster, sendResponse)
// router.post(Config.endpointv1 + "/localdir/add", AuthMiddleware(), ApiLocaldir.InsertLocaldirMaster, sendResponse)
// router.post(Config.endpointv1 + "/localdir/update", AuthMiddleware(), ApiLocaldir.UpdateLocaldirMaster, sendResponse)
// router.delete(Config.endpointv1 + "/localdir/delete", AuthMiddleware(), ApiLocaldir.DeleteLocaldirMaster, sendResponse)
// //  End emergency master

//  Start breed master
router.post(Config.endpointv1 + "/breed", AuthMiddleware(), Apibreedmaster.ListBreed, sendResponse)
router.post(Config.endpointv1 + "/breed/add", AuthMiddleware(), Apibreedmaster.InsertBreed, sendResponse)
router.post(Config.endpointv1 + "/breed/update", AuthMiddleware(), Apibreedmaster.UpdateBreed, sendResponse)
router.delete(Config.endpointv1 + "/breed/delete", AuthMiddleware(), Apibreedmaster.DeleteBreed, sendResponse)
//  End breed master

//Start businessstructure Master
router.post(Config.endpointv1 + "/businessstructure", AuthMiddleware(), Apibusinessstructuremaster.ListBusinessStructure, sendResponse)
router.post(Config.endpointv1 + "/businessstructure/add", AuthMiddleware(), Apibusinessstructuremaster.InsertBusinessStructure, sendResponse)
router.post(Config.endpointv1 + "/businessstructure/update", AuthMiddleware(), Apibusinessstructuremaster.UpdateBusinessStructure, sendResponse)
router.delete(Config.endpointv1 + "/businessstructure/delete", AuthMiddleware(), Apibusinessstructuremaster.DeleteBusinessStructure, sendResponse)
//End businessstructure Master

//Start deliverytype Master
router.post(Config.endpointv1 + "/deliverytype", AuthMiddleware(), Apideliverytypemaster.ListDeliveryTypeMaster, sendResponse)
router.post(Config.endpointv1 + "/deliverytype/add", AuthMiddleware(), Apideliverytypemaster.InsertDeliveryTypeMaster, sendResponse)
router.post(Config.endpointv1 + "/deliverytype/update", AuthMiddleware(), Apideliverytypemaster.UpdateDeliveryTypeMaster, sendResponse)
router.delete(Config.endpointv1 + "/deliverytype/delete", AuthMiddleware(), Apideliverytypemaster.DeleteDeliveryTypeMaster, sendResponse)
//End deliverytype Master

//Start dailyhelp Master
router.post(Config.endpointv1 + "/dailyhelpcategory", AuthMiddleware(), Apidailyhelpmaster.ListDailyhelpCategory, sendResponse)
router.post(Config.endpointv1 + "/dailyhelpcategory/add", AuthMiddleware(), Apidailyhelpmaster.InsertDailyhelpCategory, sendResponse)
router.post(Config.endpointv1 + "/dailyhelpcategory/update", AuthMiddleware(), Apidailyhelpmaster.UpdateDailyhelpCategory, sendResponse)
router.delete(Config.endpointv1 + "/dailyhelpcategory/delete", AuthMiddleware(), Apidailyhelpmaster.DeleteDailyhelpCategory, sendResponse)
//End dailyhelp Master

//Start dailyhelpbooking 
router.post(Config.endpointv1 + "/dailyhelp/booking", AuthMiddleware(), Apidailyhelpbooking.ListDailyhelpBooking, sendResponse)
router.post(Config.endpointv1 + "/dailyhelp/booking/add", AuthMiddleware(), Apidailyhelpbooking.InsertDailyhelpBooking, sendResponse)
router.post(Config.endpointv1 + "/dailyhelp/booking/update", AuthMiddleware(), Apidailyhelpbooking.UpdateDailyhelpBooking, sendResponse)
// router.delete(Config.endpointv1 + "/dailyhelp/booking/delete", AuthMiddleware(), Apidailuhelpbooking.del, sendResponse)
//End dailyhelpbooking 

//start dailyhelp
router.post(Config.endpointv1 + "/dailyhelp", AuthMiddleware(), Apidailyhelp.ListDailyhelpMaster, sendResponse)
router.post(Config.endpointv1 + "/dailyhelp/add", AuthMiddleware(), Apidailyhelp.InsertDailyhelpMaster, sendResponse)
router.post(Config.endpointv1 + "/dailyhelp/update", AuthMiddleware(), Apidailyhelp.UpdateDailyhelpMaster, sendResponse)
router.delete(Config.endpointv1 + "/dailyhelp/delete", AuthMiddleware(), Apidailyhelp.DeleteDailyhelpMaster, sendResponse)
//End dailyhelp 

//start dailyhelp rating
router.post(Config.endpointv1 + "/dailyhelp/rating", AuthMiddleware(), Apidailyhelpbooking.ListDailyhelpRating, sendResponse)
router.post(Config.endpointv1 + "/dailyhelp/rating/add", AuthMiddleware(), Apidailyhelpbooking.InsertDailyhelpRating, sendResponse)
//end dailyhelp rating
router.post(Config.endpointv1 + "/dailyhelp/assignslot", AuthMiddleware(), Apidailyhelpbooking.ListAssignSlot, sendResponse)


//  Start Country master
router.post(Config.endpointv1 + "/country", AuthMiddleware(), Apicountrymaster.ListCountry, sendResponse)
router.post(Config.endpointv1 + "/country/add", AuthMiddleware(), Apicountrymaster.InsertCountry, sendResponse)
router.post(Config.endpointv1 + "/country/update", AuthMiddleware(), Apicountrymaster.UpdateCountry, sendResponse)
router.delete(Config.endpointv1 + "/country/delete", AuthMiddleware(), Apicountrymaster.DeleteCountry, sendResponse)
//  End Country master

router.post(Config.endpointv1 + "/city", AuthMiddleware(), ApicityMaster.ListCity, sendResponse)
router.post(Config.endpointv1 + "/city/add", AuthMiddleware(), ApicityMaster.InsertCity, sendResponse)
router.post(Config.endpointv1 + "/city/update", AuthMiddleware(), ApicityMaster.UpdateCity, sendResponse)
router.delete(Config.endpointv1 + "/city/delete", AuthMiddleware(), ApicityMaster.DeleteCity, sendResponse)
//end city master

//  START State master
router.post(Config.endpointv1 + '/state', AuthMiddleware(), ApistateMaster.ListState, sendResponse)
router.post(Config.endpointv1 + '/state/add', AuthMiddleware(), ApistateMaster.InsertState, sendResponse)
router.post(Config.endpointv1 + '/state/update', AuthMiddleware(), ApistateMaster.UpdateState, sendResponse)
router.delete(Config.endpointv1 + '/state/delete', AuthMiddleware(), ApistateMaster.DeleteState, sendResponse)
//  END State master

//  START pincode master
router.post(Config.endpointv1 + '/pincode', AuthMiddleware(), ApipincodeMaster.ListPincode, sendResponse)
router.post(Config.endpointv1 + '/pincode/add', AuthMiddleware(), ApipincodeMaster.InsertPincode, sendResponse)
router.post(Config.endpointv1 + '/pincode/update', AuthMiddleware(), ApipincodeMaster.UpdatePincode, sendResponse)
router.delete(Config.endpointv1 + '/pincode/delete', AuthMiddleware(), ApipincodeMaster.DeletePincode, sendResponse)
//  END pincode master

//  START areatype master
router.post(Config.endpointv1 + '/areatype', AuthMiddleware(), Apiareamaster.ListAreatype, sendResponse)
router.post(Config.endpointv1 + '/areatype/add', AuthMiddleware(), Apiareamaster.InsertAreatype, sendResponse)
router.post(Config.endpointv1 + '/areatype/update', AuthMiddleware(), Apiareamaster.UpdateAreatype, sendResponse)
router.delete(Config.endpointv1 + '/areatype/delete', AuthMiddleware(), Apiareamaster.DeleteAreatype, sendResponse)
//  END areatype master

//  Start menu master
router.post(Config.endpointv1 + "/menu", AuthMiddleware(), Apimenumaster.ListMenu, sendResponse)
router.post(Config.endpointv1 + "/menu/add", AuthMiddleware(), Apimenumaster.InsertMenu, sendResponse)
router.post(Config.endpointv1 + "/menu/update", AuthMiddleware(), Apimenumaster.UpdateMenu, sendResponse)
router.delete(Config.endpointv1 + "/menu/delete", AuthMiddleware(), Apimenumaster.DeleteMenu, sendResponse)
router.post(Config.endpointv1 + "/masters", AuthMiddleware(), Apimenumaster.MasterMenu, sendResponse)
//  End menu master

//  Start Icon master
router.post(Config.endpointv1 + "/icon", AuthMiddleware(), Apiiconmaster.ListIcon, sendResponse)
router.post(Config.endpointv1 + "/icon/add", AuthMiddleware(), Apiiconmaster.InsertIcon, sendResponse)
router.post(Config.endpointv1 + "/icon/update", AuthMiddleware(), Apiiconmaster.UpdateIcon, sendResponse)
router.delete(Config.endpointv1 + "/icon/delete", AuthMiddleware(), Apiiconmaster.DeleteIcon, sendResponse)
//  End Icon master

//  Start fieldorder master
router.post(Config.endpointv1 + "/fieldorder/add", AuthMiddleware(), Apifieldorder.InsertFieldOrder, sendResponse)
//  End fieldorder master

//  Start module master
router.post(Config.endpointv1 + "/module", AuthMiddleware(), Apimodulemaster.ListModule, sendResponse)
router.post(Config.endpointv1 + "/module/add", AuthMiddleware(), Apimodulemaster.InsertModule, sendResponse)
router.post(Config.endpointv1 + "/module/update", AuthMiddleware(), Apimodulemaster.UpdateModule, sendResponse)
router.delete(Config.endpointv1 + "/module/delete", AuthMiddleware(), Apimodulemaster.DeleteModule, sendResponse)
//  End module master

//  Start module type master
router.post(Config.endpointv1 + "/moduletype", AuthMiddleware(), Apimoduletypemaster.ListModuleType, sendResponse)
//  End module type master

//  Start UserRole master
router.post(Config.endpointv1 + "/userrole", AuthMiddleware(), Apiuserrolemaster.ListUserRole, sendResponse)
router.post(Config.endpointv1 + "/userrolehierarchywise", AuthMiddleware(), Apiuserrolemaster.ListUserRoleHireachywise, sendResponse)
router.post(Config.endpointv1 + "/userrole/add", AuthMiddleware(), Apiuserrolemaster.InsertUserRole, sendResponse)
router.post(Config.endpointv1 + "/userrole/update", AuthMiddleware(), Apiuserrolemaster.UpdateUserRole, sendResponse)
router.delete(Config.endpointv1 + "/userrole/delete", AuthMiddleware(), Apiuserrolemaster.DeleteUserRole, sendResponse)
//  End UserRole master

//  Start UserRoleHierarchy master
router.post(Config.endpointv1 + "/userrolehierarchy", AuthMiddleware(), Apiuserrolehierarchy.ListUserRoleHierarchy, sendResponse)
router.post(Config.endpointv1 + "/userrolehierarchy/add", AuthMiddleware(), Apiuserrolehierarchy.UpdateUserRoleHirarchy, sendResponse)
//  End UserRoleHierarchy master

//  Start MenuAssign master
router.post(Config.endpointv1 + "/menuassign", AuthMiddleware(), Apimenuassignmaster.ListMenuAssign, sendResponse)
router.post(Config.endpointv1 + "/menuassign/update", AuthMiddleware(), Apimenuassignmaster.UpdateMenuAssign, sendResponse)
//  End MenuAssign master

// Start MenuDesign master
router.post(Config.endpointv1 + "/menudesign", AuthMiddleware(), Apimenudesignmaster.ListDesignMenu, sendResponse)
router.post(Config.endpointv1 + "/menudesign/update", AuthMiddleware(), Apimenudesignmaster.InsertMenuDesign, sendResponse)
// End MenuDesign master

//  Start Userrights master
router.post(Config.endpointv1 + "/userrights", AuthMiddleware(), Apiuserrightsmaster.ListUserrights, sendResponse)
router.post(Config.endpointv1 + "/userrights/update", AuthMiddleware(), Apiuserrightsmaster.UpdateUserrights, sendResponse)
//  End Userrights master


//  Start Usertemplate master
router.post(Config.endpointv1 + "/templaterights", AuthMiddleware(), ApiUserRightsTemplate.ListTemplateRights, sendResponse)
router.post(Config.endpointv1 + "/templaterights/add", AuthMiddleware(), ApiUserRightsTemplate.InsertTemplateRights, sendResponse)
router.post(Config.endpointv1 + "/templaterights/update", AuthMiddleware(), ApiUserRightsTemplate.UpdateTemplateRights, sendResponse)
router.delete(Config.endpointv1 + "/templaterights/delete", AuthMiddleware(), ApiUserRightsTemplate.DeleteTemplateRights, sendResponse)
//  End Usertemplate master


//Start Designation Master
router.post(Config.endpointv1 + "/designation", AuthMiddleware(), ApidesignationMaster.ListDesignation, sendResponse)
router.post(Config.endpointv1 + "/designation/add", AuthMiddleware(), ApidesignationMaster.InsertDesignation, sendResponse)
router.post(Config.endpointv1 + "/designation/update", AuthMiddleware(), ApidesignationMaster.UpdateDesignation, sendResponse)
router.delete(Config.endpointv1 + "/designation/delete", AuthMiddleware(), ApidesignationMaster.DeleteDesignation, sendResponse)
//End Designation Master


//Start department Master
router.post(Config.endpointv1 + "/department", AuthMiddleware(), Apidepartmentmaster.ListDepartment, sendResponse)
router.post(Config.endpointv1 + "/department/add", AuthMiddleware(), Apidepartmentmaster.InsertDepartment, sendResponse)
router.post(Config.endpointv1 + "/department/update", AuthMiddleware(), Apidepartmentmaster.UpdateDepartment, sendResponse)
router.delete(Config.endpointv1 + "/department/delete", AuthMiddleware(), Apidepartmentmaster.DeleteDepartment, sendResponse)
//End department Master

//  Start Series master
router.post(Config.endpointv1 + "/series", AuthMiddleware(), Apiseriesmaster.ListSeries, sendResponse)
router.post(Config.endpointv1 + "/series/add", AuthMiddleware(), Apiseriesmaster.InsertSeries, sendResponse)
router.post(Config.endpointv1 + "/series/update", AuthMiddleware(), Apiseriesmaster.UpdateSeries, sendResponse)
router.delete(Config.endpointv1 + "/series/delete", AuthMiddleware(), Apiseriesmaster.DeleteSeries, sendResponse)
//  End Series master

// // Start Errorlog
// router.post(Config.endpointv1 + "/errorlog", AuthMiddleware(), Apierrorlog.ListErrorLog, sendResponse)
// // End Errorlog

//  START EmailSMTP master
router.post(Config.endpointv1 + "/emailsmtp", AuthMiddleware(), Apiemailsmtp.ListEmailSMTP, sendResponse)
router.post(Config.endpointv1 + "/emailsmtp/add", AuthMiddleware(), Apiemailsmtp.InsertEmailSMTP, sendResponse)
router.post(Config.endpointv1 + "/emailsmtp/update", AuthMiddleware(), Apiemailsmtp.UpdateEmailSMTP, sendResponse)
router.delete(Config.endpointv1 + "/emailsmtp/delete", AuthMiddleware(), Apiemailsmtp.DeleteEmailSMTP, sendResponse)
//  END EmailSMTP master

//  START notice master
router.post(Config.endpointv1 + "/notice", AuthMiddleware(), Apinoticemaster.ListNoticeMaster, sendResponse)
router.post(Config.endpointv1 + "/notice/add", AuthMiddleware(), Apinoticemaster.InsertNoticeMaster, sendResponse)
router.post(Config.endpointv1 + "/notice/update", AuthMiddleware(), Apinoticemaster.UpdateNoticeMaster, sendResponse)
router.delete(Config.endpointv1 + "/notice/delete", AuthMiddleware(), Apinoticemaster.DeleteNoticeMaster, sendResponse)
//  END notice master

//  START policy master
router.post(Config.endpointv1 + "/policy", AuthMiddleware(), Apipolicymaster.ListPolicyMaster, sendResponse)
router.post(Config.endpointv1 + "/policy/add", AuthMiddleware(), Apipolicymaster.InsertPolicyMaster, sendResponse)
router.post(Config.endpointv1 + "/policy/update", AuthMiddleware(), Apipolicymaster.UpdatePolicyMaster, sendResponse)
router.delete(Config.endpointv1 + "/policy/delete", AuthMiddleware(), Apipolicymaster.DeletePolicyMaster, sendResponse)
//  END policy master

//  START Incident master
router.post(Config.endpointv1 + "/incident", AuthMiddleware(), Apiincidentmaster.ListIncidentMaster, sendResponse)
router.post(Config.endpointv1 + "/incident/add", AuthMiddleware(), Apiincidentmaster.InsertIncidentMaster, sendResponse)
router.post(Config.endpointv1 + "/incident/update", AuthMiddleware(), Apiincidentmaster.UpdateIncidentMaster, sendResponse)
router.delete(Config.endpointv1 + "/incident/delete", AuthMiddleware(), Apiincidentmaster.DeleteIncidentMaster, sendResponse)
//  END Incident master

// Start availability
router.post(Config.endpointv1 + "/availability", AuthMiddleware(), Apiavailabilitymaster.ListAvailabilityMaster, sendResponse)
router.post(Config.endpointv1 + "/availability/add", AuthMiddleware(), Apiavailabilitymaster.InsertAvailabilityMaster, sendResponse)
router.post(Config.endpointv1 + "/availability/update", AuthMiddleware(), Apiavailabilitymaster.UpdateAvailabilityMaster, sendResponse)
router.delete(Config.endpointv1 + "/availability/delete", AuthMiddleware(), Apiavailabilitymaster.DeleteAvailabilityMaster, sendResponse)

// Start assetcategory
router.post(Config.endpointv1 + "/assetcategory", AuthMiddleware(), Apiassetcategorymaster.ListAssetCategoryMaster, sendResponse)
router.post(Config.endpointv1 + "/assetcategory/add", AuthMiddleware(), Apiassetcategorymaster.InsertAssetCategoryMaster, sendResponse)
router.post(Config.endpointv1 + "/assetcategory/update", AuthMiddleware(), Apiassetcategorymaster.UpdateAssetCategoryMaster, sendResponse)
router.delete(Config.endpointv1 + "/assetcategory/delete", AuthMiddleware(), Apiassetcategorymaster.DeleteAssetCategoryMaster, sendResponse)
// End assetcategory

// Start assettype
router.post(Config.endpointv1 + "/assettype", AuthMiddleware(), Apiassettypemaster.ListAssetTypeMaster, sendResponse)
router.post(Config.endpointv1 + "/assettype/add", AuthMiddleware(), Apiassettypemaster.InsertAssetTypeMaster, sendResponse)
router.post(Config.endpointv1 + "/assettype/update", AuthMiddleware(), Apiassettypemaster.UpdateAssetTypeMaster, sendResponse)
router.delete(Config.endpointv1 + "/assettype/delete", AuthMiddleware(), Apiassettypemaster.DeleteAssetTypeMaster, sendResponse)

// Start capacity unit
router.post(Config.endpointv1 + "/assetcapacityunit", AuthMiddleware(), AssetCapacityUnitMaster.ListAssetCapacityUnitMaster, sendResponse)
router.post(Config.endpointv1 + "/assetcapacityunit/add", AuthMiddleware(), AssetCapacityUnitMaster.InsertAssetCapacityUnitMaster, sendResponse)
router.post(Config.endpointv1 + "/assetcapacityunit/update", AuthMiddleware(), AssetCapacityUnitMaster.UpdateAssetCapacityUnitMaster, sendResponse)
router.delete(Config.endpointv1 + "/assetcapacityunit/delete", AuthMiddleware(), AssetCapacityUnitMaster.DeleteAssetCapacityUnitMaster, sendResponse)
// End capacity unit

// Start assetstatus
router.post(Config.endpointv1 + "/assetstatus", AuthMiddleware(), Apiassetstatusmaster.ListAssetStatusMaster, sendResponse)
router.post(Config.endpointv1 + "/assetstatus/add", AuthMiddleware(), Apiassetstatusmaster.InsertAssetStatusMaster, sendResponse)
router.post(Config.endpointv1 + "/assetstatus/update", AuthMiddleware(), Apiassetstatusmaster.UpdateAssetStatusMaster, sendResponse)
router.delete(Config.endpointv1 + "/assetstatus/delete", AuthMiddleware(), Apiassetstatusmaster.DeleteAssetStatusMaster, sendResponse)
// End assetstatus


// Start assettype
router.post(Config.endpointv1 + "/assets", AuthMiddleware(), Apiassetmaster.ListAssetMaster, sendResponse)
router.post(Config.endpointv1 + "/assets/add", AuthMiddleware(), Apiassetmaster.InsertAssetMaster, sendResponse)
router.post(Config.endpointv1 + "/assets/update", AuthMiddleware(), Apiassetmaster.UpdateAssetMaster, sendResponse)
router.delete(Config.endpointv1 + "/assets/delete", AuthMiddleware(), Apiassetmaster.DeleteAssetMaster, sendResponse)
// End assettype

// Start assetcondition
router.post(Config.endpointv1 + "/assetcondition", AuthMiddleware(), Apiassetconditionmaster.ListAssetconditionMaster, sendResponse)
router.post(Config.endpointv1 + "/assetcondition/add", AuthMiddleware(), Apiassetconditionmaster.InsertAssetconditionMaster, sendResponse)
router.post(Config.endpointv1 + "/assetcondition/update", AuthMiddleware(), Apiassetconditionmaster.UpdateAssetconditionMaster, sendResponse)
router.delete(Config.endpointv1 + "/assetcondition/delete", AuthMiddleware(), Apiassetconditionmaster.DeleteAssetconditionMaster, sendResponse)
// End assetcondition


// Start item
router.post(Config.endpointv1 + "/items", AuthMiddleware(), Apiitemmaster.ListItemMaster, sendResponse)
router.post(Config.endpointv1 + "/items/add", AuthMiddleware(), Apiitemmaster.InsertItems, sendResponse)
router.post(Config.endpointv1 + "/items/update", AuthMiddleware(), Apiitemmaster.UpdateItemsMaster, sendResponse)
router.delete(Config.endpointv1 + "/items/delete", AuthMiddleware(), Apiitemmaster.DeleteItemsMaster, sendResponse)
// End item

//  START Knowledgebase master
router.post(Config.endpointv1 + "/knowledgebase", AuthMiddleware(), Apiknowledgebasemaster.ListKnowledgebaseMaster, sendResponse)
router.post(Config.endpointv1 + "/knowledgebase/add", AuthMiddleware(), Apiknowledgebasemaster.InsertKnowledgebaseMaster, sendResponse)
router.post(Config.endpointv1 + "/knowledgebase/update", AuthMiddleware(), Apiknowledgebasemaster.UpdateKnowledgebaseMaster, sendResponse)
router.delete(Config.endpointv1 + "/knowledgebase/delete", AuthMiddleware(), Apiknowledgebasemaster.DeleteKnowledgebaseMaster, sendResponse)
//  END Knowledgebase master

//  START event master
router.post(Config.endpointv1 + "/event", AuthMiddleware(), Apieventmaster.ListEventMaster, sendResponse)
router.post(Config.endpointv1 + "/event/add", AuthMiddleware(), Apieventmaster.InsertEventMaster, sendResponse)
router.post(Config.endpointv1 + "/event/update", AuthMiddleware(), Apieventmaster.UpdateEventMaster, sendResponse)
router.delete(Config.endpointv1 + "/event/delete", AuthMiddleware(), Apieventmaster.DeleteEventMaster, sendResponse)
//  END event master

//  START event master
router.post(Config.endpointv1 + "/eventcategory", AuthMiddleware(), Apieventcategorymaster.ListEventCategoryMaster, sendResponse)
router.post(Config.endpointv1 + "/eventcategory/add", AuthMiddleware(), Apieventcategorymaster.InsertEventCategoryMaster, sendResponse)
router.post(Config.endpointv1 + "/eventcategory/update", AuthMiddleware(), Apieventcategorymaster.UpdateEventCategoryMaster, sendResponse)
router.delete(Config.endpointv1 + "/eventcategory/delete", AuthMiddleware(), Apieventcategorymaster.DeleteEventCategoryMaster, sendResponse)
//  END event master


//  START event master
router.post(Config.endpointv1 + "/emergencycategory", AuthMiddleware(), Apiemergencycategory.ListEmergencycategory, sendResponse)
router.post(Config.endpointv1 + "/emergencycategory/add", AuthMiddleware(), Apiemergencycategory.InsertEmergencycategory, sendResponse)
router.post(Config.endpointv1 + "/emergencycategory/update", AuthMiddleware(), Apiemergencycategory.UpdateEmergencycategory, sendResponse)
router.delete(Config.endpointv1 + "/emergencycategory/delete", AuthMiddleware(), Apiemergencycategory.DeleteEmergencycategory, sendResponse)
//  END event master


//  Resident
router.post(Config.endpointv1 + "/residents", AuthMiddleware(), ApicustomerAuth.ListResidents, sendResponse)
router.post(Config.endpointv1 + "/committee", AuthMiddleware(), ApicustomerAuth.ListCommittee, sendResponse)
router.post(Config.endpointv1 + "/residents/pet", AuthMiddleware(), ApicustomerAuth.ListResidentsPet, sendResponse)

//  Start CheckListType master
router.post(Config.endpointv1 + "/checklisttype", AuthMiddleware(), Apichecklisttypemaster.ListCheckListType, sendResponse)
router.post(Config.endpointv1 + "/checklisttype/add", AuthMiddleware(), Apichecklisttypemaster.InsertCheckListType, sendResponse)
router.post(Config.endpointv1 + "/checklisttype/update", AuthMiddleware(), Apichecklisttypemaster.UpdateCheckListType, sendResponse)
router.delete(Config.endpointv1 + "/checklisttype/delete", AuthMiddleware(), Apichecklisttypemaster.DeleteCheckListType, sendResponse)

router.post(Config.endpointv1 + "/recurrencetype", AuthMiddleware(), Apichecklisttypemaster.ListRecurrencetype, sendResponse)
router.post(Config.endpointv1 + "/recurrencetype/add", AuthMiddleware(), Apichecklisttypemaster.InsertRecurrencetype, sendResponse)

//  End CheckListType master

//  Start CheckListType master
router.post(Config.endpointv1 + "/vehicle", AuthMiddleware(), Apivehiclemaster.ListVehicleMaster, sendResponse)
router.post(Config.endpointv1 + "/vehicle/add", AuthMiddleware(), Apivehiclemaster.InsertVehicleMaster, sendResponse)
router.post(Config.endpointv1 + "/vehicle/update", AuthMiddleware(), Apivehiclemaster.UpdateVehicleMaster, sendResponse)
router.delete(Config.endpointv1 + "/vehicle/delete", AuthMiddleware(), Apivehiclemaster.DeleteVehicleMaster, sendResponse)
//  End CheckListType master

//start Survey Form
router.post(Config.endpointv1 + '/surveyform', AuthMiddleware(), Apisurveyform.ListSurveyForm, sendResponse)
router.post(Config.endpointv1 + '/surveyform/add', AuthMiddleware(), Apisurveyform.InsertSurveyForm, sendResponse)
router.post(Config.endpointv1 + '/surveyform/update', AuthMiddleware(), Apisurveyform.UpdateSurveyForm, sendResponse)
router.delete(Config.endpointv1 + '/surveyform/delete', AuthMiddleware(), Apisurveyform.DeleteSurveyForm, sendResponse)
//End Survey Form

//start Survey 
router.post(Config.endpointv1 + '/survey', AuthMiddleware(), Apisurvey.ListSurvey, sendResponse)
router.post(Config.endpointv1 + '/getsurvey', AuthMiddleware(), Apisurvey.GetSurvey, sendResponse)
router.post(Config.endpointv1 + '/survey/add', AuthMiddleware(), Apisurvey.InsertSurvey, sendResponse)
router.post(Config.endpointv1 + '/survey/update', AuthMiddleware(), Apisurvey.UpdateSurvey, sendResponse)
router.delete(Config.endpointv1 + '/survey/delete', AuthMiddleware(), Apisurvey.DeleteSurvey, sendResponse)
router.post(Config.endpointv1 + '/surveyemailsend', AuthMiddleware(), Apisurvey.SurveyEmailSend, sendResponse)
router.post(Config.endpointv1 + '/surveyresponse', AuthMiddleware(), Apisurvey.SurveyResponse, sendResponse)
router.post(Config.endpointv1 + '/surveyanalyticsresponse', AuthMiddleware(), Apisurvey.SurveyAnalyticsResponse, sendResponse)
router.post(Config.endpointv1 + '/surveyrecords/add', AuthMiddleware(), Apisurvey.InsertSurveyRecords, sendResponse)
//End Survey 
router.post(Config.endpointv1 + '/surveytype', AuthMiddleware(), Apisurveytype.ListSurveyType, sendResponse)


//  Start checklist master
router.post(Config.endpointv1 + "/checklist", AuthMiddleware(), Apichecklist.ListChecklist, sendResponse)
router.post(Config.endpointv1 + "/checklist/add", AuthMiddleware(), Apichecklist.InsertChecklist, sendResponse)
router.post(Config.endpointv1 + "/checklist/update", AuthMiddleware(), Apichecklist.UpdateChecklist, sendResponse)
router.delete(Config.endpointv1 + "/checklist/delete", AuthMiddleware(), Apichecklist.DeleteChecklist, sendResponse)
//  End checklist master

//  Start amenities master
router.post(Config.endpointv1 + "/amenitiestype", AuthMiddleware(), ApiAmenitiestype.ListAmenitiesTypeMaster, sendResponse)
router.post(Config.endpointv1 + "/amenitiestype/add", AuthMiddleware(), ApiAmenitiestype.InsertAmenitiesTypeMaster, sendResponse)
router.post(Config.endpointv1 + "/amenitiestype/update", AuthMiddleware(), ApiAmenitiestype.UpdateAmenitiesTypeMaster, sendResponse)
router.delete(Config.endpointv1 + "/amenitiestype/delete", AuthMiddleware(), ApiAmenitiestype.DeleteAmenitiesTypeMaster, sendResponse)
//  End amenities master

//  Start amenities master
router.post(Config.endpointv1 + "/occupancystatus", AuthMiddleware(), Apioccupationmaster.ListOccupancyStatusMaster, sendResponse)
router.post(Config.endpointv1 + "/occupancystatus/add", AuthMiddleware(), Apioccupationmaster.InsertOccupancyStatusMaster, sendResponse)
router.post(Config.endpointv1 + "/occupancystatus/update", AuthMiddleware(), Apioccupationmaster.UpdateOccupancyStatusMaster, sendResponse)
router.delete(Config.endpointv1 + "/occupancystatus/delete", AuthMiddleware(), Apioccupationmaster.DeleteOccupancyStatusMaster, sendResponse)
//  End amenities master

//  Start flattype master
router.post(Config.endpointv1 + "/flattype", AuthMiddleware(), Apiflattypemaster.ListFlattypeMaster, sendResponse)
router.post(Config.endpointv1 + "/flattype/add", AuthMiddleware(), Apiflattypemaster.InsertFlattypeMaster, sendResponse)
router.post(Config.endpointv1 + "/flattype/update", AuthMiddleware(), Apiflattypemaster.UpdateFlattypeMaster, sendResponse)
router.delete(Config.endpointv1 + "/flattype/delete", AuthMiddleware(), Apiflattypemaster.DeleteFlattypeMaster, sendResponse)
//  End flattype master

//  Start vehicletype master
router.post(Config.endpointv1 + "/vehicletype", AuthMiddleware(), Apivehicletypemaster.ListVehicleTypemaster, sendResponse)
router.post(Config.endpointv1 + "/vehicletype/add", AuthMiddleware(), Apivehicletypemaster.InsertVehicleTypemaster, sendResponse)
router.post(Config.endpointv1 + "/vehicletype/update", AuthMiddleware(), Apivehicletypemaster.UpdateVehicleTypemaster, sendResponse)
router.delete(Config.endpointv1 + "/vehicletype/delete", AuthMiddleware(), Apivehicletypemaster.DeleteVehicleTypemaster, sendResponse)
//  End vehicletype master

//  Start vehicletype master
router.post(Config.endpointv1 + "/vehicle", AuthMiddleware(), Apivehicletypemaster.ListVehicleTypemaster, sendResponse)
router.post(Config.endpointv1 + "/vehicle/add", AuthMiddleware(), Apivehicletypemaster.InsertVehicleTypemaster, sendResponse)
router.post(Config.endpointv1 + "/vehicle/update", AuthMiddleware(), Apivehicletypemaster.UpdateVehicleTypemaster, sendResponse)
router.delete(Config.endpointv1 + "/vehicle/delete", AuthMiddleware(), Apivehicletypemaster.DeleteVehicleTypemaster, sendResponse)
//  End vehicletype master

//  Start Vendorstaffdesignation master
router.post(Config.endpointv1 + "/Vendorstaffdesignation", AuthMiddleware(), Apivendorstaffdesignationmaster.ListVendorstaffdesignationMaster, sendResponse)
router.post(Config.endpointv1 + "/Vendorstaffdesignation/add", AuthMiddleware(), Apivendorstaffdesignationmaster.InsertVendorstaffdesignationMaster, sendResponse)
router.post(Config.endpointv1 + "/Vendorstaffdesignation/update", AuthMiddleware(), Apivendorstaffdesignationmaster.UpdateVendorstaffdesignationMaster, sendResponse)
router.delete(Config.endpointv1 + "/Vendorstaffdesignation/delete", AuthMiddleware(), Apivendorstaffdesignationmaster.DeleteVendorstaffdesignationMaster, sendResponse)
//  End Vendorstaffdesignation master

//  Start gsttreatment master
router.post(Config.endpointv1 + "/gsttreatment", AuthMiddleware(), Apigsttreatmentmaster.ListGstTreatment, sendResponse)
router.post(Config.endpointv1 + "/gsttreatment/add", AuthMiddleware(), Apigsttreatmentmaster.InsertGstTreatment, sendResponse)
router.post(Config.endpointv1 + "/gsttreatment/update", AuthMiddleware(), Apigsttreatmentmaster.UpdateGstTreatment, sendResponse)
router.delete(Config.endpointv1 + "/gsttreatment/delete", AuthMiddleware(), Apigsttreatmentmaster.DeleteGstTreatment, sendResponse)
//  End gsttreatment master


//  Start channel master
router.post(Config.endpointv1 + "/channel", AuthMiddleware(), Apichannelmaster.ListChannelMaster, sendResponse)
router.post(Config.endpointv1 + "/channel/add", AuthMiddleware(), Apichannelmaster.InsertChannelMaster, sendResponse)
router.post(Config.endpointv1 + "/channel/update", AuthMiddleware(), Apichannelmaster.UpdateChannelMaster, sendResponse)
router.delete(Config.endpointv1 + "/channel/delete", AuthMiddleware(), Apichannelmaster.DeleteChannelMaster, sendResponse)
//  End channel master


//  Start msmeregtype master
router.post(Config.endpointv1 + "/msmeregtype", AuthMiddleware(), Apimsmeregtypemaster.ListMsmeRegType, sendResponse)
router.post(Config.endpointv1 + "/msmeregtype/add", AuthMiddleware(), Apimsmeregtypemaster.InsertMsmeRegType, sendResponse)
router.post(Config.endpointv1 + "/msmeregtype/update", AuthMiddleware(), Apimsmeregtypemaster.UpdateMsmeRegType, sendResponse)
router.delete(Config.endpointv1 + "/msmeregtype/delete", AuthMiddleware(), Apimsmeregtypemaster.DeleteMsmeRegType, sendResponse)
//  End msmeregtype master


//  Start sourceofsupply master
router.post(Config.endpointv1 + "/sourceofsupply", AuthMiddleware(), Apisourceofsupplymaster.ListSourceOfSupply, sendResponse)
router.post(Config.endpointv1 + "/sourceofsupply/add", AuthMiddleware(), Apisourceofsupplymaster.InsertSourceOfSupply, sendResponse)
router.post(Config.endpointv1 + "/sourceofsupply/update", AuthMiddleware(), Apisourceofsupplymaster.UpdateSourceOfSupply, sendResponse)
router.delete(Config.endpointv1 + "/sourceofsupply/delete", AuthMiddleware(), Apisourceofsupplymaster.DeleteSourceOfSupply, sendResponse)
//  End sourceofsupply master

//  Start lostandfoundpriority master
router.post(Config.endpointv1 + "/lostandfoundpriority", AuthMiddleware(), Apilostandfoundprioritymaster.ListLostAndFoundPriority, sendResponse)
router.post(Config.endpointv1 + "/lostandfoundpriority/add", AuthMiddleware(), Apilostandfoundprioritymaster.InsertLostAndFoundPriority, sendResponse)
router.post(Config.endpointv1 + "/lostandfoundpriority/update", AuthMiddleware(), Apilostandfoundprioritymaster.UpdateLostAndFoundPriority, sendResponse)
router.delete(Config.endpointv1 + "/lostandfoundpriority/delete", AuthMiddleware(), Apilostandfoundprioritymaster.DeleteLostAndFoundPriority, sendResponse)
//  End lostandfoundpriority master

//  Start lostandfound master
router.post(Config.endpointv1 + "/lost", AuthMiddleware(), Apilostmaster.ListLost, sendResponse)
router.post(Config.endpointv1 + "/lost/add", AuthMiddleware(), Apilostmaster.InsertLost, sendResponse)
router.post(Config.endpointv1 + "/lost/update", AuthMiddleware(), Apilostmaster.UpdateLost, sendResponse)
router.delete(Config.endpointv1 + "/lost/delete", AuthMiddleware(), Apilostmaster.DeleteLost, sendResponse)
//  End lostandfound master

//  Start lostandfound master
router.post(Config.endpointv1 + "/found", AuthMiddleware(), Apifoundmaster.ListFound, sendResponse)
router.post(Config.endpointv1 + "/found/add", AuthMiddleware(), Apifoundmaster.InsertFound, sendResponse)
router.post(Config.endpointv1 + "/found/update", AuthMiddleware(), Apifoundmaster.UpdateFound, sendResponse)
router.delete(Config.endpointv1 + "/found/delete", AuthMiddleware(), Apifoundmaster.DeleteFound, sendResponse)
//  End lostandfound master

//  Start lostandfound commentsmaster
router.post(Config.endpointv1 + "/lostandfound/comments", AuthMiddleware(), Apilostandfoundcommentsmaster.ListLostAndFoundComments, sendResponse)
router.post(Config.endpointv1 + "/lostandfound/comments/add", AuthMiddleware(), Apilostandfoundcommentsmaster.InsertLostAndFoundComments, sendResponse)
router.post(Config.endpointv1 + "/lostandfound/comments/update", AuthMiddleware(), Apilostandfoundcommentsmaster.UpdateLostAndFoundComments, sendResponse)
router.delete(Config.endpointv1 + "/lostandfound/comments/delete", AuthMiddleware(), Apilostandfoundcommentsmaster.DeleteLostAndFoundComments, sendResponse)
//  End lostandfound comments master

// router.post(Config.endpointv1 + "/masters/copymaster", AuthMiddleware(), Apicopymaster.CopyMaster, sendResponse)

//  START qrcode master
router.post(Config.endpointv1 + "/qrcode", AuthMiddleware(), Apiqrcodemaster.ListQRcode, sendResponse)
router.post(Config.endpointv1 + "/qrcode/add", AuthMiddleware(), Apiqrcodemaster.InsertQRcode, sendResponse)
router.post(Config.endpointv1 + "/qrcode/update", AuthMiddleware(), Apiqrcodemaster.UpdateQRcode, sendResponse)
router.delete(Config.endpointv1 + "/qrcode/delete", AuthMiddleware(), Apiqrcodemaster.DeleteQRcode, sendResponse)
//  END qrcode master

//  START Patrolling master
router.post(Config.endpointv1 + "/patrolling", AuthMiddleware(), Apipatrolling.ListPatrolling, sendResponse)
router.post(Config.endpointv1 + "/patrolling/add", AuthMiddleware(), Apipatrolling.InsertPatrolling, sendResponse)
router.post(Config.endpointv1 + "/patrolling/update", AuthMiddleware(), Apipatrolling.UpdatePatrolling, sendResponse)
router.delete(Config.endpointv1 + "/patrolling/delete", AuthMiddleware(), Apipatrolling.DeletePatrolling, sendResponse)
//  END Patrolling master

//  START sos master
router.post(Config.endpointv1 + "/sos", AuthMiddleware(), Apisosmaster.ListSOS, sendResponse)
router.post(Config.endpointv1 + "/sos/add", AuthMiddleware(), Apisosmaster.InsertSOS, sendResponse)
router.post(Config.endpointv1 + "/sos/update", AuthMiddleware(), Apisosmaster.UpdateSOS, sendResponse)
router.delete(Config.endpointv1 + "/sos/delete", AuthMiddleware(), Apisosmaster.DeleteSOS, sendResponse)
//  END sos master

//  START key master
router.post(Config.endpointv1 + "/key", AuthMiddleware(), Apikeymaster.ListKeyMaster, sendResponse)
router.post(Config.endpointv1 + "/key/add", AuthMiddleware(), Apikeymaster.InsertKeyMaster, sendResponse)
router.post(Config.endpointv1 + "/key/update", AuthMiddleware(), Apikeymaster.UpdateKeyMaster, sendResponse)
router.delete(Config.endpointv1 + "/key/delete", AuthMiddleware(), Apikeymaster.DeleteKeyMaster, sendResponse)
//  END key master

//  START keybunch master
router.post(Config.endpointv1 + "/keybunch", AuthMiddleware(), Apikeybunchmaster.ListKeyBunchMaster, sendResponse)
router.post(Config.endpointv1 + "/keybunch/add", AuthMiddleware(), Apikeybunchmaster.InsertKeyBunchMaster, sendResponse)
router.post(Config.endpointv1 + "/keybunch/update", AuthMiddleware(), Apikeybunchmaster.UpdateKeyBunchMaster, sendResponse)
router.delete(Config.endpointv1 + "/keybunch/delete", AuthMiddleware(), Apikeybunchmaster.DeleteKeyBunchMaster, sendResponse)
//  END keybunch master
router.post(Config.endpointv1 + "/keymanage", AuthMiddleware(), Apikeybunchmaster.KeyManageMaster, sendResponse)


//  START PARCEL master
router.post(Config.endpointv1 + "/parcel", AuthMiddleware(), Apiparcelmaster.ListParcelMaster, sendResponse)
router.post(Config.endpointv1 + "/parcelmange", AuthMiddleware(), Apiparcelmaster.manageParcel, sendResponse)
router.post(Config.endpointv1 + "/parcel/add", AuthMiddleware(), Apiparcelmaster.InsertParcelMaster, sendResponse)
router.post(Config.endpointv1 + "/parcel/update", AuthMiddleware(), Apiparcelmaster.UpdateParcelMaster, sendResponse)
router.delete(Config.endpointv1 + "/parcel/delete", AuthMiddleware(), Apiparcelmaster.DeleteParcelMaster, sendResponse)
//  END PARCEL master


//  START PARCEL master
router.post(Config.endpointv1 + "/cab", AuthMiddleware(), Apicabmaster.ListCabMaster, sendResponse)
router.post(Config.endpointv1 + "/cabmanage", AuthMiddleware(), Apicabmaster.manageCab, sendResponse)
router.post(Config.endpointv1 + "/cab/add", AuthMiddleware(), Apicabmaster.InsertCabMaster, sendResponse)
router.post(Config.endpointv1 + "/cab/update", AuthMiddleware(), Apicabmaster.UpdateCabMaster, sendResponse)
router.delete(Config.endpointv1 + "/cab/delete", AuthMiddleware(), Apicabmaster.DeleteCabMaster, sendResponse)
//  END PARCEL master

//  START task master
router.post(Config.endpointv1 + "/days", AuthMiddleware(), Apitaskmaster.ListDayMaster, sendResponse)
router.post(Config.endpointv1 + "/task", AuthMiddleware(), Apitaskmaster.ListTask, sendResponse)
router.post(Config.endpointv1 + "/task/add", AuthMiddleware(), Apitaskmaster.InsertTask, sendResponse)
router.post(Config.endpointv1 + "/task/update", AuthMiddleware(), Apitaskmaster.UpdateTask, sendResponse)
router.post(Config.endpointv1 + "/taskscheduler", AuthMiddleware(), Apitaskmaster.ListSchedule, sendResponse)
router.post(Config.endpointv1 + "/taskscheduler/add", AuthMiddleware(), Apitaskmaster.ScheduleTaskAdd, sendResponse)
router.post(Config.endpointv1 + "/taskscheduler/update", AuthMiddleware(), Apitaskmaster.ScheduleTaskUpdate, sendResponse)
router.delete(Config.endpointv1 + "/taskscheduler/delete", AuthMiddleware(), Apitaskmaster.ScheduleTaskDelete, sendResponse)
router.get(Config.endpointv1 + "/taskschedular", AuthMiddleware(), Apitaskmaster.TaskSchedulerScript, sendResponse)


router.post(Config.endpointv1 + "/taskstatus", AuthMiddleware(), Apitaskstatusmaster.ListTaskStatusMaster, sendResponse)
router.post(Config.endpointv1 + "/taskstatus/add", AuthMiddleware(), Apitaskstatusmaster.InsertTaskStatusMaster, sendResponse)
router.post(Config.endpointv1 + "/taskstatus/update", AuthMiddleware(), Apitaskstatusmaster.UpdateTaskStatusMaster, sendResponse)
router.delete(Config.endpointv1 + "/taskstatus/delete", AuthMiddleware(), Apitaskstatusmaster.DeleteTaskStatusMaster, sendResponse)

// router.post(Config.endpointv1 + "/cabmanage", AuthMiddleware(), Apicabmaster.manageCab, sendResponse)
// router.post(Config.endpointv1 + "/cab/add", AuthMiddleware(), Apicabmaster.InsertCabMaster, sendResponse)
// router.post(Config.endpointv1 + "/cab/update", AuthMiddleware(), Apicabmaster.UpdateCabMaster, sendResponse)
// router.delete(Config.endpointv1 + "/cab/delete", AuthMiddleware(), Apicabmaster.DeleteCabMaster, sendResponse)
//  END task master

// ==================================================================================================================================================================================== //
// ============================================================================= MASTER ===================================================================================== //
// ==================================================================================================================================================================================== //


// ==================================================================================================================================================================================== //
// ============================================================================= IN/OUT ===================================================================================== //
// ==================================================================================================================================================================================== //
router.post(Config.endpointv1 + '/clockinoutlog/add', AuthMiddleware(), Apilogmanage.InsertLogManageData, sendResponse)

router.post(Config.endpointv1 + '/mylog', AuthMiddleware(), Apilogmanage.MyLog, sendResponse)

// Manual Log Manage
router.post(Config.endpointv1 + "/updatepersonlogmanage", AuthMiddleware(), Apilogmanage.Updatelogregularizerequest, sendResponse)

//gatekeeper
router.post(Config.endpointv1 + "/logscalendar", AuthMiddleware(), Apilogmanage.GetLogCalender, sendResponse)
router.post(Config.endpointv1 + "/visitorlogs/calender", AuthMiddleware(), Apilogmanage.GetVisitorLogCalender, sendResponse)
router.post(Config.endpointv1 + "/patrollinglogs/calender", AuthMiddleware(), Apilogmanage.GetPatrollingLogCalender, sendResponse)

//employee
router.post(Config.endpointv1 + "/property/logscalendar", AuthMiddleware(), Apilogmanage.GetPropertyLogCalender, sendResponse)
router.post(Config.endpointv1 + "/property/visitorlogs/calender", AuthMiddleware(), Apilogmanage.GetPropertyVisitorLogCalender, sendResponse)

router.post(Config.endpointv1 + "/logregularization", AuthMiddleware(), Apilogmanage.Listlogregularizerequest, sendResponse)
router.post(Config.endpointv1 + "/logregularization/add", AuthMiddleware(), Apilogmanage.Insertlogregularizerequest, sendResponse)
router.post(Config.endpointv1 + "/logregularization/update", AuthMiddleware(), Apilogmanage.Updatelogregularizerequest, sendResponse)


// ==================================================================================================================================================================================== //
// ============================================================================= IN/OUT ===================================================================================== //
// ==================================================================================================================================================================================== //





// ==================================================================================================================================================================================== //
// ============================================================================= PROPERTY ===================================================================================== //
// ==================================================================================================================================================================================== //

//  START Property 
router.post(Config.endpointv1 + "/property", AuthMiddleware(), Apiproperty.ListProperty, sendResponse)
router.post(Config.endpointv1 + "/property/add", AuthMiddleware(), Apiproperty.InsertProperty, sendResponse)
router.post(Config.endpointv1 + "/property/update", AuthMiddleware(), Apiproperty.UpdateProperty, sendResponse)
router.post(Config.endpointv1 + "/property/singleassign", AuthMiddleware(), Apiproperty.updatePropertyAssign, sendResponse)
router.post(Config.endpointv1 + "/property/assign", AuthMiddleware(), Apiproperty.updateOneProperty, sendResponse)
router.delete(Config.endpointv1 + "/property/delete", AuthMiddleware(), Apiproperty.DeleteProperty, sendResponse)

//  END Property 

// property wing
router.post(Config.endpointv1 + "/property/wing", AuthMiddleware(), Apiproperty.ListWing, sendResponse)
router.post(Config.endpointv1 + "/property/wing/add", AuthMiddleware(), Apiproperty.AddWing, sendResponse)
router.post(Config.endpointv1 + "/property/wing/update", AuthMiddleware(), Apiproperty.UpdateWing, sendResponse)
router.delete(Config.endpointv1 + "/property/wing/delete", AuthMiddleware(), Apiproperty.DeleteWing, sendResponse)

//property unit
router.post(Config.endpointv1 + "/property/unit", AuthMiddleware(), Apiproperty.ListUnit, sendResponse)
router.post(Config.endpointv1 + "/property/unit/add", AuthMiddleware(), Apiproperty.AddUnit, sendResponse)
router.post(Config.endpointv1 + "/property/unit/update", AuthMiddleware(), Apiproperty.UpdateUnit, sendResponse)
router.post(Config.endpointv1 + "/avaliableunit", AuthMiddleware(), Apiproperty.ListavaliableUnit, sendResponse)
router.delete(Config.endpointv1 + "/property/unit/delete", AuthMiddleware(), Apiproperty.DeleteUnit, sendResponse)

//property floor
router.post(Config.endpointv1 + "/property/floor", AuthMiddleware(), Apiproperty.ListFloor, sendResponse)
router.post(Config.endpointv1 + "/property/floor/add", AuthMiddleware(), Apiproperty.AddFloor, sendResponse)
router.post(Config.endpointv1 + "/property/floor/update", AuthMiddleware(), Apiproperty.UpdateFloor, sendResponse)
router.delete(Config.endpointv1 + "/property/floor/delete", AuthMiddleware(), Apiproperty.DeleteFloor, sendResponse)

//property area
router.post(Config.endpointv1 + "/property/area", AuthMiddleware(), Apiproperty.ListArea, sendResponse)
// router.post(Config.endpointv1 + "/property/area/arealist", AuthMiddleware(), Apiproperty.ListAmenitiesPropertyArea, sendResponse)
router.post(Config.endpointv1 + "/property/area/add", AuthMiddleware(), Apiproperty.AddArea, sendResponse)
router.post(Config.endpointv1 + "/property/area/update", AuthMiddleware(), Apiproperty.UpdateArea, sendResponse)
router.delete(Config.endpointv1 + "/property/area/delete", AuthMiddleware(), Apiproperty.DeleteArea, sendResponse)

//property gate
router.post(Config.endpointv1 + "/property/gate", AuthMiddleware(), Apiproperty.ListGate, sendResponse)
router.post(Config.endpointv1 + "/property/gate/add", AuthMiddleware(), Apiproperty.AddGate, sendResponse)
router.post(Config.endpointv1 + "/property/gate/update", AuthMiddleware(), Apiproperty.UpdateGate, sendResponse)
router.delete(Config.endpointv1 + "/property/gate/delete", AuthMiddleware(), Apiproperty.DeleteGate, sendResponse)


router.post(Config.endpointv1 + "/facility", AuthMiddleware(), Apiproperty.ListFacility, sendResponse)
router.post(Config.endpointv1 + "/facility/add", AuthMiddleware(), Apiproperty.AddFacility, sendResponse)
router.post(Config.endpointv1 + "/facility/update", AuthMiddleware(), Apiproperty.UpdateFacility, sendResponse)
router.delete(Config.endpointv1 + "/facility/delete", AuthMiddleware(), Apiproperty.DeleteFacility, sendResponse)

router.post(Config.endpointv1 + "/facilitybooking", AuthMiddleware(), Apifacilitybooking.ListFacilityBooking, sendResponse)
router.post(Config.endpointv1 + "/facilitybooking/add", AuthMiddleware(), Apifacilitybooking.InsertFacilityBooking, sendResponse)
router.post(Config.endpointv1 + "/facilitybooking/update", AuthMiddleware(), Apifacilitybooking.UpdateFacilityBooking, sendResponse)
router.post(Config.endpointv1 + "/facilitybooking/approvereject", AuthMiddleware(), Apifacilitybooking.ApproveRejectFacilityBooking, sendResponse)

router.post(Config.endpointv1 + "/assignslot", AuthMiddleware(), Apifacilitybooking.ListAssignSlot, sendResponse)

router.post(Config.endpointv1 + "/facility/rating", AuthMiddleware(), Apifacilitybooking.ListFacilityRating, sendResponse)
router.post(Config.endpointv1 + "/facility/rating/add", AuthMiddleware(), Apifacilitybooking.InsertFacilityRating, sendResponse)

// ==================================================================================================================================================================================== //
// ============================================================================= PROPERTY ===================================================================================== //
// ==================================================================================================================================================================================== //







// ==================================================================================================================================================================================== //
// ============================================================================= VISITOR ===================================================================================== //
// ==================================================================================================================================================================================== //


router.post(Config.endpointv1 + "/visitor", AuthMiddleware(), Apivisitor.ListVisitorMaster, sendResponse)
router.post(Config.endpointv1 + "/visitor/add", AuthMiddleware(), Apivisitor.InsertVisitorMaster, sendResponse)
router.post(Config.endpointv1 + "/visitorinout/update", AuthMiddleware(), Apivisitor.UpdateVisitorMaster, sendResponse)
router.delete(Config.endpointv1 + "/visitor/delete", AuthMiddleware(), Apivisitor.DeleteVisitorMaster, sendResponse)


router.post(Config.endpointv1 + "/visitorinout/add", AuthMiddleware(), Apivisitor.VisitorClockInOut, sendResponse)
router.post(Config.endpointv1 + "/visitor/count", AuthMiddleware(), Apivisitor.VisitorCount, sendResponse)
router.post(Config.endpointv1 + "/visitorinout", AuthMiddleware(), Apivisitor.VisitorInOutList, sendResponse)

router.post(Config.endpointv1 + "/preapproveguest/verify", AuthMiddleware(), Apivisitor.PreApproveGuest, sendResponse)
router.post(Config.endpointv1 + "/visitor/verify", AuthMiddleware(), Apivisitor.ListUniqueVisitorMaster, sendResponse)
router.post(Config.endpointv1 + "/prepproveguest/in", AuthMiddleware(), Apivisitor.PreApproveVisitorAllow, sendResponse)


// ==================================================================================================================================================================================== //
// ============================================================================= VISITOR ===================================================================================== //
// ==================================================================================================================================================================================== //




// ==================================================================================================================================================================================== //
// ============================================================================= ZOHO ===================================================================================== //
// ==================================================================================================================================================================================== //

/* ---------------------------------------------- ZOHO ---------------------------------------------- */
// just write for test
router.get(Config.endpointv1 + "/zoho/authorizationcode/:userid", Apizohopropertysync.SuccessZohoPropertySync, sendResponse)
router.get(Config.endpointv1 + "/zoho/authorizationcode", AuthMiddleware(), new DB().zohoAuthorizationCode, sendResponse)

router.post(Config.endpointv1 + "/zoho/service", AuthMiddleware(), Apizohoservices.ListZohoServices, sendResponse)
router.post(Config.endpointv1 + "/zoho/service/add", AuthMiddleware(), Apizohoservices.InsertZohoServices, sendResponse)
router.post(Config.endpointv1 + "/zoho/service/update", AuthMiddleware(), Apizohoservices.UpdateZohoServices, sendResponse)
router.delete(Config.endpointv1 + "/zoho/service/delete", AuthMiddleware(), Apizohoservices.DeleteZohoServices, sendResponse)

router.post(Config.endpointv1 + "/zoho/accesstokens", AuthMiddleware(), Apizohoauth.ListZohoAccessToken, sendResponse)
router.post(Config.endpointv1 + "/zoho/propertysyncurl", AuthMiddleware(), Apizohopropertysync.ListZohoPropertySync, sendResponse)
/* ---------------------------------------------- ZOHO ---------------------------------------------- */

// ==================================================================================================================================================================================== //
// ============================================================================= ZOHO ===================================================================================== //
// ==================================================================================================================================================================================== //





// ==================================================================================================================================================================================== //
// ============================================================================= Complaint ======================================================================================= //
// ==================================================================================================================================================================================== //


// start complaint Category
router.post(Config.endpointv1 + '/complaintcategory', AuthMiddleware(), Apicomplaintcategorymaster.ListComplaintCategory, sendResponse)
router.post(Config.endpointv1 + '/complaintcategory/add', AuthMiddleware(), Apicomplaintcategorymaster.InsertComplaintCategory, sendResponse)
router.post(Config.endpointv1 + '/complaintcategory/update', AuthMiddleware(), Apicomplaintcategorymaster.UpdateComplaintCategory, sendResponse)
router.delete(Config.endpointv1 + '/complaintcategory/delete', AuthMiddleware(), Apicomplaintcategorymaster.DeleteComplaintCategory, sendResponse)
// end complaint Category


//Complaint
router.post(Config.endpointv1 + "/complaint", AuthMiddleware(), ApiComplaint.ListComplaint, sendResponse)
router.post(Config.endpointv1 + "/complaint/add", AuthMiddleware(), ApiComplaint.InsertComplaint, sendResponse)
router.post(Config.endpointv1 + "/complaint/update", AuthMiddleware(), ApiComplaint.UpdateComplaint, sendResponse)
router.post(Config.endpointv1 + '/ratingcomplaint', AuthMiddleware(), ApiComplaint.RatingComplaint, sendResponse)
router.delete(Config.endpointv1 + "/complaint/delete", AuthMiddleware(), ApiComplaint.DeleteComplaint, sendResponse)
//Complaint

// start complaint Flow
router.post(Config.endpointv1 + '/complaintticketflow', AuthMiddleware(), Apicomplaintflow.ListComplaintFlow, sendResponse)
router.post(Config.endpointv1 + '/complaintcategory/flow', AuthMiddleware(), Apicomplaintflow.ListPropertyComplaintFlow, sendResponse)
router.post(Config.endpointv1 + '/complaintticketflow/add', AuthMiddleware(), Apicomplaintflow.InsertComplaintFlow, sendResponse)
router.post(Config.endpointv1 + '/complaintticketflow/addmany', AuthMiddleware(), Apicomplaintflow.InsertMultipleComplaintFlow, sendResponse)
router.post(Config.endpointv1 + '/complaintticketflow/update', AuthMiddleware(), Apicomplaintflow.UpdateComplaintFlow, sendResponse)
router.delete(Config.endpointv1 + '/complaintticketflow/delete', AuthMiddleware(), Apicomplaintflow.DeleteComplaintFlow, sendResponse)
router.post(Config.endpointv1 + '/complaintassignperson', AuthMiddleware(), Apicomplaintflow.ListComplaintFlowAssignperson, sendResponse)
// end complaint Flow


// start Complaint stage
router.post(Config.endpointv1 + '/complaintstage', AuthMiddleware(), Apicomplaintstage.ListComplaintStage, sendResponse)
router.post(Config.endpointv1 + '/complaintstage/add', AuthMiddleware(), Apicomplaintstage.InsertComplaintStage, sendResponse)
router.post(Config.endpointv1 + '/complaintstage/update', AuthMiddleware(), Apicomplaintstage.UpdateComplaintStage, sendResponse)
router.delete(Config.endpointv1 + '/complaintstage/delete', AuthMiddleware(), Apicomplaintstage.DeleteComplaintStage, sendResponse)
// end Complaint stage

// start complaint stage flow
router.post(Config.endpointv1 + '/complaintstageflow', AuthMiddleware(), Apicomplaintstageflow.ListComplaintStageFlow, sendResponse)
// router.post(Config.endpointv1 + '/supportticketstageflowwithcategoty',AuthMiddleware(), Apicomplaintstageflow.,sendResponse)
router.post(Config.endpointv1 + '/complaintstageflow/add', AuthMiddleware(), Apicomplaintstageflow.InsertComplaintStageFlow, sendResponse)
router.post(Config.endpointv1 + '/complaintstageflow/addmany', AuthMiddleware(), Apicomplaintstageflow.InsertMultipleComplaintStageFlow, sendResponse)
router.post(Config.endpointv1 + '/complaintstageflow/update', AuthMiddleware(), Apicomplaintstageflow.UpdateComplaintStageFlow, sendResponse)
router.delete(Config.endpointv1 + '/complaintstageflow/delete', AuthMiddleware(), Apicomplaintstageflow.DeleteComplaintStageFlow, sendResponse)
router.post(Config.endpointv1 + '/complaintstageflowstatus', AuthMiddleware(), Apicomplaintstageflow.StageFlowTicketStatus, sendResponse)
// end complaint stage flow

// start complaint type
router.post(Config.endpointv1 + '/complainttype', AuthMiddleware(), Apicomplainttype.ListComplaintType, sendResponse)
router.post(Config.endpointv1 + '/complainttype/add', AuthMiddleware(), Apicomplainttype.InsertComplaintType, sendResponse)
router.post(Config.endpointv1 + '/complainttype/update', AuthMiddleware(), Apicomplainttype.UpdateComplaintType, sendResponse)
router.delete(Config.endpointv1 + '/complainttype/delete', AuthMiddleware(), Apicomplainttype.DeleteComplaintType, sendResponse)
// end complaint type

// start complaint type
router.post(Config.endpointv1 + '/complaintpriority', AuthMiddleware(), Apicomplaintpriority.ListComplaintPriority, sendResponse)
router.post(Config.endpointv1 + '/complaintpriority/add', AuthMiddleware(), Apicomplaintpriority.InsertComplaintPriority, sendResponse)
router.post(Config.endpointv1 + '/complaintpriority/update', AuthMiddleware(), Apicomplaintpriority.UpdateComplaintPriority, sendResponse)
router.delete(Config.endpointv1 + '/complaintpriority/delete', AuthMiddleware(), Apicomplaintpriority.DeleteComplaintPriority, sendResponse)
// end complaint type

// start complaint timelog
router.post(Config.endpointv1 + '/complainttimelog', AuthMiddleware(), Apicomplainttimelog.ListcomplaintTimelog, sendResponse)
router.post(Config.endpointv1 + '/complainttimelog/add', AuthMiddleware(), Apicomplainttimelog.InsertcomplaintTimelog, sendResponse)
router.post(Config.endpointv1 + '/complainttimelog/update', AuthMiddleware(), Apicomplainttimelog.UpdatecomplaintTimelog, sendResponse)
router.delete(Config.endpointv1 + '/complainttimelog/delete', AuthMiddleware(), Apicomplainttimelog.DeletecomplaintTimelog, sendResponse)
// end complaint timelog

// Complaint Chat
router.post(Config.endpointv1 + "/complaint/chat", AuthMiddleware(), ApiComplaintChat.ListComplaintChat, sendResponse)
router.post(Config.endpointv1 + "/complaint/chat/add", AuthMiddleware(), ApiComplaintChat.InsertComplaintChat, sendResponse)
router.post(Config.endpointv1 + "/complaint/chat/update", AuthMiddleware(), ApiComplaintChat.UpdateComplaintChat, sendResponse)
router.post(Config.endpointv1 + "/complaint/chatreaction", AuthMiddleware(), ApiComplaintChat.ComplaintChatReaction, sendResponse)
// Complaint Chat

// start complaint Comments
router.post(Config.endpointv1 + '/complaintcomments', AuthMiddleware(), Apicomplaintcomments.ListComplaintComments, sendResponse)
router.post(Config.endpointv1 + '/complaintcomments/add', AuthMiddleware(), Apicomplaintcomments.InsertComplaintComments, sendResponse)
router.post(Config.endpointv1 + '/complaintcomments/update', AuthMiddleware(), Apicomplaintcomments.UpdateComplaintComments, sendResponse)
router.delete(Config.endpointv1 + '/complaintcomments/delete', AuthMiddleware(), Apicomplaintcomments.DeleteComplaintComments, sendResponse)
// end complaint Comments

// start complaint category train
router.post(Config.endpointv1 + '/categorytrain', AuthMiddleware(), ApiCategorytrain.ListCategoryTrainMaster, sendResponse)
router.post(Config.endpointv1 + '/categorytrain/add', AuthMiddleware(), ApiCategorytrain.InsertCategoryTrainMaster, sendResponse)
router.post(Config.endpointv1 + '/categorytrain/update', AuthMiddleware(), ApiCategorytrain.UpdateCategoryTrainMaster, sendResponse)
router.delete(Config.endpointv1 + '/categorytrain/delete', AuthMiddleware(), ApiCategorytrain.DeleteCategoryTrainMaster, sendResponse)
// end complaint category train


//start complaint anlytics
// router.post(Config.endpointv1 + '/complaint/analytics',AuthMiddleware(), ApiComplaint.ComplaintAnalytics,sendResponse)
//end complaint analytics

// //  START complaint log Requests
// router.post(Config.endpointv1 + '/supportticketlogrequest', AuthMiddleware(), ApiSupportTicketTimelogRequest.ListSupportTicketTimelogRequest, sendResponse)
// router.post(Config.endpointv1 + '/supportticketlogrequest/add', AuthMiddleware(), ApiSupportTicketTimelogRequest.InsertSupportTicketTimelogRequests, sendResponse)
// router.post(Config.endpointv1 + '/supportticketrequest/update', AuthMiddleware(), ApiSupportTicketTimelogRequest.UpdateSupportTicketTimelogRequests, sendResponse)
// router.delete(Config.endpointv1 + '/supportticketrequest/delete', AuthMiddleware(), ApiSupportTicketTimelogRequest.DeleteSupportTicketTimelogRequests, sendResponse)
// //  END complaint TimelogRequests


// // Analytics charts
// // router.post(Config.endpointv1 + '/supportticketstatuschart',AuthMiddleware(), ApiSupportTicket.GetSupportTicketStatusChart,sendResponse)
// // router.post(Config.endpointv1 + '/supportticketaveragetime',AuthMiddleware(), ApiSupportTicket.GetSupportTicketAverageTime,sendResponse)
// // end Support Ticket


// ==================================================================================================================================================================================== //
// ============================================================================= Complaint ======================================================================================= //
// ==================================================================================================================================================================================== //



/* ---------------------------------------------- Testcase ---------------------------------------------- */

router.post(Config.endpointv1 + "/testcases", Apiexecutetestcase.RunTestCase)

/* ---------------------------------------------- Testcase ---------------------------------------------- */

//---------------------------------------------------- CheckList--------------------------------------------------------//
router.post(Config.endpointv1 + "/checklist", AuthMiddleware(), ApiChecklist.ListChecklist, sendResponse)
router.post(Config.endpointv1 + "/checklist/add", AuthMiddleware(), ApiChecklist.InsertChecklist, sendResponse)
router.post(Config.endpointv1 + "/checklist/update", AuthMiddleware(), ApiChecklist.UpdateChecklist, sendResponse)
router.delete(Config.endpointv1 + "/checklist/delete", AuthMiddleware(), ApiChecklist.DeleteChecklist, sendResponse)
router.post(Config.endpointv1 + "/checklistlogdetails", AuthMiddleware(), ApiChecklist.ListChecklistLogDetails, sendResponse)
router.post(Config.endpointv1 + "/checklist/copy", AuthMiddleware(), ApiChecklist.ChecklistBulkCopy, sendResponse)
//---------------------------------------------------- CheckList--------------------------------------------------------//

router.post(Config.endpointv1 + "/masters/listtaskcategory", AuthMiddleware(), ApiTaskCategory.ListTaskCategory, sendResponse)

// Task - Category Configuration
router.post(Config.endpointv1 + "/task/categoryconfiguration", AuthMiddleware(), ApiTaskCategoryConfiguration.ListCategoryConfiguration, sendResponse)
router.post(Config.endpointv1 + "/task/categoryconfiguration/add", AuthMiddleware(), ApiTaskCategoryConfiguration.InsertCategoryConfiguration, sendResponse)
router.post(Config.endpointv1 + "/task/categoryconfiguration/update", AuthMiddleware(), ApiTaskCategoryConfiguration.UpdateCategoryConfiguration, sendResponse)
router.delete(Config.endpointv1 + "/task/categoryconfiguration/delete", AuthMiddleware(), ApiTaskCategoryConfiguration.DeleteCategoryConfiguration, sendResponse)
// Task - Category Configuration


//poc
router.post(Config.endpointv1 + "/poc/decryptpayloaddata", Apipoc.decryptpayloaddata, sendResponse) //Test
router.post(Config.endpointv1 + "/poc/decryptresponseddata_new", Apipoc.decryptresponseddata_new, sendResponse) //Test
router.post(Config.endpointv1 + "/poc/decryptresponseddata", Apipoc.decryptresponseddata, sendResponse) //Test
router.post(Config.endpointv1 + "/poc/decryptresponseddata_new", Apipoc.decryptresponseddata_new, sendResponse) //Test


router.post(Config.endpointv1 + "/nationality", AuthMiddleware(), apiNationalityMaster.ListNationality, sendResponse)
router.post(Config.endpointv1 + "/nationality/add", AuthMiddleware(), apiNationalityMaster.InsertNationality, sendResponse)
router.post(Config.endpointv1 + "/nationality/update", AuthMiddleware(), apiNationalityMaster.UpdateNationality, sendResponse)
router.delete(Config.endpointv1 + "/nationality/delete", AuthMiddleware(), apiNationalityMaster.DeleteNationality, sendResponse)

router.post(Config.endpointv1 + "/customertype", AuthMiddleware(), apiCustomerTypeMaster.ListCustomerType, sendResponse)
router.post(Config.endpointv1 + "/customertype/add", AuthMiddleware(), apiCustomerTypeMaster.InsertCustomerType, sendResponse)
router.post(Config.endpointv1 + "/customertype/update", AuthMiddleware(), apiCustomerTypeMaster.UpdateCustomerType, sendResponse)
router.delete(Config.endpointv1 + "/customertype/delete", AuthMiddleware(), apiCustomerTypeMaster.DeleteCustomerType, sendResponse)

router.post(Config.endpointv1 + "/committeemembers", AuthMiddleware(), apiCommitteeMembersMaster.ListCommitteeMembers, sendResponse)
router.post(Config.endpointv1 + "/committeemembers/add", AuthMiddleware(), apiCommitteeMembersMaster.InsertCommitteeMembers, sendResponse)
router.post(Config.endpointv1 + "/committeemembers/update", AuthMiddleware(), apiCommitteeMembersMaster.UpdateCommitteeMembers, sendResponse)
router.delete(Config.endpointv1 + "/committeemembers/delete", AuthMiddleware(), apiCommitteeMembersMaster.DeleteCommitteeMembers, sendResponse)

export default router
