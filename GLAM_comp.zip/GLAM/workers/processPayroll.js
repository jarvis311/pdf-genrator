import {parentPort, workerData}  from 'worker_threads'
import _BulkSalaryMaster from "../api/HR/BulkSalaryMaster.js"

parentPort.postMessage(await runProcess(workerData))

async function runProcess(workerData) {
    try{

        let req = {
            body : workerData.reqbody,
            headers : workerData.reqheader
        }

        const Apibulksalarymaster = new _BulkSalaryMaster()
        const result = await Apibulksalarymaster.processPayroll(req)
        return result

    }catch(err){
        //node_Error(err)
    }
}