import { FieldConfig } from "../config/Init.js"
import { generateQueue } from "../cronjobs/BullQueue.js"

// /*------------------------------------------------ Audit Run ------------------------------------------------*/
// import _AuditRun from "../api/AuditRun.js"
// const Apiauditrun = new _AuditRun()

// const Auditrun_Queue = generateQueue({ queuename: FieldConfig.queuejobs.auditrun })
// Auditrun_Queue.process(Apiauditrun.AuditRun)

// global.Auditrun_Queue = Auditrun_Queue
// /*------------------------------------------------ Audit Run ------------------------------------------------*/

/*------------------------------------------------ Emails ------------------------------------------------*/
import sendEmail from "./SendEmail.js"

const Email_Queue = generateQueue({ queuename: FieldConfig.queuejobs.emails })
Email_Queue.process(sendEmail)

global.Email_Queue = Email_Queue
/*------------------------------------------------ Emails ------------------------------------------------*/
