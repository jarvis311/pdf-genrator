import chai from 'chai';
import chaiHttp from 'chai-http';
import { Config, IISAutoTest, IISMethods } from '../config/Init.js'

chai.use(chaiHttp);
chai.config.includeStack = true
const { should } = chai
should()

const ObjectId = IISMethods.getobjectid()
const areaid = new ObjectId()

const endpoint = {
  list: "/area",
  add: "/area/add",
  update: "/area/update",
  delete: "/area/delete"
}

const reqheader = {
  list:{useraction:"viewright",pagename:"area",apptype:1},
  add:{useraction:"addright",pagename:"area",apptype:1},
  update:{useraction:"editright",pagename:"area",apptype:1},
  delete:{useraction:"delright",pagename:"area",apptype:1},
}

const reqbody = {
  add: {
    _id: areaid,
    area:"SWIGGY",
    isactive:1
  },
  update: {
    _id: areaid,
    area: "SWIGGYs"
  },
  delete: {
    _id: areaid
  },
  filter: {
    searchtext: "",
    paginationinfo: {
      pageno: 1,
      pagelimit: 200000000,
      filter: { "_id": [areaid.toString(),"66dede7108cbbd28104d25eb"] },
      sort: {}
    }
  },
  sort: {
    searchtext: "",
    paginationinfo: {
      pageno: 1,
      pagelimit: 200000000,
      filter: {},
      projection: { area: 1 },
      sort: { area: 1 }
    }
  },
  search: {
    searchtext: "sw",
    paginationinfo: {
      pageno: 1,
      pagelimit: 200000000,
      filter: {},
      projection: {},
      sort: {}
    }
  }
}


const invalidDataTests = [
  {
    data: {
        area: "",
        isactive: 1
    },
    expectedError: 'Path `area` is required.',
    description: 'should return an error for empty name'
  },
  {
    data: {
        area: "SWIGGYs",
        isactive: 1
    },
    expectedError: 'Data already exist.',
    description: 'should return an error for data already exist'
  }
]

describe('Cruds', async function () {

  await IISAutoTest.EmployeeAuthTestcase()
 
  const testCases = IISAutoTest.CommonTestcase({ endpoint, reqbody,reqheader})
   for (const testCase of testCases) {
     IISAutoTest.performRequest(testCase)
   }
   
   //diffrent scenario test
   for (const dep of invalidDataTests) {
      IISAutoTest.performRequest({method: 'post',endpoint: endpoint.add,body: dep.data,expectedStatus: 400,description: dep.description,headers: reqheader.add,
         expectedResponse: (res) => {
           res.should.be.a('object')
           res.body.should.be.a('object')
           res.body.should.have.property('message').that.equals(dep.expectedError)
         }
       })
   }
 

})









