import { IISMethods,MainDB } from "../config/Init.js"
import nodemailer from "nodemailer"

import _DBConfig from "../config/DBConfig.js"
// import _Users from "../model/Users.js"

// Email Module
import _EmailSMTP from "../model/masters/Configurations/EmailSMTP.js"
 import _EmailTemplate from "../model/masters/Configurations/EmailTemplate.js"

import _EmailLogs from "../model/EmailLog.js"

const sendEmail = async (job) => {

    const ObjectId = IISMethods.getobjectid()

    const {emailhostid = "",sendername = "",from = "",to = "", bcc = "",cc = "",subject = "",templateid = "",attachments = [],data = {}} = job.data

    /*------------------------------------------ Email Body ------------------------------------------*/
    let template = ""
    let body = ""

    if (IISMethods.ValidateObjectId(templateid)) {
        // Get Email Template
        const emailtemplatePipeline = { _id: ObjectId(templateid) }
        const emailtemplate = await MainDB.FindOne("tblemailtemplate", new _EmailTemplate(), emailtemplatePipeline)

        if (emailtemplate) {
            template = emailtemplate

            body = IISMethods.createBody(template.body, data)
        }
    } else {
        template = templateid

        const tempBody = await IISMethods.getFileContent(template.body, "utf8")
        body = IISMethods.createBody(tempBody, data)
    }
    /*------------------------------------------ Email Body ------------------------------------------*/

    /*------------------------------------------ Email Host ------------------------------------------*/
    let emailsmtpPipeline = [{ $match: { default: 1 } }]

    if (emailhostid) {
        emailsmtpPipeline = [{ $match: { _id: ObjectId(emailhostid) } }]
    } else if (template.emailhostid) {
        emailsmtpPipeline = [{ $match: { _id: ObjectId(template.emailhostid) } }]
    }

    // Email SMTP
    const emailsmtpResp = await MainDB.getmenual("tblemailsmtp", new _EmailSMTP(), emailsmtpPipeline)
    let emailsmtp = emailsmtpResp.ResultData[0]

    if (!emailsmtp) {
        const emailsmtpPipeline = { default: 1 }
        emailsmtp = await MainDB.FindOne("tblemailsmtp", new _EmailSMTP(), emailsmtpPipeline)
    }


    // Email Configuration
    let transporterdata = {
        host: process.env.EMAIL_HOST,
        port: 587,
        secure: false,
        tls: {
            ciphers: "SSLv3",
            rejectUnauthorized: false
        },
        auth: {
            user: process.env.EMAIL_USER,
            pass: process.env.EMAIL_PASS
        }
    }

    if (emailsmtp) {
         transporterdata = {
            pool: false,
            host: "127.0.0.1",
            port: 1025,
            secure: false,
            auth: {
                user: "project.1",
                pass: "secret.1"
            }
        }
        // transporterdata = {
        //     host: emailsmtp.host,
        //     port: emailsmtp.port,
        //     secure: false,
        //     tls: {
        //         ciphers: "SSLv3",
        //         rejectUnauthorized: false
        //     },
        //     auth: {
        //         user: emailsmtp.username,
        //         pass: emailsmtp.password
        //     }
        // }
    }
    /*------------------------------------------ Email Host ------------------------------------------*/

    /*------------------------------------------ Send Email ------------------------------------------*/
    // Email Body
    const emailBody = { from: from === "" ? (emailsmtp ? emailsmtp.email : "") : from, to, subject: subject === "" ? template.subject : subject, text: "", html: body, attachments, bcc, cc }

    const transporter = nodemailer.createTransport(transporterdata)
    
    await transporter.sendMail(emailBody)
    /*------------------------------------------ Send Email ------------------------------------------*/
    console.log(`${job.data.name} Job completed....!`)
}
   

export default sendEmail
