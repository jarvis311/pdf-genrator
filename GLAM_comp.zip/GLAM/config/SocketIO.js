import _Config from "./Config.js"
import SocketClient from "socket.io-client"

const Config = new _Config()

/********************************* Socket Configuration **********************************/

const io = SocketClient.connect(`${Config.socketserverurl}`, {
    secure: true,
    reconnection: true,
    rejectUnauthorized: false,
    query: {
        type: "nodeserver"
    }
})

io.on("connect", () => {
    console.log("Socket Server Connected....!")
})

io.on("disconnect", () => {
    console.log("Socket Server Disconnected....!")
})


/********************************* Socket Configuration **********************************/

export { io }
