// import { createClient } from "redis"

// const redisConnect = async () => {
//     const client = createClient({
//         url: `redis://${process.env.REDIS_HOST}:${process.env.REDIS_PORT}`
//         // url: 'redis://127.0.0.1:6379'
//     })
//     await client.connect()

//     global.redisclient = client

//     console.log("Redis Connected Successfully....!")
// }

// export { redisConnect }
