import debug from "debug"

// Server
global.node_Log = debug("Server:Log")
node_Log.color = 2

// Socket
global.node_Socket = debug("Socket")
node_Socket.color = 5

// Error
global.node_Error = debug("Server:Error")
node_Error.color = 1

// Cron Jobs
global.node_Jobs = debug("Server:Jobs")
node_Jobs.color = 4

// Worker Jobs
global.node_QueueJobs = debug("Server:QueueJobs")
node_QueueJobs.color = 4

/*---------------------------------------- Developer Logs ----------------------------------------*/

global.node_Vivek = debug("Dev:Vivek")
node_Vivek.color = 6

global.node_Vivek = debug("Dev:Panish")
node_Vivek.color = 6

global.node_Ishan = debug("Dev:Ishan")
node_Ishan.color = 6

global.node_Jaydev = debug("Dev:Jaydev")
node_Jaydev.color = 6

global.node_Abhi = debug("Dev:Abhi")
node_Abhi.color = 6

/*---------------------------------------- Developer Logs ----------------------------------------*/

export default debug
