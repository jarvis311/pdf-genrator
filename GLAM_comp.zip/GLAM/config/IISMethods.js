import crypto from "crypto"
// import { io } from "../index.js"
import { io } from "./SocketIO.js"
import { BlobServiceClient } from '@azure/storage-blob'

// import {encode} from 'html-entities'
import ObjectId from "mongoose"
import md5 from "md5"
// import bcrypt from "bcrypt"
import _Config from "./Config.js"
import path from "path"
import axios from "axios"

import _ from "lodash"
import _FieldConfig from "./FieldConfig.js"

// import { Config, FieldConfig } from "./Init.js"
import fs from "fs"
import { promisify } from "util"

// Encryption
import CryptoJS from "crypto-js"

// 2FA
import speakeasy from "speakeasy"

// import sharp from "sharp"

// encode html
import entities from "html-entities"
import mongoose from "mongoose"


const Objectid = ObjectId.Types.ObjectId
const FieldConfig = new _FieldConfig()
const Config = new _Config()

export var ImageData

class IISMethods {
    /************************************************ Encryption & Decryption ************************************************/

    isCryptoJSEncryptedString(input) {
        if (typeof input !== "string") {
            return false
        }

        const parts = input.split(".")

        if (parts.length !== 2) {
            return false
        }

        const uid = parts[1]
        if (uid.length !== 16) {
            return false
        }

        const encryptedData = parts[0]

        let isValidBase64 = false
        try {
            isValidBase64 = CryptoJS.enc.Base64.parse(encryptedData).toString(CryptoJS.enc.Base64) === encryptedData
        } catch (err) {
            console.log(err)

            return false
        }

        return isValidBase64
    }

    // Generate Random String
    generateRandomString(length) {
        const characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"

        const charactersLength = characters.length

        let result = ""
        for (let i = 0; i < length; i++) {
            result += characters.charAt(Math.floor(Math.random() * charactersLength))
        }

        return result
    }

    // Encrypt Data
    encryptData(data, type = 0) {
        try {
            const uid = this.generateRandomString(16)

            let secretKey = CryptoJS.enc.Utf8.parse(process.env.ENCRYPTION_KEY)

            if (type === 1) {
                // Credit Card Encryption
                secretKey = CryptoJS.enc.Utf8.parse(process.env.CREDIT_CARD_ENCRYPTION_KEY)
            }

            const iv = CryptoJS.enc.Utf8.parse(uid)

            const encryptData = CryptoJS.AES.encrypt(JSON.stringify(data), secretKey, { iv: iv })

            return encryptData.toString() + "." + uid
        } catch (e) {
            console.log(e)

            return data
        }
    }

    // Decrypt Data
    decryptData(data, tempkey, type = 0) {
        try {
            let secretKey = CryptoJS.enc.Utf8.parse(process.env.ENCRYPTION_KEY)

            // if (type === 1) {
            //     // Credit Card Encryption
            //     secretKey = CryptoJS.enc.Utf8.parse(process.env.CREDIT_CARD_ENCRYPTION_KEY)
            // }

            let iv = CryptoJS.enc.Utf8.parse(tempkey)
            const bytes = CryptoJS.AES.decrypt(data, secretKey, { iv: iv })

            const decryptData = bytes.toString(CryptoJS.enc.Utf8)

            return JSON.parse(decryptData)
        } catch (e) {
            console.log(e)
        }
    }

    /************************************************ Encryption & Decryption ************************************************/

    /************************************************ Request Body ************************************************/

    // Validate Request Body
    validateRequestBody(req) {
        // Create a regular expression pattern to match blocked words
        const blocklistPattern = new RegExp(FieldConfig.blockedwords.join("|"), "i")

        if (req.body && blocklistPattern.test(JSON.stringify(req.body))) {
            return false
        }

        return true
    }

    /************************************************ Request Body ************************************************/


    /************************************************ Testcase ************************************************/
    correctJSONString(input) {
        // Add double quotes around keys
        let correctedString = input.replace(/(\w+):/g, '"$1":');
        // Function to quote non-numeric and non-boolean values
        const quoteValues = (match, p1) => {
            // Trim whitespace
            p1 = p1.trim();
            // Check if it's a number or boolean
            if (!isNaN(p1)) {
                return `:${p1}`;
            } else if (p1 === 'true' || p1 === 'false') {
                return `:${p1}`;
            } else if (p1.startsWith('"') && p1.endsWith('"')) {
                return `:${p1}`;
            } else {
                return `:"${p1}"`;
            }
        };

        // Quote values in key-value pairs
        correctedString = correctedString.replace(/:"?([^,\[\]{}:]+)"?(?=[,}\]])/g, quoteValues);

        // Handle arrays of objects and other complex structures
        correctedString = correctedString.replace(/:\[([^\]]+)\]/g, (match, p1) => {
            let arrayElements = [];
            let braceCount = 0;
            let currentElement = '';

            for (let char of p1) {
                if (char === '{') braceCount++;
                if (char === '}') braceCount--;
                if (char === ',' && braceCount === 0) {
                    arrayElements.push(currentElement.trim());
                    currentElement = '';
                } else {
                    currentElement += char;
                }
            }
            arrayElements.push(currentElement.trim());

            arrayElements = arrayElements.map(item => {
                item = item.trim();
                return isNaN(item) && item !== 'true' && item !== 'false' && !item.startsWith('{') && !item.endsWith('}') ? `"${item}"` : item;
            });

            return `:[${arrayElements.join(',')}]`;
        });

        // Return the corrected JSON string
        return correctedString;
    }

    ParseJSONString(process) {
        console.log("hii")
        const body = process.split('=')[1]
        var correctedString = this.correctJSONString(body);
        var jsonObject = JSON.parse(correctedString);
        return jsonObject
    }


    /************************************************ Testcase ************************************************/


    getobjectid() {
        return ObjectId.Types.ObjectId
    }

    generateuuid() {
        return crypto.randomUUID()
    }

    generateUUID() {
        var d = this.GetDT().getTime()
        var d2 = (typeof performance !== "undefined" && performance.now && performance.now() * 1000) || 0 //Time in microseconds since page-load or 0 if unsupported
        return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function (c) {
            var r = Math.random() * 16 //random number between 0 and 16
            if (d > 0) {
                //Use timestamp until depleted
                r = (d + r) % 16 | 0
                d = Math.floor(d / 16)
            } else {
                //Use microseconds since page-load if supported
                r = (d2 + r) % 16 | 0
                d2 = Math.floor(d2 / 16)
            }
            return (c === "x" ? r : (r & 0x3) | 0x8).toString(16)
        })
    }

    sanitize(data) {
        //return encode(data)
        return data
    }

    getdatetimestr() {
        return new Date()
            .toISOString()
            .replace(/T/, " ") // replace T with a space
            .replace(/\..+/, "")
    }

    getCustomDatetimestr(date) {
        return new Date(date)
            .toISOString()
            .replace(/T/, " ") // replace T with a space
            .replace(/\..+/, "")
    }

    //current date time in ISO formate
    getdatetimeisostr() {
        return new Date().toISOString()
    }

    parseTime(timeString) {
        const [time, period] = timeString.split(' ');
        let [hours, minutes] = time.split(':').map(Number);

        // Convert to 24-hour format if needed
        if (period === 'PM' && hours !== 12) {
            hours += 12;
        } else if (period === 'AM' && hours === 12) {
            hours = 0;
        }

        return { hours, minutes };
    }

    /************************************************ 2FA ************************************************/
    // Validate 2FA OTP
    validate2FAOTP({ secret, otp }) {
        // if (otp === "000000") {
        // 	return true
        // }

        return speakeasy.totp.verify({
            secret: secret,
            encoding: "base32",
            token: otp,
            window: 1,
        })
    }

    // Generate Recovery Code
    generateRecoveryCodes(count = 10) {
        const recoveryCodes = []
        const min = 100000000 // Minimum value (10^8)
        const max = 999999999 // Maximum value (10^9 - 1)

        for (let i = 0; i < count; i++) {
            const code = Math.floor(Math.random() * (max - min + 1)) + min
            recoveryCodes.push(code.toString())
        }
        return recoveryCodes
    }

    // Validate Recovery Code
    validateRecoveryCode({ recoveryCodes = [], recoveryCode = "" }) {
        return recoveryCodes.includes(recoveryCode)
    }

    // Generate OTP
    generatecode(size) {
        const digits = "0123456789"
        let code = ""

        for (let i = 0; i < size; i++) {
            const randomIndex = Math.floor(Math.random() * digits.length)
            code += digits[randomIndex]
        }

        return code
    }

    // Generate OTP
    generateOTP(size) {
        const digits = "0123456789"
        let otp = ""

        for (let i = 0; i < size; i++) {
            const randomIndex = Math.floor(Math.random() * digits.length)
            otp += digits[randomIndex]
        }

        return {otp,hashOTP:this.GetMD5(otp)}
        // return { otp, hashOTP: bcrypt.hashSync(otp, 10) }
    }

    // Validate OTP
    validateOTP({ otp, hashOTP }) {
        return this.GetMD5(otp) === hashOTP
        // return bcrypt.compareSync(otp, hashOTP)
    }
    /************************************************ 2FA ************************************************/

    /************************************************ Date Function ************************************************/

    getFormatWiseDate(date, format = 1) {
        try {
            const dateobj = new Date(date)
            const year = dateobj.getUTCFullYear() // 2022
            const month = dateobj.getUTCMonth() + 1 // 9
            const day = dateobj.getUTCDate() // 1

            const yy = year.toString().slice(-2) // 22
            const mm = month.toString().padStart(2, "0") // 09
            const dd = day.toString().padStart(2, "0") // 01
            const shortmonth = dateobj.toLocaleString("default", { month: "short" }) // Sep

            var ss = dateobj.getUTCSeconds().toString().padStart(2, "0") //Get the seconds (0-59)
            var MM = dateobj.getUTCMinutes().toString().padStart(2, "0") //Get the minutes (0-59)
            var HH = dateobj.getUTCHours().toString().padStart(2, "0") //Get the hour (0-23)
            var timestamp = dateobj.getTime() //Get time stamp
            const weekdayname = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"]
            const weekday = weekdayname[dateobj.getDay()]

            if (format === 1) {
                date = year + "-" + mm + "-" + dd
            } else if (format === 2) {
                date = month + "/" + day + "/" + year
            } else if (format === 3) {
                date = month + "/" + day + "/" + yy
            } else if (format === 4) {
                date = dd + "-" + shortmonth + "-" + yy
            } else if (format === 5) {
                date = yy + "/" + mm + "/" + dd
            } else if (format === 6) {
                date = mm + "/" + dd + "/" + yy
            } else if (format === 7) {
                date = mm + "/" + dd + "/" + year
            } else if (format === 8) {
                date = dd + " " + shortmonth + ", " + year
            } else if (format === 9) {
                date = mm + "-" + dd + "-" + year
            } else if (format === 10) {
                date = year + "-" + mm + "-" + dd + " " + HH + ":" + MM
            } else if (format === 11) {
                date = HH + ":" + MM
            } else if (format === 12) {
                date = timestamp
            } else if (format === 13) {
                date = dd + "" + mm + "" + year
            } else if (format === 14) {
                date = year + "-" + mm + "-" + dd + " " + HH + ":" + MM + ":" + ss
            } else if (format === 15) {
                date = dateobj.toLocaleString([], { hour: "2-digit", minute: "2-digit" })
            } else if (format === 16) {
                let hour = parseInt(HH)
                const ampm = hour >= 12 ? "PM" : "AM"
                hour = hour % 12
                hour = hour ? hour : 12

                let time = hour + ":" + MM + " " + ampm
                date = year + "-" + mm + "-" + dd + " " + time
            } else if (format === 17) {
                let hour = parseInt(HH)
                const ampm = hour >= 12 ? "PM" : "AM"

                hour = hour % 12
                hour = hour ? hour : 12

                hour = hour.toString().padStart(2, "0")

                let time = hour + ":" + MM + " " + ampm

                date = time
            } else if (format === 18) {
                date = dd + "/" + mm + "/" + year
            } else if (format === 19) {
                date = weekday + ", " + shortmonth + " " + dd + ", " + year
            } else if (format === 20) {
                let hour = parseInt(HH)
                const ampm = hour >= 12 ? "PM" : "AM"
                hour = hour % 12
                hour = hour ? hour : 12

                let time = hour + ":" + MM + " " + ampm
                date = mm + "/" + dd + "/" + year + " " + time
            } else if (format === 21) {
                date = year + "-" + mm + "-" + dd + " " + HH
            } else if (format === 22) {
                date = year + "-" + mm
            } else if (format === 23) {
                date = mm + "-" + dd
            } else if (format == 24) {
                date = mm + "/" + yy
            } else if (format == 25) {
                let hour = parseInt(HH)
                const ampm = hour >= 12 ? "PM" : "AM"

                hour = hour % 12
                hour = hour ? hour : 12

                hour = hour.toString().padStart(2, "0")
                date = weekday + " " + dd + " " + shortmonth + " " + year + " " + hour + ":" + MM + " " + ampm
            }
        } catch {
            date = "Invalid Date"
        }
        return date
    }
    
    async getFileContent(filepath, type) {
        const __dirname = path.resolve()
        filepath = __dirname + filepath
        const readFile = promisify(fs.readFile)
        let data = await readFile(filepath, type)
        return data
    }

    // Get System Date to ISO Date
    getSystemDate({ date = new Date() }) {
        let systemdate = new Date(date)

        if (systemdate === "Invalid Date") {
            systemdate = new Date()
        }

        return systemdate
    }


    async sendPushNotification(tokens, title, body, data = {}) {
        try {
            let result;
            const notificationHubService = azure.createNotificationHubService(process.env.NOTIFICATION_HUB_NAME, process.env.CONNECTION_STRING);

            // Chunk tokens into groups of 500
            const chunks = _.chunk(tokens, 500);

            // Map over each chunk to send notifications
            const promise = chunks.map(async (tokenChunk) => {
                // Create an array of promises for each token in the chunk
                const tokenPromises = tokenChunk.map((token) => {
                    const payload = {
                        notification: {
                            title: title,
                            body: body,
                            sound: "default",
                            click_action: "FLUTTER_NOTIFICATION_CLICK",
                        },
                        data: {
                            ...data,
                        },
                    };

                    // Return a promise to send the notification for this token
                    return new Promise((resolve, reject) => {
                        notificationHubService.gcm.send(token, payload, (error) => {
                            if (!error) {
                                console.log(`Notification sent successfully to ${token}`);
                                resolve();
                            } else {
                                console.error(`Error sending notification to ${token}:`, error);
                                reject(error);
                            }
                        })
                    })
                })

                // Wait for all notifications in the chunk to be sent
                await Promise.all(tokenPromises);
            });

            // Wait for all chunks to be processed
            await Promise.all(promise);

            return result
        } catch (e) {
            console.error('Error in sending notifications:', e);
        }
    }

    isTimeSlotOverlapping(newStartTime, newEndTime, existingStartTime, existingEndTime) {
        const newStart = new Date(`1970-01-01T${newStartTime}:00Z`);
        const newEnd = new Date(`1970-01-01T${newEndTime}:00Z`);
        const existingStart = new Date(`1970-01-01T${existingStartTime}:00Z`);
        const existingEnd = new Date(`1970-01-01T${existingEndTime}:00Z`);
    
        return newStart < existingEnd && newEnd > existingStart;
    }

    // Get Timezone Offset
    getTimezoneOffset(date = new Date(), timezone = FieldConfig.timezone) {
        const dateData = new Date(date).toLocaleString("ja", { timeZone: timezone }).split(/[/\s:]/)
        dateData[1]--

        const t1 = Date.UTC.apply(null, dateData)
        const t2 = new Date(date).setMilliseconds(0)

        return (t2 - t1) / (60 * 1000)
    }

    // Get Timezone Wise Date
    getTimezoneWiseDate({ date = new Date(), timezone = FieldConfig.timezone, isdatewithtime = true }) {
        date = date ? date : new Date()

        const dateData = new Date(date).toLocaleString("ja", { timeZone: timezone }).split(/[/\s:]/)
        dateData[1]--

        const tzDate = Date.UTC.apply(null, dateData)

        if (isdatewithtime) {
            return new Date(tzDate)
        }

        return new Date(`${new Date(tzDate).toISOString().split("T")[0]}T00:00:00.000Z`)
    }

    // Get Date With Day Light Saving
    getUTCDateWithDayLightSaving({ originaldate = new Date(), changedate = new Date(), timezone = FieldConfig.timezone, isdatewithtime = true, isutc = true }) {
        const changeDate = new Date(originaldate)
        changeDate.setUTCFullYear(changedate.getUTCFullYear())
        changeDate.setUTCMonth(changedate.getUTCMonth())
        changeDate.setUTCDate(changedate.getUTCDate())

        const originalTZDate = this.getTimezoneWiseDate({ date: originaldate, timezone })
        const changeTZDate = this.getTimezoneWiseDate({ date: changeDate, timezone })

        changeTZDate.setUTCFullYear(originalTZDate.getUTCFullYear())
        changeTZDate.setUTCMonth(originalTZDate.getUTCMonth())
        changeTZDate.setUTCDate(originalTZDate.getUTCDate())

        const dayLightDiff = originalTZDate - changeTZDate

        const finalDate = changeDate.getTime() + dayLightDiff

        if (isutc) {
            if (isdatewithtime) {
                return new Date(finalDate)
            }

            return new Date(`${new Date(finalDate).toISOString().split("T")[0]}T00:00:00.000Z`)
        }

        if (isdatewithtime) {
            return this.getTimezoneWiseDate({ date: new Date(finalDate), timezone })
        }

        return new Date(
            `${this.getTimezoneWiseDate({ date: new Date(finalDate), timezone })
                .toISOString()
                .split("T")[0]
            }T00:00:00.000Z`
        )
    }

    // Get UTC Date
    getUTCDate({ date, timezone = FieldConfig.timezone, isdatewithtime = true, currenttime = false }) {
        date = new Date(date)

        const timezoneOffset = this.getTimezoneOffset(date, timezone)

        if (currenttime) {
            const tzCurrentDate = this.getTimezoneWiseDate({ timezone })
            date.setUTCHours(tzCurrentDate.getUTCHours(), tzCurrentDate.getUTCMinutes(), tzCurrentDate.getUTCSeconds(), tzCurrentDate.getUTCMilliseconds())
        }

        const utcDate = new Date(new Date(date).getTime() + timezoneOffset * 60 * 1000)

        if (isdatewithtime) {
            return utcDate
        }

        return new Date(`${utcDate.toISOString().split("T")[0]}T00:00:00.000Z`)
    }

    // Get Property Reservation Time
    getReservationTimeByProperty({ date, propertytime, timezone }) {
        return this.getUTCDateWithDayLightSaving({ originaldate: propertytime, changedate: date, timezone })
    }

    //Get month's start & end date
    getMonthStartAndEndDate(date = new Date()) {
        const currentDate = new Date(date)

        currentDate.setUTCDate(1)
        currentDate.setUTCHours(0, 0, 0, 0)

        const startDate = currentDate.toISOString()

        currentDate.setUTCMonth(currentDate.getUTCMonth() + 1, 0)
        currentDate.setUTCHours(23, 59, 59, 999)

        const endDate = currentDate.toISOString()

        return {
            startdate: new Date(startDate),
            enddate: new Date(endDate),
        }
    }

    getStartAndEndDate(month, year) {
        // Ensure month is zero-indexed (0 = January, 11 = December)
        const startDate = new Date(Date.UTC(year, month - 1, 1));
        const endDate = new Date(Date.UTC(year, month, 0, 23, 59, 59, 999));

        // Convert to ISO string in UTC timezone and remove milliseconds
        return {
            startdate: startDate.toISOString(),
            enddate: endDate.toISOString()
        };
    }

    getPastAndFollowing7thDateForMonth(monthStart, monthEnd) {
        // Calculate the past 7th date from the month's start date
        const past7thDate = new Date(monthStart)
        past7thDate.setUTCDate(past7thDate.getUTCDate() - 7)
        past7thDate.setUTCHours(0, 0, 0, 0)

        // Calculate the following 7th date from the month's end date
        const following7thDate = new Date(monthEnd)
        following7thDate.setUTCDate(following7thDate.getUTCDate() + 7)
        following7thDate.setUTCHours(23, 59, 59, 999)

        return {
            past7thDate: past7thDate.toISOString(),
            following7thDate: following7thDate.toISOString(),
        }
    }

    getHalfMonthlyDate(year, month) {
        const lastDayOfMonth = new Date(year, month, 0).getDate()
        let halfMonthlyDay = Math.ceil(lastDayOfMonth / 2)
        const halfMonthlyDate = new Date(year, month, halfMonthlyDay + 1).setUTCHours(0, 0, 0, 0)
        return new Date(halfMonthlyDate)
    }

    /************************************************ Date Function ************************************************/

    // Get Timezone Date
    getTimezoneDate({ date = new Date(), timezone, isdatewithtime = false, withnewtime = true, isutc = false }) {
        if (timezone) {
            if (isdatewithtime) {
                date = new Date(date)

                if (withnewtime) {
                    let currentDateTime = new Date()
                    date.setUTCHours(currentDateTime.getUTCHours(), currentDateTime.getUTCMinutes(), currentDateTime.getUTCSeconds(), currentDateTime.getUTCMilliseconds())
                }

                let format = this.getFormatedDate(date)
                let utcdate = new Date(Date.UTC(format.year, format.month - 1, format.day, format.hours, format.minutes, format.second, format.millisecond))
                let intlDateObj = new Intl.DateTimeFormat("en-US", {
                    year: "numeric",
                    month: "numeric",
                    day: "numeric",
                    hour: "numeric",
                    minute: "numeric",
                    second: "numeric",
                    hour12: true,
                    timeZone: timezone,
                })

                let timezonedate = new Date(intlDateObj?.format(utcdate))

                if (isutc) {
                    let offset = this.getTimezoneOffset(timezonedate, timezone)
                    timezonedate.setUTCMinutes(timezonedate.getUTCMinutes() + parseInt(offset))
                }
                return timezonedate
            }

            return new Date(`${this.getDateFormats(new Date(new Date(date).toLocaleString("en-US", { timeZone: timezone })))}T00:00:00.000Z`)
        }

        return new Date()
    }

    // Get Timezone Date With Day Light Saving
    getTimezoneDateWithDayLightSaving({ orignaldate = new Date(), changedate = new Date(), timezone = FieldConfig.timezone }) {
        const orignalTimezoneDate = new Date(new Date(orignaldate).toLocaleString("en-US", { timeZone: timezone }))
        const changeTimezoneDate = new Date(new Date(changedate).toLocaleString("en-US", { timeZone: timezone }))

        const systemTimezoneOffset = new Date().getTimezoneOffset()

        const tempChangeTimezoneDate = new Date(changeTimezoneDate)
        tempChangeTimezoneDate.setFullYear(orignalTimezoneDate.getFullYear())
        tempChangeTimezoneDate.setMonth(orignalTimezoneDate.getMonth())
        tempChangeTimezoneDate.setDate(orignalTimezoneDate.getDate())

        const dayLightDiff = orignalTimezoneDate.getTime() - tempChangeTimezoneDate.getTime()

        return new Date(changeTimezoneDate.getTime() + dayLightDiff - systemTimezoneOffset * 60 * 1000)
    }

    // Get Timezone Date in UTC
    getTimezoneDateUTC({ date, timezone, currenttime = true }) {
        const propertyTimezoneDate = this.getTimezoneDate({ date, timezone, isdatewithtime: true })
        const timezoneOffset = this.getTimezoneOffset(propertyTimezoneDate, timezone)

        if (currenttime) {
            const timzoneDate = `${date.split("T")[0]}T${propertyTimezoneDate.toISOString().split("T")[1]}`

            return new Date(new Date(timzoneDate).getTime() + timezoneOffset * 60 * 1000)
        } else {
            return new Date(new Date(date).getTime() + timezoneOffset * 60 * 1000)
        }
    }

    // Get Property Reservation Time
    getPropertyReservationTime({ date, propertytime, timezone }) {
        const tempPropetyTime = new Date(propertytime)
        tempPropetyTime.setUTCFullYear(new Date(date).getUTCFullYear())
        tempPropetyTime.setUTCMonth(new Date(date).getUTCMonth())
        tempPropetyTime.setUTCDate(new Date(date).getUTCDate())

        const getTimzoneDate = this.getTimezoneDateWithDayLightSaving({ orignaldate: propertytime, changedate: tempPropetyTime, timezone })

        return this.getTimezoneDateUTC({ date: getTimzoneDate.toISOString(), timezone, currenttime: false })
    }

    /************************************************ Reservation Function ************************************************/




    //********** get person property or scheduler property ids  ***********/
    async getPersonPropertyIds(person, returnobjectids = false) {
        const assignedPropertyIdsSet = new Set()
        let assignedPropertyIds = []

        if (person) {
            //****** Assigned properties (property or assigned scheduler property) ******/
            let assignedProperty = person?.property || []
            if (person?.schedulerproperty?.length) {
                //Assigned scheduler property
                assignedProperty = assignedProperty.concat(
                    person?.schedulerproperty
                    // .filter((propobj)=>propobj.isselected == 1)
                )
            }

            //****** Assigned property ids  ******/
            for (const propertyObj of assignedProperty) {
                assignedPropertyIdsSet.add(propertyObj?.propertyid?.toString())
            }

            //****** return ids in object ids  ******/
            assignedPropertyIds = Array.from(assignedPropertyIdsSet)
            if (returnobjectids) {
                assignedPropertyIds = assignedPropertyIds.map((obj) => Objectid(obj))
            }
        }

        return assignedPropertyIds
    }


    toISOString() {
        let date = new Date()
        return date.toISOString()
    }

    Jsontostring(data) {
        return JSON.stringify(data)
    }

    //get number of days in month
    daysInMonth(month, year) {
        return new Date(year, month, 0).getDate()
    }

    // date past/following
    datepastfollowing(date, days, add = true) {
        var cdate = new Date(date)
        if (add == false) {
            cdate.setDate(cdate.getDate() - days)
        } else {
            cdate.setDate(cdate.getDate() + days)
        }
        return cdate
    }

    //get month MM
    getCurrentMonth(date = "", balanceOffset = false) {
        if (balanceOffset) {
            date = this.balanceDateTimeOffset(date)
        }
        var month
        if (date !== "") {
            month = new Date(date).getUTCMonth() + 1
        } else {
            month = new Date().getMonth() + 1
        }
        // return parseInt(month.toString().padStart(2, "0"))
        return month.toString().padStart(2, "0")
    }

    fetchIP(req){
        
        // socket changes
        // return req.header('x-forwarded-for') || req.headers['public-ip'] || req.body.publicip || req.headers.publicip || req.connection.localAddress

        if(typeof req.header === "function"){
            return req.headers['public-ip'] || req.header('x-forwarded-for')  || req.body.publicip || req.headers.publicip || req.connection.localAddress
        }else{
            return req.headers['public-ip'] || req.body.publicip || req.headers.publicip
        }
    }


    //get year YYYY
    getCurrentYear(date = "", balanceOffset = false) {
        if (balanceOffset) {
            date = this.balanceDateTimeOffset(date)
        }
        var year

        if (date !== "") {
            year = new Date(date).getUTCFullYear()
        } else {
            year = new Date().getFullYear()
        }
        return parseInt(year)
    }

    getCurrentWeekStartEndDate(date = new Date(), balanceOffset = false) {
        if (balanceOffset) {
            date = this.balanceDateTimeOffset(date)
        }
        var curr = new Date(date)
        var startdate = new Date(curr.setDate(curr.getDate() - curr.getDay()))
        var enddate = new Date(curr.setDate(curr.getDate() - curr.getDay() + 6))
        return { startdate: startdate, enddate: enddate }
    }

    // jaydev -- function to get week number of date in month
    getWeekNumberOfMonth(date) {
        const startOfMonth = new Date(date.getFullYear(), date.getMonth(), 1)
        const dayOfWeek = startOfMonth.getDay()
        const day = date.getDate()
        const daysUntilFirstWeek = 7 - dayOfWeek

        if (day <= daysUntilFirstWeek) {
            return 1 // The day is in the first week of the month
        } else {
            return Math.ceil((day - daysUntilFirstWeek) / 7) + 1
        }
    }
    // jaydev ------

    getCurrentMonthStartAndEnd() {
        const currentDate = new Date()
        const year = currentDate.getFullYear()
        const month = currentDate.getMonth()

        const firstDate = new Date(year, month, 1)
        const lastDate = new Date(year, month + 1, 0)

        return {
            firstDate,
            lastDate,
        }
    }

    //get all dates [] between two dates
    getDatesInRange(startDate, endDate) {
        startDate = new Date(startDate)
        endDate = new Date(endDate)

        const date = new Date(startDate.getTime())

        const dates = []

        while (date <= endDate) {
            dates.push({ date: new Date(date) })
            date.setDate(date.getDate() + 1)
        }

        return dates
    }

    //add for salarymaster
    isDateBetween(startdate, date, enddate) {
        return (
            new Date(new Date(startdate).setUTCSeconds(0)) <= new Date(new Date(date).setUTCSeconds(0)) &&
            new Date(new Date(date).setUTCSeconds(0)) <= new Date(new Date(enddate).setUTCSeconds(0))
        )
    }

    // get date according to 6 months - jaydev
    getDateHalfYearWise(fromdate, todate, currentdate) {
        fromdate = new Date(fromdate)
        todate = new Date(todate)
        currentdate = new Date(currentdate)

        if (fromdate <= currentdate && todate >= currentdate) {
            var date1 = fromdate
            var date2 = this.dateaftermonth(fromdate, 6)
            let tmpdate = new Date(date2.toISOString())
            var date3 = new Date(tmpdate.setDate(tmpdate.getDate() + 1))
            var date4 = todate

            if (date1 <= currentdate && date2 >= currentdate) {
                return { startdate: date1, endate: date2 }
            } else if (date3 <= currentdate && date4 >= currentdate) {
                return { startdate: date3, endate: date4 }
            }
        }
    }

    addHoursToDate(hours, date = new Date()) {
        if (typeof hours !== "number") {
            throw new Error('Invalid "hours" argument')
        }

        if (!(date instanceof Date)) {
            throw new Error('Invalid "date" argument')
        }

        date.setHours(date.getHours() + hours)

        return date
    }

    // find date after months
    dateaftermonth(date, month) {
        let a = new Date(date)
        let b = a.getMonth() + parseInt(month)
        let c = new Date(new Date(date).getFullYear(), b, new Date(date).getDate())
        c = new Date(c.toISOString().substring(0, 10))
        return c
    }

    //months/year range  parth
    getMonthRange(startDate, endDate) {
        var start = startDate.split("-")
        var end = endDate.split("-")
        var startYear = parseInt(start[0])
        var endYear = parseInt(end[0])
        var dates = []

        for (var i = startYear; i <= endYear; i++) {
            var endMonth = i != endYear ? 11 : parseInt(end[1]) - 1
            var startMon = i === startYear ? parseInt(start[1]) - 1 : 0

            for (var j = startMon; j <= endMonth; j = j > 12 ? j % 12 || 11 : j + 1) {
                var month = j + 1
                var displayMonth = month < 10 ? "0" + month : month
                dates.push([i, displayMonth, "01"].join("-"))
            }
        }
        return dates
    }

    GetHourToDayAndHour(totalhours, dayhour) {
        var Days = Math.floor(totalhours / dayhour)
        var Remainder = totalhours % dayhour
        var Hours = Math.floor(Remainder)
        var Minutes = Math.floor(60 * (Remainder - Hours))
        return { d: Days, h: Hours, m: Minutes }
    }

    getGraphHourRange(data, fromdate, todate) {
        try {
            if (data.length === 0) return []

            let startdate = new Date(new Date(fromdate).setUTCHours(0, 0, 0, 0))
            let enddate = new Date(new Date(todate).setUTCHours(0, 0, 0, 0))

            const hourRange = []

            while (startdate.getTime() <= enddate.getTime()) {
                hourRange.push(startdate)

                startdate = new Date(new Date(startdate).setUTCDate(startdate.getUTCDate() + 1))
            }

            return hourRange
        } catch (err) {
            return []
        }
    }

    convertEstimateTime(time, hoursperday) {
        var hours = time % hoursperday
        var days = Math.floor(time / hoursperday)
        var remender = days % 22 //  30 - 8(Weekends) = 22
        var months = Math.floor(days / 22)

        var weeks = Math.floor(remender / 5) // 5 Day working
        remender = remender % 5

        hours += remender * hoursperday

        var EstimateTime = ""
        if (months) EstimateTime += `${months} Months, `
        if (weeks) {
            EstimateTime += `${weeks} Weeks, `
        }
        if (hours) {
            EstimateTime += `${hours} Hours `
        }
        return EstimateTime
    }

    getMinDifference(startDate, endDate) {
        startDate = new Date(startDate)
        endDate = new Date(endDate)

        var result = (endDate - startDate) / (1000 * 60)

        return result
    }

    getDaysDifference(startDate, endDate) {
        startDate = new Date(startDate)
        endDate = new Date(endDate)

        var result = (endDate - startDate) / (1000 * 60 * 60 * 24) + 1

        return result
    }

    getnewDaysDifference(startDate, endDate) {
        startDate = new Date(startDate)
        endDate = new Date(endDate)

        var result = (endDate - startDate) / (1000 * 60 * 60 * 24) + 1

        return result
    }

    //get month difference betwwen two days
    getMonthDifference(startDate, endDate) {
        startDate = new Date(startDate)
        endDate = new Date(endDate)

        return endDate.getMonth() - startDate.getMonth() + 12 * (endDate.getFullYear() - startDate.getFullYear())
    }

    //get milisecond difference betwwen two times
    getTimeDifference(starttime, endtime) {
        starttime = new Date(starttime)
        endtime = new Date(endtime)

        return endtime - starttime
    }

    convertMinsToHrsMins(mins = 0, withcondition = true) {
        let h = Math.floor(mins / 60)
        let m = Math.floor(mins % 60)
        if (withcondition) {
            h = h < 10 ? "0" + h : h
            m = m < 10 ? "0" + m : m
        }
        return { h: h, m: m }
    }

    convertSingleToDoubleDigit(value) {
        return value < 10 ? "0" + value : value
    }

    convertMinsToHrsMinsFormat(mins, withcondition = true) {
        let h = Math.floor(mins / 60)
        let m = Math.floor(mins % 60)
        if (withcondition) {
            h = h < 10 ? "0" + h : h
            m = m < 10 ? "0" + m : m
        }
        return h + ":" + m
    }

    convertMinsToHrsMinsSecsFormat(mins, withcondition = true) {
        let h = Math.floor(mins / 60)
        let m = Math.floor(mins % 60)
        let s = Math.floor((mins * 60) % 60)
        if (withcondition) {
            h = h < 10 ? "0" + h : h
            m = m < 10 ? "0" + m : m
            s = s < 10 ? "0" + s : s
        }
        return h + ":" + m + ":" + s
    }

    convertHrsMinsSecsFormatToSeconds(timeString) {
        let [hours, minutes, seconds] = timeString?.split(":").map(Number)

        let totalSeconds = hours * 3600 + minutes * 60 + seconds

        return totalSeconds
    }

    getdateandtimeformiso(datetime) {
        // const isodate = new Date(datetime).toISOString()
        const date = datetime.split("T")[0]
        var time = datetime.split("T")[1]
        time = time.substring(0, 8)
        return { date: date, time: time }
    }

    componentToHex(c) {
        const hex = c.toString(16)
        return hex.length == 1 ? "0" + hex : hex
    }

    rgbaToHex(r, g, b, a) {
        r = r.toString(16)
        g = g.toString(16)
        b = b.toString(16)
        a = Math.round(a * 255).toString(16)

        if (r.length == 1) r = "0" + r
        if (g.length == 1) g = "0" + g
        if (b.length == 1) b = "0" + b
        if (a.length == 1) a = "0" + a

        return "#" + r + g + b + a
    }

    rgbaStringToHexCodeString(color) {
        const rgba = color.replace(/^rgba?\(|\s+|\)$/g, "").split(",")
        const hex = `#${((1 << 24) + (parseInt(rgba[0]) << 16) + (parseInt(rgba[1]) << 8) + parseInt(rgba[2])).toString(16).slice(1)}`
        return hex
    }

    hexToRgba(hex) {
        var c
        let color = {}
        if (/^#([A-Fa-f0-9]{3}){1,2}$/.test(hex)) {
            c = hex.substring(1).split("")
            if (c.length == 3) {
                c = [c[0], c[0], c[1], c[1], c[2], c[2]]
            }
            c = "0x" + c.join("")
            color.r = (c >> 16) & 255
            color.g = (c >> 8) & 255
            color.b = c & 255
            color.a = 1
            return color
        }
    }

    GetTimestamp() {
        return Date.now()
    }

    GetMD5(data) {
        // return  crypto.createHash("sha256").update(data, "binary").digest("base64");
        return md5(data)
    }

    CheckUserRoleExist(value, array) {
        var isExist = false
        array.some((data) => {
            if (data.userroleid === value) {
                isExist = true
            }
        })

        return isExist
    }

    GetValueofObjectID(data) {
        return data.valueOf()
    }

    getobjectfromarray(arr, key, value) {
        try {
            return arr.find((o) => o[key] === value)
        } catch {
            return undefined
        }
    }

    groupBy(xs, key, sumfield, maxfield) {
        return xs.reduce(function (rv, x) {
            ; (rv[x[key]] = rv[x[key]] || []).push(x)
            if (sumfield) rv[x[key]].workedtime = rv[x[key]].workedtime ? rv[x[key]].workedtime + x[sumfield] : x[sumfield]
            if (maxfield) rv[x[key]].maxdate = rv[x[key]].maxdate ? (rv[x[key]].maxdate < x[maxfield] ? x[maxfield] : rv[x[key]].maxdate) : x[maxfield]
            return rv
        }, {})
    }

    ValidateObjectId(id) {
        // Validator function
        if (Objectid.isValid(id)) {
            if (String(new Objectid(id)) === id) return true
            return false
        }

        return false
    }

    ValidateField(field, value, type) {
        switch (type) {
            case 'String':
                return typeof value === 'string' ? null : `${field} should be a string`;

            case 'Number':
                return typeof value === 'number' ? null : `${field} should be a string`;

            case 'integer':
                return Number.isInteger(value) ? null : `${field} should be an integer`;

            case 'double':
                return typeof value === 'number' && isFinite(value) ? null : `${field} should be a double or float`;

            case 'float':
                return typeof value === 'number' && isFinite(value) ? null : `${field} should be a float`;

            case 'long':
                return Number.isSafeInteger(value) ? null : `${field} should be a long`;

            case 'longdouble':
                return typeof value === 'number' && isFinite(value) ? null : `${field} should be a long double`;

            case 'date':
                return value instanceof Date && !isNaN(value) ? null : `${field} should be a date`;

            case 'array':
                return Array.isArray(value) ? null : `${field} should be an array`;

            case 'object':
                return value && typeof value === 'object' && !Array.isArray(value) ? null : `${field} should be an object`;

            case 'ObjectID':
                return mongoose.Types.ObjectId.isValid(value) ? null : `${field} should be a valid ObjectId`;

            case 'null':
                return value === null ? null : `${field} should be null`;

            case 'bool':
                return typeof value === 'boolean' ? null : `${field} should be a boolean`;

            case 'undefined':
                return value === undefined ? null : `${field} should be undefined`;

            case 'Mixed':
                if (typeof value === 'object' && value !== null) {
                    if (Array.isArray(value)) {
                        // Check if all items in the array are objects
                        const allObjects = value.every(item => typeof item === 'object' && item !== null && !Array.isArray(item));
                        return allObjects ? null : `${field} should be an array of objects`;
                    }
                    // Value is an object but not an array
                    return null;
                } else {
                    return `${field} should be an object or an array of objects`;
                }

            default:
                return 'Invalid type specified';
        }
    };


    getFieldsAndTypes(model) {
        const schemaPaths = model.schema.paths;
        const fieldsToValidate = [];

        for (let path in schemaPaths) {
            if (schemaPaths.hasOwnProperty(path)) {
                const instance = schemaPaths[path].instance;
                fieldsToValidate.push({ field: path, type: instance });
            }
        }
        return fieldsToValidate;
    }

    GetGlobalSearchFilter(schemaObj, searchtext) {
        const searchFilter = []

        for (const key in schemaObj) {
            if (schemaObj[key].type === String) {
                searchFilter.push({ [key]: { $regex: searchtext, $options: "i" } })
            } else if (schemaObj[key].type === Number && !isNaN(searchtext)) {
                searchFilter.push({ [key]: parseFloat(searchtext) })
            } else if (Array.isArray(schemaObj[key])) {
                for (const arraykey in schemaObj[key][0]) {
                    if (schemaObj[key][0][arraykey].type === String) {
                        searchFilter.push({ [`${key}.${arraykey}`]: { $regex: searchtext, $options: "i" } })
                    } else if (schemaObj[key][0][arraykey].type === Number && !isNaN(searchtext)) {
                        searchFilter.push({ [`${key}.${arraykey}`]: parseFloat(searchtext) })
                    }
                }
            }
        }

        return [{ $match: { $or: searchFilter } }]
    }

    // GetPipelineForFilter(filter, concatobj = null) {
    //     var pipeline = []
    //     var keyval = []
    //     var newPipe = []

    //     if (Object.keys(filter).length) {
    //         Object.entries(filter).forEach(([key, value]) => {
    //             if (value !== "") {
    //                 if (typeof value === "number" || typeof value === "boolean") {
    //                     keyval.push({ [key]: value })
    //                 } else if (Array.isArray(value)) {
    //                     value.map((data) => {
    //                         if (this.ValidateObjectId(data)) {
    //                             newPipe.push({ [key]: new Objectid(data) })
    //                         } else newPipe.push({ [key]: { $regex: data, $options: "i" } })
    //                     })
    //                 } else if (this.ValidateObjectId(value)) {
    //                     keyval.push({ [key]: new Objectid(value) })
    //                 } else keyval.push({ [key]: { $regex: value, $options: "i" } })
    //             }
    //         })
    //         if (keyval.length && newPipe.length) pipeline = [{ $match: { $and: keyval, $or: newPipe } }]
    //         else if (keyval.length) pipeline = [{ $match: { $and: keyval } }]
    //         else if (newPipe.length) pipeline = [{ $match: { $or: newPipe } }]
    //     }

    //     var concatfield = {}
    //     if (concatobj !== null) {
    //         concatobj.forEach((val) => {
    //             concatfield = {
    //                 $addFields: { [val.concatname]: { $concat: ["$" + val.field1, val.symbol, "$" + val.field2] } }
    //             }
    //             pipeline.push(concatfield)
    //         })
    //     }
    //     return pipeline
    // }


    GetPipelineForFilter(filter, concatobj = null) {
        let pipeline = []

        const filterObj = {}

        if (Object.keys(filter).length) {
            Object.entries(filter).forEach(([key, value]) => {
                if (value !== "") {
                    if (typeof value === "number" || typeof value === "boolean") {
                        filterObj[key] = value
                    } else if (Array.isArray(value)) {
                        if (value.length) {
                            if (this.ValidateObjectId(value[0])) {
                                filterObj[key] = { $in: value.map((data) => Objectid(data)) }
                            } else {
                                filterObj[key] = { $in: value }
                            }
                        }
                    } else if (this.ValidateObjectId(value)) {
                        filterObj[key] = Objectid(value)
                    } else if (typeof value === "string") {
                        filterObj[key] = { $regex: value, $options: "i" }
                    }
                }
            })

            pipeline = [{ $match: filterObj }]
        }

        if (concatobj !== null) {
            concatobj.forEach((val) => {
                const concatfield = { $addFields: { [val.concatname]: { $concat: ["$" + val.field1, val.symbol, "$" + val.field2] } } }
                pipeline.push({ ...concatfield })
            })
        }

        return pipeline
    }

    GetPipelineForAndFilter(filter, concatobj = null) {
        var pipeline = []
        var keyval = []
        var newPipe = []

        if (Object.keys(filter).length) {
            Object.entries(filter).forEach(([key, value]) => {
                if (value !== "") {
                    if (typeof value === "number" || typeof value === "boolean") {
                        keyval.push({ [key]: value })
                    } else if (Array.isArray(value)) {
                        if (value.length) {
                            // var _value = value.map(v=>Objectid(v))
                            var _value = value.map((data) => {
                                if (this.ValidateObjectId(data)) {
                                    return Objectid(data)
                                } else {
                                    return data
                                }
                            })

                            newPipe.push({ [key]: { $in: _value } })
                        }
                    } else if (this.ValidateObjectId(value)) {
                        keyval.push({ [key]: new Objectid(value) })
                    } else keyval.push({ [key]: value })
                }
            })
            if (keyval.length && newPipe.length) {
                pipeline = [{ $match: { $and: [{ $and: keyval }, { $and: newPipe }] } }]
            } else if (keyval.length) {
                pipeline = [{ $match: { $and: keyval } }]
            } else if (newPipe.length) {
                pipeline = [{ $match: { $and: newPipe } }]
            }
        }

        var concatfield = {}
        if (concatobj !== null) {
            concatobj.forEach((val) => {
                concatfield = {
                    $addFields: { [val.concatname]: { $concat: ["$" + val.field1, val.symbol, "$" + val.field2] } },
                }
                pipeline.push(concatfield)
            })
        }
        return pipeline
    }

    chatSearchGroupFolderFilter(array, searchFilter) {
        let groupFolderData = []
        const getNodes = (result, object) => {
            const searchText = searchFilter.toLowerCase().replace(/([.?*+^$[\]\\(){}|-])/g, "\\$1")
            if (object.groupname.toLowerCase().search(searchText) >= 0) {
                result.push(object)
                groupFolderData.push(object)
                return result
            }
            if (Array.isArray(object.data)) {
                const nodes = object.data.reduce(getNodes, [])
            }
            return result
        }
        return {
            nodes: array.reduce(getNodes, []),
            groupFolderData: groupFolderData,
        }
    }

    buildChatFolderTree(nodes) {
        let tree = []
        for (let i = nodes.length - 1; i >= 0; i--) {
            if (nodes[i].hasparentfolder === 1) {
                let parent = nodes.filter((elem) => elem._id.toString() === nodes[i].parentfolderid.toString()).pop()

                if (parent) {
                    parent.data.push(nodes[i])
                    if (nodes[i].noofunseenchats > 0) {
                        parent.noofunseenchats += 1
                    }

                    //Sort folder and after group wise
                    parent.data.sort((a, b) => b.isgroupfolder - a.isgroupfolder)
                }
            } else {
                tree.push(nodes[i])
            }
        }
        return tree
    }

    /******************************************************** AWS Functions ********************************************************/

    // Add Face Collection
    async addFaceCollection({ collectionId }) {
        try {
            AWS.config.update({
                accessKeyId: process.env.AWS_ACCESS_KEY,
                secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
                region: process.env.AWS_REGION,
            })

            const rekognition = new AWS.Rekognition()

            const collectionResp = await rekognition.listCollections().promise()

            if (collectionResp.CollectionIds.includes(collectionId)) {
                return { status: 200, message: Config.getErrmsg()["isexist"] }
            }

            const params = {
                CollectionId: collectionId,
            }

            await rekognition.createCollection(params).promise()

            return { status: 200, message: Config.getErrmsg()["insert"] }
        } catch (err) {
            console.log(err)
        }
    }

    // Add Face to Collection
    async addFaceToCollection({ collectionId, Key }) {
        try {
            // Create Face Collection if not exist
            await this.addFaceCollection({ collectionId })

            AWS.config.update({
                accessKeyId: process.env.AWS_ACCESS_KEY,
                secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
                region: process.env.AWS_REGION,
            })

            const rekognition = new AWS.Rekognition()

            // Check Face is Already Exist
            // const searchParams = {
            // 	CollectionId: collectionId,
            // 	Image: {
            // 		S3Object: {
            // 			Bucket: Config.getS3Bucket(),
            // 			Name: Key
            // 		}
            // 	}
            // }

            // const searchData = await rekognition.searchFacesByImage(searchParams).promise()

            // if (searchData.FaceMatches.length) {
            // 	const exactMatch = searchData.FaceMatches.find((face) => face.Similarity === 100)

            // 	if (exactMatch) {
            // 		return exactMatch.Face.FaceId
            // 	}
            // }

            // Add Face to Collection
            const imageParams = {
                CollectionId: collectionId,
                Image: {
                    S3Object: {
                        Bucket: Config.getS3Bucket(),
                        Name: Key,
                    },
                },
            }

            const faceResp = await rekognition.indexFaces(imageParams).promise()

            const {
                Face: { FaceId },
            } = faceResp.FaceRecords[0]

            return FaceId
        } catch (err) {
            console.log(err)

            return ""
        }
    }

    // Search Face in Collection
    async searchFaceInCollection({ collectionId, Key }) {
        try {
            // Create Face Collection if not exist
            await this.addFaceCollection({ collectionId })

            AWS.config.update({
                accessKeyId: process.env.AWS_ACCESS_KEY,
                secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
                region: process.env.AWS_REGION,
            })

            const rekognition = new AWS.Rekognition()

            const imageParams = {
                CollectionId: collectionId,
                Image: {
                    S3Object: {
                        Bucket: Config.getS3Bucket(),
                        Name: Key,
                    },
                },
            }

            const { FaceMatches } = await rekognition.searchFacesByImage(imageParams).promise()

            const FaceIds = []

            FaceMatches.forEach((face) => {
                if (face.Similarity >= 95) {
                    FaceIds.push(face.Face.FaceId)
                }
            })

            return FaceIds
        } catch (err) {
            console.log(err)

            return []
        }
    }

    // Search Face in All Collection
    async searchFaceInAllCollection({ Key }) {
        try {
            AWS.config.update({
                accessKeyId: process.env.AWS_ACCESS_KEY,
                secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
                region: process.env.AWS_REGION,
            })

            const rekognition = new AWS.Rekognition()

            const { CollectionIds = [] } = await rekognition.listCollections().promise()

            const FaceIds = []

            for (const collectionid of CollectionIds) {
                const imageParams = {
                    CollectionId: collectionid,
                    Image: {
                        S3Object: {
                            Bucket: Config.getS3Bucket(),
                            Name: Key,
                        },
                    },
                }

                const { FaceMatches } = await rekognition.searchFacesByImage(imageParams).promise()

                FaceMatches.forEach((face) => {
                    if (face.Similarity >= 95) {
                        FaceIds.push(face.Face.FaceId)
                    }
                })
            }

            return FaceIds
        } catch (err) {
            console.log(err)

            return []
        }
    }


    // Detect Text
    async detectText({ document = "" }) {
        try {
            AWS.config.update({
                accessKeyId: process.env.AWS_ACCESS_KEY,
                secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
                region: process.env.AWS_REGION,
            })

            const textract = new AWS.Textract()

            const params = {
                Document: {
                    Bytes: document,
                },
            }

            const extractData = await textract.detectDocumentText(params).promise()

            const documentData = []

            for (let i = 0; i < extractData.Blocks?.length; i++) {
                const item = extractData.Blocks[i]

                if (item.BlockType === "LINE") {
                    documentData.push(item.Text)
                }
            }

            return documentData
        } catch (err) {
            return []
        }
    }

    // Compare Faces
    async compareFaces({ sourceImage = "", targetImage = "", similarityThreshold = 95 }) {
        try {
            AWS.config.update({
                accessKeyId: process.env.AWS_ACCESS_KEY,
                secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
                region: process.env.AWS_REGION,
            })

            const rekognition = new AWS.Rekognition()

            const params = {
                SourceImage: {
                    Bytes: sourceImage,
                },
                TargetImage: {
                    S3Object: {
                        Bucket: Config.s3bucket,
                        Name: targetImage,
                    },
                },
                SimilarityThreshold: similarityThreshold,
            }

            const { FaceMatches = [] } = await rekognition.compareFaces(params).promise()

            if (FaceMatches.length) {
                const faceMatch = FaceMatches[0]
                const similarity = faceMatch.Similarity

                if (similarity >= similarityThreshold) {
                    return 1
                }
            }

            return 0
        } catch (err) {
            return 0
        }
    }

    /******************************************************** AWS Functions ********************************************************/

    /******************************************************** File Upload Functions ********************************************************/

    // Get AWS Cloudwatch Logs
    async getAWSCloudwatchLogs({ loggroupname = Config.loggroupname, logstreamname = Config.logstreamname }) {
        try {
            AWS.config.update({
                accessKeyId: process.env.AWS_CLOUDWATCH_ACCESS_KEY, // Access Key
                secretAccessKey: process.env.AWS_CLOUDWATCH_SECRET_ACCESS_KEY, // Secret Access Key
                region: process.env.AWS_CLOUDWATCH_REGION, // Region
            })

            // Create an instance of the CloudWatch Logs service
            const cloudwatchlogs = new AWS.CloudWatchLogs()

            const params = {
                logGroupName: loggroupname,
                logStreamName: logstreamname,
                limit: 1, // Limit to 1 log event
                startFromHead: false, // Start from the newest log event
            }

            const data = await cloudwatchlogs.getLogEvents(params).promise()

            if (data.events.length) {
                const lastLogEvent = data.events[0]

                return JSON.parse(lastLogEvent.message)
            } else {
                return null
            }
        } catch (err) {
            console.log(err)

            return null
        }
    }

    // AWS Cloudwatch Logs
    async addAWSCloudwatchLogs({ loggroupname = Config.loggroupname, logstreamname = Config.logstreamname, message = {}, date = new Date() }) {
        try {
            AWS.config.update({
                accessKeyId: process.env.AWS_CLOUDWATCH_ACCESS_KEY, // Access Key
                secretAccessKey: process.env.AWS_CLOUDWATCH_SECRET_ACCESS_KEY, // Secret Access Key
                region: process.env.AWS_CLOUDWATCH_REGION, // Region
            })

            // Create an instance of the CloudWatch Logs service
            const cloudwatchlogs = new AWS.CloudWatchLogs()

            const params = {
                logGroupName: loggroupname,
                logStreamName: logstreamname,
                logEvents: [
                    {
                        message: JSON.stringify(message),
                        timestamp: new Date(date).getTime(),
                    },
                ],
            }

            await cloudwatchlogs.putLogEvents(params).promise()
        } catch (err) {
            console.log(err)
        }
    }

    // Base64 to Buffer
    async base64ToBuffer(base64Data) {
        const base64 = base64Data.split(",")
        const bufferData = Buffer.from(base64[1], "base64")

        let ContentType = base64[0].split(":")
        ContentType = ContentType[1].split(";")
        ContentType = ContentType[0]

        let filetype = base64[0].split("/")
        filetype = filetype[1].split(";")
        filetype = filetype[0]

        const BufferObj = {
            bufferData: bufferData,
            filetype: filetype,
            ContentType: ContentType,
        }

        return BufferObj
    }

    // Get File Path
    getfilepath(s3domainname = "", prefix = "") {
        const currentYear = new Date().getFullYear()
        const currentMonth = ("0" + (new Date().getMonth() + 1)).slice(-2)
        const uuid = this.generateuuid()

        prefix = path.parse(prefix).name

        return s3domainname + "/" + currentYear + "/" + currentMonth + "/" + uuid + "_" + prefix
    }


    // Upload File in S3
    async uploadToS3(file, name, delObj = "", data = {}, addfaceindex = false) {
        try {
            if ((typeof file === "string" && file != "" && file != "undefined" && file.startsWith("data:") && file) || (file && file.data)) {
                let BufferObj
                let bufferData
                let filetype
                let ContentType

                if (typeof file === "string" && file.startsWith("data:")) {
                    BufferObj = await this.base64ToBuffer(file)

                    bufferData = BufferObj["bufferData"]
                    filetype = BufferObj["filetype"]

                    ContentType = BufferObj["ContentType"]
                } else {
                    bufferData = file.data
                    ContentType = file.mimetype
                    filetype = file.mimetype.split("/")
                    filetype = filetype[1]
                }

                if (filetype == "svg+xml") {
                    filetype = "svg"
                }

                AWS.config.update({
                    accessKeyId: process.env.AWS_ACCESS_KEY, // Access Key
                    secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY, // Secret Access Key
                    region: process.env.AWS_REGION, // Region
                })

                const s3 = new AWS.S3()

                // Binary data base64
                const fileContent = Buffer.from(bufferData, "binary")

                // Setting up S3 upload parameters
                const params = {
                    Bucket: Config.getS3Bucket(),
                    Key: name + "." + filetype, // File name you want to save as in S3
                    Body: fileContent,
                    ACL: "public-read",
                    ContentType: ContentType,
                }

                const ImageData = await s3.upload(params).promise()

                // if (delObj && ["prod"].includes(Config.servermode)) {
                // 	this.deletefileS3(delObj)
                // }

                const { Key } = ImageData

                if (addfaceindex) {
                    // Add Face to Collection
                    const FaceId = await this.addFaceToCollection({ collectionId: data.collectionid, Key })

                    return { Key, FaceId }
                }

                return Key
            } else {
                const Key = this.getImageUrl(file, 1)

                if (addfaceindex) {
                    // Add Face to Collection
                    const FaceId = await this.addFaceToCollection({ collectionId: data.collectionid, Key })

                    return { Key, FaceId }
                }

                return this.getImageUrl(file, 1)
            }
        } catch (err) {
            console.log(err)

            return ""
        }
    }


    async uploadToBlob(file, name, delBlob = "", data = {}, addFaceIndex = false) {
        try {
            const containerName = Config.getContainer()
            const connectionString = Config.getBlobkey()
            // Check if file is valid
            if ((typeof file === "string" && file !== "" && file !== "undefined" && file.startsWith("data:")) || file?.data) {
                let bufferData;
                let filetype;
                let contentType;

                //DefaultEndpointsProtocol=https;AccountName=<your-account-name>;AccountKey=<your-account-key>;EndpointSuffix=core.windows.net
                // Handle base64 file
                if (typeof file === "string" && file.startsWith("data:")) {
                    const base64Data = file.split(';base64,').pop();
                    bufferData = Buffer.from(base64Data, 'base64');
                    const fileTypeMatch = file.match(/data:(.*?);base64/);
                    contentType = fileTypeMatch ? fileTypeMatch[1] : 'application/octet-stream';
                    filetype = path.extname(file).split('.')[1];
                } else {
                    // Handle binary file upload
                    bufferData = file.data;
                    contentType = file.mimetype;
                    filetype = file.mimetype.split('/')[1];
                }

                if (filetype === 'svg+xml') {
                    filetype = 'svg';
                }

                const blobName = `${name}.${filetype}`;

                // Connect to Azure Blob Service
                const blobServiceClient = BlobServiceClient.fromConnectionString(connectionString);
                const containerClient = blobServiceClient.getContainerClient(containerName);

                // Create container if not exists
                const exists = await containerClient.exists();
                if (!exists) {
                    await containerClient.create();
                }

                // Get a block blob client
                const blockBlobClient = containerClient.getBlockBlobClient(blobName);

                // Upload buffer data to Azure Blob Storage
                await blockBlobClient.uploadData(bufferData, {
                    blobHTTPHeaders: { blobContentType: contentType },
                });

                const blobUrl = blockBlobClient.url;

                // Delete the old blob if needed
                if (delBlob) {
                    const oldBlobClient = containerClient.getBlobClient(delBlob);
                    await oldBlobClient.deleteIfExists();
                }

                // Handle additional processing, e.g., adding face index
                // if (addFaceIndex) {
                //     const faceId = await this.addFaceToCollection({ collectionId: data.collectionId, blobUrl });
                //     return { blobUrl, faceId };
                // }
                console.log("🚀 ~ uploadToBlob ~ blobUrl:", blobUrl)
                return blobUrl;
            } else {
                const blobUrl = this.getImageUrl(file, 1);

                // if (addFaceIndex) {
                //     const faceId = await this.addFaceToCollection({ collectionId: data.collectionId, blobUrl });
                //     return { blobUrl, faceId };
                // }

                return blobUrl;
            }

        } catch (err) {
            console.error('Error uploading to Blob Storage:', err);
            return '';
        }
    }


    async deleteBlobImage(blobName, containerName) {
        try {
            // Get connection string and container details from config
            const connectionString = Config.getBlobkey();
    
            // Connect to Azure Blob Service
            const blobServiceClient = BlobServiceClient.fromConnectionString(connectionString);
            const containerClient = blobServiceClient.getContainerClient(containerName);
    
            // Check if the container exists
            const containerExists = await containerClient.exists();
            if (!containerExists) {
                console.error(`Container "${containerName}" does not exist.`);
                return false;
            }
    
            // Get a blob client for the blob to be deleted
            const blobClient = containerClient.getBlobClient(blobName);
    
            // Check if the blob exists
            const blobExists = await blobClient.exists();
            if (!blobExists) {
                console.error(`Blob "${blobName}" does not exist.`);
                return false;
            }
    
            // Delete the blob
            await blobClient.delete();
    
            console.log(`Blob "${blobName}" deleted successfully.`);
            return true;
        } catch (err) {
            console.error('Error deleting blob image:', err);
            return false;
        }
    }
    // async uploadToS3(file, name, delObj = "", data = {}, addfaceindex = false, compressed = 1) {
    // 	try {

    // 		AWS.config.update({
    // 			accessKeyId: process.env.AWS_ACCESS_KEY, // Access Key
    // 			secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY, // Secret Access Key
    // 			region: process.env.AWS_REGION // Region
    // 		})

    // 		const s3 = new AWS.S3()

    // 		let bufferSizeInBytes = 0
    // 		let imageBuffer = null
    // 		let Key;
    // 		let bufferfileContent;
    // 		let paramsKey;
    // 		let paramsContentType;
    // 		let bufferFlag = 0

    // 		if ((typeof file === "string" && file != "" && file != "undefined" && file.startsWith("data:") && file) || (file && file.data)) {
    // 			let BufferObj
    // 			let bufferData
    // 			let filetype
    // 			let ContentType

    // 			if (typeof file === "string" && file.startsWith("data:")) {
    // 				BufferObj = await this.base64ToBuffer(file)

    // 				bufferData = BufferObj["bufferData"]
    // 				filetype = BufferObj["filetype"]

    // 				ContentType = BufferObj["ContentType"]
    // 			} else {
    // 				bufferData = file.data
    // 				ContentType = file.mimetype
    // 				filetype = file.mimetype.split("/")
    // 				filetype = filetype[1]
    // 			}

    // 			if (filetype == "svg+xml") {
    // 				filetype = "svg"
    // 			}

    // 			// Binary data base64
    // 			const fileContent = Buffer.from(bufferData, "binary")
    // 			bufferSizeInBytes = fileContent.byteLength
    // 			bufferfileContent = fileContent
    // 			paramsKey = name + "." + filetype
    // 			paramsContentType = ContentType
    // 			bufferFlag = 1

    // 		} else {
    // 			const imageObj = {}

    // 			/****************************** Get Image Object ******************************/
    // 			imageObj.imagekey = this.getImageUrl(file, 1)

    // 			// Get Image from S3
    // 			const getImageParams = {
    // 				Bucket: Config.getS3Bucket(),
    // 				Key: imageObj.imagekey
    // 			}

    // 			const imageStream = await s3.getObject(getImageParams).promise()
    // 			/****************************** Get Image Object ******************************/

    // 			bufferSizeInBytes = imageStream.ContentLength
    // 			bufferfileContent = imageStream.Body
    // 			paramsKey = imageObj.imagekey
    // 			paramsContentType = imageStream.ContentType
    // 			bufferFlag = 0
    // 		}

    // 		if (compressed) {
    // 			const compressfilesize = 1000000

    // 			/****************************** Compress Image ******************************/
    // 			const initialQuality = 90 // Initial quality value

    // 			let currentQuality = initialQuality

    // 			while ((!imageBuffer || imageBuffer.length > compressfilesize) && bufferSizeInBytes > compressfilesize) {
    // 				try {
    // 					imageBuffer = await sharp(bufferfileContent).jpeg({ quality: currentQuality }).toBuffer()

    // 					if (imageBuffer.length > compressfilesize) {
    // 						// Adjust quality for the next iteration
    // 						currentQuality -= 2
    // 					}
    // 				} catch (error) {
    // 					break
    // 				}
    // 			}

    // 			if (!imageBuffer) {
    // 				imageBuffer = bufferfileContent
    // 			}
    // 			/****************************** Compress Image ******************************/

    // 		}
    // 		const params = {
    // 			Bucket: Config.getS3Bucket(),
    // 			Key: paramsKey,
    // 			Body: imageBuffer,
    // 			ACL: "public-read",
    // 			ContentType: paramsContentType
    // 		}

    // 		const ImageData = await s3.upload(params).promise()
    // 		Key = bufferFlag ? ImageData.Key : this.getImageUrl(file, 1)

    // 		if (addfaceindex) {
    // 			// Add Face to Collection
    // 			const FaceId = await this.addFaceToCollection({ collectionId: data.collectionid, Key })

    // 			return { Key, FaceId }
    // 		}

    // 		return bufferFlag ? Key : this.getImageUrl(file, 1)
    // 	} catch (err) {
    // 		console.log(err)

    // 		return ""
    // 	}
    // }



 

    async pad(str, max) {
        str = str.toString()
        return str.length < max ? pad("0" + str, max) : str
    }

    async genrand(len = 8) {
        return Math.random()
            .toString(36)
            .substring(2, len + 2)
    }

    generateUniqueNo(name, getnamelen = 3) {
        name = name.replace(/[^A-Z0-9]/gi, "")
        let getPropertyChar = ""
        if (name.length >= getnamelen) {
            getPropertyChar = name.substring(0, getnamelen)
        } else {
            getPropertyChar = name
        }

        return getPropertyChar.toUpperCase() + Math.floor(Math.random() * 100000)
    }

    buildStickynoteTree(nodes) {
        let tree = []

        for (let i = 0; i < nodes.length; i++) {
            if (nodes[i].hasparent === 1) {
                let parent = nodes.filter((elem) => elem._id == nodes[i].parentid).pop()
                if (parent) {
                    parent.stickynotes.push(nodes[i])
                }
            } else {
                tree.push(nodes[i])
            }
        }

        return tree
    }

    axiosrequest(method, url, reqBody, reqHeaders, successCallback, errorCallback) {
        axios({
            method: method,
            url: url,
            data: reqBody,
            headers: reqHeaders,
        })
            .then((response) => successCallback(response))
            .catch((error) => errorCallback(error))
    }

    async axiosRequest(payload) {
        return axios(payload)
    }

    generateMessage(str, data) {
        const regex = /\{\{(.*?)(?!\{\{)\}\}/g
        return str.replace(regex, (match, key) => data[key])
    }

    isIsoDate(date) {
        if (typeof date == "object") {
            date = date.toISOString()
        }
        if (!/\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}.\d{3}Z/.test(date)) return false
        const d = new Date(date)
        return d instanceof Date && !isNaN(d) && d.toISOString() === date // valid date
    }


    getTimezoneTime({ date = new Date(), timezone }) {
        if (timezone) {
            return new Date(date).toLocaleTimeString("en-US", {
                timeZone: timezone,
                hour: "2-digit",
                minute: "2-digit",
            })
        }

        return new Date(date).toLocaleTimeString("en-US", {
            timeZone: timezone,
            hour: "2-digit",
            minute: "2-digit",
        })
    }


    balanceDateTimeOffset(date) {
        let isIsoDate = this.isIsoDate(date)
        if (!isIsoDate) {
            return date
        }
        date = new Date(date)
        let offset = date.getTimezoneOffset()
        date.setMinutes(date.getMinutes() + parseInt(offset))
        return date
    }

    phoneFormat(num) {
        num = num.replace(/^0+/, "")
        num = num.replace(/[^0-9]/, "")

        if (num.length == 12) {
            if (num.substr(0, 1) == 1) num = "+1 " + num.substr(1, 3) + " " + num.substr(4, 3) + " " + num.substr(7, 5)
            else num = "+" + num.substr(0, 2) + " " + num.substr(2, 3) + " " + num.substr(5, 3) + " " + num.substr(8, 4)
        }

        return num
    }

    datesAreOnSameDay(first, second) {
        if (first.getFullYear() === second.getFullYear() && first.getMonth() === second.getMonth() && first.getDate() === second.getDate()) {
            return true
        } else {
            return false
        }
    }

    getSameDateFilter({ date, filterkey, timezone}) {

        if(!timezone){
            timezone = req.headers.timezone || FieldConfig.timezone
        }
        
		const startdate = new Date(date)

		if (startdate.toString() !== "Invalid Date") {
			const pipeline = [
                {
                    $addFields: {
                      "converteddate": {
                        $dateFromString: {
                          dateString: `\$${filterkey}`,
                        }
                      }
                    }
                  },
				{
					$addFields: {
						[`_${filterkey}`]: {
							$dateToString: {
								format: "%Y-%m-%d",
								date: '$converteddate',
								timezone: timezone
							}
						}
					}
				}
			]

			pipeline.push({ $match: { [`_${filterkey}`]: this.getFormatWiseDate(new Date(startdate))}})
				
			return pipeline
		}

		return []
	}

    getSameDateTwoFilter({ date, filterkey, filterkey2, timezone }) {
        if (!timezone) {
            timezone = req.headers.timezone || FieldConfig.timezone;
        }
    
        const startdate = new Date(date);
    
        if (startdate.toString() !== "Invalid Date") {
            const formattedDate = this.getFormatWiseDate(startdate);
    
            const pipeline = [
                {
                    $addFields: {
                        [`_${filterkey}`]: {
                            $dateToString: {
                                format: "%Y-%m-%d",
                                date: `$${filterkey}`,
                                timezone: timezone,
                            },
                        },
                    },
                },
            ];
    
            if (filterkey2) {
                pipeline.push(
                    {
                        $addFields: {
                            [`_${filterkey2}`]: {
                                $dateToString: {
                                    format: "%Y-%m-%d",
                                    date: `$${filterkey2}`,
                                    timezone: timezone,
                                },
                            },
                        },
                    },
                    {
                        $match: {
                            $or: [
                                { [`_${filterkey}`]: formattedDate },
                                { [`_${filterkey2}`]: formattedDate },
                            ],
                        },
                    }
                );
            } else {
                pipeline.push({
                    $match: {
                        [`_${filterkey}`]: formattedDate,
                    },
                });
            }
    
            return pipeline;
        }
    
        return [];
    }
    
    
    


    getTimeFromDesimal(decimalTimeString) {
        var decimalTime = parseFloat(decimalTimeString)
        decimalTime = decimalTime * 60 * 60
        var hours = Math.floor(decimalTime / (60 * 60))
        decimalTime = decimalTime - hours * 60 * 60
        var minutes = Math.floor(decimalTime / 60)
        decimalTime = decimalTime - minutes * 60
        var seconds = Math.round(decimalTime)
        if (hours < 10) {
            hours = "0" + hours
        }
        if (minutes < 10) {
            minutes = "0" + minutes
        }
        if (seconds < 10) {
            seconds = "0" + seconds
        }

        return hours + ":" + minutes + ":" + seconds
    }

    getDateFromDateTime(datetime = "") {
        if (!datetime) {
            datetime = new Date().toISOString()
        }

        datetime = new Date(datetime)
        let day = datetime.getDate()
        day = day.toString().length == 1 ? `0${day}` : day
        let month = datetime.getMonth() + 1
        month = month.toString().length == 1 ? `0${month}` : month
        let year = datetime.getFullYear()
        return `${year}-${month}-${day}`
    }

    getDateFormats(date, format = 1, balanceOffset = false) {
        try {
            if (balanceOffset) {
  
                date = this.balanceDateTimeOffset(date)
            }
            const dateobj = new Date(date)
            const year = dateobj.getFullYear() // 2022
            const month = dateobj.getMonth() + 1 // 9
            const day = dateobj.getDate() // 1

            const yy = year.toString().slice(-2) // 22
            const mm = month.toString().padStart(2, "0") // 09
            const dd = day.toString().padStart(2, "0") // 01
            const shortmonth = dateobj.toLocaleString("default", { month: "short" }) // Sep

            var ss = dateobj.getSeconds().toString().padStart(2, "0") //Get the seconds (0-59)
            var MM = dateobj.getMinutes().toString().padStart(2, "0") //Get the minutes (0-59)
            var HH = dateobj.getHours().toString().padStart(2, "0") //Get the hour (0-23)
            var timestamp = dateobj.getTime() //Get time stamp

            if (format === 1) {
                date = year + "-" + mm + "-" + dd
            } else if (format === 2) {
                date = month + "/" + day + "/" + year
            } else if (format === 3) {
                date = month + "/" + day + "/" + yy
            } else if (format === 4) {
                date = dd + "-" + shortmonth + "-" + yy
            } else if (format === 5) {
                date = yy + "/" + mm + "/" + dd
            } else if (format === 6) {
                date = mm + "/" + dd + "/" + yy
            } else if (format === 7) {
                date = mm + "/" + dd + "/" + year
            } else if (format === 8) {
                date = dd + " " + shortmonth + ", " + year
            } else if (format === 9) {
                date = mm + "-" + dd + "-" + year
            } else if (format === 10) {
                date = year + "-" + mm + "-" + dd + " " + HH + ":" + MM
            } else if (format === 11) {
                date = HH + ":" + MM
            } else if (format === 12) {
                date = timestamp
            } else if (format === 13) {
                date = dd + "" + mm + "" + year
            } else if (format === 14) {
                date = year + "-" + mm + "-" + dd + " " + HH + ":" + MM + ":" + ss
            } else if (format === 15) {
                date = dateobj.toLocaleString([], { hour: "2-digit", minute: "2-digit" })
            } else if (format === 16) {
                let hour = parseInt(HH)
                const ampm = hour >= 12 ? "PM" : "AM"
                hour = hour % 12
                hour = hour ? hour : 12
                let time = hour + ":" + MM + " " + ampm
                date = year + "-" + mm + "-" + dd + " " + time
            } else if (format === 17) {
                const HH = dateobj.getUTCHours().toString().padStart(2, "0")
                const MM = dateobj.getUTCMinutes().toString().padStart(2, "0")

                let hour = parseInt(HH)
                const ampm = hour >= 12 ? "PM" : "AM"

                hour = hour % 12
                hour = hour ? hour : 12

                let time = hour + ":" + MM + " " + ampm

                date = time
            }
        } catch {
            date = "Invalid Date"
        }
        return date
    }

    // Not Used
    getDateFormatsTemp(date, format = 1) {
        try {
            // date = this.balanceDateTimeOffset(date)
            const dateobj = new Date(date).toISOString()
            const year = dateobj.slice(0, 4) // 2022
            const month = dateobj.slice(5, 7) // 9
            const day = dateobj.slice(8, 10) // 1

            const yy = year.slice(-2) // 22
            const mm = month.padStart(2, "0") // 09
            const dd = day.padStart(2, "0") // 01
            const shortmonth = dateobj.toLocaleString("default", { month: "short" }) // Sep

            var HH = dateobj.slice(11, 13).padStart(2, "0") //Get the hour (0-23)
            var MM = dateobj.slice(14, 16).padStart(2, "0") //Get the minutes (0-59)
            var ss = dateobj.slice(17, 19).padStart(2, "0") //Get the seconds (0-59)
            var timestamp = new Date(dateobj).getTime() //Get time stamp

            if (format === 1) {
                date = year + "-" + mm + "-" + dd
            } else if (format === 2) {
                date = month + "/" + day + "/" + year
            } else if (format === 3) {
                date = month + "/" + day + "/" + yy
            } else if (format === 4) {
                date = dd + "-" + shortmonth + "-" + yy
            } else if (format === 5) {
                date = yy + "/" + mm + "/" + dd
            } else if (format === 6) {
                date = mm + "/" + dd + "/" + yy
            } else if (format === 7) {
                date = mm + "/" + dd + "/" + year
            } else if (format === 8) {
                date = dd + " " + shortmonth + ", " + year
            } else if (format === 9) {
                date = mm + "-" + dd + "-" + year
            } else if (format === 10) {
                date = year + "-" + mm + "-" + dd + " " + HH + ":" + MM
            } else if (format === 11) {
                date = HH + ":" + MM
            } else if (format === 12) {
                date = timestamp
            } else if (format === 13) {
                date = dd + "" + mm + "" + year
            } else if (format === 14) {
                date = year + "-" + mm + "-" + dd + " " + HH + ":" + MM + ":" + ss
            } else if (format === 15) {
                date = dateobj.toLocaleString([], { hour: "2-digit", minute: "2-digit" })
            }
        } catch (err) {
            date = "Invalid Date"
            console.log(err)
        }
        return date
    }

    getDateFormatsOld(date, format = 1) {
        try {
            date = date.toString()
            const dateobj = new Date(date)
            const year = dateobj.getFullYear() // 2022
            const month = dateobj.getMonth() + 1 // 9
            const day = dateobj.getDate() // 1

            const yy = year.toString().slice(-2) // 22
            const mm = month.toString().padStart(2, "0") // 09
            const dd = day.toString().padStart(2, "0") // 01
            const shortmonth = dateobj.toLocaleString("default", { month: "short" }) // Sep

            var ss = dateobj.getSeconds().toString().padStart(2, "0") //Get the seconds (0-59)
            var MM = dateobj.getMinutes().toString().padStart(2, "0") //Get the minutes (0-59)
            var HH = dateobj.getHours().toString().padStart(2, "0") //Get the hour (0-23)
            var timestamp = dateobj.getTime() //Get time stamp

            if (format === 1) {
                date = year + "-" + mm + "-" + dd
            } else if (format === 2) {
                date = month + "/" + day + "/" + year
            } else if (format === 3) {
                date = month + "/" + day + "/" + yy
            } else if (format === 4) {
                date = dd + "-" + shortmonth + "-" + yy
            } else if (format === 5) {
                date = yy + "/" + mm + "/" + dd
            } else if (format === 6) {
                date = mm + "/" + dd + "/" + yy
            } else if (format === 7) {
                date = mm + "/" + dd + "/" + year
            } else if (format === 8) {
                date = dd + " " + shortmonth + ", " + year
            } else if (format === 9) {
                date = mm + "-" + dd + "-" + year
            } else if (format === 10) {
                date = year + "-" + mm + "-" + dd + " " + HH + ":" + MM
            } else if (format === 11) {
                date = HH + ":" + MM
            } else if (format === 12) {
                date = timestamp
            } else if (format === 13) {
                date = dd + "" + mm + "" + year
            } else if (format === 14) {
                date = year + "-" + mm + "-" + dd + " " + HH + ":" + MM + ":" + ss
            } else if (format === 15) {
                date = dateobj.toLocaleString([], { hour: "2-digit", minute: "2-digit" })
            }
        } catch {
            date = "Invalid Date"
        }
        return date
    }

    getFormatedDate(date, balanceOffset = false) {
        if (balanceOffset) {
            date = this.balanceDateTimeOffset(date)
        }
        const dateobj = new Date(date)
        const year = dateobj.getFullYear() // 2022
        const month = dateobj.getMonth() + 1 // 9
        const day = dateobj.getDate() // 1
        const yy = year.toString().slice(-2) // 22
        const mm = month.toString().padStart(2, "0") // 09
        const dd = day.toString().padStart(2, "0") // 01
        const shortmonth = dateobj.toLocaleString("default", { month: "short" }) // Sep
        const weekday = dateobj.getDay() // 1

        var second = dateobj.getSeconds().toString().padStart(2, "0") //Get the seconds (0-59)
        var minutes = dateobj.getMinutes().toString().padStart(2, "0") //Get the minutes (0-59)
        var hours = dateobj.getHours().toString().padStart(2, "0") //Get the hour (0-23)
        var millisecond = dateobj.getMilliseconds().toString()
        var timestamp = dateobj.getTime() //Get time stamp

        return {
            year: year,
            month: month,
            day: day,
            yy: yy,
            mm: mm,
            dd: dd,
            weekday: weekday,
            shortmonth: shortmonth,
            second: second,
            minutes: minutes,
            hours: hours,
            millisecond: millisecond,
            timestamp: timestamp,
        }
    }

    paginateArray({ data, requiredPage }) {
        let ResultData = []
        let currentpage = 0
        let nextpage = 0

        // Sort
        data = _.sortBy(data, Object.keys(requiredPage.sort))

        if (Object.keys(requiredPage.sort).length && requiredPage.sort[Object.keys(requiredPage.sort)[0]] === -1) {
            data.reverse()
        }

        if (Object.keys(requiredPage).length !== 0 && requiredPage.pagelimit !== "*") {
            // Pagination
            currentpage = requiredPage.pageno

            ResultData = [...data].slice(requiredPage.skip, requiredPage.skip + requiredPage.pagelimit)

            const totaldocument = data.length
            const totalPage = Math.ceil(totaldocument / requiredPage.pagelimit)

            if (totalPage > currentpage) nextpage = 1
        } else {
            ResultData = [...data]
        }

        return { ResultData, currentpage, nextpage }
    }

    // Get Media URL
    // getImageUrl(image, halfURL = 0) {
    //     const halfImageURL = image ? imagereplace(new RegExp(Config.s3baseurl_old, "gi"), "") : ""

    //     if (halfURL) {
    //         return halfImageURL ? halfImageURL.replace(new RegExp([Config.s3baseurl_old, Config.s3baseurl, Config.s3baseurl_region].join("|"), "gi"), "") : ""
    //     }

    //     return halfImageURL
    //         ? `${Config.s3baseurl}${halfImageURL.replace(new RegExp([Config.s3baseurl_old, Config.s3baseurl, Config.s3baseurl_region].join("|"), "gi"), "")}`
    //         : ""
    // }

    getImageUrl(image, halfURL = 0) {
        const azureBlobBaseUrl = Config.azureBlobBaseUrl; 
        const oldAzureBlobBaseUrl = Config.azureBlobBaseUrl_old; 
        const regionBlobUrl = Config.azureBlobRegionUrl; 
    
        const halfImageURL = image ? image.replace(new RegExp(oldAzureBlobBaseUrl, "gi"), "") : "";
    
        if (halfURL) {
            return halfImageURL ? halfImageURL.replace(new RegExp([oldAzureBlobBaseUrl, azureBlobBaseUrl, regionBlobUrl].join("|"), "gi"), "") : "";
        }
    
        return halfImageURL
            ? `${azureBlobBaseUrl}${halfImageURL.replace(new RegExp([oldAzureBlobBaseUrl, azureBlobBaseUrl, regionBlobUrl].join("|"), "gi"), "")}`
            : "";
    }


    getDateFilter({ fromdate, todate, filterkey, timezone, isequal = false }) {
        const startdate = new Date(fromdate)
        const enddate = new Date(todate)
        if (startdate.toString() !== "Invalid Date" && enddate.toString() !== "Invalid Date") {
            const pipeline = []
            // const pipeline = [
            //     {
            //         $addFields: {
            //             [`_${filterkey}`]: {
            //                 $dateToString: {
            //                     format: "%Y-%m-%d",
            //                     date: `\$${filterkey}`
            //                 },
            //             },
            //         },
            //     },
            // ]

            isequal
                ? pipeline.push({ $match: { [`${filterkey}`]: { $gte: startdate, $lte: enddate } } })
                : pipeline.push({ $match: { [`${filterkey}`]: { $gte: startdate, $lt: enddate } } })

            return pipeline
        }

        return []
    }

    getDateFilterByOrFilter({ fromdate, todate, filterkey1, filterkey2, timezone, isequal = false }) {
        const startdate = new Date(fromdate)
        const enddate = new Date(todate)

        if (startdate.toString() !== "Invalid Date" && enddate.toString() !== "Invalid Date") {
            const pipeline = []

            isequal
                ? pipeline.push({
                    $match: {
                        $or: [
                            { [`${filterkey1}`]: { $gte: startdate, $lte: enddate } },
                            { [`${filterkey2}`]: { $gte: startdate, $lte: enddate } },
                        ],
                    },
                })
                : pipeline.push({
                    $match: {
                        $or: [
                            { [`${filterkey1}`]: { $gte: startdate, $lt: enddate} },
                            { [`${filterkey2}`]: { $gte: startdate, $lt: enddate} }
                        ],
                    },
                })
            return pipeline
        }
        return []
    }

    getTimeFormat(time, format = 2, balanceOffset = true) {
        try {
            if (balanceOffset) {
                time = this.balanceDateTimeOffset(time)
            }
            // time = time.toString()
            const timeobj = new Date(time)
            let hour = timeobj.getHours()
            const minute = timeobj.getMinutes().toString().padStart(2, "0")
            var second = timeobj.getSeconds()

            if (format === 1) {
                time = hour + ":" + minute
            } else if (format === 2) {
                const ampm = hour >= 12 ? "PM" : "AM"
                hour = hour % 12
                hour = hour ? hour : 12
                time = hour + ":" + minute + " " + ampm
            }
        } catch {
            time = "Invalid Time"
        }
        return time
    }

    getTimeZone() {
        const timezone = Intl.DateTimeFormat().resolvedOptions().timeZone
        return timezone
    }

    getage(date) {
        let age = new Date(new Date() - new Date(date)).getFullYear() - 1970
        if (age == -1) {
            age = 0
        }
        return age
    }

    /******************************************************** Socket Functions ********************************************************/

    // Emit Room Wise Socket
    emitRoomWiseSocket(payload) {
        io.emit(Config.getSocketTriggers()["roomwisesocket"], Config.socketencryptionenable ? this.encryptData(payload) : payload)
    }

    emitAllSocket(payload) {
        io.emit(Config.getSocketTriggers()["emitallsocket"], Config.socketencryptionenable ? this.encryptData(payload) : payload)
    }

    // Check Connected Rooms
    async checkroom(roomid) {
        io.emit(Config.getSocketTriggers()["checkroom"], Config.socketencryptionenable ? this.encryptData(roomid) : roomid)

        return new Promise((resolve, reject) => {
            io.on(Config.getSocketTriggers()["checkroomresponse"], (data) => {
                if (Config.socketencryptionenable && data) {
                    const encryptData = data.split(".")[0]
                    const tmpKey = data.split(".")[1]

                    const respData = this.decryptData(encryptData, tmpKey)

                    resolve(respData)
                } else {
                    resolve(data)
                }
            })
        })
    }

    /******************************************************** Socket Functions ********************************************************/

    /******************************************************** Notification Functions ********************************************************/

    // Send Push Notification
    async sendPushNotification(tokens, title, body, data = {}) {
        try {
            let result

            const chunks = _.chunk(tokens, 500)
            const promise = chunks.map(async function (tokenchunk) {
                const payload = {
                    tokens: tokenchunk,
                    title: title,
                    body: body,
                    data: data,
                }

                result = await firebaseAdminobj.sendMulticastNotification(payload)
            })
            await Promise.all(promise)

            return result
        } catch (e) {
            console.log(e)
        }
    }

    // Send Chat Push Notification
    async sendChatPushNotification(tokens, title, body, data = {}) {
        try {
            const promise = tokens.map((token) => {
                if (data.guestmessage) {
                    if (token.chatNotificationSetting.guestmessage.notificationEnable) {
                        data.channelId = token.chatNotificationSetting.guestmessage.channelId
                        data.notificationSound = token.chatNotificationSetting.guestmessage.notificationSound
                    } else {
                        return {}
                    }
                } else {
                    if (token.chatNotificationSetting[data.priority]?.notificationEnable) {
                        data.channelId = token.chatNotificationSetting[data.priority].channelId
                        data.notificationSound = token.chatNotificationSetting[data.priority].notificationSound
                    } else if (token.chatNotificationSetting[data.reaction]?.notificationEnable) {
                        data.channelId = token.chatNotificationSetting[data.reaction].channelId
                        data.notificationSound = token.chatNotificationSetting[data.reaction].notificationSound
                    } else {
                        return {}
                    }
                }

                const payload = {
                    token: token,
                    title: title,
                    body: body,
                    data: data,
                    content_available: true,
                }

                if (data.notificationColor !== "") {
                    payload.color = data.notificationColor
                }

                if (data.badge === null || data.badge === undefined) {
                    let badgeValue = 0
                    data.badge = badgeValue.toString()
                }

                return firebaseAdminobj.sendChatMulticastNotification(payload)
            })

            const result = await Promise.all(promise)

            return result
        } catch (e) {
            console.log(e)
        }
    }

    /******************************************************** Notification Functions ********************************************************/

    /******************************************************** Email Functions ********************************************************/

    // Generate Email Body
    createBody(body, data) {
        let startIndex = 0
        let result = []

        for (let strchar = 0; strchar <= body.length; strchar++) {
            if (body.charAt(strchar) === "#") {
                startIndex = strchar
            } else if (body.charAt(strchar) === "?") {
                result.push(body.substring(parseInt(startIndex), parseInt(strchar) + 1))
            }
        }

        for (let i = -0; i < result.length; i++) {
            body = body.replaceAll(result[i], data[result[i].substring(1, result[i].length - 1)])
        }

        return body
    }

    /******************************************************** Email Functions ********************************************************/


    GetUniqueData(array, key) {
        const arrayUniqueByKey = [...new Map(array.map((item) => [item[key], item])).values()]

        return arrayUniqueByKey
    }

    getReportingAndApprover(personid, person) {
        let reportingperson = []
        let added = []
        let getReporting = (personid) => {
            var allperson = person.filter((o) => Array.isArray(o.reportingtos) && o.reportingtos.find((obj) => obj.reportingtoid.toString() == personid))
            if (allperson.length) {
                for (const p of allperson) {
                    if (p._id != personid) {
                        if (!added.includes(p._id.toString())) {
                            reportingperson.push(p)
                            added.push(p._id.toString())
                        }
                        getReporting(p._id.toString())
                    }
                }
            }
            return true
        }
        let getApprover = (personid) => {
            var allperson = person.filter((o) => Array.isArray(o.approvetos) && o.approvetos.find((obj) => obj.approvetoid.toString() == personid))
            if (allperson.length) {
                for (const p of allperson) {
                    if (p._id != personid) {
                        if (!added.includes(p._id.toString())) {
                            reportingperson.push(p)
                            added.push(p._id.toString())
                        }
                        getApprover(p._id.toString())
                    }
                }
            }
            return true
        }
        getReporting(personid)
        getApprover(personid)
        return {
            reportingperson: reportingperson,
            added: added,
        }
    }

    gettasktimeline(categoryobj, TaskStatusResp, taskobj) {
        let timeline = []

        if (categoryobj.timelinestages) {
            for (let stageobj of categoryobj.timelinestages) {
                let tasklogarray = TaskStatusResp?.ResultData.filter(
                    (obj) => obj.taskid.toString() == taskobj._id.toString() && stageobj.statustype.includes(obj.taskstatustype) && obj.commentlog != 1
                )
                let taskcommentlogarray = TaskStatusResp?.ResultData.filter(
                    (obj) => obj.taskid.toString() == taskobj._id.toString() && stageobj.statustype.includes(obj.taskstatustype) && obj.commentlog == 1
                )

                const compareDates = (a, b) => new Date(a.datetime) - new Date(b.datetime)
                taskcommentlogarray.sort(compareDates)

                let titlename = stageobj.title 
                let subtitlename = ""
                let stagestatus = 0
                let stagedate = ""
                let process = []
                let description = []

                for (const commentobj of taskcommentlogarray) {
                    if (commentobj.comment) {
                        description.push({
                            title: commentobj.comment,
                            date: commentobj.datetime,
                        })
                    }
                }

                if (stageobj.statustype.includes("unassigned") && tasklogarray.length == 0) {
                    tasklogarray = TaskStatusResp?.ResultData.filter((obj) => obj.taskid.toString() == taskobj._id.toString())
                    tasklogarray = tasklogarray[0] ? [tasklogarray[0]] : []
                }

                if (tasklogarray.length == 1) {
                    stagestatus = 1
                    stagedate = tasklogarray[0].datetime

                    subtitlename = stageobj.subtitle

                    if (taskobj.iscompleted == 1 && stageobj.title == "In Progress") {
                        subtitlename = "your request was #processstatus#"
                    }

                    subtitlename = subtitlename.replace("#assigneename#", taskobj.assignperson)
                    subtitlename = subtitlename.replace("#processstatus#", tasklogarray[0].action_name)
                    if (
                        taskobj.isrequestwithdraw == 1 &&
                        tasklogarray[tasklogarray.length - 1].recordinfo.entryby == "guest" &&
                        (tasklogarray[tasklogarray.length - 1].taskstatus == "Completed" || tasklogarray[tasklogarray.length - 1].taskstatus == "Delivered")
                    ) {
                        subtitlename = "Your request was withdrawn by you."
                        titlename = "Withdrawn"
                    } 
                } else if (tasklogarray.length > 1) {
                    stagestatus = 1
                    stagedate = tasklogarray[tasklogarray.length - 1].datetime

                    subtitlename = stageobj.subtitle

                    if (taskobj.iscompleted == 1 && stageobj.title == "In Progress") {
                        subtitlename = "your request was #processstatus#"
                    }

                    subtitlename = subtitlename.replace("#assigneename#", taskobj.assignperson)
                    subtitlename = subtitlename.replace("#processstatus#", tasklogarray[tasklogarray.length - 1].action_name)
                    // process
                    var t = 0

                    //Splice current running process to not show into process
                    if (!taskobj.iscompleted) {
                        tasklogarray.splice(tasklogarray.length - 1)
                    }


                    if (
                        taskobj.isrequestwithdraw == 1 &&
                        tasklogarray[tasklogarray.length - 1].recordinfo.entryby == "guest" &&
                        (tasklogarray[tasklogarray.length - 1].taskstatus == "Completed" || tasklogarray[tasklogarray.length - 1].taskstatus == "Delivered")
                    ) {
                        subtitlename = "Your request was withdrawn by you."
                        titlename = "Withdrawn"
                    } 

                    for (let tasklogobj of tasklogarray) {
                        let processsubtitle = "Your request was " + tasklogobj.action_name


                        if (
                            taskobj.isrequestwithdraw == 1 &&
                            tasklogobj.recordinfo.entryby == "guest" &&
                            (tasklogobj.taskstatus == "Completed" || tasklogobj.taskstatus == "Delivered")
                        ) {
                            processsubtitle = "Your request was withdrawn by you."
                            titlename = "Withdrawn"
                        }

                        process.push({
                            title: processsubtitle,
                            date: tasklogobj.datetime,
                        })
                        t++
                    }
                    if (stageobj.title == "Raised") {
                        process = []
                    }
                }

                process.sort((a, b) => Number(a.date) - Number(b.date)) 

                timeline.push({
                    title: titlename,
                    subtitle: subtitlename,
                    stagestatus: stagestatus,
                    date: stagedate,
                    process: process,
                    description: description,
                })
            }
        }
        return timeline
    }



    getcomplainttimelines() {
        const complaintTimelineResp = {
            timelinestages: [
                {
                    title: "Raised",
                    subtitle: "Complaint has been raised",
                    statustype: ["unassigned"],
                },
                {
                    title: "Assigned",
                    subtitle: "Complaint has been assigned to #assigneename#",
                    statustype: ["open"],
                },
                {
                    title: "In Progress",
                    subtitle: "Complaint is #processstatus#",
                    statustype: ["inprogress", "escalate", "communicate", "investigate", "effort", "resolution", "respond", "followup"], 
                },
                {
                    title: "Paused",
                    subtitle: "Complaint is #processstatus#",
                    statustype: ["paused"],
                },
                {
                    title: "Completed",
                    subtitle: "Complaint has been processed and completed",
                    statustype: ["completed", "reinspection"],
                },
                {
                    title: "Inspection Pending",
                    subtitle: "Inspection is pending for your Complaint",
                    statustype: ["inspection pending"],
                },
                {
                    title: "Inspected",
                    subtitle: "Complaint has been Inspected",
                    statustype: ["inspected"],
                },
                {
                    title: "Revisit",
                    subtitle: "Complaint has transferred for Revisit",
                    statustype: ["revisit"],
                },
            ],
            displayorder: 1,
        }
        return complaintTimelineResp
    }

    getClosestDate(dates = []) {
        if (dates.length) {
            var temp = dates.map((d) => Math.abs(new Date() - new Date(d).getTime()))
            var idx = temp.indexOf(Math.min(...temp))
            return dates[idx]
        } else {
            return null
        }
    }

    getSystemDateWithSetCurrentTime(date = new Date()) {
        let systemdate = new Date(date)

        if (systemdate === "Invalid Date") {
            systemdate = new Date()
        }
        let currentDateTime = new Date()
        systemdate.setHours(currentDateTime.getHours(), currentDateTime.getMinutes(), currentDateTime.getSeconds(), currentDateTime.getMilliseconds())
        return systemdate
    }

    specialTaskFilterData(specialtasks, categoryid, subcategoryid) {
        return specialtasks.filter(
            (special) =>
                special.tasksubcategoryid?.toString() != Config.dummyObjid &&
                special.taskcategoryid?.toString() == categoryid?.toString() &&
                special.tasksubcategoryid?.toString() == subcategoryid?.toString()
        )
    }

    calculateDistance(lat1, lon1, lat2, lon2) {
        const earthRadiusKm = 6371 
        const degToRad = (degrees) => (degrees * Math.PI) / 180

        const dLat = degToRad(lat2 - lat1)
        const dLon = degToRad(lon2 - lon1)

        const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) + Math.cos(degToRad(lat1)) * Math.cos(degToRad(lat2)) * Math.sin(dLon / 2) * Math.sin(dLon / 2)

        const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))

        const distanceKm = earthRadiusKm * c

        if (distanceKm >= 1) {
            return Math.round(distanceKm) * 1000
        } else {
            return Math.round(distanceKm * 1000)
        }
    }

    removeDuplicateaction(taskactionarray) {
        const uniquetaskaction = []
        if (taskactionarray) {
            const taskactionidSet = new Set()

            for (let obj of taskactionarray) {
                if (!taskactionidSet.has(obj.taskactionid.toString())) {
                    taskactionidSet.add(obj.taskactionid.toString())
                    uniquetaskaction.push(obj)
                }
            }
        }
        return uniquetaskaction
    }

    getDatearrayofweek(date) {
        date = new Date(date)
        var diff = date.getDate() - date.getDay() + (date.getDay() === 0 ? -6 : 1)

        let rangefrom = new Date(date.setDate(diff))

        let arr = []
        for (let index = 0; index < 7; index++) {
            var fromdate = new Date(rangefrom)
            fromdate.setDate(fromdate.getDate() + index)
            arr.push(new Date(fromdate))
        }
        return arr
    }



    getDateFormats_new(date, format) {
        try {
            const dateobj = new Date(date)
            let dateISO = dateobj.toISOString()

            const dateSplit = dateISO.split("T")

            const fulldate = dateSplit[0]
            const time = dateSplit[1].split(".")[0]

            const year = fulldate.split("-")[0]
            const month = fulldate.split("-")[1]
            const day = fulldate.split("-")[2]

            const yy = year.slice(-2)
            const mm = parseInt(month) < 10 ? month.slice(-1) : month
            const dd = parseInt(day) < 10 ? day.slice(-1) : day
            const shortmonth = dateobj.toLocaleString("default", { month: "short" })

            const HH = time.split(":")[0]
            const MM = time.split(":")[1]
            const SS = time.split(":")[2]
            const timestamp = dateobj.getTime()

            if (format === 1) {
                date = year + "-" + month + "-" + day
            } else if (format === 2) {
                date = mm + "/" + dd + "/" + year
            } else if (format === 3) {
                date = mm + "/" + dd + "/" + yy
            } else if (format === 4) {
                date = day + "-" + shortmonth + "-" + yy
            } else if (format === 5) {
                date = yy + "/" + month + "/" + day
            } else if (format === 6) {
                date = month + "/" + day + "/" + yy
            } else if (format === 7) {
                date = month + "/" + day + "/" + year
            } else if (format === 8) {
                date = day + " " + shortmonth + ", " + year
            } else if (format === 9) {
                date = month + "-" + day + "-" + year
            } else if (format === 10) {
                date = year + "-" + month + "-" + day + " " + HH + ":" + MM
            } else if (format === 11) {
                date = HH + ":" + MM
            } else if (format === 12) {
                date = timestamp
            } else if (format === 13) {
                date = day + "" + month + "" + year
            } else if (format === 14) {
                date = year + "-" + month + "-" + day + " " + HH + ":" + MM + ":" + SS
            } else if (format === 15) {
                date = dateobj.toLocaleString([], { hour: "2-digit", minute: "2-digit" })
            } else if (format === 16) {
                let hour = parseInt(HH)
                const ampm = hour >= 12 ? "PM" : "AM"
                hour = hour % 12
                hour = hour ? hour : 12
                let time = hour + ":" + MM + " " + ampm
                date = year + "-" + month + "-" + day + " " + time
            } else if (format === 17) {
                const HH = dateobj.getUTCHours().toString().padStart(2, "0")
                const MM = dateobj.getUTCMinutes().toString().padStart(2, "0")

                let hour = parseInt(HH)
                const ampm = hour >= 12 ? "PM" : "AM"

                hour = hour % 12
                hour = hour ? hour : 12

                let time = hour + ":" + MM + " " + ampm

                date = time
            }
        } catch (err) {
            date = "Invalid Date"
            console.log(err)
        }
        return date
    }

    // milisec to hours:mini:sec
    getMiliSecToHours(milisecond) {
        var milliseconds = Math.floor((milisecond % 1000) / 100),
            seconds = Math.floor((milisecond / 1000) % 60),
            minutes = Math.floor((milisecond / (1000 * 60)) % 60),
            hours = Math.floor(milisecond / (1000 * 60 * 60))

        hours = hours < 10 ? "0" + hours : hours
        minutes = minutes < 10 ? "0" + minutes : minutes
        seconds = seconds < 10 ? "0" + seconds : seconds

        return hours + ":" + minutes + ":" + seconds
    }

    //find short day name (date wise)
    getDayNameAndId(date) {
        const dayNames = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"]
        const dayIds = [
            "62fe1881cbac206928991247",
            "62fe1844cbac206928991241",
            "62fe1850cbac206928991242",
            "62fe1857cbac206928991243",
            "62fe1861cbac206928991244",
            "62fe186bcbac206928991245",
            "62fe187bcbac206928991246",
        ]

        const dayIndex = date.getDay()
        return { dayname: dayNames[dayIndex], dayid: dayIds[dayIndex] }
    }

    GetDT(date, days = 0) {
        try {
            let dt = date ? new Date(date) : new Date()
            dt.setUTCDate(new Date(dt).getUTCDate() + days)
            dt.setUTCHours(0, 0, 0, 0)

            return new Date(dt)
        } catch {
            return "Invalid Date"
        }
    }

    // pass date object and set time to 00:00:00
    setStartTimeOfDay(date) {
        let year = new Date(date).getUTCFullYear()
        let month = new Date(date).getUTCMonth()
        let day = new Date(date).getUTCDate()

        const currentDate = new Date()
        currentDate.setUTCFullYear(year)
        currentDate.setUTCMonth(month)
        currentDate.setUTCDate(day)

        return new Date(currentDate.setUTCHours(0, 0, 0, 0))
    }
    // pass date object and set time to 00:00:00

    // pass date object and set time to 23:59:59
    setEndTimeOfDay(date) {
        let year = new Date(date).getUTCFullYear()
        let month = new Date(date).getUTCMonth()
        let day = new Date(date).getUTCDate()

        const currentDate = new Date()
        currentDate.setUTCFullYear(year)
        currentDate.setUTCMonth(month)
        currentDate.setUTCDate(day)
        return new Date(currentDate.setUTCHours(23, 59, 59, 0))
    }

    ConvertDateObjTOISOString(date) {
        let year = date.getUTCFullYear()
        let month = date.getUTCMonth()
        month = (month + 1).toString().length > 1 ? month + 1 : `0${month + 1}`
        let day = date.getUTCDate()
        day = day.toString().length > 1 ? day : `0${day}`
        let hr = date.getUTCHours()
        hr = hr.toString().length > 1 ? hr : `0${hr}`
        let min = date.getUTCMinutes()
        min = min.toString().length > 1 ? min : `0${min}`
        let sec = date.getUTCSeconds()
        sec = sec.toString().length > 1 ? sec : `0${sec}`
        return `${year}-${month}-${day}T${hr}:${min}:${sec}.000Z`
    }

    GetISOdate(date) {
        let splitdate = `${date.split("T")[0]}`
        return splitdate.replaceAll("-", "/")
    }

    isOverlapDate(startdate, enddate, startdate1, enddate1) {
        if (
            (new Date(startdate) <= new Date(startdate1) && new Date(enddate) >= new Date(startdate1)) ||
            (new Date(startdate1) <= new Date(enddate) && new Date(enddate1) >= new Date(enddate)) ||
            (new Date(startdate1) <= new Date(startdate) && new Date(enddate1) >= new Date(startdate)) ||
            (new Date(startdate1) <= new Date(enddate) && new Date(enddate1) >= new Date(enddate))
        ) {
            return true
        } else {
            return false
        }
    }

    
    isTimeRangeOverlapping = (range1Start,range1End,range2Start, range2End) => {
        
        const extractTime = (dateString) => new Date(dateString).toISOString().substring(11, 19);
        
        const start1 = extractTime(range1Start);
        const end1 = extractTime(range1End);
        const start2 = extractTime(range2Start);
        const end2 = extractTime(range2End);

        return (start1 < end2 && start2 < end1);
    };

    paginationArr(arr, size, pageno) {
        function paginate(arr, size) {
            return arr.reduce((acc, val, i) => {
                let idx = Math.floor(i / size)
                let page = acc[idx] || (acc[idx] = [])
                page.push(val)

                return acc
            }, [])
        }

        let paginatedata = paginate(arr, size)
        var page = 0
        if (paginatedata.length - 1 > pageno) {
            page = 1
        }

        let paginationdata = {
            data: paginatedata[pageno],
            page: page,
        }
        return paginationdata
    }

    subtractMinutes(numOfMinutes, date = new Date()) {
        date.setMinutes(date.getMinutes() - numOfMinutes)
        return date
    }

    // date past/privious
    datepastprevious(date, days, add = true) {
        var cdate = new Date(date)
        if (add == false) {
            cdate.setDate(cdate.getDate() - days)
        } else {
            cdate.setDate(cdate.getDate() + days)
        }
        return cdate
    }


    async makeScheduleTimeBlock(filepath, data) {
        const __dirname = path.resolve()
        filepath = __dirname + filepath
        const readFile = promisify(fs.readFile)
        let block = await readFile(filepath, "utf8")
        let result = this.makeContent(block, data)
        return result
    }

    makeContent(body, data) {
        let startIndex = 0
        let result = []

        for (let strchar = 0; strchar <= body?.length; strchar++) {
            if (body.charAt(strchar) === "#") {
                startIndex = strchar
            } else if (body.charAt(strchar) === "?") {
                result.push(body.substring(parseInt(startIndex), parseInt(strchar) + 1))
            }
        }

        for (let i = -0; i < result.length; i++) {
            body = body.replaceAll(result[i], data[result[i].substring(1, result[i].length - 1)])
        }

        return body
    }
    // -------------------

    GetLastWeeksDate(day) {
        let date = day ? day : new Date().toISOString()

        const now = new Date(date)

        return new Date(now.getFullYear(), now.getMonth(), now.getDate() - 7)
    }

    GetLastMonthDates(day) {
        let date = day ? day : new Date().toISOString()
        date = new Date(date)

        var firstDay = new Date(date.getFullYear(), date.getMonth() - 1, 1)
        var lastDay = new Date(date.getFullYear(), date.getMonth(), 0)

        return { firstDay: firstDay, lastDay: lastDay }
    }

    datebeforemonth(date, month) {
        var pereviousmonth = new Date(date)
        pereviousmonth.setDate(1)
        pereviousmonth.setMonth(pereviousmonth.getMonth() - parseInt(month))
        return pereviousmonth
    }

    GetLastYearDates(day) {
        let date = day ? day : new Date().toISOString()

        const currentYear = new Date(date).getFullYear() - 1
        const firstDay = new Date(currentYear, 0, 1)
        const lastDay = new Date(currentYear, 11, 31)

        return { firstDay: firstDay, lastDay: lastDay }
    }

    PasswordValidation(password) {
        let message = ""

        // if (password?.length < 14) {
        //     return (message = "Password must be at least 14 characters")
        // }
        // if (password.search(/[0-9]/) < 0) {
        //     return (message = "Password have at least one number")
        // }
        // if (password.search(/[a-z]/) < 0) {
        //     return (message = "Password have at least one lower case letter")
        // }
        // if (password.search(/[A-Z]/) < 0) {
        //     return (message = "Password have at least one upper case letter")
        // }
        // if (password.search(/[!@#$%^&?_"]/) < 0) {
        //     return (message = "Password have at least one symbol !@#$%^&?_")
        // }
        // if (this.SeriesPasswordValidation(password) == false) {
        //     return (message = "Password Numbers & Character are not is Series")
        // }
        return message
    }

    SeriesPasswordValidation(str = "") {
        if (!str) return false

        for (let i = 0; i < str.length; i++) {
            if (str[i + 1] && str[i + 2] && str?.charCodeAt(i) + 1 === str?.charCodeAt(i + 1) && str?.charCodeAt(i + 1) + 1 === str?.charCodeAt(i + 2)) {
                return false
            }
            if (str[i + 1] && str[i + 2] && str?.charCodeAt(i + 1) + 1 === str?.charCodeAt(i) && str?.charCodeAt(i + 1) === str?.charCodeAt(i + 2) + 1) {
                return false
            }
            if (str.length === i + 1) return true
        }
    }

    encodeData(data) {
        let iismethod = new IISMethods()
        if (typeof data === "string") {
            return entities.encode(data)
        } else if (Array.isArray(data)) {
            return data.map(iismethod.encodeData)
        } else if (typeof data === "object") {
            for (const key in data) {
                data[key] = iismethod.encodeData(data[key])
            }
        }
        return data
    }

    decodeData(data) {
        let iismethod = new IISMethods()
        if (typeof data === "string") {
            return entities.decode(data)
        } else if (Array.isArray(data)) {
            return data.map(iismethod.decodeData)
        } else if (typeof data === "object") {
            for (const key in data) {
                data[key] = iismethod.decodeData(data[key])
            }
        }
        return data
    }

    extractObjectIdKeys(obj, result = []) {
        for (const key in obj) {
            if (obj[key]?.type === mongoose.Schema.Types.ObjectId) {
                result.push(key)
            } else if (typeof obj[key] === "object") {
                this.extractObjectIdKeys(obj[key], result)
            }
        }
        return result
    }

    ObjectIdValidation(data, schema) {
        const schemaarray = this.extractObjectIdKeys(schema)

        for (const obj in data) {
            if (typeof data[obj] == "string") {
                if (schemaarray.includes(obj)) {
                    if (this.ValidateObjectId(data[obj]) === false) {
                        return false
                    }
                }
                data[obj] = entities.encode(data[obj])
            } else if (typeof data[obj] == "object") {
                const result = this.ObjectIdValidation(data[obj], schema)
                if (result === false) {
                    return false
                }
            }
        }
        return data
    }



    getFirstDateForDayOfWeekInMonth(dayOfWeek) {
        // Validate input
        const days = ["sunday", "monday", "tuesday", "wednesday", "thursday", "friday", "saturday"]
        const shortnamedays = ["sun", "mon", "tue", "wed", "thu", "fri", "sat"]
        dayOfWeek = dayOfWeek.toLowerCase()

        if (!days.includes(dayOfWeek) && !shortnamedays.includes(dayOfWeek)) {
            console.log("Invalid day of the week")
            return null
        } else {
            // Get current date
            const today = new Date()

            // Set the date to the first day of the month
            const firstDayOfMonth = new Date(today.getFullYear(), today.getMonth(), 1)

            // Get the current day of the week for the first day of the month
            const currentDayOfWeek = firstDayOfMonth.getDay()

            // Calculate the difference between the desired day and the current day
            let difference = null
            if (days.includes(dayOfWeek)) {
                difference = days.indexOf(dayOfWeek) - currentDayOfWeek + (days.indexOf(dayOfWeek) < currentDayOfWeek ? 7 : 0)
            } else if (shortnamedays.includes(dayOfWeek)) {
                difference = days.indexOf(dayOfWeek) - currentDayOfWeek + (days.indexOf(dayOfWeek) < currentDayOfWeek ? 7 : 0)
            }

            // Calculate the date for the desired day in the current month
            const targetDate = new Date(firstDayOfMonth)
            targetDate.setDate(firstDayOfMonth.getDate() + difference)

            return targetDate
        }
    }

    getDatesForWeekdayOccurrences(weekDayName, occurrence) {
        const normalizedWeekDayName = weekDayName.toLowerCase()
        const weekDays = ["sunday", "monday", "tuesday", "wednesday", "thursday", "friday", "saturday"]
        const shortweekDays = ["sun", "mon", "tue", "wed", "thu", "fri", "sat"]

        if ((!weekDays.includes(normalizedWeekDayName) && !shortweekDays.includes(normalizedWeekDayName)) || occurrence < 1 || occurrence > 5) {
            return "Invalid input"
        } else {
            const today = new Date()
            const currentYear = today.getFullYear()
            let dates = new Date()
            const month = today.getMonth()
            // for (let month = 0; month < 12; month++) {
            const firstDayOfMonth = new Date(currentYear, month, 1)

            // Find the first occurrence of the specified weekday in the month
            let targetWeekdayIndex = null
            if (weekDays.includes(normalizedWeekDayName)) {
                targetWeekdayIndex = weekDays.indexOf(normalizedWeekDayName)
            } else if (shortweekDays.includes(normalizedWeekDayName)) {
                targetWeekdayIndex = shortweekDays.indexOf(normalizedWeekDayName)
            }
            const currentWeekdayIndex = firstDayOfMonth.getDay()
            const daysUntilTargetDay = (targetWeekdayIndex - currentWeekdayIndex + 7) % 7

            const firstOccurrenceDate = new Date(firstDayOfMonth)
            firstOccurrenceDate.setDate(firstOccurrenceDate.getDate() + daysUntilTargetDay)

            // Calculate the date of the Nth occurrence
            const nthOccurrenceDate = new Date(firstOccurrenceDate)
            nthOccurrenceDate.setDate(nthOccurrenceDate.getDate() + (occurrence - 1) * 7)

            // Ensure the calculated date is still within the current month
            if (nthOccurrenceDate.getMonth() === month) {
                dates = nthOccurrenceDate
            }
            // }

            return dates
        }
    }

    /*-------------------------------------------- PMS Function --------------------------------------------*/

    hexToStr(hexValue) {
        const decimalValue = parseInt(hexValue, 16)

        return decimalValue.toString()
    }

    /*-------------------------------------------- PMS Function --------------------------------------------*/

    PaginationArr(arr, size, pageno, sort, searchtext) {
        if (arr.length) {
            if (searchtext) {
                arr = this.gloabalSearch(arr, searchtext)
            }

            if (sort && Object.keys(sort).length !== 0) {
                const keys = Object.keys(sort)
                let sortWith = keys.length > 0 ? keys[0] : undefined
                if (sortWith) {
                    arr = this.sortByKey(arr, sortWith, sort[sortWith])
                }
            }

            function paginate(arr, size) {
                return arr.reduce((acc, val, i) => {
                    let idx = Math.floor(i / size)
                    let page = acc[idx] || (acc[idx] = [])
                    page.push(val)
                    return acc
                }, [])
            }

            let paginatedata = paginate(arr, size)

            var page = 0
            if (paginatedata.length - 1 > pageno) {
                page = 1
            }

            let paginationdata = {
                data: paginatedata[pageno],
                page: page,
            }
            return paginationdata
        } else {
            return {
                data: [],
                page: 0,
            }
        }
    }

    removeHtmlTags(str) {
        // Replace HTML tags with a single space
        return str
            .replace(/<\/?[^>]+(>|$)/g, " ")
            .trim()
            .replace(/\s+/g, " ")
    }

    toFixedFloat(value, cut = 2) {
        return parseFloat(value.toFixed(cut))
    }

    getYearDifference(startdate, enddate) {
        // Parse the dates to Date objects
        const fromdate = new Date(startdate)
        const todate = new Date(enddate)

        // Get the year components of both dates
        const fromdateYear = fromdate.getFullYear()
        const todateYear = todate.getFullYear()

        // Calculate the difference in years
        let yearDifference = Math.abs(todateYear - fromdateYear)

        // Adjust the difference if the second date is earlier in the year than the first date
        const fromdateMonth = fromdate.getMonth()
        const todateMonth = todate.getMonth()
        const fromdateDay = fromdate.getDate()
        const todateDay = todate.getDate()

        if (todateMonth < fromdateMonth || (todateMonth === fromdateMonth && todateDay < fromdateDay)) {
            yearDifference--
        }

        return yearDifference
    }

    isDateInRange(date, startDate, endDate) {
        const dateObj = new Date(date);
        return dateObj >= new Date(startDate) && dateObj <= new Date(endDate);
    }


    calculateDateDifference(startDate, endDate, SuffixStringType = 0, isIncludeEndDate = false) {
        // SuffixStringType ~ 0 : "", 1 : "to go", 2 : "remaining"
        // Parse the input dates
        let fromDate = new Date(new Date(startDate).setUTCHours(0, 0, 0, 0))
        let toDate = new Date(new Date(endDate).setUTCHours(0, 0, 0, 0))
        toDate.setUTCFullYear(fromDate.getUTCFullYear())

        // Calculate the difference in time
        const differenceInTime = toDate.getTime() - fromDate.getTime()

        // Calculate the difference in days
        const differenceInDays = isIncludeEndDate ? differenceInTime / (1000 * 3600 * 24) + 1 : differenceInTime / (1000 * 3600 * 24) // Including the end date

        if (toDate < fromDate) {
            toDate.setUTCFullYear(toDate.getUTCFullYear() + 1)
        }

        // Calculate the difference in years, months and days
        let years = toDate.getUTCFullYear() - fromDate.getUTCFullYear()
        let months = toDate.getUTCMonth() - fromDate.getUTCMonth()
        let days = isIncludeEndDate ? toDate.getUTCDate() - fromDate.getUTCDate() + 1 : toDate.getUTCDate() - fromDate.getUTCDate() // Including the end date


        // Adjust for negative days
        if (days < 0) {
            months -= 1
            const previousMonth = new Date(toDate.getUTCFullYear(), toDate.getUTCMonth() - 1, fromDate.getUTCDate())
            days = new Date(previousMonth.getUTCFullYear(), previousMonth.getUTCMonth() + 1, 0).getUTCDate() - previousMonth.getUTCDate() + 1 + toDate.getUTCDate()
        }

        // Adjust for negative months
        if (months < 0) {
            years -= 1
            months += 12
        }

        // Handle month transition
        if (days > new Date(fromDate.getUTCFullYear(), fromDate.getUTCMonth() + 1, 0).getUTCDate()) {
            months += 1
            days -= new Date(fromDate.getUTCFullYear(), fromDate.getUTCMonth() + 1, 0).getUTCDate()
        }

        // Prepare the result string
        let result = ""
        if (years > 0) {
            result += `${years} year${years === 1 ? "" : "s"}`
        }
        if (months == 1 && days == 0) {
            if (result !== "") {
                result += " "
            }
            result += `${differenceInDays} day${differenceInDays === 1 ? "" : "s"}`
        } else if (months > 0) {
            if (result !== "") {
                result += " "
            }
            result += `${months} month${months === 1 ? "" : "s"}`
        }
        if (days > 0) {
            if (result !== "") {
                result += " "
            }
            result += `${days} day${days === 1 ? "" : "s"}`
        }

        return result === "" ? "" : SuffixStringType === 1 ? `${result} to go` : SuffixStringType === 2 ? `${result} remaining` : result
    }

    getCurrentQuarter() {
        const month = new Date().getMonth() + 1;
        return Math.ceil(month / 3);
    }

    createDisabledSlots(dates, slots) {
        const disabledSlots = [];
    
        for (const dateString of dates) {
            const baseDate = new Date(dateString);
    
            for (const slot of slots) {
                const startTime = new Date(slot.starttime);
                const endTime = new Date(slot.endtime);
    
                // Clone baseDate and directly set hours and minutes
                const startDate = new Date(baseDate)
                startDate.setHours(startTime.getHours(), startTime.getMinutes(), 0, 0)

                const endDate = new Date(baseDate)
                endDate.setHours(endTime.getHours(), endTime.getMinutes(), 0, 0)
    
                disabledSlots.push({
                    date: dateString,
                    starttime: startDate.toISOString(),
                    endtime: endDate.toISOString(),
                    slotId: slot._id,
                });
            }
        }
    
        return disabledSlots
    }


    istToUtc(istDateString) {
        // Create a date object from the IST date string
        const istDate = new Date(istDateString);
        
        // Get the UTC offset for IST (5 hours and 30 minutes in milliseconds)
        const istOffset = 5.5 * 60 * 60 * 1000;
        
        // Convert to UTC by subtracting the IST offset
        const utcDate = new Date(istDate.getTime() - istOffset);
        
        return utcDate;
    }
    
    // Example usage:
    // const istTime = '2024-03-20T15:30:00';
    // const utcTime = istToUtc(istTime);
    // console.log('IST:', istTime);
    // console.log('UTC:', utcTime.toISOString());

    generateDateTimeRange({ startdate, enddate, starttime, endtime, weekdays }) {
        const daysMapping = {
            'Sun': 0,
            'Mon': 1,
            'Tue': 2,
            'Wed': 3,
            'Thu': 4,
            'Fri': 5,
            'Sat': 6
        };
    
        // If no weekdays are provided, consider all days of the week
        const days = weekdays ? weekdays.map(day => daysMapping[day]) : [0, 1, 2, 3, 4, 5, 6];
    
        // Parse the startdate and enddate as UTC to avoid timezone issues
        const startDateObj = new Date(startdate);
        const endDateObj = new Date(enddate);
        
        const finalArray = [];
    
        // Parse the time input or use defaults
        const { hours: startHour = 0, minutes: startMinute = 0 } = starttime ? IISMethods.parseTime(starttime) : {};
        const { hours: endHour = 23, minutes: endMinute = 59 } = endtime ? IISMethods.parseTime(endtime) : {};
    
        // Iterate through each date from startdate to enddate
        for (let currentDate = new Date(startDateObj); currentDate <= endDateObj; currentDate.setUTCDate(currentDate.getUTCDate() + 1)) {
            if (days.includes(currentDate.getUTCDay())) {
                // Set the start time in UTC
                const formattedStartDate = new Date(currentDate);
                formattedStartDate.setUTCHours(startHour, startMinute, 0, 0)
    
                // Set the end time in UTC
                const formattedEndDate = new Date(currentDate);
                formattedEndDate.setUTCHours(endHour, endMinute, 59, 999)
    
                // Push the formatted date object to the final array
                finalArray.push({
                    startdate: formattedStartDate.toISOString(),
                    enddate: formattedEndDate.toISOString()
                });
            }
        }
    
        return finalArray;
    }


    generateDateTimeRange({ startdate, enddate, starttime, endtime, weekdays }) {
        const daysMapping = {
            'Sun': 0,
            'Mon': 1,
            'Tue': 2,
            'Wed': 3,
            'Thu': 4,
            'Fri': 5,
            'Sat': 6
        };
    
        // If no weekdays are provided, consider all days of the week
        const days = weekdays ? weekdays.map(day => daysMapping[day]) : [0, 1, 2, 3, 4, 5, 6];
    
        // Parse the startdate and enddate as UTC to avoid timezone issues
        const startDateObj = new Date(startdate);
        const endDateObj = new Date(enddate);
        
        const finalArray = [];
    
        // Parse the time input or use defaults
        const { hours: startHour = 0, minutes: startMinute = 0 } = starttime ? IISMethods.parseTime(starttime) : {};
        const { hours: endHour = 23, minutes: endMinute = 59 } = endtime ? IISMethods.parseTime(endtime) : {};
    
        // Iterate through each date from startdate to enddate
        for (let currentDate = new Date(startDateObj); currentDate <= endDateObj; currentDate.setUTCDate(currentDate.getUTCDate() + 1)) {
            if (days.includes(currentDate.getUTCDay())) {
                // Set the start time in UTC
                const formattedStartDate = new Date(currentDate);
                formattedStartDate.setUTCHours(startHour, startMinute, 0, 0)
    
                // Set the end time in UTC
                const formattedEndDate = new Date(currentDate);
                formattedEndDate.setUTCHours(endHour, endMinute, 59, 999)
    
                // Push the formatted date object to the final array
                finalArray.push({
                    startdate: formattedStartDate.toISOString(),
                    enddate: formattedEndDate.toISOString()
                });
            }
        }
    
        return finalArray;
    }
    

}


export default IISMethods
