
import _Config from "./Config.js"
const Config = new _Config()


class FieldConfig {
    constructor() {   

        this.notificationsetting = {
            housekeeping:  "/notification/housekeeping.svg",
            maintenance:  "/notification/maintenance.svg"
        }

        this.roomactionname = {
            complaint: "Complaint",
        }

        // chat user status
        this.chatstatus = {
            Available: "6368b2877be3db6d0856a0f4",
            Away: "6368b2de7be3db6d0856a1dd",
            Busy: "6368b27a7be3db6d0856a0e1",
            Offline: "6368b26c7be3db6d0856a0ce",
            DND: "636202076d1d0c0dae3dbe92"
        }

        this.chatstatuscolor = {
            Available: "#08c72a",
            Away: "#eec10f",
            Busy: "#d10029",
            Offline: "#949494",
            DND: "#d10029"
        }


        this.priority = {
            low: "6303126355c8ad547b0f809c",
            medium: "6303126055c8ad547b0f809b",
            high: "6303125b55c8ad547b0f809a"
        }

        this.checklistsvg = "glam/svg/checklist.svg"

        this.socketevent = {
            unassigned: "unassigned",
            open: "open"
        }

        this.complaintalias = "complaint"  
        
        this.notificationcategory = {
            complaint: "63c52a49581f7a2dc5099cf4"
        }


        this.notificationalias = {
            unassigned: "unassigned",
            open: "open",
            dirty: "dirty",
            // Complaint
            response: "response",
            escalation: "escalation",
            tasktransfer: "tasktransfer",
            investigation: "investigation"
        }


        this.complainttype = {
            // house keepimg
            "6409bc1f9de9a418e1c85ecf": {
                complainttype: "Others"
            },
            "6409bbfd9de9a418e1c85ece": {
                complainttype: "Amenities"
            },
            "6409bb909de9a418e1c85ec7": {
                complainttype: "Cleanliness"
            }
        }


        this.readingcolor = {
            white: {
                r: 255,
                g: 255,
                b: 255,
                a: 1
            },
            yellow: {
                r: 255,
                g: 255,
                b: 0,
                a: 1
            },
            green: {
                r: 30,
                g: 176,
                b: 90,
                a: 1
            },
            red: {
                r: 206,
                g: 34,
                b: 34,
                a: 1
            }
        }

        this.checklistcolor = {
            default: {
                r: 34,
                g: 49,
                b: 124,
                a: 1
            },
            green: {
                r: 30,
                g: 176,
                b: 90,
                a: 1
            },
            red: {
                r: 206,
                g: 34,
                b: 34,
                a: 1
            },
            darkgreen: {
                r: 37,
                g: 129,
                b: 74,
                a: 1
            }
        }

        this.timezone = "Asia/Kolkata"

        this.domainname = "godrejliving"

        this.moduletype = {
            web: "621632cd6e7429b80322da0d",
            app: "621637248d1a174bd75d04e5",
            desktop: "6380b987f17f5c600cb5ff9e",
            chat: "638de7cdb2716d726ab43eca"
        }

        this.modulename = {
            web: "web",
            app: "app"
        }

        this.ostype = {
            web: "63ad6519a96926082de326d8",
            android: "63ad67d4a96926082de326e6",
            ios: "63ad67dca96926082de326e7",
            desktop: "63ad67e1a96926082de326e8",
            macos: "63ad67e4a96926082de326e9"
        }

        this.seriestype = {
            breakqueue: "6603a1f6240183582f589c99"
       }


        // Blocked body
        this.blockedwords = ["<link>", "<script>"]

        this.URLPages = {
            // Signup ----------------------------
            "/getaccesstoken": { pagename: { web: "login" }, action: "list" },
            "/checkdomain": { pagename: { web: "login" }, action: "list" },
            "/login": { pagename: { web: "login" }, action: "list" },
            "/2FA/login": { pagename: { web: "login" }, action: "list" },
            "/logout": { pagename: { web: "login", app: "logout" }, action: "list" },
            "/logindata": { pagename: { web: "login" }, action: "list" },
            "/glamlogin": { pagename: { web: "login" }, action: "list" },
            "/attendancehwlogin": { pagename: { web: "login" }, action: "list" },
            "/forgotpasswordrequest": { pagename: { web: "login" }, action: "add" },
            "/forgotpasswordotp/verify": { pagename: { web: "login" }, action: "update" },
            "/forgotpasswordreset": { pagename: { web: "login" }, action: "update" },
            "/changepassword": { pagename: { web: "login" }, action: "update" },
            // ------------------------------------------

            // 2FA ---------------------------------------
            "/2FA/enable": { pagename: { web: "employeemaster" }, action: "update" },
            "/2FA/verifyenable": { pagename: { web: "employeemaster" }, action: "update" },
            "/2FA/disable": { pagename: { web: "employeemaster" }, action: "update" },
            "/2FA/recoverycode": { pagename: { web: "employeemaster" }, action: "update" },
            "/2FA/recoverycode/verify": { pagename: { web: "employeemaster" }, action: "update" },
            // ---------------------------------------------

            "/menu": { pagename: { web: "menumaster" }, action: "list" },
            "/menu/add": { pagename: { web: "menumaster" }, action: "add" },
            "/menu/update": { pagename: { web: "menumaster" }, action: "update" },
            "/menu/delete": { pagename: { web: "menumaster" }, action: "delete" },

            "/icon": { pagename: { web: "iconmaster" }, action: "list" },
            "/icon/add": { pagename: { web: "iconmaster" }, action: "add" },
            "/icon/update": { pagename: { web: "iconmaster" }, action: "update" },
            "/icon/delete": { pagename: { web: "iconmaster" }, action: "delete" },

            "/masters/module": { pagename: { web: "modulemaster" }, action: "list" },
            "/masters/module/add": { pagename: { web: "modulemaster" }, action: "add" },
            "/masters/module/update": { pagename: { web: "modulemaster" }, action: "update" },
            "/masters/module/delete": { pagename: { web: "modulemaster" }, action: "delete" },

            "/dashboard/menu": { pagename: { web: "dashboard", app: "dashboard" }, action: "list" } /*.....*/,
            "/dashboard/menu/add": { pagename: { web: "dashboard", app: "dashboard" }, action: "add" } /*.....*/,
            "/dashboard/menu/update": { pagename: { web: "dashboard", app: "dashboard" }, action: "update" } /*.....*/,
            "/dashboard/menu/delete": { pagename: { web: "dashboard", app: "dashboard" }, action: "delete" } /*.....*/,

            "/masters/userrole": { pagename: { web: "userrolemaster" }, action: "list" },
            "/masters/userrole/add": { pagename: { web: "userrolemaster" }, action: "add" },
            "/masters/userrole/update": { pagename: { web: "userrolemaster" }, action: "update" },
            "/masters/userrole/delete": { pagename: { web: "userrolemaster" }, action: "delete" },

            "/userrolehierarchy": { pagename: { web: "userrolehierarchy" }, action: "list" },
            "/userrolehierarchy/add": { pagename: { web: "userrolehierarchy" }, action: "add" },
            "/userrolehierarchycopy": { pagename: { web: "userrolehierarchy" }, action: "update" },

            "/masters/menuassign": { pagename: { web: "menuassign" }, action: "list" },
            "/masters/menuassign/add": { pagename: { web: "menuassign" }, action: "add" },
            "/masters/menuassign/update": { pagename: { web: "menuassign" }, action: "update" },

            "/menudesign": { pagename: { web: "menudesign" }, action: "list" },
            "/menudesign/update": { pagename: { web: "menudesign" }, action: "update" },

            "/masters/userrights": { pagename: { web: "userrights" }, action: "list" },
            "/masters/userrights/update": { pagename: { web: "userrights" }, action: "update" },
            "/masters/userrightscopy": { pagename: { web: "userrights" }, action: "update" },

            "/masters/dashboardrights": { pagename: { web: "dashboardrights" }, action: "list" },
            "/masters/dashboardrights/update": { pagename: { web: "dashboardrights" }, action: "update" },
            "/masters/dashboardrightscopy": { pagename: { web: "dashboardrights" }, action: "update" },
            "/masters/dashboardrightscopynew": { pagename: { web: "dashboardrights" }, action: "update" },

            "/masters/frontdeskdashboardrights": { pagename: { web: "dashboardrights" }, action: "list" },

            "/masters/dashboardrights/fields": { pagename: { web: "dashboardrights" }, action: "list" },

            "/masters/series": { pagename: { web: "series" }, action: "list" },
            "/masters/series/add": { pagename: { web: "series" }, action: "add" },
            "/masters/series/update": { pagename: { web: "series" }, action: "update" },
            "/masters/series/delete": { pagename: { web: "series" }, action: "delete" },

            "/masters/projectgroup": { pagename: { web: "projectgroup" }, action: "list" },
            "/masters/projectgroup/add": { pagename: { web: "projectgroup" }, action: "add" },
            "/masters/projectgroup/update": { pagename: { web: "projectgroup" }, action: "update" },
            "/masters/projectgroup/delete": { pagename: { web: "projectgroup" }, action: "delete" },

            "/masters/country": { pagename: { web: "country" }, action: "list" },
            "/masters/country/add": { pagename: { web: "country" }, action: "add" },
            "/masters/country/update": { pagename: { web: "country" }, action: "update" },
            "/masters/country/delete": { pagename: { web: "country" }, action: "delete" },

            "/masters/state": { pagename: { web: "state" }, action: "list" },
            "/masters/state/add": { pagename: { web: "state" }, action: "add" },
            "/masters/state/update": { pagename: { web: "state" }, action: "update" },
            "/masters/state/delete": { pagename: { web: "state" }, action: "delete" },

            "/masters/city": { pagename: { web: "city" }, action: "list" },
            "/masters/city/add": { pagename: { web: "city" }, action: "add" },
            "/masters/city/update": { pagename: { web: "city" }, action: "update" },
            "/masters/city/delete": { pagename: { web: "city" }, action: "delete" },

            "/saas_admin/employee": { pagename: { web: "employee" }, action: "list" } /*.....*/,
            "/saas_admin/employee/add": { pagename: { web: "employee" }, action: "add" } /*.....*/,
            "/saas_admin/employee/update": { pagename: { web: "employee" }, action: "update" } /*.....*/,
            "/saas_admin/employee/delete": { pagename: { web: "employee" }, action: "delete" } /*.....*/,

            "/generateseries": { pagename: { web: "series" }, action: "list" },

            "/emailsmtp": { pagename: { web: "emailsmtp" }, action: "list" },
            "/emailsmtp/add": { pagename: { web: "emailsmtp" }, action: "add" },
            "/emailsmtp/update": { pagename: { web: "emailsmtp" }, action: "update" },
            "/emailsmtp/delete": { pagename: { web: "emailsmtp" }, action: "delete" },

            "/emailtemplate": { pagename: { web: "emailtemplate" }, action: "list" }, // new
            "/emailtemplate/add": { pagename: { web: "emailtemplate" }, action: "add" }, // new
            "/emailtemplate/update": { pagename: { web: "emailtemplate" }, action: "update" }, // new
            "/emailtemplate/delete": { pagename: { web: "emailtemplate" }, action: "delete" }, // new


            // -----------------------------------------------------

        }

        this.duplicatepunchtime = 100000 //in milliseconds

     
        // Cron Jobs
        this.cronjobs = {
            complaintsolve:"complaintsolve",
            complaintaccept:"complaintaccept",
        }

        // Queue Jobs
        this.queuejobs = {
            emails: "Emails"
        }

    }
}


export default FieldConfig
