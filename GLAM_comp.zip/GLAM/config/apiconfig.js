import { Config, MainDB, IISMethods, FieldConfig } from "../config/Init.js"
// import _Users from "../model/Users.js"
import _DBConfig from "./DBConfig.js"

import ApiLog from "../model/ApiLog.js"


export var RequestHeaders
export var ResponseHeaders = {}
export var IpAddress
export var URL

// Set Request Header Params
export async function setReqHeaderParams(req, res, next) {
    try {
        // Decrypt Data
        if (Config.dataencryptionenable) {
            req.headers.skipencryption = true

            if (req.headers.reqheader) {
                req.headers.skipencryption = false

                const headerData = req.headers.reqheader.split(".")[0]
                const tmpKey = req.headers.reqheader.split(".")[1]

                const headerKeys = IISMethods.decryptData(headerData, tmpKey)
                req.headers = { ...req.headers, ...headerKeys }

                delete req.headers.reqheader
            }

            if (req.body.reqbody) {
                req.headers.skipencryption = false

                const bodyData = req.body.reqbody.split(".")[0]
                const tmpKey = req.body.reqbody.split(".")[1]

                const bodyKeys = IISMethods.decryptData(bodyData, tmpKey)
                req.body = { ...req.body, ...bodyKeys }

                delete req.body.reqbody
            }
        }

        // Validate Request Body
        if (!IISMethods.validateRequestBody(req) && !["propertyidealscreen"].includes(req.headers.pagename)) {
            let ResponseBody = { status: 406, message: Config.getResponsestatuscode()["406"] }

            if (Config.dataencryptionenable && !req.headers.skipencryption) {
                const respJSON = JSON.stringify(ResponseBody)
                ResponseBody = IISMethods.encryptData(respJSON)
            }

            return res.status(406).send(ResponseBody)
        }


        // Add System Date and Timezone
        req.headers.domainname = FieldConfig.domainname
        req.headers.systemdate = IISMethods.getSystemDate({ date: req.headers.systemdate })
        req.headers.timezone = req.headers.timezone !== "" && req.headers.timezone ? req.headers.timezone : FieldConfig.timezone

        // Global Variable
        RequestHeaders = req.headers
        IpAddress = req.headers["x-forwarded-for"] || req.headers["public-ip"] || req.connection.remoteAddress || req.body["public-ip"]

        req.headers.ipaddress = IpAddress

        URL = req.url

        // Add Property ID and Name
        if (
            !req.body?.propertyid &&
            !req.body?.propertyname &&
            req.headers.pagename !== "property" &&
            req.headers.propertyid &&
            req.headers.propertyname &&
            req.headers.useraction[0] !== "u"
        ) {
            req.body.propertyid = req.headers.propertyid
            req.body.propertyname = req.headers.propertyname
        }

        const RequestBody = req.body

        // Add Record Info
        if (URL.includes("/add")) {
            req.body.recordinfo = {
                entryuid: req.headers.uid,
                entryby: req.headers.personname,
                entrydate: IISMethods.getdatetimeisostr(),
                timestamp: IISMethods.GetTimestamp(),
                isactive: 1
            }
        }

        let breakreq = false
        await MainDB.puthistory(RequestBody, req.headers, IpAddress, URL)

        if (breakreq === false) {
            next()
        } else {
            let ResponseHeaders = {}
            let ResponseBody = {}

            if (Config.dataencryptionenable && !req.headers.skipencryption) {
                const respJSON = JSON.stringify(ResponseBody)
                ResponseBody = IISMethods.encryptData(respJSON)

                const respHeaderJSON = JSON.stringify(ResponseHeaders)

                ResponseHeaders = {}
                ResponseHeaders.resheader = IISMethods.encryptData(respHeaderJSON)
            }

            res.set(ResponseHeaders)
            res.status(400).send(ResponseBody)
        }
    } catch (err) {
        console.log(err)

        let ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"] }

        if (Config.dataencryptionenable && !req.headers.skipencryption) {
            const respJSON = JSON.stringify(ResponseBody)
            ResponseBody = IISMethods.encryptData(respJSON)
        }

        res.status(500).send(ResponseBody)
    }
}

// Auth Middleware
export function AuthMiddleware(action = "", skiprights = false, skipdomain = false, checkreportto = false, checkapproveto = false) {
    return async function (req, res, next) {
        try {
            const apiLogObj = {
                url: req.url,
                headers: req.headers,
                payload: req.body,
                datestr: new Date()
            }
            await MainDB.executedata("i", new ApiLog(), "tblapilog", apiLogObj, false)

            if (req.headers.token) {
                // Validate user
                let userauth = {}

                if (action) {
                    userauth = await MainDB.authenticateuser(req.headers.token, req.headers.domainname, req.headers.uid, req.headers.unqkey, req.headers.issuer, req.headers["user-agent"], req.headers.host, req.headers.platform, req.headers.pagename, req.headers.useraction, req.headers.propertyid, req.headers.userroleid, req.headers.masterlisting, req.headers.action, Config.getOtherformdataaction(), action)
                } else if (req.headers.domainname && req.headers.domainname != undefined) {
                    userauth = await MainDB.authenticateuser(req.headers.token, req.headers.domainname, req.headers.uid, req.headers.unqkey, req.headers.issuer, req.headers["user-agent"], req.headers.host, req.headers.platform, req.headers.pagename, req.headers.useraction, req.headers.propertyid, req.headers.userroleid, req.headers.masterlisting, req.headers.action, Config.getOtherformdataaction(), action)
                } else {
                    userauth.status = 401
                    userauth.message = Config.getResponsestatuscode()["401"]
                }


                // If Token expire then set new token
                if (userauth.key && userauth.unqkey) {
                    const ResponseHeaders = {
                        key: userauth.key,
                        unqkey: userauth.unqkey
                    }

                    req.ResponseHeaders = ResponseHeaders
                }

                // If user valid next
                if (userauth.status === 200 || (skiprights && userauth.status === 401)) {
                    req.userauth = userauth

                    return next()
                } else {
                    let ResponseHeaders = req.ResponseHeaders || {}
                    let ResponseBody = { status: userauth.status, message: userauth.message }

                    if (Config.dataencryptionenable && !req.headers.skipencryption) {
                        const respJSON = JSON.stringify(ResponseBody)
                        ResponseBody = IISMethods.encryptData(respJSON)
                    }

                    if (Config.dataencryptionenable && !req.headers.skipencryption) {
                        const respHeaderJSON = JSON.stringify(ResponseHeaders)

                        ResponseHeaders = {}
                        ResponseHeaders.resheader = IISMethods.encryptData(respHeaderJSON)
                    }

                    res.set(ResponseHeaders)
                    res.status(userauth.status).send(ResponseBody)
                }
            } else {
                let ResponseBody = { status: 401, message: Config.getResponsestatuscode()["401"] }

                if (Config.dataencryptionenable && !req.headers.skipencryption) {
                    const respJSON = JSON.stringify(ResponseBody)
                    ResponseBody = IISMethods.encryptData(respJSON)
                }

                res.status(401).send(ResponseBody)
            }

        } catch (err) {
            console.log(err)
        }
    }
}

// Send Response
export function sendResponse(req, res, next) {
    let ResponseHeaders = req.ResponseHeaders || {}
    let ResponseBody = req.ResponseBody

    let status = ResponseBody["status"]

    if (status === 500 && Config.logerror) {
        status = 400

        console.log(ResponseBody.err)

        if (ResponseBody.err) {
            console.log("error comming")
            MainDB.addErrLog({ req, data: ResponseBody.err, url: req.url })
        }

        delete ResponseBody.err
    }

    if (Config.dataencryptionenable && !req.headers.skipencryption) {
        const respJSON = JSON.stringify(ResponseBody)
        ResponseBody = IISMethods.encryptData(respJSON)

        const respHeaderJSON = JSON.stringify(ResponseHeaders)

        ResponseHeaders = {}
        ResponseHeaders.resheader = IISMethods.encryptData(respHeaderJSON)
    }

    ResponseHeaders["x-frame-options"] = "DENY"
    ResponseHeaders["referrer-policy"] = "strict-origin"
    ResponseHeaders["x-content-type-options"] = "nosniff"
    ResponseHeaders["strict-transport-security"] = "max-age=31536000; preload"
    ResponseHeaders["x-xss-protection"] = "1; mode=block"

    res.set(ResponseHeaders)
    res.status(status).send(ResponseBody)
}
