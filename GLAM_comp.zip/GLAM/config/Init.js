import _Config from "./Config.js"
import _FieldConfig from "./FieldConfig.js"
import _DBConfig from "./DBConfig.js"
import _IISMethods from "./IISMethods.js"
import _RecordInfo from "./RecordInfo.js"
import _FieldOrder from "./FieldOrder.js"
import _PaginationInfo from "./PaginationInfo.js"
import _IISAutomationMethods from '../config/IISAutomationMethods.js';

// import {redisConnect} from './Redis.js'
//  await redisConnect()

export var Config = new _Config()
export var MainDB = new _DBConfig(true)
export var IISMethods = new _IISMethods()
export var FieldConfig = new _FieldConfig()
export var RecordInfo = new _RecordInfo()
export var FieldOrder = new _FieldOrder()
export var PaginationInfo = new _PaginationInfo()
export var IISAutoTest = new _IISAutomationMethods()
