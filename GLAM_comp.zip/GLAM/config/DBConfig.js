import _Config from "./Config.js"
import DB from './DB.js'
var Config = new _Config()


class DBConfig extends DB
{
    constructor(connect)
    {
        super();
        if(connect){

            var DBType = Config.getDBType()
            var DBName = Config.getDBName()
            var DBUser = Config.getDBUser()
            var DBHost = Config.getDBHost()
            var DBPass = Config.getDBPass()
            var DBPort = Config.getDBPort()

            //Main Database connection
            this.setDBType(DBType);
            this.setDBName(DBName);
            this.setDBUser(DBUser);
            this.setDBHost(DBHost);
            this.setDBPass(DBPass);
            this.setDBPort(DBPort);
            this.Connect(connect)
            
        }
    }
}


export default DBConfig