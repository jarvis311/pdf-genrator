class Userrights
{

    constructor(){
        var formname
        var formnametext
        var viewright
        var allviewright
        var selfviewright
        var addright
        var alladdright
        var selfaddright
        var editright
        var alleditright
        var selfeditright
        var delright
        var alldelright
        var selfdelright
        var printright
        var allprintright
        var selfprintright
        var requestright
        var changepriceright
    }

    getFormname(){
		return this.formname
	}

	setFormname(formname){
		this.formname = formname
	}

	getFormnametext(){
		return this.formnametext
	}

	setFormnametext(formnametext){
		this.formnametext = formnametext
	}
	
	getViewright(){
		return this.viewright
	}

	setViewright(viewright){
		this.viewright = viewright
	}

	getAllviewright(){
		return this.allviewright
	}

	setAllviewright(allviewright){
		this.allviewright = allviewright
	}

	getSelfviewright(){
		return this.selfviewright
	}

	setSelfviewright(selfviewright){
		this.selfviewright = selfviewright
	}

	getAddright(){
		return this.addright
	}

	setAddright(addright){
		this.addright = addright
	}

	getAlladdright(){
		return this.alladdright
	}

	setAlladdright(alladdright){
		this.alladdright = alladdright
	}

	getSelfaddright(){
		return this.selfaddright
	}

	setSelfaddright(selfaddright){
		this.selfaddright = selfaddright
	}

	getEditright(){
		return this.editright
	}

	setEditright(editright){
		this.editright = editright
	}

	getAlleditright(){
		return this.alleditright
	}

	setAlleditright(alleditright){
		this.alleditright = alleditright
	}

	getSelfeditright(){
		return this.selfeditright
	}

	setSelfeditright(selfeditright){
		this.selfeditright = selfeditright
	}

	getDelright(){
		return this.delright
	}

	setDelright(delright){
		this.delright = delright
	}

	getAlldelright(){
		return this.alldelright
	}

	setAlldelright(alldelright){
		this.alldelright = alldelright
	}

	getSelfdelright(){
		return this.selfdelright
	}

	setSelfdelright(selfdelright){
		this.selfdelright = selfdelright
	}

	getPrintright(){
		return this.printright
	}

	setPrintright(printright){
		this.printright = printright
	}

	getAllprintright(){
		return this.allprintright
	}

	setAllprintright(allprintright){
		this.allprintright = allprintright
	}

	getSelfprintright(){
		return this.selfprintright
	}

	setSelfprintright(selfprintright){
		this.selfprintright = selfprintright
	}

	getRequestright(){
		return this.requestright
	}

	setRequestright(requestright){
		this.requestright = requestright
	}

	getChangepriceright(){
		return this.changepriceright
	}

	setChangepriceright(changepriceright){
		this.changepriceright = changepriceright
	}
}

export default Userrights