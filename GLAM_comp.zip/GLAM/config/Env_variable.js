import { SecretsManagerClient, GetSecretValueCommand } from "@aws-sdk/client-secrets-manager"

const getSecrets = async () => {
    try {
        const secret_name = "elastic-beanstalk-secret"

        const client = new SecretsManagerClient({
            region: "us-east-1"
        })

        const response = await client.send(
            new GetSecretValueCommand({
                SecretId: secret_name,
                VersionStage: "AWSCURRENT" // VersionStage defaults to AWSCURRENT if unspecified
            })
        )

        const secretObj = JSON.parse(response.SecretString)

        if (Object.keys(secretObj).length) {
            process.env.NODE_ENV = secretObj.NODE_ENV

            process.env.TOKEN_KEY = secretObj.TOKEN_KEY

            process.env.ENCRYPTION_KEY = secretObj.ENCRYPTION_KEY

            process.env.MONGODB_PROJECT_ID = secretObj.MONGODB_PROJECT_ID
            process.env.MONGODB_PUBLIC_KEY = secretObj.MONGODB_PUBLIC_KEY
            process.env.MONGODB_PRIVATE_KEY = secretObj.MONGODB_PRIVATE_KEY

            process.env.MONGODB_DBNAME = secretObj.MONGODB_DBNAME
            process.env.MONGODB_HOST = secretObj.MONGODB_HOST
            process.env.MONGODB_PORT = secretObj.MONGODB_PORT
            process.env.MONGODB_USER = secretObj.MONGODB_USER
            process.env.MONGODB_PASS = secretObj.MONGODB_PASS

            process.env.EMAIL_HOST = secretObj.EMAIL_HOST
            process.env.EMAIL_FROM = secretObj.EMAIL_FROM
            process.env.EMAIL_USER = secretObj.EMAIL_USER
            process.env.EMAIL_PASS = secretObj.EMAIL_PASS

            process.env.REDIS_HOST = secretObj.REDIS_HOST
            process.env.REDIS_PORT = secretObj.REDIS_PORT
            process.env.REDIS_PASS = secretObj.REDIS_PASS

            process.env.MASTER_PASSWORD_ALIAS = secretObj.MASTER_PASSWORD_ALIAS
        }
    } catch (err) {
        console.log(err)
    }
}

export default getSecrets
