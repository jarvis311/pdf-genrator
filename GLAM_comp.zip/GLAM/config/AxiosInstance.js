import axios from 'axios'
import { IISMethods, MainDB } from './Init.js';
import _ZohoApiHistory from '../model/Zoho/ZohoApiHistory.js'

const instance = axios.create()

instance.interceptors.request.use(function (config) {
    config.metadata = { startTime: new Date() }
    return config;
}, function (error) {
    return Promise.reject(error);
});

instance.interceptors.response.use(async function (response) {
    response.config.metadata.endTime = new Date();
    response.duration = response.config.metadata.endTime.getTime() - response.config.metadata.startTime.getTime();
    response.subdomain = response.config.extradata.subdomain ?? "";
    console.log("🚀 ~ file: AxiosInstance.js:15 ~ response:", response.config)


    const history = {
        req_url: response.config.url,
        req_params: IISMethods.Jsontostring(response.config.params) ?? '',
        req_body: response.config.data ?? '',
        req_time: response.config.metadata.startTime,
        req_for: response.config.extradata.req_for,
        req_operation: response.config.extradata.req_operation,
        subdomain: response.subdomain ?? "",
        res_status: response.status,
        res_body: IISMethods.Jsontostring(response.data),
        res_time: new Date(),
        execution_time: response.duration,
    }
    console.log("🚀 ~ file: AxiosInstance.js:28 ~ history:", history)

    console.log("🚀 ~ file: AxiosInstance.js:36 ~ response.subdomain:", response.subdomain)
    if (response.subdomain) {
        const resp = await MainDB.executedata("i", new _ZohoApiHistory(), "tblzohoapihistory", history)
    }

    return response;

}, async function (error) {
    error.config.metadata.endTime = new Date();
    error.duration = error.config.metadata.endTime.getTime() - error.config.metadata.startTime.getTime();

    const history = {
        req_url: response.config.url,
        req_params: IISMethods.Jsontostring(response.config.params) ?? '',
        req_body: response.config.data ?? '',
        req_time: response.config.metadata.startTime,
        req_for: response.config.extradata.req_for,
        req_operation: response.config.extradata.req_operation,
        subdomain: response.subdomain ?? "",
        res_status: response.status,
        res_body: IISMethods.Jsontostring(response.data),
        res_time: new Date(),
        execution_time: response.duration,
    }
    console.log("🚀 ~ file: AxiosInstance.js:28 ~ history:", history)

    console.log("🚀 ~ file: AxiosInstance.js:36 ~ response.subdomain:", response.subdomain)
    if (response.subdomain) {
        const resp = await MainDB.executedata("i", new _ZohoApiHistory(), "tblzohoapihistory", history)
    }
    return Promise.reject(error);
});



export default instance;