import chai from 'chai';
import chaiHttp from 'chai-http';
import { Config } from './Init.js'


chai.use(chaiHttp)
chai.config.includeStack = <true></true>
const { should } = chai
should()

class IISAutomationMethods {
    constructor() {
        this.token
        this.uid
        this.unqkey
        this.propertyid
        this.userroleid
        this.issuer
        this.host
        this.platform
        this.username
        this.useragent
    }

    //sorting data
    validateSorting(data, sortField, sortOrder) {
        const sortedData = data.map(item => item[sortField].toLowerCase());

        for (let i = 0; i < sortedData.length - 1; i++) {
            if (sortOrder === 'ascending') {
                sortedData[i].should.be.at.most(sortedData[i + 1], `Value "${sortedData[i]}" should come before "${sortedData[i + 1]}" in ascending order`);
            } else if (sortOrder === 'descending') {
                sortedData[i].should.be.at.least(sortedData[i + 1], `Value "${sortedData[i]}" should come after "${sortedData[i + 1]}" in descending order`);
            } else {
                throw new Error(`Unknown sort order: ${sortOrder}`);
            }
        }
    }

    //common function for testcase implementation
    performRequest({
        method,
        endpoint,
        body = {},
        queryParams = {},
        timeout = { response: 10000, deadline: 50000 },
        expectedStatus = 200,
        headers = {},
        expectedHeaders = [],
        expectedResponse = (res) => { res.should.be.a('object'); res.body.should.be.a('object') },
        description
    }) {
        const self = this; // Capture the class instance

        it(`${headers.pagename} ${description}`, function (done) {
            const request = chai.request.execute(Config.getBaseurl())[method](endpoint);

            if (method === 'post' || method === 'delete') {
                request.send(body);
            }
            //add query parameters
            if (Object.keys(queryParams).length) {
                request.query(queryParams);
            }

            if (Object.keys(timeout).length) {
                request.timeout(timeout);
            }

            //set header parameters
            if (Object.keys(headers).length) {
                const validHeaders = {};

                if (endpoint !== "/getaccesstoken") {
                    validHeaders.token = self.token;
                    validHeaders.uid = self.uid;
                    validHeaders.unqkey = self.unqkey;
                }

                if (endpoint !== '/employee/login' && self.host && self.issuer) {
                    validHeaders.propertyid = self.propertyid
                    validHeaders.userroleid = self.userroleid
                    validHeaders.issuer = self.issuer
                    validHeaders.host = self.host
                    validHeaders.platform = self.platform
                    validHeaders.username = self.username
                    validHeaders["user-agent"] = self.useragent
                }

                Object.entries(headers).forEach(([key, value]) => {
                    if (value === undefined) {
                        throw new Error(`Undefined value for header "${key}"`);
                    } else {
                        validHeaders[key] = value;
                    }
                });

                request.set(validHeaders);
            }

            request.end(function (err, res) {
                if (err) {
                    return done(err);
                }

                try {
                    res.should.have.status(expectedStatus);

                    if (expectedHeaders.length) {
                        expectedHeaders.forEach(header => {
                            res.should.have.header(header);
                        });
                    }

                    expectedResponse(res);    //expected Response pass function
                    done();
                } catch (e) {
                    done(e);
                }
            });
        });
    }



    CommonTestcase({ endpoint = {}, reqbody = {}, reqheader = {}, isdelete = 1}) {

        const data = [
            {
                method: 'post', endpoint: endpoint.list, body: Config.requestBody, description: 'should return a 200 status and a response with data property on a valid POST request', headers: reqheader.list,
                expectedResponse: (res) => {
                    res.should.be.a('object')
                    res.body.should.have.property('data')
                }
            },
            {
                method: 'post', endpoint: endpoint.list, body: Config.invalidRequestBody, expectedStatus: 400, description: 'should return a 400 error for missing or invalid parameters in the request', headers: reqheader.list,
                expectedResponse: (res) => {
                    res.should.be.a('object')
                }
            },
            {
                method: 'post', endpoint: endpoint.list, body: Config.slowRequestBody, timeout: { response: 3000, deadline: 5000 }, description: 'should gracefully handle request timeouts', headers: reqheader.list,
                expectedResponse: (res) => {
                    res.should.have.status(200)
                    res.should.be.a('object')
                }
            },
            // {
            //     method: 'post', endpoint: endpoint.list, body: Config.requestBody, description: 'should validate header parameters and return a 200 status', expectedStatus: 200, expectedHeaders: ['unqkey', 'userroleid', 'uid', 'token', 'issuer', 'propertyid'], headers: reqheader.list,
            //     expectedResponse: (res) => {
            //         res.should.be.a('object')
            //     }
            // },
            {
                method: 'post', endpoint: endpoint.add, body: reqbody.add, expectedStatus: 200, description: 'should successfully create a new resource', headers: reqheader.add,
                expectedResponse: (res) => {
                    res.body.should.have.property('message').that.equals(`${endpoint.dataname} inserted successfully.`)
                }
            },
            {
                method: 'post', endpoint: endpoint.list, body: reqbody.sort, description: 'should sort the results based on the specified field and order', headers: reqheader.list,
                expectedResponse: (res) => {
                    res.should.have.status(200)
                    const data = res.body.data
                    const sortField = Object.keys(reqbody.sort.paginationinfo.sort)[0]
                    const sortOrder = reqbody.sort.paginationinfo.sort[sortField]

                    if (sortOrder === 1) {
                        this.validateSorting(data, sortField, "ascending")
                    } else if (sortOrder === -1) {
                        this.validateSorting(data, sortField, "descending")
                    }
                }
            },
            {
                method: 'post', endpoint: endpoint.list, body: reqbody.filter, description: 'should filter results based on the provided criteria', headers: reqheader.list,
                expectedResponse: (res) => {
                    res.should.have.status(200);
                    res.body.should.have.property('data')
                    res.body.data.should.be.an('array').that.is.not.empty

                    res.body.data.forEach((item) => {
                        const filters = reqbody.filter.paginationinfo.filter
                        Object.keys(filters).forEach((filterField) => {
                            if (filters[filterField].includes(item[filterField])) {
                                item.should.have.property(filterField).that.equals(item[filterField])
                            } else {
                                throw new Error(`Item with ${filterField}: ${item[filterField]} does not match filter criteria.`)
                            }
                        });
                    });
                }
            },
            {
                method: 'post', endpoint: endpoint.list, body: reqbody.sort, description: 'should return only the fields specified in the projection', headers: reqheader.list,
                expectedResponse: (res) => {
                    res.should.have.status(200);
                    res.body.should.have.property('data')
                    res.body.data.should.be.an('array').that.is.not.empty

                    const projectionFields = Object.keys(reqbody.sort.paginationinfo.projection)
                    if (!('_id' in reqbody.sort.paginationinfo.projection)) {
                        projectionFields.push('_id');
                    }

                    res.body.data.forEach((item) => {
                        Object.keys(item).forEach((field) => {
                            projectionFields.should.include(field)
                        });
                        Object.keys(item).length.should.be.eql(projectionFields.length)
                    });
                }
            },
            {
                method: 'post', endpoint: endpoint.list, body: Config.requestBody, description: 'should respond within acceptable time limits', headers: reqheader.list,
                expectedResponse: (res) => {
                    const acceptableResponseTime = 2000
                    const start = performance.now()
                    const end = performance.now()
                    const responseTime = end - start

                    res.should.have.status(200);
                    res.body.should.be.a('object');
                    responseTime.should.be.below(acceptableResponseTime)
                    console.log(`Response time: ${responseTime} ms`)
                }
            },
            {
                method: 'post', endpoint: endpoint.list, body: reqbody.search, description: 'should return documents matching the search text', headers: reqheader.list,
                expectedResponse: (res) => {
                    res.should.have.status(200)
                    res.body.should.have.property('data')
                    res.body.data.should.be.an('array').that.is.not.empty

                    const searchText = reqbody.search.searchtext.toLowerCase()
                    res.body.data.forEach((item) => {
                        let found = false;
                        Object.keys(item).forEach((key) => {
                            const value = item[key]
                            if (typeof value === 'string' && value.toLowerCase().includes(searchText)) {
                                found = true
                            }
                        });
                        found.should.be.true
                    });
                }
            },
            {
                method: 'post', endpoint: endpoint.list, body: reqbody.filter, expectedStatus: 200, description: 'should confirm that data was added to the database', headers: reqheader.list,
                expectedResponse: (res) => {
                    res.should.have.status(200);
                    res.body.should.have.property('data')
                    res.body.data.should.be.an('array').that.is.not.empty

                    res.body.data.forEach((item) => {
                        const filters = reqbody.filter.paginationinfo.filter
                        Object.keys(filters).forEach((filterField) => {
                            if (filters[filterField].includes(item[filterField])) {
                                item.should.have.property(filterField).that.equals(item[filterField])
                            } else {
                                throw new Error(`Data was not inserted in the database.`)
                            }
                        });
                    });
                }
            },
            {
                method: 'post', endpoint: endpoint.add, body: reqbody.add, expectedStatus: 409, description: 'should return a conflict error for duplicate data insertion', headers: reqheader.add,
                expectedResponse: (res) => {
                    res.body.should.have.property('message').that.equals('Data already exist.')
                }
            },
            {
                method: 'post', endpoint: endpoint.update, body: reqbody.update, expectedStatus: 200, description: 'should update the resource and verify that the _id exists in the response', headers: reqheader.update,
                expectedResponse: (res) => {
                    res.should.have.status(200);
                    res.body.should.be.a('object');
                    res.body.should.have.property('message').that.equals(`${endpoint.dataname} updated successfully.`)
                }
            },
            {
                method: 'post', endpoint: endpoint.update, body: reqbody.update, expectedStatus: 200, description: 'should handle conflicts during resource update when conflicting data exists', headers: reqheader.update,
                expectedResponse: (res) => {
                    res.should.have.status(200);
                    res.body.should.be.a('object')
                }
            }   
        ]

        if(isdelete == 1){
            data.push({
                method: 'delete', endpoint: endpoint.delete, body: reqbody.delete, expectedStatus: 200, description: 'should delete the resource and return a success message', headers: reqheader.delete,
                expectedResponse: (res) => {
                    res.body.should.be.a('object')
                    res.body.should.have.property('message').that.equals(`${endpoint.dataname} deleted successfully.`)
                }
            })
        }
        return data
    }


    async updateAndCheckDependencies(resourceName, updateEndpoint, reqBody, reqHeader) {
        // Perform the update request
        const self = this; 
        it(`should update ${resourceName} and all dependencies dynamically`, async function () {
            self.IISAutoTest.performRequest({
            method: 'post',
            endpoint: updateEndpoint,
            body: reqBody.update,
            expectedStatus: 200,
            description: `should update ${resourceName} resource successfully`,
            headers: reqHeader.update,
            expectedResponse: async (res) => {
              res.body.should.have.property('message').that.equals('Data updated successfully.');
              res.should.have.status(200);
            }
          });
      
          // Check each dependency dynamically
          for (const dep of reqBody.dependancy) {
            it(`should validate ${dep.endpoint.list} and all dependencies for ${resourceName} dynamically`, async function () {
            self.IISAutoTest.performRequest({
                method: 'post',
                endpoint: dep.endpoint.list,
                body: dep.filter,
                expectedStatus: 200,
                description: `${resourceName} dependencies check`,
                headers: reqHeader.list,
                expectedResponse: async (res1) => {
                  res1.should.have.status(200);
                  const records = res1.body.data;
      
                  for (const matchKey of dep.match) {
                    const matchValue = reqBody.update[matchKey];
                    const matchExists = records.some(record => record[matchKey] === matchValue);
                    matchExists.should.be.true;
                  }
                }
              });
            });
          }
        });
      }


    async deleteAndCheckDependencies(resourceName, deleteEndpoint, reqBody, reqHeader) {
        // Perform the update request
        const self = this; 
        it(`should update ${resourceName} and all dependencies dynamically`, async function () {
          self.IISAutoTest.performRequest({
            method: 'post',
            endpoint: deleteEndpoint,
            body: reqBody.delete,
            expectedStatus: 200,
            description: `should delete ${resourceName} resource successfully`,
            headers: reqHeader.delete,
            expectedResponse: async (res) => {
              res.body.should.have.property('message').that.equals('Data deleted successfully.');
              res.should.have.status(200);
            }
          });
      
          // Check each dependency dynamically
          for (const dep of reqBody.dependancy) {
            it(`should validate ${dep.endpoint.list} and all dependencies for ${resourceName} dynamically`, async function () {
             self.IISAutoTest.performRequest({
                method: 'post',
                endpoint: dep.endpoint.list,
                body: dep.filter,
                expectedStatus: 200,
                description: `${resourceName} dependencies check`,
                headers: reqHeader.list,
                expectedResponse: async (res1) => {
                  res1.should.have.status(200);
                  const records = res1.body.data;
      
                  for (const matchKey of dep.match) {
                    const matchValue = reqBody.update[matchKey]
                    const matchExists = records.some(record => record[matchKey] === matchValue);
                    matchExists.should.be.true
                  }
                }
              });
            });
          }
        });
      }

     
    //employee login
    async EmployeeAuthTestcase() {
        const self = this; // Capture the class instance
        const data = [
            {
                method: 'get',
                endpoint: "/healthcheck",
                body: {},
                description: 'should return status 200 on healthcheck',
                expectedResponse: (res) => {
                    res.should.have.status(200);
                    res.body.should.be.a('object');
                }
            },
            {
                method: 'post',
                endpoint: "/getaccesstoken",
                body: { "paginationinfo": { "pageno": 1, "pagelimit": 10, "filter": {}, "sort": {} } },
                description: 'get unqkey and uid for login',
                headers: {
                    "key": process.env.TOKEN_KEY,
                    "issuer": Config.testissuer,
                    "user-agent": "testing",
                    "host": Config.testhost
                },
                expectedResponse: (res) => {
                    self.token = res.headers.token;
                    self.unqkey = res.body.data.unqkey;
                    self.uid = res.body.data.uid;
                    res.body.should.have.property('data');
                }
            },
            {
                method: 'post',
                endpoint: "/employee/login",
                body: { "email": "admin", "password": "a" },
                description: 'Successfully Login',
                headers: async () => ({
                    "issuer": "website",
                    "user-agent": "testing",
                    "host": "192.168.1.35",
                    "platform": 1,
                    "useraction": 'login',
                    "pagename": "/",
                    "moduletype": 'web',
                    "apptype": 1
                }),
                expectedResponse: (res) => {
                    const authbody = res.body.data;
                    self.token = res.headers.token;
                    self.uid = authbody._id;
                    self.unqkey = res.headers.unqkey;
                    self.propertyid = authbody.property[0].propertyid;
                    self.userroleid = authbody.userrole[0].userroleid;
                    self.issuer = Config.testissuer;
                    self.host = Config.testhost;
                    self.platform = 1;
                    self.useragent = "testing";
                    self.username = authbody.personname;
                }
            }
        ];


        for (const testCase of data) {
            if (typeof testCase.headers === 'function') {
                testCase.headers = await testCase.headers();
            }
            await self.performRequest(testCase);
        }
    }


    //gatekeeper login
    async GatekeeperAuthTestcase() {
        const self = this // Capture the class instance
        const data = [
            {
                method: 'get',
                endpoint: "/healthcheck",
                body: {},
                description: 'should return status 200 on healthcheck',
                expectedResponse: (res) => {
                    res.should.have.status(200);
                    res.body.should.be.a('object');
                }
            },
            {
                method: 'post',
                endpoint: "/getaccesstoken",
                body: { "paginationinfo": { "pageno": 1, "pagelimit": 10, "filter": {}, "sort": {} } },
                description: 'get unqkey and uid for login',
                headers: {
                    "key": process.env.TOKEN_KEY,
                    "issuer": Config.testissuer,
                    "user-agent": "testing",
                    "host": Config.testhost
                },
                expectedResponse: (res) => {
                    self.token = res.headers.token;
                    self.unqkey = res.body.data.unqkey;
                    self.uid = res.body.data.uid;
                    res.body.should.have.property('data');
                }
            },
            {
                method: 'post',
                endpoint: "/gatekeeper/login",
                body: { "email": "admin", "password": "a" },
                description: 'Successfully Login',
                headers: async () => ({
                    "issuer": "website",
                    "user-agent": "testing",
                    "host": "192.168.1.35",
                    "platform": 1,
                    "useraction": 'login',
                    "pagename": "/",
                    "moduletype": 'web',
                    "apptype": 1
                }),
                expectedResponse: (res) => {
                    const authbody = res.body.data;
                    self.token = res.headers.token;
                    self.uid = authbody._id;
                    self.unqkey = res.headers.unqkey;
                    self.propertyid = authbody.property[0].propertyid;
                    self.userroleid = authbody.userrole[0].userroleid;
                    self.issuer = Config.testissuer;
                    self.host = Config.testhost;
                    self.platform = 1;
                    self.useragent = "testing";
                    self.username = authbody.personname;
                }
            }
        ];


        for (const testCase of data) {
            if (typeof testCase.headers === 'function') {
                testCase.headers = await testCase.headers();
            }
            await self.performRequest(testCase);
        }
    }

    //customer login
    async CustomerAuthTestcase() {
        const self = this; // Capture the class instance
        const data = [
            {
                method: 'get',
                endpoint: "/healthcheck",
                body: {},
                description: 'should return status 200 on healthcheck',
                expectedResponse: (res) => {
                    res.should.have.status(200);
                    res.body.should.be.a('object');
                }
            },
            {
                method: 'post',
                endpoint: "/getaccesstoken",
                body: { "paginationinfo": { "pageno": 1, "pagelimit": 10, "filter": {}, "sort": {} } },
                description: 'get unqkey and uid for login',
                headers: {
                    "key": process.env.TOKEN_KEY,
                    "issuer": Config.testissuer,
                    "user-agent": "testing",
                    "host": Config.testhost
                },
                expectedResponse: (res) => {
                    self.token = res.headers.token;
                    self.unqkey = res.body.data.unqkey;
                    self.uid = res.body.data.uid;
                    res.body.should.have.property('data');
                }
            },
            {
                method: 'post',
                endpoint: "/customer/login",
                body: { "email": "admin", "password": "a" },
                description: 'Successfully Login',
                headers: async () => ({
                    "issuer": "website",
                    "user-agent": "testing",
                    "host": "192.168.1.35",
                    "platform": 1,
                    "useraction": 'login',
                    "pagename": "/",
                    "moduletype": 'web',
                    "apptype": 1
                }),
                expectedResponse: (res) => {
                    const authbody = res.body.data;
                    self.token = res.headers.token;
                    self.uid = authbody._id;
                    self.unqkey = res.headers.unqkey;
                    self.propertyid = authbody.property[0].propertyid;
                    self.userroleid = authbody.userrole[0].userroleid;
                    self.issuer = Config.testissuer;
                    self.host = Config.testhost;
                    self.platform = 1;
                    self.useragent = "testing";
                    self.username = authbody.personname;
                }
            }
        ];


        for (const testCase of data) {
            if (typeof testCase.headers === 'function') {
                testCase.headers = await testCase.headers();
            }
            await self.performRequest(testCase);
        }
    }
}


// let token, uid, unqkey, propertyid, userroleid, issuer, host, platform, username,useragent

// class IISAutomationMethods {

//     validateSorting(data, sortField, sortOrder) {
//         const sortedData = data.map(item => item[sortField].toLowerCase());

//         for (let i = 0; i < sortedData.length - 1; i++) {
//             if (sortOrder === 'ascending') {
//                 sortedData[i].should.be.at.most(sortedData[i + 1], `Value "${sortedData[i]}" should come before "${sortedData[i + 1]}" in ascending order`)
//             } else if (sortOrder === 'descending') {
//                 sortedData[i].should.be.at.least(sortedData[i + 1], `Value "${sortedData[i]}" should come after "${sortedData[i + 1]}" in descending order`);
//             } else {
//                 throw new Error(`Unknown sort order: ${sortOrder}`)
//             }
//         }
//     }


//     performRequest({ method, endpoint, body, queryParams = {}, timeout = { response: 10000, deadline: 50000 }, expectedStatus = 200, headers = {}, expectedHeaders = [], expectedResponse = (res) => { res.should.be.a('object'); res.body.should.be.a('object') }, description }) {
//         it(description, function (done) {
//             const request = chai.request.execute(Config.getBaseurl())[method](endpoint);

//             if (method === 'post' || method === 'delete') {
//                 request.send(body);
//             }
//             if (Object.keys(queryParams).length) {
//                 request.query(queryParams);
//             }
//             if (Object.keys(timeout).length) {
//                 request.timeout(timeout);
//             }
//             if (Object.keys(headers).length) {
//                 const validHeaders = {}

//                 if (endpoint != "/getaccesstoken") {
//                     headers.token = token
//                     headers.uid = uid
//                     headers.unqkey = unqkey
//                 }

//                 if (endpoint != '/employee/login' && host && issuer) {
//                     headers.propertyid = propertyid
//                     headers.userroleid = userroleid
//                     headers.issuer = issuer
//                     headers.host = host
//                     headers.platform = platform
//                     headers.username = username
//                     headers["user-agent"] = useragent
//                 }


//                 Object.entries(headers).forEach(([key, value]) => {
//                     if (value === undefined) {
//                         throw new Error(`Undefined value for header "${key}"`)
//                     } else {
//                         validHeaders[key] = value
//                     }
//                 })
//                 request.set(validHeaders)
//             }

//             request.end(function (err, res) {
//                 if (err) {
//                     return done(err)
//                 }

//                 try {
//                     res.should.have.status(expectedStatus)

//                     if (expectedHeaders.length) {
//                         expectedHeaders.forEach(header => {
//                             res.should.have.header(header)
//                         });
//                     }
//                     expectedResponse(res)

//                     done()
//                 } catch (e) {
//                     done(e)
//                 }
//             })
//         })
//     }


export default IISAutomationMethods