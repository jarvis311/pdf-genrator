import mongoose from "mongoose"

export default class FieldOrder {
    constructor() {
        this._id
        this.pagename = { type: String, required: true }
        this.userid = { type: String, required: true }
        this.fields = { type: Array, required: true }
        this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: "recordinfo" }
    }
}
