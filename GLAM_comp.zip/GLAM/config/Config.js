import Servermode from "./serverENV.js"

import dotenv1 from "dotenv"

if (!["uat", "production", "dev"].includes(process.env.NODE_ENV)) {
	dotenv1.config({ path: ".env" })
}

class Config {

	constructor() {
		var weburl
		var imageurl
		var hosturl
		var endpointurl
		var endpointv1
		var docurl
		var regdomain
		var mailurl
		var protocol
		var docpath
		var cdnurl
		var servermode
		var maindirpath
		var dirpath
		var page404url
		var nodatafound
		var reporturl
		var errmsg
		var htmlcontorls
		var gridclasses
		var sidebarsizeclasses
		var marginclasses
		var paddingclasses
		var modalsizeclasses
		var tblgridsizeclasses
		var FieldSize
		var statustype
		var sessionname
		var adminutype
		var updatemyprofile
		var changepassword
		var changeusertype
		var submitbutton
		var generatereport
		var defaultimageurl
		var defaultcatimageurl
		var socketurl
		var socketserver
		var otherformdataaction
		var adminUserId
		//fix db connection
		var DBType
		var DBName
		var DBUser
		var DBHost
		var DBPass
		var DBPort
		//fix db connection

		process.env.TZ = "Asia/Kolkata"
		this.subdbprefix = "glam"
		this.protocol = "http://" // http:// or https://
		this.servermode = Servermode // prod - Live | uat - test | dev = development
		this.zohoaccesstokenurl = 'https://accounts.zoho.in/oauth/v2/token'
		this.dummyObjid = "625d5ed5220ccd5a20904f79" //dummyid
		//  project lavel configuration
		this.adminutype = "628caa34c56124e5411034cc"
		this.page404url = "/views/404"
		this.teamapp = "667f8d0fbc28d961a9fdfcc3"
		this.customerapp = "667f8d27bc28d961a9fdfcc4"
		this.gatekeeperapp = "667f8d4cbc28d961a9fdfcc5"
		this.highlostpriorityid = "67455a5cb4bedc1f2d9c1b3c"
		this.highlostpriority = "High"

		this.updatemyprofile = "Update Profile"
		this.changepassword = "Change Password"
		this.changeusertype = "Change Usertype"
		this.submitbutton = "Submit"
		this.generatereport = "Generate Report"

		this.staffid = "66ac9e63ee40a69efde098eb"
		this.taxiid = "66ac9e62ee40a69efde098db"
		this.twoFAMode = "otp"

		this.baseUrl = "http://192.168.1.28:8080/V1"

		this.months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]

		this.UnAssignedStatus = "63bfce31ddbfb755cf714ec0"
		this.ReopenStatus = "65d49637584b496007027ee2"
		this.CompletedStatus = '65d49654584b4960070280b8'

		this.taskandcomplainttransferstatus = {
			notstarted: "Not Started",
			pause: "Pause",
			running: "Running",
			completed: "Completed",
		}

		//vendor staff role 
		this.ownerroleid = "673edee4a74ff3b155373251"
		this.ownerrole = "Owner"

		this.alerttype = {
			notificationid: "67050f17c3d30d868b4a0819",
			emailid: "67050f25c3d30d868b4a0820",
			whatsappid: "67050f46c3d30d868b4a082e"
		}

		// Asset Status
		this.assetstatus = {
			"Available": "64dddfff3684059ffa63c680",
			"Allocated": "64dddf943684059ffa63c67f",
			"In Repair": "64dde0473684059ffa63c683",
			"Missing": "64dde0243684059ffa63c681",
			"Retired": "64dde03c3684059ffa63c682",
			"Occupied": "64dde0523684059ffa63c684",
			"In Replace": "64e33f22dcbd5da2ffe4a1c3",
			"Broken": "66066f3bff09a9e03155e228",
			"Sold": "6745a8c0a68573c44c3ef8ad",
			"Scraped": "6745a8faa68573c44c3ef8e2"
		}

		this.seriestype = {
			"Item": "64e4588b7e217c8f76942662",
			"Asset": "64de11303684059ffa63c697"
		}

		this.testissuer = "website"
		this.testhost = "192.168.1.35"

		//support ticket statustype
		this.supportticketstatustype = {
			open: "open",
			inprogress: "inprogress",
			completed: "completed"
		}

		this.moduletype = {
			web: "621632cd6e7429b80322da0d",
			app: "65d70d4e0ea05b41bf04b6d0",
			chat: "638de7cdb2716d726ab43eca",
			desktop: "6380b987f17f5c600cb5ff9e"
		}

		this.rightstype = {
			addright: "addright",
			editright: "editright",
			delright: "delright",
			requestright: "requestright"
		}

		this.tasktype = {
			Custom: "67567d3450103e80bc2cd440",
			Monthly: "67567d4650103e80bc2cd44b",
			Weekly: "67567d5050103e80bc2cd456",
			Daily: "67567d5650103e80bc2cd461"
		}

		this.taskstatus = {
			unassigned: {
				taskstatuscolor: "#ab056e",
				taskstatusid: "63bfce31ddbfb755cf714ec0",
				taskstatus: "UnAssigned"
			},
			open: {
				taskstatuscolor: "#0dff66",
				taskstatusid: "65d49637584b496007027ee9",
				taskstatus: "Open"
			},
			complete: {
				taskstatuscolor: "#ff0d0d",
				taskstatusid: "65d49654584b4960070280b8",
				taskstatus: "Complete"
			}
		}

		this.allowedVideo = ["mov", "wmv", "avi", "mp4", "avchd", "flv", "f4v", "swf", "mkv", "webm"]


		this.actions = ["signup", "login", "forgotpassword", "resetpassword"]
		this.invalidactions = ["signup", "login", "forgotpassword", "resetpassword"]

		/**************************************** Logs Configuration ****************************************/
		this.loggroupname = "glam-app-log"
		this.logstreamname = "glam.app"
		/**************************************** Logs Configuration ****************************************/

		/**************************************** Login Configuration ****************************************/

		// OTP Expiry
		this.otpexpiredtime = 1 // In Min

		// Password Expiry Time
		this.passwordexpirytime = 365 // In Days

		// Login Valid Time
		this.invalidlogincount = 15

		// User Auth Actions
		this.userauthactions = {
			login: "login",
			resetpassword: "resetpassword",
			forgotpassword: "forgotpassword"
		}


		this.serieselement = {
			currentmonth: "623beefe278a8e4326f1adef",
			currentyear: "623bef1d278a8e4326f1adf0",
			currentfyyear: "623beeda278a8e4326f1aded",
			currentfyyeardash: "623beee7278a8e4326f1adee"
		}

		// 2FA Configuration
		this.twoFAName = "glam"
		this.twoFAMode = "otp"

		this.tokenkey = process.env.TOKEN_KEY
		/**************************************** Login Configuration ****************************************/

		// Server Configuration

		// Allowed origin
		this.allowedorigin = ["https://glam.us"]

		if (this.servermode == "dev") {
			// Development
			this.port = 8080
			this.hosturl = "localhost:3000"
			this.apiurl = "http://192.168.1.55:8080/v1"
			this.maindirpath = "/"
			this.dirpath = this.maindirpath + ""
			this.host = this.hosturl + this.dirpath
			this.weburl = this.protocol + this.host
			this.docpath = this.docroot
			this.cdnurl = this.protocol + this.host

			this.endpointv1 = "/v1"
			this.endpointurl = this.protocol + this.hosturl + this.dirpath + "api/" + this.endpointverson
			this.imageurl = this.protocol + this.hosturl + this.maindirpath + "assets/"
			this.iconurl = this.protocol + "192.168.1.18:8080" + this.maindirpath + "assets/"
			this.page404url = this.protocol + this.host + this.page404url
			this.nodatafound = this.protocol + this.host + "views/nodatafound.php"
			this.reporturl = this.protocol + this.host + "report/"

			this.socketurl = "http://192.168.2.141:3002/socket.io/socket.io.js"
			this.socketserver = "http://192.168.2.28:8084"
			this.serversocketurl = "http://192.168.2.141:3002/sendmessage/"

			// Socket Server
			this.socketserverurl = "http://192.168.1.28:8084" // Socket Server For API

			// Schedule Server
			this.scheduleserver = "192.168.1.56" // Please Don't Change This

			// Encryption
			this.dataencryptionenable = true
			this.socketencryptionenable = false
			this.logerror = true

			// Allow IP
			this.checkallowip = false

			this.DBType = "MONGODB"
			this.DBName = process.env.MONGODB_DBNAME
			this.DBHost = process.env.MONGODB_HOST
			this.DBPort = process.env.MONGODB_PORT
			this.DBUser = process.env.MONGODB_USER
			this.DBPass = process.env.MONGODB_PASS

			this.blobkey = process.env.BLOB_STORAGE_KEY
			this.container = process.env.CONTAINERNAME
		} else if (this.servermode == "prod") {
			// live
			this.port = 3002
			this.hosturl = "localhost:3000"
			this.apiurl = ""
			this.maindirpath = "/"
			this.dirpath = this.maindirpath + ""
			this.host = this.hosturl + this.dirpath
			this.weburl = this.protocol + this.host
			this.docpath = this.docroot
			this.cdnurl = this.protocol + this.host

			this.mailurl = ""
			this.endpointv1 = "/v1"
			this.endpointurl = this.protocol + this.hosturl + this.dirpath + "api/" + this.endpointverson
			this.imageurl = this.protocol + this.hosturl + this.maindirpath + "assets/"
			this.page404url = this.protocol + this.host + this.page404url
			this.nodatafound = this.protocol + this.host + "views/nodatafound.php"
			this.reporturl = this.protocol + this.host + "report/"

			this.socketurl = "http://192.168.1.18:8083/socket.io/socket.io.js"
			this.socketserver = "http://192.168.1.18:8083/"
			this.serversocketurl = ""

			// Socket Server
			this.socketserverurl = ""

			// Schedule Server
			this.scheduleserver = "" // Please Don't Change This

			// Encryption
			this.dataencryptionenable = true
			this.socketencryptionenable = true
			this.logerror = true

			// Allow IP
			this.checkallowip = false

			this.DBType = "MONGODB"
			this.DBName = process.env.MONGODB_DBNAME
			this.DBHost = process.env.MONGODB_HOST
			this.DBPort = process.env.MONGODB_PORT
			this.DBUser = process.env.MONGODB_USER
			this.DBPass = process.env.MONGODB_PASS

			this.blobkey = process.env.BLOB_STORAGE_KEY
			this.container = process.env.CONTAINERNAME
		} else if (this.servermode == "uat") {
			// test
			this.port = 8080
			this.protocol = "https://"
			this.hosturl = "localhost:3000"
			this.apiurl = "http://192.168.2.91:8080/v1"
			this.maindirpath = "/"
			this.dirpath = this.maindirpath + "" /* Directory Name */
			this.host = this.hosturl + this.dirpath
			this.weburl = this.protocol + this.host + "/"
			this.docpath = this.docroot
			this.endpointv1 = "/v1"
			this.endpointurl = this.protocol + this.hosturl + this.dirpath + "api/" + this.endpointverson
			this.imageurl = this.protocol + this.hosturl + this.maindirpath + "assets/"
			this.page404url = this.protocol + this.host + this.page404url
			this.nodatafound = this.protocol + this.host + "views/nodatafound.php"
			this.reporturl = this.protocol + this.host + "report/"
			this.serversocketurl = ""
			// Link
			this.mobilecheckinurl = this.protocol + this.regdomain
			this.guestexperienceurl = this.protocol + this.guestexpdomain
			this.formsurl = this.protocol + this.saasregdomain + ""

			// Socket Server
			this.socketserverurl = "" // Socket Server For API

			// Schedule Server
			this.scheduleserver = ""
			// Encryption
			this.dataencryptionenable = true
			this.socketencryptionenable = true
			this.logerror = true

			// Allow IP
			this.checkallowip = false

			this.DBType = "MONGODB"
			this.DBName = process.env.MONGODB_DBNAME
			this.DBHost = process.env.MONGODB_HOST
			this.DBPort = process.env.MONGODB_PORT
			this.DBUser = process.env.MONGODB_USER
			this.DBPass = process.env.MONGODB_PASS

			this.blobkey = process.env.BLOB_STORAGE_KEY
			this.container = process.env.CONTAINERNAME
		}

		this.chatstatuscolor = {
			Available: "#08c72a",
			Away: "#eec10f",
			Busy: "#d10029",
			Offline: "#949494",
			DND: "#d10029"
		}

		this.adminLogin = {
			"email": "admin",
			"password": "a"
		}

		this.appmoduleid = "621637248d1a174bd75d04e5"
		this.chatappmoduleid = "638de7cdb2716d726ab43eca"


		this.htmlcontorls = {
			video: "video",
			switch: "switch",
			status: "status",
			text: "text",
			icon: "icon",
			checkbox: "checkbox",
			dropdown: "dropdown",
			radio: "radio",
			multipleselectdropdown: "multipleselectdropdown",
			checkpicker: "checkpicker",
			lookup: "lookup",
			combobox: "combobox",
			input: "input",
			datepicker: "datepicker",
			datetimepicker: "datetimepicker",
			daterangepicker: "daterangepicker",
			timepicker: "timepicker",
			timerangepicker: "timerangepicker",
			monthpicker: "monthpicker",
			colorpicker: "colorpicker",
			rangepicker: "rangepicker",
			image: "image",
			audio: "audio",
			email: "email",
			phone: "phone",
			link: "link",
			file: "file",
			table: "table",
			color: "color",
			combinefield: "combinefield",
			action: "action",
			array: "array",
			timer: "timer",
			action_status: 'action_button',
			isactive: 'isactive',
			action_button: 'action_button',
			//new controls
			kText: 'text',
			kInputText: 'input-text',
			kLookUp: 'lookup',
			kNumberInput: 'number-input',
			kDropDown: 'dropdown',
			kMultiSelectDropDown: 'multipleselectdropdown',
			kRadio: 'radio',
			kSwitch: 'switch',
			kDocumentAdd: 'document_add',
			kStatus: 'status',
			kPriority: 'priority',
			kChat: 'chat',
			kTenantStatus: 'tenantstatus',
			kDropStatus: 'drop_status',
			kCheckBox: 'checkbox',
			kPassword: 'password',
			kInputTextArea: 'input-textarea',
			kDateRangePicker: 'daterangepicker',
			kTable: 'table',
			kTimeRangePicker: 'timerangepicker',
			kTimePicker: 'timepicker',
			kDatePicker: 'datepicker',
			kImagePicker: 'image',
			kFilePicker: 'file',
			kHtmlEditor: 'htmleditor',
			kMultipleImagePicker: 'multipleimagepicker',
			kMultipleSideImagePicker: 'multiplesideimagepicker',
			kModel: 'modal',
			kMultipleContactSelection: 'multiplecontactselection',
			kFieldGroupList: 'fieldgrouplist',
			kPrimaryField: 'primary',
			kEmptyBlock: 'empty-block',
			kMultipleTextFieldWithTitle: 'multipletextfieldwithtitle',
			kMultipleFilePickerFieldWithTitle: 'multipleFilePickerfieldwithtitle',
			kTextArray: 'text-array',
			kTableAddButton: 'table-add-button',
			kDivider: 'divider',
			kMasterForm: 'masterform',
			"number-count": "text",
			"stickydata-assign-button": "stickydata-assign-button",
			"property-setup-button": "property-setup-button",
			"product-assign-button": "product-assign-button",
			"modal-file": "modal-file",
			"modal-text": "modal-text",
			"number-count": "text",
			"stickydata-assign-button": "stickydata-assign-button",
			"html-editor": "html-editor",
			"text-array": "text-array",
			"modal-eye": "modal-eye",
			"link-redirection": "link-redirection",
			"number-input": "number-input",
			"float-number-input": "float-number-input",
			"input-text": "input-text",
			"input-textarea": "input-textarea",
			"button-action": "button-action",
			"field-group": "field-group",
			'time-range-list': 'time-range-list',
		}

		this.modalsizeclasses = {
			xs: 400,
			sm: 600,
			750: 750,
			775: 775,
			800: 800,
			md: 850,
			lg: 1000,
			xl: 1400,
			full: 1800
		}

		this.images = [
			'jpg',
			'jpeg',
			'png',
			'webp',
			// 'svg'
		]

		this.pdfExtension = [
			'pdf',
		]

		this.docExtension = [
			'doc',
			'docx',
		]

		this.excelExtension = [
			'xls',
			'xlsx',
		]



		this.FieldSize = {
			k25: 25,
			k30: 30,
			k50: 50,
			k75: 75,
			k100: 100,
			k125: 125,
			k150: 150,
			k175: 175,
			k200: 200,
			k225: 225,
			k243: 218,
			k250: 250,
			k266: 266,
			k275: 275,
			k300: 300,
			k325: 325,
			k350: 350,
			k375: 375,
			k400: 400,
			k425: 425,
			k450: 450,
			k475: 475,
			k500: 500,
			k525: 525,
			k550: 550,
			k575: 575,
			k600: 600,
			k625: 625,
			k650: 650,
			k675: 675,
			k700: 700,
			k725: 725,
			k750: 750,
			k775: 775,
			k800: 800,
			k825: 825,
			k850: 850,
			k875: 875,
			k900: 900,
			k925: 925,
			k950: 950,
			k975: 975,
			k1000: 1000,
			k1025: 1025,
			k1050: 1050,
			k1075: 1075,
			k1100: 1100,
			k1125: 1125,
			k1150: 1150,
			k1175: 1175,
			k1200: 1200
		};


		// Perosn Session Log Type
		this.personsessionlogtype = {
			login: "Person Login",
			logout: "Person Logout",
			invalidlogin: "Person Invalid Login",
			attendancehwlogin: "Attendance HW Login",
			attendancehwlogout: "Attendance HW Logout",
			invalidattendancehwlogin: "Invalid Attendance HW Login"
		}

		this.statustype = [
			{ 'value': 1, 'label': 'Active' },
			{ 'value': 0, 'label': 'Inactive' },
		];

		this.yesno = [
			{ 'value': 1, 'label': 'Yes' },
			{ 'value': 0, 'label': 'No' },
		];
		this.regex = {
			imageregex: /<img[^>]+src="([^">]+)"/g,
			'hsncode': "^[0-9]{4,8}$",
			"phone": "^(?:[+0]9)?[0-9]{10}$",
			"email": "^[\\w\\-\\.]+@([\\w\\-]+\\.)+[\\w\\-]{2,4}$",
			"gstno": "^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$",
			"pincode": "^[1-9][0-9]{5}$",
			"ip": "[^0-9:\\.]",
			"aadharno": "^[2-9]{1}[0-9]{3}[0-9]{4}[0-9]{4}$",
			"panno": "^[A-Z]{5}[0-9]{4}[A-Z]{1}$",
			"ifsccode": "^[A-Z]{4}0[A-Z0-9]{6}$",
			"name": "^[a-zA-Z\\s]*$",
			"pass": "^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[!@#\\$&*~]).{8,}$",
			"contactno": "^(?:[0-9] ?){6,14}[0-9]$",
			"accountno": "^([0-9]{11})|([0-9]{2}-[0-9]{3}-[0-9]{6})$",
			"exportbondno": "^(\\d{2})-?([a-zA-Z]{3})-?(\\d{6})-?(\\d{2})-?(\\d{1,4})$"
		}
		this.tblgridsizeclasses = {
			1: 1,
			2: 2,
			3: 3,
			4: 4,
			5: 5,
			6: 6,
			7: 7,
			8: 8,
			10: 10,
			15: 15,
			16: 16,
			18: 18,
			20: 20,
			25: 25,
			30: 30,
			35: 35,
			40: 40,
			45: 45,
			50: 50,
			55: 55,
			56: 56,
			60: 60,
			70: 70,
			80: 80,
			85: 85,
			86: 86,
			90: 90,
			100: 100
		}


		//for error message

		this.errmsg = {
			checkcontact: "OTP has been sent to your registered contact no.",
			notsuperadmin: "You are not authorized to add a new Super Admin.",
			insert: "inserted successfully.",
			update: "updated successfully.",
			delete: "deleted successfully.",
			bulkwrite: "Bulk write successfully done.",
			required: "Please fill in all required fields.",
			inuse: "Data is already in use.",
			isexist: "Data already exist.",
			futurelog: "Future log not apply",
			addleave: "Please add leave first",
			notexist: "Data not exist.",
			dberror: "Something went wrong, Error Code : ",
			userright: "Sorry, You don't have enough permissions to perform this action",
			size: "Sorry, You don't have enough permissions to perform this action",
			success: "Data found",
			error: "Error",
			nodatafound: "No data found",
			uservalidate: "User Validate.",
			checkmail: "Check Mail",
			deactivate: "Your account is suspended, please contact administrator to activate account.",
			invalidrequest: "Invalid request.",
			sessiontimeout: "Session timeout",
			samedisplayorder: "Same display order data is already exist.",
			samedisplayorderlayoutexist: "Same display order property layout is already exist.",
			samedisplayorderamenitiesexist: "Same display order amenities is already exist.",
			sametitlepromotionexist: "Same title promotion is already exist.",
			sametitlepropetylayoutexist: "Same title property layout is already exist.",
			samenameamenitiesexist: "Same name amenities is already exist.",
			cannotaddfoldertosamefolder: "Sorry, you can't add this folder to the same folder",
			dataduplicate: "Data Duplicated Succesfully",
			cannotdeleteauperadmin: "Can not delete admin",
			tokenvalidate: "Token validated",
			invalidtoken: "Invalid token.",
			usernotfound: "User not found",
			correctpass: "Please enter correct old password",
			invalidusername: "Invalid Username or Password.",
			invalidpassword: "Invalid Username or Password.",
			verifyemail: "Please verify your email addess",
			clockintoproperty: "Please switch the clockin property to ",
			verifysubdomain: "Please verify subdomain",
			filetype: "Invalid file extension",
			loginright: "Sorry, You don't have enough permissions to login. Please contact admin",
			somethingwrong: "Sorry, something went wrong.",
			loginsuccess: "Login Successfully",
			logoutsuccess: "Logout Successfully",
			appupdate: "We have released new version of glam App. Download the update and install to continue use this App.",
			"profile-update": "Profile updated successfully",
			reqseries: "Series data is required",
			seriesnotfound: "Series not found.",
			reqflow: "Flow is required",
			nonotifound: "No notification found",
			noorderfound: "No order found",
			nologfound: "No log found",
			nolostfoundrecord: "Lost and Found record is not found",
			itemready: "Item has been ready successfully",
			itemserved: "Item has been served successfully",
			processavailibility: "Procedure Flow not available",
			personnotfound: "Person not found",
			personisrequired: "Person is required",
			notificationnotsent: "Notification not sent",
			notificationsentsuccessfully: "Notification sent successfully",
			uncompletedtasknotfound: "Uncompleted task not found",
			remindernotfound: "Reminder not found",
			mediauploaded: "Media uploaded",
			nofileuploaded: "No file uploaded",
			mediadeleted: "Media Deleted",
			serialnumberalreadyinuse: "Serial number already in used.",
			taskexist: "task already exist.",
			youcannotupdatesubcategory: "You can't update service.",
			auditrundatenotbegreaterthantody: "The audit date should not be greater than today.",
			webloginright: "Sorry, You are not allowed to web login. Please contact admin",
			apploginright: "Sorry, You are not allowed to app login. Please contact admin",
			preferencesavedsuccessfully: "Preference saved successfully.",
			removeallsubgroups: "Please remove all sub groups first then convert main group to sub group",
			onlyadminsallowedtomsg: "Sorry, Only Admin can send messages.",
			groupisdeleted: "Sorry, group is deleted by admin.",
			removedfromgroup: "Sorry, you were removed from this group by Admin.",
			cleanorsubcategorytaskexist: "Cleaning or subcategory task should be already exist.",
			cantaddcheckinorcheckoutsubcategory: "Can't add checkin or checkout sub category.",
			subcategoryisalreadyaddedintheanothertask: "subcategory is already added in the another task.",
			cantaddtask: "Can't add task because,",
			profiledatanotfound: "Profile data not found",
			alreadyonvideocall: "Sorry, user is on another call.",
			companynotfound: "Company not found",
			clockoutfromoldproperty: "First, Clockout From Current Property",
			breakoutfromoldproperty: "First, Breakout From Current Property",
			alreadyaccepted: "Task already accepted!",
			alreadystarted: "Task already started!",
			breaktimerunning: "Can't start timer on breaktime or traveltime",
			needclockinfirst: "First you need to clock-in a property",
			groupnotfound: "Group not found.",
			onlysendercanupdate: "You cannot edit sender message.",
			alreadyvotedpoll: "You cannot vote on this poll again.",
			pollnotfound: "Poll not found",
			notdeleted: "Data not deleted",
			copysuccess: "Data copied successfully",
			overwritesuccess: "Data overwrite successfully",
			typemessageagain: "Sorry, please type your query or message again",
			cancelreservation: "Current reservation cannot be cancelled in extend stay",
			invalidip: "This IP address is not allowed",
			chooseanotherlatecheckouttime: "Sorry, we are unable to approve the time you have entered. Please select another time. ",
			nolatecheckoutorroomtypeprovided: "No latecheckouttime or roomtype if provided.",
			clockin: "You have successfully clocked in",
			clockout: "You have successfully clocked out",
			policyassigned: "Below employees already has a policy assigned for current year",
			policyused: "Below employees already used policy",
			shiftexist: "Below employees already has a Shift assigned for this month range",
			attendancepinexist: "Attendance pin is already in use",
			selfloan: "can not approve self loan",
			superadminlessthanone: "All super admin delete are not allowed",
			moduletypenotfound: "Moduletype not found",
			iconnotfound: "Icon not found",
			salaryapproved: "Can not re-run approved salary",
			noofnight: "No Of Night Required",
			auditrunstart: "Audit run started successfully",
			auditrunprocess: "Audit run already in progress.",
			passwordexpired: "Your password has been expired, please change your password.",
			otpsent: "OTP has been sent to your registered email address.",
			otpsended: "OTP already has been sent to your email. Please check your email.",
			otpverify: "OTP verified successfully.",
			otpexpired: "OTP has expired. Please request a new one.",
			invalidotp: "Invalid OTP. Please try again.",
			otpnotsent: "OTP not sent. Please verify your email address.",
			otpnotverified: "OTP not verified. Please verify your email address.",
			passreset: "Password Reset Successfully",
			emailsent: "Email Sent",
			processstart: "Process started, please wait.",
			bulksalarygenerate: "Salary generated",
			lastpasswordsame: "New password can not be same as old password",
			last4passwordsame: "New password can not be same as last 4 password",
			passchanged: "Password changed successfully",
			usernotauthorised: "You are not authorised",
			propertynotallowed: "You are not allowed to access this property",
			apinotfound: "API Route Not Found",
			breakinpersonlimit: "Break limit of this callcenter is exceed",
			calltranferlimit: "Call Transfer Limit Exceed",
			breaklimit: "Break limit of this callcenter is exceed, you can not transfer call and your break added in queue",
			breakqueueadd: "Break Queue Added Successfully",
			existbreakqueue: "You are already in break queue, please wait for your turn",
			surveyformexpired: "Survey form has been expired",
			userdomainexist: "User domain already exist",
			pmsconnectnotfound: "glam PMS connect not found",
			preferenceupdated: "Preference Updated Successfully",
			linkexpired: "Your Link Has Been Expired",
			sessionunlock: "Session Unlocked Successfully",
			invalidsessionpassword: "Invalid Password",
			invalidsession2facode: "Invalid 2FA Code",
			menualreadyassign: 'Menu already assign please update the menu assign data',
			timeslotoverlap: "The provided timeslots are overlapping. Please provide non-conflicting timeslots.",
			alreadybooked: "Sorry, the facility is already booked for the selected time slot. Please choose a different time.",
			notclockin: "You haven't clocked in yet",
			//panish 
			alreadyin: "The visitor is already present this property.",
			visitorout: "The visitor has checked out.",
			visitorin: "The visitor has checked in.",
			visitorexpired: "The visitor's code is not valid at this time.",
			noteditable: "Facility booking cannot be edited once approved or rejected.",
			notreopen: "This Ticket not Reopen yet.",
			qrcodenotfound: "QR code not found. Ensure the code is correct and try again.",
			qrcodesuccess: "QR code scanned successfully. Access granted.",
			notchecklist: "Task cannot be completed. Required checklists missing",
			selfapprove: "Can't approve self request",
            selfreject: "Can't reject self request",
			terminated:"Your account has been terminated. Please contact your administrator for more details.",
			selfterminated: "You cannot terminated your own account.",
			selfdeactive: "You cannot deactive your own account.",
			"2FAalreadyenable": "You have already turned on the two factor authentication",
			"2FAnotenabled": "Two factor authentication is not enabled",
			"2FAnotreuqest": "You have not requested to turn on the two factor authentication",
			"2FAinvalidotp": "OTP Validation failed - You have entered incorrect otp",
			"2FAenable": "Two factor authentication enabled successfully",
			"2FAdisable": "Two factor authentication disabled successfully",
			"2FAnotsent": "You have not sent request for 2 factor authentication",
			"2FAinvalidrecoverycode": "Invalid Recovery Code Provided",
		}

		this.otherformdataaction = {}

		this.resstatuscode = {
			100: "Continue",
			101: "Switching Protocols",
			103: "Early Hints",
			200: "OK",
			201: "Created",
			202: "Accepted",
			203: "Non-Authoritative Information",
			204: "No Content",
			205: "Reset Content",
			206: "Partial Content",
			300: "Multiple Choices",
			301: "Moved Permanently",
			302: "Found",
			303: "See Other",
			304: "Not Modified",
			307: "Temporary Redirect",
			308: "Permanent Redirect",
			400: "Bad Request",
			401: "Unauthorized",
			402: "Payment Required",
			403: "Forbidden",
			404: "Not Found",
			405: "Method Not Allowed",
			406: "Not Acceptable",
			407: "Proxy Authentication Required",
			408: "Request Timeout",
			409: "Conflict",
			410: "Gone",
			411: "Length Required",
			412: "Precondition Failed",
			413: "Payload Too Large",
			414: "URI Too Long",
			415: "Unsupported Media Type",
			416: "Range Not Satisfiable",
			417: "Expectation Failed",
			418: "I'm a teapot",
			422: "Unprocessable Entity",
			425: "Too Early",
			426: "Upgrade Required",
			428: "Precondition Required",
			429: "Too Many Requests",
			431: "Request Header Fields Too Large",
			451: "Unavailable For Legal Reasons",
			500: "Internal Server Error",
			501: "Not Implemented",
			502: "Bad Gateway",
			503: "Service Unavailable",
			504: "Gateway Timeout",
			505: "HTTP Version Not Supported",
			506: "Variant Also Negotiates",
			507: "Insufficient Storage",
			508: "Loop Detected",
			510: "Not Extended",
			511: "Network Authentication Required"
		}

		this.imagemodel = {
			name: { type: String },
			size: { type: Number },
			url: { type: String },
			extension: { type: String },
			uploadeddate: { type: String },
			uploadedby: { type: String },
			isUploaded: { type: Boolean },
		  }

		this.priorityseverityclasses = {
			high: "high",
			medium: "medium",
			low: "low",
			none: "none"
		}

		this.sockettriggers = {
			// Socket API
			request: "request",
			response: "response",

			roomwisesocket: "roomwisesocket",
			emitallsocket: "emitallsocket",
			checkroom: "checkroom",
			checkroomresponse: "checkroomresponse",
			message: "message",
			messagereceive: "messagereceive",
		}


		this.emailtemplates = {
			forgotpassword: {
				subject: "Reset Your Password",
				body: "/assets/htmltemplates/forgotpassword.html",
				type: 20
			},
			survey: {
				subject: "survey",
				body: "/assets/htmltemplates/survey.html",
				type: 1
			},
			draftsurvey: {
				subject: "Draft Survey",
				body: "/assets/htmltemplates/draftsurveyform.html",
				type: 1
			},
			managerialsurvey: {
				subject: "Form",
				body: "/assets/htmltemplates/managerialsurvey.html",
				type: 1
			},
			complaint: {
				subject: "complaint",
				body: "/assets/htmltemplates/supportticketnotify.html",
				type: 1
			},
			notice: {
				subject: "notice",
				body: "/assets/htmltemplates/notice.html",
				type: 1
			}
		}

		// jaydev
		this.notificationtype = {
			taskassign: 1,
			issueassign: 2,
			project: 3,
			announcement: 4,
			taskcomment: 5
		}

		this.notificationtitles = {
			taskreminder: "Reminder for your task",
			taskassign: "#owner? Assigned Task, Task: #taskid?"
		}

		this.apipagename = {
			tblemployee :  { pagename: "property", alias: "property" },
			tblgatekeeper : { pagename: "gatekeeper", alias: "gatekeeper" },
			tblchecklist: { pagename: "checklist", alias: "checklist" },
			tblfacilitybooking: { pagename: "facility", alias: "facility" },
			tblcomplaint: { pagename: "complaint", alias: "complaint" },
			tbldailyhelp: { pagename: "dailyhelp", alias: "dailyhelp" },
			tblvendor: { pagename: "vendor", alias: "vendor" },
			tblcustomer :{ pagename: "customer", alias: "customer" },
			tblvendorstaff : {pagename:"vendorstaff",alias:"vendorstaff"},
			tbldailyhelpmaster :{pagename:"dailyhelp",alias:"dailyhelp"}
		}


		this.formfileds = {
			isactive: {
				'field': 'isactive',
				'text': 'Status',
				'type': 'dropdown',
				'disabled': false,
				'defaultvisibility': true,
				'required': true,
				'gridsize': 375,
				'masterdata': 'isactive',
				'masterdataarray': this.statustype,
				'defaultvalue': 1,
				'formdatafield': 'isactive',
				'cleanable': true,
				'searchable': true,
				'masterdatadependancy': false,
			}
		}

		this.basicheadertype = "6231b1b7a7f4d06428c30417"

		// Perosn Change Log Type
		this.personchangelogtype = {
			create: "User Created",
			update: "User Updated",
			previlege: "User Previlege Updated",
			delete: "User Deleted",
			passwordupdate: "User Password Updated",
			passwordreset: "User Password Reset",
			creditcardpasswordupdate: "User Credit Card Password Updated",
			creditcardpasswordreset: "User Credit Card Password Reset",
			accountlock: "User Account Locked",
			accountunlock: "User Account Unlocked"
		}

		// Socket API Route
		this.socketapiroute = {
			building: "property/building",
			wing: "property/wing"
		}

		this.itemstoragetype = {
			"rack": "Rack",
			"shelf": "Shelf"
		}

		this.surveyformfor = {
			customer: 'Customer',
			employee: 'Employee',
		}

		this.requestBody = {
			"searchtext": "",
			"paginationinfo": {
				"pageno": 1,
				"pagelimit": 2000,
				"filter": {},
				"projection": {},
				"sort": { "city": -1 }
			}
		};

		this.invalidRequestBody = {
			"paginationinfo": {
				"pageno": "invalid",
				"pagelimit": -10,
			}
		};

		this.slowRequestBody = {
			"searchtext": "",
			"paginationinfo": {
				"pageno": 1,
				"pagelimit": 2000,
				"filter": {},
				"projection": {},
				"sort": {}
			}
		};
	}


	getErrmsg() {
		return this.errmsg
	}

	getFormfields() {
		return this.formfileds
	}

	getStaffid() {
		return this.staffid
	}
	getTaxiid() {
		return this.taxiid
	}

	getUnAssignedStatus() {
		return this.UnAssignedStatus
	}
	getReopenStatus() {
		return this.ReopenStatus
	}
	getCompletedStatus() {
		return this.CompletedStatus
	}
	getOtherformdataaction() {
		return this.otherformdataaction
	}
	getResponsestatuscode() {
		return this.resstatuscode
	}

	getMssqldefval() {
		return this.weburl
	}

	getMysqldefval() {
		return this.weburl
	}

	getWeburl() {
		return this.weburl
	}

	getBlobkey() {
		return this.blobkey
	}

	getContainer() {
		return this.container
	}

	setWeburl(weburl) {
		this.weburl = weburl
	}

	getendpointv1() {
		return this.endpointv1
	}

	getTblgridsizeclasses() {
		return this.tblgridsizeclasses
	}
	getPrioritySeverityclasses() {
		return this.priorityseverityclasses
	}

	getImageModel(){
		return this.imagemodel
	}

	getSocketTriggers() {
		return this.sockettriggers
	}

	setendpointv1(endpointv1) {
		this.endpointv1 = endpointv1
	}

	getEndpointurl() {
		return this.endpointurl
	}

	setEndpointurl(endpointurl) {
		this.endpointurl = endpointurl
	}

	getDocurl() {
		return this.docurl
	}

	setDocurl(docurl) {
		this.docurl = docurl
	}

	getRegdomain() {
		return this.regdomain
	}

	setRegdomain(regdomain) {
		this.regdomain = regdomain
	}

	getMailurl() {
		return this.mailurl
	}

	setMailurl(mailurl) {
		this.mailurl = mailurl
	}

	getProtocol() {
		return this.protocol
	}

	getBaseurl() {
		return this.baseUrl
	}

	getSubdbprefix() {
		return this.subdbprefix
	}
	setProtocol(protocol) {
		this.protocol = protocol
	}

	getDocpath() {
		return this.docpath
	}

	setDocpath(docpath) {
		this.docpath = docpath
	}

	getCdnurl() {
		return this.cdnurl
	}

	setCdnurl(cdnurl) {
		this.cdnurl = cdnurl
	}

	getServermode() {
		return this.servermode
	}

	setServermode(servermode) {
		this.servermode = servermode
	}

	getMainDirpath() {
		return this.maindirpath
	}

	setMainDirpath(maindirpath) {
		this.maindirpath = maindirpath
	}

	getDirpath() {
		return this.dirpath
	}

	setDirpath(dirpath) {
		this.dirpath = dirpath
	}

	getAdminutype() {
		return this.adminutype
	}

	getDummyId() {
		return this.dummyObjid
	}

	getSubmitbutton() {
		return this.submitbutton
	}

	getGeneratereport() {
		return this.generatereport
	}


	getUpdateMyProfile() {
		return this.updatemyprofile
	}

	getChangePassword() {
		return this.changepassword
	}

	getChangeUsertype() {
		return this.changeusertype
	}

	getPage404url() {
		return this.page404url
	}

	getImageurl() {
		return this.imageurl
	}

	getNoDataFound() {
		return this.nodatafound
	}

	getStateId() {
		return this.stateid
	}

	getStatustype() {
		return this.statustype
	}

	getYesNoType() {
		return this.yesno
	}

	getTokenKey() {
		return this.tokenkey
	}

	getTokenKey() {
		return this.tokenkey
	}

	getAdminUserId() {
		return this.adminuid
	}

	getSocketurl() {
		return this.socketurl
	}

	getSocketserver() {
		return this.socketserver
	}
	getHtmlcontorls() {
		return this.htmlcontorls
	}
	getFieldSize() {
		return this.FieldSize
	}
	getReports() {
		return this.reports
	}
	getModalsizeclasses() {
		return this.modalsizeclasses
	}


	setDBType(DBType) {
		this.DBType = DBType
	}

	getDBType() {
		return this.DBType
	}

	setDBName(DBName) {
		this.DBName = DBName
	}

	getDBName() {
		return this.DBName
	}

	setDBUser(DBUser) {
		this.DBUser = DBUser
	}

	getDBUser() {
		return this.DBUser
	}

	setDBHost(DBHost) {
		this.DBHost = DBHost
	}

	getDBHost() {
		return this.DBHost
	}

	setDBPass(DBPass) {
		this.DBPass = DBPass
	}

	getDBPass() {
		return this.DBPass
	}

	setDBPort(DBPort) {
		this.DBPort = DBPort
	}

	getDBPort() {
		return this.DBPort
	}

	getWeekOffids() {
		return this.weekoffs
	}

	getEmailTemplates() {
		return this.emailtemplates
	}

	getNotificationTitles() {
		return this.notificationtitles
	}

}

export default Config
