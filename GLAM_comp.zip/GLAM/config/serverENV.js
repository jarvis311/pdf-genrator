// const servermode = ""
// export default servermode // prod - Live | uat - test | dev = development

import dotenv1 from "dotenv"

if (!["uat", "dev", "production"].includes(process.env.NODE_ENV)) {
	dotenv1.config({ path: ".env" })
}
const servermode = process.env.NODE_ENV
export default servermode // prod - Live | uat - test | dev = development

