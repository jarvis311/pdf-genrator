import chai from 'chai';
import chaiHttp from 'chai-http';
import { Config, IISAutoTest, IISMethods, FieldConfig } from '../../config/Init.js'
import async from 'async'

chai.use(chaiHttp);
chai.config.includeStack = true
const { should } = chai
should()

const ObjectId = IISMethods.getobjectid()
const customerid = new ObjectId()

const endpoint = {
    list: "/customer",
    add: "/customer/add",
    update: "/customer/update",
    delete: "/customer/delete"
};

const reqheader = {
    list: { useraction: "viewright", pagename: "customer", apptype: 1 },
    add: { useraction: "addright", pagename: "customer", apptype: 1 },
    update: { useraction: "editright", pagename: "customer", apptype: 1 },
    delete: { useraction: "delright", pagename: "customer", apptype: 1 },
}

const reqbody = {
    add: {
        _id: customerid,
        "firstname": "Het1",
        "middlename": "M",
        "lastname": "Patel",
        "personemail": "jayesh11@gmail.com",
        "username": "jayesh11",
        "password": "a",
        "contact": "98745632292",
        "alternatecontact": "98745632190",
        "profilepic": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAAAeP4ixAAAAAXNSR0IArs4c6QAAA1NJREFUaEPt2r9LclEYB/Cvk6RDYEPhICKCQ0N/gLm0NLhIgQ1OIji4RQ2RSGkE4uImOAgNOrg4BjU4qZNLkIMQ0lBBUFFDhFMvz3m5dl9/dO8951zTeA8Eeu+59zyf+zznEN5jabfbnw6HA1arFfPY+v0+Xl5eYOn1ep/0wev1YnFxca4sb29vuLm5ASXCcn9//2m329mBecIoCIr5/f39L8TpdEJ9YtYzMxzrw8PDF4Rqah4w42Icgcw6ZtKDHguZVcx31TIRMmsYrZL/FjIrGC0ExakJ+WmMHoRuyE9h9CIMQaaNMYIwDJkWxiiCC2I2hgfBDTELw4sQgsjGiCCEIbIwoggpEFGMDIQ0CC9GFkIqxChGJkI6RC9GNsIUiBbGDIRpkEkYsxCmQoYx9N3MHzd0/RtPQfA2JQt0vZm/0PyH6MmQek7MbWmNm9hzN9m/C9gsjPQ5oidQPX30lK66j1SIkQCN9NWDkgbhCYznmkkoKRCRgESulVpaMgKRcQ+hjMgIQHmqovfihogOPK7WRe7JBREZUGsF4r23YQjvQFoA9XmeMQxBeAYwAhDB6IZME8GzAOiC/ATCKEYTwot4fn5GJBLBxcUFiymTySCVSqHZbGJ9fZ0dK5fLrM+49vHxgd3dXRSLRXZ6a2sLhUIBr6+v2NnZwdXV1eCedN60V2/dbhelUgnpdBoLCwssGMIlk0mcnp7CZrPh6OgIsVgMPp9vxKLuu7S0xN42dzodVKtVJBIJds3JyQk2Njbg9/snQ3gzoUSkfvJra2ssAGrn5+fsSVOrVCpwu92o1+vweDwsO3Ss1+shHA4Pnjz1bTQaoL0AuVwOx8fHWF5eZtm9vb1l15n2epoCokaDKNmhzxS0GqL0yefzoN0Xj4+PgxKkvlSOSnb29vZwdnaGYDCI1dVVXF9fs/tRn6lsGFACiUajaLVaIxmh0hguJXWt0XyhMtze3sbl5SXi8Tju7u7w9PTE/kYyIlpO6sHV9UslQE+OanvcHHG5XCxQAlFfmle1Wm0kowcHB8hms2xeraysgL6HQiFsbm5+ZUT2phr1qkUDUanRpB1etWg1olILBAL/zJH9/f3BqqXMMZrgVKbKqnV4eMhWs8Gmml+zzem3bDz7Azf0RKt+wu2dAAAAAElFTkSuQmCC",
        "genderid": "6221dc42c85eb209a703eb00",
        "gender": "Male",
        "dateofbirth": "2000-06-06",
        "currentaddress": "Shivaan avenue",
        "countryid": "628dddec9ed69439d028a663",
        "country": "India",
        "stateid": "628df13f8957f1ddc3f014d9",
        "state": "Gujarat",
        "cityid": "628e0f9f54946738e80be4a5",
        "city": "Surat",
        "area": "Coseway",
        "pincode": 394005,
        "pincodeid": "628e0f9f54946738e80be4a5",
        "isactive": 1,
        "property": [
            {
                "propertyid": "62cd5968b4dba4125805d072",
                "property": "Hotel 1"
            }
        ],
        "schedulerproperty": [
            {
                "propertyid": "62cd5968b4dba4125805d072",
                "property": "Hotel 1",
                "isselected": 1
            }
        ],
        "designationid": "62e23d73798ba64178f1d2ba",
        "designation": "Designation1",
        "reportingtoid": "62e13dc40e54c436dd682773",
        "reportingto": "MD Crus",
        "presentstatus": 1,
        "userrole": [
            {
                "userroleid": "622ed36cbe213c85a88da9a0",
                "userrole": "Super Admin"
            }
        ],
        "documents": [
            {
                "documentname": "doc1",
                "documentfile": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAAAeP4ixAAAAAXNSR0IArs4c6QAAA1NJREFUaEPt2r9LclEYB/Cvk6RDYEPhICKCQ0N/gLm0NLhIgQ1OIji4RQ2RSGkE4uImOAgNOrg4BjU4qZNLkIMQ0lBBUFFDhFMvz3m5dl9/dO8951zTeA8Eeu+59zyf+zznEN5jabfbnw6HA1arFfPY+v0+Xl5eYOn1ep/0wev1YnFxca4sb29vuLm5ASXCcn9//2m329mBecIoCIr5/f39L8TpdEJ9YtYzMxzrw8PDF4Rqah4w42Icgcw6ZtKDHguZVcx31TIRMmsYrZL/FjIrGC0ExakJ+WmMHoRuyE9h9CIMQaaNMYIwDJkWxiiCC2I2hgfBDTELw4sQgsjGiCCEIbIwoggpEFGMDIQ0CC9GFkIqxChGJkI6RC9GNsIUiBbGDIRpkEkYsxCmQoYx9N3MHzd0/RtPQfA2JQt0vZm/0PyH6MmQek7MbWmNm9hzN9m/C9gsjPQ5oidQPX30lK66j1SIkQCN9NWDkgbhCYznmkkoKRCRgESulVpaMgKRcQ+hjMgIQHmqovfihogOPK7WRe7JBREZUGsF4r23YQjvQFoA9XmeMQxBeAYwAhDB6IZME8GzAOiC/ATCKEYTwot4fn5GJBLBxcUFiymTySCVSqHZbGJ9fZ0dK5fLrM+49vHxgd3dXRSLRXZ6a2sLhUIBr6+v2NnZwdXV1eCedN60V2/dbhelUgnpdBoLCwssGMIlk0mcnp7CZrPh6OgIsVgMPp9vxKLuu7S0xN42dzodVKtVJBIJds3JyQk2Njbg9/snQ3gzoUSkfvJra2ssAGrn5+fsSVOrVCpwu92o1+vweDwsO3Ss1+shHA4Pnjz1bTQaoL0AuVwOx8fHWF5eZtm9vb1l15n2epoCokaDKNmhzxS0GqL0yefzoN0Xj4+PgxKkvlSOSnb29vZwdnaGYDCI1dVVXF9fs/tRn6lsGFACiUajaLVaIxmh0hguJXWt0XyhMtze3sbl5SXi8Tju7u7w9PTE/kYyIlpO6sHV9UslQE+OanvcHHG5XCxQAlFfmle1Wm0kowcHB8hms2xeraysgL6HQiFsbm5+ZUT2phr1qkUDUanRpB1etWg1olILBAL/zJH9/f3BqqXMMZrgVKbKqnV4eMhWs8Gmml+zzem3bDz7Azf0RKt+wu2dAAAAAElFTkSuQmCC"
            },
            {
                "documentname": "doc2",
                "documentfile": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAAAeP4ixAAAAAXNSR0IArs4c6QAAA1NJREFUaEPt2r9LclEYB/Cvk6RDYEPhICKCQ0N/gLm0NLhIgQ1OIji4RQ2RSGkE4uImOAgNOrg4BjU4qZNLkIMQ0lBBUFFDhFMvz3m5dl9/dO8951zTeA8Eeu+59zyf+zznEN5jabfbnw6HA1arFfPY+v0+Xl5eYOn1ep/0wev1YnFxca4sb29vuLm5ASXCcn9//2m329mBecIoCIr5/f39L8TpdEJ9YtYzMxzrw8PDF4Rqah4w42Icgcw6ZtKDHguZVcx31TIRMmsYrZL/FjIrGC0ExakJ+WmMHoRuyE9h9CIMQaaNMYIwDJkWxiiCC2I2hgfBDTELw4sQgsjGiCCEIbIwoggpEFGMDIQ0CC9GFkIqxChGJkI6RC9GNsIUiBbGDIRpkEkYsxCmQoYx9N3MHzd0/RtPQfA2JQt0vZm/0PyH6MmQek7MbWmNm9hzN9m/C9gsjPQ5oidQPX30lK66j1SIkQCN9NWDkgbhCYznmkkoKRCRgESulVpaMgKRcQ+hjMgIQHmqovfihogOPK7WRe7JBREZUGsF4r23YQjvQFoA9XmeMQxBeAYwAhDB6IZME8GzAOiC/ATCKEYTwot4fn5GJBLBxcUFiymTySCVSqHZbGJ9fZ0dK5fLrM+49vHxgd3dXRSLRXZ6a2sLhUIBr6+v2NnZwdXV1eCedN60V2/dbhelUgnpdBoLCwssGMIlk0mcnp7CZrPh6OgIsVgMPp9vxKLuu7S0xN42dzodVKtVJBIJds3JyQk2Njbg9/snQ3gzoUSkfvJra2ssAGrn5+fsSVOrVCpwu92o1+vweDwsO3Ss1+shHA4Pnjz1bTQaoL0AuVwOx8fHWF5eZtm9vb1l15n2epoCokaDKNmhzxS0GqL0yefzoN0Xj4+PgxKkvlSOSnb29vZwdnaGYDCI1dVVXF9fs/tRn6lsGFACiUajaLVaIxmh0hguJXWt0XyhMtze3sbl5SXi8Tju7u7w9PTE/kYyIlpO6sHV9UslQE+OanvcHHG5XCxQAlFfmle1Wm0kowcHB8hms2xeraysgL6HQiFsbm5+ZUT2phr1qkUDUanRpB1etWg1olILBAL/zJH9/f3BqqXMMZrgVKbKqnV4eMhWs8Gmml+zzem3bDz7Azf0RKt+wu2dAAAAAElFTkSuQmCC"
            }
        ]
    },
    update: {
        _id: customerid,
        customer: "German",
        status: 1
    },
    delete: {
        _id: customerid
    },
    filter: {
        searchtext: "",
        paginationinfo: {
            pageno: 1,
            pagelimit: 200000000,
            filter: { "_id": [customerid.toString(), "66acc53ca826a13d00a88190"] },
            sort: {}
        }
    },
    sort: {
        searchtext: "",
        paginationinfo: {
            pageno: 1,
            pagelimit: 200000000,
            filter: {},
            projection: { personname: 1 },
            sort: { personname: 1 }
        }
    },
    search: {
        searchtext: "In",
        paginationinfo: {
            pageno: 1,
            pagelimit: 200000000,
            filter: {},
            projection: {},
            sort: {}
        }
    },
    dependancy: [
        {
            endpoint: { list: "/state", add: "/state/add" },
            match: ['customer'],
            body: {
                _id: stateid,
                state: "mp",
                customerid: customerid,
                customer: "German"
            },
            filter: {
                searchtext: "",
                paginationinfo: {
                    pageno: 1,
                    pagelimit: 2000,
                    filter: { "countyid": [customerid] },
                    projection: {},
                    sort: {}
                }
            }
        },
        {
            endpoint: { list: "/city", add: "/city/add" },
            match: ['customer'],
            body: {
                _id: cityid,
                city: "surat",
                stateid: stateid,
                state: "mp",
                customerid: customerid,
                customer: "German"
            },
            filter: {
                searchtext: "",
                paginationinfo: {
                    pageno: 1,
                    pagelimit: 2000,
                    filter: { "countyid": [stateid] },
                    projection: {},
                    sort: {}
                }
            }
        }
    ]
}


const invalidDataTests = [
    {
        data: {
            customer: "",
            status: 1,
            flag: "India",
            customerdialcode: "+91",
            customercode: "In"
        },
        expectedError: 'Path `customer` is required.',
        description: 'should return an error for empty customer name'
    },
    {
        data: {
            customer: "India",
            status: 1
        },
        expectedError: 'Path `flag` is required.,Path `customerdialcode` is required.,Path `customercode` is required.',
        description: 'should return an error for required parameter'
    }
]

let authDetails

describe('Cruds', async function () {

    await IISAutoTest.EmployeeAuthTestcase()

    const testCases = IISAutoTest.CommonTestcase({ endpoint, reqbody, reqheader })
    for (const testCase of testCases) {
        IISAutoTest.performRequest(testCase)
    }

    //diffrent scenario test
    for (const dep of invalidDataTests) {
        IISAutoTest.performRequest({
            method: 'post', endpoint: endpoint.add, body: dep.data, expectedStatus: 400, description: dep.description, headers: reqheader.add,
            expectedResponse: (res) => {
                res.should.be.a('object')
                res.body.should.be.a('object')
                res.body.should.have.property('message').that.equals(dep.expectedError)
            }
        })
    }


    //dependancy testcase   
    reqbody.dependancy.forEach(dep => {
        it(`should insert data into ${dep.endpoint.add}`, async function () {
            IISAutoTest.performRequest({
                method: 'post', endpoint: endpoint.add, body: dep.data, expectedStatus: 200, description: 'should create resource successfully', headers: reqheader.add,
                expectedResponse: (res) => {
                    res.body.should.have.property('message').that.equals('Data inserted successfully.')
                }
            })
        })
    })

    it('should update customer and all dependencies dynamically', async function () {
        IISAutoTest.performRequest({
            method: 'post', endpoint: endpoint.update, body: reqbody.update, expectedStatus: 200, description: 'should update resource successfully', headers: reqheader.update,
            expectedResponse: async (res) => {
                res.body.should.have.property('message').that.equals('Data updated successfully.');
                res.should.have.status(200);
            }
        });

        for (const dep of reqbody.dependancy) {
            it(`should validate ${dep.endpoint.list} and all dependencies dynamically`, async function () {
                IISAutoTest.performRequest({
                    method: 'post', endpoint: dep.endpoint.list, body: dep.filter, expectedStatus: 200, description: 'dependencies check', headers: reqheader.list,
                    expectedResponse: async (res1) => {
                        res1.should.have.status(200)
                        const records = res1.body.data

                        for (const matchKey of dep.match) {
                            const matchValue = reqbody.update[matchKey]
                            const matchExists = records.some(record => record[matchKey] === matchValue)
                            matchExists.should.be.true
                        }
                    }
                })
            })
        }
    })

    // Concurrent requests test
    it('should handle concurrent requests correctly without data corruption or errors', function (done) {
        this.timeout(30000);

        const numConcurrentRequests = 50;
        const requestBodies = Array(numConcurrentRequests).fill(Config.requestBody)

        const requestFunctions = requestBodies.map(body => {
            return (callback) => {
                chai.request.execute(Config.getBaseurl())
                    .post(endpoint.list)
                    .send(body)
                    .end((err, res) => {
                        if (err) return callback(err)

                        try {
                            res.should.have.status(200)
                            res.body.should.be.a('object')
                            res.body.should.have.property('status').eql(200)
                            callback()
                        } catch (e) {
                            callback(e)
                        }
                    })
            }
        })

        async.parallel(requestFunctions, (err) => {
            if (err) return done(err)
            done()
        })
    })

})



