// import chai from 'chai';
// import chaiHttp from 'chai-http';
// import { Config, IISAutoTest, IISMethods,FieldConfig } from '../../config/Init.js'
// import async from 'async'

// chai.use(chaiHttp);
// chai.config.includeStack = true
// const { should} = chai
// should()

// const ObjectId = IISMethods.getobjectid()
// const userrightid = new ObjectId()

// const endpoint = {
//   list: "/userright",
//   add: "/userright/add",
//   update: "/userright/update",
//   delete: "/userright/delete"
// }

// const reqheader = {
//   list:{useraction:"viewright",pagename:"userright",apptype:1},
//   add:{useraction:"addright",pagename:"userright",apptype:1},
//   update:{useraction:"editright",pagename:"userright",apptype:1},
//   delete:{useraction:"delright",pagename:"userright",apptype:1},
// }

// const reqbody = {
//   add: {
//     _id: userrightid,
//     "personid": "667d1bd1e4314b0db96fd8ea",
//     // "userroleid": "635230eb66b87f45ca7600d9",
//      "moduletypeid":"621632cd6e7429b80322da0d",
//      "propertyid":"667d1bd1e4314b0db96fd8ea",
//      "data": [
//          {
//              "menuname": "campaign",
//              "formname": "campaign",
//              "alias": "campaign",
//              "displayinsidebar": 1,
//              "canhavechild": 0,
//              "allviewright": 0,
//              "selfviewright": 0,
//              "alladdright": 1,
//              "selfaddright": 1,
//              "alleditright": 1,
//              "selfeditright": 1,
//              "alldelright": 1,
//              "selfdelright": 1,
//              "allexportdata":1,
//              "allimportdata":1,
//              "allprintright": 1,
//              "selfprintright": 1,
//              "requestright": 1,
//              "changepriceright": 1,
//              "moduleid": ""
//          },
//          {
//              "menuname": "loggers",
//              "formname": "loggers",
//              "alias": "loggers",
//              "displayinsidebar": 1,
//              "canhavechild": 0,
//              "allviewright": 0,
//              "selfviewright": 0,
//              "alladdright": 0,
//              "selfaddright": 0,
//              "alleditright": 0,
//              "selfeditright": 0,
//              "alldelright": 0,
//              "selfdelright": 0,
//              "allprintright": 0,
//              "selfprintright": 0,
//              "allexportdata":0,
//              "allimportdata":0,
//              "requestright": 0,
//              "changepriceright": 0,
//              "allfinancialdata": 0,
//              "selffinancialdata": 0,
//              "moduleid": ""
//          }
//      ]
//   },
//   update: {
//     _id: userrightid,
//     "personid": "667d1bd1e4314b0db96fd8ea",
//     // "userroleid": "635230eb66b87f45ca7600d9",
//      "moduletypeid":"621632cd6e7429b80322da0d",
//      "propertyid":"667d1bd1e4314b0db96fd8ea",
//      "data": [
//          {
//              "menuname": "campaign",
//              "formname": "campaign",
//              "alias": "campaign",
//              "displayinsidebar": 1,
//              "canhavechild": 0,
//              "allviewright": 1,
//              "selfviewright": 1,
//              "alladdright": 1,
//              "selfaddright": 1,
//              "alleditright": 1,
//              "selfeditright": 1,
//              "alldelright": 0,
//              "selfdelright": 0,
//              "allexportdata":1,
//              "allimportdata":1,
//              "allprintright": 1,
//              "selfprintright": 1,
//              "requestright": 1,
//              "changepriceright": 1,
//              "moduleid": ""
//          },
//          {
//              "menuname": "loggers",
//              "formname": "loggers",
//              "alias": "loggers",
//              "displayinsidebar": 1,
//              "canhavechild": 0,
//              "allviewright": 0,
//              "selfviewright": 0,
//              "alladdright": 0,
//              "selfaddright": 0,
//              "alleditright": 0,
//              "selfeditright": 0,
//              "alldelright": 0,
//              "selfdelright": 0,
//              "allprintright": 0,
//              "selfprintright": 0,
//              "allexportdata":0,
//              "allimportdata":0,
//              "requestright": 0,
//              "changepriceright": 0,
//              "allfinancialdata": 0,
//              "selffinancialdata": 0,
//              "moduleid": ""
//          }
//      ]
//   },
//   delete: {
//     _id: userrightid
//   },
//   filter: {
//     searchtext: "",
//     paginationinfo: {
//       pageno: 1,
//       pagelimit: 200000000,
//       filter: { "_id": [userrightid.toString(),"66acc53ca826a13d00a88190"] },
//       sort: {}
//     }
//   },
//   sort: {
//     searchtext: "",
//     paginationinfo: {
//       pageno: 1,
//       pagelimit: 200000000,
//       filter: {},
//       projection: { userright: 1 },
//       sort: { userright: 1 }
//     }
//   },
//   search: {
//     searchtext: "In",
//     paginationinfo: {
//       pageno: 1,
//       pagelimit: 200000000,
//       filter: {},
//       projection: {},
//       sort: {}
//     }
//   },
//   dependancy: [
//     {
//       endpoint: { list: "/state", add: "/state/add" },
//       match: ['userright'],
//       body: {
//         _id: stateid,
//         state: "mp",
//         userrightid: userrightid,
//         userright: "German"
//       },
//       filter: {
//         searchtext: "",
//         paginationinfo: {
//           pageno: 1,
//           pagelimit: 2000,
//           filter: { "countyid": [userrightid] },
//           projection: {},
//           sort: {}
//         }
//       }
//     },
//     {
//       endpoint: { list: "/city", add: "/city/add" },
//       match: ['userright'],
//       body: {
//         _id: cityid,
//         city: "surat",
//         stateid: stateid,
//         state: "mp",
//         userrightid: userrightid,
//         userright: "German"
//       },
//       filter: {
//         searchtext: "",
//         paginationinfo: {
//           pageno: 1,
//           pagelimit: 2000,
//           filter: { "countyid": [stateid] },
//           projection: {},
//           sort: {}
//         }
//       }
//     }
//   ]
// }


// const invalidDataTests = [
//   {
//     data: {
//       userright: "",
//       status: 1,
//       flag: "India",
//       userrightdialcode: "+91",
//       userrightcode: "In"
//     },
//     expectedError: 'Path `userright` is required.',
//     description: 'should return an error for empty userright name'
//   },
//   {
//     data: {
//       userright: "India",
//       status: 1
//     },
//     expectedError: 'Path `flag` is required.,Path `userrightdialcode` is required.,Path `userrightcode` is required.',
//     description: 'should return an error for required parameter'
//   }
// ]

// let authDetails

// describe('Cruds', async function () {

//  await IISAutoTest.EmployeeAuthTestcase()

//  const testCases = IISAutoTest.CommonTestcase({ endpoint, reqbody,reqheader})
//   for (const testCase of testCases) {
//     IISAutoTest.performRequest(testCase)
//   }
  
//   //diffrent scenario test
//   for (const dep of invalidDataTests) {
//      IISAutoTest.performRequest({method: 'post',endpoint: endpoint.add,body: dep.data,expectedStatus: 400,description: dep.description,headers: reqheader.add,
//         expectedResponse: (res) => {
//           res.should.be.a('object')
//           res.body.should.be.a('object')
//           res.body.should.have.property('message').that.equals(dep.expectedError)
//         }
//       })
//   }


//   //dependancy testcase   
//   reqbody.dependancy.forEach(dep => {
//     it(`should insert data into ${dep.endpoint.add}`, async function () {
//       IISAutoTest.performRequest({method: 'post', endpoint: endpoint.add, body: dep.data, expectedStatus: 200, description: 'should create resource successfully',headers: reqheader.add,
//         expectedResponse: (res) => {
//           res.body.should.have.property('message').that.equals('Data inserted successfully.')
//         }
//       })
//     })
//   })

//   it('should update userright and all dependencies dynamically', async function () {
//     IISAutoTest.performRequest({ method: 'post', endpoint: endpoint.update, body: reqbody.update, expectedStatus: 200,description: 'should update resource successfully',headers: reqheader.update,
//       expectedResponse: async (res) => {
//         res.body.should.have.property('message').that.equals('Data updated successfully.');
//         res.should.have.status(200);
//       }
//     });

//     for (const dep of reqbody.dependancy) {
//       it(`should validate ${dep.endpoint.list} and all dependencies dynamically`, async function () {
//         IISAutoTest.performRequest({method: 'post',endpoint: dep.endpoint.list,body: dep.filter,expectedStatus: 200,description: 'dependencies check',headers: reqheader.list,
//           expectedResponse: async (res1) => {
//             res1.should.have.status(200)
//             const records = res1.body.data

//             for (const matchKey of dep.match) {
//               const matchValue = reqbody.update[matchKey]
//               const matchExists = records.some(record => record[matchKey] === matchValue)
//               matchExists.should.be.true
//             }
//           }
//         })
//       })
//     }
//   })

//   // Concurrent requests test
//   it('should handle concurrent requests correctly without data corruption or errors', function (done) {
//     this.timeout(30000);

//     const numConcurrentRequests = 50;
//     const requestBodies = Array(numConcurrentRequests).fill(Config.requestBody)

//     const requestFunctions = requestBodies.map(body => {
//       return (callback) => {
//         chai.request.execute(Config.getBaseurl())
//           .post(endpoint.list)
//           .send(body)
//           .end((err, res) => {
//             if (err) return callback(err)

//             try {
//               res.should.have.status(200)
//               res.body.should.be.a('object')
//               res.body.should.have.property('status').eql(200)
//               callback()
//             } catch (e) {
//               callback(e)
//             }
//           })
//       }
//     })

//     async.parallel(requestFunctions, (err) => {
//       if (err) return done(err)
//       done()
//     })
//   })

// })



