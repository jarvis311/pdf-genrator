import chai from 'chai';
import chaiHttp from 'chai-http';
import { Config, IISAutoTest, IISMethods, FieldConfig } from '../../config/Init.js'

chai.use(chaiHttp);
chai.config.includeStack = true
const { should } = chai
should()

const ObjectId = IISMethods.getobjectid()
const dailyhelpid = new ObjectId()
const bookingid = new ObjectId()
const slots = Array.from({ length: 8 }, () => new ObjectId())
const [slot1, slot2, slot3, slot4, slot5, slot6, slot7, slot8] = slots

const endpoint = {
    list: "/dailyhelp",
    add: "/dailyhelp/add",
    update: "/dailyhelp/update",
    delete: "/dailyhelp/delete"
}

const reqheader = {
    list: { useraction: "viewright", pagename: "dailyhelp", apptype: 1 },
    add: { useraction: "addright", pagename: "dailyhelp", apptype: 1 },
    update: { useraction: "editright", pagename: "dailyhelp", apptype: 1 },
    delete: { useraction: "delright", pagename: "dailyhelp", apptype: 1 },
}



const endpointBooking = {
    list: "/dailyhelp/booking",
    add: "/dailyhelp/booking/add",
    update: "/dailyhelp/booking/update",
    delete: "/dailyhelp/booking/delete",
    slot: "/dailyhelp/assignslot"
}

const reqheaderBooking = {
    list: { useraction: "viewright", pagename: "dailyhelpbooking", apptype: 1 },
    add: { useraction: "addright", pagename: "dailyhelpbooking", apptype: 1 },
    update: { useraction: "editright", pagename: "dailyhelpbooking", apptype: 1 },
    delete: { useraction: "delright", pagename: "dailyhelpbooking", apptype: 1 },
    slot: { useraction: "viewright", pagename: "dailyhelpbooking", apptype: 1 }
}

const reqbodyBooking = {
    add: {
        "_id":bookingid,
        "propertyid": "66aa00c1710be1e36a6de171",
        "propertyname": "Glpl",
        "customerid": "667d1bd1e4314b0db96fd8ea",
        "customer": "Virat Kohli",
        "dailyhelpid": dailyhelpid,
        "dailyhelp": "ground",
        "slot": [
            {
                "starttime": "2024-09-11T09:00:00Z",
                "endtime": "2024-09-11T11:00:00Z",
                "_id": slot1
            }
        ], 
        "rejectreason": ""
    },
    update: {
        _id: bookingid,
        "dailyhelp": "ground Tour",
    },
    delete: {
        _id: bookingid
    },
    filter: {
        searchtext: "",
        paginationinfo: {
            pageno: 1,
            pagelimit: 200000000,
            filter: { "_id": [bookingid.toString(), "66acc53ca826a13d00a88190"] },
            sort: {}
        }
    },
    sort: {
        searchtext: "",
        paginationinfo: {
            pageno: 1,
            pagelimit: 200000000,
            filter: {},
            projection: { dailyhelp: 1 },
            sort: { dailyhelp: 1 }
        }
    },
    search: {
        searchtext: "Gro",
        paginationinfo: {
            pageno: 1,
            pagelimit: 200000000,
            filter: {},
            projection: {},
            sort: {}
        }
    },
    slot: {
        propertyid: "66aa00c1710be1e36a6de171",
        dailyhelpid: dailyhelpid,
        month: "9",
        year: "2024"
    }
}




const reqbody = {
    add: {
        _id: dailyhelpid,
        "_id":"66e28b3adede4d582b7b36e2",
        "disableslot": [
        {
          "starttime":  "2024-09-14T09:00:00.000Z",
          "endtime": "2024-09-14T11:00:00.000Z",
          "propertyid": "64f7a7a0bcd1234567890130",
          "isbooked": 0,
          "_id":  "66e290791534706af6b664c8"
        },
        {
          "starttime":  "2024-09-28T11:00:00.000Z",
          "endtime": "2024-09-28T14:00:00.000Z",
          "propertyid": "64f7a7a0bcd1234567890130",
          "isbooked": 0,
          "_id":  "66e290791534706af6b664c1"
        },
        {
          "starttime":  "2024-08-28T11:00:00.000Z",
          "endtime": "2024-08-28T14:00:00.000Z",
          "propertyid": "64f7a7a0bcd1234567890130",
          "isbooked": 0,
          "_id":  "66e290791534706af6b664c1"
        }
      ],
      "firstname": "John",
      "middlename": "A",
      "lastname": "Doe",
      "personname": "John A Doe",
      "personemail": "john.doe@example.com",
      "contact": "1234567890",
      "businesscontact": "0987654321",
      "countrycode": "+1",
      "profilepic": "https://example.com/profilepic.jpg",
      "genderid": "64f7a7a0bcd1234567890123",
      "gender": "Male",
      "businessaddress": "123 Business St.",
      "countryid": "64f7a7a0bcd1234567890124",
      "country": "USA",
      "stateid": "64f7a7a0bcd1234567890125",
      "state": "California",
      "cityid": "64f7a7a0bcd1234567890126",
      "city": "Los Angeles",
      "pincodeid": "64f7a7a0bcd1234567890127",
      "pincode": "90001",
      "area": "Downtown",
      "emergencyname": "Jane Doe",
      "emergencycontact": "1122334455",
      "websiteURL": "https://example.com",
      "isactive": 1,
      "isdelete": 0,
      "dailyhelpcategory": "Cleaning",
      "dailyhelpcategoryid": "64f7a7a0bcd1234567890128",
      "properrty": [
        {
          "propertyid": "64f7a7a0bcd1234567890129",
          "property": "Apartment 101"
        }
      ],
      "slot": [
        {
          "starttime": "2024-09-15T09:00:00Z",
          "endtime": "2024-09-15T11:00:00Z",
          "propertyid": "64f7a7a0bcd1234567890130",
          "isbooked": 0
        }
      ],
      "isapproved": 1,
      "rejectreason": "",
      "iscancel": 0,
      "cancelreason": "",
      "bankName": "Bank of America",
      "accountNumber": "1234567890",
      "ifscCode": "BOFAUS3N",
      "paymentTerms": "Net 30",
      "certificationsAndLicenses": [
        {
          "documentName": "Business License",
          "documentFile": "https://example.com/license.pdf"
        }
      ],
      "codeOfConduct": "Follow the rules and regulations.",
      "signature": "John Doe",
      "documents": [
        {
          "documentname": "ID Proof",
          "documentfile": "https://example.com/idproof.pdf"
        }
      ]
    },
    update: {
        _id: dailyhelpid,
        "personname": "Het M",
    },
    delete: {
        _id: dailyhelpid
    },
    filter: {
        searchtext: "",
        paginationinfo: {
            pageno: 1,
            pagelimit: 200000000,
            filter: { "_id": [dailyhelpid.toString(), "66acc53ca826a13d00a88190"] },
            sort: {}
        }
    },
    sort: {
        searchtext: "",
        paginationinfo: {
            pageno: 1,
            pagelimit: 200000000,
            filter: {},
            projection: { personname: 1 },
            sort: { personname: 1 }
        }
    },
    search: {
        searchtext: "John",
        paginationinfo: {
            pageno: 1,
            pagelimit: 200000000,
            filter: {},
            projection: {},
            sort: {}
        }
    }
}



describe('dailyhelpBooking', async function () {

    await IISAutoTest.EmployeeAuthTestcase()

    const testCases = IISAutoTest.CommonTestcase({ endpoint, reqbody, reqheader })
    for (const testCase of testCases) {
        IISAutoTest.performRequest(testCase)
    }




  IISAutoTest.performRequest({method: 'post', endpoint: endpointBooking.slot, body: reqbodyBooking.slot, expectedStatus: 200, description: "should return an available slot", headers: reqheaderBooking.slot,
    expectedResponse: (res) => {
        res.should.be.a('object');
        res.body.should.be.a('object');

        res.body.should.have.property('data').that.is.a('array');

        // Variables to track if the slot is available
        let slotFound = false;
        let dateMatched = false;

        for (var obj of reqbodyBooking.add.slot) {
            res.body.data.forEach((item) => {
                if (item.date === obj.starttime.split('T')[0]) {
                    dateMatched = true

                    if (item.slot && item.slot.length > 0) {
                        item.slot.forEach((slot) => {

                            if (dateMatched && slot.starttime === obj.starttime) {
                                slotFound = true;
                               
                                const matchedSlotId = slot._id; // Capture matched slot ID
                                console.log(`Matched Slot ID: ${matchedSlotId}`); // For verification
                            }
                        });
                    }
                }
            });
        }

        slotFound.should.be.true
        dateMatched.should.be.true
    }
});

IISAutoTest.performRequest({method: 'post',endpoint: endpointBooking.slot,body: reqbodyBooking.slot,expectedStatus: 200,description: "should return no available slots",headers: reqheaderBooking.slot,
  expectedResponse: (res) => {
      res.should.be.a('object');
      res.body.should.be.a('object');

      res.body.should.have.property('data').that.is.a('array');

      const requestedDates = reqbodyBooking.add.slot.map(slot => slot.starttime.split('T')[0]);
      let noSlotsAvailable = true;

      requestedDates.forEach(requestedDate => {
          res.body.data.forEach(item => {
              if (item.date === requestedDate) {
                  if (item.slot.length > 0) {
                      noSlotsAvailable = false;
                  }
              }
          });
      });

      noSlotsAvailable.should.be.true
  }
})


    IISAutoTest.performRequest({method: 'post', endpoint: endpointBooking.slot,body: reqbodyBooking.slot,expectedStatus: 200,description: "should return fully booked slots",headers: reqheaderBooking.slot,
        expectedResponse: (res) => {
            res.should.be.a('object');
            res.body.should.be.a('object');

            res.body.should.have.property('data').that.is.a('array');

            let fullyBooked = true;
            for (var obj of reqbodyBooking.add.slot) {
            res.body.data.forEach((item) => {
                if (item.date === obj.starttime.split('T')[0]) {
                    item.slot.forEach((slot) => {
                        if (slot.isbooked === 0) {
                            fullyBooked = false; 
                        }
                    });
                }
            });
          }

          fullyBooked.should.be.true
        }
    })

        const invalidDateReqBody = { ...reqbodyBooking.slot };
        // invalidDateReqBody.add.starttime = '2024/09/10'; 

        // IISAutoTest.performRequest({method: 'post',endpoint: endpointBooking.slot, body: invalidDateReqBody,expectedStatus: 400, 
        //    headers: reqheaderBooking.slot,
        //     expectedResponse: (res) => {
        //         res.should.be.a('object')
        //         res.body.should.have.property('message')
        //         res.body.message.should.include('Invalid date format', 'Expected error message for invalid date format')
        //     }
        // })
    

    IISAutoTest.performRequest({method: 'post',endpoint: endpointBooking.slot,body: reqbodyBooking.slot,expectedStatus: 200,description: "should return an empty array when no data is available",headers: reqheaderBooking.slot,
        expectedResponse: (res) => {
            res.should.be.a('object')
            res.body.should.be.a('object')

            // Ensure response has 'data' property and it's an empty array
            res.body.should.have.property('data').that.is.an('array').that.is.empty
        }
    });


    IISAutoTest.performRequest({method: 'post',endpoint: endpointBooking.slot,body: reqbodyBooking.slot,expectedStatus: 200,description: "should return available slots for 2024-09-10",headers: reqheaderBooking.slot,
        expectedResponse: (res) => {
            res.should.be.a('object');
            res.body.should.be.a('object');

            // Check for specific date
            let slotsAvailable = false;
            res.body.data.forEach((item) => {
                if (item.date === '2024-09-10') {
                    slotsAvailable = item.slot.length > 0 // Check if slots are available
                }
            })

            // Assert slots are available for the specific date
            slotsAvailable.should.equal(true, 'Slots should be available on 2024-09-10');
        }
    })

})




