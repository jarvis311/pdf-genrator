import chai from 'chai';
import chaiHttp from 'chai-http';
import { Config, IISAutoTest, IISMethods, FieldConfig } from '../../config/Init.js'

chai.use(chaiHttp);
chai.config.includeStack = true
const { should } = chai
should()

const ObjectId = IISMethods.getobjectid()
const vendorid = new ObjectId()
const bookingid = new ObjectId()
const slots = Array.from({ length: 8 }, () => new ObjectId())
const [slot1, slot2, slot3, slot4, slot5, slot6, slot7, slot8] = slots

const endpoint = {
    list: "/vendor",
    add: "/vendor/add",
    update: "/vendor/update",
    delete: "/vendor/delete"
}

const reqheader = {
    list: { useraction: "viewright", pagename: "vendor", apptype: 1 },
    add: { useraction: "addright", pagename: "vendor", apptype: 1 },
    update: { useraction: "editright", pagename: "vendor", apptype: 1 },
    delete: { useraction: "delright", pagename: "vendor", apptype: 1 },
}

const reqbody = {
    add: {
        _id: vendorid,
        "seriesid": "60d0fe4f5311236168a109ca",
        "maxid": 1,
        "firstname": "Het1",
        "middlename": "M",
        "lastname": "Patel",
        "personname": "Het1 M Patel",
        "personemail": "jayesh11@gmail.com",
        "contact": "98745632292",
        "businesscontact": "98745632190",
        "countrycode": "IN",
        "profilepic": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAAAeP4ixAAAAAXNSR0IArs4c6QAAA1NJREFUaEPt2r9LclEYB/Cvk6RDYEPhICKCQ0N/gLm0NLhIgQ1OIji4RQ2RSGkE4uImOAgNOrg4BjU4qZNLkIMQ0lBBUFFDhFMvz3m5dl9/dO8951zTeA8Eeu+59zyf+zznEN5jabfbnw6HA1arFfPY+v0+Xl5eYOn1ep/0wev1YnFxca4sb29vuLm5ASXCcn9//2m329mBecIoCIr5/f39L8TpdEJ9YtYzMxzrw8PDF4Rqah4w42Icgcw6ZtKDHguZVcx31TIRMmsYrZL/FjIrGC0ExakJ+WmMHoRuyE9h9CIMQaaNMYIwDJkWxiiCC2I2hgfBDTELw4sQgsjGiCCEIbIwoggpEFGMDIQ0CC9GFkIqxChGJkI6RC9GNsIUiBbGDIRpkEkYsxCmQoYx9N3MHzd0/RtPQfA2JQt0vZm/0PyH6MmQek7MbWmNm9hzN9m/C9gsjPQ5oidQPX30lK66j1SIkQCN9NWDkgbhCYznmkkoKRCRgESulVpaMgKRcQ+hjMgIQHmqovfihogOPK7WRe7JBREZUGsF4r23YQjvQFoA9XmeMQxBeAYwAhDB6IZME8GzAOiC/ATCKEYTwot4fn5GJBLBxcUFiymTySCVSqHZbGJ9fZ0dK5fLrM+49vHxgd3dXRSLRXZ6a2sLhUIBr6+v2NnZwdXV1eCedN60V2/dbhelUgnpdBoLCwssGMIlk0mcnp7CZrPh6OgIsVgMPp9vxKLuu7S0xN42dzodVKtVJBIJds3JyQk2Njbg9/snQ3gzoUSkfvJra2ssAGrn5+fsSVOrVCpwu92o1+vweDwsO3Ss1+shHA4Pnjz1bTQaoL0AuVwOx8fHWF5eZtm9vb1l15n2epoCokaDKNmhzxS0GqL0yefzoN0Xj4+PgxKkvlSOSnb29vZwdnaGYDCI1dVVXF9fs/tRn6lsGFACiUajaLVaIxmh0hguJXWt0XyhMtze3sbl5SXi8Tju7u7w9PTE/kYyIlpO6sHV9UslQE+OanvcHHG5XCxQAlFfmle1Wm0kowcHB8hms2xeraysgL6HQiFsbm5+ZUT2phr1qkUDUanRpB1etWg1olILBAL/zJH9/f3BqqXMMZrgVKbKqnV4eMhWs8Gmml+zzem3bDz7Azf0RKt+wu2dAAAAAElFTkSuQmCC",
        "genderid": "6221dc42c85eb209a703eb00",
        "gender": "Male",
        "businessaddress": "Shivaan avenue",
        "countryid": "628dddec9ed69439d028a663",
        "country": "India",
        "stateid": "628df13f8957f1ddc3f014d9",
        "state": "Gujarat",
        "cityid": "628e0f9f54946738e80be4a5",
        "city": "Surat",
        "pincodeid": "628e0f9f54946738e80be4a5",
        "pincode": "394005",
        "area": "Coseway",
        "emergencyname": "Emergency Contact",
        "emergencycontact": "9874567890",
        "websiteURL": "http://example.com",
        "isactive": 1,
        "isdelete": 0,
        "deliverytype": "Type1",
        "deliverytypeid": "62e23d73798ba64178f1d2ba",
        "businessStructure": "Structure1",
        "businessStructureid": "62e23d73798ba64178f1d2ba",
        "bankName": "Bank Name",
        "accountNumber": "1234567890",
        "ifscCode": "IFSC0001",
        "paymentTerms": "Net 30",
        "certificationsAndLicenses": [
            {
                "documentName": "Certification 1",
                "documentFile": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAAAeP4ixAAAAAXNSR0IArs4c6QAAA1NJREFUaEPt2r9LclEYB/Cvk6RDYEPhICKCQ0N/gLm0NLhIgQ1OIji4RQ2RSGkE4uImOAgNOrg4BjU4qZNLkIMQ0lBBUFFDhFMvz3m5dl9/dO8951zTeA8Eeu+59zyf+zznEN5jabfbnw6HA1arFfPY+v0+Xl5eYOn1ep/0wev1YnFxca4sb29vuLm5ASXCcn9//2m329mBecIoCIr5/f39L8TpdEJ9YtYzMxzrw8PDF4Rqah4w42Icgcw6ZtKDHguZVcx31TIRMmsYrZL/FjIrGC0ExakJ+WmMHoRuyE9h9CIMQaaNMYIwDJkWxiiCC2I2hgfBDTELw4sQgsjGiCCEIbIwoggpEFGMDIQ0CC9GFkIqxChGJkI6RC9GNsIUiBbGDIRpkEkYsxCmQoYx9N3MHzd0/RtPQfA2JQt0vZm/0PyH6MmQek7MbWmNm9hzN9m/C9gsjPQ5oidQPX30lK66j1SIkQCN9NWDkgbhCYznmkkoKRCRgESulVpaMgKRcQ+hjMgIQHmqovfihogOPK7WRe7JBREZUGsF4r23YQjvQFoA9XmeMQxBeAYwAhDB6IZME8GzAOiC/ATCKEYTwot4fn5GJBLBxcUFiymTySCVSqHZbGJ9fZ0dK5fLrM+49vHxgd3dXRSLRXZ6a2sLhUIBr6+v2NnZwdXV1eCedN60V2/dbhelUgnpdBoLCwssGMIlk0mcnp7CZrPh6OgIsVgMPp9vxKLuu7S0xN42dzodVKtVJBIJds3JyQk2Njbg9/snQ3gzoUSkfvJra2ssAGrn5+fsSVOrVCpwu92o1+vweDwsO3Ss1+shHA4Pnjz1bTQaoL0AuVwOx8fHWF5eZtm9vb1l15n2epoCokaDKNmhzxS0GqL0yefzoN0Xj4+PgxKkvlSOSnb29vZwdnaGYDCI1dVVXF9fs/tRn6lsGFACiUajaLVaIxmh0hguJXWt0XyhMtze3sbl5SXi8Tju7u7w9PTE/kYyIlpO6sHV9UslQE+OanvcHHG5XCxQAlFfmle1Wm0kowcHB8hms2xeraysgL6HQiFsbm5+ZUT2phr1qkUDUanRpB1etWg1olILBAL/zJH9/f3BqqXMMZrgVKbKqnV4eMhWs8Gmml+zzem3bDz7Azf0RKt+wu2dAAAAAElFTkSuQmCC",
                "issuedBy": "Authority 1",
                "issuedDate": "2023-01-01",
                "expiryDate": "2025-01-01",
                "isValid": 1
            }
        ],
        "contactperson": [
            {
                "contactname": "John Doe",
                "contactnumber": "9876543210",
                "contactemail": "johndoe@example.com",
                "position": "Manager"
            }
        ],
        "businessCategory": [
            {
                "categoryid": "62e23d73798ba64178f1d2bb",
                "category": "Category 1"
            }
        ],
        "businessType": [
            {
                "typeid": "62e23d73798ba64178f1d2bc",
                "type": "Type 1"
            }
        ],
        "isapproved": 1,
        "isdeclined": 0,
        "vendorList": [
            {
                "vendorid": "vendor1",
                "vendorName": "Vendor 1",
                "vendorContact": "1234567890",
                "vendorEmail": "vendor1@example.com"
            }
        ]
    },
    update: {
        _id: vendorid,
        personname: "Het1",
    },
    delete: {
        _id: vendorid
    },
    filter: {
        searchtext: "",
        paginationinfo: {
            pageno: 1,
            pagelimit: 200000000,
            filter: { "_id": [vendorid.toString(), "66acc53ca826a13d00a88190"] },
            sort: {}
        }
    },
    sort: {
        searchtext: "",
        paginationinfo: {
            pageno: 1,
            pagelimit: 200000000,
            filter: {},
            projection: { personname: 1 },
            sort: { personname: 1 }
        }
    },
    search: {
        searchtext: "Gro",
        paginationinfo: {
            pageno: 1,
            pagelimit: 200000000,
            filter: {},
            projection: {},
            sort: {}
        }
    }
}


// const invalidDataTests = [
//     {
//         data: {
//             "propertyid": "66aa00c1710be1e36a6de171",
//             "propertyname": "",
//             "areatypeid": "66dede7108cbbd28104d25eb",
//             "areatype": "",
//             "vendor": "ground",
//             "capacitycount": "100",
//             "charges": "2000",

//             "capacitydescription": "Spacious area with modern amenities.",
//             "amenities": "WiFi, AC, Parking",
//             "description": "This is a premium property located in the heart of the city.",
//             "rules_regulations": "No pets allowed, No smoking indoors",

//             "contact": [
//                 {
//                     "countrycode": "+1",
//                     "phonenumber": "1234567890"
//                 }
//             ],
//             "timeslot": [
//                 {
//                     "starttime": "2023-08-31T00:00:00.000Z",
//                     "endtime": "2023-08-31T03:00:00.000Z"
//                 },
//                 {
//                     "starttime": "2023-08-31T03:00:00.000Z",
//                     "endtime": "2023-08-31T06:00:00.000Z"
//                 },
//                 {
//                     "starttime": "2023-08-31T06:00:00.000Z",
//                     "endtime": "2023-08-31T09:00:00.000Z"
//                 },
//                 {
//                     "starttime": "2023-08-31T09:00:00.000Z",
//                     "endtime": "2023-08-31T12:00:00.000Z"
//                 },
//                 {
//                     "starttime": "2023-08-31T12:00:00.000Z",
//                     "endtime": "2023-08-31T15:00:00.000Z"
//                 },
//                 {
//                     "starttime": "2023-08-31T15:00:00.000Z",
//                     "endtime": "2023-08-31T18:00:00.000Z"
//                 },
//                 {
//                     "starttime": "2023-08-31T18:00:00.000Z",
//                     "endtime": "2023-08-31T21:00:00.000Z"
//                 },
//                 {
//                     "starttime": "2023-08-31T21:00:00.000Z",
//                     "endtime": "2023-09-01T00:00:00.000Z"
//                 }
//             ],
//             "email": "sample@property.com",
//             "areaplan": "plan123.pdf",
//             "image": [
//                 {
//                     "url": "https://example.com/image1.jpg",
//                     "alt": "Image description"
//                 },
//                 {
//                     "url": "https://example.com/image2.jpg",
//                     "alt": "Another image description"
//                 }
//             ]
//         },
//         expectedError: 'Path `propertyname` is required.,Path `areatype` is required.',
//         description: 'should return an error for empty name'
//     },
//     {
//         data: {
//             "propertyid": "66aa00c1710be1e36a6de171",
//             "propertyname": "Glpl",
//             "areatypeid": "66dede7108cbbd28104d25eb",
//             "areatype": "Medium",
//             "vendor": "ground",
//             "capacitycount": "100",
//             "charges": "2000",

//             "capacitydescription": "Spacious area with modern amenities.",
//             "amenities": "WiFi, AC, Parking",
//             "description": "This is a premium property located in the heart of the city.",
//             "rules_regulations": "No pets allowed, No smoking indoors",

//             "contact": [
//                 {
//                     "countrycode": "+1",
//                     "phonenumber": "1234567890"
//                 }
//             ],
//             "timeslot": [
//                 {
//                     "starttime": "",
//                     "endtime": ""
//                 }
//             ],
//             "email": "sample@property.com",
//             "areaplan": "plan123.pdf",
//             "image": [
//                 {
//                     "url": "https://example.com/image1.jpg",
//                     "alt": "Image description"
//                 },
//                 {
//                     "url": "https://example.com/image2.jpg",
//                     "alt": "Another image description"
//                 }
//             ]
//         },
//         expectedError: 'Path `starttime` is required.,Path `endtime` is required.',
//         description: 'should return an error for not select timeslot'
//     }
// ]


describe('vendorBooking', async function () {

    await IISAutoTest.EmployeeAuthTestcase()

    const testCases = IISAutoTest.CommonTestcase({ endpoint, reqbody, reqheader })
    for (const testCase of testCases) {
        IISAutoTest.performRequest(testCase)
    }

})



const endpointBooking = {
    list: "/vendorbooking",
    add: "/vendorbooking/add",
    update: "/vendorbooking/update",
    delete: "/vendorbooking/delete",
    slot: "/assignslot"
}

const reqheaderBooking = {
    list: { useraction: "viewright", pagename: "vendor", apptype: 1 },
    add: { useraction: "addright", pagename: "vendor", apptype: 1 },
    update: { useraction: "editright", pagename: "vendor", apptype: 1 },
    delete: { useraction: "delright", pagename: "vendor", apptype: 1 },
    slot: { useraction: "viewright", pagename: "vendor", apptype: 1 }
}

const reqbodyBooking = {
    add: {
        "_id":vendorid,
        "propertyid": "66aa00c1710be1e36a6de171", 
        "property": "Glpl",          
        "customerid": "64c9a2e8d9b9c1a4f8cde4f3",   
        "customer": "John Doe", 
        "vendorid":"66a1f5cbb335306f2b7879a8",
        "vendor":"Het1 M Patel",                    
        "isbooked": 1,     
        "phonenumber":"96578545632",                      
        "rejectreason": "" 
    },
    update: {
        _id: bookingid,
        "vendor": "ground Tour",
    },
    delete: {
        _id: bookingid
    },
    filter: {
        searchtext: "",
        paginationinfo: {
            pageno: 1,
            pagelimit: 200000000,
            filter: { "_id": [bookingid.toString(), "66acc53ca826a13d00a88190"] },
            sort: {}
        }
    },
    sort: {
        searchtext: "",
        paginationinfo: {
            pageno: 1,
            pagelimit: 200000000,
            filter: {},
            projection: { vendor: 1 },
            sort: { vendor: 1 }
        }
    },
    search: {
        searchtext: "He",
        paginationinfo: {
            pageno: 1,
            pagelimit: 200000000,
            filter: {},
            projection: {},
            sort: {}
        }
    }
}



describe('vendorBooking', async function () {

  IISAutoTest.performRequest({method: 'post', endpoint: endpointBooking.slot, body: reqbodyBooking.slot, expectedStatus: 200, description: "should return an available slot", headers: reqheaderBooking.slot,
    expectedResponse: (res) => {
        res.should.be.a('object');
        res.body.should.be.a('object');

        res.body.should.have.property('data').that.is.a('array');

        // Variables to track if the slot is available
        let slotFound = false;
        let dateMatched = false;

        for (var obj of reqbodyBooking.add.slot) {
            res.body.data.forEach((item) => {
                if (item.date === obj.starttime.split('T')[0]) {
                    dateMatched = true

                    if (item.slot && item.slot.length > 0) {
                        item.slot.forEach((slot) => {

                            if (dateMatched && slot.starttime === obj.starttime) {
                                slotFound = true;
                               
                                const matchedSlotId = slot._id; // Capture matched slot ID
                                console.log(`Matched Slot ID: ${matchedSlotId}`); // For verification
                            }
                        });
                    }
                }
            });
        }

        slotFound.should.be.true
        dateMatched.should.be.true
    }
});

IISAutoTest.performRequest({method: 'post',endpoint: endpointBooking.slot,body: reqbodyBooking.slot,expectedStatus: 200,description: "should return no available slots",headers: reqheaderBooking.slot,
  expectedResponse: (res) => {
      res.should.be.a('object');
      res.body.should.be.a('object');

      res.body.should.have.property('data').that.is.a('array');

      const requestedDates = reqbodyBooking.add.slot.map(slot => slot.starttime.split('T')[0]);
      let noSlotsAvailable = true;

      requestedDates.forEach(requestedDate => {
          res.body.data.forEach(item => {
              if (item.date === requestedDate) {
                  if (item.slot.length > 0) {
                      noSlotsAvailable = false;
                  }
              }
          });
      });

      noSlotsAvailable.should.be.true
  }
})


    IISAutoTest.performRequest({method: 'post', endpoint: endpointBooking.slot,body: reqbodyBooking.slot,expectedStatus: 200,description: "should return fully booked slots",headers: reqheaderBooking.slot,
        expectedResponse: (res) => {
            res.should.be.a('object');
            res.body.should.be.a('object');

            res.body.should.have.property('data').that.is.a('array');

            let fullyBooked = true;
            for (var obj of reqbodyBooking.add.slot) {
            res.body.data.forEach((item) => {
                if (item.date === obj.starttime.split('T')[0]) {
                    item.slot.forEach((slot) => {
                        if (slot.isbooked === 0) {
                            fullyBooked = false; 
                        }
                    });
                }
            });
          }

          fullyBooked.should.be.true
        }
    })

        const invalidDateReqBody = { ...reqbodyBooking.slot };
        invalidDateReqBody.add.starttime = '2024/09/10'; 

        IISAutoTest.performRequest({method: 'post',endpoint: endpointBooking.slot, body: invalidDateReqBody,expectedStatus: 400, 
           headers: reqheaderBooking.slot,
            expectedResponse: (res) => {
                res.should.be.a('object')
                res.body.should.have.property('message')
                res.body.message.should.include('Invalid date format', 'Expected error message for invalid date format')
            }
        })
    

    IISAutoTest.performRequest({method: 'post',endpoint: endpointBooking.slot,body: reqbodyBooking.slot,expectedStatus: 200,description: "should return an empty array when no data is available",headers: reqheaderBooking.slot,
        expectedResponse: (res) => {
            res.should.be.a('object')
            res.body.should.be.a('object')

            // Ensure response has 'data' property and it's an empty array
            res.body.should.have.property('data').that.is.an('array').that.is.empty
        }
    });


    IISAutoTest.performRequest({method: 'post',endpoint: endpointBooking.slot,body: reqbodyBooking.slot,expectedStatus: 200,description: "should return available slots for 2024-09-10",headers: reqheaderBooking.slot,
        expectedResponse: (res) => {
            res.should.be.a('object');
            res.body.should.be.a('object');

            // Check for specific date
            let slotsAvailable = false;
            res.body.data.forEach((item) => {
                if (item.date === '2024-09-10') {
                    slotsAvailable = item.slot.length > 0 // Check if slots are available
                }
            })

            // Assert slots are available for the specific date
            slotsAvailable.should.equal(true, 'Slots should be available on 2024-09-10');
        }
    })


    const testCases = IISAutoTest.CommonTestcase({ endpoint: endpointBooking, reqbody: reqbodyBooking, reqheader: reqheaderBooking })
    for (const testCase of testCases) {
        IISAutoTest.performRequest(testCase)
    }


    IISAutoTest.performRequest({
        method: 'post', endpoint: endpointBooking.slot, body: reqbodyBooking.slot, expectedStatus: 200, description: "Approve slot", headers: reqheaderBooking.slot,
        expectedResponse: (res) => {
            res.should.be.a('object')
            res.body.should.be.a('object')
        }
    })
})




