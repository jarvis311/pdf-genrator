import chai from 'chai';
import chaiHttp from 'chai-http';
import { Config, IISAutoTest, IISMethods,FieldConfig } from '../../config/Init.js'
import async from 'async'

chai.use(chaiHttp);
chai.config.includeStack = true
const { should} = chai
should()

const ObjectId = IISMethods.getobjectid()
const eventid = new ObjectId()
const stateid = new ObjectId()
const cityid = new ObjectId()

const endpoint = {
  list: "/event",
  add: "/event/add",
  update: "/event/update",
  delete: "/event/delete",
  dataname :"Event"
};

const reqheader = {
  list:{useraction:"viewright",pagename:"event",apptype:1},
  add:{useraction:"addright",pagename:"event",apptype:1},
  update:{useraction:"editright",pagename:"event",apptype:1},
  delete:{useraction:"delright",pagename:"event",apptype:1},
}

const reqbody = {
  add: {
    _id: eventid,
    "title": "Annual Tech Conference",
    "eventcategoryid": "64e10f5a3f9a9f00212b0e29", 
    "eventcategory": "Technology",
    "location": "New York City",
    "description": "A conference to showcase new technology trends.",
    "image": { "url": "https://example.com/image.png", "alt": "Event Image" },
    "ispresent": 1,
    "eventdate": "2024-10-10",
    "eventtime": "10:00 AM",
    "eventformtdate": "10th October, 2024",
    "isactive": 1
  },
  update: {
    _id: eventid,
    "title": "Annual",
    "eventcategoryid": "64e10f5a3f9a9f00212b0e29",
    "eventcategory": "Technology",
    "location": "New York City",
    "description": "A conference to showcase new technology trends.",
    "image": { "url": "https://example.com/image.png", "alt": "Event Image" },
    "ispresent": 1,
    "eventdate": "2024-10-10",
    "eventtime": "10:00 AM",
    "eventformtdate": "10th October, 2024",
    "isactive": 1
  },
  delete: {
    _id: eventid
  },
  filter: {
    searchtext: "",
    paginationinfo: {
      pageno: 1,
      pagelimit: 200000000,
      filter: { "_id": [eventid.toString(),"66acc53ca826a13d00a88190"] },
      sort: {}
    }
  },
  sort: {
    searchtext: "",
    paginationinfo: {
      pageno: 1,
      pagelimit: 200000000,
      filter: {},
      projection: { title: 1 },
      sort: { title: 1 }
    }
  },
  search: {
    searchtext: "In",
    paginationinfo: {
      pageno: 1,
      pagelimit: 200000000,
      filter: {},
      projection: {},
      sort: {}
    }
  },
  dependancy: [
    {
      endpoint: { list: "/state", add: "/state/add" },
      match: ['event'],
      body: {
        _id: stateid,
        state: "mp",
        eventid: eventid,
        event: "German"
      },
      filter: {
        searchtext: "",
        paginationinfo: {
          pageno: 1,
          pagelimit: 2000,
          filter: { "countyid": [eventid] },
          projection: {},
          sort: {}
        }
      }
    },
    {
      endpoint: { list: "/city", add: "/city/add" },
      match: ['event'],
      body: {
        _id: cityid,
        city: "surat",
        stateid: stateid,
        state: "mp",
        eventid: eventid,
        event: "German"
      },
      filter: {
        searchtext: "",
        paginationinfo: {
          pageno: 1,
          pagelimit: 2000,
          filter: { "countyid": [stateid] },
          projection: {},
          sort: {}
        }
      }
    }
  ]
}


const invalidDataTests = [
  {
    data: {
      "title": "",
      "eventcategoryid": "64e10f5a3f9a9f00212b0e29",
      "eventcategory": "Technology",
      "location": "New York City",
      "description": "",
      "image": { "url": "https://example.com/image.png", "alt": "Event Image" },
      "ispresent": 1,
      "eventdate": "2024-10-10",
      "eventtime": "10:00 AM",
      "eventformtdate": "10th October, 2024",
      "isactive": 1
    },
    expectedError: 'Path `title` is required.,Path `description` is required.',
    description: 'should return an error for empty event name'
  },
  {
    data: {
      "title": "",
      "eventcategoryid": "64e10f5a3f9a9f00212b0e29",
      "eventcategory": "Technology",
      "location": "New York City",
      "description": "best place ever",
      "image": { "url": "https://example.com/image.png", "alt": "Event Image" },
      "ispresent": 1,
      "eventdate": "2024-10-10",
      "eventtime": "10:00 AM",
      "eventformtdate": "10th October, 2024",
      "isactive": 1
    },
    expectedError: 'Path `title` is required.',
    description: 'should return an error for required parameter'
  }
]


describe('Cruds', async function () {

 await IISAutoTest.EmployeeAuthTestcase()

 const testCases = IISAutoTest.CommonTestcase({ endpoint, reqbody,reqheader})
  for (const testCase of testCases) {
    IISAutoTest.performRequest(testCase)
  }
  
  //diffrent scenario test
  for (const dep of invalidDataTests) {
     IISAutoTest.performRequest({method: 'post',endpoint: endpoint.add,body: dep.data,expectedStatus: 400,description: dep.description,headers: reqheader.add,
        expectedResponse: (res) => {
          res.should.be.a('object')
          res.body.should.be.a('object')
          res.body.should.have.property('message').that.equals(dep.expectedError)
        }
      })
  }


  //dependancy testcase   
  reqbody.dependancy.forEach(dep => {
    it(`should insert data into ${dep.endpoint.add}`, async function () {
      IISAutoTest.performRequest({method: 'post', endpoint: endpoint.add, body: dep.data, expectedStatus: 200, description: 'should create resource successfully',headers: reqheader.add,
        expectedResponse: (res) => {
          res.body.should.have.property('message').that.equals('Data inserted successfully.')
        }
      })
    })
  })

  it('should update event and all dependencies dynamically', async function () {
    IISAutoTest.performRequest({ method: 'post', endpoint: endpoint.update, body: reqbody.update, expectedStatus: 200,description: 'should update resource successfully',reqheader: reqheader.update,
      expectedResponse: async (res) => {
        res.body.should.have.property('message').that.equals('Data updated successfully.');
        res.should.have.status(200);
      }
    });

    for (const dep of reqbody.dependancy) {
      it(`should validate ${dep.endpoint.list} and all dependencies dynamically`, async function () {
        IISAutoTest.performRequest({method: 'post',endpoint: dep.endpoint.list,body: dep.filter,expectedStatus: 200,description: 'dependencies check',headers: reqheader.list,
          expectedResponse: async (res1) => {
            res1.should.have.status(200)
            const records = res1.body.data

            for (const matchKey of dep.match) {
              const matchValue = reqbody.update[matchKey]
              const matchExists = records.some(record => record[matchKey] === matchValue)
              matchExists.should.be.true
            }
          }
        })
      })
    }
  })

  // Concurrent requests test
  it('should handle concurrent requests correctly without data corruption or errors', function (done) {
    this.timeout(30000);

    const numConcurrentRequests = 50;
    const requestBodies = Array(numConcurrentRequests).fill(Config.requestBody)

    const requestFunctions = requestBodies.map(body => {
      return (callback) => {
        chai.request.execute(Config.getBaseurl())
          .post(endpoint.list)
          .send(body)
          .end((err, res) => {
            if (err) return callback(err)

            try {
              res.should.have.status(200)
              res.body.should.be.a('object')
              res.body.should.have.property('status').eql(200)
              callback()
            } catch (e) {
              callback(e)
            }
          })
      }
    })

    async.parallel(requestFunctions, (err) => {
      if (err) return done(err)
      done()
    })
  })

})



