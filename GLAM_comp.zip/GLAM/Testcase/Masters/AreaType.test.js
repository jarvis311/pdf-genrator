import chai from 'chai';
import chaiHttp from 'chai-http';
import { Config, IISAutoTest, IISMethods } from '../../config/Init.js'

chai.use(chaiHttp);
chai.config.includeStack = true
const { should } = chai
should()

const ObjectId = IISMethods.getobjectid()
const areatypeid = new ObjectId()

const endpoint = {
  list: "/areatype",
  add: "/areatype/add",
  update: "/areatype/update",
  delete: "/areatype/delete",
  dataname :"AreaType"
}

const reqheader = {
  list: { useraction: "viewright", pagename: "areatype", apptype: 1 },
  add: { useraction: "addright", pagename: "areatype", apptype: 1 },
  update: { useraction: "editright", pagename: "areatype", apptype: 1 },
  delete: { useraction: "delright", pagename: "areatype", apptype: 1 }
}

const reqbody = {
  add: {
    _id: areatypeid,
    areatype:"SWIGGY",
    isactive:1
  },
  update: {
    _id: areatypeid,
    areatype: "SWIGGYs"
  },
  delete: {
    _id: areatypeid
  },
  filter: {
    searchtext: "",
    paginationinfo: {
      pageno: 1,
      pagelimit: 200000000,
      filter: { "_id": [areatypeid.toString()] },
      sort: {}
    }
  },
  sort: {
    searchtext: "",
    paginationinfo: {
      pageno: 1,
      pagelimit: 200000000,
      filter: {},
      projection: { areatype: 1 },
      sort: { areatype: 1 }
    }
  },
  search: {
    searchtext: "sw",
    paginationinfo: {
      pageno: 1,
      pagelimit: 200000000,
      filter: {},
      projection: {},
      sort: {}
    }
  }
}


const invalidDataTests = [
  {
    data: {
        areatype: "",
        isactive: 1
    },
    expectedError: 'Path `areatype` is required.',
    description: 'should return an error for empty name'
  },
  {
    data: {
        areatype: "SWIGGYs",
        isactive: 1
    },
    expectedError: 'Data already exist.',
    description: 'should return an error for data already exist'
  }
]

describe('Cruds', async function () {

  await IISAutoTest.EmployeeAuthTestcase()
 
  const testCases = IISAutoTest.CommonTestcase({ endpoint, reqbody,reqheader})
   for (const testCase of testCases) {
     IISAutoTest.performRequest(testCase)
   }
   
   //diffrent scenario test
   for (const dep of invalidDataTests) {
      IISAutoTest.performRequest({method: 'post',endpoint: endpoint.add,body: dep.data,expectedStatus: 400,description: dep.description,headers: reqheader.add,
         expectedResponse: (res) => {
           res.should.be.a('object')
           res.body.should.be.a('object')
           res.body.should.have.property('message').that.equals(dep.expectedError)
         }
       })
   }
 

})









