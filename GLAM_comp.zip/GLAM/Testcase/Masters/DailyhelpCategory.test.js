import chai from 'chai';
import chaiHttp from 'chai-http';
import { Config, IISAutoTest, IISMethods } from '../../config/Init.js'


chai.use(chaiHttp);
chai.config.includeStack = true
const { should} = chai
should()

const ObjectId = IISMethods.getobjectid()
const categoryid = new ObjectId()

const endpoint = {
  list: "/dailyhelpcategory",
  add: "/dailyhelpcategory/add",
  update: "/dailyhelpcategory/update",
  delete: "/dailyhelpcategory/delete",
  dataname :"Daily Help Category"
}

const reqheader = {
  list: { useraction: "viewright", pagename: "dailyhelpcategory", apptype: 1 },
  add: { useraction: "addright", pagename: "dailyhelpcategory", apptype: 1 },
  update: { useraction: "editright", pagename: "dailyhelpcategory", apptype: 1 },
  delete: { useraction: "delright", pagename: "dailyhelpcategory", apptype: 1 },
}

const reqbody = {
  add: {
    _id: categoryid,
    category: "tes",
    isactive: 1
  },
  update: {
    _id: categoryid,
    category: "test",
    isactive: 1
  },
  delete: {
    _id: categoryid
  },
  filter: {
    searchtext: "",
    paginationinfo: {
      pageno: 1,
      pagelimit: 200000000,
      filter: { "_id": [categoryid.toString(),"66acc53ca826a13d00a88190"] },
      sort: {}
    }
  },
  sort: {
    searchtext: "",
    paginationinfo: {
      pageno: 1,
      pagelimit: 200000000,
      filter: {},
      projection: { category: 1 },
      sort: { category: 1 }
    }
  },
  search: {
    searchtext: "tes",
    paginationinfo: {
      pageno: 1,
      pagelimit: 200000000,
      filter: {},
      projection: {},
      sort: {}
    }
  },
//   dependancy: [
//     {
//       endpoint: { list: "/state", add: "/state/add" },
//       match: ['country'],
//       body: {
//         _id: stateid,
//         state: "mp",
//         categoryid: categoryid,
//         country: "German"
//       },
//       filter: {
//         searchtext: "",
//         paginationinfo: {
//           pageno: 1,
//           pagelimit: 2000,
//           filter: { "countyid": [categoryid] },
//           projection: {},
//           sort: {}
//         }
//       }
//     },
//     {
//       endpoint: { list: "/city", add: "/city/add" },
//       match: ['country'],
//       body: {
//         _id: cityid,
//         city: "surat",
//         stateid: stateid,
//         state: "mp",
//         categoryid: categoryid,
//         country: "German"
//       },
//       filter: {
//         searchtext: "",
//         paginationinfo: {
//           pageno: 1,
//           pagelimit: 2000,
//           filter: { "countyid": [stateid] },
//           projection: {},
//           sort: {}
//         }
//       }
//     }
//   ]
}


const invalidDataTests = [
  {
    data: {
      category: "",
      isactive: 1,
    },
    expectedError: 'Path `category` is required.',
    description: 'should return an error for empty category name'
  },
  {
    data: {
    category: "test",
    isactive: 1
    },
    expectedError: 'Data already exist.',
    description: 'should return an error for data already exist'
  }
]

describe('Cruds', async function () {

  await IISAutoTest.EmployeeAuthTestcase()
 
  const testCases = IISAutoTest.CommonTestcase({ endpoint, reqbody,reqheader})
   for (const testCase of testCases) {
     IISAutoTest.performRequest(testCase)
   }
   
   //diffrent scenario test
   for (const dep of invalidDataTests) {
      IISAutoTest.performRequest({method: 'post',endpoint: endpoint.add,body: dep.data,expectedStatus: 400,description: dep.description,headers: reqheader.add,
         expectedResponse: (res) => {
           res.should.be.a('object')
           res.body.should.be.a('object')
           res.body.should.have.property('message').that.equals(dep.expectedError)
         }
       })
   }


  //dependancy testcase   
  // reqbody.dependancy.forEach(dep => {
  //   it(`should insert data into ${dep.endpoint.add}`, async function () {
  //     IISAutoTest.performRequest({
  //       method: 'post', endpoint: endpoint.add, body: dep.data, expectedStatus: 200, description: 'should create resource successfully',
  //       expectedResponse: (res) => {
  //         res.body.should.have.property('message').that.equals('Data inserted successfully.')
  //       }
  //     })
  //   })
  // })

})



