import chai from 'chai';
import chaiHttp from 'chai-http';
import { Config, IISAutoTest, IISMethods } from '../../config/Init.js'


chai.use(chaiHttp);
chai.config.includeStack = true
const { should } = chai
should()

const ObjectId = IISMethods.getobjectid()
const companyid = new ObjectId()

const endpoint = {
  list: "/checklisttype",
  add: "/checklisttype/add",
  update: "/checklisttype/update",
  delete: "/checklisttype/delete",
  dataname :"CheckListType"
}

const reqheader = {
  list: { useraction: "viewright", pagename: "checklisttype", apptype: 1 },
  add: { useraction: "addright", pagename: "checklisttype", apptype: 1 },
  update: { useraction: "editright", pagename: "checklisttype", apptype: 1 },
  delete: { useraction: "delright", pagename: "checklisttype", apptype: 1 },
}

const reqbody = {
  add: {
    _id: companyid,
    checklisttype:"SWIGGY",
    status:1
  },
  update: {
    _id: companyid,
    checklisttype: "SWIGGYs"
  },
  delete: {
    _id: companyid
  },
  filter: {
    searchtext: "",
    paginationinfo: {
      pageno: 1,
      pagelimit: 200000000,
      filter: { "_id": [companyid.toString(),"66acc53ca826a13d00a88190"] },
      sort: {}
    }
  },
  sort: {
    searchtext: "",
    paginationinfo: {
      pageno: 1,
      pagelimit: 200000000,
      filter: {},
      projection: { checklisttype: 1 },
      sort: { checklisttype: 1 }
    }
  },
  search: {
    searchtext: "sw",
    paginationinfo: {
      pageno: 1,
      pagelimit: 200000000,
      filter: {},
      projection: {},
      sort: {}
    }
  }
}


const invalidDataTests = [
  {
    data: {
        checklisttype: "",
        status: 1
    },
    expectedError: 'Path `checklisttype` is required.',
    description: 'should return an error for empty name'
  }
]

let authDetails

describe('Cruds', async function () {

  await IISAutoTest.EmployeeAuthTestcase()
 
  const testCases = IISAutoTest.CommonTestcase({ endpoint, reqbody,reqheader})
   for (const testCase of testCases) {
     IISAutoTest.performRequest(testCase)
   }
   
   //diffrent scenario test
   for (const dep of invalidDataTests) {
      IISAutoTest.performRequest({method: 'post',endpoint: endpoint.add,body: dep.data,expectedStatus: 400,description: dep.description,header: reqheader.add,
         expectedResponse: (res) => {
           res.should.be.a('object')
           res.body.should.be.a('object')
           res.body.should.have.property('message').that.equals(dep.expectedError)
         }
       })
   }
 
})









