import chai from 'chai';
import chaiHttp from 'chai-http';
import { Config, IISAutoTest, IISMethods } from '../../config/Init.js'


chai.use(chaiHttp);
chai.config.includeStack = true;

const { should, expect } = chai;
should();

const ObjectId = IISMethods.getobjectid()
const pincodeid = new ObjectId()

const endpoint = {
    list: "/pincode",
    add: "/pincode/add",
    update: "/pincode/update",
    delete: "/pincode/delete",
    dataname :"Pincode"
}

const reqheader = {
  list: { useraction: "viewright", pagename: "pincode", apptype: 1 },
  add: { useraction: "addright", pagename: "pincode", apptype: 1 },
  update: { useraction: "editright", pagename: "pincode", apptype: 1 },
  delete: { useraction: "delright", pagename: "pincode", apptype: 1 },
}

const reqbody = {
    add: {
        _id: pincodeid,
        pincode:395006,
        area:"ns",
        stateid: "628df13f8957f1ddc3f014d9",
        state: "Gujarat",
        countryid: "62ac27b8f829ef6999b3526c",
        country: "India",
        city: "kp",
        cityid:"62ac27b8f829ef6999b3526b",
        status: 1
    },
    update: {
        _id: pincodeid,
        pincode:395006,
        stateid: "628df13f8957f1ddc3f014d9",
        state: "Gujarat",
        countryid: "62ac27b8f829ef6999b3526c",
        country: "bhavnagar",
        status: 1
    },
    delete: {
        _id: pincodeid
    },
    filter: {
      searchtext: "",
      paginationinfo: {
          pageno: 1,
          pagelimit: 2000,
          filter: { "_id":[pincodeid.toString(),'66ebf4ce4b64029be9e171a5'] },
          projection: {},
          sort: {}
      }
  },
    sort: {
        searchtext: "",
        paginationinfo: {
            pageno: 1,
            pagelimit: 2000,
            filter: {},
            projection: { pincode: 1 },
            sort: { pincode: -1 }
        }
    },
    dependancy:[]
}

const invalidDataTests = [
    {
        data: {
            "pincode":"",
            "city": "",
            "stateid": "66ed3614c79dcfbb498d8420",
            "state": "",
            "countryid": "66ed3614c79dcfbb498d841f",
            "country": "",
            "isactive": 1
        },
        expectedError: 'Path `pincode` is required.,Path `area` is required.,Path `city` is required.,Path `state` is required.,Path `country` is required.',
        description: 'should return an error for empty name'
    },
    {
        data: {
            "city": "surat",
            "pincode":"395006",
            "area":"ns",
            "stateid": "66ed3614c79dcfbb498d8420",
            "state": "",
            "countryid": "66ed3614c79dcfbb498d841f",
            "country": "",
            "isactive": 1
        },
        expectedError: 'Path `state` is required.,Path `country` is required.',
        description: 'should return an error for missing value'
    },
    {
        data: {
            "city": "np",
            "city":"66ed3614c79dcfbb498d841c",
            "pincode":"395006",
            "area":"ns",
            "stateid":  "66ed3614c79dcfbb498d8420",
            "state": "nsp",
            "countryid": "66ed3614c79dcfbb498d841f",
            "country": "np",
            "isactive": 1
        },
    expectedError: 'Data already exist.',
    description: 'should return an error for data already exist'
    }
]


describe('Cruds', async function () {

  await IISAutoTest.EmployeeAuthTestcase()
 
  const testCases = IISAutoTest.CommonTestcase({ endpoint, reqbody,reqheader})
   for (const testCase of testCases) {
     IISAutoTest.performRequest(testCase)
   }
   
   //diffrent scenario test
   for (const dep of invalidDataTests) {
      IISAutoTest.performRequest({method: 'post',endpoint: endpoint.add,body: dep.data,expectedStatus: 400,description: dep.description,headers: reqheader.add,
         expectedResponse: (res) => {
           res.should.be.a('object')
           res.body.should.be.a('object')
           res.body.should.have.property('message').that.equals(dep.expectedError)
         }
       })
   }

})

