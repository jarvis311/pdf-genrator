import chai from 'chai';
import chaiHttp from 'chai-http';
import { Config, IISAutoTest, IISMethods,FieldConfig } from '../../config/Init.js'
import async from 'async'

chai.use(chaiHttp);
chai.config.includeStack = true
const { should} = chai
should()

const ObjectId = IISMethods.getobjectid()
const propertyid = new ObjectId()
const towerid = new ObjectId()
const floorid = new ObjectId()
const unitid = new ObjectId()


const endpoint = {
  list: "/property",
  add: "/property/add",
  update: "/property/update",
  delete: "/property/delete",
  dataname :"Property"
};

const reqheader = {
  list:{useraction:"viewright",pagename:"property",apptype:1},
  add:{useraction:"addright",pagename:"property",apptype:1},
  update:{useraction:"editright",pagename:"property",apptype:1},
  delete:{useraction:"delright",pagename:"property",apptype:1},
}

const reqbody = {
  add: {
    "_id": propertyid,
    "employeeid": "650fe15f4d42f92dbb536f12",
    "brandname": "Demo Brand",
    "property_id": "PROP12345",
    "propertyname": "Sunset Villas",
    "prefix": "SV",
    "uniqueno": "1001",
    "propertycontactno": "+1-123-456-7890",
    "propertyemail": "contact@sunsetvillas.com",
    "website": "https://www.sunsetvillas.com",
    "maincontactperson": "John Doe",
    "maincontactpersonemail": "john.doe@sunsetvillas.com",
    "mainpersoncontactno": "+1-098-765-4321",
    "mainpersondesignation": "Manager",
    "propertyimage": "https://example.com/image.jpg",
    "isactive": 1,
    "isdelete": 0,
    "location": "Downtown",
    "latitude": "37.7749",
    "longitude": "-122.4194",
    "arearange": 5000,
    "address": "123 Main St, Downtown",
    "fulladdress": "123 Main St, Downtown, Sunset City, CA, USA",
    "pincode": "94105",
    "pincodeid": "650fe15f4d42f92dbb536f13",
    "cityid": "650fe15f4d42f92dbb536f14",
    "city": "Sunset City",
    "stateid": "650fe15f4d42f92dbb536f15",
    "state": "California",
    "countryid": "650fe15f4d42f92dbb536f16",
    "country": "USA"
  },
  update: {
    _id: propertyid,
    propertyname: "Godrej Eternity 1"
  },
  delete: {
    _id: propertyid
  },
  filter: {
    searchtext: "",
    paginationinfo: {
      pageno: 1,
      pagelimit: 200000000,
      filter: { "_id": [propertyid.toString()] },
      sort: {}
    }
  },
  sort: {
    searchtext: "",
    paginationinfo: {
      pageno: 1,
      pagelimit: 200000000,
      filter: {},
      projection: { propertyname: 1 },
      sort: { propertyname: 1 }
    }
  },
  search: {
    searchtext: "Down",
    paginationinfo: {
      pageno: 1,
      pagelimit: 200000000,
      filter: {},
      projection: {},
      sort: {}
    }
  },
  dependancy: [
    {
      endpoint: { list: "/property/floor", add: "/property/floor/add" },
      match: ['property'],
      filter: {
        searchtext: "",
        paginationinfo: {
          pageno: 1,
          pagelimit: 2000,
          filter: { "propertyid": [propertyid] },
          projection: {},
          sort: {}
        }
      }
    },
    {
      endpoint: { list: "/property/unit", add: "/property/unit/add" },
      match: ['property'],
      filter: {
        searchtext: "",
        paginationinfo: {
          pageno: 1,
          pagelimit: 2000,
          filter: { "propertyid": [propertyid] },
          projection: {},
          sort: {}
        }
      }
    },
    {
      endpoint: { list: "/property/tower", add: "/property/tower/add" },
      match: ['property'],
      filter: {
        searchtext: "",
        paginationinfo: {
          pageno: 1,
          pagelimit: 2000,
          filter: { "propertyid": [propertyid] },
          projection: {},
          sort: {}
        }
      }
    }
  ]
}

const invalidDataTests = [
  {
    data: {
        "employeeid": "650fe15f4d42f92dbb536f12",
        "brandname": "Demo Brand",
        "property_id": "PROP12345",
        "propertyname": "",
        "prefix": "",
        "uniqueno": "1001",
        "propertycontactno": "",
        "propertyemail": "contact@sunsetvillas.com",
        "website": "",
        "maincontactperson": "",
        "maincontactpersonemail": "",
        "maincontactpersonnumber": "+1-098-765-4321",
        "mainpersondesignation": "Manager",
        "propertyimage": "https://example.com/image.jpg",
        "isactive": 1,
        "isdelete": 0,
        "location": "Downtown",
        "latitude": "37.7749",
        "longitude": "-122.4194",
        "arearange": 5000,
        "address": "123 Main St, Downtown",
        "fulladdress": "123 Main St, Downtown, Sunset City, CA, USA",
        "pincode": "94105",
        "pincodeid": "650fe15f4d42f92dbb536f13",
        "cityid": "650fe15f4d42f92dbb536f14",
        "city": "Sunset City",
        "stateid": "650fe15f4d42f92dbb536f15",
        "state": "California",
        "countryid": "650fe15f4d42f92dbb536f16",
        "country": "USA"
    },
    expectedError: 'Path `propertyname` is required.,Path `prefix` is required.,Path `propertycontactno` is required.,Path `maincontactperson` is required.',
    description: 'should return an error for empty property name'
  },
  {
    data: {
        "employeeid": "650fe15f4d42f92dbb536f12",
        "brandname": "Demo Brand",
        "property_id": "PROP12345",
        "propertyname": "",
        "prefix": "SV",
        "uniqueno": "1001",
        "propertycontactno": "+1-123-456-7890",
        "propertyemail": "contact@sunsetvillas.com",
        "website": "https://www.sunsetvillas.com",
        "maincontactperson": "John Doe",
        "maincontactpersonemail": "john.doe@sunsetvillas.com",
        "maincontactpersonnumber": "+1-098-765-4321",
        "mainpersondesignation": "Manager",
        "propertyimage": "https://example.com/image.jpg",
        "isactive": 1,
        "isdelete": 0,
        "location": "Downtown",
        "latitude": "37.7749",
        "longitude": "-122.4194",
        "arearange": 5000,
        "address": "123 Main St, Downtown",
        "fulladdress": "123 Main St, Downtown, Sunset City, CA, USA",
        "pincode": "94105",
        "pincodeid": "650fe15f4d42f92dbb536f13",
        "cityid": "650fe15f4d42f92dbb536f14",
        "city": "Sunset City",
        "stateid": "650fe15f4d42f92dbb536f15",
        "state": "California",
        "countryid": "650fe15f4d42f92dbb536f16",
        "country": "USA"
    },
    expectedError: 'Path `propertyname` is required.',
    description: 'should return an error for required parameter'
  }
]

describe('Property master', async function () {

  await IISAutoTest.EmployeeAuthTestcase()

 const testCases = IISAutoTest.CommonTestcase({ endpoint, reqbody,reqheader,isdelete:1})
  for (const testCase of testCases) {
    IISAutoTest.performRequest(testCase)
  }
  
  //diffrent scenario test
  for (const dep of invalidDataTests) {
     IISAutoTest.performRequest({method: 'post',endpoint: endpoint.add,body: dep.data,expectedStatus: 400,description: dep.description,headers: reqheader.add,
        expectedResponse: (res) => {
          res.should.be.a('object')
          res.body.should.be.a('object')
          res.body.should.have.property('message').that.equals(dep.expectedError)
        }
      })


      IISAutoTest.performRequest({method: 'post',endpoint: endpoint.add,body: dep.data,expectedStatus: 400,description:"property also add in admin role",headers: reqheader.add,
        expectedResponse: (res) => {
          res.should.be.a('object')
          res.body.should.be.a('object')
          res.body.should.have.property('message').that.equals(dep.expectedError)
        }
      })
    
    
      IISAutoTest.performRequest({method: 'post',endpoint: endpoint.add,body: dep.data,expectedStatus: 400,description:"property update that time also update in gatekeeper,customer and employee",headers: reqheader.add,
        expectedResponse: (res) => {
          res.should.be.a('object')
          res.body.should.be.a('object')
          res.body.should.have.property('message').that.equals(dep.expectedError)
        }
      })
    
      IISAutoTest.performRequest({method: 'post',endpoint: endpoint.add,body: dep.data,expectedStatus: 400,description:"In property delete time check dependancy in gatekeepeer,customer and employee",headers: reqheader.add,
        expectedResponse: (res) => {
          res.should.be.a('object')
          res.body.should.be.a('object')
          res.body.should.have.property('message').that.equals(dep.expectedError)
        }
      })
  }


  

  //dependancy testcase   
  // reqbody.dependancy.forEach(dep => {
  //   it(`should insert data into ${dep.endpoint.add}`, async function () {
  //     IISAutoTest.performRequest({method: 'post', endpoint: endpoint.add, body: dep.data, expectedStatus: 200, description: 'should create resource successfully',
  //       expectedResponse: (res) => {
  //         res.body.should.have.property('message').that.equals('Data inserted successfully.')
  //       }
  //     })
  //   })
  // })

  // it('should update property and all dependencies dynamically', async function () {
  //   IISAutoTest.performRequest({ method: 'post', endpoint: endpoint.update, body: reqbody.update, expectedStatus: 200,description: 'should update resource successfully',
  //     expectedResponse: async (res) => {
  //       res.body.should.have.property('message').that.equals('Data updated successfully.');
  //       res.should.have.status(200);
  //     }
  //   });

  //   for (const dep of reqbody.dependancy) {
  //     it(`should validate ${dep.endpoint.list} and all dependencies dynamically`, async function () {
  //       IISAutoTest.performRequest({method: 'post',endpoint: dep.endpoint.list,body: dep.filter,expectedStatus: 200,description: 'dependencies check',
  //         expectedResponse: async (res1) => {
  //           res1.should.have.status(200)
  //           const records = res1.body.data

  //           for (const matchKey of dep.match) {
  //             const matchValue = reqbody.update[matchKey]
  //             const matchExists = records.some(record => record[matchKey] === matchValue)
  //             matchExists.should.be.true
  //           }
  //         }
  //       })
  //     })
  //   }
  // })

})



//================================================================= Tower ==============================================================================================//


const endpointTower = {
  list: "/property/tower",
  add: "/property/tower/add",
  update: "/property/tower/update",
  delete: "/property/tower/delete",
  dataname :"Tower"
};

const reqheaderTower = {
  list:{useraction:"viewright",pagename:"tower",apptype:1},
  add:{useraction:"addright",pagename:"tower",apptype:1},
  update:{useraction:"editright",pagename:"tower",apptype:1},
  delete:{useraction:"delright",pagename:"tower",apptype:1},
}

const reqbodyTower = {
  add: {
    _id: towerid,
    "propertyid": propertyid,
    "propertyname": "Godrej Surat",
    "towername": "varacha"
  },
  update: {
    _id: towerid,
    "towername": "AB"
  },
  delete: {
    _id: towerid
  },
  filter: {
    searchtext: "",
    paginationinfo: {
      pageno: 1,
      pagelimit: 200000000,
      filter: { "_id": [towerid.toString(),"66acc53ca826a13d00a88190"] },
      sort: {}
    }
  },
  sort: {
    searchtext: "",
    paginationinfo: {
      pageno: 1,
      pagelimit: 200000000,
      filter: {},
      projection: { towername: 1 },
      sort: { towername: 1 }
    }
  },
  search: {
    searchtext: "In",
    paginationinfo: {
      pageno: 1,
      pagelimit: 200000000,
      filter: {},
      projection: {},
      sort: {}
    }
  },
  dependancy: [
    {
      endpoint: { list: "/property/floor", add: "/property/floor/add" },
      match: ['towername'],
      filter: {
        searchtext: "",
        paginationinfo: {
          pageno: 1,
          pagelimit: 2000,
          filter: { "towerid": [towerid] },
          projection: {},
          sort: {}
        }
      }
    },
    {
      endpoint: { list: "/property/unit", add: "/property/unit/add" },
      match: ['towername'],
      filter: {
        searchtext: "",
        paginationinfo: {
          pageno: 1,
          pagelimit: 2000,
          filter: { "towerid": [towerid] },
          projection: {},
          sort: {}
        }
      }
    }
  ]
}

const invalidDataTestsTower = [
  {
    data: {
      "propertyid": "669f5122a664b86fd6f4a4e8",
      "propertyname": "",
      "towername": ""
    },
    expectedError: 'No data found',
    description: 'Property exits or not'
  },
  {
    data: {
        "propertyid": propertyid,
        "propertyname": "",
        "towername": ""
    },
    expectedError: 'Path `propertyname` is required.,Path `towername` is required.',
    description: 'should return an error for required parameter'
  }
]

describe('Cruds', async function () {

 const testCases = IISAutoTest.CommonTestcase({endpoint:endpointTower, reqbody:reqbodyTower,reqheader:reqheaderTower,isdelete:1})
  for (const testCase of testCases) {
    IISAutoTest.performRequest(testCase)
  }
  
  //diffrent scenario test
  for (const dep of invalidDataTestsTower) {
     IISAutoTest.performRequest({method: 'post',endpoint: endpointTower.add,body: dep.data,expectedStatus: 400,description: dep.description,
        expectedResponse: (res) => {
          res.should.be.a('object')
          res.body.should.be.a('object')
          res.body.should.have.property('message').that.equals(dep.expectedError)
        }
      })
  }

  // //dependancy testcase   
  // reqbodyTower.dependancy.forEach(dep => {
  //   it(`should insert data into ${dep.endpoint.add}`, async function () {
  //     IISAutoTest.performRequest({method: 'post', endpoint: endpointTower.add, body: dep.data, expectedStatus: 200, description: 'should create resource successfully',
  //       expectedResponse: (res) => {
  //         res.body.should.have.property('message').that.equals('Data inserted successfully.')
  //       }
  //     })
  //   })
  // })

})




//================================================================= Floor ==============================================================================================//

const endpointFloor = {
  list: "/property/floor",
  add: "/property/floor/add",
  update: "/property/floor/update",
  delete: "/property/floor/delete"
}

const reqheaderFloor = {
  list:{useraction:"viewright",pagename:"floor",apptype:1},
  add:{useraction:"addright",pagename:"floor",apptype:1},
  update:{useraction:"editright",pagename:"floor",apptype:1},
  delete:{useraction:"delright",pagename:"floor",apptype:1},
}

const reqbodyFloor = {
  add: {
    _id: floorid,
    "propertyid": propertyid,
    "propertyname": "Godrej Surat",
    "towerid": towerid,
    "towername": "varacha",
    "floor": "3",
    "isactive":1
  },
  update: {
    _id: floorid,
    "floor": "floor10",
  },
  delete: {
    _id: floorid
  },
  filter: {
    searchtext: "",
    paginationinfo: {
      pageno: 1,
      pagelimit: 200000000,
      filter: { "_id": [floorid.toString(),"66acc53ca826a13d00a88190"] },
      sort: {}
    }
  },
  sort: {
    searchtext: "",
    paginationinfo: {
      pageno: 1,
      pagelimit: 200000000,
      filter: {},
      projection: { floorname: 1 },
      sort: { floorname: 1 }
    }
  },
  search: {
    searchtext: "In",
    paginationinfo: {
      pageno: 1,
      pagelimit: 200000000,
      filter: {},
      projection: {},
      sort: {}
    }
  },
  dependancy: [
    {
      endpoint: { list: "/property/unit", add: "/property/unit/add" },
      match: ['floor'],
      filter: {
        searchtext: "",
        paginationinfo: {
          pageno: 1,
          pagelimit: 2000,
          filter: { "floorid": [floorid] },
          projection: {},
          sort: {}
        }
      }
    }
  ]
}


const invalidDataTestsFloor = [
  {
    data: {
        "propertyid": "669f5122a664b86fd6f4a4e8",
        "propertyname": "Godrej Surat",
        "buildingid": "66a0db8c5e4f01a50e1695c5",
        "buildingname": "varacha",
        "floor": "",
        "isactive":1
    },
    expectedError: 'No data found',
    description: 'Property exits or not'
  },
  {
    data: {
        "propertyid":propertyid,
        "propertyname": "Godrej Surat",
        "buildingid": towerid,
        "buildingname": "varacha",
        "floor": "",
        "isactive":1
    },
    expectedError: 'Path `floor` is required.',
    description: 'should return an error for required parameter'
  }
]

describe('Cruds', async function () {

 const testCases = IISAutoTest.CommonTestcase({endpoint:endpointFloor, reqbody:reqbodyFloor,reqheader:reqheaderFloor,isdelete:1})
  for (const testCase of testCases) {
    IISAutoTest.performRequest(testCase)
  }
  
  //diffrent scenario test
  for (const dep of invalidDataTestsFloor) {
     IISAutoTest.performRequest({method: 'post',endpoint: endpoint.add,body: dep.data,expectedStatus: 400,description: dep.description,headers: reqheaderTower.add,
        expectedResponse: (res) => {
          res.should.be.a('object')
          res.body.should.be.a('object')
          res.body.should.have.property('message').that.equals(dep.expectedError)
        }
      })
  }

})




//================================================================= Unit ==============================================================================================//
const endpointUnit = {
  list: "/property/unit",
  add: "/property/unit/add",
  update: "/property/unit/update",
  delete: "/property/unit/delete"
};

const reqheaderUnit = {
  list:{useraction:"viewright",pagename:"unit",apptype:1},
  add:{useraction:"addright",pagename:"unit",apptype:1},
  update:{useraction:"editright",pagename:"unit",apptype:1},
  delete:{useraction:"delright",pagename:"unit",apptype:1},
}

const reqbodyUnit = {
  add: {
    _id: unitid,
    "propertyid": propertyid,
    "propertyname": "Godrej Surat",
    "towerid": towerid,
    "towername": "varacha",
     "floorid": floorid,
     "floor":"floor09",
    "unitname": "103"
  },
  update: {
    _id: unitid,
    "unitname": "109"
  },
  delete: {
    _id: unitid
  },
  filter: {
    searchtext: "",
    paginationinfo: {
      pageno: 1,
      pagelimit: 200000000,
      filter: { "_id": [unitid.toString(),"66acc53ca826a13d00a88190"] },
      sort: {}
    }
  },
  sort: {
    searchtext: "",
    paginationinfo: {
      pageno: 1,
      pagelimit: 200000000,
      filter: {},
      projection: { unitname: 1 },
      sort: { unitname: 1 }
    }
  },
  search: {
    searchtext: "In",
    paginationinfo: {
      pageno: 1,
      pagelimit: 200000000,
      filter: {},
      projection: {},
      sort: {}
    }
  },
  dependancy: [
    {
      endpoint: { list: "/state", add: "/state/add" },
      match: ['unit'],
      body: {
        _id: propertyid,
        state: "mp",
        unitid: unitid,
        unit: "German"
      },
      filter: {
        searchtext: "",
        paginationinfo: {
          pageno: 1,
          pagelimit: 2000,
          filter: { "countyid": [unitid] },
          projection: {},
          sort: {}
        }
      }
    },
    // {
    //   endpoint: { list: "/city", add: "/city/add" },
    //   match: ['unit'],
    //   body: {
    //     _id: cityid,
    //     city: "surat",
    //     propertyid: propertyid,
    //     state: "mp",
    //     unitid: unitid,
    //     unit: "German"
    //   },
    //   filter: {
    //     searchtext: "",
    //     paginationinfo: {
    //       pageno: 1,
    //       pagelimit: 2000,
    //       filter: { "countyid": [propertyid] },
    //       projection: {},
    //       sort: {}
    //     }
    //   }
    // }
  ]
}


const invalidDataTestsUnit = [
  {
    data: {
        "propertyid": "669f5122a164b86fd6f4a4e8",
        "propertyname": "Godrej Surat",
        "buildingid": "66a0db8c5e4f01a50e1695c5",
        "buildingname": "varacha",
         "floorid":"66a0dbbc5e4f01a50e1695f5",
         "floor":"floor09",
        "unitname": "107"
    },
    expectedError: 'No data found',
    description: 'Property exits or not'
  },
  {
    data: {
        "propertyid": "669f5122a164b86fd6f4a4e8",
        "propertyname": "Godrej Surat",
        "buildingid": "66a0db8c5e4f01a50e1695c5",
        "buildingname": "varacha",
         "floorid":"66a0dbbc5e4f01a50e1695f5",
         "floor":"floor09",
        "unitname": ""
    },
    expectedError: 'Path `unitname` is required.',
    description: 'should return an error for required parameter'
  }
]

describe('Cruds', async function () {
   
    const testCases = IISAutoTest.CommonTestcase({endpoint:endpointUnit, reqbody:reqbodyUnit,reqheader:reqheaderUnit,isdelete:1})
     for (const testCase of testCases) {
       IISAutoTest.performRequest(testCase)
     }
     
     //diffrent scenario test
     for (const dep of invalidDataTestsUnit) {
        IISAutoTest.performRequest({method: 'post',endpoint: endpoint.add,body: dep.data,expectedStatus: 400,description: dep.description,headers: reqheaderUnit.add,
           expectedResponse: (res) => {
             res.should.be.a('object')
             res.body.should.be.a('object')
             res.body.should.have.property('message').that.equals(dep.expectedError)
           }
         })
     }   

})



//dependancy
describe('Property Dependancy', async function () {
  await IISAutoTest.updateAndCheckDependencies('property', endpoint.update, reqbody, reqheader);
  await IISAutoTest.updateAndCheckDependencies('tower', endpointTower.update, reqbodyTower, reqheaderTower);
  await IISAutoTest.updateAndCheckDependencies('floor', endpointFloor.update, reqbodyFloor, reqheaderFloor);
  await IISAutoTest.updateAndCheckDependencies('unit', endpointUnit.update, reqbodyUnit, reqheaderUnit);
})


