import chai from 'chai';
import chaiHttp from 'chai-http';
import { Config, IISAutoTest, IISMethods } from '../../config/Init.js'
import async from 'async'


chai.use(chaiHttp);
chai.config.includeStack = true

const { should, expect } = chai
should()

const ObjectId = IISMethods.getobjectid()
const stateid = new ObjectId()
const countryid = new ObjectId()
const cityid = new ObjectId()

const endpoint = {
  list: "/state",
  add: "/state/add",
  update: "/state/update",
  delete: "/state/delete",
  dataname :"State"
};

const reqheader = {
  list: { useraction: "viewright", pagename: "state", apptype: 1 },
  add: { useraction: "addright", pagename: "state", apptype: 1 },
  update: { useraction: "editright", pagename: "state", apptype: 1 },
  delete: { useraction: "delright", pagename: "state", apptype: 1 },
}

const reqbody = {
  add: {
    _id: stateid,
    shortcode:"ND",
    state:"North Delhi",
    countryid :countryid,
    country: "German",
  },
  update: {
    _id: stateid,
    state: "North mp",
    status: 1
  },
  delete: {
    _id: stateid
  },
  filter: {
    searchtext: "",
    paginationinfo: {
      pageno: 1,
      pagelimit: 200000000,
      filter: { "_id": ["66acd3c56a781176246a9500"] },
      sort: {}
    }
  },
  sort: {
    searchtext: "",
    paginationinfo: {
      pageno: 1,
      pagelimit: 200000000,
      filter: {},
      projection: { country: 1 },
      sort: { country: 1 }
    }
  },
  search: {
    searchtext: "In",
    paginationinfo: {
      pageno: 1,
      pagelimit: 200000000,
      filter: {},
      projection: {},
      sort: {}
    }
  },
  dependancy: [
    {
      endpoint: { list: "/city", add: "/city/add" },
      match: ['country'],
      body: {
        _id: cityid,
        city: "surat",
        stateid: stateid,
        state: "mp",
        countryid: countryid,
        country: "German"
      },
      filter: {
        searchtext: "",
        paginationinfo: {
          pageno: 1,
          pagelimit: 2000,
          filter: { "stateid": [stateid] },
          projection: {},
          sort: {}
        }
      }
    }
  ]
}


const invalidDataTests = [
  {
    data: {
      countryid: "620381a7af6dcf2c633ef21a",
      country:"",
      statecode:"",
      state:""
    },
    expectedError: 'Path `shortcode` is required.,Path `state` is required.,Path `country` is required.',
    description: 'should return an error for empty field'
  },
  {
    data: {
      countryid : "66acc555a826a13d00a883f0",
      country:"",
      shortcode:"017",
      state:"hl"
    },
    expectedError: 'Path `country` is required.',
    description: 'should return an error for required parameter'
  },
  {
    data: {
      countryid : "66acc555a826a13d00a883f0",
      country:"india",
      shortcode:"91",
      state:"mp"
    },
    expectedError: 'Data inserted successfully.',
    description: 'should return an successfully documnet added'
  },
  {
    data: {
      countryid : "66acc555a826a13d00a883f0",
      country:"india",
      shortcode:"91",
      state:"mp"
    },
    expectedError: 'Data already exist.',
    description: 'should return an error for data already exist'
  }
]

describe('Cruds', async function () {

  await IISAutoTest.EmployeeAuthTestcase()
 
  const testCases = IISAutoTest.CommonTestcase({ endpoint, reqbody,reqheader})
   for (const testCase of testCases) {
     IISAutoTest.performRequest(testCase)
   }
   
   //diffrent scenario test
   for (const dep of invalidDataTests) {
      IISAutoTest.performRequest({method: 'post',endpoint: endpoint.add,body: dep.data,expectedStatus: 400,description: dep.description,headers: reqheader.add,
         expectedResponse: (res) => {
           res.should.be.a('object')
           res.body.should.be.a('object')
           res.body.should.have.property('message').that.equals(dep.expectedError)
         }
       })
   }
 

  //dependancy testcase   
  reqbody.dependancy.forEach(dep => {
    it(`should insert data into ${dep.endpoint.add}`, async function () {
      IISAutoTest.performRequest({
        method: 'post', endpoint: endpoint.add, body: dep.data, expectedStatus: 200, description: 'should create resource successfully', headers: reqheader.add,
        expectedResponse: (res) => {
          res.body.should.have.property('message').that.equals('Data inserted successfully.')
        }
      })
    })
  })

  it('should update country and all dependencies dynamically', async function () {
    IISAutoTest.performRequest({
      method: 'post',
      endpoint: endpoint.update,
      body: reqbody.update,
      expectedStatus: 200,
      headers: reqheader.add,
      description: 'should update resource successfully',
      expectedResponse: async (res) => {
        res.body.should.have.property('message').that.equals('Data updated successfully.');
        res.should.have.status(200);
      }
    });

    for (const dep of reqbody.dependancy) {
      it(`should validate ${dep.endpoint.list} and all dependencies dynamically`, async function () {
        IISAutoTest.performRequest({
          method: 'post',
          endpoint: dep.endpoint.list,
          body: dep.filter,
          expectedStatus: 200,
          description: 'dependencies check',
          headers: reqheader.add,
          expectedResponse: async (res1) => {
            res1.should.have.status(200)
            const records = res1.body.data

            for (const matchKey of dep.match) {
              const matchValue = reqbody.update[matchKey]
              const matchExists = records.some(record => record[matchKey] === matchValue)
              matchExists.should.be.true
            }
          }
        })
      })
    }
  })

  // Concurrent requests test
  it('should handle concurrent requests correctly without data corruption or errors', function (done) {
    this.timeout(30000);

    const numConcurrentRequests = 50;
    const requestBodies = Array(numConcurrentRequests).fill(Config.requestBody)

    const requestFunctions = requestBodies.map(body => {
      return (callback) => {
        chai.request.execute(Config.getBaseurl())
          .post(endpoint.list)
          .send(body)
          .end((err, res) => {
            if (err) return callback(err)

            try {
              res.should.have.status(200)
              res.body.should.be.a('object')
              res.body.should.have.property('status').eql(200)
              callback()
            } catch (e) {
              callback(e)
            }
          })
      }
    })

    async.parallel(requestFunctions, (err) => {
      if (err) return done(err)
      done()
    })
  })

})
