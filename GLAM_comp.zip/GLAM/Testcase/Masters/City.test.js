import chai from 'chai';
import chaiHttp from 'chai-http';
import { Config, IISAutoTest, IISMethods } from '../../config/Init.js'
import async from 'async'

chai.use(chaiHttp);
chai.config.includeStack = true;

const { should, expect } = chai;
should();

const ObjectId = IISMethods.getobjectid()
const cityid = new ObjectId()

const endpoint = {
    list: "/city",
    add: "/city/add",
    update: "/city/update",
    delete: "/city/delete",
    dataname :"City"
};

const reqheader = {
  list: { useraction: "viewright", pagename: "city", apptype: 1 },
  add: { useraction: "addright", pagename: "city", apptype: 1 },
  update: { useraction: "editright", pagename: "city", apptype: 1 },
  delete: { useraction: "delright", pagename: "city", apptype: 1 },
}

const reqbody = {
    add: {
        _id: cityid,
        stateid: "628df13f8957f1ddc3f014d9",
        state: "Gujarat",
        countryid: "62ac27b8f829ef6999b3526c",
        country: "India",
        city: "kp"
    },
    update: {
        _id: cityid,
        city: "vapi",
        stateid: "628df13f8957f1ddc3f014d9",
        state: "Gujarat",
        countryid: "62ac27b8f829ef6999b3526c",
        country: "bhavnagar",
    },
    delete: {
        _id: cityid
    },
    filter: {
      searchtext: "",
      paginationinfo: {
          pageno: 1,
          pagelimit: 2000,
          filter: { _id:['66ebf4ce4b64029be9e171a5'],stateid: ["628df13f8957f1ddc3f014d9"],countryid: ["62ac27b8f829ef6999b3526c"] },
          projection: {},
          sort: {}
      }
  },
    sort: {
        searchtext: "Va",
        paginationinfo: {
            pageno: 1,
            pagelimit: 2000,
            filter: {},
            projection: { city: 1 },
            sort: { city: -1 }
        }
    },
    dependancy:[]
}

const invalidDataTests = [
    {
        data: {
            "city": "",
            "stateid": "66ed3614c79dcfbb498d8420",
            "state": "",
            "countryid": "66ed3614c79dcfbb498d841f",
            "country": "",
            "isactive": 1
        },
        expectedError: 'Path `city` is required.,Path `state` is required.,Path `country` is required.',
        description: 'should return an error for empty name'
    },
    {
        data: {
          city: "vapi",
          stateid: "628df13f8957f1ddc3f014d9",
          state: "Gujarat",
          countryid: "62ac27b8f829ef6999b3526c",
          country: "bhavnagar",
        },
        expectedError: 'Path `state` is required.,Path `country` is required.',
        description: 'should return an error for missing value'
    },
    {
        data: {
            "city": "vapi",
            "stateid":  "66ed3614c79dcfbb498d8420",
            "state": "nsp",
            "countryid": "66ed3614c79dcfbb498d841f",
            "country": "np",
            "isactive": 1
        },
    expectedError: 'Data already exist.',
    description: 'should return an error for data already exist'
    }
]


describe('Cruds', async function () {

  await IISAutoTest.EmployeeAuthTestcase()
 
  const testCases = IISAutoTest.CommonTestcase({ endpoint, reqbody,reqheader})
   for (const testCase of testCases) {
     IISAutoTest.performRequest(testCase)
   }
   
   //diffrent scenario test
   for (const dep of invalidDataTests) {
      IISAutoTest.performRequest({method: 'post',endpoint: endpoint.add,body: dep.data,expectedStatus: 400,description: dep.description,headers: reqheader.add,
         expectedResponse: (res) => {
           res.should.be.a('object')
           res.body.should.be.a('object')
           res.body.should.have.property('message').that.equals(dep.expectedError)
         }
       })
   }
 

  // Concurrent requests test
  it('should handle concurrent requests correctly without data corruption or errors', function (done) {
    this.timeout(30000);

    const numConcurrentRequests = 50;
    const requestBodies = Array(numConcurrentRequests).fill(Config.requestBody)

    const requestFunctions = requestBodies.map(body => {
      return (callback) => {
        chai.request.execute(Config.getBaseurl())
          .post(endpoint.list)
          .send(body)
          .end((err, res) => {
            if (err) return callback(err)

            try {
              res.should.have.status(200)
              res.body.should.be.a('object')
              res.body.should.have.property('status').eql(200)
              callback()
            } catch (e) {
              callback(e)
            }
          })
      }
    })

    async.parallel(requestFunctions, (err) => {
      if (err) return done(err)
      done()
    })
  })

})

