import chai from 'chai';
import chaiHttp from 'chai-http';
import { Config, IISAutoTest, IISMethods } from '../../config/Init.js'


chai.use(chaiHttp);
chai.config.includeStack = true
const { should } = chai
should()

const ObjectId = IISMethods.getobjectid()
const channelid = new ObjectId()

const endpoint = {
  list: "/channel",
  add: "/channel/add",
  update: "/channel/update",
  delete: "/channel/delete",
  dataname :"Channel"
}

const reqheader = {
  list: { useraction: "viewright", pagename: "channel", apptype: 1 },
  add: { useraction: "addright", pagename: "channel", apptype: 1 },
  update: { useraction: "editright", pagename: "channel", apptype: 1 },
  delete: { useraction: "delright", pagename: "channel", apptype: 1 },
}

const reqbody = {
  add: {
    _id: channelid,
    channel:"SWIGGY",
    status:1
  },
  update: {
    _id: channelid,
    channel: "SWIGGYs"
  },
  delete: {
    _id: channelid
  },
  filter: {
    searchtext: "",
    paginationinfo: {
      pageno: 1,
      pagelimit: 200000000,
      filter: { "_id": [channelid.toString()] },
      sort: {}
    }
  },
  sort: {
    searchtext: "",
    paginationinfo: {
      pageno: 1,
      pagelimit: 200000000,
      filter: {},
      projection: { channel: 1 },
      sort: { channel: 1 }
    }
  },
  search: {
    searchtext: "sw",
    paginationinfo: {
      pageno: 1,
      pagelimit: 200000000,
      filter: {},
      projection: {},
      sort: {}
    }
  }
}


const invalidDataTests = [
  {
    data: {
        channel: "",
        status: 1
    },
    expectedError: 'Path `channel` is required.',
    description: 'should return an error for empty name'
  }
]


describe('Cruds', async function () {

  await IISAutoTest.EmployeeAuthTestcase()
 
  const testCases = IISAutoTest.CommonTestcase({ endpoint, reqbody,reqheader})
   for (const testCase of testCases) {
     IISAutoTest.performRequest(testCase)
   }
   
   //diffrent scenario test
   for (const dep of invalidDataTests) {
      IISAutoTest.performRequest({method: 'post',endpoint: endpoint.add,body: dep.data,expectedStatus: 400,description: dep.description,header: reqheader.add,
         expectedResponse: (res) => {
           res.should.be.a('object')
           res.body.should.be.a('object')
           res.body.should.have.property('message').that.equals(dep.expectedError)
         }
       })
   }
})









