import chai from 'chai';
import chaiHttp from 'chai-http';
import { Config, IISAutoTest, IISMethods } from '../../config/Init.js'


chai.use(chaiHttp);
chai.config.includeStack = true
const { should, expect } = chai
should()

const ObjectId = IISMethods.getobjectid()
const companyid = new ObjectId()

const endpoint = {
  list: "/deliverycompany",
  add: "/deliverycompany/add",
  update: "/deliverycompany/update",
  delete: "/deliverycompany/delete",
  dataname :"Delivery Company"
}

const reqheader = {
  list: { useraction: "viewright", pagename: "deliverycompany", apptype: 1 },
  add: { useraction: "addright", pagename: "deliverycompany", apptype: 1 },
  update: { useraction: "editright", pagename: "deliverycompany", apptype: 1 },
  delete: { useraction: "delright", pagename: "deliverycompany", apptype: 1 },
  dataname :"Channel"
}

const reqbody = {
  add: {
    _id: companyid,
    name:"Rapido",
    logo:"SWIGGY.png",
    status:1
  },
  update: {
    _id: companyid,
    name: "Rapid",
  },
  delete: {
    _id: companyid
  },
  filter: {
    searchtext: "",
    paginationinfo: {
      pageno: 1,
      pagelimit: 200000000,
      filter: { "_id": [companyid.toString(),"66aca213be064cab4199b3a1"] },
      sort: {}
    }
  },
  sort: {
    searchtext: "",
    paginationinfo: {
      pageno: 1,
      pagelimit: 200000000,
      filter: {},
      projection: { name: 1 },
      sort: { name: 1 }
    }
  },
  search: {
    searchtext: "sw",
    paginationinfo: {
      pageno: 1,
      pagelimit: 200000000,
      filter: {},
      projection: {},
      sort: {}
    }
  }
}


const invalidDataTests = [
  {
    data: {
            name: "",
            logo: "SWIGGY.png",
            status: 1
    },
    expectedError: 'Path `name` is required.',
    description: 'should return an error for empty name'
  },
  {
    data: reqbody.update,
    expectedError: 'Data already exist.',
    description: 'should return an error for data already exist'
  }
]

describe('Cruds', async function () {

  await IISAutoTest.EmployeeAuthTestcase()
 
  const testCases = IISAutoTest.CommonTestcase({ endpoint, reqbody,reqheader})
   for (const testCase of testCases) {
     IISAutoTest.performRequest(testCase)
   }
   
   //diffrent scenario test
   for (const dep of invalidDataTests) {
      IISAutoTest.performRequest({method: 'post',endpoint: endpoint.add,body: dep.data,expectedStatus: 400,description: dep.description,headers: reqheader.add,
         expectedResponse: (res) => {
           res.should.be.a('object')
           res.body.should.be.a('object')
           res.body.should.have.property('message').that.equals(dep.expectedError)
         }
       })
   }
 

  //dependancy testcase   
  // reqbody.dependancy.forEach(dep => {
  //   it(`should insert data into ${dep.endpoint.add}`, async function () {
  //     IISAutoTest.performRequest({
  //       method: 'post', endpoint: endpoint.add, body: dep.data, expectedStatus: 200, description: 'should create resource successfully',
  //       expectedResponse: (res) => {
  //         res.body.should.have.property('message').that.equals('Data inserted successfully.')
  //       }
  //     })
  //   })
  // })

})









