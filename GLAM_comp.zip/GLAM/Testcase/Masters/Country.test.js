import chai from 'chai';
import chaiHttp from 'chai-http';
import { Config, IISAutoTest, IISMethods, FieldConfig } from '../../config/Init.js'
import async from 'async'

chai.use(chaiHttp);
chai.config.includeStack = true
const { should } = chai
should()

const ObjectId = IISMethods.getobjectid()
const countryid = new ObjectId()
const stateid = new ObjectId()
const cityid = new ObjectId()

//api endpoint
const endpoint = {
  list: "/country",
  add: "/country/add",
  update: "/country/update",
  delete: "/country/delete",
  dataname :"Country"
};

//header parameter
const reqheader = {
  list: { useraction: "viewright", pagename: "country", apptype: 1 },
  add: { useraction: "addright", pagename: "country", apptype: 1 },
  update: { useraction: "editright", pagename: "country", apptype: 1 },
  delete: { useraction: "delright", pagename: "country", apptype: 1 },
}

//reqbody for diffrent testcase
const reqbody = {
  add: {
    _id: countryid,
    country: "India",
    flag: "India",
    countrydialcode: "+91",
    countrycode: "In"
  },
  update: {
    _id: countryid,
    country: "German"
  },
  delete: {
    _id: countryid
  },
  filter: {
    searchtext: "",
    paginationinfo: {
      pageno: 1,
      pagelimit: 200000000,
      filter: { "_id": [countryid.toString(), "66acc53ca826a13d00a88190"] },
      sort: {}
    }
  },
  sort: {
    searchtext: "",
    paginationinfo: {
      pageno: 1,
      pagelimit: 200000000,
      filter: {},
      projection: { country: 1 },
      sort: { country: 1 }
    }
  },
  search: {
    searchtext: "In",
    paginationinfo: {
      pageno: 1,
      pagelimit: 200000000,
      filter: {},
      projection: {},
      sort: {}
    }
  },
  dependancy: [
    {
      endpoint: { list: "/state", add: "/state/add" },
      match: ['country'],
      body: {
        _id: stateid,
        state: "mp",
        countryid: countryid,
        country: "German"
      },
      filter: {
        searchtext: "",
        paginationinfo: {
          pageno: 1,
          pagelimit: 2000,
          filter: { "countyid": [countryid] },
          projection: {},
          sort: {}
        }
      }
    },
    {
      endpoint: { list: "/city", add: "/city/add" },
      match: ['country'],
      body: {
        _id: cityid,
        city: "surat",
        stateid: stateid,
        state: "mp",
        countryid: countryid,
        country: "German"
      },
      filter: {
        searchtext: "",
        paginationinfo: {
          pageno: 1,
          pagelimit: 2000,
          filter: { "countyid": [stateid] },
          projection: {},
          sort: {}
        }
      }
    }
  ]
}

//invalid payload
const invalidDataTests = [
  {
    data: {
      country: "",
      status: 1,
      flag: "India",
      countrydialcode: "+91",
      countrycode: "In"
    },
    expectedError: 'Path `country` is required.',
    description: 'should return an error for empty country name'
  },
  {
    data: {
      country: "India",
      status: 1
    },
    expectedError: 'Path `flag` is required.,Path `countrydialcode` is required.,Path `countrycode` is required.',
    description: 'should return an error for required parameter'
  }
]

let authDetails

describe('Cruds', async function () {

  //employee authentication
  await IISAutoTest.EmployeeAuthTestcase()

  //common testcase
  const testCases = IISAutoTest.CommonTestcase({ endpoint, reqbody, reqheader })
  for (const testCase of testCases) {
    IISAutoTest.performRequest(testCase)
  }

  //diffrent scenario test
  for (const dep of invalidDataTests) {
    IISAutoTest.performRequest({
      method: 'post', endpoint: endpoint.add, body: dep.data, expectedStatus: 400, description: dep.description, headers: reqheader.add,
      expectedResponse: (res) => {
        res.should.be.a('object')
        res.body.should.be.a('object')
        res.body.should.have.property('message').that.equals(dep.expectedError)
      }
    })
  }


  //dependancy testcase   
  reqbody.dependancy.forEach(dep => {
    it(`should insert data into ${dep.endpoint.add}`, async function () {
      IISAutoTest.performRequest({
        method: 'post', endpoint: endpoint.add, body: dep.data, expectedStatus: 200, description: 'should create resource successfully', headers: reqheader.add,
        expectedResponse: (res) => {
          res.body.should.have.property('message').that.equals('Data inserted successfully.')
        }
      })
    })
  })

  //update dependancy testcase
  IISAutoTest.updateAndCheckDependencies('country', endpoint.update, reqbody, reqheader);
  IISAutoTest.deleteAndCheckDependencies('country', endpoint.delete, reqbody, reqheader);
  

  //concurrent request testcase
  it('should handle concurrent requests correctly without data corruption or errors', function (done) {
    this.timeout(30000);

    const numConcurrentRequests = 50;
    const requestBodies = Array(numConcurrentRequests).fill(Config.requestBody);

    // Create array of promises for concurrent requests
    const requestPromises = requestBodies.map(body => {
      return IISAutoTest.performRequest({
        method: 'post',
        endpoint: endpoint.list,
        body: body,
        expectedStatus: 200,
        description: 'concurrent requests check',
        headers: reqheader.list,
        expectedResponse: (res) => {
          res.should.have.status(200);
          res.body.should.be.a('object');
          res.body.should.have.property('status').eql(200);
        }
      });
    });

    // Use Promise.all to handle concurrent execution
    Promise.all(requestPromises)
      .then(() => done())
      .catch(err => done(err))
  })
})



