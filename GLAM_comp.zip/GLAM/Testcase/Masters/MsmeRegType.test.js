import chai from 'chai';
import chaiHttp from 'chai-http';
import { Config, IISAutoTest, IISMethods } from '../../config/Init.js'


chai.use(chaiHttp);
chai.config.includeStack = true
const { should } = chai
should()

const ObjectId = IISMethods.getobjectid()
const msmeregtypeid = new ObjectId()

const endpoint = {
  list: "/msmeregtype",
  add: "/msmeregtype/add",
  update: "/msmeregtype/update",
  delete: "/msmeregtype/delete",
    dataname :"MsmeRegType"
}

const reqheader = {
  list: { useraction: "viewright", pagename: "msmeregtype", apptype: 1 },
  add: { useraction: "addright", pagename: "msmeregtype", apptype: 1 },
  update: { useraction: "editright", pagename: "msmeregtype", apptype: 1 },
  delete: { useraction: "delright", pagename: "msmeregtype", apptype: 1 },
}

const reqbody = {
  add: {
    _id: msmeregtypeid,
    msmeregtype:"SWIGGY",
    status:1
  },
  update: {
    _id: msmeregtypeid,
    msmeregtype: "SWIGGYs"
  },
  delete: {
    _id: msmeregtypeid
  },
  filter: {
    searchtext: "",
    paginationinfo: {
      pageno: 1,
      pagelimit: 200000000,
      filter: { "_id": [msmeregtypeid.toString()] },
      sort: {}
    }
  },
  sort: {
    searchtext: "",
    paginationinfo: {
      pageno: 1,
      pagelimit: 200000000,
      filter: {},
      projection: { msmeregtype: 1 },
      sort: { msmeregtype: 1 }
    }
  },
  search: {
    searchtext: "sw",
    paginationinfo: {
      pageno: 1,
      pagelimit: 200000000,
      filter: {},
      projection: {},
      sort: {}
    }
  }
}


const invalidDataTests = [
  {
    data: {
        msmeregtype: "",
        status: 1
    },
    expectedError: 'Path `msmeregtype` is required.',
    description: 'should return an error for empty name'
  }
]


describe('Cruds', async function () {

  await IISAutoTest.EmployeeAuthTestcase()
 
  const testCases = IISAutoTest.CommonTestcase({ endpoint, reqbody,reqheader})
   for (const testCase of testCases) {
     IISAutoTest.performRequest(testCase)
   }
   
   //diffrent scenario test
   for (const dep of invalidDataTests) {
      IISAutoTest.performRequest({method: 'post',endpoint: endpoint.add,body: dep.data,expectedStatus: 400,description: dep.description,header: reqheader.add,
         expectedResponse: (res) => {
           res.should.be.a('object')
           res.body.should.be.a('object')
           res.body.should.have.property('message').that.equals(dep.expectedError)
         }
       })
   }
 
})









