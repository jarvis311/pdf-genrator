import chai from 'chai';
import chaiHttp from 'chai-http';
import { Config, IISAutoTest, IISMethods,FieldConfig } from '../../../config/Init.js'
import async from 'async'

chai.use(chaiHttp);
chai.config.includeStack = true
const { should} = chai
should()

const ObjectId = IISMethods.getobjectid()
const visitorid = new ObjectId()
const stateid = new ObjectId()
const cityid = new ObjectId()

const endpoint = {
  list: "/visitor",
  add: "/visitor/add",
  update: "/visitor/update",
  delete: "/visitor/delete"
};

const reqheader = {
  list:{useraction:"viewright",pagename:"visitor",apptype:1},
  add:{useraction:"addright",pagename:"visitor",apptype:1},
  update:{useraction:"editright",pagename:"visitor",apptype:1},
  delete:{useraction:"delright",pagename:"visitor",apptype:1},
}

const reqbody = {
  add: {
    _id: visitorid,
    "gatekeeperid": "64e0fe4f5311236168a10abc",
    "categoryid": "64e0fe4f5311236168a10def",
    "category": "Security",
    "propertyid": "64e0fe4f5311236168a10abc",
    "property": "Building A",

    "propertydetails": [
        {
            "buidingid": "64e0fe4f5311236168a10abc",
            "buiding": "Main Building",
            "floorid": "64e0fe4f5311236168a10abc",
            "floor": "Ground Floor",
            "unitid": "64e0fe4f5311236168a10abc",
            "unit": "Unit 101",
            "isallownotification": 1,
            "temporaryproperty": 0
        },
        {
            "buidingid": "64e0fe4f5311236168a10abc",
            "buiding": "Annex Building",
            "floorid": "64e0fe4f5311236168a10abc",
            "floor": "First Floor",
            "unitid": "64e0fe4f5311236168a10abc",
            "unit": "Unit 202",
            "isallownotification": 1,
            "temporaryproperty": 1
        }
    ],

    "contact": "9876543210",
    "isverify": 1,
    "personname": "John Doe",
    "vehicleno": "AB123CD",
    "deliverycompanyid": "64e0fe4f5311236168a10abc",
    "deliverycompany": "Fast Delivery Ltd.",

    "documents": {
        "documentname": "ID Proof",
        "documentfile": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAAAeP4ixAAAAAXNSR0IArs4c6QAAA1NJREFUaEPt2r9LclEYB/Cvk6RDYEPhICKCQ0N/gLm0NLhIgQ1OIji4RQ2RSGkE4uImOAgNOrg4BjU4qZNLkIMQ0lBBUFFDhFMvz3m5dl9/dO8951zTeA8Eeu+59zyf+zznEN5jabfbnw6HA1arFfPY+v0+Xl5eYOn1ep/0wev1YnFxca4sb29vuLm5ASXCcn9//2m329mBecIoCIr5/f39L8TpdEJ9YtYzMxzrw8PDF4Rqah4w42Icgcw6ZtKDHguZVcx31TIRMmsYrZL/FjIrGC0ExakJ+WmMHoRuyE9h9CIMQaaNMYIwDJkWxiiCC2I2hgfBDTELw4sQgsjGiCCEIbIwoggpEFGMDIQ0CC9GFkIqxChGJkI6RC9GNsIUiBbGDIRpkEkYsxCmQoYx9N3MHzd0/RtPQfA2JQt0vZm/0PyH6MmQek7MbWmNm9hzN9m/C9gsjPQ5oidQPX30lK66j1SIkQCN9NWDkgbhCYznmkkoKRCRgESulVpaMgKRcQ+hjMgIQHmqovfihogOPK7WRe7JBREZUGsF4r23YQjvQFoA9XmeMQxBeAYwAhDB6IZME8GzAOiC/ATCKEYTwot4fn5GJBLBxcUFiymTySCVSqHZbGJ9fZ0dK5fLrM+49vHxgd3dXRSLRXZ6a2sLhUIBr6+v2NnZwdXV1eCedN60V2/dbhelUgnpdBoLCwssGMIlk0mcnp7CZrPh6OgIsVgMPp9vxKLuu7S0xN42dzodVKtVJBIJds3JyQk2Njbg9/snQ3gzoUSkfvJra2ssAGrn5+fsSVOrVCpwu92o1+vweDwsO3Ss1+shHA4Pnjz1bTQaoL0AuVwOx8fHWF5eZtm9vb1l15n2epoCokaDKNmhzxS0GqL0yefzoN0Xj4+PgxKkvlSOSnb29vZwdnaGYDCI1dVVXF9fs/tRn6lsGFACiUajaLVaIxmh0hguJXWt0XyhMtze3sbl5SXi8Tju7u7w9PTE/kYyIlpO6sHV9UslQE+OanvcHHG5XCxQAlFfmle1Wm0kowcHB8hms2xeraysgL6HQiFsbm5+ZUT2phr1qkUDUanRpB1etWg1olILBAL/zJH9/f3BqqXMMZrgVKbKqnV4eMhWs8Gmml+zzem3bDz7Azf0RKt+wu2dAAAAAElFTkSuQmCC"
    },
    "isactive": 1,
    "clockin":1
  },
  update: {
    _id: visitorid,
    visitor: "German",
    status: 1
  },
  delete: {
    _id: visitorid
  },
  filter: {
    searchtext: "",
    paginationinfo: {
      pageno: 1,
      pagelimit: 200000000,
      filter: { "_id": [visitorid.toString(),"66acc53ca826a13d00a88190"] },
      sort: {}
    }
  },
  sort: {
    searchtext: "",
    paginationinfo: {
      pageno: 1,
      pagelimit: 200000000,
      filter: {},
      projection: { personname: 1 },
      sort: { personname: 1 }
    }
  },
  search: {
    searchtext: "In",
    paginationinfo: {
      pageno: 1,
      pagelimit: 200000000,
      filter: {},
      projection: {},
      sort: {}
    }
  },
  dependancy: [
    {
      endpoint: { list: "/state", add: "/state/add" },
      match: ['visitor'],
      body: {
        _id: stateid,
        state: "mp",
        visitorid: visitorid,
        visitor: "German"
      },
      filter: {
        searchtext: "",
        paginationinfo: {
          pageno: 1,
          pagelimit: 2000,
          filter: { "countyid": [visitorid] },
          projection: {},
          sort: {}
        }
      }
    },
    {
      endpoint: { list: "/city", add: "/city/add" },
      match: ['visitor'],
      body: {
        _id: cityid,
        city: "surat",
        stateid: stateid,
        state: "mp",
        visitorid: visitorid,
        visitor: "German"
      },
      filter: {
        searchtext: "",
        paginationinfo: {
          pageno: 1,
          pagelimit: 2000,
          filter: { "countyid": [stateid] },
          projection: {},
          sort: {}
        }
      }
    }
  ]
}


const invalidDataTests = [
  {
    data: {
        "gatekeeperid": "64e0fe4f5311236168a10abc",
        "categoryid": "64e0fe4f5311236168a10def",
        "category": "Security",
        "propertyid": "64e0fe4f5311236168a10abc",
        "property": "Building A",
    
        "propertydetails": [
            {
                "buidingid": "64e0fe4f5311236168a10abc",
                "buiding": "Main Building",
                "floorid": "64e0fe4f5311236168a10abc",
                "floor": "Ground Floor",
                "unitid": "64e0fe4f5311236168a10abc",
                "unit": "Unit 101",
                "isallownotification": 1,
                "temporaryproperty": 0
            },
            {
                "buidingid": "64e0fe4f5311236168a10abc",
                "buiding": "Annex Building",
                "floorid": "64e0fe4f5311236168a10abc",
                "floor": "First Floor",
                "unitid": "64e0fe4f5311236168a10abc",
                "unit": "Unit 202",
                "isallownotification": 1,
                "temporaryproperty": 1
            }
        ],
    
        "contact": "9876543210",
        "isverify": 1,
        "personname": "",
        "vehicleno": "AB123CD",
        "deliverycompanyid": "64e0fe4f5311236168a10abc",
        "deliverycompany": "Fast Delivery Ltd.",
    
        "documents": {
            "documentname": "ID Proof",
            "documentfile": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAAAeP4ixAAAAAXNSR0IArs4c6QAAA1NJREFUaEPt2r9LclEYB/Cvk6RDYEPhICKCQ0N/gLm0NLhIgQ1OIji4RQ2RSGkE4uImOAgNOrg4BjU4qZNLkIMQ0lBBUFFDhFMvz3m5dl9/dO8951zTeA8Eeu+59zyf+zznEN5jabfbnw6HA1arFfPY+v0+Xl5eYOn1ep/0wev1YnFxca4sb29vuLm5ASXCcn9//2m329mBecIoCIr5/f39L8TpdEJ9YtYzMxzrw8PDF4Rqah4w42Icgcw6ZtKDHguZVcx31TIRMmsYrZL/FjIrGC0ExakJ+WmMHoRuyE9h9CIMQaaNMYIwDJkWxiiCC2I2hgfBDTELw4sQgsjGiCCEIbIwoggpEFGMDIQ0CC9GFkIqxChGJkI6RC9GNsIUiBbGDIRpkEkYsxCmQoYx9N3MHzd0/RtPQfA2JQt0vZm/0PyH6MmQek7MbWmNm9hzN9m/C9gsjPQ5oidQPX30lK66j1SIkQCN9NWDkgbhCYznmkkoKRCRgESulVpaMgKRcQ+hjMgIQHmqovfihogOPK7WRe7JBREZUGsF4r23YQjvQFoA9XmeMQxBeAYwAhDB6IZME8GzAOiC/ATCKEYTwot4fn5GJBLBxcUFiymTySCVSqHZbGJ9fZ0dK5fLrM+49vHxgd3dXRSLRXZ6a2sLhUIBr6+v2NnZwdXV1eCedN60V2/dbhelUgnpdBoLCwssGMIlk0mcnp7CZrPh6OgIsVgMPp9vxKLuu7S0xN42dzodVKtVJBIJds3JyQk2Njbg9/snQ3gzoUSkfvJra2ssAGrn5+fsSVOrVCpwu92o1+vweDwsO3Ss1+shHA4Pnjz1bTQaoL0AuVwOx8fHWF5eZtm9vb1l15n2epoCokaDKNmhzxS0GqL0yefzoN0Xj4+PgxKkvlSOSnb29vZwdnaGYDCI1dVVXF9fs/tRn6lsGFACiUajaLVaIxmh0hguJXWt0XyhMtze3sbl5SXi8Tju7u7w9PTE/kYyIlpO6sHV9UslQE+OanvcHHG5XCxQAlFfmle1Wm0kowcHB8hms2xeraysgL6HQiFsbm5+ZUT2phr1qkUDUanRpB1etWg1olILBAL/zJH9/f3BqqXMMZrgVKbKqnV4eMhWs8Gmml+zzem3bDz7Azf0RKt+wu2dAAAAAElFTkSuQmCC"
        },
        
        "isactive": 1,
        "clockin":1
    },
    expectedError: 'Path `personname` is required.',
    description: 'should return an error for empty visitor name'
  },
  {
    data: {
        "gatekeeperid": "64e0fe4f5311236168a10abc",
        "categoryid": "64e0fe4f5311236168a10def",
        "category": "Security",
        "propertyid": "64e0fe4f5311236168a10abc",
        "property": "Building A",
    
        "propertydetails": [
            {
                "buidingid": "64e0fe4f5311236168a10abc",
                "buiding": "Main Building",
                "floorid": "64e0fe4f5311236168a10abc",
                "floor": "Ground Floor",
                "unitid": "64e0fe4f5311236168a10abc",
                "unit": "Unit 101",
                "isallownotification": 1,
                "temporaryproperty": 0
            },
            {
                "buidingid": "64e0fe4f5311236168a10abc",
                "buiding": "Annex Building",
                "floorid": "64e0fe4f5311236168a10abc",
                "floor": "First Floor",
                "unitid": "64e0fe4f5311236168a10abc",
                "unit": "Unit 202",
                "isallownotification": 1,
                "temporaryproperty": 1
            }
        ],
    
        "contact": "9876543210",
        "isverify": 1,
        "personname": "",
        "vehicleno": "AB123CD",
        "deliverycompanyid": "64e0fe4f5311236168a10abc",
        "deliverycompany": "Fast Delivery Ltd.",
    
        "documents": {
            "documentname": "ID Proof",
            "documentfile": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAAAeP4ixAAAAAXNSR0IArs4c6QAAA1NJREFUaEPt2r9LclEYB/Cvk6RDYEPhICKCQ0N/gLm0NLhIgQ1OIji4RQ2RSGkE4uImOAgNOrg4BjU4qZNLkIMQ0lBBUFFDhFMvz3m5dl9/dO8951zTeA8Eeu+59zyf+zznEN5jabfbnw6HA1arFfPY+v0+Xl5eYOn1ep/0wev1YnFxca4sb29vuLm5ASXCcn9//2m329mBecIoCIr5/f39L8TpdEJ9YtYzMxzrw8PDF4Rqah4w42Icgcw6ZtKDHguZVcx31TIRMmsYrZL/FjIrGC0ExakJ+WmMHoRuyE9h9CIMQaaNMYIwDJkWxiiCC2I2hgfBDTELw4sQgsjGiCCEIbIwoggpEFGMDIQ0CC9GFkIqxChGJkI6RC9GNsIUiBbGDIRpkEkYsxCmQoYx9N3MHzd0/RtPQfA2JQt0vZm/0PyH6MmQek7MbWmNm9hzN9m/C9gsjPQ5oidQPX30lK66j1SIkQCN9NWDkgbhCYznmkkoKRCRgESulVpaMgKRcQ+hjMgIQHmqovfihogOPK7WRe7JBREZUGsF4r23YQjvQFoA9XmeMQxBeAYwAhDB6IZME8GzAOiC/ATCKEYTwot4fn5GJBLBxcUFiymTySCVSqHZbGJ9fZ0dK5fLrM+49vHxgd3dXRSLRXZ6a2sLhUIBr6+v2NnZwdXV1eCedN60V2/dbhelUgnpdBoLCwssGMIlk0mcnp7CZrPh6OgIsVgMPp9vxKLuu7S0xN42dzodVKtVJBIJds3JyQk2Njbg9/snQ3gzoUSkfvJra2ssAGrn5+fsSVOrVCpwu92o1+vweDwsO3Ss1+shHA4Pnjz1bTQaoL0AuVwOx8fHWF5eZtm9vb1l15n2epoCokaDKNmhzxS0GqL0yefzoN0Xj4+PgxKkvlSOSnb29vZwdnaGYDCI1dVVXF9fs/tRn6lsGFACiUajaLVaIxmh0hguJXWt0XyhMtze3sbl5SXi8Tju7u7w9PTE/kYyIlpO6sHV9UslQE+OanvcHHG5XCxQAlFfmle1Wm0kowcHB8hms2xeraysgL6HQiFsbm5+ZUT2phr1qkUDUanRpB1etWg1olILBAL/zJH9/f3BqqXMMZrgVKbKqnV4eMhWs8Gmml+zzem3bDz7Azf0RKt+wu2dAAAAAElFTkSuQmCC"
        },
        
        "isactive": 1,
        "clockin":1
    },
    expectedError: 'Path `flag` is required.,Path `visitordialcode` is required.,Path `visitorcode` is required.',
    description: 'should return an error for required parameter'
  }
]

let authDetails

describe('Cruds', async function () {

 await IISAutoTest.AuthTestcase()

 const testCases = IISAutoTest.CommonTestcase({ endpoint, reqbody,reqheader})
  for (const testCase of testCases) {
    IISAutoTest.performRequest(testCase)
  }
  
  //diffrent scenario test
  for (const dep of invalidDataTests) {
     IISAutoTest.performRequest({method: 'post',endpoint: endpoint.add,body: dep.data,expectedStatus: 400,description: dep.description,
        expectedResponse: (res) => {
          res.should.be.a('object')
          res.body.should.be.a('object')
          res.body.should.have.property('message').that.equals(dep.expectedError)
        }
      })
  }


  //dependancy testcase   
  reqbody.dependancy.forEach(dep => {
    it(`should insert data into ${dep.endpoint.add}`, async function () {
      IISAutoTest.performRequest({method: 'post', endpoint: endpoint.add, body: dep.data, expectedStatus: 200, description: 'should create resource successfully',
        expectedResponse: (res) => {
          res.body.should.have.property('message').that.equals('Data inserted successfully.')
        }
      })
    })
  })

  it('should update visitor and all dependencies dynamically', async function () {
    IISAutoTest.performRequest({ method: 'post', endpoint: endpoint.update, body: reqbody.update, expectedStatus: 200,description: 'should update resource successfully',
      expectedResponse: async (res) => {
        res.body.should.have.property('message').that.equals('Data updated successfully.');
        res.should.have.status(200);
      }
    });

    for (const dep of reqbody.dependancy) {
      it(`should validate ${dep.endpoint.list} and all dependencies dynamically`, async function () {
        IISAutoTest.performRequest({method: 'post',endpoint: dep.endpoint.list,body: dep.filter,expectedStatus: 200,description: 'dependencies check',
          expectedResponse: async (res1) => {
            res1.should.have.status(200)
            const records = res1.body.data

            for (const matchKey of dep.match) {
              const matchValue = reqbody.update[matchKey]
              const matchExists = records.some(record => record[matchKey] === matchValue)
              matchExists.should.be.true
            }
          }
        })
      })
    }
  })

  // Concurrent requests test
  it('should handle concurrent requests correctly without data corruption or errors', function (done) {
    this.timeout(30000);

    const numConcurrentRequests = 50;
    const requestBodies = Array(numConcurrentRequests).fill(Config.requestBody)

    const requestFunctions = requestBodies.map(body => {
      return (callback) => {
        chai.request.execute(Config.getBaseurl())
          .post(endpoint.list)
          .send(body)
          .end((err, res) => {
            if (err) return callback(err)

            try {
              res.should.have.status(200)
              res.body.should.be.a('object')
              res.body.should.have.property('status').eql(200)
              callback()
            } catch (e) {
              callback(e)
            }
          })
      }
    })

    async.parallel(requestFunctions, (err) => {
      if (err) return done(err)
      done()
    })
  })

})



