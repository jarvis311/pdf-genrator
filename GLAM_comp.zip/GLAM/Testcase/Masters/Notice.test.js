import chai from 'chai';
import chaiHttp from 'chai-http';
import { Config, IISAutoTest, IISMethods,FieldConfig } from '../../config/Init.js'
import async from 'async'

chai.use(chaiHttp);
chai.config.includeStack = true
const { should} = chai
should()

const ObjectId = IISMethods.getobjectid()
const noticeid = new ObjectId()
const stateid = new ObjectId()
const cityid = new ObjectId()

const endpoint = {
  list: "/notice",
  add: "/notice/add",
  update: "/notice/update",
  delete: "/notice/delete",
  dataname :"notice"
};

const reqheader = {
  list:{useraction:"viewright",pagename:"notice",apptype:1},
  add:{useraction:"addright",pagename:"notice",apptype:1},
  update:{useraction:"editright",pagename:"notice",apptype:1},
  delete:{useraction:"delright",pagename:"notice",apptype:1},
}

const reqbody = {
  add: {
    _id: noticeid,
    "title":"GHM ON 29TH MARCH",
    "description":"Lent Course Don’t forget about our Lent Course – “Tales of the Unexpected Monday Evening @ St Philips starting at 7pm:  28th March, 4th April, 11th April Thursday Daytime @ St Martins starting at 12 noon:  31st March, 7th April, 14th AprilAPCM",
    "date":"2024-07-31T07:44:37.684+00:00",
    "image":"static.jpg",
    "isactive":"1"
  },
  update: {
    _id: noticeid,
    "title":"GHM ON 29TH MARCH",
    "description":"Lent Course Don’t forget about our Lent Course – “Tales of the Unexpected Monday Evening @ St Philips starting at 7pm:  28th March, 4th April, 11th April Thursday Daytime @ St Martins starting at 12 noon:  31st March, 7th April, 14th AprilAPCM",
    "date":"2024-07-31T07:44:37.684+00:00",
    "image":"static.jpg",
    "isactive":"1"
  },
  delete: {
    _id: noticeid
  },
  filter: {
    searchtext: "",
    paginationinfo: {
      pageno: 1,
      pagelimit: 200000000,
      filter: { "_id": [noticeid.toString(),"66acc53ca826a13d00a88190"] },
      sort: {}
    }
  },
  sort: {
    searchtext: "",
    paginationinfo: {
      pageno: 1,
      pagelimit: 200000000,
      filter: {},
      projection: { title: 1 },
      sort: { title: 1 }
    }
  },
  search: {
    searchtext: "In",
    paginationinfo: {
      pageno: 1,
      pagelimit: 200000000,
      filter: {},
      projection: {},
      sort: {}
    }
  },
  dependancy: [
    {
      endpoint: { list: "/state", add: "/state/add" },
      match: ['notice'],
      body: {
        _id: stateid,
        state: "mp",
        noticeid: noticeid,
        notice: "German"
      },
      filter: {
        searchtext: "",
        paginationinfo: {
          pageno: 1,
          pagelimit: 2000,
          filter: { "countyid": [noticeid] },
          projection: {},
          sort: {}
        }
      }
    },
    {
      endpoint: { list: "/city", add: "/city/add" },
      match: ['notice'],
      body: {
        _id: cityid,
        city: "surat",
        stateid: stateid,
        state: "mp",
        noticeid: noticeid,
        notice: "German"
      },
      filter: {
        searchtext: "",
        paginationinfo: {
          pageno: 1,
          pagelimit: 2000,
          filter: { "countyid": [stateid] },
          projection: {},
          sort: {}
        }
      }
    }
  ]
}


const invalidDataTests = [
  {
    data: {
    "title":"",
    "description":"",
    "image":"static.jpg",
    },
    expectedError: 'Path `title` is required.,Path `description` is required.',
    description: 'should return an error for empty notice name'
  },
  {
    data: {
    "title":"",
    "description":"das ad",
    "image":"static.jpg"
    },
    expectedError: 'Path `title` is required.',
    description: 'should return an error for required parameter'
  }
]


describe('Cruds', async function () {

 await IISAutoTest.EmployeeAuthTestcase()

 const testCases = IISAutoTest.CommonTestcase({ endpoint, reqbody,reqheader})
  for (const testCase of testCases) {
    IISAutoTest.performRequest(testCase)
  }
  
  //diffrent scenario test
  for (const dep of invalidDataTests) {
     IISAutoTest.performRequest({method: 'post',endpoint: endpoint.add,body: dep.data,expectedStatus: 400,description: dep.description,headers: reqheader.add,
        expectedResponse: (res) => {
          res.should.be.a('object')
          res.body.should.be.a('object')
          res.body.should.have.property('message').that.equals(dep.expectedError)
        }
      })
  }


  //dependancy testcase   
  reqbody.dependancy.forEach(dep => {
    it(`should insert data into ${dep.endpoint.add}`, async function () {
      IISAutoTest.performRequest({method: 'post', endpoint: endpoint.add, body: dep.data, expectedStatus: 200, description: 'should create resource successfully',headers: reqheader.add,
        expectedResponse: (res) => {
          res.body.should.have.property('message').that.equals('Data inserted successfully.')
        }
      })
    })
  })

  it('should update notice and all dependencies dynamically', async function () {
    IISAutoTest.performRequest({ method: 'post', endpoint: endpoint.update, body: reqbody.update, expectedStatus: 200,description: 'should update resource successfully',reqheader: reqheader.update,
      expectedResponse: async (res) => {
        res.body.should.have.property('message').that.equals('Data updated successfully.');
        res.should.have.status(200);
      }
    });

    for (const dep of reqbody.dependancy) {
      it(`should validate ${dep.endpoint.list} and all dependencies dynamically`, async function () {
        IISAutoTest.performRequest({method: 'post',endpoint: dep.endpoint.list,body: dep.filter,expectedStatus: 200,description: 'dependencies check',headers: reqheader.list,
          expectedResponse: async (res1) => {
            res1.should.have.status(200)
            const records = res1.body.data

            for (const matchKey of dep.match) {
              const matchValue = reqbody.update[matchKey]
              const matchExists = records.some(record => record[matchKey] === matchValue)
              matchExists.should.be.true
            }
          }
        })
      })
    }
  })

  // Concurrent requests test
  it('should handle concurrent requests correctly without data corruption or errors', function (done) {
    this.timeout(30000);

    const numConcurrentRequests = 50;
    const requestBodies = Array(numConcurrentRequests).fill(Config.requestBody)

    const requestFunctions = requestBodies.map(body => {
      return (callback) => {
        chai.request.execute(Config.getBaseurl())
          .post(endpoint.list)
          .send(body)
          .end((err, res) => {
            if (err) return callback(err)

            try {
              res.should.have.status(200)
              res.body.should.be.a('object')
              res.body.should.have.property('status').eql(200)
              callback()
            } catch (e) {
              callback(e)
            }
          })
      }
    })

    async.parallel(requestFunctions, (err) => {
      if (err) return done(err)
      done()
    })
  })

})



