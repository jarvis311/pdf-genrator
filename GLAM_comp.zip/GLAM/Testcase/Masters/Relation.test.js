import chai from 'chai';
import chaiHttp from 'chai-http';
import { Config, IISAutoTest, IISMethods } from '../../config/Init.js'


chai.use(chaiHttp);
chai.config.includeStack = true
const { should } = chai
should()

const ObjectId = IISMethods.getobjectid()
const relationid = new ObjectId()

const endpoint = {
  list: "/relation",
  add: "/relation/add",
  update: "/relation/update",
  delete: "/relation/delete",
  dataname :"Relation"
}

const reqheader = {
  list: { useraction: "viewright", pagename: "relation", apptype: 1 },
  add: { useraction: "addright", pagename: "relation", apptype: 1 },
  update: { useraction: "editright", pagename: "relation", apptype: 1 },
  delete: { useraction: "delright", pagename: "relation", apptype: 1 },
}

const reqbody = {
  add: {
    _id: relationid,
    relation:"Mother",
    status:1  
  },
  update: {
    _id: relationid,
    relation: "Mother"
  },
  delete: {
    _id: relationid
  },
  filter: {
    searchtext: "",
    paginationinfo: {
      pageno: 1,
      pagelimit: 200000000,
      filter: { "_id": [relationid.toString(),"66acc53ca826a13d00a88190"] },
      sort: {}
    }
  },
  sort: {
    searchtext: "",
    paginationinfo: {
      pageno: 1,
      pagelimit: 200000000,
      filter: {},
      projection: { relation: 1 },
      sort: { relation: 1 }
    }
  },
  search: {
    searchtext: "MO",
    paginationinfo: {
      pageno: 1,
      pagelimit: 200000000,
      filter: {},
      projection: {},
      sort: {}
    }
  }
}


const invalidDataTests = [
  {
    data: {
        relation: "",
        status: 1
    },
    expectedError: 'Path `relation` is required.',
    description: 'should return an error for empty name'
  }
]

describe('Cruds', async function () {

  await IISAutoTest.EmployeeAuthTestcase()
 
  const testCases = IISAutoTest.CommonTestcase({ endpoint, reqbody,reqheader})
   for (const testCase of testCases) {
     IISAutoTest.performRequest(testCase)
   }
   
   //diffrent scenario test
   for (const dep of invalidDataTests) {
      IISAutoTest.performRequest({method: 'post',endpoint: endpoint.add,body: dep.data,expectedStatus: 400,description: dep.description,headers: reqheader.add,
         expectedResponse: (res) => {
           res.should.be.a('object')
           res.body.should.be.a('object')
           res.body.should.have.property('message').that.equals(dep.expectedError)
         }
       })
   }
 

})









