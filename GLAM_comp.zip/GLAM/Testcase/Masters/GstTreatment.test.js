import chai from 'chai';
import chaiHttp from 'chai-http';
import { Config, IISAutoTest, IISMethods } from '../../config/Init.js'


chai.use(chaiHttp);
chai.config.includeStack = true
const { should } = chai
should()

const ObjectId = IISMethods.getobjectid()
const gsttreatmentid = new ObjectId()

const endpoint = {
  list: "/gsttreatment",
  add: "/gsttreatment/add",
  update: "/gsttreatment/update",
  delete: "/gsttreatment/delete",
  dataname :"GST Treatment"
}

const reqheader = {
  list: { useraction: "viewright", pagename: "gsttreatment", apptype: 1 },
  add: { useraction: "addright", pagename: "gsttreatment", apptype: 1 },
  update: { useraction: "editright", pagename: "gsttreatment", apptype: 1 },
  delete: { useraction: "delright", pagename: "gsttreatment", apptype: 1 },
}

const reqbody = {
  add: {
    _id: gsttreatmentid,
    gsttreatment:"SWIGGY",
    status:1
  },
  update: {
    _id: gsttreatmentid,
    gsttreatment: "SWIGGYs"
  },
  delete: {
    _id: gsttreatmentid
  },
  filter: {
    searchtext: "",
    paginationinfo: {
      pageno: 1,
      pagelimit: 200000000,
      filter: { "_id": [gsttreatmentid.toString()] },
      sort: {}
    }
  },
  sort: {
    searchtext: "",
    paginationinfo: {
      pageno: 1,
      pagelimit: 200000000,
      filter: {},
      projection: { gsttreatment: 1 },
      sort: { gsttreatment: 1 }
    }
  },
  search: {
    searchtext: "sw",
    paginationinfo: {
      pageno: 1,
      pagelimit: 200000000,
      filter: {},
      projection: {},
      sort: {}
    }
  }
}


const invalidDataTests = [
  {
    data: {
        gsttreatment: "",
        status: 1
    },
    expectedError: 'Path `gsttreatment` is required.',
    description: 'should return an error for empty name'
  }
]


describe('Cruds', async function () {

  await IISAutoTest.EmployeeAuthTestcase()
 
  const testCases = IISAutoTest.CommonTestcase({ endpoint, reqbody,reqheader})
   for (const testCase of testCases) {
     IISAutoTest.performRequest(testCase)
   }
   
   //diffrent scenario test
   for (const dep of invalidDataTests) {
      IISAutoTest.performRequest({method: 'post',endpoint: endpoint.add,body: dep.data,expectedStatus: 400,description: dep.description,header: reqheader.add,
         expectedResponse: (res) => {
           res.should.be.a('object')
           res.body.should.be.a('object')
           res.body.should.have.property('message').that.equals(dep.expectedError)
         }
       })
   }
 
})









