import chai from 'chai';
import chaiHttp from 'chai-http';
import { Config, IISAutoTest, IISMethods } from '../../config/Init.js'


chai.use(chaiHttp);
chai.config.includeStack = true
const { should, expect } = chai
should()

const ObjectId = IISMethods.getobjectid()
const categoryid = new ObjectId()

const endpoint = {
  list: "/category",
  add: "/category/add",
  update: "/category/update",
  delete: "/category/delete",
  dataname :"Category"
}

const reqheader = {
  list: { useraction: "viewright", pagename: "category", apptype: 1 },
  add: { useraction: "addright", pagename: "category", apptype: 1 },
  update: { useraction: "editright", pagename: "category", apptype: 1 },
  delete: { useraction: "delright", pagename: "category", apptype: 1 },
}

const reqbody = {
  add: {
    _id: categoryid,
    name:"MILKMAN",
    hascompanyselection:1,
    isservice:1,
    isactive:1,
  },
  update: {
    _id: categoryid,
    name:"OP",
    hascompanyselection:1,
    isservice:1,
    isactive:1,
  },
  delete: {
    _id: categoryid
  },
  filter: {
    searchtext: "",
    paginationinfo: {
      pageno: 1,
      pagelimit: 200000000,
      filter: { "_id": [categoryid.toString()] },
      sort: {}
    }
  },
  sort: {
    searchtext: "",
    paginationinfo: {
      pageno: 1,
      pagelimit: 200000000,
      filter: {},
      projection: { name: 1 },
      sort: { name: 1 }
    }
  },
  search: {
    searchtext: "op",
    paginationinfo: {
      pageno: 1,
      pagelimit: 200000000,
      filter: {},
      projection: {},
      sort: {}
    }
  },
//   dependancy: [
//     {
//       endpoint: { list: "/state", add: "/state/add" },
//       match: ['country'],
//       body: {
//         _id: stateid,
//         state: "mp",
//         categoryid: categoryid,
//         country: "German"
//       },
//       filter: {
//         searchtext: "",
//         paginationinfo: {
//           pageno: 1,
//           pagelimit: 2000,
//           filter: { "countyid": [categoryid] },
//           projection: {},
//           sort: {}
//         }
//       }
//     },
//     {
//       endpoint: { list: "/city", add: "/city/add" },
//       match: ['country'],
//       body: {
//         _id: cityid,
//         city: "surat",
//         stateid: stateid,
//         state: "mp",
//         categoryid: categoryid,
//         country: "German"
//       },
//       filter: {
//         searchtext: "",
//         paginationinfo: {
//           pageno: 1,
//           pagelimit: 2000,
//           filter: { "countyid": [stateid] },
//           projection: {},
//           sort: {}
//         }
//       }
//     }
//   ]
}


const invalidDataTests = [
  {
    data: {
        name:"",
        hascompanyselection:1,
        isservice:1,
        isactive:1
    },
    expectedError: 'Path `name` is required.',
    description: 'should return an error for empty name'
  }
]

describe('Cruds', async function () {

  await IISAutoTest.EmployeeAuthTestcase()
 
  const testCases = IISAutoTest.CommonTestcase({ endpoint, reqbody,reqheader})
   for (const testCase of testCases) {
     IISAutoTest.performRequest(testCase)
   }
   
   //diffrent scenario test
   for (const dep of invalidDataTests) {
      IISAutoTest.performRequest({method: 'post',endpoint: endpoint.add,body: dep.data,expectedStatus: 400,description: dep.description,headers: reqheader.add,
         expectedResponse: (res) => {
           res.should.be.a('object')
           res.body.should.be.a('object')
           res.body.should.have.property('message').that.equals(dep.expectedError)
         }
       })
   }
 
})





