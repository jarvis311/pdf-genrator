import dotenv1 from "dotenv"

if (!["uat", "production","dev"].includes(process.env.NODE_ENV)) {
	dotenv1.config({ path: ".env" })
}

import http from "http"
import express from "express"
import cors from "cors"
import fileUpload from "express-fileupload"

import _Config from "./config/Config.js"
import route from "./Route.js"

const Config = new _Config()

const app = express()
const server = http.createServer(app)

// PORT ON SERVER RUNS
const port = Config.port

app.disable("x-powered-by")

app.use((req, res, next) => {
    try {
        decodeURIComponent(req.path)
    } catch (err) {
        return res.status(400).send({ status: 400, message: Config.getResponsestatuscode()["400"] })
    }

    next()
})

// ALLOW FILE UPLOAD
app.use(fileUpload())

// SERVER START
app.use(express.json({ limit: "50mb" }))

app.use((err, req, res, next) => {
    if (err instanceof SyntaxError && err.status === 400 && "body" in err) {
        return res.status(400).send({ status: 400, message: Config.getResponsestatuscode()["400"] })
    }

    next()
})

// Decode X-WWW-FORM-URLENCODED
app.use(express.urlencoded({ extended: true }))

// CORS
app.use(cors({ origin: true, exposedHeaders: ["key", "token", "unqkey", "domainname", "resheader"] }))

// API ROUTES
app.use("/", route)



//---------------------test case------------------
// export const testcase = (req, res) => {
//     const { filepath, a, b } = req.body;

//     if (!filepath) {
//         return res.status(400).json({ message: 'Filepath is required in request body' });
//     }

//     const mochaPath = path.join(process.cwd(), 'node_modules', '.bin', 'mocha');
//     // Use double quotes for --body option value to prevent issues with JSON string
//     const command = `${mochaPath} ${filepath} --body=${JSON.stringify(req.body)}`;

//     exec(command, (error, stdout, stderr) => {
//         if (error) {
//             console.error(`Error executing tests: ${error}`);
//             res.status(500).json({ message: 'Error executing tests', error: error });
//         } else {
//             console.log(`Test execution successful:\n${stdout}`);
//             res.status(200).json({ message: 'Tests executed successfully', stdout, stderr });
//         }
//     });
// };

// app.post('/v1/testcase', testcase);

//-------------------------------test case------------------------------------------

// API NOT FOUND
app.use("*", (req, res) => {
    res.status(404).send({ status: 404, message: Config.getErrmsg()["apinotfound"] })
})

server.listen(port, "0.0.0.0", () => {
    console.log("Node app is running on port...." + port)
})

// // Cron Jobs
// await import("./workers/Queue_Process.js")

// if (process.env.CRONJOB_SERVER === "cronjobserver") {
//     await import("./cronjobs/Schedule_Jobs.js")
// }

// if (process.argv[2] === "test") {
//     process.exit(0)
// }

export { server,app }
