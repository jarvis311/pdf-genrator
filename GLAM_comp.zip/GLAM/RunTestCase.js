import { IISMethods, Config } from "./config/Init.js"
import { exec } from 'child_process'
import path from 'path'

export default class RunTestCase {
	// List Vendor
    async RunTestCase(req,res,next){
        try{
            var ResponseBody = {};

            const { filepath, a, b } = req.body;

            if (!filepath) {
                ResponseBody.status = 401
			    ResponseBody.message = "Filepath is required in request body"
            }
        
            const mochaPath = path.join(process.cwd(), 'node_modules', '.bin', 'mocha');
            // Use double quotes for --body option value to prevent issues with JSON string
            const command = `${mochaPath} ${filepath} --body=${JSON.stringify(req.body)}`;
        
            console.log(command)
            console.log("----------------------")

            exec(command, (error, stdout, stderr) => {
                if (error) {
                    console.error(`Error executing tests: ${error}`);
                    res.status(500).json({ message: 'Error executing tests', error: error });
                } else {
                    console.log(`Test execution successful:\n${stdout}`);
                    res.status(200).json({ message: 'Tests executed successfully', stdout, stderr });
                }
            });
        
            // exec(command, (error, stdout, stderr) => {
            //     if (error) {
            //         console.error(`Error executing tests: ${error}`);
            //          ResponseBody.status = 500
			//          ResponseBody.message = "Error executing tests"
            //          ResponseBody.data = error
            //     } else {
            //         console.log(`Test execution successful:\n${stdout}`);
            //         ResponseBody.status = 200
            //         ResponseBody.message = "Test execution successful"
            //         ResponseBody.data = stdout
            //     }
            // });

            //  req.ResponseBody = ResponseBody
            // next()
        }catch (err) {
            console.log(err)
			req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
			next()
		}
    }

}
