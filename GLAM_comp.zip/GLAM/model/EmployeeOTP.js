import mongoose from "mongoose"

export default class EmployeeOTP {
	constructor() {
		this._id
		this.personid = { type: mongoose.Schema.Types.ObjectId, ref: "tblemployee" }
		this.email = { type: String }
		this.contact = { type: String }
		this.otp = { type: String }
		this.isused = { type: Number, default: 0 }
		this.verify = { type: Number, default: 0 } // for forgot pass
		this.type = { type: Number } // 1: Login Pass  2: Forgot Pass
		this.time = { type: Date, default: Date.now }
	}
}
