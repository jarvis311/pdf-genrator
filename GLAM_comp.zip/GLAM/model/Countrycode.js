import mongoose from 'mongoose';
import _Config from '../config/Config.js'

export default class Vendor {
    constructor () {
        this._id;
        this.name = { type: String };
        this.dial_code = { type: String };
        this.code = { type: String };
    }
}