import  mongoose  from 'mongoose'
import _Config from '../../config/Config.js'

export default class LogManage
{ 
    constructor(){
        this._id
        this.DeviceLogId = {type:String, required:[true, 'Devicelog ID is required']}
        this.DeviceId = {type: String, required:false}
        this.gatekeeper = {type:String,required:false}
        this.gatekeeperid = {type:mongoose.Schema.Types.ObjectId, ref: 'tblgatekeeper'}
        this.propertyid = {type:mongoose.Schema.Types.ObjectId, ref: 'tblpropertymaster'}
        this.property = {type:String,required:false}
        this.visitorid = {type:mongoose.Schema.Types.ObjectId, ref: 'tblvisitor'}
        this.visitor = {type:String}
        this.categoryid = {type:mongoose.Schema.Types.ObjectId, ref: 'tblvisitorcategory'}
        this.category = {type:String}
        this.C1 = {type:String}
        this.C2 = {type:String}
        this.C3 = {type:String}
        this.C4 = {type:String}
        this.C5 = {type: String}
        this.C6 = {type: String}
        this.C7 = {type:String}
        this.LogDate = {type:Date}
        this.documents = { type:Object,default:{} }
        this.LogDetail = {type: String}
        this.datestr = {type:String}
        this.clockintype = {type:Number} // 1 : clock in , 2 : clock out
        this.visitortype = {type:Number} // 1:new visitor , 2:pre approve visitor
        this.recordinfo = {type : mongoose.Schema.Types.Mixed, ref: 'recordinfo'}
    }
}