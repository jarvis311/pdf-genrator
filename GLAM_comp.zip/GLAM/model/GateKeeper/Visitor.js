import mongoose from "mongoose"
import _Config from "../../config/Config.js"

const Config = new _Config()
export default class Visitor {
  constructor() {
    this._id
    this.gatekeeperid = { type: mongoose.Schema.Types.ObjectId, ref: "tblgatekeeper" }
    this.categoryid = { type: mongoose.Schema.Types.ObjectId, ref: "tblcategorymaster" }
    this.category = { type: String }
    this.propertyid = { type: mongoose.Schema.Types.ObjectId, ref: "tblproperty" },
      this.property = { type: String, required: true },
      this.propertydetails = [
        {
          wingid: { type: mongoose.Schema.Types.ObjectId, ref: "tblpropertybuilding" },
          wing: { type: String },
          floorid: { type: mongoose.Schema.Types.ObjectId, ref: "tblpropertyfloor" },
          floor: { type: String },
          unitid: { type: mongoose.Schema.Types.ObjectId, ref: "tblpropertyunit" },
          unit: { type: String },
          isallownotification: { type: Number, default: 1 },
          temporaryproperty: { type: Number, default: 0 }
        }
      ]
    this.propertyarea = [
      {
        wingid: { type: mongoose.Schema.Types.ObjectId, ref: "tblpropertybuilding" },
        wing: { type: String },
        floorid: { type: mongoose.Schema.Types.ObjectId, ref: "tblpropertyfloor" },
        floor: { type: String },
        areaid: { type: mongoose.Schema.Types.ObjectId, ref: "tblpropertyarea" },
        area: { type: String },
        isallownotification: { type: Number, default: 1 },
        temporaryproperty: { type: Number, default: 0 }
      }
    ]
    this.contact = { type: String, trim: true }
    this.isverify = { type: Number, default: 0 }
    this.personname = { type: String, trim: true }
    this.vehicleno = { type: String, trim: true }
    this.vehicletype = { type: Number, default: 0 }
    this.noofvisitor = { type: Number, trim: true }
    this.deliverycompanyid = { type: mongoose.Schema.Types.ObjectId, ref: "tbldeliverycompany" }
    this.deliverycompany = { type: String, trim: true }
    // Documents
    this.customerid = { type: mongoose.Schema.Types.ObjectId }
    this.customer = { type: String }
    this.pettype = { type: String, default: "" }
    this.pettypeid = { type: mongoose.Schema.Types.ObjectId, ref: "tblpettypemaster", default: Config.dummyObjid }
    this.breed = { type: String, default: "" }
    this.breedid = { type: mongoose.Schema.Types.ObjectId, ref: "tblbreedmaster", default: Config.dummyObjid }
    this.dateofbirth = { type: Date, trim: true }
    this.identificationfeature = { type: String }
    this.approvetype = { type: Number } //1-guest 2-kids 3-pets 4-asset
    this.age = { type: String, default: "" },
      this.relation = { type: String, default: "" },
      this.gender = { type: String, default: "" },
      this.visitorimage = Config.getImageModel()
    this.clockin = { type: Number, trim: true, default: 0 }  // 1-clockin 2-clockout
    this.visitorin = { type: Date, default: null }
    this.visitorout = { type: Date, default: null }
    this.assetid = { type: String, maxLength: 50 }
    this.serialnumber = { type: String }
    this.assetstatus = { type: String }
    this.assetstatusid = { type: mongoose.Schema.Types.ObjectId, ref: "tblassetstatusmaster", default: Config.dummyObjid }
    this.isactive = { type: Number, required: true, default: 1 } // 1 - active, 0 - deactive
    this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: "recordinfo" }
  }

  getDataName() {
    return "Visitor"
  }

  getFieldOrder() {

    return {
      "fields": [
        {
          "field": "action_button",
          "text": "",
          "type": "action_button",
          "freeze": 1,
          "active": 1,
          "sorttable": 0,
          "filter": 0,
          "disableflex": 1,
          "filterfieldtype": "lookup",
          "defaultvalue": "",
          "tblsize": 10
        },
        {
          "field": "clockin",
          "text": "Status",
          "type": "isactive",
          "freeze": 1,
          "active": 1,
          "sorttable": 0,
          "filter": 0,
          "disableflex": 1,
          "filterfieldtype": "lookup",
          "defaultvalue": "",
          "tblsize": 15
        },
        {
          "field": "category",
          "text": "Category",
          "type": "text",
          "freeze": 0,
          "active": 1,
          "sorttable": 1,
          "sortby": "category",
          "filter": 0,
          "disableflex": 1,
          "filterfieldtype": "lookup",
          "defaultvalue": "",
          "tblsize": 20
        },
        {
          "field": "deliverycompany",
          "text": "DeliveryCompany",
          "type": "text",
          "freeze": 0,
          "active": 1,
          "sorttable": 1,
          "sortby": "deliverycompany",
          "filter": 0,
          "filterfieldtype": "lookup",
          "defaultvalue": "",
          "tblsize": 20
        },
        {
          "field": "personname",
          "text": "Person Name",
          'type': 'person-name',
          "freeze": 0,
          "active": 1,
          "sorttable": 1,
          "sortby": "personname",
          "filter": 0,
          "disableflex": 1,
          "filterfieldtype": "lookup",
          "defaultvalue": "",
          "tblsize": 15
        },
        {
          "field": "contact",
          "text": "Contact",
          "type": "text",
          "freeze": 0,
          "active": 1,
          "sorttable": 1,
          "sortby": "contact",
          "filter": 0,
          "filterfieldtype": "lookup",
          "defaultvalue": "",
          "tblsize": 15
        },
        {
          "field": "vehicleno",
          "text": "Vehicle No",
          "type": "text",
          "freeze": 0,
          "active": 1,
          "sorttable": 1,
          "sortby": "vehicleno",
          "filter": 0,
          "filterfieldtype": "lookup",
          "defaultvalue": "",
          "tblsize": 15
        },
        {
          "field": "property",
          "text": "Property Name",
          "type": "text",
          "freeze": 0,
          "active": 1,
          "sorttable": 1,
          "sortby": "property",
          "filter": 0,
          "disableflex": 1,
          "filterfieldtype": "lookup",
          "defaultvalue": "",
          "tblsize": 20
        },
        // {
        //   "field": "propertydetails",
        //   "text": "Building Name / Wing Name / Unit Name",
        //   "type": "text-array",
        //   "freeze": 0,
        //   "textarrayfiledname": "propertydetails",
        //   "active": 1,
        //   "sorttable": 0,
        //   "filter": 0,
        //   "filterfieldtype": "lookup",
        //   "defaultvalue": "",
        //   "tblsize": 30
        // },
        {
          'field': ['wing', 'floor', 'unit'],
          'text': 'Building Name / Wing Name / Unit Name',
          'type': "taglist",
          "forlisttag": "propertydetails",
          'freeze': 0,
          'active': 1,
          'sorttable': 0,
          "filterfieldtype": "lookup",
          "defaultvalue": "",
          'filter': 0,
          'tblsize': Config.getTblgridsizeclasses()[30]
        },

        // {
        //   "field": "propertyarea",
        //   "text": "Area Name",
        //   "type": "text-array",
        //   "freeze": 0,
        //   "textarrayfiledname": "propertyarea",
        //   "active": 1,
        //   "sorttable": 0,
        //   "filter": 0,
        //   "filterfieldtype": "lookup",
        //   "defaultvalue": "",
        //   "tblsize": 20
        // },
        {
          'field': ['wing', 'floor', 'area'],
          'text': 'Area Name',
          'type': "taglist",
          "forlisttag": "propertyarea",
          'freeze': 0,
          'active': 1,
          'sorttable': 0,
          "filterfieldtype": "lookup",
          "defaultvalue": "",
          'filter': 0,
          'tblsize': Config.getTblgridsizeclasses()[30]
        },

        {
          "field": "visitorin",
          "text": "Visitor In",
          "type": "text",
          "freeze": 0,
          "active": 1,
          "sorttable": 1,
          "sortby": "visitorin",
          "filter": 0,
          "filterfieldtype": "lookup",
          "defaultvalue": "",
          "tblsize": 15
        },
        {
          "field": "visitorout",
          "text": "Visitor Out",
          "type": "text",
          "freeze": 0,
          "active": 1,
          "sorttable": 1,
          "sortby": "visitorout",
          "filter": 0,
          "filterfieldtype": "lookup",
          "defaultvalue": "",
          "tblsize": 15
        },
      ]
    }
  }


}
