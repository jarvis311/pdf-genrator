import  mongoose  from 'mongoose'
import _Config from '../../config/Config.js'

export default class ComplaintLog
{ 
    constructor(){
        this._id
        this.complaintid = {type : mongoose.Schema.Types.ObjectId, ref:'tbltask'}
        this.complaint = {type : String} 
        this.ownerid = {type : mongoose.Schema.Types.ObjectId, ref:'tblpersonmaster'}
        this.owner = {type : String}
        this.logdatetime = {type: String}
        this.status = {type :String}
        this.statusid = {type : mongoose.Schema.Types.ObjectId, ref:'tblsupportticketstatus'}
        this.recordinfo = {type : mongoose.Schema.Types.Mixed, ref: 'recordinfo'}
    }
    
    getDataName() {
        return "Complaint Log"
    }

}
