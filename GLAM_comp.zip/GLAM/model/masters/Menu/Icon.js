import mongoose from 'mongoose'
import { Config } from '../../../config/Init.js'

export default class Icon {
  constructor() {
    this._id
    this.iconname = { type: String, required: true, index: true, unique: true, trim: true }
    this.iconimage = {
      url: { type: String, required: false, trim: true },
      name: { type: String, required: false, trim: true },
      size: { type: Number, required: false, trim: true },
      extension: { type: String, required: false, trim: true }
    }
    this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: 'recordinfo' }
  }

  getDataName() {
    return "Icon"
  }

  getFieldOrder() {
    return {
      fields: [
        {
          'field': 'action_button',
          'text': '',
          'type': Config.getHtmlcontorls()['action_button'],
          'freeze': 1,
          'active': 1,
          'sorttable': 0,
          'filter': 0,
          'disableflex': 1,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': 8
        },
        {
          'field': 'iconname',
          'text': 'Icon Name',
          'type': Config.getHtmlcontorls()['text'],
          'freeze': 1,
          'active': 1,
          'sorttable': 1,
          'filter': 0,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': 90
        },
        {
          'field': 'iconimage',
          'text': 'Svg Icon',
          'type': Config.getHtmlcontorls()['icon'],
          'freeze': 1,
          'active': 1,
          'sorttable': 0,
          'filter': 0,
          'filterfieldtype': Config.getHtmlcontorls()['dropdown'],
          'defaultvalue': '',
          'tblsize': 87
        }
      ]
    }
  }

  getFormFieldOrder() {
    return {
      "rightsidebarsize": Config.getModalsizeclasses()['xs'],
      "pagename": 'icon',
      "formname": 'Icon',
      "dataview": "tab",
      "alias": 'icon',
      "formfields": [
        {
          "tab": "Icon",
          "formFields": [
            {
              'field': 'iconname',
              'text': 'Icon Name',
              'type': Config.getHtmlcontorls()['kInputText'],
              'disabled': false,
              'defaultvisibility': true,
              'required': true,
              'gridsize': Config.getFieldSize()['k375'],
              "capitalcase": true
            },
            {
              'field': 'iconimage',
              'text': 'Svg Icon',
              'type': Config.getHtmlcontorls()['kFilePicker'],
              'disabled': false,
              'defaultvisibility': true,
              'required': true,
              'filetypes': ['svg'],
              'gridsize': Config.getFieldSize()['k375'],
            },
          ]
        },
      ]
    };
  }
}

