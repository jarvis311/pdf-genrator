import mongoose from 'mongoose'
import _Config from '../../../config/Config.js'

export default class MenuDesign {
    constructor() {
        this._id
        this.moduletypeid = { type: mongoose.Schema.Types.ObjectId, ref: 'tblmoduletyprmaster' },

            this.menudesigndata = [
                {
                    menuname: { type: String, required: true, trim: true },
                    formname: { type: String, required: true, trim: true },
                    // moduletypeid: {type : mongoose.Schema.Types.ObjectId, ref: 'tblmoduletyprmaster'},
                    iconid: { type: mongoose.Schema.Types.ObjectId, ref: 'tbliconmaster' },
                    iconimage: {
                        url: { type: String, required: false, trim: true },
                        name: { type: String, required: false, trim: true },
                        size: { type: Number, required: false, trim: true },
                        extension: { type: String, required: false, trim: true }
                    },
                    alias: { type: String, required: true, trim: true },
                    isparent: { type: Number, required: true },
                    parentid: { type: mongoose.Schema.Types.ObjectId, ref: 'tblmenumaster' },
                    moduleid: { type: mongoose.Schema.Types.ObjectId, ref: 'tblmodulemaster' },
                    menuid: { type: mongoose.Schema.Types.ObjectId, ref: 'tblmenumaster' },
                    containright: { type: Number },
                    defaultopen: { type: Number },
                    displayinsidebar: { type: Number, required: true },
                    title: { type: String, required: true },
                    expanded: { type: Boolean },
                    canhavechild: { type: Number, default: 0 }
                }
            ]
        this.userid = { type: mongoose.Schema.Types.ObjectId, ref: 'tblusermaster' }
        this.isdefaultmenu = { type: Number, default: 0 }
        this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: 'recordinfo' }
    }

    getDataName() {
        return "Menu Design"
    }
}