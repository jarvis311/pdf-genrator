import mongoose from "mongoose"
import _Config from "../../../config/Config.js"

export default class ModuleType {
    constructor() {
        this._id
        this.moduletype = { type: String, required: true, trim: true }
        this.isrelease = { type: Number, default:0 }
        this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: "recordinfo" }
    }

    getFieldOrder() {
        const Config = new _Config()

        return {
            fields: [
                {
                    field: "moduletype",
                    text: "Module Type",
                    type: Config.getHtmlcontorls()["text"],
                    freeze: 0,
                    active: 1,
                    sorttable: 1,
                    filter: 1,
                    filterfieldtype: Config.getHtmlcontorls()["lookup"],
                    defaultvalue: "",
                    tblsize: Config.getTblgridsizeclasses()["tbl-min-w150"]
                }
            ]
        }
    }
}
