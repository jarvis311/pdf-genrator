import mongoose from 'mongoose'
import { Config } from '../../../config/Init.js'


export default class Menu {
  constructor() {
    this._id
    this.menuname = { type: String, required: true, trim: true }
    this.formname = { type: String, required: true, trim: true }

    this.moduletype = [{
      moduletypeid: { type: mongoose.Schema.Types.ObjectId, ref: 'tblmoduletyprmaster' },
      moduletype: { type: String, required: true }
    }]

    this.iconid = { type: mongoose.Schema.Types.ObjectId, ref: 'tbliconmaster' }
    this.iconimage = {
      url: { type: String, required: false, trim: true },
      name: { type: String, required: false, trim: true },
      size: { type: Number, required: false, trim: true },
      extension: { type: String, required: false, trim: true }
    }
    this.alias = { type: String, required: true, trim: true }
    this.containright = { type: Number, required: true }
    // this.defaultopen = { type: Number, required: true }
    this.displayinsidebar = { type: Number, required: true }
    this.canhavechild = { type: Number, default: 0 }
    this.ismaster = { type: Number, default: 0 }
    // this.isreport = { type: Number, default: 0 } 
    this.forios = { type: Number, default: 0 }
    this.forandroid = { type: Number, default: 0 }
    this.containsseries = { type: Number, default: 0 }
    this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: 'recordinfo' }
  }

  getDataName() {
    return "Menu"
  }

  compoundIndex() {
    return [
      { "moduletype.moduletype": 1, menuname: 1 },
      { "moduletype.moduletype": 1, alias: 1 },
      { "moduletype.moduletype": 1, formname: 1 }
    ]
  }

  getFieldOrder() {
    return {
      fields: [
        {
          'field': 'action_button',
          'text': '',
          'type': Config.getHtmlcontorls()['action_button'],
          'freeze': 1,
          'active': 1,
          'sorttable': 0,
          'filter': 0,
          'disableflex': 1,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': 8
        },
        {
          'field': 'menuname',
          'text': 'Menu Name',
          'type': Config.getHtmlcontorls()['text'],
          'freeze': 1,
          'active': 1,
          'sorttable': 1,
          'filter': 0,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': 24
        },
        {
          'field': 'moduletype',
          'text': 'Type',
          'type': Config.getHtmlcontorls()['text-array'],
          'freeze': 1,
          'active': 1,
          'sorttable': 1,
          'filter': 0,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': 21
        },
        {
          'field': 'formname',
          'text': 'Form Name',
          'type': Config.getHtmlcontorls()['text'],
          'freeze': 1,
          'active': 1,
          'sorttable': 1,
          'filter': 0,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': 21
        },
        {
          'field': 'alias',
          'text': 'Alias (Page Name)',
          'type': Config.getHtmlcontorls()['text'],
          'freeze': 1,
          'active': 1,
          'sorttable': 1,
          'filter': 0,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': 21
        },
        {
          'field': 'containright',
          'text': 'Contains User Right',
          'type': Config.getHtmlcontorls()['switch'],
          'freeze': 1,
          'active': 1,
          'sorttable': 0,
          'filter': 0,
          'filterfieldtype': Config.getHtmlcontorls()['checkbox'],
          'defaultvalue': 0,
          'tblsize': 15
        },
        {
          'field': 'displayinsidebar',
          'text': 'Display In Sidebar',
          'type': Config.getHtmlcontorls()['switch'],
          'freeze': 1,
          'active': 1,
          'sorttable': 0,
          'filter': 0,
          'filterfieldtype': Config.getHtmlcontorls()['checkbox'],
          'defaultvalue': 0,
          'tblsize': 15
        },
        {
          'field': 'canhavechild',
          'text': 'Can Have Child',
          'type': Config.getHtmlcontorls()['switch'],
          'freeze': 1,
          'active': 1,
          'sorttable': 0,
          'filter': 0,
          'filterfieldtype': Config.getHtmlcontorls()['checkbox'],
          'defaultvalue': 0,
          'tblsize': 15
        },
        {
          'field': 'ismaster',
          'text': 'Show In Master',
          'type': Config.getHtmlcontorls()['switch'],
          'freeze': 1,
          'active': 1,
          'sorttable': 0,
          'filter': 0,
          'filterfieldtype': Config.getHtmlcontorls()['checkbox'],
          'defaultvalue': 0,
          'tblsize': 15
        },
        {
          'field': 'forandroid',
          'text': 'Show In Android',
          'type': Config.getHtmlcontorls()['switch'],
          'freeze': 1,
          'active': 1,
          'sorttable': 0,
          'filter': 0,
          'filterfieldtype': Config.getHtmlcontorls()['checkbox'],
          'defaultvalue': 0,
          'tblsize': 15
        },
        {
          'field': 'forios',
          'text': 'Show In IOS',
          'type': Config.getHtmlcontorls()['switch'],
          'freeze': 1,
          'active': 1,
          'sorttable': 0,
          'filter': 0,
          'filterfieldtype': Config.getHtmlcontorls()['checkbox'],
          'defaultvalue': 0,
          'tblsize': 15
        },
        {
          'field': 'containsseries',
          'text': 'Contains Series',
          'type': Config.getHtmlcontorls()['switch'],
          'freeze': 1,
          'active': 1,
          'sorttable': 0,
          'filter': 0,
          'filterfieldtype': Config.getHtmlcontorls()['checkbox'],
          'defaultvalue': 0,
          'tblsize': 15
        }
      ]
    }
  }


  getFormFieldOrder() {
    return {
      "rightsidebarsize": Config.getModalsizeclasses()['xs'],
      "pagename": 'menu',
      "formname": 'Menu',
      "alias": 'menu',
      "dataview": "tab",
      "formfields": [
        {
          "tab": "Menu",
          "formFields": [
            {
              'field': 'menuname',
              'text': 'Menu Name',
              'type': Config.getHtmlcontorls()['kInputText'],
              'disabled': false,
              'defaultvisibility': true,
              'required': true,
              'gridsize': Config.getFieldSize()['k375'],
              "capitalcase": true
            },
            {
              'field': 'formname',
              'text': 'Form Name',
              'type': Config.getHtmlcontorls()['kInputText'],
              'disabled': false,
              'defaultvisibility': true,
              'required': true,
              'gridsize': Config.getFieldSize()['k375'],
              "capitalcase": true
            },
            {
              'field': 'alias',
              'text': 'Alias Name',
              'type': Config.getHtmlcontorls()['kInputText'],
              'disabled': false,
              'disableonedit': true,
              'required': true,
              'defaultvisibility': true,
              'gridsize': Config.getFieldSize()['k375'],
              "capitalcase": true
            },
            {
              'field': 'iconid',
              'text': 'Icon',
              'type': Config.getHtmlcontorls()['kDropDown'],
              'disabled': false,
              'required': false,
              'defaultvisibility': true,
              'gridsize': Config.getFieldSize()['k375'],
              'masterdata': 'icon',
              'masterdatafield': 'iconname',
              'formdatafield': 'icon',
              'cleanable': true,
              'searchable': true,
              'projection': {
                'icon': 1,
                'iconclass': 1,
                'iconname': 1,
                'iconstyle': 1,
                'iconunicode': 1,
                '_id': 1,
              }
            },
            {
              'field': 'moduletype',
              'text': 'Module Type',
              'type': Config.getHtmlcontorls()['kMultiSelectDropDown'],
              'disabled': false,
              'required': true,
              'defaultvisibility': true,
              'gridsize': Config.getFieldSize()['k375'],
              'masterdata': 'moduletype',
              'masterdatafield': 'moduletype',
              'formdatafield': 'moduletype',
              'cleanable': true,
              'searchable': false,
            },
            {
              'field': 'displayinsidebar',
              'text': 'Display In Sidebar',
              'type': Config.getHtmlcontorls()['kCheckBox'],
              'disabled': false,
              'required': false,
              'defaultvisibility': true,
              'gridsize': Config.getFieldSize()['k375'],
            },
            {
              'field': 'canhavechild',
              'text': 'Can Have Child',
              'type': Config.getHtmlcontorls()['kCheckBox'],
              'disabled': false,
              'required': false,
              'defaultvisibility': true,
              'gridsize': Config.getFieldSize()['k375'],
            },
            {
              'field': 'containright',
              'text': 'Contain Right',
              'type': Config.getHtmlcontorls()['kCheckBox'],
              'disabled': false,
              'required': false,
              'defaultvisibility': true,
              'gridsize': Config.getFieldSize()['k375'],
            },
            {
              'field': 'ismaster',
              'text': 'Show in Master Menu',
              'type': Config.getHtmlcontorls()['kCheckBox'],
              'disabled': false,
              'required': false,
              'defaultvisibility': true,
              'gridsize': Config.getFieldSize()['k375'],
            },
            {
              'field': 'containsseries',
              'text': 'Contains Series',
              'type': Config.getHtmlcontorls()['kCheckBox'],
              'disabled': false,
              'required': false,
              'defaultvisibility': true,
              'gridsize': Config.getFieldSize()['k375'],
            },
          ]
        }
      ]
    };
  }
}

