import mongoose from 'mongoose'
import { Config } from '../../../config/Init.js'

export default class MenuAssign {
    constructor() {
        this._id
        this.displayinsidebar = { type: Number, required: false, default: 1 }
        this.moduletypeid = { type: String, required: true, trim: true }
        this.menuname = { type: String, required: true, trim: true }
        this.formname = { type: String, required: true, trim: true }
        this.iconid = { type: mongoose.Schema.Types.ObjectId, ref: "tbliconmaster" }
        this.iconimage = {
            url: { type: String, required: false, trim: true },
            name: { type: String, required: false, trim: true },
            size: { type: Number, required: false, trim: true },
            extension: { type: String, required: false, trim: true }
        }
        this.alias = { type: String, required: true, trim: true }
        this.isparent = { type: Number, required: true }
        this.parentid = { type: String, trim: true, default: "" }
        this.moduleid = { type: String, required: true, trim: true }
        this.menuid = { type: mongoose.Schema.Types.ObjectId, ref: "tblmenumaster" }
        this.containright = { type: Number, required: true }
        this.forios = { type: Number, default: 0 }
        this.forandroid = { type: Number, default: 0 }
        this.ipallowed = { type: Number, default: 1 }
        this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: "recordinfo" }
    }

    getDataName() {
        return "Menu Assign"
    }

    getFieldOrder() {
        return {
            fields: [
                {
                    'field': 'isassigned',
                    'text': 'All',
                    'type': Config.getHtmlcontorls()['checkbox'],
                    'freeze': 1,
                    'active': 1,
                    'filter': 0,
                    'filterfieldtype': Config.getHtmlcontorls()['lookup'],
                    'defaultvalue': '',
                    'selectall': 0,
                    'tblsize': Config.getTblgridsizeclasses()[10]
                },
                {
                    'field': 'menuname',
                    'text': 'Menu',
                    'type': Config.getHtmlcontorls()['text'],
                    'freeze': 1,
                    'active': 1,
                    'filter': 0,
                    'filterfieldtype': Config.getHtmlcontorls()['lookup'],
                    'defaultvalue': '',
                    'tblsize': Config.getTblgridsizeclasses()[20]
                },
                {
                    'field': 'isparent',
                    'text': 'Is Parent',
                    'type': Config.getHtmlcontorls()['radio'],
                    'freeze': 1,
                    'active': 1,
                    'filter': 0,
                    'filterfieldtype': Config.getHtmlcontorls()['lookup'],
                    'defaultvalue': '',
                    'tblsize': Config.getTblgridsizeclasses()[20]
                }
            ]

        }
    }
}

