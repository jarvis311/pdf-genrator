import mongoose from 'mongoose'
import { Config } from '../../../config/Init.js'

export default class Module {
  constructor() {
    this._id
    this.module = { type: String, required: true, index: true, unique: true, trim: true }

    this.moduletype = [{
      moduletypeid: { type: mongoose.Schema.Types.ObjectId, ref: 'tblmoduletype' },
      moduletype: { type: String, required: true }
    }]

    this.iconid = { type: mongoose.Schema.Types.ObjectId, ref: 'tbliconmaster' }
    this.iconimage = {
      url: { type: String, required: false, trim: true },
      name: { type: String, required: false, trim: true },
      size: { type: Number, required: false, trim: true },
      extension: { type: String, required: false, trim: true }
    }

    this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: 'recordinfo' }
  }

  getDataName() {
    return "Module"
  }

  getFieldOrder() {
    return {
      fields: [
        {
          'field': 'action_button',
          'text': '',
          'type': Config.getHtmlcontorls()['action_button'],
          'freeze': 1,
          'active': 1,
          'sorttable': 0,
          'filter': 0,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': 8
        },
        {
          'field': 'moduletype',
          'text': 'Module Type',
          'type': Config.getHtmlcontorls()['text-array'],
          'active': 1,
          'sorttable': 1,
          'filter': 0,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': 50
        },
        {
          'field': 'module',
          'text': 'Module Name',
          'type': Config.getHtmlcontorls()['text'],
          'active': 1,
          'sorttable': 1,
          'filter': 0,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': 76
        },
        {
          'field': 'iconimage',
          'text': 'Icon',
          'type': Config.getHtmlcontorls()['icon'],
          'active': 1,
          'sorttable': 0,
          'filter': 0,
          'filterfieldtype': Config.getHtmlcontorls()['dropdown'],
          'defaultvalue': '',
          'tblsize': 50
        }
      ]
    }
  }

  getFormFieldOrder() {
    return {
      "rightsidebarsize": Config.getModalsizeclasses()['xs'],
      "pagename": 'module',
      "formname": 'Module',
      "alias": 'module',
      "dataview": "tab",
      "formfields": [
        {
          "tab": "Module",
          "formFields": [
            {
              'field': 'moduletype',
              'text': 'Module Type',
              'type': Config.getHtmlcontorls()['kMultiSelectDropDown'],
              'disabled': false,
              'defaultvisibility': true,
              'gridsize': Config.getFieldSize()['k375'],
              'required': true,
              'masterdata': 'moduletype',
              'masterdatafield': 'moduletype',
              'formdatafield': 'moduletype',
              'cleanable': true,
              'searchable': false,
              "masterdatadependancy": false,
            },
            {
              'field': 'module',
              'text': 'Module Name',
              'type': Config.getHtmlcontorls()['kInputText'],
              'disabled': false,
              'defaultvisibility': true,
              'required': true,
              'gridsize': Config.getFieldSize()['k375'],
              "capitalcase": true
            },
            {
              'field': 'iconid',
              'text': 'Icon',
              'type': Config.getHtmlcontorls()['kDropDown'],
              'disabled': false,
              'required': true,
              'defaultvisibility': true,
              'gridsize': Config.getFieldSize()['k375'],
              'masterdata': 'icon',
              'masterdatafield': 'iconname',
              'formdatafield': 'icon',
              'cleanable': true,
              'searchable': true,
              "masterdatadependancy": false,
            },
          ]
        }
      ]
    };

  }
}

