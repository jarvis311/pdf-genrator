import mongoose from 'mongoose'
import { Config } from '../../config/Init.js'

export default class DailyhelpBookingReq {
  constructor() {
    this._id
    this.propertyid = { type:mongoose.Schema.Types.ObjectId, ref: 'tblproperty'}
    this.customerid = { type:mongoose.Schema.Types.ObjectId, ref: 'tblcustomer'}
    this.dailyhelpid = { type:mongoose.Schema.Types.ObjectId, ref: 'tblpropertyfacility'}
    this.slot = [{
        starttime: {type : String},
        endtime:{ type: String},  
    }] 
    this.isrequest = { type: Number, default: 0 }
    this.req_body = {type: String}
    this.isbooked = {type:Number,default:0}        // 0-not booked 1-booked
    this.isapproved = { type: Number, default: 0 } // 0-pending 1- approved 2- rejected
    this.rejectreason = { type: String, default: "" }
    this.iscancel = {type:Number,default:0}
    this.cancelreason = { type:String,default:""}
    this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: 'recordinfo' }
  }

  getDataName() {
    return "Dailyhelp Booking"
  }

  getFieldOrder() {
    return {
      fields: [
        {
          'field': 'action_button',
          'text': '',
          'type': Config.getHtmlcontorls()['action_button'],
          'freeze': 1,
          'active': 1,
          'sorttable': 0,
          'filter': 0,
          'disableflex': 1,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': 10
        },
        {
          'field': 'isactive',
          'text': 'Status',
          'type': Config.getHtmlcontorls()['isactive'],
          'freeze': 1,
          'active': 1,
          'sorttable': 0,
          'filter': 0,
          'disableflex': 1,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': 15
        },
        {
          'field': 'city',
          'text': 'City Name',
          'type': Config.getHtmlcontorls()['text'],
          'freeze': 1,
          'active': 1,
          'sorttable': 1,
          'sortby': 'city',
          'filter': 0,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': 10
        },
        {
          'field': 'state',
          'text': 'State Name',
          'type': Config.getHtmlcontorls()['text'],
          'freeze': 1,
          'active': 1,
          'sorttable': 1,
          'sortby': 'state',
          'filter': 0,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': 10
        },
        {
          'field': 'country',
          'text': 'Country Name',
          'type': Config.getHtmlcontorls()['text'],
          'freeze': 1,
          'active': 1,
          'sorttable': 1,
          'sortby': 'country',
          'filter': 1,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': 10
        }
      ]
    }
  }

  getFormFieldOrder() {
    return {
      "rightsidebarsize": Config.getModalsizeclasses()['xs'],
      "pagename": 'city',
      "formname": 'City',
      "alias": 'city',
      "dataview": "tab",
      'formfields': [
        {
          "tab": "City",
          "formFields": [
            {
              'field': 'city',
              'text': 'City Name',
              'type': Config.getHtmlcontorls()['kInputText'],
              'disabled': false,
              'defaultvisibility': true,
              'required': true,
              'gridsize': Config.getFieldSize()['k375'],
            },
            {
              'field': 'countryid',
              'text': 'Country',
              'type': Config.getHtmlcontorls()['kDropDown'],
              'disabled': false,
              'defaultvisibility': true,
              'required': true,
              'gridsize': Config.getFieldSize()['k375'],
              'masterdata': 'country',
              'masterdatafield': 'country',
              'formdatafield': 'country',
              'cleanable': true,
              'searchable': true,
              'onchangefill': ['stateid'],
              'staticfilter': { 'isactive': 1 },
            },
            {
              'field': 'stateid',
              'text': 'State Name',
              'type': Config.getHtmlcontorls()['kDropDown'],
              'disabled': false,
              'defaultvisibility': true,
              'required': true,
              'gridsize': Config.getFieldSize()['k375'],
              'masterdata': 'state',
              'masterdatafield': 'state',
              'formdatafield': 'state',
              'cleanable': true,
              'searchable': true,
              'dependentfilter': {
                'countryid': 'countryid',
              },
              'masterdatadependancy': false,
              'staticfilter': { 'isactive': 1 },
            },
            Config.getFormfields()['isactive']
          ]
        }
      ],
    }
  }
}

