import mongoose from "mongoose"
import _Config from "../../config/Config.js"
const Config = new _Config()

export default class Event {
  constructor() {
    this._id
    this.title = { type: String, required: true, trim: true, index: { unique: true, collation: { locale: 'en', strength: 1 } } }
    this.owner = { type: String }
    this.ownerid = { type: mongoose.Schema.Types.ObjectId }
    this.propertyid = { type: mongoose.Schema.Types.ObjectId, ref: "tblpropertymaster" }
    this.property = { type: String, required: true }
    this.areaid = { type: mongoose.Schema.Types.ObjectId, ref: "tblpropertyarea" }
    this.area = { type: String, required: true }
    // this.eventcategoryid = { type: mongoose.Schema.Types.ObjectId, ref: "tbleventcategory" }
    // this.eventcategory = { type: String, required: true }
    // this.location = { type: String, required: true }
    this.description = { type: Array }
    this.image = { type: Object }
    this.ispresent = { type: Number }
    this.eventdate = { type: Date, required: true }
    this.eventformtdate = { type: String }
    this.sender = { type: String, required: true }
    this.senderid = { type: mongoose.Schema.Types.ObjectId }
    this.iscancel = { type: Number, default: 0 }
    this.cancelreason = { type: String }
    // this.isactive = { type: Number, required: true, default: 1 } // 1 - active, 0 - deactive
    this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: "recordinfo" }
  }

  getDataName() {
    return "Event"
  }

  getFieldOrder() {

    return {
      "fields": [
        {
          "field": "action_button",
          "text": "",
          "type": "action_button",
          "freeze": 1,
          "active": 1,
          "sorttable": 0,
          "filter": 0,
          "disableflex": 1,
          "filterfieldtype": "lookup",
          "defaultvalue": "",
          "tblsize": 8
        },
        {
          "field": "iscancel",
          "text": "Event Status",
          "type": "status",
          "freeze": 0,
          "active": 1,
          "sorttable": 1,
          "sortby": "iscancel",
          "filter": 0,
          "filterfield": "iscancel",
          "filterfieldtype": "lookup",
          "defaultvalue": "",
          "tblsize": 15
        },
        // {
        //   "field": "isactive",
        //   "text": "Status",
        //   "type": "isactive",
        //   "freeze": 1,
        //   "active": 1,
        //   "sorttable": 0,
        //   "filter": 0,
        //   "disableflex": 1,
        //   "filterfieldtype": "lookup",
        //   "defaultvalue": "",
        //   "tblsize": 15
        // },
        {
          "field": "title",
          "text": "title",
          "type": "text",
          "freeze": 0,
          "active": 1,
          "sorttable": 1,
          "sortby": "title",
          "filter": 0,
          "filterfield": "title",
          "filterfieldtype": "lookup",
          "defaultvalue": "",
          "tblsize": 30
        },
        // {
        //   "field": "eventcategory",
        //   "text": "Event Category",
        //   "type": "text",
        //   "freeze": 0,
        //   "active": 1,
        //   "sorttable": 1,
        //   "sortby": "title",
        //   "filter": 1,
        //   "filterfieldtype": "lookup",
        //   "defaultvalue": "",
        //   "tblsize": 20
        // },
        // {
        //   "field": "description",
        //   "text": "Descriprtion",
        //   "type": "text",
        //   "freeze": 0,
        //   "active": 1,
        //   "sorttable": 1,
        //   "sortby": "description",
        //   "filter": 1,
        //   "filterfieldtype": "lookup",
        //   "defaultvalue": "",
        //   "tblsize": 25
        // },
        {
          "field": "eventdate",
          "text": "Event Date & Time",
          "type": "datetime",
          "freeze": 0,
          "active": 1,
          "sorttable": 1,
          "sortby": "eventdate",
          "filter": 0,
          "filterfield": "eventdate",
          "filterfieldtype": "datetimepicker",
          "defaultvalue": "",
          "tblsize": 20
        },
        {
          "field": "fromdate",
          "text": "From Date & Time",
          "type": "datetimepicker",
          "freeze": 0,
          "active": 0,
          "sorttable": 1,
          "sortby": "fromdate",
          "filter": 1,
          "filterfield": "fromdate",
          "filterfieldtype": "datetimepicker",
          "isonlyfilter": 1,
          "defaultvalue": "",
          "tblsize": 28
        },
        {
          "field": "todate",
          "text": "To Date & Time",
          "type": "datetimepicker",
          "freeze": 0,
          "active": 0,
          "sorttable": 1,
          "sortby": "todate",
          "filter": 1,
          "filterfield": "todate",
          "filterfieldtype": "datetimepicker",
          "isonlyfilter": 1,
          "defaultvalue": "",
          "tblsize": 28
        },
        {
          "field": "area",
          "text": "Location",
          "type": "text",
          "freeze": 0,
          "active": 1,
          "sorttable": 1,
          "sortby": "area",
          "filter": 1,
          "formdatafield": "area",
          "filterfield": "areaid",
          "masterdata": "property/area",
          "masterdatafield": "area",
          "filterfieldtype": "dropdown",
          "defaultvalue": "",
          "tblsize": 112
        },
        // {
        //   "field": "cancelreason",
        //   "text": "Cancel Reason",
        //   "type": "text",
        //   "freeze": 0,
        //   "active": 1,
        //   "sorttable": 1,
        //   "sortby": "cancelreason",
        //   "filter": 0,
        //   "filterfield": "cancelreason",
        //   "filterfieldtype": "lookup",
        //   "defaultvalue": "",
        //   "tblsize": 97
        // },
        // {
        //   "field": "image",
        //   "text": "Image",
        //   "type": "image",
        //   "freeze": 0,
        //   "active": 1,
        //   "sorttable": 0,
        //   "filter": 0,
        //   "filterfieldtype": "lookup",
        //   "defaultvalue": "",
        //   "tblsize": 15
        // }
      ]
    }
  }

  getFormFieldOrder() {
    return {
      "rightsidebarsize": Config.getModalsizeclasses()['775'],
      "pagename": "event",
      "formname": "Event",
      "alias": "event",
      "dataview": "tab",
      "formfields": [
        {
          "tab": "event",
          "formFields": [
            {
              "field": "title",
              "text": "Event Title",
              "type": "input-text",
              "disabled": false,
              "defaultvisibility": true,
              "required": true,
              "gridsize": 760
            },
            // {
            //   "field": "eventcategory",
            //   "text": "Event Category",
            //   "type": "input-text",
            //   "disabled": false,
            //   "defaultvisibility": true,
            //   "required": true,
            //   "gridsize": 375
            // },
            {
              "field": "description",
              "text": "Description",
              "type": "htmleditor",
              "disabled": false,
              "defaultvisibility": true,
              "required": true,
              "gridsize": 375
            },
            {
              "field": "areaid",
              "text": "Location",
              "type": "dropdown",
              "disabled": false,
              "defaultvisibility": true,
              "required": true,
              "gridsize": 375,
              "masterdata": "property/area",
              "masterdatafield": "area",
              "formdatafield": "area",
              "cleanable": true,
              "searchable": true,
              "masterdatadependancy": false,
              "filter": 1,
              "staticfilter": { "isactive": 1 }
            },
            // {
            //   "field": "location",
            //   "text": "Location",
            //   "type": "input-text",
            //   "disabled": false,
            //   "defaultvisibility": true,
            //   "required": true,
            //   "gridsize": 375
            // },
            {
              "field": "eventdate",
              "text": "Event Date & Time",
              "type": "datetimepicker",
              "disabled": false,
              "defaultvisibility": true,
              "required": true,
              "gridsize": 375
            },
            {
              'field': 'image',
              'text': 'Image',
              'type': "multipleimagepicker",
              'disabled': false,
              'defaultvisibility': true,
              'required': false,
              'filetypes': Config.images,
              'gridsize': 375,
            },
            // {
            //   "field": "isactive",
            //   "text": "Is Active",
            //   "type": "dropdown",
            //   "disabled": false,
            //   "defaultvisibility": true,
            //   "required": true,
            //   "gridsize": 375,
            //   "masterdata": "isactive",
            //   "masterdataarray": [
            //     { "value": 1, "label": "Active" },
            //     { "value": 0, "label": "Inactive" }
            //   ],
            //   "defaultvalue": 1,
            //   "formdatafield": "isactive",
            //   "cleanable": true,
            //   "searchable": true,
            //   "masterdatadependancy": false
            // }
          ]
        }
      ]
    }
  }

}
