import mongoose from "mongoose"
import _Config from "../../config/Config.js"
const Config = new _Config()

export default class Notice {
  constructor() {
    this._id
    this.title = { type: String, required: [true, 'Title is required'], trim: true, index: { unique: true, collation: { locale: 'en', strength: 1 } } }
    this.description = { type: Array }
    this.foremployee = { type: Number }
    this.forgatekeeper = { type: Number }
    this.forcustomer = { type: Number }
    this.photo = [Config.getImageModel()]
    this.sender = { type: String, required: [true, 'Sender is required'], }
    this.senderid = { type: mongoose.Schema.Types.ObjectId }
    this.propertyid = { type: mongoose.Schema.Types.ObjectId, ref: "tblpropertymaster" }
    this.property = { type: String, required: [true, 'Property is required'], }
    this.customer = [{
      customerid: { type: mongoose.Schema.Types.ObjectId, ref: "tblcustomer" },
      customer: { type: String },
    }]
    this.gatekeeper = [{
      gatekeeperid: { type: mongoose.Schema.Types.ObjectId, ref: "tblgatekeeper" },
      gatekeeper: { type: String },
    }]
    this.employee = [{
      employeeid: { type: mongoose.Schema.Types.ObjectId, ref: "tblemployee" },
      employee: { type: String },
    }]
    this.persontype = { type: Number, default: 1 }  //1-customer,2-gatekeeper,3-employee
    this.noticedate = { type: Date, default: Date.now }
    this.isactive = { type: Number, default: 1 }
    this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: "recordinfo" }
  }

  getDataName() {
    return "Notice"
  }

  getFieldOrder() {

    return {
      fields: [
        {
          'field': 'action_button',
          'text': '',
          'type': Config.getHtmlcontorls()['action_button'],
          'freeze': 1,
          'active': 1,
          'sorttable': 0,
          'filter': 0,
          'disableflex': 1,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': Config.getTblgridsizeclasses()[8]
        },
        {
          'field': 'isactive',
          'text': 'Status',
          'type': Config.getHtmlcontorls()['isactive'],
          'freeze': 1,
          'active': 1,
          'sorttable': 0,
          'filter': 0,
          'disableflex': 1,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': 15
        },
        {
          'field': 'title',
          'text': 'title',
          'type': Config.getHtmlcontorls()['text'],
          'freeze': 0,
          'active': 1,
          'sorttable': 1,
          'sortby': 'title',
          'filter': 0,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': Config.getTblgridsizeclasses()[20]
        },
        {
          'field': 'formatedate',
          'text': 'Notice Date',
          'type': Config.getHtmlcontorls()['text'],
          'freeze': 0,
          'active': 1,
          'sorttable': 1,
          'sortby': 'formatedate',
          'filter': 0,
          'defaultvalue': '',
          'tblsize': Config.getTblgridsizeclasses()[20]
        },
        {
          "field": "fromdate",
          "text": "From Date",
          "type": "datepicker",
          "freeze": 0,
          "active": 0,
          "sorttable": 1,
          "sortby": "fromdate",
          "filter": 1,
          "filterfield": "fromdate",
          "filterfieldtype": "datepicker",
          "isonlyfilter": 1,
          "defaultvalue": "",
          "tblsize": 28
        },
        {
          "field": "todate",
          "text": "To Date",
          "type": "datepicker",
          "freeze": 0,
          "active": 0,
          "sorttable": 1,
          "sortby": "todate",
          "filter": 1,
          "filterfield": "todate",
          "filterfieldtype": "datepicker",
          "isonlyfilter": 1,
          "defaultvalue": "",
          "tblsize": 28
        },
        {
          'field': 'customer',
          'text': 'Customers',
          'type': 'text-array',
          'freeze': 0,
          'active': 1,
          'sorttable': 0,
          'sortby': 'customer',
          'filter': 0,
          'tblsize': Config.getTblgridsizeclasses()[35]
        },
        {
          'field': 'gatekeeper',
          'text': 'Gatekeeper',
          'type': 'text-array',
          'freeze': 0,
          'active': 1,
          'sorttable': 0,
          'filter': 0,
          'tblsize': Config.getTblgridsizeclasses()[35]
        },
        {
          'field': 'employee',
          'text': 'Employee',
          'type': 'text-array',
          'freeze': 0,
          'active': 1,
          'sorttable': 0,
          'filter': 0,
          'tblsize': Config.getTblgridsizeclasses()[35]
        },
        {
          "field": "gatekeeper",
          "text": "Gatekeeper",
          "type": "text-array",
          "isonlyfilter": 1,
          "freeze": 0,
          "active": 0,
          "sorttable": 0,
          "filter": 1,
          "filterfieldtype": "multipleselectdropdown",
          'filterfield': 'gatekeeper',
          'masterdata': 'gatekeeper',
          'masterdatafield': 'personname',
          'formdatafield': 'gatekeeper',
          "defaultvalue": [],
          // "onchangefill": ["floor"],
          // "masterdatadependancy": false,
          "staticfilter": { "isactive": 1 }
        },
        {
          "field": "employee",
          "text": "Employee",
          "type": "text-array",
          "isonlyfilter": 1,
          "freeze": 0,
          "active": 0,
          "sorttable": 0,
          "filter": 1,
          "filterfieldtype": "multipleselectdropdown",
          'filterfield': 'employee',
          // "apipath": "property/floor",
          'masterdata': 'employee',
          'masterdatafield': 'personname',
          'formdatafield': 'employee',
          "defaultvalue": [],
          // "onchangefill": ["unit"],
          // "dependentfilter": { "wingid": "wing.wingid" },
          // "masterdatadependancy": true,
          "staticfilter": { "isactive": 1 },
        },
        {
          "field": "customer",
          "text": "Customer",
          "type": "text-array",
          "isonlyfilter": 1,
          "freeze": 0,
          "active": 0,
          "sorttable": 0,
          "filter": 1,
          "filterfieldtype": "multipleselectdropdown",
          'filterfield': 'customer',
          // "apipath": "property/unit",
          "masterdata": "customer",
          "masterdatafield": "personname",
          "formdatafield": "customer",
          "defaultvalue": [],
          // "dependentfilter": { "wingid": "wing.wingid", "floorid": "floor.floorid", },
          // "masterdatadependancy": true,
          "staticfilter": { "isactive": 1, "customertype": [1, 2] }
        },
      ]
    }
  }

  getFormFieldOrder() {
    return {
      "rightsidebarsize": Config.getModalsizeclasses()['md'],
      "pagename": 'notice',
      "formname": 'Notice',
      "alias": 'notice',
      "dataview": "tab",
      'formfields': [
        {
          "tab": "notice",
          "formFields": [
            {
              'field': 'title',
              'text': 'Title',
              'type': Config.getHtmlcontorls()['kInputText'],
              'disabled': false,
              'defaultvisibility': true,
              'required': true,
              'gridsize': Config.getFieldSize()['k375'],
            },
            {
              "field": "noticedate",
              "text": "Date",
              "ispastdateselectable": false,
              "type": "datepicker",
              "disabled": false,
              "defaultvisibility": true,
              "required": true,
              "gridsize": 375
            },
            {
              'field': 'forgatekeeper',
              'text': 'For Gatekeeper',
              'type': 'checkbox',
              'disabled': false,
              'required': false,
              'defaultvisibility': true,
              'gridsize': 180,
            },
            {
              'field': 'forcustomer',
              'text': 'For Customer',
              'type': 'checkbox',
              'disabled': false,
              'required': false,
              'defaultvisibility': true,
              'gridsize': 180,
            },
            {
              'field': 'foremployee',
              'text': 'For Employee',
              'type': 'checkbox',
              'disabled': false,
              'required': false,
              'defaultvisibility': true,
              'gridsize': 180,
            },
            {
              'field': 'gatekeeper',
              'text': 'Gatekeeper',
              'type': Config.getHtmlcontorls()['kMultiSelectDropDown'],
              'disabled': false,
              'defaultvisibility': true,
              'gridsize': Config.getFieldSize()['k375'],
              'required': false,
              'masterdata': 'gatekeeper',
              'masterdatafield': 'personname',
              'formdatafield': 'gatekeeper',
              'cleanable': true,
              'searchable': false,
              'condition': {
                'forgatekeeper': [1]
              },
              "staticfilter": { "isactive": 1, },
              "masterdatadependancy": false,
            },
            {
              'field': 'employee',
              'text': 'Employee',
              'type': Config.getHtmlcontorls()['kMultiSelectDropDown'],
              'disabled': false,
              'defaultvisibility': true,
              'gridsize': Config.getFieldSize()['k375'],
              'required': false,
              'masterdata': 'employee',
              'masterdatafield': 'personname',
              'formdatafield': 'employee',
              'cleanable': true,
              'searchable': false,
              'condition': {
                'foremployee': [1]
              },
              "masterdatadependancy": false,
              "staticfilter": { "isactive": 1, }
            },
            // {
            //   "field": "wing",
            //   "text": "Wing",
            //   "type": "multipleselectdropdown",
            //   "disabled": false,
            //   "defaultvisibility": true,
            //   "required": false,
            //   "gridsize": 375,
            //   "masterdata": "property/wing",
            //   "masterdatafield": "wingname",
            //   "formdatafield": "wing",
            //   'condition': {
            //     "forcustomer": [1]
            //   },
            //   "cleanable": true,
            //   "searchable": true,
            //   "onchangefill": ["floor"],
            //   "masterdatadependancy": false,
            //   "staticfilter": { "isactive": 1 }
            // },
            // {
            //   "field": "floor",
            //   "text": "Floor",
            //   "type": "multipleselectdropdown",
            //   "disabled": false,
            //   "defaultvisibility": true,
            //   "required": false,
            //   "gridsize": 375,
            //   "masterdata": "property/floor",
            //   "masterdatafield": "floor",
            //   "formdatafield": "floor",
            //   "cleanable": true,
            //   "searchable": true,
            //   "onchangefill": ["unit"],
            //   'condition': {
            //     "forcustomer": [1]
            //   },
            //   "dependentfilter": { "wingid": "wing" },
            //   "masterdatadependancy": true,
            //   "storeextrakeys": { "wingid": "wingid", "wing": "wingname" },
            //   "staticfilter": { "isactive": 1 },
            //   "attributes": ["wingname"]
            // },
            // {
            //   "field": "unit",
            //   "text": "Unit",
            //   "type": "multipleselectdropdown",
            //   "disabled": false,
            //   "defaultvisibility": true,
            //   "required": false,
            //   "gridsize": 375,
            //   "masterdata": "property/unit",
            //   "masterdatafield": "unitname",
            //   "formdatafield": "unit",
            //   "cleanable": true,
            //   "searchable": true,
            //   "dependentfilter": { "wingid": "wing", "floorid": "floor", },
            //   "storeextrakeys": { "wingid": "wingid", "wing": "wingname", "floorid": "floorid", "floor": "floor" },
            //   "masterdatadependancy": true,
            //   'condition': {
            //     "forcustomer": [1]
            //   },
            //   "staticfilter": { "isactive": 1 },
            //   "attributes": ["wingname", "floor"]
            // },
            {
              "field": "customer",
              "text": "Customer",
              "type": "multipleselectdropdown",
              "disabled": false,
              "defaultvisibility": true,
              "required": false,
              "gridsize": 375,
              "masterdata": "customer",
              "masterdatafield": "personname",
              "formdatafield": "customer",
              "cleanable": true,
              "searchable": true,
              // "onchangefill": ["floor"],
              "masterdatadependancy": false,
              'condition': {
                "forcustomer": [1]
              },
              "staticfilter": { "isactive": 1, "customertype": [1, 2] }
            },
            // {
            //   "field": "floor",
            //   "text": "Floor",
            //   "type": "multipleselectdropdown",
            //   "disabled": false,
            //   "defaultvisibility": true,
            //   "required": false,
            //   "gridsize": 375,
            //   "masterdata": "property/floor",
            //   "masterdatafield": "floor",
            //   "formdatafield": "floor",
            //   "cleanable": true,
            //   "searchable": true,
            //   "onchangefill": ["unit"],
            //   "dependentfilter": { "wingid": "wing" },
            //   "masterdatadependancy": true,
            //   "storeextrakeys": { "wingid": "wingid", "wing": "wingname" },
            //   "staticfilter": { "isactive": 1 },
            //   'condition': {
            //     "forcustomer": [1]
            //   },
            //   "attributes": ["wingname"]
            // },
            // {
            //   "field": "unit",
            //   "text": "Unit",
            //   "type": "multipleselectdropdown",
            //   "disabled": false,
            //   "defaultvisibility": true,
            //   "required": false,
            //   "gridsize": 375,
            //   "masterdata": "property/unit",
            //   "masterdatafield": "unitname",
            //   "formdatafield": "unit",
            //   "cleanable": true,
            //   "searchable": true,
            //   "dependentfilter": { "wingid": "wing", "floorid": "floor", },
            //   "storeextrakeys": { "wingid": "wingid", "wing": "wingname", "floorid": "floorid", "floor": "floor" },
            //   "masterdatadependancy": true,
            //   "staticfilter": { "isactive": 1 },
            //   'condition': {
            //     "forcustomer": [1]
            //   },
            //   "attributes": ["wingname", "floor"]
            // },
            {
              'field': 'photo',
              'text': 'Attachment',
              'type': "multipleimagepicker",
              'disabled': false,
              'defaultvisibility': true,
              'required': false,
              'filetypes': [
                ...Config.pdfExtension,
                ...Config.images,
                ...Config.docExtension,
                ...Config.excelExtension,
              ],
              'gridsize': 850,
              "freeze": 0,
              "active": 1,
              "sorttable": 0,
              "filter": 0,
              "defaultvalue": ""
            },
            {
              "field": "description",
              "text": "Description",
              "height": 400,
              "type": "htmleditor",
              "disabled": false,
              "defaultvisibility": true,
              "required": true,
            },
          ]
        }
      ],
    }
  }

}
