import mongoose from 'mongoose'
import { Config } from '../../config/Init.js'

export default class LocalDir {
    constructor() {
        this._id
        this.propertyid = { type: mongoose.Schema.Types.ObjectId, ref: "tblpropertymaster" },
            this.property = { type: String, required: true }
        this.personname = { type: String, required: true }
        this.mobileno = { type: String }
        this.address = { type: String, required: false }
        this.photo = Config.getImageModel()
        this.starttime = { type: Date, required: false }
        this.endtime = { type: Date, required: false }
        this.latlong = { type: String, required: false }
        this.isactive = { type: Number, required: true, default: 1 } // 1 - active, 0 - deactive
        this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: 'recordinfo' }
    }

    getDataName() {
        return "LocalDir"
    }

    getFieldOrder() {
        return {
            fields: [
                {
                    'field': 'action_button',
                    'text': '',
                    'type': Config.getHtmlcontorls()['action_button'],
                    'freeze': 1,
                    'active': 1,
                    'sorttable': 0,
                    'filter': 0,
                    'disableflex': 1,
                    'filterfieldtype': Config.getHtmlcontorls()['lookup'],
                    'defaultvalue': '',
                    'tblsize': 8

                },
                {
                    'field': 'isactive',
                    'text': 'Status',
                    'type': Config.getHtmlcontorls()['isactive'],
                    'freeze': 0,
                    'active': 1,
                    'sorttable': 0,
                    'filter': 0,
                    'disableflex': 1,
                    'filterfieldtype': Config.getHtmlcontorls()['lookup'],
                    'defaultvalue': '',
                    'tblsize': 15
                },
                {
                    "field": "photo",
                    "text": "Photo",
                    "type": Config.getHtmlcontorls()["image"],
                    "freeze": 0,
                    "active": 1,
                    "sorttable": 0,
                    "filter": 0,
                    "defaultvalue": "",
                    'tblsize': 15
                },
                {
                    'field': 'personname',
                    'text': 'Shope Name',
                    'type': Config.getHtmlcontorls()['text'],
                    'freeze': 0,
                    'active': 1,
                    'sorttable': 1,
                    'filter': 0,
                    'sortby': 'personname',
                    "defaultvisibility": true,
                    'filterfieldtype': Config.getHtmlcontorls()['lookup'],
                    'defaultvalue': '',
                    'tblsize': 15
                },
                {
                    'field': 'mobileno',
                    'text': 'Mobile Number',
                    'type': Config.getHtmlcontorls()['text'],
                    'freeze': 0,
                    'active': 1,
                    'sorttable': 0,
                    'filter': 0,
                    'filterfieldtype': Config.getHtmlcontorls()['lookup'],
                    'defaultvalue': '',
                    'tblsize': 15
                },
                {
                    "field": "starttime",
                    "text": "Start Time",
                    "type": "time",
                    "freeze": 0,
                    "active": 1,
                    "sorttable": 1,
                    "sortby": "fromdate",
                    "filter": 0,
                    "filterfield": "fromdate",
                    "filterfieldtype": "datetimepicker",
                    "isonlyfilter": 1,
                    "defaultvalue": "",
                    "tblsize": 15
                },
                {
                    "field": "endtime",
                    "text": "End Time",
                    "type": "time",
                    "freeze": 0,
                    "active": 1,
                    "sorttable": 1,
                    "sortby": "todate",
                    "filter": 0,
                    "filterfield": "todate",
                    "filterfieldtype": "datetimepicker",
                    "isonlyfilter": 1,
                    "defaultvalue": "",
                    "tblsize": 15
                },
            ]
        }
    }

    getFormFieldOrder() {
        return {
            "rightsidebarsize": Config.getModalsizeclasses()['xs'],
            "pagename": 'localdir',
            "formname": 'Local Directory',
            "alias": 'localdir',
            "dataview": "tab",
            'formfields': [
                {
                    "tab": "Local Directory",
                    "formFields": [
                        {
                            "field": "personname",
                            "capitalize": true,
                            "text": "Shope Name",
                            "type": "input-text",
                            "disabled": false,
                            "defaultvisibility": true,
                            "capitalize": true,
                            "required": true,
                            "gridsize": 375
                        },
                        {
                            "field": "mobileno",
                            "text": "Mobile Number",
                            "type": "number-input",
                            "disabled": false,
                            "defaultvisibility": true,
                            "prefixtext": "code",
                            "required": true,

                            "gridsize": 375
                        },
                        {
                            "field": "address",
                            "text": "Address",
                            "type": "input-text",
                            "disabled": false,
                            "defaultvisibility": true,
                            "required": true,
                            "gridsize": 375
                        },
                        {
                            "field": "latlong",
                            "text": "Latitude & Longitude",
                            "type": "latlong",
                            "disabled": false,
                            "decimalpoint": 6,
                            "defaultvisibility": true,
                            "required": false,
                            "cleanable": true,
                            "gridsize": 375,

                        },

                        {
                            "field": "photo",
                            "text": "Photo",
                            "type": "file",
                            "filetypes": Config.images,
                            "disabled": false,
                            "defaultvisibility": true,
                            "required": false,
                            "gridsize": 375
                        },
                        {
                            "field": "starttime",
                            "text": "Start Time",
                            "type": "timepicker",
                            "freeze": 0,
                            "active": 0,
                            "sorttable": 1,
                            "sortby": "endtime",
                            // "filter": 0,
                            // "filterfield": "todate",
                            // "filterfieldtype": "datetimepicker",
                            "isonlyfilter": 1,
                            "defaultvalue": "",
                            "tblsize": 28,
                            "gridsize": 375,
                        },

                        {
                            "field": "endtime",
                            "text": "End Time",
                            "type": "timepicker",
                            "freeze": 0,
                            "active": 0,
                            "sorttable": 1,
                            "sortby": "endtime",
                            // "filter": 0,
                            // "filterfield": "todate",
                            // "filterfieldtype": "datetimepicker",
                            "isonlyfilter": 1,
                            "defaultvalue": "",
                            "tblsize": 28,
                            "gridsize": 375,
                        },

                    ]
                }
            ],
        }
    }
}

