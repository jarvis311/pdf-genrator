import mongoose from 'mongoose'
import { Config } from '../../config/Init.js'

export default class FamilyMember {
    constructor() {
        this._id
        this.firstname = { type: String, required: true },
            this.lastname = { type: String },
            this.personname = { type: String },
            this.contactno = { type: String },
            this.age = { type: Number },
            this.contact_countrycode = { type: String, trim: true },
            this.personemail = { type: String },
            this.relationid = { type: mongoose.Schema.Types.ObjectId, ref: "tblrelationmaster" },
            this.relation = { type: String },
            this.genderid = { type: mongoose.Schema.Types.ObjectId, ref: "tblgendermaster" },
            this.gender = { type: String },
            this.profilepic = Config.getImageModel(),
            this.iskids = { type: Number, default: 0 },
            this.isactive = { type: Number, default: 1 }
        this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: 'recordinfo' }
    }

    getDataName() {
        return "Flattype"
    }

    getFieldOrder() {
        return {
            fields: [
                {
                    'field': 'action_button',
                    'text': '',
                    'type': Config.getHtmlcontorls()['action_button'],
                    'freeze': 1,
                    'active': 1,
                    'sorttable': 0,
                    'filter': 0,
                    'disableflex': 1,
                    'filterfieldtype': Config.getHtmlcontorls()['lookup'],
                    'defaultvalue': '',
                    'tblsize': 8
                },
                {
                    'field': 'isactive',
                    'text': 'Status',
                    'type': Config.getHtmlcontorls()['isactive'],
                    'freeze': 0,
                    'active': 1,
                    'sorttable': 0,
                    'filter': 0,
                    'disableflex': 1,
                    'filterfieldtype': Config.getHtmlcontorls()['lookup'],
                    'defaultvalue': '',
                    'tblsize': 15
                },
                {
                    'field': 'flattype',
                    'text': 'Flat Type',
                    'type': Config.getHtmlcontorls()['text'],
                    'freeze': 0,
                    'active': 1,
                    'sorttable': 1,
                    'filter': 0,
                    'sortby': 'flattype',
                    'filterfieldtype': Config.getHtmlcontorls()['lookup'],
                    'defaultvalue': '',
                    'tblsize': 165
                }
            ]
        }
    }

    getFormFieldOrder() {
        return {
            "rightsidebarsize": 400,
            "pagename": "flattype",
            "formname": "Flat Type",
            "alias": "flattype",
            "dataview": "tab",
            "formfields": [
                {
                    "tab": "Flat Type",
                    "formFields": [
                        {
                            "field": "flattype",
                            "text": "Flat Type",
                            "type": "input-text",
                            "disabled": false,
                            "defaultvisibility": true,
                            "required": true,
                            "gridsize": 375,
                            "capitalcase": true
                        },
                    ]
                }
            ]
        }
    }
}

