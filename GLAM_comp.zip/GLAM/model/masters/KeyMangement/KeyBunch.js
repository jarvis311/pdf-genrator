import mongoose from 'mongoose'
import { Config } from '../../../config/Init.js'

export default class KeyBunch {
  constructor() {
    this._id
    this.keybunch = { type: String, required: true, trim: true, index: { unique: true, collation: { locale: 'en', strength: 1 } } }
    this.key = [{
      keyid: { type: mongoose.Schema.Types.ObjectId, ref: "tblkeymaster" },
      key: { type: String, required: true }
    }]
    this.image = { type: Object }
    this.propertyid = { type: mongoose.Schema.Types.ObjectId, ref: 'tblpropertymaster' }
    this.property = { type: String, required: true }
    this.assigntogatekeeper = { type: Number, required: true, default: 0 } // 1 - gatekeeper, 2-employee
    this.assinee = [{
      assineeid: { type: mongoose.Schema.Types.ObjectId },
      assinee: { type: String, required: true }
    }]
    this.recollectpersonid = { type: mongoose.Schema.Types.ObjectId }
    this.recollectperson = { type: String }
    this.logs = [
      {
        assignpersonid: { type: mongoose.Schema.Types.ObjectId },
        assignperson: { type: String },
        date: { type: Date },
        logtype: { type: Number },
        status: { type: String },
        message: { type: String },
        recollectpersonid: { type: mongoose.Schema.Types.ObjectId },
        recollectperson: { type: String },
      }
    ]
    this.status = { type: Number }
    this.isactive = { type: Number, required: true, default: 1 } // 1 - active, 0 - deactive
    this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: 'recordinfo' }
  }

  getDataName() {
    return "Keys Bunch"
  }

  getFieldOrder() {
    return {
      fields: [
        {
          'field': 'action_button',
          'text': '',
          'type': Config.getHtmlcontorls()['action_button'],
          'freeze': 1,
          'active': 1,
          'sorttable': 0,
          'filter': 0,
          'disableflex': 1,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': 8
        },
        {
          'field': 'isactive',
          'text': 'Status',
          'type': Config.getHtmlcontorls()['isactive'],
          'freeze': 1,
          'active': 1,
          'sorttable': 0,
          'filter': 0,
          'disableflex': 1,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': 15
        },
        {
          'field': 'keybunch',
          'text': 'Key Bunch',
          "type": "text",
          "freeze": 0,
          "active": 1,
          "sorttable": 1,
          "filter": 0,
          'tblsize': 20

        },
        {
          "field": "key",
          "text": "Key(s)",
          "type": "text-array",
          "isonlyfilter": 1,
          "freeze": 0,
          "active": 0,
          "sorttable": 0,
          "filter": 0,
          'tblsize': 20
        },
        {
          'field': ['assinee'],
          'text': 'Assinee',
          'type': "taglist",
          "forlisttag": "assinee",
          'freeze': 0,
          'active': 1,
          'sorttable': 0,
          'sortby': 'assinee',
          'filter': 0,
          "filterfieldtype": Config.getHtmlcontorls()["lookup"],
          "defaultvalue": "",
          "tblsize": Config.getTblgridsizeclasses()["tbl-w140"]
        },

        {
          "field": "image",
          "text": "Image",
          "type": "image",
          "freeze": 0,
          "active": 1,
          "sorttable": 0,
          "filter": 0,
          "defaultvalue": "",
          'tblsize': 150
        },
      ]
    }
  }

  getFormFieldOrder() {
    return {
      "rightsidebarsize": Config.getModalsizeclasses()['xs'],
      "pagename": 'keysbunch',
      "formname": 'Keys Bunch',
      "alias": 'keysbunch',
      "dataview": "tab",
      'formfields': [
        {
          "tab": "Keys Bunch",
          "formFields": [
            {
              'field': 'keybunch',
              'text': 'Key Bunch',
              'type': Config.getHtmlcontorls()['kInputText'],
              'disabled': false,
              'defaultvisibility': true,
              'required': true,
              'gridsize': Config.getFieldSize()['k375'],
              "capitalcase": true
            },
            {
              "field": "key",
              "masterdata": "key",
              "masterdatafield": "keyname",
              "formdatafield": "key",
              "text": "Keys(s)",
              "type": "multipleselectdropdown",
              "disabled": false,
              "defaultvisibility": true,
              "required": false,// demo
              "gridsize": 375,
              "filter": 0,
              "filterfieldtype": "multipleselectdropdown",
              "cleanable": true,
              "searchable": true,
              "masterdatadependancy": false,
              "staticfilter": { "isactive": 1 }
            },
            {
              'field': 'assigntogatekeeper',
              'text': 'Assign To gatekeeper',
              'type': 'checkbox',
              'disabled': false,
              'required': false, 'defaultvalue': 0,
              'defaultvisibility': true,
              'gridsize': 180,
              'gridsize': Config.getFieldSize()['k375'],
            },
            {
              'field': 'gatekeeper',
              'text': 'Gatekeeper',
              'type': Config.getHtmlcontorls()['kMultiSelectDropDown'],
              'disabled': false,
              'defaultvisibility': true,
              'gridsize': Config.getFieldSize()['k375'],
              'required': true,
              'masterdata': 'gatekeeper',
              'masterdatafield': 'personname',
              'formdatafield': 'gatekeeper',
              'cleanable': true,
              'searchable': true,
              "storeextrakeys": { "gatekeeper": "gatekeeper", "gatekeeperid": "gatekeeperid", },
              'condition': {
                'assigntogatekeeper': [1]
              },
              "masterdatadependancy": false,
            },
            {
              'field': 'employee',
              'text': 'Employee',
              'type': Config.getHtmlcontorls()['kMultiSelectDropDown'],
              'disabled': false,

              'required': true,
              'masterdata': 'employee',
              'masterdatafield': 'personname',
              'formdatafield': 'employee',
              "storeextrakeys": { "employee": "employee", "employeeid": "employeeid", },
              'cleanable': true,
              'searchable': true,
              'condition': {
                'assigntogatekeeper': [0]
              },
              "masterdatadependancy": false,
            },
            { "field": "image", "text": "image", "type": "file", "filetypes": Config.images, "disabled": false, "defaultvisibility": true, "required": false, "gridsize": 375 },

          ]
        }
      ],
    }
  }
}

