import mongoose from 'mongoose'
import { Config } from '../../../config/Init.js'

export default class Key {
  constructor() {
    this._id
    this.keyname = { type: String, required: true, trim: true, index: { unique: true, collation: { locale: 'en', strength: 1 } } }
    this.propertyid = { type: mongoose.Schema.Types.ObjectId, ref: 'tblpropertymaster' }
    this.property = { type: String,required:true}
    this.image = { type: Object }
    this.assignpersonid = { type:mongoose.Schema.Types.ObjectId}
    this.assignperson = { type:String,trim:true}
    this.recollectpersonid = { type:mongoose.Schema.Types.ObjectId}
    this.recollectperson = { type:String,trim:true}
    this.logs = [
      {
        assignpersonid: { type: mongoose.Schema.Types.ObjectId },
        assignperson: { type: String },
        date: { type: Date },
        logtype: { type: Number },
        status: { type: String },
        recollectpersonid: { type: mongoose.Schema.Types.ObjectId },
        recollectperson: { type: String },
        message: { type: String }
      }
    ]
    this.status = {type:Number} //1-assign 2-recollect
    this.isactive = { type: Number, required: true, default: 1 } // 1 - active, 0 - deactive
    this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: 'recordinfo' }
  }

  getDataName() {
    return "Key"
  }

  getFieldOrder() {
    return {
      fields: [
        {
          'field': 'action_button',
          'text': '',
          'type': Config.getHtmlcontorls()['action_button'],
          'freeze': 1,
          'active': 1,
          'sorttable': 0,
          'filter': 0,
          'disableflex': 1,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': 8
        },
        {
          'field': 'isactive',
          'text': 'Status',
          'type': Config.getHtmlcontorls()['isactive'],
          'freeze': 0,
          'active': 1,
          'sorttable': 0,
          'filter': 0,
          'disableflex': 1,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': 15
        },
        {
          'field': 'keyname',
          'text': 'key Name',
          "type": "text",
          "freeze": 0,
          "active": 1,
          "sorttable": 1,
          "filter": 0,
        },
        {
          "field": "image",
          "text": "Image",
          "type": "image",
          "freeze": 0,
          "active": 1,
          "sorttable": 0,
          "filter": 0,
          "defaultvalue": ""
        },
      ]
    }
  }

  getFormFieldOrder() {
    return {
      "rightsidebarsize": Config.getModalsizeclasses()['xs'],
      "pagename": 'keys',
      "formname": 'Keys',
      "alias": 'keys',
      "dataview": "tab",
      'formfields': [
        {
          "tab": "Areatype",
          "formFields": [
            {
              'field': 'keyname',
              'text': 'key Name',
              'type': Config.getHtmlcontorls()['kInputText'],
              'disabled': false,
              'defaultvisibility': true,
              'required': true,
              'gridsize': Config.getFieldSize()['k375'],
              "capitalcase": true
            },

            { "field": "image", "text": "image", "type": "file", "filetypes": Config.images, "disabled": false, "defaultvisibility": true, "required": false, "gridsize": 375 },

          ]
        }
      ],
    }
  }
}

