import mongoose from 'mongoose'
import _Config from "../../config/Config.js"

export default class Shift
{ 
    constructor(){
        this._id
        this.shiftname = {type: String, required: [true, 'Shift name is required'],index:true, unique : true}
        this.lunchminute = {type: Number, required: [true, 'Lunch minute is required']}
        this.starttime = {type: String, required: [true, 'Start time is required']}
        this.endtime = {type: String, required: [true, 'End time is required']}
        this.isnightshift = {type : Number, default: 0}
        this.shifthour = {type : Number, default: 0}
        this.buffertime = {type : Number, default: 0}
        this.lunchhourcutafter = {type : Number, required: false}
        this.flexible = {type : Number, required: false}
        this.active = {type : Number, required: false, default: 1}
        this.totalshiftduration =  {type : Number, default: 0} 
        this.recordinfo = {type : mongoose.Schema.Types.Mixed, ref: 'recordinfo'}
    }
    getDataName() {
        return "Shift"
    }
    getFieldOrder(){

        return { 
            fields : [
            {
                'field' : 'shiftname',
                'text' : 'Shift Name',
                'type' : Config.getHtmlcontorls()['text'],
                'freeze' : 1,
                'active' : 1,
                'sorttable' : 1,
                'filter' : 1,
                'filterfieldtype' : Config.getHtmlcontorls()['lookup'],
                'defaultvalue' : '',
                'tblsize' : Config.getTblgridsizeclasses()['tbl-min-w200'],
                'indexfield': 1
            },
            {
                'field' : 'starttime',
                'text' : 'Start Time',
                'type' : Config.getHtmlcontorls()['text'],
                'freeze' : 0,
                'active' : 1,
                'sorttable' : 0,
                'filter' : 1,
                'filterfieldtype' : Config.getHtmlcontorls()['timepicker'],
                'defaultvalue' : '',
                'tblsize' : Config.getTblgridsizeclasses()['tbl-min-w150']
            },
            {
                'field' : 'endtime',
                'text' : 'End Time',
                'type' : Config.getHtmlcontorls()['text'],
                'freeze' : 0,
                'active' : 1,
                'sorttable' : 0,
                'filter' : 1,
                'filterfieldtype' : Config.getHtmlcontorls()['timepicker'],
                'defaultvalue' : '',
                'tblsize' : Config.getTblgridsizeclasses()['tbl-min-w150']
            },
            {
                'field' : 'lunchminute',
                'text' : 'Lunch Minute',
                'type' : Config.getHtmlcontorls()['text'],
                'freeze' : 0,
                'active' : 1,
                'sorttable' : 0,
                'filter' : 1,
                'filterfieldtype' : Config.getHtmlcontorls()['number-input'],
                'defaultvalue' : '',
                'tblsize' : Config.getTblgridsizeclasses()['tbl-min-w150']
            },
            {
                'field' : 'flexible',
                'text' : 'Flexible Time',
                'type' : Config.getHtmlcontorls()['switch'],
                'freeze' : 0,
                'active' : 1,
                'sorttable' : 0,
                'filter' : 1,
                'filterfieldtype' : Config.getHtmlcontorls()['checkbox'],
                'defaultvalue' : '',
                'tblsize' : Config.getTblgridsizeclasses()['tbl-w160']
            }, 
            {
                'field' : 'buffertime',
                'text' : 'Buffer Time',
                'type' : Config.getHtmlcontorls()['text'],
                'freeze' : 0,
                'active' : 1,
                'sorttable' : 0,
                'filter' : 1,
                'filterfieldtype' : Config.getHtmlcontorls()['number-input'],
                'defaultvalue' : '',
                'tblsize' : Config.getTblgridsizeclasses()['tbl-w160']
            },
            {
                'field' : 'active',
                'text' : 'Active',
                'type' : Config.getHtmlcontorls()['switch'],
                'freeze' : 0,
                'active' : 1,
                'sorttable' : 0,
                'filter' : 0,
                'filterfieldtype' : Config.getHtmlcontorls()['number-input'],
                'defaultvalue' : '',
                'tblsize' : Config.getTblgridsizeclasses()['tbl-w160']
            },
        ]

        }
    }   
}

