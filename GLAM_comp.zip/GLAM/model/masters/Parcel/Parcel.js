import mongoose from "mongoose"
import _Config from "../../../config/Config.js"
const Config = new _Config()

export default class Parcel {

  constructor() {
    this._id
    this.customerid = { type: mongoose.Schema.Types.ObjectId, ref: "tblcustomer" }
    this.customer = { type: String, required: true }
    this.propertyid = { type: mongoose.Schema.Types.ObjectId, ref: "tblpropertymaster" }
    this.property = { type: String, trim: true, required: true }
    this.parceldate = { type: Date, required: true }
    this.deliverycompanyid = { type: mongoose.Schema.Types.ObjectId, ref: "tbldeliverycompany" }
    this.deliverycompany = { type: String }
    this.deliveryperson = { type: String }
    this.notes = { type: String }
    this.contact = { type: String, trim: true }
    this.contact_countrycode = { type: String, trim: true }
    this.alternatecontact = { type: String, trim: true }
    this.alternatecontact_countrycode = { type: String, trim: true }
    this.ownedproperties = [{
      propertyid: { type: mongoose.Schema.Types.ObjectId, ref: "tblpropertymaster" },
      property: { type: String },
      unitid: { type: mongoose.Schema.Types.ObjectId, ref: "tblpropertyunit" },
      unit: { type: String },
      wingid: { type: mongoose.Schema.Types.ObjectId, ref: "tblpropertywing" },
      wing: { type: String },
      floorid: { type: mongoose.Schema.Types.ObjectId, ref: "tblpropertyfloor" },
      floor: { type: String },
      customerid: { type: mongoose.Schema.Types.ObjectId, ref: "tblcustomer" },
      customer: { type: String }
    }]
    this.gatekeeperid = { type:mongoose.Schema.Types.ObjectId},
    this.gatekeeper = {type:String},
    this.iscollectfromgate = { type: Number, enum: [0, 1], default: 0 } // 0-no , 1-yes
    this.status = { type: Number, default: 0 } // 0-pending ,1-collect gatekeeper,2 - collect customer
    this.collectdate = { type: Date }
    this.handoverdate = { type: Date }
    this.isentry = { type: String, required: true } //1-customer 2-gatekeeper
    this.isactive = { type: Number, required: true, default: 1 } // 1 - active, 0 - deactive
    this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: "recordinfo" }
  }

  getDataName() {
    return "Parcel"
  }

  getFieldOrder() {
    return {
      fields: [
        {
          'field': 'action_button',
          'text': '',
          'type': Config.getHtmlcontorls()['action_button'],
          'freeze': 1,
          'active': 1,
          'sorttable': 0,
          'filter': 0,
          'disableflex': 1,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': Config.getTblgridsizeclasses()[10]
        },
        {
          'field': 'status',
          'text': 'Status',
          'type': Config.getHtmlcontorls()['isactive'],
          'freeze': 1,
          'active': 1,
          'sorttable': 0,
          'filter': 0,
          'disableflex': 1,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': Config.getTblgridsizeclasses()[18]
        },
        {
          "field": "deliverycompany",
          "text": "Delivery Company",
          "type": "text",
          "freeze": 0,
          "active": 1,
          "sorttable": 1,
          "filter": 0,
          "filterfieldtype": "lookup",
          "defaultvalue": "",
          'tblsize': Config.getTblgridsizeclasses()[20]

        },
        {
          "field": "deliveryperson",
          "text": "Delivery person Name",
          "type": "text",
          "freeze": 0,
          "active": 1,
          "sorttable": 1,
          "filter": 0,
          "filterfieldtype": "lookup",
          "defaultvalue": "",
          'tblsize': Config.getTblgridsizeclasses()[20]

        },
        {
          "field": "customer",
          "text": "Customer Name",
          "type": "text",
          "freeze": 0,
          "active": 1,
          "sorttable": 1,
          "filter": 0,
          "filterfieldtype": "input-text",
          "masterdatafield": "personname",
          "formdatafield": "customerid",
          "defaultvalue": [],
          'tblsize': Config.getTblgridsizeclasses()[15]
        },
        {
          "field": "contact",
          "text": "Mobile Number",
          "type": "text",
          "freeze": 0,
          "active": 1,
          "sorttable": 0,
          "filter": 0,
          "filterfieldtype": "lookup",
          "defaultvalue": "", 'tblsize': Config.getTblgridsizeclasses()[15]
        },
        {
          "field": "alternatecontact",
          "text": "Phone Number",
          "type": "text",
          "freeze": 0,
          "active": 1,
          "sorttable": 0,
          "filter": 0,
          "filterfieldtype": "lookup",
          "defaultvalue": "", 'tblsize': Config.getTblgridsizeclasses()[15]
        },
        {
          'field': ['wing', 'floor', 'unit'],
          'text': 'Property Details',
          'type': "taglist",
          "forlisttag": "ownedproperties",
          'freeze': 0,
          'active': 1,
          'sorttable': 0,
          'sortby': 'wing',
          'filter': 0,
          'tblsize': Config.getTblgridsizeclasses()[55]
        },

        {
          "field": "fromdate",
          "text": "From Date & Time",
          "type": "datetimepicker",
          "freeze": 0,
          "active": 0,
          "sorttable": 1,
          "sortby": "fromdate",
          "filter": 1,
          "filterfield": "fromdate",
          "filterfieldtype": "datetimepicker",
          "isonlyfilter": 1,
          "defaultvalue": "",
          "tblsize": 28
        },
        {
          "field": "todate",
          "text": "To Date & Time",
          "type": "datetimepicker",
          "freeze": 0,
          "active": 0,
          "sorttable": 1,
          "sortby": "todate",
          "filter": 1,
          "filterfield": "todate",
          "filterfieldtype": "datetimepicker",
          "isonlyfilter": 1,
          "defaultvalue": "",
          "tblsize": 28
        },
        {
          "field": "notes",
          "text": "Notes",
          "type": "text",
          "freeze": 0,
          "active": 1,
          "sorttable": 0,
          "filter": 0,
          "filterfieldtype": "lookup",
          "defaultvalue": "",
          'tblsize': Config.getTblgridsizeclasses()[20]

        },
        {
          'field': 'collectdate',
          'text': 'Collect Date',
          'type': Config.getHtmlcontorls()['text'],
          'freeze': 0,
          'active': 1,
          'sorttable': 1,
          'sortby': 'collectdate',
          'filter': 0,
          'defaultvalue': '',
          'tblsize': Config.getTblgridsizeclasses()[15]
        },
        {
          'field': 'handoverdate',
          'text': 'Handover Date',
          'type': Config.getHtmlcontorls()['text'],
          'freeze': 0,
          'active': 1,
          'sorttable': 1,
          'sortby': 'handoverdate',
          'filter': 0,
          'defaultvalue': '',
          'tblsize': Config.getTblgridsizeclasses()[15]
        },

      ]
    }
  }

  getFormFieldOrder() {
    return {
      "rightsidebarsize": Config.getModalsizeclasses()['xs'],
      "pagename": 'parcel',
      "formname": 'Parcel',
      "alias": 'parcel',
      "dataview": "tab",
      'formfields': [
        {
          "tab": "parcel",
          "formFields": [
            // {
            //   'field': 'country',
            //   'text': 'Country Name',
            //   'type': Config.getHtmlcontorls()['kInputText'],
            //   'disabled': false,
            //   'defaultvisibility': true,
            //   'required': true,
            //   'gridsize': Config.getFieldSize()['k375'],
            // },
            // {
            //   'field': 'stateid',
            //   'text': 'State Name',
            //   'type': Config.getHtmlcontorls()['kDropDown'],
            //   'disabled': false,
            //   'defaultvisibility': true,
            //   'required': true,
            //   'gridsize': Config.getFieldSize()['k375'],
            //   'masterdata': 'state',
            //   'masterdatafield': 'state',
            //   'formdatafield': 'state',
            //   'cleanable': true,
            //   'searchable': true,

            //   'masterdatadependancy': false,
            //   'staticfilter': { 'isactive': 1 },
            // },
            // {
            //   'field': 'isactive',
            //   'text': 'Status',
            //   'type': Config.getHtmlcontorls()['kDropDown'],
            //   'disabled': false,
            //   'defaultvisibility': true,
            //   'required': true,
            //   'gridsize': Config.getFieldSize()['k375'],
            //   'masterdata': 'isactive',
            //   'masterdataarray': Config.getStatustype(),
            //   'defaultvalue': 1,
            //   'formdatafield': 'isactive',
            //   'cleanable': true,
            //   'searchable': true,
            //   'masterdatadependancy': false,
            // },
          ]
        }
      ],
    }
  }

}
