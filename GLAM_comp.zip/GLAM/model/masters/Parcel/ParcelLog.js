import mongoose from "mongoose"
import _Config from "../../../config/Config.js"
const Config = new _Config()

export default class ParcelLog {

    constructor() {
        this._id
        this.parcelid = { type: mongoose.Schema.Types.ObjectId, ref: "tblparcel" }
        this.propertyid = { type: mongoose.Schema.Types.ObjectId, ref: "tblpropertymaster" }
        this.property = { type: String} 
        this.gatekeeperid = { type: mongoose.Schema.Types.ObjectId, ref: "tblgatekeeper" }
        this.gatekeeper = { type:String}
        this.date = {type:Date,default:Date.now}        
        this.iscollectfromgate = { type: Number, enum: [0, 1], default: 0 } // 0-no , 1-yes
        this.status = { type: Number, default: 0 } //0 - pending ,1 - collect gatekeeper, 2 - collect customer
        this.collectdate = { type: Date }
        this.handoverdate = { type: Date }
        this.isactive = { type: Number, required: true, default: 1 } // 1 - active, 0 - deactive
        this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: "recordinfo" }
    }

  getDataName() {
    return "Parcel Log"
  }

}
