import mongoose from 'mongoose'
import { Config } from '../../config/Init.js'

export default class Vendorstaffdesignation {
    constructor() {
        this._id
        this.vendorstaffdesignation = { type: String, required: true, trim: true, index: { unique: true, collation: { locale: 'en', strength: 1 } } }
        this.isactive = { type: Number, required: true, default: 1 } // 1 - active, 0 - deactive
        this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: 'recordinfo' }
    }

    getDataName() {
        return "Vendorstaffdesignation"
    }

    getFieldOrder() {
        return {
            fields: [
                {
                    'field': 'action_button',
                    'text': '',
                    'type': Config.getHtmlcontorls()['action_button'],
                    'freeze': 1,
                    'active': 1,
                    'sorttable': 0,
                    'filter': 0,
                    'disableflex': 1,
                    'filterfieldtype': Config.getHtmlcontorls()['lookup'],
                    'defaultvalue': '',
                    'tblsize': 8
                },
                {
                    'field': 'isactive',
                    'text': 'Status',
                    'type': Config.getHtmlcontorls()['isactive'],
                    'freeze': 0,
                    'active': 1,
                    'sorttable': 0,
                    'filter': 0,
                    'disableflex': 1,
                    'filterfieldtype': Config.getHtmlcontorls()['lookup'],
                    'defaultvalue': '',
                    'tblsize': 15
                },
                {
                    'field': 'vendorstaffdesignation',
                    'text': 'Vendor Staff Designation',
                    'type': Config.getHtmlcontorls()['text'],
                    'freeze': 0,
                    'active': 1,
                    'sorttable': 1,
                    'filter': 0,
                    'sortby': 'vendorstaffdesignation',
                    'filterfieldtype': Config.getHtmlcontorls()['lookup'],
                    'defaultvalue': '',
                    'tblsize': 165
                }
            ]
        }
    }

    getFormFieldOrder() {
        return {
            "rightsidebarsize": 400,
            "pagename": "vendorstaffdesignation",
            "formname": "Vendor Staff Designation",
            "alias": "vendorstaffdesignation",
            "dataview": "tab",
            "formfields": [
                {
                    "tab": "Vendor Staff Designation",
                    "formFields": [
                        {
                            "field": "vendorstaffdesignation",
                            "text": "Vendor Staff Designation",
                            "type": "input-text",
                            "disabled": false,
                            "defaultvisibility": true,
                            "required": true,
                            "gridsize": 375,
                            "capitalcase": true
                        },
                    ]
                }
            ]
        }
    }
}

