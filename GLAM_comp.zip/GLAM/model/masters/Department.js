import mongoose from "mongoose"
import _Config from "../../config/Config.js"

export default class Department {
    constructor() {
        this._id
        this.department = { type: String, required: true, trim: true, unique: true }
        this.departmentcolor = {
            r: { type: Number, required: true, default: 0 },
            g: { type: Number, required: true, default: 0 },
            b: { type: Number, required: true, default: 0 },
            a: { type: Number, required: true, default: 0 }
        }
        this.isactive = { type: Number, default: 1 }
        this.isdefault = { type: Number, default: 0 }
        this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: "recordinfo" }
    }

    getFieldOrder() {
        const Config = new _Config()

        return {
            fields: [
                {
                    field: "department",
                    text: "Department",
                    type: Config.getHtmlcontorls()["text"],
                    freeze: 1,
                    active: 1,
                    sorttable: 1,
                    filter: 1,
                    filterfieldtype: Config.getHtmlcontorls()["lookup"],
                    defaultvalue: "",
                    tblsize: Config.getTblgridsizeclasses()["tbl-w350"]
                },
                {
                    field: "departmentcolor",
                    text: "Color",
                    type: Config.getHtmlcontorls()["color"],
                    freeze: 0,
                    active: 1,
                    sorttable: 0,
                    filter: 0,
                    filterfieldtype: Config.getHtmlcontorls()["lookup"],
                    defaultvalue: "",
                    tblsize: Config.getTblgridsizeclasses()["tbl-w30"]
                },
                {
					field: "isdefault",
					text: "Default",
					type: Config.getHtmlcontorls()["switch"],
					freeze: 0,
					active: 1,
					sorttable: 0,
					filter: 0, 
					filterfieldtype: Config.getHtmlcontorls()["dropdown"],
					formdatafield: "isdefault",
					masterdataarray: [
						{
							label: "Active",
							value: 1
						},
						{
							label: "Inactive",
							value: 0
						}
					],
					defaultvalue: 0,
					tblsize: Config.getTblgridsizeclasses()["tbl-w110"]
				},
                {
                    field: "isactive",
                    text: "Status",
                    type: Config.getHtmlcontorls()["switch"],
                    freeze: 0,
                    active: 1,
                    sorttable: 0,
                    filter: 1,
                    filterfieldtype: Config.getHtmlcontorls()["dropdown"], 
                    formdatafield: "isactive",
                    masterdataarray: [
                        {
                            label: "Active",
                            value: 1
                        },
                        {
                            label: "Inactive",
                            value: 0
                        }
                    ],
                    defaultvalue: "",
                    tblsize: Config.getTblgridsizeclasses()["tbl-w30"]
                }
            ]
        }
    }
}
