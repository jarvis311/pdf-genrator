import mongoose from 'mongoose'
import { Config } from '../../config/Init.js'

export default class GstTreatment {
  constructor() {
    this._id
    this.gsttreatment = { type: String, required: true, trim: true, index: { unique: true, collation: { locale: 'en', strength: 1 } } }
    this.description = { type: String }
    this.isgstnumber = { type: Number, default: 0 }
    this.isactive = { type: Number, required: true, default: 1 } // 1 - active, 0 - deactive
    this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: 'recordinfo' }
  }

  getDataName() {
    return "GST Treatment"
  }

  getFieldOrder() {
    return {
      fields: [
        {
          'field': 'action_button',
          'text': '',
          'type': Config.getHtmlcontorls()['action_button'],
          'freeze': 1,
          'active': 1,
          'sorttable': 0,
          'filter': 0,
          'disableflex': 1,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': 8
        },
        {
          'field': 'isactive',
          'text': 'Status',
          'type': Config.getHtmlcontorls()['isactive'],
          'freeze': 1,
          'active': 1,
          'sorttable': 0,
          'filter': 0,
          'disableflex': 1,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': 15
        },
        {
          'field': 'gsttreatment',
          'text': 'Gst Treatment',
          'type': Config.getHtmlcontorls()['text'],
          'freeze': 1,
          'active': 1,
          'sorttable': 1,
          'sortby': 'name',
          'filter': 0,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': 60
        },
        // {
        //   'field': 'description',
        //   'text': 'Description',
        //   'type': Config.getHtmlcontorls()['text'],
        //   'freeze': 1,
        //   'active': 1,
        //   'sorttable': 1,
        //   'sortby': 'name',
        //   'filter': 0,
        //   'filterfieldtype': Config.getHtmlcontorls()['lookup'],
        //   'defaultvalue': '',
        //   'tblsize': 70
        // },
        {
          'field': 'isgstnumber',
          'text': 'GST Number Required',
          type: Config.getHtmlcontorls()["switch"],
          'freeze': 1,
          'active': 1,
          'sorttable': 1,
          'sortby': 'name',
          'filter': 0,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': 35
        }
      ]
    }
  }

  getFormFieldOrder() {
    return {
      "rightsidebarsize": Config.getModalsizeclasses()['xs'],
      "pagename": 'gsttreatment',
      "formname": 'Gst Treatment',
      "alias": 'gsttreatment',
      "dataview": "tab",
      'formfields': [
        {
          "tab": "gsttreatment",
          "formFields": [
            {
              'field': 'gsttreatment',
              'text': 'Gst Treatment',
              'type': Config.getHtmlcontorls()['kInputText'],
              'disabled': false,
              'defaultvisibility': true,
              'required': true,
              'gridsize': Config.getFieldSize()['k375'],
              "capitalcase": true
            },
            // {
            //   'field': 'description',
            //   'text': 'Description',
            //   'type': Config.getHtmlcontorls()['kInputText'],
            //   'disabled': false,
            //   'defaultvisibility': true,
            //   'required': true,
            //   'gridsize': Config.getFieldSize()['k375'],
            // },
            {
              'field': 'isactive',
              'text': 'Status',
              'type': Config.getHtmlcontorls()['kDropDown'],
              'disabled': false,
              'defaultvisibility': true,
              'required': true,
              'gridsize': Config.getFieldSize()['k375'],
              'masterdata': 'isactive',
              'masterdataarray': Config.getStatustype(),
              'defaultvalue': 1,
              'formdatafield': 'isactive',
              'cleanable': true,
              'searchable': true,
              'masterdatadependancy': false,
            },
          ]
        }
      ],
    }
  }
}

