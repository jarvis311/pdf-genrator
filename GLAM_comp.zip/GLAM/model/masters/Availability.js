import mongoose from 'mongoose'
import { Config } from '../../config/Init.js'

export default class Availability {
    constructor() {
        this._id
        this.availability = { type: String, required: true, trim: true, index: { unique: true, collation: { locale: 'en', strength: 1 } } }
        this.isactive = { type: Number, required: true, default: 1 } // 1 - active, 0 - deactive
        this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: 'recordinfo' }
    }

    getDataName() {
        return "Availability"
    }

    getFieldOrder() {
        return {
            fields: [
                {
                    'field': 'action_button',
                    'text': '',
                    'type': Config.getHtmlcontorls()['action_button'],
                    'freeze': 1,
                    'active': 1,
                    'sorttable': 0,
                    'filter': 0,
                    'disableflex': 1,
                    'filterfieldtype': Config.getHtmlcontorls()['lookup'],
                    'defaultvalue': '',
                    'tblsize': 8
                },
                {
                    'field': 'isactive',
                    'text': 'Status',
                    'type': Config.getHtmlcontorls()['isactive'],
                    'freeze': 0,
                    'active': 1,
                    'sorttable': 0,
                    'filter': 0,
                    'disableflex': 1,
                    'filterfieldtype': Config.getHtmlcontorls()['lookup'],
                    'defaultvalue': '',
                    'tblsize': 15
                },
                {
                    'field': 'availability',
                    'text': 'Availability',
                    'type': Config.getHtmlcontorls()['text'],
                    'freeze': 0,
                    'active': 1,
                    'sorttable': 1,
                    'filter': 0,
                    'sortby': 'availability',
                    'filterfieldtype': Config.getHtmlcontorls()['lookup'],
                    'defaultvalue': '',
                    'tblsize': 165
                }
            ]
        }
    }

    getFormFieldOrder() {
        return {
            "rightsidebarsize": 400,
            "pagename": "availability",
            "formname": "Availability",
            "alias": "availability",
            "dataview": "tab",
            "formfields": [
                {
                    "tab": "availability",
                    "formFields": [
                        {
                            "field": "availability",
                            "text": "Availability",
                            "type": "input-text",
                            "disabled": false,
                            "defaultvisibility": true,
                            "required": true,
                            "gridsize": 375,
                            "capitalcase": true
                        },
                    ]
                }
            ]
        }
    }
}

