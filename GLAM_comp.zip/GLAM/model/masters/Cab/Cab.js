import mongoose from 'mongoose'
import { Config } from '../../../config/Init.js'

export default class Cab {
  constructor() {
    this._id
    this.customerid = { type: mongoose.Schema.Types.ObjectId, ref: "tblcustomer" }
    this.customer = { type: String, required: true }
    this.propertyid = { type: mongoose.Schema.Types.ObjectId, ref: "tblpropertymaster" }
    this.property = { type: String, trim: true, required: true }
    this.cabdate = { type: Date, required: true }
    this.cabcategoryid = { type: mongoose.Schema.Types.ObjectId, ref: "tblcabcategory" }
    this.cabcategory = { type: String, required: true }
    this.cabnumber = { type: String, required: true }
    this.cabperson = { type: String }
    this.notes = { type: String }
    this.contact = { type: String, trim: true }
    this.contact_countrycode = { type: String, trim: true }
    this.alternatecontact = { type: String, trim: true }
    this.alternatecontact_countrycode = { type: String, trim: true }
    this.ownedproperties = [{
      propertyid: { type: mongoose.Schema.Types.ObjectId, ref: "tblpropertymaster" },
      property: { type: String },
      unitid: { type: mongoose.Schema.Types.ObjectId, ref: "tblpropertyunit" },
      unit: { type: String },
      wingid: { type: mongoose.Schema.Types.ObjectId, ref: "tblpropertywing" },
      wing: { type: String },
      floorid: { type: mongoose.Schema.Types.ObjectId, ref: "tblpropertyfloor" },
      floor: { type: String },
      customerid: { type: mongoose.Schema.Types.ObjectId, ref: "tblcustomer" },
      customer: { type: String }
    }]
    this.startdate = { type: Date }
    this.enddate = { type: Date }
    // this.starttime = {type: String},
    // this.endtime = {type: String},
    // this.allowtime = [{
    //     startdate: { type: Date },
    //     enddate: { type: Date }
    //   }],
    this.status = { type: Number, default: 0 } // 0-pending ,1-verify gatekeeper, 2-out gatekeeper
    this.cabindate = { type: Date }
    this.caboutdate = { type: Date }
    this.isentry = { type: Number, required: true } //1-customer 2-gatekeeper
    this.isactive = { type: Number, required: true, default: 1 } // 1 - active, 0 - deactive
    this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: "recordinfo" }
    this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: 'recordinfo' }
  }

  getDataName() {
    return "Cab"
  }

  getFieldOrder() {
    return {
      fields: [
        {
          'field': 'action_button',
          'text': '',
          'type': Config.getHtmlcontorls()['action_button'],
          'freeze': 1,
          'active': 1,
          'sorttable': 0,
          'filter': 0,
          'disableflex': 1,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': Config.getTblgridsizeclasses()[10]
        },
        {
          'field': 'status',
          'text': 'Status',
          'type': Config.getHtmlcontorls()['isactive'],
          'freeze': 1,
          'active': 1,
          'sorttable': 0,
          'filter': 0,
          'disableflex': 1,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': Config.getTblgridsizeclasses()[18]
        },
        {
          "field": "cabcategory",
          "text": "Cab Company",
          "type": "text",
          "freeze": 0,
          "active": 1,
          "sorttable": 1,
          "filter": 0,
          "filterfieldtype": "lookup",
          "defaultvalue": "",
          'tblsize': Config.getTblgridsizeclasses()[20]

        },
        {
          "field": "cabperson",
          "text": "Cab person Name",
          "type": "text",
          "freeze": 0,
          "active": 1,
          "sorttable": 1,
          "filter": 0,
          "filterfieldtype": "lookup",
          "defaultvalue": "",
          'tblsize': Config.getTblgridsizeclasses()[20]

        },
        {
          "field": "cabnumber",
          "text": "Cab Number",
          "type": "text",
          "freeze": 0,
          "active": 1,
          "sorttable": 1,
          "filter": 0,
          "filterfieldtype": "lookup",
          "defaultvalue": "",
          'tblsize': Config.getTblgridsizeclasses()[20]

        },
        {
          "field": "customer",
          "text": "Customer Name",
          "type": "text",
          "freeze": 0,
          "active": 1,
          "sorttable": 1,
          "filter": 0,
          "filterfieldtype": "input-text",
          "masterdatafield": "personname",
          "formdatafield": "customerid",
          "defaultvalue": [],
          'tblsize': Config.getTblgridsizeclasses()[15]
        },
        {
          "field": "contact",
          "text": "Mobile Number",
          "type": "text",
          "freeze": 0,
          "active": 1,
          "sorttable": 0,
          "filter": 0,
          "filterfieldtype": "lookup",
          "defaultvalue": "", 'tblsize': Config.getTblgridsizeclasses()[15]
        },
        {
          "field": "alternatecontact",
          "text": "Phone Number",
          "type": "text",
          "freeze": 0,
          "active": 1,
          "sorttable": 0,
          "filter": 0,
          "filterfieldtype": "lookup",
          "defaultvalue": "", 'tblsize': Config.getTblgridsizeclasses()[15]
        },
        {
          'field': ['wing', 'floor', 'unit'],
          'text': 'Property Details',
          'type': "taglist",
          "forlisttag": "ownedproperties",
          'freeze': 0,
          'active': 1,
          'sorttable': 0,
          'sortby': 'wing',
          'filter': 0,
          'tblsize': Config.getTblgridsizeclasses()[55]
        },
        {
          "field": "fromdate",
          "text": "From Date & Time",
          "type": "datetimepicker",
          "freeze": 0,
          "active": 0,
          "sorttable": 1,
          "sortby": "fromdate",
          "filter": 1,
          "filterfield": "fromdate",
          "filterfieldtype": "datetimepicker",
          "isonlyfilter": 1,
          "defaultvalue": "",
          "tblsize": 28
        },
        {
          "field": "todate",
          "text": "To Date & Time",
          "type": "datetimepicker",
          "freeze": 0,
          "active": 0,
          "sorttable": 1,
          "sortby": "todate",
          "filter": 1,
          "filterfield": "todate",
          "filterfieldtype": "datetimepicker",
          "isonlyfilter": 1,
          "defaultvalue": "",
          "tblsize": 28
        },
        {
          'field': 'cabdate',
          'text': 'Cab Date',
          'type': Config.getHtmlcontorls()['text'],
          'freeze': 0,
          'active': 1,
          'sorttable': 1,
          'sortby': 'cabdate',
          'filter': 0,
          'defaultvalue': '',
          'tblsize': Config.getTblgridsizeclasses()[15]
        },
        {
          'field': 'cabindate',
          'text': 'Cab In Date',
          'type': Config.getHtmlcontorls()['text'],
          'freeze': 0,
          'active': 1,
          'sorttable': 1,
          'sortby': 'cabindate',
          'filter': 0,
          'defaultvalue': '',
          'tblsize': Config.getTblgridsizeclasses()[15]
        },
        {
          'field': 'caboutdate',
          'text': 'Cab Out Date',
          'type': Config.getHtmlcontorls()['text'],
          'freeze': 0,
          'active': 1,
          'sorttable': 1,
          'sortby': 'caboutdate',
          'filter': 0,
          'defaultvalue': '',
          'tblsize': Config.getTblgridsizeclasses()[15]
        },
      ]
    }
  }

  getFormFieldOrder() {
    return {
      "rightsidebarsize": Config.getModalsizeclasses()['xs'],
      "pagename": 'cab',
      "formname": 'Cab History',
      "alias": 'cab',
      "dataview": "tab",
      'formfields': [
        {
          "tab": "cab",
          "formFields": [
            {
              'field': 'cabcategory',
              'text': 'Cab Category Name',
              'type': Config.getHtmlcontorls()['kInputText'],
              'disabled': false,
              'defaultvisibility': true,
              'required': true,
              'gridsize': Config.getFieldSize()['k375'],
            },
            {
              'field': 'isactive',
              'text': 'Status',
              'type': Config.getHtmlcontorls()['kDropDown'],
              'disabled': false,
              'defaultvisibility': true,
              'required': true,
              'gridsize': Config.getFieldSize()['k375'],
              'masterdata': 'status',
              'masterdataarray': Config.getStatustype(),
              'defaultvalue': 1,
              'formdatafield': 'status',
              'cleanable': true,
              'searchable': true,
              'onchangedata': ['statusid'],
              'masterdatadependancy': false,
            },
          ]
        }
      ],
    }
  }
}

