import mongoose from 'mongoose'
import { Config } from '../../config/Init.js'

export default class VisitorCategory {
  constructor() {
    this._id
    this.name = { type: String, required: true, trim: true, index: { unique: true, collation: { locale: 'en', strength: 1 } } }
    this.iconimage = {
      url: { type: String, required: false, trim: true },
      name: { type: String, required: false, trim: true },
      size: { type: Number, required: false, trim: true },
      extension: { type: String, required: false, trim: true }
    }
    this.captureimage = { type: Number, default: 1 }
    this.hascompanyselection = { type: Number, default: 1 }
    this.isservice = { type: Number, default: 1 }
    this.image = { type: String }
    this.isactive = { type: Number, required: true, default: 1 } // 1 - active, 0 - deactive
    this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: 'recordinfo' }
  }

  getDataName() {
    return "Visitor Category";
  }

  getFieldOrder() {
    return {
      fields: [
        {
          'field': 'action_button',
          'text': '',
          'type': Config.getHtmlcontorls()['action_button'],
          'freeze': 1,
          'active': 1,
          'sorttable': 0,
          'filter': 0,
          'disableflex': 1,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': 8
        },
        {
          'field': 'isactive',
          'text': 'Status',
          'type': Config.getHtmlcontorls()['isactive'],
          'freeze': 1,
          'active': 1,
          'sorttable': 0,
          'filter': 0,
          'disableflex': 1,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': 15
        },
        {
          'field': 'name',
          'text': 'Category Name',
          'type': Config.getHtmlcontorls()['text'],
          'freeze': 1,
          'active': 1,
          'sorttable': 1,
          'filter': 0,
          'sortby': 'name',
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': 25
        },
        {
          'field': 'iconimage',
          'text': 'Category Image',
          'type': Config.getHtmlcontorls()['icon'],
          'freeze': 1,
          'active': 1,
          'sorttable': 0,
          'filter': 0,
          'filterfieldtype': Config.getHtmlcontorls()['dropdown'],
          'defaultvalue': '',
          'tblsize': 15
        },
        {
          'field': 'hascompanyselection',
          'text': 'Has Company Selection',
          'type': Config.getHtmlcontorls()['switch'],
          'freeze': 0,
          'active': 1,
          'sorttable': 0,
          'filter': 0,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': 15
        },
        {
          'field': 'isservice',
          'text': 'is Service',
          'type': Config.getHtmlcontorls()['switch'],
          'freeze': 0,
          'active': 1,
          'sorttable': 0,
          'filter': 0,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': 15
        },
        
      ]
    }
  }

  getFormFieldOrder() {
    return {
      "rightsidebarsize": Config.getModalsizeclasses()['xs'],
      "pagename": 'visitorcategory',
      "formname": 'Visitor Category',
      "alias": 'visitor',
      "dataview": "tab",
      'formfields': [
        {
          "tab": "visitor",
          "formFields": [
            {
              'field': 'name',
              'text': 'Category Name',
              'type': Config.getHtmlcontorls()['kInputText'],
              'disabled': false,
              "regex": "[a-zA-Z ]",
              'defaultvisibility': true,
              'required': true,
              'gridsize': Config.getFieldSize()['k375'],
              "capitalcase": true
            },
            {
              'field': 'iconimage',
              'text': 'Category Image',
              'type': Config.getHtmlcontorls()['kFilePicker'],
              'disabled': false,
              'defaultvisibility': true,
              'required': true,
              'filetypes': Config.images,
              'gridsize': Config.getFieldSize()['k375'],
            },
            {
              'field': 'captureimage',
              'text': 'Capture Image',
              'type': 'checkbox',
              'disabled': false,
              'required': false,
              'defaultvisibility': true,
              'gridsize': 375,
            },
            {
              'field': 'hascompanyselection',
              'text': 'Has Company Selection',
              'type': 'checkbox',
              'disabled': false,
              'required': false,
              'defaultvisibility': true,
              'gridsize': 375,
            },
            {
              'field': 'isservice',
              'text': 'is Service',
              'type': 'checkbox',
              'disabled': false,
              'required': false,
              'defaultvisibility': true,
              'gridsize': 375,
            },
            {
              'field': 'isactive',
              'text': 'Status',
              'type': Config.getHtmlcontorls()['kDropDown'],
              'disabled': false,
              'defaultvisibility': true,
              'required': true,
              'gridsize': Config.getFieldSize()['k375'],
              'masterdata': 'status',
              'masterdataarray': Config.getStatustype(),
              'defaultvalue': 1,
              'formdatafield': 'status',
              'cleanable': true,
              'searchable': true,
              'onchangedata': ['statusid'],
              'masterdatadependancy': false,
            },
          ]
        }
      ],
    }
  }
}

