import mongoose from 'mongoose'
import { Config } from '../../config/Init.js'

export default class DeliveryCompany {
  constructor() {
    this._id
    this.deliverycompany = { type: String, required: true, trim: true, index: { unique: true, collation: { locale: 'en', strength: 1 } } }
    this.logo = { type: Object,default:{}}
    this.visitorcategoryid = { type: mongoose.Schema.Types.ObjectId, ref: 'tblcategorymaster' }
    this.visitorcategory = { type: String }
    this.isactive = { type: Number, required: true, default: 1 } // 1 - active, 0 - deactive
    this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: 'recordinfo' }
  }

  getDataName() {
    return "Delivery Company"
  }

  getFieldOrder() {
    return {
      fields: [
        {
          'field': 'action_button',
          'text': '',
          'type': Config.getHtmlcontorls()['action_button'],
          'freeze': 1,
          'active': 1,
          'sorttable': 0,
          'filter': 0,
          'disableflex': 1,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': 8
        },
        {
          'field': 'isactive',
          'text': 'Status',
          'type': Config.getHtmlcontorls()['isactive'],
          'freeze': 0,
          'active': 1,
          'sorttable': 0,
          'filter': 0,
          'disableflex': 1,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': 15
        },
        {
          'field': 'visitorcategory',
          'text': 'Visitor Category',
          'type': Config.getHtmlcontorls()['text'],
          'freeze': 0,
          'active': 1,
          'sorttable': 1,
          'filter': 0,

          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': 80
        },
        {
          'field': 'name',
          'text': 'Delivery Company Name',
          'type': Config.getHtmlcontorls()['text'],
          'freeze': 0,
          'active': 1,
          'sorttable': 1,
          'filter': 0,
          'sortby': 'name',
          // '  ': 3,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': 85
        },

      ]
    }
  }

  getFormFieldOrder() {
    return {
      "rightsidebarsize": Config.getModalsizeclasses()['xs'],
      "pagename": 'deliverycompany',
      "formname": 'Delivery Company',
      "alias": 'deliverycompany',
      "dataview": "tab",
      'formfields': [
        {
          "tab": "delivery",
          "formFields": [
            {
              'field': 'visitorcategoryid',
              'text': 'Visitor Category',
              'type': Config.getHtmlcontorls()['kDropDown'],
              'disabled': false,
              'defaultvisibility': true,
              'required': true,
              'gridsize': Config.getFieldSize()['k375'],
              'masterdata': 'visitorcategory',
              'masterdatafield': 'name',
              'defaultvalue': '',
              'formdatafield': 'visitorcategory',
              'cleanable': true,
              'searchable': true,
              'onchangedata': ['visitorcategoryid'],
              'masterdatadependancy': false,
            },
            {
              'field': 'deliverycompany',
              'text': 'Company Name',
              'type': Config.getHtmlcontorls()['kInputText'],
              'disabled': false,
              'defaultvisibility': true,
              'required': true,
              'gridsize': Config.getFieldSize()['k375'],
              "capitalcase": true,
            },
            {"field": "logo", "text": "Logo", "type": "file", "filetypes": Config.images, "disabled": false, "defaultvisibility": true, "required": false, "gridsize": 375},
            {
              'field': 'isactive',
              'text': 'Status',
              'type': Config.getHtmlcontorls()['kDropDown'],
              'disabled': false,
              'defaultvisibility': true,
              'required': true,
              'gridsize': Config.getFieldSize()['k375'],
              'masterdata': 'status',
              'masterdataarray': Config.getStatustype(),
              'defaultvalue': 1,
              'formdatafield': 'status',
              'cleanable': true,
              'searchable': true,
              'onchangedata': ['statusid'],
              'masterdatadependancy': false,
            },
          ]
        }
      ],
    }
  }
}

