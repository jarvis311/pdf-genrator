import mongoose from 'mongoose'
import { Config } from '../../config/Init.js'

export default class City {
  constructor() {
    this._id
    this.city = { type: String, required: true, trim: true, index: { unique: true, collation: { locale: 'en', strength: 1 } } }
    this.stateid = { type: mongoose.Schema.Types.ObjectId, ref: 'tblstatemaster' }
    this.state = { type: String, required: true, trim: true }
    this.countryid = { type: mongoose.Schema.Types.ObjectId, ref: 'tblcountrymaster' }
    this.country = { type: String, required: true, trim: true }
    this.isactive = { type: Number, required: true, default: 1 } // 1 - active, 0 - deactive
    this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: 'recordinfo' }
  }

  getDataName() {
    return "City"
  }

  getFieldOrder() {
    return {
      fields: [
        {
          "field": "action_button",
          "text": "",
          "type": "action_button",
          "freeze": 1,
          "active": 1,
          "sorttable": 0,
          "filter": 0,
          "disableflex": 1,
          "filterfieldtype": "lookup",
          "defaultvalue": "",
          "tblsize": 8
        },
        {
          "field": "isactive",
          "text": "Status",
          "type": "isactive",
          "freeze": 1,
          "active": 1,
          "sorttable": 0,
          "filter": 0,
          "disableflex": 1,
          "filterfieldtype": "lookup",
          "defaultvalue": "",
          "tblsize": 15
        },
        {
          "field": "state",
          "text": "State Name",
          "type": "text",
          "freeze": 1,
          "active": 1,
          "sorttable": 1,
          "sortby": "state",
          "filter": 0,
          'filterfield': 'state',
          "filterfieldtype": "dropdown",
          "apipath": "masters/state",
          "masterdata": "state",
          "masterdatafield": "state",
          "formdatafield": "stateid",
          "defaultvalue": "",
          "tblsize": 15
        },
        {
          "field": "city",
          "text": "City Name",
          "type": "text",
          "freeze": 1,
          "active": 1,
          "sorttable": 1,
          "sortby": "city",
          "filter": 0,
          "filterfieldtype": "lookup",
          "defaultvalue": "",
          "tblsize": 15
        },
        {
          'field': 'country',
          'text': 'Country Name',
          'type': Config.getHtmlcontorls()['text'],
          'freeze': 1,
          'active': 1,
          'sorttable': 1,
          'sortby': 'country',
          'filter': 0,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': 15
        },
        // {
        //     "field": "country",
        //     "text": "Country Name",
        //     "type": "text",
        //     "freeze": 1,
        //     "active": 1,
        //     "sorttable": 1,
        //     "sortby": "country",
        //     "filter": 1,
        //     'filterfield': 'country',
        //     "filterfieldtype": "dropdown",
        //     "apipath": "masters/country",
        //     "masterdata": "country",
        //     "masterdatafield": "country",
        //     "formdatafield": "countryid",
        //     "defaultvalue": "",
        //     "tblsize": 10
        // }
      ]
    }
  }

  getFormFieldOrder() {
    return {
      "rightsidebarsize": Config.getModalsizeclasses()['xs'],
      "pagename": 'city',
      "formname": 'City',
      "alias": 'city',
      "dataview": "tab",
      'formfields': [
        {
          "tab": "City",
          "formFields": [
            {
              'field': 'city',
              'text': 'City Name',
              'type': Config.getHtmlcontorls()['kInputText'],
              'disabled': false,
              'defaultvisibility': true,
              'required': true,
              'gridsize': Config.getFieldSize()['k375'],
              "capitalcase": true
            },
            {
              'field': 'countryid',
              'text': 'Country Name',
              'type': Config.getHtmlcontorls()['kDropDown'],
              'disabled': false,
              'defaultvisibility': true,
              'required': true,
              'gridsize': Config.getFieldSize()['k375'],
              'masterdata': 'country',
              'masterdatafield': 'country',
              'formdatafield': 'country',
              'cleanable': true,
              'searchable': true,
              'onchangefill':['stateid'],
              // 'dependentfilter': {
              //   'countryid': 'countryid',
              // },
              'masterdatadependancy': false,
              'staticfilter': { 'isactive': 1 },
            },
            {
              'field': 'stateid',
              'text': 'State Name',
              'type': Config.getHtmlcontorls()['kDropDown'],
              'disabled': false,
              'defaultvisibility': true,
              'required': true,
              'gridsize': Config.getFieldSize()['k375'],
              'masterdata': 'state',
              'masterdatafield': 'state',
              'formdatafield': 'state',
              'cleanable': true,
              'searchable': true,
              'dependentfilter': {
                'countryid': 'countryid',
              },
              'masterdatadependancy': true,
              'staticfilter': { 'isactive': 1 },
            },
           
            Config.getFormfields()['isactive']
          ]
        }
      ],
    }
  }
}

