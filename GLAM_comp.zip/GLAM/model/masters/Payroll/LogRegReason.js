import mongoose from 'mongoose'
import _Config from '../../../config/Config.js'


export default class LogRegularizationReason
{ 
    constructor(){
        this._id
        this.reason = {type: String, required: true}
        this.deletereason = {type: Number, default: 0}
        this.recordinfo = {type : mongoose.Schema.Types.Mixed, ref: 'recordinfo'}
    }
    getDataName() {
        return "Log Regularization Reason"
    }
}