import  mongoose  from 'mongoose'
import _Config from '../../../config/Config.js'

export default class LogManage
{ 
    constructor(){
        this._id
        // Clock or Break
        this.DeviceLogId = { type: String, required: true, unique: true, trim: true }
        this.DownloadDate = { type: String, trim: true, default: "" }
        this.DeviceId = { type: String, trim: true, default: "" }
        this.UserId = { type: String, required: true, trim: true }
        this.Direction = { type: String, trim: true, default: "" }
        this.AttDirection = { type: String, trim: true, default: "" }
        this.propertyname = { type: String, trim: true, default: "" }
        this.C1 = { type: String, trim: true, default: "" } 
        this.C2 = { type: String, trim: true, default: "" } 
        this.C3 = { type: String, trim: true, default: "" } 
        this.LogDate = { type: Date, default: Date.now }
        this.ActualLogDate = { type: Date, default: null }
        this.estimateTime = { type: Number, default: 0 }
        this.LogDetail = { type: String, trim: true, default: "" }
        this.WorkCode = { type: String, trim: true, default: "" }
        this.platform = { type: String, trim: true, default: "" }
        this.notes = { type: String, trim: true, default: "" }
        this.latitude = { type: String, trim: true, default: "" }
        this.longitude = { type: String, trim: true, default: "" }
        this.sendnotification = { type: Number, default: 0 }
        this.ismanual = { type: Number, default: 0 }
        this.deleted = { type: Number, default: 0 }
        this.deletereason = { type: String, trim: true, default: "" }
        this.logtype = { type: Number, default: 0 } // 1->Clock
        this.clocktype = {type: Number, default: 0} // 1->ClockIn, 2->ClockOut
        // Late Reason
        this.islateclockin = { type: Number, default: 0 }
        this.requestedclockin = { type: Number, trim: true, default: 0 } // 0 -> normal log , 1 -> requested clock
        // to handle log request
        this.logrequestid = { type : mongoose.Schema.Types.ObjectId}
        this.logrequeststatus = { type: Number, default : 0}
        this.requestreason = { type: String, trim: true, default: "" }
        this.headerpropertyid = { type: String, trim: true, default: "" }
        this.headerpropertyname = { type: String, trim: true, default: "" }
        this.ontimereporting = { type: Number, default: 0 } 
        this.aftertimereporting = { type: Number, default: 0 } 
        this.LogDate_timezone = { type: Date }
        this.ActualLogDate_timezone = { type: Date }
        this.sortLogDate = { type: Date}
        this.assignpersonid = { type: mongoose.Schema.Types.ObjectId},
        this.assignperson = { type: String, trim: true, default: "" },
        this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: "recordinfo" }
    }
    getDataName() {
        return "Log Data"
    }

        //DOUBT
        getFieldOrder(){
            const Config = new _Config()
    
            return {
                fields : [
                    
                    {
                        'field' : 'personname',
                        'text' : 'Requested Person',
                        'type' : Config.getHtmlcontorls()['text'],
                        'freeze' : 1,
                        'active' : 1,
                        'sorttable' : 1,
                        'filter' : 1,
                        'filterfieldtype' : Config.getHtmlcontorls()['input-text'],
                        'defaultvalue' : '',
                        'tblsize' : Config.getTblgridsizeclasses()['tbl-min-w200']
                    },
                    {
                        'field' : 'date',
                        'text' : 'Requested Date',
                        'type' : Config.getHtmlcontorls()['text'],
                        'freeze' : 0,
                        'active' : 1,
                        'sorttable' : 1,
                        'filter' : 0,
                        'filterfieldtype' : Config.getHtmlcontorls()['datepicker'],
                        'defaultvalue' : '',
                        'tblsize' : Config.getTblgridsizeclasses()['tbl-min-w200']
                    },          
                    {
                        'field' : 'requestedtimelog',
                        'text' : 'Requested Time Log',
                        'type' : Config.getHtmlcontorls()['text'],
                        'freeze' : 0,
                        'active' : 1,
                        'sorttable' : 1,
                        'filter' : 0,
                        'filterfieldtype' : Config.getHtmlcontorls()['timepicker'],
                        'defaultvalue' : '',
                        'tblsize' : Config.getTblgridsizeclasses()['tbl-min-w200']
                    }, 
                    // {
                    //     'field' : 'reportingstatus',
                    //     'text' : 'Reporting Status',
                    //     'type' : Config.getHtmlcontorls()['text'],
                    //     'freeze' : 0,
                    //     'active' : 1,
                    //     'sorttable' : 1,
                    //     'filter' : 0,
                    //     'filterfieldtype' : Config.getHtmlcontorls()['input-text'],
                    //     'defaultvalue' : '',
                    //     'tblsize' : Config.getTblgridsizeclasses()['tbl-min-w200']
                    // },
                    {
                        'field' : 'status',
                        'text' : 'Status',
                        'type' : Config.getHtmlcontorls()['text'],
                        'freeze' : 0,
                        'active' : 1,
                        'sorttable' : 1,
                        'filter' : 0,
                        'filterfieldtype' : Config.getHtmlcontorls()['input-text'],
                        'defaultvalue' : '',
                        'tblsize' : Config.getTblgridsizeclasses()['tbl-min-w200']
                    },
                    {
                        'field' : 'requesttype',
                        'text' : 'Request Type',
                        'type' : Config.getHtmlcontorls()['text'],
                        'freeze' : 0,
                        'active' : 1,
                        'sorttable' : 1,
                        'filter' : 0,
                        'filterfieldtype' : Config.getHtmlcontorls()['input-text'],
                        'defaultvalue' : '',
                        'tblsize' : Config.getTblgridsizeclasses()['tbl-min-w200']
                    },
                    {
                        'field' : 'reason',
                        'text' : 'Reason',
                        'type' : Config.getHtmlcontorls()['text'],
                        'freeze' : 0,
                        'active' : 1,
                        'sorttable' : 1,
                        'filter' : 0,
                        'filterfieldtype' : Config.getHtmlcontorls()['modal-eye'],
                        'defaultvalue' : '',
                        'tblsize' : Config.getTblgridsizeclasses()['tbl-min-w150']
                    }  , 
                    
                    // {
                    //     'field' : 'approvalstatus',
                    //     'text' : 'Approval Status',
                    //     'type' : Config.getHtmlcontorls()['text'],
                    //     'freeze' : 0,
                    //     'active' : 1,
                    //     'sorttable' : 1,
                    //     'filter' : 0,
                    //     'filterfieldtype' : Config.getHtmlcontorls()['input-text'],
                    //     'defaultvalue' : '',
                    //     'tblsize' : Config.getTblgridsizeclasses()['tbl-min-w200']
                    // },
                    // {
                    //     'field' : 'rejectreason',
                    //     'text' : 'Reject Reason',
                    //     'type' : Config.getHtmlcontorls()['text'],
                    //     'freeze' : 0,
                    //     'active' : 1,
                    //     'sorttable' : 1,
                    //     'filter' : 0,
                    //     'filterfieldtype' : Config.getHtmlcontorls()['input-text'],
                    //     'defaultvalue' : '',
                    //     'tblsize' : Config.getTblgridsizeclasses()['tbl-min-w150']
                    // },
                ]
            }
        }
}