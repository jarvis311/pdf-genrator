import  mongoose  from 'mongoose'
import _Config from '../../../config/Config.js'

export default class InvalidLogs
{ 
    constructor(){
        this._id
        this.DeviceLogId = {type:String, }
        this.DownloadDate = {type:String,}
        this.DeviceId = {type: String, required:false}
        this.UserId = {type: String, required:false}
        this.Direction = {type: String}
        this.AttDirection = {type: String}
        this.person = {type:String,required:false}
        this.personid = {type:mongoose.Schema.Types.ObjectId, ref: 'tblpersonmaster'}
        this.C1 = {type:String}
        this.C2 = {type:String}
        this.C3 = {type:String}
        this.C4 = {type:String}
        this.C5 = {type: String}
        this.C6 = {type: String}
        this.C7 = {type:String}
        this.LogDate = {type:String}
        this.employeecode = {type:String}
        this.ip = {type:String}
        this.LogDetail = {type: String}
        this.WorkCode = {type: String}
        this.platform = {type:String}
        this.deleted = {type:Number}
        this.location = {type:Array, required:false}
        this.image = {type:String, required:false}
        this.reason = {type:String}
        this.latereasonid = {type:String}
        this.latereason = {type:String}
        this.status = {type:Number, default:0} // 0 pending 1 approved 2 reject
        this.approveorrejectdbyid = {type: String}
        this.clockintype = {type: Number} // 1 : clock in, 2 : clock out 
        this.approveorrejectdby = {type:String}
        this.approveorrejecttime = {type:String}
        this.recordinfo = {type : mongoose.Schema.Types.Mixed, ref: 'recordinfo'}
    }
    getDataName() {
        return "LOG"
    }
    //DOUBT
    getFieldOrder(){
        const Config = new _Config()

        return {
            fields : [
                {
                    'field' : 'employeecode',
                    'text' : 'EMPLOYEE CODE',
                    'type' : Config.getHtmlcontorls()['text'],
                    'freeze' : 1,
                    'active' : 1,
                    'sorttable' : 1,
                    'filter' : 1,
                    'filterfieldtype' : Config.getHtmlcontorls()['lookup'],
                    'defaultvalue' : '',
                    'tblsize' : Config.getTblgridsizeclasses()['tbl-min-w200']
                },
                {
                    'field' : 'person',
                    'text' : 'Name',
                    'type' : Config.getHtmlcontorls()['text'],
                    'freeze' : 0,
                    'active' : 1,
                    'sorttable' : 1,
                    'filter' : 1,
                    'filterfieldtype' : Config.getHtmlcontorls()['lookup'],
                    'defaultvalue' : '',
                    'tblsize' : Config.getTblgridsizeclasses()['tbl-min-w150']
                },                  
                {
                    'field' : 'time',
                    'text' : 'Time',
                    'type' : Config.getHtmlcontorls()['text'],
                    'freeze' : 0,
                    'active' : 1,
                    'sorttable' : 1,
                    'filter' : 1,
                    'filterfieldtype' : Config.getHtmlcontorls()['lookup'],
                    'defaultvalue' : '',
                    'tblsize' : Config.getTblgridsizeclasses()['tbl-min-w150']
                },                  
                {
                    'field' : 'ip',
                    'text' : 'IP',
                    'type' : Config.getHtmlcontorls()['text'],
                    'freeze' : 0,
                    'active' : 1,
                    'sorttable' : 1,
                    'filter' : 1,
                    'filterfieldtype' : Config.getHtmlcontorls()['lookup'],
                    'defaultvalue' : '',
                    'tblsize' : Config.getTblgridsizeclasses()['tbl-min-w150']
                },                  
                {
                    'field' : 'status',
                    'text' : 'Status',
                    'type' : Config.getHtmlcontorls()['text'],
                    'freeze' : 0,
                    'active' : 1,
                    'sorttable' : 1,
                    'filter' : 1,
                    'filterfieldtype' : Config.getHtmlcontorls()['lookup'],
                    'defaultvalue' : '',
                    'tblsize' : Config.getTblgridsizeclasses()['tbl-min-w150']
                },                  
                {
                    'field' : 'approvedorrejectedby',
                    'text' : 'Approved/rejected by',
                    'type' : Config.getHtmlcontorls()['text'],
                    'freeze' : 0,
                    'active' : 1,
                    'sorttable' : 1,
                    'filter' : 1,
                    'filterfieldtype' : Config.getHtmlcontorls()['lookup'],
                    'defaultvalue' : '',
                    'tblsize' : Config.getTblgridsizeclasses()['tbl-min-w150']
                },                  
                {
                    'field' : 'approvetime',
                    'text' : 'Approve Time',
                    'type' : Config.getHtmlcontorls()['text'],
                    'freeze' : 0,
                    'active' : 1,
                    'sorttable' : 1,
                    'filter' : 1,
                    'filterfieldtype' : Config.getHtmlcontorls()['lookup'],
                    'defaultvalue' : '',
                    'tblsize' : Config.getTblgridsizeclasses()['tbl-min-w150']
                },                  
            ]
        }
    }

}

