import { Config } from "../../../config/Init.js"
import mongoose from "mongoose"

export default class ClockinRequest {
    constructor() {
        this._id

        this.DeviceLogId = { type: String, required: true, unique: true, trim: true }
        this.DownloadDate = { type: String, trim: true, default: "" }
        this.DeviceId = { type: String, trim: true, default: "" }
        this.UserId = { type: String, required: true, trim: true }
        this.Direction = { type: String, trim: true, default: "" }
        this.AttDirection = { type: String, trim: true, default: "" }
        this.propertyname = { type: String, trim: true, default: "" }
        this.personid = { type: mongoose.Schema.Types.ObjectId, ref: "tblpersonmaster" }
        this.personname = { type: String, trim: true, default: "" }
        this.companyid = { type: mongoose.Schema.Types.ObjectId, ref: "tblcompanymaster" }
        this.companyname = { type: String, trim: true, default: "" }
        this.C1 = { type: String, trim: true, default: "" } // PropertyId
        this.C2 = { type: String, trim: true, default: "" } // Selfi Path
        this.C3 = { type: String, trim: true, default: "" } // Address
        this.C4 = { type: String, trim: true, default: "" } // Break Type Id
        this.C5 = { type: String, trim: true, default: "" } // QR Code
        this.C6 = { type: String, trim: true, default: "" }
        this.C7 = { type: String, trim: true, default: "" }
        this.LogDate = { type: Date, default: Date.now }
        this.ActualLogDate = { type: Date, default: null }
        this.estimateTime = { type: Number, default: 0 }
        this.LogDetail = { type: String, trim: true, default: "" }
        this.WorkCode = { type: String, trim: true, default: "" }
        this.platform = { type: String, trim: true, default: "" }
        this.notes = { type: String, trim: true, default: "" }
        this.latitude = { type: String, trim: true, default: "" }
        this.longitude = { type: String, trim: true, default: "" }
        this.sendnotification = { type: Number, default: 0 }

        this.batterylevel = { type: Number, default: 0 }
        this.ismanual = { type: Number, default: 0 }
        this.deleted = { type: Number, default: 0 }
        this.deletereason = { type: String, trim: true, default: "" }
        this.logtype = { type: Number, default: 1 } // 1->Clock

        this.nightshift = { type: Number, default: 0 }
        this.status = { type: Number, default: 0 } // 0 -> pending log , 1 -> approved, 2 -> rejected
        this.requestedclockin = { type: Number, trim: true, default: 1 } 
        this.rejectreason = { type: String, trim:true, default: "" } // reject reason for reject clockin request

        //Attendance Hardware Log
        this.attendancehardwareid = { type: mongoose.Schema.Types.ObjectId, default: Config.dummyObjid },

        //for paid log
        this.ispaid = { type: Number, trim: true, default: 0 } // 1-> paid , 0 -> unpaid

        this.approveorrejectpersonid = { type: mongoose.Schema.Types.ObjectId, ref: "tblpersonmaster" }
        this.approveorrejectperson = { type: String, trim: true, default: "" }
        this.approveorrejecttime = { type: Date, trim: true , default: "" }

        this.requestreason = { type: String, trim: true, default: "" }

        this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: "recordinfo" }
    }

    getFieldOrder() {
        return {
            fields: [
                {
                    field: "propertyname",
                    text: "Property Name",
                    type: Config.getHtmlcontorls()["text"],
                    freeze: 1,
                    active: 1,
                    sorttable: 1,
                    filter: 1,
                    filterfieldtype: Config.getHtmlcontorls()["lookup"],
                    defaultvalue: "",
                    tblsize: Config.getTblgridsizeclasses()["tbl-min-w150"]
                },
                {
                    field: "personname",
                    text: "Person Name",
                    type: Config.getHtmlcontorls()["text"],
                    freeze: 0,
                    active: 1,
                    sorttable: 1,
                    filter: 1,
                    filterfieldtype: Config.getHtmlcontorls()["lookup"],
                    defaultvalue: "",
                    tblsize: Config.getTblgridsizeclasses()["tbl-min-w150"]
                },
                {
                    field: "LogDate",
                    text: "Requested Date/Time",
                    type: Config.getHtmlcontorls()["text"],
                    freeze: 0,
                    active: 1,
                    sorttable: 1,
                    filter: 1,
                    filterfieldtype: Config.getHtmlcontorls()["daterangepicker"],
                    defaultvalue: "",
                    tblsize: Config.getTblgridsizeclasses()["tbl-min-w150"]
                },
                {
                    field: "requestreason",
                    text: "Request Reason",
                    type: Config.getHtmlcontorls()["text"],
                    freeze: 0,
                    active: 1,
                    sorttable: 1,
                    filter: 1,
                    filterfieldtype: Config.getHtmlcontorls()["lookup"],
                    defaultvalue: "",
                    tblsize: Config.getTblgridsizeclasses()["tbl-min-w150"]
                },
                // {
                //     field: "LogDate",
                //     text: "Requested Time",
                //     type: Config.getHtmlcontorls()["text"],
                //     freeze: 0,
                //     active: 1,
                //     sorttable: 1,
                //     filter: 1,
                //     filterfieldtype: Config.getHtmlcontorls()["datetimepicker"],
                //     defaultvalue: "",
                //     tblsize: Config.getTblgridsizeclasses()["tbl-min-w150"]
                // },
                // {
				// 	field: "status",
				// 	text: "Status",
				// 	type: Config.getHtmlcontorls()["text"],
				// 	freeze: 0,
				// 	active: 1,
				// 	sorttable: 1,
				// 	filter: 1,
				// 	filterfieldtype: Config.getHtmlcontorls()["number-input"],
				// 	defaultvalue: "",
				// 	tblsize: Config.getTblgridsizeclasses()["tbl-min-w150"]
				// }
                {
                    field: "status",
                    text: "Status",
                    type : Config.getHtmlcontorls()['text'],
                    freeze: 0,
                    active: 1,
                    sorttable: 0,
                    filter: 1,
                    filterfieldtype: Config.getHtmlcontorls()["dropdown"],
                    formdatafield: "status",
                    masterdataarray: [
                        {
                            label: "Pending",
                            value: 0
                        },
                        {
                            label: "Approved",
                            value: 1
                        },
                        {
                            label: "Rejected",
                            value: 2
                        }
                    ],
                    defaultvalue: "",
                    tblsize: Config.getTblgridsizeclasses()["tbl-min-w150"]
                },
            ]
        }
    }
}
