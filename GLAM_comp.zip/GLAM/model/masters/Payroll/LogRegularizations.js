import mongoose from 'mongoose'
import _Config from '../../../config/Config.js'

export default class LogRegularizations {
    constructor() {
        this._id
        this.personid = { type: mongoose.Schema.Types.ObjectId }
        this.personname = { type: String }
        this.propertyid = {type:mongoose.Schema.Types.ObjectId}
        this.property = {type:String}
        this.reason = { type: String }
        this.reasonid = { type: String }
        this.rejectreason = { type: String }
        this.logdate = { type: Date }
        this.requesttype = { type: Number, default: 0 }
        this.isdeleted = { type: Number, default: 0 }
        this.logid = { type: mongoose.Schema.Types.ObjectId } // _id of device logs 
        this.status = { type: Number, default: 0 } // 0 - pending && 1 - approvel && 2 - rejected
        this.date = { type: String }
        this.approveorrejectpersonid = { type: mongoose.Schema.Types.ObjectId }
        this.approveorrejectperson = { type: String }
        this.approveorrejecttime = { type: Date }
        this.approvals = [
            {
                approverid: { type: mongoose.Schema.Types.ObjectId, ref: 'tblreferencetype' },
                approver: { type: String },
                status: { type: Number, required: [true, 'Status is required'], default: 0 }, //0 - pending , 1 - approved , 2 - rejected
                reason: { type: String }
            }
        ]
        this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: 'recordinfo' },
        this.reportingstatus = { type: Number, default: 0 },
        this.reporttingpersonid = { type: String },
        this.reporttingperson = { type: String },
        this.latereasonid = { type: String }// late reason
        this.latereason = { type: String } // late reason

        this.clockintype = { type: Number }//1 - IN, 2 - OUT

        this.approvalstatus = { type: Number, default: 0 },
        this.approvingpersonid = { type: String },
        this.approvingperson = { type: String },

        this.reviewbyid = { type: String },
        this.reviewby = { type: String }

    }
    getDataName() {
        return "Log Regularization"
    }
    //DOUBT
    getFieldOrder() {
        const Config = new _Config()

        return {
            fields: [
                {
                    'field': 'action_button',
                    'text': '',
                    'type': Config.getHtmlcontorls()['action_button'],
                    'freeze': 1,
                    'active': 1,
                    'sorttable': 0,
                    'filter': 0,
                    'disableflex': 1,
                    'filterfieldtype': Config.getHtmlcontorls()['lookup'],
                    'defaultvalue': '',
                    'tblsize': Config.getTblgridsizeclasses()[10]
                },
                {
                    'field': 'personname',
                    'text': 'Requested Person',
                    'type': 'person-name',
                    'freeze': 1,
                    'active': 1,
                    'sorttable': 1,
                    'filter': 0,
                    'filterfieldtype': Config.getHtmlcontorls()['input-text'],
                    'defaultvalue': '',
                    'tblsize': Config.getTblgridsizeclasses()[40]
                },
                {
                    'field': 'logdate',
                    'text': 'Requested Date',
                    'type': 'date',
                    'freeze': 0,
                    'active': 1,
                    'sorttable': 1,
                    'filter': 0,
                    'filterfieldtype': Config.getHtmlcontorls()['datepicker'],
                    'defaultvalue': '',
                    'tblsize': Config.getTblgridsizeclasses()[25]
                },
                {
                    'field': 'logdate',
                    'text': 'Requested Time Log',
                    'type': 'time',
                    'freeze': 0,
                    'active': 1,
                    'sorttable': 1,
                    'filter': 0,
                    'filterfieldtype': Config.getHtmlcontorls()['timepicker'],
                    'defaultvalue': '',
                    'tblsize': Config.getTblgridsizeclasses()[25]
                },
                // {
                //     "field": "personname",
                //     "text": "Person",
                //     "type": "text",
                //     "freeze": 0,
                //     "active": 1,
                //     "sorttable": 1,
                //     "sortby": "person",
                //     "filter": 1,
                //     "formdatafield": "personname",
                //     "filterfield": "personid",
                //     "masterdata": "gatekeeper",
                //     "masterdatafield": "personname",
                //     "filterfieldtype": "dropdown",
                //     "defaultvalue": "",
                //     "tblsize": 34
                // },
                {
                    "field": "fromdate",
                    "text": "From Date & Time",
                    "type": "datetimepicker",
                    "freeze": 0,
                    "active": 0,
                    "sorttable": 1,
                    "sortby": "fromdate",
                    "filter": 1,
                    "filterfield": "fromdate",
                    "filterfieldtype": "datetimepicker",
                    "isonlyfilter": 1,
                    "defaultvalue": "",
                    "tblsize": 28
                },
                {
                    "field": "todate",
                    "text": "To Date & Time",
                    "type": "datetimepicker",
                    "freeze": 0,
                    "active": 0,
                    "sorttable": 1,
                    "sortby": "todate",
                    "filter": 1,
                    "filterfield": "todate",
                    "filterfieldtype": "datetimepicker",
                    "isonlyfilter": 1,
                    "defaultvalue": "",
                    "tblsize": 28
                },
                {
                    'field': 'status',
                    'text': 'Status',
                    'type': 'status',
                    'freeze': 0,
                    'active': 1,
                    'sorttable': 1,
                    'filter': 0,
                    'filterfieldtype': Config.getHtmlcontorls()['input-text'],
                    'defaultvalue': '',
                    'tblsize': Config.getTblgridsizeclasses()[25]
                },
                // {
                //     'field': 'requesttype',
                //     'text': 'Request Type',
                //     'type': 'requesttype',
                //     'freeze': 0,
                //     'active': 1,
                //     'sorttable': 1,
                //     'filter': 0,
                //     'filterfieldtype': Config.getHtmlcontorls()['input-text'],
                //     'defaultvalue': '',
                //     'tblsize': Config.getTblgridsizeclasses()[20]
                // },
                {
                    'field': 'reason',
                    'text': 'Reason',
                    'type': Config.getHtmlcontorls()['text'],
                    'freeze': 0,
                    'active': 1,
                    'sorttable': 1,
                    'filter': 0,
                    'filterfieldtype': Config.getHtmlcontorls()['modal-eye'],
                    'defaultvalue': '',
                    'tblsize': Config.getTblgridsizeclasses()[60]
                },
            ]
        }
    }


    getrejctFieldOrder() {
        const Config = new _Config()

        return {
            fields: [
                {
                    'field': 'personname',
                    'text': 'Requested Person',
                    'type': Config.getHtmlcontorls()['text'],
                    'freeze': 0,
                    'active': 1,
                    'sorttable': 1,
                    'filter': 1,
                    'filterfieldtype': Config.getHtmlcontorls()['input-text'],
                    'defaultvalue': '',
                    'tblsize': Config.getTblgridsizeclasses()['tbl-min-w200']
                },
                {
                    'field': 'logdate',
                    'text': 'Requested Date',
                    'type': Config.getHtmlcontorls()['text'],
                    'freeze': 0,
                    'active': 1,
                    'sorttable': 1,
                    'filter': 0,
                    'filterfieldtype': Config.getHtmlcontorls()['datepicker'],
                    'defaultvalue': '',
                    'tblsize': Config.getTblgridsizeclasses()['tbl-min-w200']
                },
                {
                    'field': 'requestedtimelog',
                    'text': 'Requested Time Log',
                    'type': Config.getHtmlcontorls()['text'],
                    'freeze': 0,
                    'active': 1,
                    'sorttable': 1,
                    'filter': 0,
                    'filterfieldtype': Config.getHtmlcontorls()['timepicker'],
                    'defaultvalue': '',
                    'tblsize': Config.getTblgridsizeclasses()['tbl-min-w200']
                },
                // {
                //     'field' : 'reportingstatus',
                //     'text' : 'Reporting Status',
                //     'type' : Config.getHtmlcontorls()['text'],
                //     'freeze' : 0,
                //     'active' : 1,
                //     'sorttable' : 1,
                //     'filter' : 0,
                //     'filterfieldtype' : Config.getHtmlcontorls()['input-text'],
                //     'defaultvalue' : '',
                //     'tblsize' : Config.getTblgridsizeclasses()['tbl-min-w200']
                // },
                {
                    'field': 'status',
                    'text': 'Status',
                    'type': Config.getHtmlcontorls()['text'],
                    'freeze': 0,
                    'active': 1,
                    'sorttable': 1,
                    'filter': 0,
                    'filterfieldtype': Config.getHtmlcontorls()['input-text'],
                    'defaultvalue': '',
                    'tblsize': Config.getTblgridsizeclasses()['tbl-min-w200']
                },
                {
                    'field': 'reason',
                    'text': 'Reason',
                    'type': Config.getHtmlcontorls()['text'],
                    'freeze': 0,
                    'active': 1,
                    'sorttable': 0,
                    'filter': 0,
                    'filterfieldtype': Config.getHtmlcontorls()['input-text'],
                    'defaultvalue': '',
                    'tblsize': Config.getTblgridsizeclasses()['tbl-min-w150']
                },
                // {
                //     'field' : 'approvalstatus',
                //     'text' : 'Approval Status',
                //     'type' : Config.getHtmlcontorls()['text'],
                //     'freeze' : 0,
                //     'active' : 1,
                //     'sorttable' : 1,
                //     'filter' : 0,
                //     'filterfieldtype' : Config.getHtmlcontorls()['input-text'],
                //     'defaultvalue' : '',
                //     'tblsize' : Config.getTblgridsizeclasses()['tbl-min-w200']
                // },
                // {
                //     'field' : 'rejectreason',
                //     'text' : 'Reject Reason',
                //     'type' : Config.getHtmlcontorls()['text'],
                //     'freeze' : 0,
                //     'active' : 1,
                //     'sorttable' : 0,
                //     'filter' : 0,
                //     'filterfieldtype' : Config.getHtmlcontorls()['input-text'],
                //     'defaultvalue' : '',
                //     'tblsize' : Config.getTblgridsizeclasses()['tbl-min-w150']
                // },               
            ]
        }
    }

}