import mongoose from 'mongoose'
import { Config } from '../../config/Init.js'

export default class ParkingZone {
    constructor() {
        this._id
        this.parkingzone = { type: String, required: true,  trim: true,index: { unique: true, collation: { locale: 'en', strength: 1 }}}
        this.isactive = { type: Number, required: true, default: 1 } // 1 - active, 0 - deactive
        this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: 'recordinfo' }
    }

    getDataName() {
        return "Parking Zone"
    }

    getFieldOrder() {
        return {
            fields: [
                {
                    'field': 'action_button',
                    'text': '',
                    'type': Config.getHtmlcontorls()['action_button'],
                    'freeze': 1,  
                    'active': 1,
                    'sorttable': 0,
                    'filter': 0,
                    'disableflex': 1,
                    'filterfieldtype': Config.getHtmlcontorls()['lookup'],
                    'defaultvalue': '',
                    'tblsize': 10
                },
                {
                    'field': 'isactive',
                    'text': 'Status',
                    'type': Config.getHtmlcontorls()['isactive'],
                    'freeze': 1,
                    'active': 1,
                    'sorttable': 0,
                    'filter': 0,
                    'disableflex': 1,
                    'filterfieldtype': Config.getHtmlcontorls()['lookup'],
                    'defaultvalue': '',
                    'tblsize': 10
                },
                {
                    'field': 'parking Zone',
                    'text': 'parkingzone',
                    'type': Config.getHtmlcontorls()['text'],
                    'freeze': 1,
                    'active': 1,
                    'sorttable': 1,
                    'sortby': 'parkingzone',
                    'filter': 0,
                    'filterfieldtype': Config.getHtmlcontorls()['lookup'],
                    'defaultvalue': '',
                    'tblsize': 10
                }
            ]
        }
    }

    getFormFieldOrder(){
          return {
            "rightsidebarsize": Config.getModalsizeclasses()['xs'],
            "pagename": 'designation',
            "formname": 'Designation',
            "alias": 'designation',
            "dataview": "tab",
            'formfields': [
              {
                "tab": "Designation",
                "formFields": [
                  {
                    'field': 'designation',
                    'text': 'Designation Name',
                    'type': Config.getHtmlcontorls()['kInputText'],
                    'disabled': false,
                    'defaultvisibility': true,
                    'required': true,
                    'gridsize': Config.getFieldSize()['k375'],
                  },
                  {
                    'field': 'isactive',
                    'text': 'Status',
                    'type': Config.getHtmlcontorls()['kDropDown'],
                    'disabled': false,
                    'defaultvisibility': true,
                    'required': true,
                    'gridsize': Config.getFieldSize()['k375'],
                    'masterdata': 'status',
                    'masterdataarray': Config.getStatustype(),
                    'defaultvalue': 1,
                    'formdatafield': 'status',
                    'cleanable': true,
                    'searchable': true,
                    'onchangedata': ['statusid'],
                    'masterdatadependancy': false,
                  },
                ]
              }
            ],
          }
    }
}

