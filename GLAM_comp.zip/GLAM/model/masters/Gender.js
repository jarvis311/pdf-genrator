import _Config from "../../config/Config.js"

export default class Gender {
    constructor() {
        this._id
        this.gender = { type: String, trim: true }
    }
}
