import mongoose from "mongoose"
import _Config from "../../../config/Config.js"
const Config = new _Config()

export default class Userrole {
  constructor() {
    this._id
    this.userrole = { type: String, required: true, unique: true, trim: true }
    this.alias = { type: String, required: true, unique: true, trim: true }
    // this.categoryid = { type: mongoose.Schema.Types.ObjectId, ref: 'tblcategorymaster' }
    // this.category = { type: String, required: true }
    this.hasmiddlelayerweblogin = { type: Number, default: 0 }
    this.hasmiddlelayerapplogin = { type: Number, default: 0 }
    this.hasemployeewevlogin = { type: Number, default: 0 }
    this.hasemployeeapplogin = { type: Number, default: 0 }
    this.hasgatekeeperweblogin = { type: Number, default: 0 }
    this.hasgatekeeperapplogin = { type: Number, default: 0 }
    this.isactive = { type: Number, required: false, default: 1 }
    this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: "recordinfo" }
  }

  getIndexes() {
    return [{ userrole: 1, alias: 1 }]
  }

  getFieldOrder() {
    return {
      fields: [
        {
          'field': 'action_button',
          'text': '',
          'type': Config.getHtmlcontorls()['action_button'],
          'freeze': 1,
          'active': 1,
          'sorttable': 0,
          'filter': 0,
          'disableflex': 1,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': 7
        },
        {
          'field': 'userrole',
          'text': 'Name',
          'type': Config.getHtmlcontorls()['text'],
          'freeze': 1,
          'active': 1,
          'sorttable': 1,
          'sortby': 'userrole',
          'filter': 0,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': 35
        },
        // {
        //   'field': 'category',
        //   'text': 'Category Name',
        //   'type': Config.getHtmlcontorls()['text'],
        //   'freeze': 1,
        //   'active': 1,
        //   'sorttable': 1,
        //   'sortby': 'category',
        //   'filter': 0,
        //   'filterfieldtype': Config.getHtmlcontorls()['lookup'],
        //   'defaultvalue': '',
        //   'tblsize': 35
        // },
        {
          'field': 'hasmiddlelayerapplogin',
          'text': 'Has Middle Layer App Login',
          'type': Config.getHtmlcontorls()['switch'],
          'freeze': 1,
          'active': 1,
          'sorttable': 0,
          'filter': 0,
          'filterfieldtype': Config.getHtmlcontorls()['checkbox'],
          'defaultvalue': 0,
          'tblsize': 30
        },
        {
          'field': 'hasemployeewevlogin',
          'text': 'Has Employee Web Login',
          'type': Config.getHtmlcontorls()['switch'],
          'freeze': 1,
          'active': 1,
          'sorttable': 0,
          'filter': 0,
          'filterfieldtype': Config.getHtmlcontorls()['checkbox'],
          'defaultvalue': 0,
          'tblsize': 30
        },
        {
          'field': 'hasemployeeapplogin',
          'text': 'Has Employee App Login',
          'type': Config.getHtmlcontorls()['switch'],
          'freeze': 1,
          'active': 1,
          'sorttable': 0,
          'filter': 0,
          'filterfieldtype': Config.getHtmlcontorls()['checkbox'],
          'defaultvalue': 0,
          'tblsize': 30
        },
        {
          'field': 'hasgatekeeperweblogin',
          'text': 'Has Gatekeeper Web Login',
          'type': Config.getHtmlcontorls()['switch'],
          'freeze': 1,
          'active': 1,
          'sorttable': 0,
          'filter': 0,
          'filterfieldtype': Config.getHtmlcontorls()['checkbox'],
          'defaultvalue': 0,
          'tblsize': 30
        },
        {
          'field': 'hasgatekeeperapplogin',
          'text': 'Has Gatekeeper App Login',
          'type': Config.getHtmlcontorls()['switch'],
          'freeze': 1,
          'active': 1,
          'sorttable': 0,
          'filter': 0,
          'filterfieldtype': Config.getHtmlcontorls()['checkbox'],
          'defaultvalue': 0,
          'tblsize': 30
        },

      ]
    }
  }

  getFormFieldOrder() {
    return {
      "rightsidebarsize": Config.getModalsizeclasses()['xs'],
      "pagename": 'userrole',
      "formname": 'Userrole',
      "alias": 'userrole',
      "dataview": "tab",
      'formfields': [
        {
          "tab": "Userrole",
          "formFields": [
            {
              'field': 'userrole',
              'text': 'Userrole',
              'type': Config.getHtmlcontorls()['kInputText'],
              'disabled': false,
              'defaultvisibility': true,
              'required': true,
              'gridsize': Config.getFieldSize()['k375'],
            },
            // {
            //   "field": "categoryid",
            //   "text": "Category",
            //   "type": "dropdown",
            //   "disabled": false,
            //   "defaultvisibility": true,
            //   "required": true,
            //   "gridsize": 375,
            //   "masterdata": "category",
            //   "masterdatafield": "name",
            //   "formdatafield": "category",
            //   "cleanable": true,
            //   "searchable": true,
            //   "masterdatadependancy": false,
            //   "staticfilter": { "isactive": 1, "isservice": 1 }
            // },
            {
              'field': 'isactive',
              'text': 'Status',
              'type': Config.getHtmlcontorls()['kDropDown'],
              'disabled': false,
              'defaultvisibility': true,
              'required': true,
              'gridsize': Config.getFieldSize()['k375'],
              'masterdata': 'isactive',
              'masterdataarray': Config.getStatustype(),
              'defaultvalue': 1,
              'formdatafield': 'isactive',
              'cleanable': true,
              'searchable': true,
              'masterdatadependancy': false,
            },
            {
              'field': 'hasmiddlelayerweblogin',
              'text': 'Has Middle Layer Web Login',
              'type': Config.getHtmlcontorls()['kCheckBox'],
              'disabled': false,
              'required': false,
              'defaultvisibility': true,
              'gridsize': Config.getFieldSize()['k375'],
            },
            {
              'field': 'hasmiddlelayerapplogin',
              'text': 'Has Middle Layer App Login',
              'type': Config.getHtmlcontorls()['kCheckBox'],
              'disabled': false,
              'required': false,
              'defaultvisibility': true,
              'gridsize': Config.getFieldSize()['k375'],
            },
            {
              'field': 'hasemployeewevlogin',
              'text': 'Has Employee Web Login',
              'type': Config.getHtmlcontorls()['kCheckBox'],
              'disabled': false,
              'required': false,
              'defaultvisibility': true,
              'gridsize': Config.getFieldSize()['k375'],
            },
            {
              'field': 'hasemployeeapplogin',
              'text': 'Has Employee App Login',
              'type': Config.getHtmlcontorls()['kCheckBox'],
              'disabled': false,
              'required': false,
              'defaultvisibility': true,
              'gridsize': Config.getFieldSize()['k375'],
            },
            {
              'field': 'hasgatekeeperweblogin',
              'text': 'Has Gatekeeper Web Login',
              'type': Config.getHtmlcontorls()['kCheckBox'],
              'disabled': false,
              'required': false,
              'defaultvisibility': true,
              'gridsize': Config.getFieldSize()['k375'],
            },
            {
              'field': 'hasgatekeeperapplogin',
              'text': 'Has Gatekeeper App Login',
              'type': Config.getHtmlcontorls()['kCheckBox'],
              'disabled': false,
              'required': false,
              'defaultvisibility': true,
              'gridsize': Config.getFieldSize()['k375'],
            },

          ]
        }
      ]
    };
  }
}
