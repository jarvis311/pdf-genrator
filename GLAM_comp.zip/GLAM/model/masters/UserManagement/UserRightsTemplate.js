import { Config } from "../../../config/Init.js"
import mongoose from "mongoose"

export default class UserRightsTemplate {
	constructor() {
		this._id
		this.templatename = { type: String, required: true }
        // this.propertyid = { type: mongoose.Schema.Types.ObjectId, ref: "tblproperty" }
        // this.property = { type: String, trim: true }
		this.moduletypeid = { type: mongoose.Schema.Types.ObjectId, ref: "tblmoduletype" }
		this.moduletype = { type: String }
        this.userrights = [
            {
				formname: { type: String },
				alias: { type: String },
                moduleid: { type: mongoose.Schema.Types.ObjectId, ref: "tblmodulemaster" },
                allviewright: { type: Number, default: 0 },
                selfviewright: { type: Number, default: 0 },
                alladdright: { type: Number, default: 0 },
                selfaddright: { type: Number, default: 0 },
                alleditright: { type: Number, default: 0 },
                selfeditright: { type: Number, default: 0 },
                alldelright: { type: Number, default: 0 },
                selfdelright: { type: Number, default: 0 },
				moduletypeid: { type: mongoose.Schema.Types.ObjectId, ref: "tblmoduletype" },
				propertyid: { type: mongoose.Schema.Types.ObjectId, ref: "tblbranchmaster" },
				personid: { type: String, default: "" },
				userroleid: { type: String, default: "" }
            }
        ]
		this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: "recordinfo" }
	}

    getIndexes() {
        return [[{ moduletypeid: 1, templatename: 1 },{ unique: 1 }]]
    }

    getFieldOrder() {
		return {
			fields: [
				{
					field: "templatename",
					text: "Template Name",
					type: Config.getHtmlcontorls()['text'],
					freeze: 1,
					active: 1,
					sorttable: 1,
					filter: 1,
					filterfieldtype: Config.getHtmlcontorls()["lookup"],
					defaultvalue: "",
					tblsize: 10
				},
				{
					field: "moduletype",
					text: "Module Name",
					type: Config.getHtmlcontorls()['text'],
					freeze: 0,
					active: 1,
					sorttable: 1,
					filter: 1,
					filterfieldtype: Config.getHtmlcontorls()["lookup"],
					defaultvalue: "",
					tblsize: 10
				},
				{
                    field: "userrights",
                    text: "User Rights",
                    type: Config.getHtmlcontorls()["modal-eye"],
                    freeze: 0,
                    active: 1,
                    sorttable: 0,
                    filter: 0,
                    filterfieldtype: Config.getHtmlcontorls()["lookup"],
                    defaultvalue: "",
                    tblsize: 10
                },
			]
		}
	}

	getRightsOrder() {
		return {
			fields: [
				{
					field: "formname",
					text: "Page Name",
					type: Config.getHtmlcontorls()["text"]
				},
				{
					field: "viewright",
					text: "Can View",
					type: Config.getHtmlcontorls()["text"],
					htmlcontrols: [
						{
							field: "allviewright",
							text: "All",
							type: Config.getHtmlcontorls()["checkbox"]
						},
						{
							field: "selfviewright",
							text: "Self",
							type: Config.getHtmlcontorls()["checkbox"]
						}
					]
				},
				{
					field: "addright",
					text: "Can Add",
					type: Config.getHtmlcontorls()["text"],
					htmlcontrols: [
						{
							field: "alladdright",
							text: "All",
							type: Config.getHtmlcontorls()["checkbox"]
						},
						{
							field: "selfaddright",
							text: "Self",
							type: Config.getHtmlcontorls()["checkbox"]
						}
					]
				},
				{
					field: "editright",
					text: "Can Update",
					type: Config.getHtmlcontorls()["text"],
					htmlcontrols: [
						{
							field: "alleditright",
							text: "All",
							type: Config.getHtmlcontorls()["checkbox"]
						},
						{
							field: "selfeditright",
							text: "Self",
							type: Config.getHtmlcontorls()["checkbox"]
						}
					]
				},
				{
					field: "delright",
					text: "Can Delete",
					type: Config.getHtmlcontorls()["text"],
					htmlcontrols: [
						{
							field: "alldelright",
							text: "All",
							type: Config.getHtmlcontorls()["checkbox"]
						},
						{
							field: "selfdelright",
							text: "Self",
							type: Config.getHtmlcontorls()["checkbox"]
						}
					]
				}
			]
		}
	}
}
