import mongoose from "mongoose"
import _Config from "../../../config/Config.js"

export default class UserRoleHierarchy {
    constructor() {
        this._id
        this.propertyid = { type: mongoose.Schema.Types.ObjectId, ref: "tblbranchmaster" }
        this.userrolehierarchy = {}
        this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: "recordinfo" }
    }
}
