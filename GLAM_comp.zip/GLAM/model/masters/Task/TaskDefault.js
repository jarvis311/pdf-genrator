import mongoose from "mongoose"
import _Config from "../../../config/Config.js"
import { Config, FieldConfig } from "../../../config/Init.js"

export default class TaskDefault {
    constructor() {
        this._id
        this.categoryid = { type: mongoose.Schema.Types.ObjectId}
        this.category = { type: String, required: true, trim: true }
        this.propertyid = { type:mongoose.Schema.Types.ObjectId,ref:"tblpropertymaster"}
        this.property = { type:String,trim:true}
        this.recurrencetypeid = { type: mongoose.Schema.Types.ObjectId, ref: "tblrecurrencetypemaster", default: Config.dummyObjid }
        this.recurrencetype = { type: String, required: true, trim: true }
        this.selecteddays = {type:Array}
        this.selecteddates = {type:Array}
        this.dates = {type:Array}
        this.startdate = { type: Date, trim: true }
        this.enddate = { type: Date, trim: true }
        this.title = { type: String, trim: true, default: "" }
        this.description = { type: String, trim: true, default: "" }      
        this.assignperson = [
            {
                assignpersonid: { type: mongoose.Schema.Types.ObjectId},
                assignperson: { type: String, trim: true }
            }
        ]
        this.comment = { type: String, trim: true, default: "" }
        this.checklistid = { type: mongoose.Schema.Types.ObjectId , ref:"tblchecklistmaster"},
        this.checklist = { type: String,trim:true}
        this.assignbypersonid = { type: mongoose.Schema.Types.ObjectId, ref: "tblpersonmaster", default: Config.dummyObjid }
        this.assignbyperson = { type: String, trim: true, default: "" }
        this.serialnumber = { type: String, trim: true, default: "" }
        this.assetid = { type: mongoose.Schema.Types.ObjectId },
        this.asset = { type: String , trim:true}
        this.taskactions = [
            {
                taskactionid: { type: mongoose.Schema.Types.ObjectId, ref: "" },
                taskaction: { type: String, trim: true }
            }
        ]
        this.tasktime = { type: Date, trim: true }
        this.taskprogresstime = { type: Number, trim: true, default: 0 }
        this.everynoofoccurrence = { type: Number, default: 0 } // Number of Days, Months, Years
        this.lastscheduledate = { type: Date, default: null } // Last schedule script run date
        this.distributetask = { type: Number, default: 0 } // person wise distribute task
        this.autocomplete = { type: Number, default: 0 }
        this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: "recordinfo" }
    }

    // getIndexes() {
    //     return [{ categoryid: 1, propertyid: 1, buildingid: 1, wingid: 1, assignpersonid: 1 }]
    // }
    getDataName() {
        return "Task Schedule"
    }

    getFieldOrder() {
        return {
          fields: [
            {
              'field': 'action_button',
              'text': '',
              'type': Config.getHtmlcontorls()['action_button'],
              'freeze': 1,
              'active': 1,
              'sorttable': 0,
              'filter': 0,
              'disableflex': 1,
              'filterfieldtype': Config.getHtmlcontorls()['lookup'],
              'defaultvalue': '',
              'tblsize': 7
            },
            {
              'field': 'title',
              'text': 'Name',
              'type': Config.getHtmlcontorls()['text'],
              'freeze': 1,
              'active': 1,
              'sorttable': 1,
              'sortby': 'title',
              'filter': 0,
              'filterfieldtype': Config.getHtmlcontorls()['lookup'],
              'defaultvalue': '',
              'tblsize': 20
            },
            {
              'field': 'category',
              'text': 'Task Type',
              'type': Config.getHtmlcontorls()['text'],
              'freeze': 1,
              'active': 1,
              'sorttable': 1,
              'sortby': 'title',
              'filter': 0,
              'filterfieldtype': Config.getHtmlcontorls()['lookup'],
              'defaultvalue': '',
              'tblsize': 20
            },
            {
              'field': 'recurrencetype',
              'text': 'Recurrence Type',
              'type': Config.getHtmlcontorls()['text'],
              'freeze': 1,
              'active': 1,
              'sorttable': 1,
              'sortby': 'title',
              'filter': 0,
              'filterfieldtype': Config.getHtmlcontorls()['lookup'],
              'defaultvalue': '',
              'tblsize': 20
            },
            {
              'field': 'startdate',
              'text': 'Start Type',
              'type': Config.getHtmlcontorls()['text'],
              'freeze': 1,
              'active': 1,
              'sorttable': 1,
              'sortby': 'title',
              'filter': 0,
              'filterfieldtype': Config.getHtmlcontorls()['lookup'],
              'defaultvalue': '',
              'tblsize': 20
            },
            {
              'field': 'enddate',
              'text': 'End Type',
              'type': Config.getHtmlcontorls()['text'],
              'freeze': 1,
              'active': 1,
              'sorttable': 1,
              'sortby': 'title',
              'filter': 0,
              'filterfieldtype': Config.getHtmlcontorls()['lookup'],
              'defaultvalue': '',
              'tblsize': 20
            },
            
            {
              'field': 'asset',
              'text': 'Asset',
              'type': Config.getHtmlcontorls()['text'],
              'freeze': 1,
              'active': 1,
              'sorttable': 1,
              'sortby': 'title',
              'filter': 0,
              'filterfieldtype': Config.getHtmlcontorls()['lookup'],
              'defaultvalue': '',
              'tblsize': 20
            },
            {
              'field': 'checklist',
              'text': 'Checklist',
              'type': Config.getHtmlcontorls()['text'],
              'freeze': 1,
              'active': 1,
              'sorttable': 1,
              'sortby': 'title',
              'filter': 0,
              'filterfieldtype': Config.getHtmlcontorls()['lookup'],
              'defaultvalue': '',
              'tblsize': 20
            },
            // {
            //   'field': 'category',
            //   'text': 'Category Name',
            //   'type': Config.getHtmlcontorls()['text'],
            //   'freeze': 1,
            //   'active': 1,
            //   'sorttable': 1,
            //   'sortby': 'category',
            //   'filter': 0,
            //   'filterfieldtype': Config.getHtmlcontorls()['lookup'],
            //   'defaultvalue': '',
            //   'tblsize': 20
            // },
            // {
            //   'field': 'hasmiddlelayerapplogin',
            //   'text': 'Has Middle Layer App Login',
            //   'type': Config.getHtmlcontorls()['switch'],
            //   'freeze': 1,
            //   'active': 1,
            //   'sorttable': 0,
            //   'filter': 0,
            //   'filterfieldtype': Config.getHtmlcontorls()['checkbox'],
            //   'defaultvalue': 0,
            //   'tblsize': 30
            // },
            // {
            //   'field': 'hasemployeewevlogin',
            //   'text': 'Has Employee Web Login',
            //   'type': Config.getHtmlcontorls()['switch'],
            //   'freeze': 1,
            //   'active': 1,
            //   'sorttable': 0,
            //   'filter': 0,
            //   'filterfieldtype': Config.getHtmlcontorls()['checkbox'],
            //   'defaultvalue': 0,
            //   'tblsize': 30
            // },
            // {
            //   'field': 'hasemployeeapplogin',
            //   'text': 'Has Employee App Login',
            //   'type': Config.getHtmlcontorls()['switch'],
            //   'freeze': 1,
            //   'active': 1,
            //   'sorttable': 0,
            //   'filter': 0,
            //   'filterfieldtype': Config.getHtmlcontorls()['checkbox'],
            //   'defaultvalue': 0,
            //   'tblsize': 30
            // },
            // {
            //   'field': 'hasgatekeeperweblogin',
            //   'text': 'Has Gatekeeper Web Login',
            //   'type': Config.getHtmlcontorls()['switch'],
            //   'freeze': 1,
            //   'active': 1,
            //   'sorttable': 0,
            //   'filter': 0,
            //   'filterfieldtype': Config.getHtmlcontorls()['checkbox'],
            //   'defaultvalue': 0,
            //   'tblsize': 30
            // },
            // {
            //   'field': 'hasgatekeeperapplogin',
            //   'text': 'Has Gatekeeper App Login',
            //   'type': Config.getHtmlcontorls()['switch'],
            //   'freeze': 1,
            //   'active': 1,
            //   'sorttable': 0,
            //   'filter': 0,
            //   'filterfieldtype': Config.getHtmlcontorls()['checkbox'],
            //   'defaultvalue': 0,
            //   'tblsize': 30
            // },
    
          ]
        }
      }


    getFormFieldOrder() {
        return {
          "rightsidebarsize": 775,
          "pagename": "Task Scheduler",
          "formname": "Task Scheduler",
          "alias": "taskscheduler",
          "dataview": "tab",
          "formfields": [
            {
              "tab": "Task Scheduler",
              "formFields": [
                {
                  "field": "categoryid",
                  "text": "Task Type",
                  "type": 'dropdown',
                  "disabled": false,
                  "defaultvisibility": true,
                  "required": true,
                  "gridsize": 375,
                  "masterdata": "checklisttype",
                  "masterdatafield": "checklisttype",
                  "formdatafield": "category",
                  "cleanable": false,
                  "searchable": true,
                  "staticfilter": {"isactive": 1},
                  'onchangefill': ['checklistid'],
                },
                {
                  "field": "title",
                  "text": "Name",
                  "type": "input-text",
                  "disabled": false,
                  "defaultvisibility": true,
                  "required": true,
                  "gridsize": 375,
                },
                {
                  "field": "recurrencetypeid",
                  "text": "Recurrence Type",
                  "type": "tab",
                  "disabled": false,
                  "defaultvisibility": true,
                  "required": true,
                  "gridsize": 800,
                  "masterdata": "recurrencetype",
                  "masterdatafield": "recurrencetype",
                  "formdatafield": "recurrencetype",
                  "cleanable": true,
                  "searchable": true,
                  "staticfilter": {"isactive": 1}
                },
                {
                  "field": "startdate",
                  "text": "Start Date",
                  "type": "datepicker",
                  "disabled": false,
                  "defaultvisibility": true,
                  "required": true,
                  "defaultvalue": '',
                  "gridsize": 375,
                  'condition': {
                    'recurrencetypeid': ['67567d5050103e80bc2cd456', '67567d4650103e80bc2cd44b', '67567d5650103e80bc2cd461']
                  },
                },
                {
                  "field": "enddate",
                  "text": "End Date",
                  "type": "datepicker",
                  "disabled": false,
                  "defaultvisibility": true,
                  "required": true,
                  "defaultvalue": '',
                  "gridsize": 375,
                  'condition': {
                    'recurrencetypeid': ['67567d5050103e80bc2cd456', '67567d4650103e80bc2cd44b', '67567d5650103e80bc2cd461']
                  },
                },
                {
                  "field": "selecteddays",
                  "text": "Select Days",
                  "type": "weekdaypicker",
                  "disabled": false,
                  "defaultvisibility": true,
                  "required": true,
                  "gridsize": 800,
                  'condition': {
                    'recurrencetypeid': ['67567d5050103e80bc2cd456']
                  },
                },
                {
                  "field": "selecteddates",
                  "text": "Select Dates",
                  "type": "monthdatepicker",
                  "disabled": false,
                  "defaultvisibility": true,
                  "required": true,
                  "gridsize": 800,
                  'condition': {
                    'recurrencetypeid': ['67567d4650103e80bc2cd44b']
                  },
                },
                {
                  "field": "dates",
                  "text": "Select Dates",
                  "type": "multipledatepicker",
                  "disabled": false,
                  "defaultvisibility": true,
                  "required": true,
                  "gridsize": 800,
                  'condition': {
                    'recurrencetypeid': ['67567d3450103e80bc2cd440']
                  },
                },
                {
                  "field": "gatekeeper",
                  "text": "Assigned Personnel",
                  "type": "multipleselectdropdown",
                  "disabled": false,
                  "defaultvisibility": true,
                  "required": true,
                  "gridsize": 375,
                  "masterdata": "gatekeeper",
                  "masterdatafield": "personname",
                  "formdatafield": "gatekeeper",
                  "cleanable": true,
                  "searchable": true,
                  "masterdatadependancy": false,
                  'condition': {
                    'categoryid': ['67567437925dffbf83cd0e23']
                  },
                  "staticfilter": {"isactive": 1}
                },
                {
                  "field": "employee",
                  "text": "Assigned Personnel",
                  "type": "multipleselectdropdown",
                  "disabled": false,
                  "defaultvisibility": true,
                  "required": true,
                  "gridsize": 375,
                  "masterdata": "employee",
                  "masterdatafield": "personname",
                  "formdatafield": "employee",
                  "cleanable": true,
                  "searchable": true,
                  "masterdatadependancy": false,
                  'alternateField': 'assignperson',
                  'condition': {
                    'categoryid': ["6756741d925dffbf83cd0e18"]
                  },
                  "staticfilter": {"isactive": 1}
                },
                {
                  "field": "assetid",
                  "text": "Assets",
                  "type": 'dropdown',
                  "disabled": false,
                  "defaultvisibility": true,
                  "required": true,
                  "gridsize": 375,
                  "masterdata": "assets",
                  "masterdatafield": "assetname",
                  "formdatafield": "asset",
                  "cleanable": false,
                  "searchable": true,
                  'condition': {
                    'categoryid': ["6756741d925dffbf83cd0e18"]
                  },
                  // "staticfilter": {"isactive": 1}
                },
                {
                  "field": "checklistid",
                  "text": "Checklist",
                  "type": 'dropdown',
                  "disabled": false,
                  "defaultvisibility": true,
                  "required": true,
                  "gridsize": 375,
                  "masterdata": "checklist",
                  "masterdatafield": "checklist",
                  "formdatafield": "checklist",
                  "cleanable": false,
                  "searchable": true,
                  'dependentfilter': {
                    'checklisttypeid': 'categoryid',
                  },
                  // 'condition': {
                  //   'categoryid': ["6756741d925dffbf83cd0e18"]
                  // },
                  "staticfilter": {"isactive": 1}
                },
                {
                  "field": "comment",
                  "text": "Description",
                  "height": 400,
                  "gridsize": 800,
                  "type": "input-textarea",
                  "disabled": false,
                  "defaultvisibility": true,
                  "required": false,
                },
              ]
            },
          ]
        }
      }
}
