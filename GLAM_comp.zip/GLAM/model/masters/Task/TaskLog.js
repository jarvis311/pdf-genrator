import mongoose from "mongoose"
import _Config from "../../../config/Config.js"

export default class TaskLog {
    constructor() {
        this._id
        this.taskid = { type: mongoose.Schema.Types.ObjectId, ref: "tbltaskassign" }

        this.userid = { type: mongoose.Schema.Types.ObjectId, ref: "tblpersonmaster" }
        this.username = { type: String, trim: true }

        this.datetime = { type: Date }
        this.actionid = { type: mongoose.Schema.Types.ObjectId, ref: "" }
        this.action_name = { type: String, trim: true }

        this.taskstatusid = { type: mongoose.Schema.Types.ObjectId, ref: "tbltaskstatusmaster" }
        this.taskstatustype = { type: String, trim: true }
        this.taskstatus = { type: String, trim: true }

        this.comment = { type: String, trim: true }
        this.commentlog = { type: Number, default: 0 }
        this.hkcomments = { type: String, trim: true }
        this.logtype = { type: Number, required: true } //1=>Taskstatus, 2=>TaskAction, 3=>ProductPart, 4=>ReplacePart, 5=> logbook, 6=> Task Transfer Log, 7=> task transfer log, 8 => Swap Product, 9 => Transfer product
        this.logtypefilter = { type: Number, required: true } //logtype=> 3 || 4: [1=>AddPart, 2=>RequestPart, 3=>DeletePart, 4=>VerifyPart]
        this.tasktime = { type: Number, default : 0} // only if logtype == 6
        this.tasktransferfrompersonid = { type: mongoose.Schema.Types.ObjectId, ref : "tblpersonmaster"}
        this.tasktransferfromperson = { type : String, trim : true }
        this.tasktransfertopersonid = { type: mongoose.Schema.Types.ObjectId, ref : "tblpersonmaster"}
        this.tasktransfertoperson = { type : String, trim : true }
        this.tasktransferreason  = { type : String, default : ""}
        this.imageslog = [  
            {
                image: { type: String, trim: true }
            }
        ]
        this.svg = { type: String, trim: true }
        this.flag = { type: Number, trim: true }
        this.products = [{
                productid: { type: mongoose.Schema.Types.ObjectId, ref: "tblproductmaster" },
                product: { type: String, trim: true }
            }
        ]
        this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: "recordinfo" }
        this.actualdatetime = { type : Date, default : null}
    }

    getIndexes(){
        return [{taskid : 1}]  
    }

    getFieldOrder() {
        const Config = new _Config()
        return {
            fields: []
        }
    }
}
