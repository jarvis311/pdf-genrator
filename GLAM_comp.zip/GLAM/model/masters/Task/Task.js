import mongoose from "mongoose"
import _Config from "../../../config/Config.js"
import { Config } from "../../../config/Init.js"

export default class Task {
  constructor() {
    this._id
    this.taskdefaultid = { type: mongoose.Schema.Types.ObjectId, ref: "tbltaskschedular", default: Config.dummyObjid }
    this.seriesid = { type: mongoose.Schema.Types.ObjectId, ref: "tblseriesmaster" }
    this.maxid = { type: Number }
    this.taskcode = { type: String, trim: true }
    this.categoryid = { type: mongoose.Schema.Types.ObjectId, ref: "tbltaskcategory" }
    this.category = { type: String, required: true, trim: true }
    this.recurrencetypeid = { type: mongoose.Schema.Types.ObjectId, ref: "tblrecurrencetypemaster", default: Config.dummyObjid }
    this.recurrencetype = { type: String, required: true, trim: true }
    this.days = [
      {
        _id: { type: mongoose.Schema.Types.ObjectId, ref: "tblday" },
        name: { type: String, trim: true }
      }
    ]
    this.expirydate = { type: Date, trim: true, default: null }
    this.title = { type: String, trim: true, default: "" }
    this.description = { type: String, trim: true, default: "" }
    this.assignpersons = [
      {
        assignpersonid: { type: mongoose.Schema.Types.ObjectId },
        assignperson: { type: String, trim: true }
      }
    ]
    this.assignpersonid = { type: mongoose.Schema.Types.ObjectId, default: Config.dummyObjid }
    this.assignperson = { type: String, trim: true, default: "" }
    this.assignbypersonid = { type: mongoose.Schema.Types.ObjectId, default: Config.dummyObjid }
    this.assignbyperson = { type: String, trim: true, default: "" }
    this.propertyid = { type: mongoose.Schema.Types.ObjectId, ref: "tblpropertymaster", required: true }
    this.property = { type: String, trim: true, required: true }
    this.serialnumber = { type: String, trim: true, default: "" }
    this.startdate = { type: Date, trim: true }
    this.enddate = { type: Date, trim: true }
    this.taskcompleteddate = { type: Date, trim: true, default: null }
    this.assigneetask_completeddate = { type: Date, trim: true, default: null }
    this.taskcompletedsystemdate = { type: Date, trim: true, default: null }
    this.revisittime = { type: Date, trim: true, default: null }
    this.taskstatusid = { type: mongoose.Schema.Types.ObjectId, ref: "tbltaskstatusmaster" }
    this.taskstatus = { type: String, trim: true }
    this.taskstatuscolor = { type: String, trim: true }
    this.taskstatustype = { type: String, trim: true }
    this.taskstatuslog = [
      {
        taskstatusid: { type: mongoose.Schema.Types.ObjectId, ref: "tbltaskstatusmaster" },
        taskstatus: { type: String, trim: true },
        taskstatustype: { type: String, trim: true },
        taskstatuslogtime: { type: Number, trim: true }
      }
    ]
    this.assetcategoryid = { type: mongoose.Schema.Types.ObjectId, ref: "tblassetcategory" }
    this.assetcategory = { type: String, trim: true }
    this.isimagerequired = { type: Number, trim: true, default: 0 }
    this.checklists = [
      {
        question: { type: String, required: true, trim: true },
        ismandatory: { type: Number, default: 0 },
        iscompleted: { type: Number, default: 0 },
        personid: { type: mongoose.Schema.Types.ObjectId },
        person:{type:String},
        logdate: { type: Date },
      }
    ]
    this.log = [
      {
        statusid: { type: mongoose.Schema.Types.ObjectId, ref: 'tbltaskstatusmaster' },
        status: { type: String },
        backgroundcolor: { type: String, default: "#ab056e" },
        personid: { type: mongoose.Schema.Types.ObjectId },
        person: { type: String },
        logdatetime: { type: Date },
        logtype: { type: Number },
        message: { type: String }
      }
    ]
    this.checklistid = { type: mongoose.Schema.Types.ObjectId, ref: "tblchecklist" },
    this.checklist = { type: String, trim: true },
    this.tasktime = { type: Date, trim: true } // Last event time like[start, pause, complete action etc... time ]
    this.isnewrequest = { type: Number, trim: true, default: 1 }
    this.iscompleted = { type: Number, default: 0 } // Completed Task
    this.isrejected = { type: Number, default: 0 } // 1 => rejected 
    this.isreleased = { type: Number, default: 0 } // 1 => released 
    this.taskprogresstime = { type: Number, trim: true, default: 0 }
    this.lasttaskstarttime = { type: Date, trim: true, default: null }
    this.taskstartdatetime = { type: Date, trim: true, default: null }
    this.taskstarttime = { type: Date, trim: true, default: null }
    this.isstarttimer = { type: Number, trim: true, default: 0 }
    this.everynoofoccurrence = { type: Number, default: 0 } // Number of Days, Months, Years
    this.occurrencetype = { type: String, trim: true, default: "" }
    this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: "recordinfo" }
  }


  // getIndexes(){ 
  //     return [
  //         { propertyid: 1, categoryid: 1, assignmentforid: 1, roomnoid: 1, reservationid: 1 },
  //         { propertyid: 1, roomnoid: 1, buildingid: 1, wigid: 1 },
  //         { startdate: 1, taskactions: 1, roomnoid: 1 },
  //         { categoryid: 1, propertyid: 1, assignmentforid: 1, assignpersonid: 1, iscompleted: 1, verifypersonid: 1, isinspected: 1 },
  //     ]
  // }

  getFieldOrder() {
    return {
      fields: [
        {
          'field': 'action_button',
          'text': '',
          'type': Config.getHtmlcontorls()['action_button'],
          'freeze': 1,
          'active': 1,
          'sorttable': 0,
          'filter': 0,
          'disableflex': 1,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': 7
        },
        {
          'field': 'taskcode',
          'text': 'Task Code',
          'type': Config.getHtmlcontorls()['text'],
          'freeze': 1,
          'active': 1,
          'sorttable': 1,
          'sortby': 'taskcode',
          'filter': 0,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': 20
        },
        {
          'field': 'title',
          'text': 'Name',
          'type': Config.getHtmlcontorls()['text'],
          'freeze': 1,
          'active': 1,
          'sorttable': 1,
          'sortby': 'title',
          'filter': 0,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': 20
        },
        {
          'field': 'description',
          'text': 'description',
          'type': Config.getHtmlcontorls()['text'],
          'freeze': 1,
          'active': 1,
          'sorttable': 1,
          'sortby': 'title',
          'filter': 0,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': 20
        },

        {
          'field': 'startdate',
          'text': 'Due Date',
          'type': Config.getHtmlcontorls()['text'],
          'freeze': 1,
          'active': 1,
          'sorttable': 1,
          'sortby': 'title',
          'filter': 1,
          filterfield: 'startdate',
          // apipath: "property/building", //api path
          // masterdata: "checklisttype",
          // masterdatafield: "checklisttype",
          // formdatafield: "category",
          'filterfieldtype': Config.getHtmlcontorls()['datepicker'],
          'defaultvalue': '',
          'tblsize': 20
        },
        {
          'field': 'category',
          'text': 'Category',
          'type': Config.getHtmlcontorls()['text'],
          'freeze': 1,
          'active': 1,
          'sorttable': 1,
          'sortby': 'category',
          'filter': 1,
          filterfield: 'categoryid',
          filterfieldtype: Config.getHtmlcontorls()["dropdown"],
          // apipath: "property/building", //api path
          masterdata: "checklisttype",
          masterdatafield: "checklisttype",
          formdatafield: "category",
          'filterfieldtype': Config.getHtmlcontorls()['dropdown'],
          'defaultvalue': '',
          'tblsize': 20
        },
        {
          'field': 'checklist',
          'text': 'checklist',
          'type': Config.getHtmlcontorls()['text'],
          'freeze': 1,
          'active': 1,
          'sorttable': 1,
          'sortby': 'checklist',
          'filter': 0,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': 20
        },
        {
          'field': 'status',
          'text': 'Status',
          'type': Config.getHtmlcontorls()['status'],
          'freeze': 1,
          'active': 1,
          'sorttable': 0,
          'sortby': 'checklist',
          'filter': 0,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': 20
        },
      ]
    }
  }

  getFormFieldOrder() {
    return {
      "rightsidebarsize": Config.getModalsizeclasses()['xs'],
      "pagename": 'Tasks',
      "formname": 'Tasks',
      "alias": 'task',
      "dataview": "tab",
      'formfields': [
        {
          "tab": "Tasks",
          "formFields": []
        }
      ]
    };
  }

}
