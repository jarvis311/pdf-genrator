import mongoose from "mongoose"
import _Config from "../../config/Config.js"
const Config = new _Config()

export default class Policy {
  constructor() {
    this._id
    this.title = { type: String, required: true, trim: true }
    this.description = { type: Array }
    this.foremployee = { type: Number }
    this.forgatekeeper = { type: Number }
    this.forcustomer = { type: Number }
    this.photo = [Config.getImageModel()]
    this.sender = { type: String, required: true }
    this.senderid = { type: mongoose.Schema.Types.ObjectId }
    this.propertyid = { type: mongoose.Schema.Types.ObjectId, ref: "tblpropertymaster" }
    this.property = { type: String, required: true }
    this.persontype = { type: Number, default: 1 }  //1-customer,2-gatekeeper,3-employee
    this.policydate = { type: Date, default: Date.now }
    this.isactive = { type: Number, default: 1 }
    this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: "recordinfo" }
  }

  getDataName() {
    return "Policy"
  }
  getIndexes() {
    return [[{ propertyid: 1, title: 1 }, { unique: 1 }]]
  }
  getFieldOrder() {

    return {
      fields: [
        {
          'field': 'action_button',
          'text': '',
          'type': Config.getHtmlcontorls()['action_button'],
          'freeze': 1,
          'active': 1,
          'sorttable': 0,
          'filter': 0,
          'disableflex': 1,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': Config.getTblgridsizeclasses()[8]
        },
        {
          'field': 'isactive',
          'text': 'Status',
          'type': Config.getHtmlcontorls()['isactive'],
          'freeze': 1,
          'active': 1,
          'sorttable': 0,
          'filter': 0,
          'disableflex': 1,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': 15
        },
        {
          'field': 'title',
          'text': 'title',
          'type': Config.getHtmlcontorls()['text'],
          'freeze': 0,
          'active': 1,
          'sorttable': 1,
          'sortby': 'title',
          'filter': 0,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': Config.getTblgridsizeclasses()[25]
        },
        {
          'field': 'formatedate',
          'text': 'Policy Date',
          'type': Config.getHtmlcontorls()['text'],
          'freeze': 0,
          'active': 1,
          'sorttable': 1,
          'sortby': 'formatedate',
          'filter': 0,
          'defaultvalue': '',
          'tblsize': Config.getTblgridsizeclasses()[25]
        },
        {
          "field": "fromdate",
          "text": "From Date",
          "type": "datepicker",
          "freeze": 0,
          "active": 0,
          "sorttable": 1,
          "sortby": "fromdate",
          "filter": 1,
          "filterfield": "fromdate",
          "filterfieldtype": "datepicker",
          "isonlyfilter": 1,
          "defaultvalue": "",
          "tblsize": 28
        },
        {
          "field": "todate",
          "text": "To Date",
          "type": "datepicker",
          "freeze": 0,
          "active": 0,
          "sorttable": 1,
          "sortby": "todate",
          "filter": 1,
          "filterfield": "todate",
          "filterfieldtype": "datepicker",
          "isonlyfilter": 1,
          "defaultvalue": "",
          "tblsize": 28
        },
        {
          'field': 'forcustomer',
          'text': 'Policy For Customer',
          'type': Config.getHtmlcontorls()['switch'],
          'freeze': 0,
          'active': 1,
          'sorttable': 0,
          'defaultvalue': '',
          'filter': 0,
          'tblsize': Config.getTblgridsizeclasses()[30]
        },
        {
          'field': 'forgatekeeper',
          'text': 'Policy For Gatekeeper',
          'type': Config.getHtmlcontorls()['switch'],
          'freeze': 0,
          'active': 1,
          'sorttable': 0,
          'defaultvalue': '',
          'filter': 0,
          'tblsize': Config.getTblgridsizeclasses()[30]
        },
        {
          'field': 'foremployee',
          'text': 'Policy For Employee',
          'type': Config.getHtmlcontorls()['switch'],
          'freeze': 0,
          'active': 1,
          'sorttable': 0,
          'filter': 0,
          'defaultvalue': '',
          'tblsize': 58
        },
      ]
    }
  }

  getFormFieldOrder() {
    return {
      "rightsidebarsize": Config.getModalsizeclasses()['md'],
      "pagename": 'policy',
      "formname": 'Policy',
      "alias": 'policy',
      "dataview": "tab",
      'formfields': [
        {
          "tab": "policy",
          "formFields": [
            {
              'field': 'title',
              'text': 'Title',
              'type': Config.getHtmlcontorls()['kInputText'],
              'disabled': false,
              'defaultvisibility': true,
              'required': true,
              'gridsize': Config.getFieldSize()['k375'],
            },
            {
              "field": "policydate",
              "text": "Date",
              "type": "datepicker",
              "disabled": false,
              "defaultvisibility": true,
              "required": true,
              "gridsize": 375
            },
            {
              'field': 'forgatekeeper',
              'text': 'For Gatekeeper',
              'type': 'checkbox',
              'disabled': false,
              'required': false,
              'defaultvisibility': true,
              'gridsize': 180,
            },
            {
              'field': 'forcustomer',
              'text': 'For Customer',
              'type': 'checkbox',
              'disabled': false,
              'required': false,
              'defaultvisibility': true,
              'gridsize': 180,
            },
            {
              'field': 'foremployee',
              'text': 'For Employee',
              'type': 'checkbox',
              'disabled': false,
              'required': false,
              'defaultvisibility': true,
              'gridsize': 180,
            },
            {
              'field': 'photo',
              'text': 'Photo',
              'type': "multipleimagepicker",
              'disabled': false,
              'defaultvisibility': true,
              'required': false,
              'filetypes': Config.images,
              'gridsize': 375,
              "freeze": 0,
              "active": 1,
              "sorttable": 0,
              "filter": 0,
              "defaultvalue": ""
            },
            {
              "field": "description",
              "text": "Description",
              "height": 400,
              "type": "htmleditor",
              "disabled": false,
              "defaultvisibility": true,
              "required": true,
            },
          ]
        }
      ],
    }
  }

}
