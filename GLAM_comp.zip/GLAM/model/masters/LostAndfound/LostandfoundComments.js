import mongoose from "mongoose"

export default class LostandfoundComments {
    constructor() {
        this._id
        this.propertyid = { type: mongoose.Schema.Types.ObjectId, ref: "tblproperty" }
        this.property = { type: String, required: true }
        this.personid = { type:mongoose.Schema.Types.ObjectId}
        this.person = {type:String}
        this.lostandfoundid = { type: mongoose.Schema.Types.ObjectId, ref: "tbllostandfoundmaster" }
        this.lostandfound = {type:String}
        this.unitid = {type:String}
        this.personname = { type:String}
        this.email = { type: String, default : "",trim: true }
        this.phoneno = { type: String, default : "",trim: true }
        this.photo = [{ type: Object, default : "",trim: true }]
        this.comment = { type: String,default : "", trim: true }
        this.createdate = {type:Date,default:Date.now}
        this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: "recordinfo" }
    }
}
