import mongoose from 'mongoose'
import { Config } from '../../../config/Init.js'


export default class LostandfoundPriority {
  constructor() {
    this._id
    this.lostandfoundpriority = { type: String, required: true, unique: true }
    this.backgroundcolor = { type: String, required: true, default: 'FF0000' }
    this.isactive = { type: Number, default: 1 }
    this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: 'recordinfo' }
  }

  getDataName() {
    return "LostAndFound Priority"
  }

  getFieldOrder() {
    return {
      fields: [
        {
          'field': 'action_button',
          'text': '',
          'type': Config.getHtmlcontorls()['action_button'],
          'freeze': 1,
          'active': 1,
          'sorttable': 0,
          'filter': 0,
          'disableflex': 1,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': 8
        },
        {
          'field': 'isactive',
          'text': 'Status',
          'type': Config.getHtmlcontorls()['isactive'],
          'freeze': 1,
          'active': 1,
          'sorttable': 0,
          'filter': 0,
          'disableflex': 1,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': 15
        },
        {
          'field': 'complaintpriority',
          'text': 'LostAndFound Priority',
          'type': Config.getHtmlcontorls()['text'],
          'freeze': 1,
          'active': 1,
          'sorttable': 1,
          'sortby': 'complaintpriority',
          'filter': 0,
          'disableflex': 2,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': 25
        },
        {
          "field": "backgroundcolor",
          "text": "Status Color",
          "type": "color",
          'freeze': 0,
          'active': 1,
          'sorttable': 0,
          'filter': 0,
          "disabled": false,
          "required": false,
          "defaultvisibility": true,
          "tblsize": 140
        }
      ]
    }
  }

  getFormFieldOrder() {
    return {
      "rightsidebarsize": Config.getModalsizeclasses()['xs'],
      "pagename": 'complaintpriority',
      "formname": 'LostAndFound Priority',
      "alias": 'complaintpriority',
      "dataview": "tab",
      'formfields': [
        {
          "tab": "complaintpriority",
          "formFields": [
            {
              'field': 'complaintpriority',
              'text': 'LostAndFound Priority',
              'type': Config.getHtmlcontorls()['kInputText'],
              'disabled': false,
              'defaultvisibility': true,
              'required': true,
              'gridsize': Config.getFieldSize()['k375'],
              "capitalcase": true
            },
            {
              "field": "backgroundcolor",
              "text": "Status Color",
              "type": "colorpicker",
              "disabled": false,
              "required": true,
              "defaultvisibility": true,
              "gridsize": 375
            },
            {
              'field': 'isactive',
              'text': 'Status',
              'type': Config.getHtmlcontorls()['kDropDown'],
              'disabled': false,
              'defaultvisibility': true,
              'required': true,
              'gridsize': Config.getFieldSize()['k375'],
              'masterdata': 'isactive',
              'masterdataarray': Config.getStatustype(),
              'defaultvalue': 1,
              'formdatafield': 'isactive',
              'cleanable': true,
              'searchable': true,
              'masterdatadependancy': false,
            },
          ]
        }
      ],
    }
  }
}