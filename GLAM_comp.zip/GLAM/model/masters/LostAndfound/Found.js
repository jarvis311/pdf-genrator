import mongoose from "mongoose"
import _Config from "../../../config/Config.js"
const Config = new _Config()

export default class Found {

  constructor() {
    this._id
    this.itemlostfound = { type: String, default: "", trim: true }
    this.itemlostfounddescription = { type: String, default: "", trim: true }
    this.lostcomment = { type: String, default: "", trim: true }
    this.lostpriorityid = { type: mongoose.Schema.Types.ObjectId, ref: "tbllostandfoundprioritymaster" }
    this.lostpriority = { type: String }
    this.status = { type: String, trim: true }
    this.propertyid = { type: mongoose.Schema.Types.ObjectId, ref: "tblpropertymaster", required: true }
    this.property = { type: String, trim: true, required: true }
    this.customerid = { type: mongoose.Schema.Types.ObjectId, ref: "tblcustomer" }
    this.customer = { type: String }
    this.locationtype = { type: Number } // 1-area 2-unit
    this.wing = { type: String }
    this.wingid = { type: mongoose.Schema.Types.ObjectId, ref: 'tblpropertywing', default: Config.dummyObjid }
    this.floor = { type: String }
    this.floorid = { type: mongoose.Schema.Types.ObjectId, ref: 'tblpropertyfloor', default: Config.dummyObjid }
    this.unit = { type: String }
    this.unitid = { type: mongoose.Schema.Types.ObjectId, ref: 'tblpropertyunit', default: Config.dummyObjid }
    this.area = { type: String }
    this.areaid = { type: mongoose.Schema.Types.ObjectId, ref: 'tblpropertyarea', default: Config.dummyObjid }
    this.notfoundreason = { type: String, trim: true, default: "" }
    this.createddate = { type: Date, default: new Date() }
    this.assignperson = { type: mongoose.Schema.Types.ObjectId, default: Config.dummyObjid }
    this.foundby = { type: String, trim: true, default: "" }
    this.foundcomment = { type: String, default: "", trim: true }
    this.founddetails = {
      wing: { type: String },
      wingid: { type: mongoose.Schema.Types.ObjectId, ref: 'tblpropertywing', default: Config.dummyObjid },
      floor: { type: String },
      floorid: { type: mongoose.Schema.Types.ObjectId, ref: 'tblpropertyfloor', default: Config.dummyObjid },
      unit: { type: String },
      unitid: { type: mongoose.Schema.Types.ObjectId, ref: 'tblpropertyunit', default: Config.dummyObjid },
      area: { type: String },
      areaid: { type: mongoose.Schema.Types.ObjectId, ref: 'tblpropertyarea', default: Config.dummyObjid }
    }
    this.foundimage = [Config.getImageModel()]
    this.lostimage = [Config.getImageModel()]
    this.iswithrow = { type: Number, default: 0 }
    this.giveaway = { type: Number, default: 0 }
    this.giveawayname = { type: String }
    this.lostandfoundaction = [
      {
        lostandfoundactionid: { type: mongoose.Schema.Types.ObjectId, ref: "" },
        lostandfoundaction: { type: String, trim: true },
        lostandfoundctionsvg: { type: String, trim: true },
      }
    ]
    this.isactive = { type: Number, required: true, default: 1 } // 1 - active, 0 - deactive
    this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: "recordinfo" }
  }

  getDataName() {
    return "Found"
  }
  getFieldOrder() {
    return {
      fields: [
        {
          'field': 'action_button',
          'text': '',
          'type': Config.getHtmlcontorls()['action_button'],
          'freeze': 1,
          'active': 1,
          'sorttable': 0,
          'filter': 0,
          'disableflex': 1,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': Config.getTblgridsizeclasses()[8]
        },

        {
          'field': 'giveaway',
          'text': 'Found Status',
          'type': Config.getHtmlcontorls()['isactive'],
          'freeze': 0,
          'active': 1,
          'sorttable': 0,
          'filter': 0,
          'disableflex': 1,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': Config.getTblgridsizeclasses()[18]
        },
        // {
        //   'field': 'lostpriority',
        //   'text': 'Priority Status',
        //   'type': 'status',
        //   'freeze': 0,
        //   'active': 1,
        //   'sorttable': 1,
        //   'sortby': 'lostpriority',
        //   'filter': 1,
        //   'filterfieldtype': Config.getHtmlcontorls()['dropdown'],
        //   'filterfield': 'lostpriorityid',
        //   "masterdata": "lostandfoundpriority",
        //   "masterdatafield": "lostandfoundpriority",
        //   "formdatafield": "lostpriorityid",
        //   'tblsize': Config.getTblgridsizeclasses()[20]
        // },
        {
          'field': 'lostpriority',
          'text': 'Priority',
          'type': Config.getHtmlcontorls()['text'],
          'freeze': 0,
          'active': 1,
          'sorttable': 0,
          'filter': 0,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': Config.getTblgridsizeclasses()[15]
        },
        {
          'field': 'customer',
          'text': 'Person Name',
          'type': Config.getHtmlcontorls()['text'],
          'freeze': 0,
          'active': 1,
          'sorttable': 1,
          'sortby': 'customer',
          'filter': 0,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': Config.getTblgridsizeclasses()[15]
        },
        {
          'field': 'itemlostfound',
          'text': 'Found Item Name',
          'type': Config.getHtmlcontorls()['text'],
          'freeze': 0,
          'active': 1,
          'sorttable': 1,
          'sortby': 'itemlostfound',
          'filter': 0,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': Config.getTblgridsizeclasses()[15]
        },
        {
          'field': 'itemlostfounddescription',
          'text': 'Descriprtion',
          'type': Config.getHtmlcontorls()['text'],
          'freeze': 0,
          'active': 1,
          'sorttable': 0,
          'sortby': 'itemlostfounddescription',
          'filter': 0,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': Config.getTblgridsizeclasses()[15]
        },

        // {
        //   'field': 'lostpriority',
        //   'text': 'Priority',
        //   'type': Config.getHtmlcontorls()['text'],
        //   'freeze': 0,
        //   'active': 1,
        //   'sorttable': 0,
        //   'filter': 0,
        //   'filterfieldtype': Config.getHtmlcontorls()['lookup'],
        //   'defaultvalue': '',
        //   'tblsize': Config.getTblgridsizeclasses()[15]
        // },
        {
          'field': ['wing', 'floor', 'unit', 'area'],
          'text': 'Wing',
          'type': "taglist",
          'freeze': 0,
          'active': 1,
          'sorttable': 0,
          'sortby': 'wing',
          'filter': 0,
          'tblsize': Config.getTblgridsizeclasses()[20]
        },

        {
          "field": "fromdate",
          "text": "From Date & Time",
          "type": "datetimepicker",
          "freeze": 0,
          "active": 0,
          "sorttable": 1,
          "sortby": "fromdate",
          "filter": 1,
          "filterfield": "fromdate",
          "filterfieldtype": "datetimepicker",
          "isonlyfilter": 1,
          "defaultvalue": "",
          "tblsize": 28
        },
        {
          "field": "todate",
          "text": "To Date & Time",
          "type": "datetimepicker",
          "freeze": 0,
          "active": 0,
          "sorttable": 1,
          "sortby": "todate",
          "filter": 1,
          "filterfield": "todate",
          "filterfieldtype": "datetimepicker",
          "isonlyfilter": 1,
          "defaultvalue": "",
          "tblsize": 28
        },
      ]
    }
  }

  getFormFieldOrder() {
    const Config = new _Config()
    return {
      "rightsidebarsize": Config.getModalsizeclasses()['xs'],
      "pagename": 'found',
      "formname": 'Found',
      "alias": 'found',
      "dataview": "tab",
      'formfields': [
        {
          "tab": "Found",
          "formFields": [
            {
              "field": "foundimage",
              "text": "Found Item Image",
              "type": "multipleimagepicker",
              "disabled": false,
              "defaultvisibility": true,
              "required": false,
              "filetypes": Config.images,
              "gridsize": 375,
              "freeze": 0,
              "active": 1,
              "sorttable": 0,
              "filter": 0,
              "defaultvalue": ""
            },
            {
              'field': 'itemlostfound',
              'text': 'Found Item Name',
              'type': Config.getHtmlcontorls()['kInputText'],
              'disabled': false,
              'defaultvisibility': true,
              'required': true,
              'gridsize': Config.getFieldSize()['k375'],
            },
            {
              'field': 'itemlostfounddescription',
              'text': 'Item Found Description',
              'type': Config.getHtmlcontorls()['input-textarea'],
              'disabled': false,
              'defaultvisibility': true,
              'required': false,
              'gridsize': Config.getFieldSize()['k375'],
            },
            {
              "field": "lostpriorityid",
              "text": "Found Priority",
              "type": "dropdown",
              "disabled": false,
              "defaultvisibility": true,
              "required": true,
              "gridsize": 375,
              "masterdata": "lostandfoundpriority",
              "masterdatafield": "lostandfoundpriority",
              "formdatafield": "lostpriority",
              "cleanable": true,
              "searchable": true,
              "masterdatadependancy": false,
              "staticfilter": { "isactive": 1 }
            },
            {
              'field': 'locationtype',
              'text': 'Wing & Floor or Area',
              'type': 'radio',
              'disabled': false,
              'defaultvisibility': true,
              'required': false,
              'gridsize': 375,
              'defaultvalue': 1,
              'masterdata': 'locationtype',
              'masterdataarray': [
                { 'label': 'Wing & Floor & Unit', 'value': 2 },
                { 'label': 'Area', 'value': 1 },
              ],
            },
            {
              "field": "wingid",
              "text": "Wing",
              "type": "dropdown",
              "disabled": false,
              "defaultvisibility": true,
              "required": false,
              "gridsize": 375,
              "masterdata": "property/wing",
              "masterdatafield": "wingname",
              "formdatafield": "wing",
              "cleanable": true,
              "isautofillvalue": false,

              "searchable": true,
              "onchangefill": ["floorid"],
              "masterdatadependancy": false,
              "condition": { "locationtype": [2] },
              "staticfilter": { "isactive": 1 }
            },
            {
              "field": "floorid",
              "text": "Floor",
              "type": "dropdown",
              "disabled": false,
              "defaultvisibility": true,
              "required": false,
              "isautofillvalue": false,

              "gridsize": 375,
              "masterdata": "property/floor",
              "masterdatafield": "floor",
              "formdatafield": "floor",
              "cleanable": true,
              "searchable": true,
              "onchangefill": ["unitid"],
              "dependentfilter": { "wingid": "wingid" },
              "masterdatadependancy": true,
              "condition": { "locationtype": [2] },
              "staticfilter": { "isactive": 1 },
            },
            {
              "field": "unitid",
              "text": "Unit",
              "type": "dropdown",
              "disabled": false,
              "defaultvisibility": true,
              "required": false,
              "gridsize": 375,
              "masterdata": "property/unit",
              "masterdatafield": "unitname",
              "formdatafield": "unit",
              "cleanable": true,
              "searchable": true,
              "isautofillvalue": false,
              "condition": { "locationtype": [2] },
              "dependentfilter": { "wingid": "wingid", "floorid": "floorid" },
              "masterdatadependancy": true,
              "staticfilter": { "isactive": 1 },
            },
            {
              "field": "areaid",
              "text": "Area",
              "type": "dropdown",
              "disabled": false,
              "defaultvisibility": true,
              "required": false,
              "gridsize": 375,
              "masterdata": "property/area",
              "masterdatafield": "area",
              "formdatafield": "area",
              "cleanable": true,
              "isautofillvalue": false,

              "searchable": true,
              "condition": { "locationtype": [1] },
              "masterdatadependancy": false,
              "staticfilter": { "isactive": 1 },
            },
          ]
        }
      ],
    }
  }

}
