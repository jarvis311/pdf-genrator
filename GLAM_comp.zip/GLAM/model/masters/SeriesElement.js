import mongoose from "mongoose"

export default class SeriesElement {
    constructor() {
        this._id
        this.serieselement = { type: String, trim: true }
        this.hasproperty = { type: Number }
        this.hasdaterange = { type: Number }
        this.order = { type: Number }
    }

}
