import mongoose from "mongoose";

export default class AppUpdate {
    constructor () {
        this._id;
        this.type = { type: Number, required: false, default: 0 };
        this.phonetype = { type: Number, required: false }; // 1: Android, 2: iOS
        this.phonetxt = { type: String, required: false, trim: true };
        this.vername = { type: String, required: false, trim: true };
        this.vercode = { type: String, required: false, trim: true };
        this.isforcefully = { type: Number, required: false }; // 1: Update Forcefully
        this.isforcelogout = { type: Number, required: false, default: 0 }; // 1: Forcefully logout after update
        this.timestamp = { type: Number, required: false };
        this.entryuid = { type: mongoose.Schema.Types.ObjectId, required: false, trim: true, ref: "tblusermaster" };
        this.entrydate = { type: Date, required: false };
        this.updateuid = { type: mongoose.Schema.Types.ObjectId, required: false, trim: true, ref: "tblusermaster" };
        this.updatedate = { type: Date, required: false };
    }
}