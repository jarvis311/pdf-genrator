import _Config from "../../../config/Config.js"

export default class Notification {
    constructor() {
        this._id
        this.alias = { type: String, trim: true }
    }
}
