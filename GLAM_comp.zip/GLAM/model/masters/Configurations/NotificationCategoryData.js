import mongoose from "mongoose"
import { Config } from "../../../config/Init.js"

export default class NotificationCategoryData {
    constructor() {
        this._id
        this.notificationcategoryid = { type: mongoose.Schema.Types.ObjectId, ref: "tblnotificationcategory" }
        this.notificationcategory = { type: String, trim: true }
        this.alias = { type: String, trim: true }
        this.name = { type: String, trim: true }
        this.interval = {type: Number, trim:true, default:0}
        this.nooftimerepeat = {type:Number, trim:true, default:0}
        // this.message = { type: String, trim: true }
        this.title = { type: String, trim: true }
        this.body = { type: String, trim: true }
    }

    getFieldOrder() {
        return {
            fields: [
                {
                    field: "name",
                    text: "Notification",
                    type: Config.getHtmlcontorls()["text"],
                    freeze: 1,
                    active: 1,
                    sorttable: 1,
                    filter: 1,
                    filterfieldtype: Config.getHtmlcontorls()["lookup"],
                    defaultvalue: "",
                    tblsize: Config.getTblgridsizeclasses()["tbl-w150"]
                },
                {
                    field: "alias",
                    text: "Alias",
                    type: Config.getHtmlcontorls()["text"],
                    freeze: 0,
                    active: 1,
                    sorttable: 1,
                    filter: 1,
                    filterfieldtype: Config.getHtmlcontorls()["lookup"],
                    defaultvalue: "",
                    tblsize: Config.getTblgridsizeclasses()["tbl-w150"]
                },
                {
                    field: "title",
                    text: "Notification Title",
                    type: Config.getHtmlcontorls()["text"],
					freeze: 0,
					active: 1,
					sorttable: 1,
					filter: 0,
					filterfieldtype: Config.getHtmlcontorls()["lookup"],
					defaultvalue: "",
					tblsize: Config.getTblgridsizeclasses()["tbl-w150"]
                },
                {
                    field: "body",
                    text: "Notification Body",
                    type: Config.getHtmlcontorls()["text"],
                    freeze: 0,
                    active: 1,
                    sorttable: 1,
                    filter: 1,
                    filterfieldtype: Config.getHtmlcontorls()["lookup"],
                    defaultvalue: "",
                    tblsize: Config.getTblgridsizeclasses()["tbl-w150"]
                },
                {
                    field: "messagepreview",
                    text: "Message Preview",
                    type: Config.getHtmlcontorls()["modal-eye"],
                    freeze: 0,
                    active: 1,
                    sorttable: 0,
                    filter: 0,
                    filterfieldtype: Config.getHtmlcontorls()["lookup"],
                    defaultvalue: "",
                    tblsize: Config.getTblgridsizeclasses()["tbl-w150"]
                }
            ]
        }
    }
}
