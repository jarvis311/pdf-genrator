import _Config from "../../../config/Config.js"

export default class NotificationCategory {
    constructor() {
        this._id
        this.name = { type: String, trim: true }
        this.svg = { type: String, trim: true }
    }
}
