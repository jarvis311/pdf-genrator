import { Config } from "../../../config/Init.js"
import mongoose from "mongoose"

export default class EmailTemplate {
	constructor() {
		this._id
		this.templateforid = { type: mongoose.Schema.Types.ObjectId, ref: "tbltemplatemode" }
		this.templatefor = { type: String, trim: true, required: true, unique: true }
		this.templatename = { type: String, trim: true, required: true }
		this.bcc = { type: Array, default: [] }
		this.cc = { type: Array, default: [] }
		this.body = { type: String, trim: true, default: "" }
		this.status = { type: Number, default: 1 }
		this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: "recordinfo" }
	}

	getFieldOrder() {
		return {
			fields: [
				{
					field: "templatename",
					text: "Template Name",
					type: Config.getHtmlcontorls()["text"],
					freeze: 1,
					active: 1,
					sorttable: 1,
					filter: 1,
					filterfieldtype: Config.getHtmlcontorls()["lookup"],
					defaultvalue: "",
					tblsize: Config.getTblgridsizeclasses()["tbl-min-w150"]
				},
				{
					field: "templatefor",
					text: "Template For",
					type: Config.getHtmlcontorls()["text"],
					freeze: 0,
					active: 1,
					sorttable: 1,
					filter: 1,
					filterfieldtype: Config.getHtmlcontorls()["lookup"],
					defaultvalue: "",
					tblsize: Config.getTblgridsizeclasses()["tbl-min-w200"]
				},
				{
					field: "bcc",
					text: "BCC",
					type: Config.getHtmlcontorls()["modal-eye"],
					freeze: 0,
					active: 1,
					sorttable: 0,
					filter: 0,
					filterfieldtype: Config.getHtmlcontorls()["modal-eye"],
					defaultvalue: "",
					tblsize: Config.getTblgridsizeclasses()["tbl-min-w150"]
				},
				{
					field: "cc",
					text: "CC",
					type: Config.getHtmlcontorls()["modal-eye"],
					freeze: 0,
					active: 1,
					sorttable: 0,
					filter: 0,
					filterfieldtype: Config.getHtmlcontorls()["modal-eye"],
					defaultvalue: "",
					tblsize: Config.getTblgridsizeclasses()["tbl-min-w150"]
				},
				{
					field: "body",
					text: "Template",
					type: Config.getHtmlcontorls()["modal-eye"],
					freeze: 0,
					active: 1,
					sorttable: 0,
					filter: 0,
					filterfieldtype: Config.getHtmlcontorls()["modal-eye"],
					defaultvalue: "",
					tblsize: Config.getTblgridsizeclasses()["tbl-min-w150"]
				},
				{
					field: "status",
					text: "Status",
					type: Config.getHtmlcontorls()["switch"],
					freeze: 0,
					active: 1,
					sorttable: 1,
					filter: 1,
					filterfieldtype: Config.getHtmlcontorls()["number-input"],
					defaultvalue: "",
					tblsize: Config.getTblgridsizeclasses()["tbl-min-w150"]
				}
			]
		}
	}
}
