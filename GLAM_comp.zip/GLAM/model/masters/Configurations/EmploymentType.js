import mongoose from "mongoose"
import _Config from "../../../config/Config.js"

export default class EmployeementType {
    constructor() {
        this._id
        this.employeementtype = { type: String, required: true, trim: true, unique: true }
        this.isactive = { type: Number, default: 1}
        this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: "recordinfo" }
    }
    getFieldOrder() {
        const Config = new _Config()

        return {
            fields: [
                {
                    field: "employeementtype",
                    text: "Employment Type",
                    type: Config.getHtmlcontorls()["text"],
                    freeze: 1,
                    active: 1,
                    sorttable: 1,
                    filter: 1,
                    filterfieldtype: Config.getHtmlcontorls()["lookup"],
                    defaultvalue: "",
                    tblsize: Config.getTblgridsizeclasses()["tbl-w400"]
                },
                {
                    field: "isactive",
                    text: "Status",
                    type: Config.getHtmlcontorls()["switch"],
                    freeze: 0,
                    active: 1,
                    sorttable: 0,
                    filter: 1,
                    filterfieldtype: Config.getHtmlcontorls()["dropdown"],
                    formdatafield: "isactive",
                    masterdataarray: [
                        {
                            label: "Active",
                            value: 1
                        },
                        {
                            label: "Inactive",
                            value: 0
                        }
                    ],
                    defaultvalue: "",
                    tblsize: Config.getTblgridsizeclasses()["tbl-w30"]
                }
            ]
        }
    }
}
