import { Config } from "../../../config/Init.js"
import mongoose from "mongoose"

export default class EmailSMTP {
	constructor() {
		this._id
		this.sendername = { type: String, trim: true, default: "" }
		this.host = { type: String, trim: true, default: "" }
		this.port = { type: String, trim: true, default: "" }
		this.email = { type: String, trim: true, default: "", unique: true }
		this.username = { type: String, trim: true, default: "" }
		this.password = { type: String, trim: true, default: "" }
		this.status = { type: Number, default: 1 }
		this.default = { type: Number, default: 0 }
		this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: "recordinfo" }
	}

	getFieldOrder() {
		return {
			fields: [
				{
					field: "sendername",
					text: "Sender Name",
					type: Config.getHtmlcontorls()["text"],
					freeze: 0,
					active: 1,
					sorttable: 0,
					filter: 1,
					filterfieldtype: Config.getHtmlcontorls()["lookup"],
					defaultvalue: "",
					tblsize: Config.getTblgridsizeclasses()["tbl-min-w150"]
				},
				{
					field: "host",
					text: "Host",
					type: Config.getHtmlcontorls()["text"],
					freeze: 1,
					active: 1,
					sorttable: 1,
					filter: 1,
					filterfieldtype: Config.getHtmlcontorls()["lookup"],
					defaultvalue: "",
					tblsize: Config.getTblgridsizeclasses()["tbl-min-w200"]
				},
				{
					field: "email",
					text: "Email",
					type: Config.getHtmlcontorls()["text"],
					freeze: 0,
					active: 1,
					sorttable: 1,
					filter: 1,
					filterfieldtype: Config.getHtmlcontorls()["lookup"],
					defaultvalue: "",
					tblsize: Config.getTblgridsizeclasses()["tbl-min-w150"]
				},
				{
					field: "username",
					text: "Username",
					type: Config.getHtmlcontorls()["text"],
					freeze: 0,
					active: 1,
					sorttable: 1,
					filter: 1,
					filterfieldtype: Config.getHtmlcontorls()["lookup"],
					defaultvalue: "",
					tblsize: Config.getTblgridsizeclasses()["tbl-min-w150"]
				},
				{
					field: "status",
					text: "Status",
					type: Config.getHtmlcontorls()["switch"],
					freeze: 0,
					active: 1,
					sorttable: 0,
					filter: 1,
					filterfieldtype: Config.getHtmlcontorls()["dropdown"],
					formdatafield: "status",
					masterdataarray: [
                        {
                            label: "Active",
                            value: 1
                        },
                        {
                            label: "Inactive",
                            value: 0
                        }
                    ],
					defaultvalue: "",
					tblsize: Config.getTblgridsizeclasses()["tbl-min-w150"]
				},
				{
					field: "default",
					text: "Default",
					type: Config.getHtmlcontorls()["switch"],
					freeze: 0,
					active: 1,
					sorttable: 0,
					filter: 1,
					filterfieldtype: Config.getHtmlcontorls()["dropdown"],
					formdatafield: "default",
					masterdataarray: [
                        {
                            label: "Active",
                            value: 1
                        },
                        {
                            label: "Inactive",
                            value: 0
                        }
                    ],
					defaultvalue: "",
					tblsize: Config.getTblgridsizeclasses()["tbl-min-w150"]
				}
			]
		}
	}
}
