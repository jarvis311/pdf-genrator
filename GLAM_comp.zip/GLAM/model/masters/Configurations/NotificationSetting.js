import mongoose from "mongoose"
import { Config } from "../../../config/Init.js"

export default class NotificationSetting {
    constructor() {
        this._id
        //setting works userrole or personid wise 
        this.userroleid = { type: mongoose.Schema.Types.ObjectId }
        this.userrole = { type: String, trim: true, default: "" }
        this.personid = { type: mongoose.Schema.Types.ObjectId, ref: "tblpersonmaster" }

        this.notificationcategoryid = { type: mongoose.Schema.Types.ObjectId, ref: "tblnotificationcategory" }
        this.notificationcategory = { type: String, trim: true }
        this.notificationcategorydataid = { type: mongoose.Schema.Types.ObjectId, ref: "tblnotificationcategorydata" }
        this.notificationcategorydata = { type: String, trim: true }

        this.alias = { type: String, trim: true }
        this.isselected = { type: Number, default: 0 },
        this.isshow = { type: Number, default: 0 },
        this.message = { type: String } // 05-01-24 Abhi Shah

        this.interval = { type: Number, default:0 } //in minutes
        this.nooftimerepeat = { type: Number, default:0 }


        //person of departments, designations, persons
        this.departments = [
            {
                departmentid: { type: mongoose.Schema.Types.ObjectId, ref: "tbldepartmentmaster", default: Config.dummyObjid },
                department: { type: String, trim: true, default: "" },
            }
        ]
        this.designations = [
            {
                designationid: { type: mongoose.Schema.Types.ObjectId, ref: "tbldesignationmaster", default: Config.dummyObjid },
                designation: { type: String, trim: true, default: "" },
            }
        ]
        this.persons = [
            {
                personid: { type: mongoose.Schema.Types.ObjectId, ref: "tblpersonmaster", default: Config.dummyObjid },
                person: { type: String, trim: true, default: "" },
            }
        ]
       
        //this.moduletypeid = { type: mongoose.Schema.Types.ObjectId}
        this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: "recordinfo" }

        // this.audiourl = { type: String, trim: true, default: "" }
    }

    getIndexes() {
        return [{ notificationcategoryid: 1, userroleid: 1 }, { notificationcategoryid : 1, alias : 1 }]
    }

    getFieldOrder() {
        return {
            fields: [
                {
                    field: "userrole",
                    text: "User Role",
                    type: Config.getHtmlcontorls()["text"],
                    freeze: 1,
                    active: 1,
                    sorttable: 1,
                    filter: 1,
                    filterfieldtype: Config.getHtmlcontorls()["lookup"],
                    defaultvalue: "",
                    tblsize: Config.getTblgridsizeclasses()["tbl-min-w150"]
                },
                {
                    field: "notificationcategory",
                    text: "Notification Category",
                    type: Config.getHtmlcontorls()["text"],
                    freeze: 0,
                    active: 1,
                    sorttable: 1,
                    filter: 1,
                    filterfieldtype: Config.getHtmlcontorls()["lookup"],
                    defaultvalue: "",
                    tblsize: Config.getTblgridsizeclasses()["tbl-min-w150"]
                },
                {
                    field: "notificationcategorydata",
                    text: "Notification Category Data",
                    type: Config.getHtmlcontorls()["text"],
                    freeze: 0,
                    active: 1,
                    sorttable: 1,
                    filter: 1,
                    filterfieldtype: Config.getHtmlcontorls()["lookup"],
                    defaultvalue: "",
                    tblsize: Config.getTblgridsizeclasses()["tbl-min-w150"]
                },

            ]
        }
    }
}
