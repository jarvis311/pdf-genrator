import mongoose from 'mongoose'
import { Config } from '../../config/Init.js'

export default class EmergencyDir {
    constructor() {
        this._id
        this.propertyid = { type: mongoose.Schema.Types.ObjectId, ref: "tblpropertymaster" },
            this.property = { type: String, required: true }
        this.emergencycategoryid = { type: mongoose.Schema.Types.ObjectId, ref: "tblemergencycategory" }
        this.emergencycategory = { type: String, required: true }
        this.personname = { type: String }
        this.mobileno = { type: String }
        this.latlong = { type: String }
        this.isactive = { type: Number, required: true, default: 1 } // 1 - active, 0 - deactive
        this.profilepicture = Config.getImageModel()
        this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: 'recordinfo' }
    }

    getDataName() {
        return "EmergencyDir"
    }

    getFieldOrder() {
        return {
            fields: [
                {
                    'field': 'action_button',
                    'text': '',
                    'type': Config.getHtmlcontorls()['action_button'],
                    'freeze': 1,
                    'active': 1,
                    'sorttable': 0,
                    'filter': 0,
                    'disableflex': 1,
                    'filterfieldtype': Config.getHtmlcontorls()['lookup'],
                    'defaultvalue': '',
                    'tblsize': Config.getTblgridsizeclasses()[8]

                },
                {
                    'field': 'isactive',
                    'text': 'Status',
                    'type': Config.getHtmlcontorls()['isactive'],
                    'freeze': 1,
                    'active': 1,
                    'sorttable': 0,
                    'filter': 0,
                    'disableflex': 1,
                    'filterfieldtype': Config.getHtmlcontorls()['lookup'],
                    'defaultvalue': '',
                    'tblsize': Config.getTblgridsizeclasses()[15]
                },
                // {
                //     "field": "profilepicture",
                //     "text": "Profile Picture",
                //     "type": "file",
                //     'freeze': 0,
                //     'active': 1,
                //     'sorttable': 1,
                //     'filter': 0,
                //     "filetypes": Config.images,
                //     "disabled": false,
                //     "defaultvisibility": true,
                // },
                {
                    'field': 'personname',
                    'text': 'Person Name',
                    'type': Config.getHtmlcontorls()['text'],
                    'freeze': 0,
                    'active': 1,
                    'sorttable': 1,
                    'filter': 0,
                    'sortby': 'personname',
                    "defaultvisibility": true,
                    'filterfieldtype': Config.getHtmlcontorls()['lookup'],
                    'defaultvalue': '',
                    'tblsize': Config.getTblgridsizeclasses()[20]
                },
                {
                    'field': 'mobileno',
                    'text': 'Mobile Number',
                    'type': Config.getHtmlcontorls()['text'],
                    'freeze': 0,
                    'active': 1,
                    'sorttable': 0,
                    'filter': 0,
                    'filterfieldtype': Config.getHtmlcontorls()['lookup'],
                    'defaultvalue': '',
                    'tblsize': 20
                },
                // {
                //     "field": "latlong",
                //     "text": "Latitude & Longitude",
                //     "type": "text",
                //     "freeze": 0,
                //     "active": 1,
                //     "sorttable": 0,
                //     "filter": 0,
                //     "filterfieldtype": "lookup",
                //     "defaultvalue": ""
                // },

            ]
        }
    }

    getFormFieldOrder() {
        return {
            "rightsidebarsize": Config.getModalsizeclasses()['xs'],
            "pagename": 'emergencydir',
            "formname": 'Emergency Directory',
            "alias": 'emergencydir',
            "dataview": "tab",
            'formfields': [
                {
                    "tab": "emergencydir",
                    "formFields": [
                        {
                            "field": "emergencycategoryid",
                            "text": "Emergency Category",
                            "type": "dropdown",
                            "disabled": false,
                            "defaultvisibility": true,
                            "required": true,
                            "gridsize": 375,
                            "masterdata": "emergencycategory",
                            "masterdatafield": "emergencycategory",
                            "formdatafield": "emergencycategory",
                            "cleanable": true,
                            "searchable": true,
                            "masterdatadependancy": false,
                            // "staticfilter": { "isactive": 1 }
                        },
                        {
                            "field": "personname",
                            "text": "Person Name",
                            "type": "input-text",
                            "disabled": false,
                            "capitalize": true,
                            'regex': "[a-zA-Z ]",
                            "defaultvisibility": true,
                            "required": true,
                            "gridsize": 375
                        },
                        {
                            "field": "mobileno",
                            "text": "Mobile Number",
                            "type": "number-input",
                            "disabled": false,
                            "defaultvisibility": true,
                            "prefixtext": "code",
                            "required": true,
                            "gridsize": 375
                        },
                        {
                            "field": "latlong",
                            "text": "Latitude & Longitude",
                            "type": "latlong",
                            "disabled": false,
                            "decimalpoint": 6,
                            "defaultvisibility": true,
                            "required": false,
                            "cleanable": true,
                            "gridsize": 375,
                            "onchangefill": [
                                "currentaddress",
                                "area",
                                "pincode"
                            ]
                        },
                        {
                            "field": "profilepicture",
                            "text": "Profile Picture",
                            "type": "file",
                            "filetypes": Config.images,
                            "disabled": false,
                            "defaultvisibility": true,
                            "required": false,
                            "gridsize": 375
                        }


                    ]
                }
            ],
        }
    }
}

