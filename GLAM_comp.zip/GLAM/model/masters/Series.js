import { Config } from "../../config/Init.js"
import mongoose from "mongoose"
import _Config from "../../config/Config.js"

export default class Series {
    constructor() {
        this._id
        this.propertyid = { type: mongoose.Schema.Types.ObjectId, ref: "tblproperty" }
        this.property = { type: String, trim: true }
        this.seriestypeid = { type: mongoose.Schema.Types.ObjectId, ref: "tblmenumaster" }
        this.seriestype = { type: String, trim: true }
        this.startnumber = { type: Number }
        this.noofseries = { type: Number }
        this.prefix = { type: String, required: true, trim: true }
        this.elements = [{ elementid: { type: mongoose.Schema.Types.ObjectId }, element: { type: String } }]
        this.series = { type: String, required: true, trim: true }
        this.isinfinite = { type: Number, default: 0 }
        this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: "recordinfo" }
    }

    getDataName() {
        return "Series"
    }

    getIndexes() {
        return [{ seriestypeid: 1, seriestype: 1, companyid: 1, propertyid: 1 }]
    }

    getFieldOrder() {
        const Config = new _Config()

        return {
            fields: [
                {
                    'field': 'action_button',
                    'text': '',
                    'type': Config.getHtmlcontorls()['action_button'],
                    'freeze': 1,
                    'active': 1,
                    'sorttable': 0,
                    'filter': 0,
                    'disableflex': 1,
                    'filterfieldtype': Config.getHtmlcontorls()['lookup'],
                    'defaultvalue': '',
                    'tblsize': Config.getTblgridsizeclasses()[8]
                },
                {
                    field: "seriestype",
                    text: "Series Type",
                    type: Config.getHtmlcontorls()["text"],
                    freeze: 0,
                    active: 1,
                    sorttable: 1,
                    filter: 1,
                    filterfieldtype: Config.getHtmlcontorls()["lookup"],
                    defaultvalue: "",
                    tblsize: 20
                },
                {
                    field: "prefix",
                    text: "Series Prefix",
                    type: Config.getHtmlcontorls()["text"],
                    freeze: 0,
                    active: 1,
                    sorttable: 1,
                    filter: 1,
                    filterfieldtype: Config.getHtmlcontorls()["lookup"],
                    defaultvalue: "",
                    tblsize: 30
                },
                {
                    field: "series",
                    text: "Series Preview",
                    type: Config.getHtmlcontorls()["text"],
                    freeze: 0,
                    active: 1,
                    sorttable: 1,
                    filter: 1,
                    filterfieldtype: Config.getHtmlcontorls()["lookup"],
                    defaultvalue: "",
                    tblsize: 127
                }
            ]
        }
    }


    getFormFieldOrder() {
        return {
            "rightsidebarsize": Config.getModalsizeclasses()['xs'],
            "pagename": 'Series',
            "formname": 'Series',
            "alias": 'series',
            "dataview": "tab",
            "formfields": [
                {
                    "tab": "Series",
                    "formFields": [
                        {
                            'field': 'seriestypeid',
                            'text': 'Series Type',
                            'type': Config.getHtmlcontorls()['kDropDown'],
                            'disabled': false,
                            'required': false,
                            'defaultvisibility': true,
                            'gridsize': Config.getFieldSize()['k375'],
                            'masterdata': 'seriestype',
                            'masterdatafield': 'seriestype',
                            'formdatafield': 'seriestype',
                            'cleanable': false,
                            'searchable': true,
                            'projection': {
                                'seriestype': 1,
                                '_id': 1,
                            }
                        },
                        {
                            'field': 'startnumber',
                            'text': 'Start Number',
                            'type': Config.getHtmlcontorls()['kNumberInput'],
                            'disabled': false,
                            'defaultvisibility': true,
                            'required': true,
                            'gridsize': Config.getFieldSize()['k375'],
                        },
                        {
                            'field': 'noofseries',
                            'text': 'No of Series',
                            'type': Config.getHtmlcontorls()['kNumberInput'],
                            'disabled': false,
                            'defaultvisibility': true,
                            'required': true,
                            'gridsize': Config.getFieldSize()['k375'],
                            'condition': { "isinfinite": [0] },
                        },
                        {
                            'field': 'prefix',
                            'text': 'Series Prefix',
                            'type': Config.getHtmlcontorls()['kInputText'],
                            'disabled': false,
                            'defaultvisibility': true,
                            'required': true,
                            'gridsize': Config.getFieldSize()['k375'],
                        },
                        {
                            'field': 'elementid',
                            'text': 'Elements',
                            'type': Config.getHtmlcontorls()['kDropDown'],
                            'disabled': false,
                            'required': true,
                            'defaultvisibility': true,
                            'gridsize': Config.getFieldSize()['k375'],
                            'masterdata': 'serieselement',
                            'masterdatafield': 'serieselement',
                            'formdatafield': 'element',
                            'cleanable': false,
                            'searchable': true,
                        },
                        {
                            'field': 'isinfinite',
                            'text': 'Infinite Series',
                            'type': 'checkbox',
                            'disabled': false,
                            'required': false,
                            'defaultvisibility': true,
                            'gridsize': 180,
                        },
                        {
                            'field': 'button',
                            'text': 'Button',
                            'type': 'button',
                            'disabled': false,
                            'required': false,
                            'defaultvisibility': true,
                            'gridsize': Config.getFieldSize()['k30'],
                            'masterdata': '',
                            'masterdatafield': '',
                            'formdatafield': 'button',
                        },
                        {
                            'field': 'elements',
                            'text': 'Elements',
                            'type': 'serieselement',
                            'disabled': false,
                            'required': false,
                            'defaultvisibility': true,
                            'gridsize': Config.getFieldSize()['k375'],
                            'masterdata': 'serieselement',
                            'masterdatafield': 'serieselement',
                            'formdatafield': 'elements',
                            'cleanable': false,
                            'searchable': true,
                        },
                        {
                            'field': 'series',
                            'text': 'Series',
                            'type': 'input-text',
                            'disabled': true,
                            'required': false,
                            'defaultvisibility': true,
                            'gridsize': Config.getFieldSize()['k375'],
                            'masterdata': '',
                            'masterdatafield': '',
                            'formdatafield': 'series',
                            'cleanable': false,
                            'searchable': true,
                        },
                    ]
                }
            ]
        };
    }

}
