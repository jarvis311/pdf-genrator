import mongoose from "mongoose"
import _Config from "../../../config/Config.js"
import { Config } from "../../../config/Init.js"

export class Propertycommon {
    constructor() {
        this._id
        this.employeeid = { type: mongoose.Schema.Types.ObjectId, ref: "tblemployee" }
        this.brandname = { type: String, default: "", trim: true }
        this.property_id = { type: String, default: "", trim: true }
        this.propertyname = { type: String, default: "", required: true, unique: true, trim: true }
        this.prefix = { type: String, default: "", trim: true, required: true }
        this.uniqueno = { type: String, default: "", required: true, trim: true }
        this.website = { type: String, default: "", trim: true }
        this.maincontactperson = { type: String, default: "", required: true, trim: true }
        this.maincontactpersonemail = { type: String, default: "", trim: true }
        this.mainpersoncontactno = { type: String, default: "", required: true, trim: true }
        this.mainpersondesignation = { type: String, default: "", trim: true }
        this.propertyimage = Config.getImageModel()
        this.gstin_uin = { type: String, trim: true }
        this.gsttreatmentid = { type: mongoose.Schema.Types.ObjectId, ref: "tblgsttreatmentmaster" }
        this.gsttreatment = { type: String, trim: true }
        this.location = { type: String, default: "" },
            this.latlong = { type: String, default: "" },
            // this.latitude = { type: String, default: "" },
            // this.longitude = { type: String, default: "" },
            this.arearange = { type: Number, default: 0 },
            this.addressline1 = { type: String, trim: true }
            this.addressline2 = { type: String, trim: true }
        this.area = { type: String, trim: true }
        this.pincode = { type: String, default: "" },
            this.pincodeid = { type: mongoose.Schema.Types.ObjectId, ref: "tblpincodemaster" },
            this.cityid = { type: mongoose.Schema.Types.ObjectId, ref: "tblcitymaster" },
            this.city = { type: String, default: "" },
            this.stateid = { type: mongoose.Schema.Types.ObjectId, ref: "tblstatemaster" },
            this.state = { type: String, default: "" },
            this.countryid = { type: mongoose.Schema.Types.ObjectId, ref: "tblcountrymaster" },
            this.country = { type: String, default: "" },
            this.isactive = { type: Number, default: 1 }
        this.isdelete = { type: Number, default: 0 }
        this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: "recordinfo" }
    }

    getDataName() {
        return "Property"
    }

    getIndexes() {
        return [{ propertyname: 1 }]
    }

    getFieldOrder() {
        const Config = new _Config()
        return {
            "fields": [
                {
                    "field": "action_button",
                    "text": "",
                    "type": "action_button",
                    "freeze": 1,
                    "active": 1,
                    "sorttable": 0,
                    "filter": 0,
                    "disableflex": 1,
                    "filterfieldtype": "lookup",
                    "defaultvalue": "",
                    "tblsize": 8
                },
                {
                    "field": "isactive",
                    "text": "Status",
                    "type": "isactive",
                    "freeze": 1,
                    "active": 1,
                    "sorttable": 0,
                    "filter": 0,
                    "disableflex": 1,
                    "filterfieldtype": "lookup",
                    "defaultvalue": "",
                    "tblsize": 15
                },
                {
                    'field': 'empolyees',
                    'text': 'Assign Employees',
                    'type': 'button',
                    "freeze": 1,
                    "active": 1,
                    'disabled': false,
                    'required': true,
                    'defaultvisibility': true,
                    "tblsize": 15

                },
                {
                    "field": "prefix",
                    "text": "Prefix",
                    "type": "text",
                    "freeze": 0,
                    "active": 1,
                    "sorttable": 1,
                    "filter": 0,
                    "sortby": "prefix",
                    "filterfieldtype": "lookup",
                    "defaultvalue": "",
                },
                {
                    "field": "propertyname",
                    "text": "Property Name",
                    "type": "text",
                    "freeze": 0,
                    "active": 1,
                    "sorttable": 1,
                    "filter": 0,
                    "sortby": "propertyname",
                    "filterfieldtype": "lookup",
                    "defaultvalue": "",
                },
                {
                    "field": "latitude",
                    "text": "Latitude",
                    "type": "text",
                    "freeze": 0,
                    "active": 1,
                    "sorttable": 1,
                    "filter": 0,
                    "sortby": "propertyname",
                    "filterfieldtype": "lookup",
                    "defaultvalue": "",
                },
                {
                    "field": "longitude",
                    "text": "Longitude",
                    "type": "text",
                    "freeze": 0,
                    "active": 1,
                    "sorttable": 1,
                    "filter": 0,
                    "sortby": "propertyname",
                    "filterfieldtype": "lookup",
                    "defaultvalue": "",
                },
                // {
                //     "field": "propertycontactno",
                //     "text": "Phone Number",
                //     "type": "text",
                //     "freeze": 0,
                //     "active": 1,
                //     "sorttable": 1,
                //     "filter": 0,
                //     "sortby": "propertycontactno",
                //     "filterfieldtype": "lookup",
                //     "defaultvalue": "",
                // },
                // {
                //     "field": "propertyemail",
                //     "text": "Email",
                //     "type": "text",
                //     "freeze": 0,
                //     "active": 1,
                //     "sorttable": 1,
                //     "filter": 0,
                //     "sortby": "propertyemail",
                //     "filterfieldtype": "lookup",
                //     "defaultvalue": "",
                // },
                {
                    "field": "propertyimage",
                    "text": "Property Image",
                    "type": "multipleimagepicker",
                    "freeze": 0,
                    "active": 1,
                    "sorttable": 0,
                    "filter": 0,
                    "defaultvalue": ""
                },

                {
                    "field": "uniqueno",
                    "text": "Unique No",
                    "type": "text",
                    "freeze": 0,
                    "active": 1,
                    "sorttable": 1,
                    "filter": 0,
                    "sortby": "uniqueno",
                    "filterfieldtype": "lookup",
                    "defaultvalue": "",
                },
                {
                    "field": "maincontactperson",
                    "text": "Contact Person",
                    "type": "text",
                    "freeze": 0,
                    "active": 1,
                    "sorttable": 1,
                    "filter": 0,
                    "sortby": "maincontactperson",
                    "filterfieldtype": "lookup",
                    "defaultvalue": "",
                    "tblsize": 30
                },
                {
                    "field": "mainpersondesignation",
                    "text": "Person Designation",
                    "type": "text",
                    "freeze": 0,
                    "active": 1,
                    "sorttable": 1,
                    "filter": 0,
                    "sortby": "mainpersondesignation",
                    "filterfieldtype": "lookup",
                    "defaultvalue": "",
                    "tblsize": 30
                },
                {
                    "field": "mainpersoncontactno",
                    "text": "Contact Person Number",
                    "type": "text",
                    "freeze": 0,
                    "active": 1,
                    "sorttable": 1,
                    "filter": 0,
                    "sortby": "mainpersoncontactno",
                    "filterfieldtype": "lookup",
                    "defaultvalue": "",
                    "tblsize": 30
                },
                {
                    "field": "maincontactpersonemail",
                    "text": "Contact Person Mail",
                    "type": "text",
                    "freeze": 0,
                    "active": 1,
                    "sorttable": 1,
                    "filter": 0,
                    "sortby": "maincontactpersonemail",
                    "filterfieldtype": "lookup",
                    "defaultvalue": "",
                    "tblsize": 30
                },

            ]
        };
    }

    getFormFieldOrder() {
        return {
            "rightsidebarsize": 800,
            "pagename": "property",
            "formname": "Property",
            "alias": "property",
            "dataview": "tab",
            "formfields": [
                {
                    "tab": "Property Details",
                    "formFields": [
                        {
                            "field": "propertyname",
                            "text": "Property Name",
                            "type": "input-text",
                            "disabled": false,
                            "defaultvisibility": true,
                            "required": true,
                            "capitalcase": true,
                            "gridsize": 375,
                            'minlength': 3,
                            "capitalcase": true

                        },
                        {
                            "field": "prefix",
                            "text": "Prefix",
                            "type": "input-text",
                            "disabled": false,
                            "defaultvisibility": true,
                            "required": true,
                            "gridsize": 375,
                            'minlength': 2,
                            "capitalcase": true,
                            'allcapital': true,
                            "regex": "[a-zA-Z0-9]",
                        },
                        {
                            "field": "propertyimage",
                            "text": "Property Image",
                            "type": "multipleimagepicker",
                            "disabled": false,
                            "defaultvisibility": true,
                            "required": false,
                            "filetypes": Config.images,
                            "gridsize": 750
                        }
                    ]
                },
                {
                    "tab": "Contact Person Details",
                    "formFields": [
                        {
                            "field": "maincontactperson",
                            "text": "Contact Person",
                            "type": "input-text",
                            "disabled": false,
                            "defaultvisibility": true,
                            "required": true,
                            "capitalcase": true,
                            "gridsize": 375
                        },
                        {
                            "field": "mainpersondesignation",
                            "text": "Person Designation",
                            "type": "input-text",
                            "disabled": false,
                            "defaultvisibility": true,
                            "required": true,
                            "gridsize": 375
                        },
                        {
                            "field": "mainpersoncontactno",
                            "text": "Contact Person Number",
                            "type": "number-input",
                            "prefixtext": "code",
                            "disabled": false,
                            "defaultvisibility": true,
                            "required": true,
                            "gridsize": 375
                        },
                        {
                            "field": "maincontactpersonemail",
                            "text": "Contact Person Email",
                            "type": "input-text",
                            "disabled": false,
                            "defaultvisibility": true,
                            "required": false,
                            "gridsize": 375
                        },
                    ]
                },
                {
                    "tab": "Address Information",
                    "formFields": [
                        {
                            "field": "latlong",
                            "text": "Latitude & Longitude",
                            "type": "latlong",
                            "disabled": false,
                            'decimalpoint': 6,
                            "defaultvisibility": true,
                            "required": true,
                            "cleanable": true,
                            "gridsize": 375,
                            "onchangefill": ["currentaddress", "area", "pincode"], /// Always Put this orderdo not Change :- Adrress on 0, Area on 1, Pincode on 2
                        },
                        {
                            "field": "addressline1",
                            "text": "Flat, House no., Building, Street",
                            "type": "input-text",
                            "disabled": false,
                            "defaultvisibility": true,
                            "required": true,
                            "gridsize": 375
                        },
                        {
                            "field": "addressline2",
                            "text": "Area, Landmark",
                            "type": "input-text",
                            "disabled": false,
                            "defaultvisibility": true,
                            "required": true,
                            "gridsize": 375
                        },
                        {
                            "field": "area",
                            "text": "Landmark",
                            "type": "input-text",
                            "disabled": false,
                            "defaultvisibility": true,
                            "required": false,
                            "gridsize": 375
                        },
                        {
                            "field": "pincode",
                            "text": "Pincode",
                            "type": "number-input",
                            "disabled": false,
                            "defaultvisibility": true,
                            "required": true,
                            "gridsize": 375
                        },
                        {
                            "field": "stateid",
                            "text": "State",
                            "type": "dropdown",
                            "disabled": false,
                            "defaultvisibility": true,
                            "required": true,
                            "gridsize": 375,
                            "masterdata": "state",
                            "masterdatafield": "state",
                            "formdatafield": "state",
                            "cleanable": true,
                            "searchable": true,
                            "onchangefill": ["cityid"],
                            "dependentfilter": { "countryid": "countryid" },
                            "masterdatadependancy": false,
                            "staticfilter": { "isactive": 1 },

                            "defaultvalue": "66acd3cb6a781176246a9637",
                        },
                        {
                            "field": "cityid",
                            "text": "City",
                            "type": "dropdown",
                            "disabled": false,
                            "defaultvisibility": true,
                            "required": true,
                            "gridsize": 375,
                            "masterdata": "city",
                            "masterdatafield": "city",
                            "formdatafield": "city",
                            "cleanable": true,
                            "searchable": true,
                            "dependentfilter": { "stateid": "stateid" },
                            "masterdatadependancy": true,
                            "staticfilter": { "isactive": 1 },
                            "defaultvalue": "6710b1a7d57b9665bf472274",



                        },
                    ]
                },

                {
                    "tab": "Other Details",
                    "formFields": [
                        {
                            "field": "gsttreatmentid",
                            "text": "GST Treatment",
                            "type": "dropdown",
                            "disabled": false,
                            "defaultvisibility": true,
                            "required": true,
                            "gridsize": 375,
                            "masterdata": "gsttreatment",
                            "masterdatafield": "gsttreatment",
                            "formdatafield": "gsttreatment",
                            "cleanable": true,
                            "searchable": true,
                            "masterdatadependancy": false,
                            "staticfilter": { "isactive": 1 },
                            "storeextrakeys": {
                                "isgstnumber": "isgstnumber"
                            }
                        },
                        {
                            "field": "gstin_uin",
                            "tooltip": "GST Identification Number or Unique Identification Number",
                            "text": "GSTIN / UIN",
                            "type": "input-text",
                            "disabled": false,
                            "defaultvisibility": false,
                            "required": true,
                            "gridsize": 375,
                            "condition": {
                                "isgstnumber": [1]
                            }
                        },
                        {
                            "field": "documents",
                            "text": "Document Name",
                            "type": "multipleFilePickerfieldwithtitle",
                            "disabled": false,
                            "defaultvisibility": true,
                            "required": true,
                            "gridsize": 375
                        }
                    ],
                },
            ]
        };
    }
}


export class PropertyWing {
    constructor() {
        this._id
        this.propertyid = { type: mongoose.Schema.Types.ObjectId, ref: "tblproperty" }
        this.propertyname = { type: String, required: [true, 'Property is required'], trim: true }
        this.wingimage = Config.getImageModel()
        this.wingname = { type: String, required: [true, 'Wingnmae is required'], trim: true }
        this.isactive = { type: Number, default: 1 }
        this.floorcount = { type: Number, default: 0 }
        this.unitcount = { type: Number, default: 0 }
        this.areacount = { type: Number, default: 0 }
        this.amenities = [{
            amenitiesid: { type: mongoose.Schema.Types.ObjectId, ref: "tblamenitiestypemaster" },
            amenities: { type: String },
        }]
        this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: "recordinfo" }
    }

    getDataName() {
        return "Wing"
    }

    getIndexes() {
        return [[{ propertyid: 1, wingname: 1 }, { unique: 1 }]]
    }

    getFieldOrder() {
        const Config = new _Config()
        return {
            fields: [
                {
                    field: 'action_button',
                    text: '',
                    type: Config.getHtmlcontorls()['action_button'],
                    freeze: 1,
                    active: 1,
                    sorttable: 0,
                    filter: 0,
                    disableflex: 1,
                    filterfieldtype: Config.getHtmlcontorls()['lookup'],
                    defaultvalue: '',
                    tblsize: 10
                },
                {
                    field: 'isactive',
                    text: 'Status',
                    type: Config.getHtmlcontorls()['isactive'],
                    freeze: 1,
                    active: 1,
                    sorttable: 0,
                    filter: 0,
                    disableflex: 1,
                    filterfieldtype: Config.getHtmlcontorls()['lookup'],
                    defaultvalue: '',
                    tblsize: Config.getTblgridsizeclasses()[15]
                },

                {
                    field: "wingname",
                    text: "Wing Name",
                    type: Config.getHtmlcontorls()["text"],
                    freeze: 0,
                    active: 1,
                    sorttable: 1,
                    filter: 0,
                    filterfieldtype: Config.getHtmlcontorls()["lookup"],
                    defaultvalue: "",
                    tblsize: Config.getTblgridsizeclasses()[15]

                },
                // {
                //     field: 'wingimage',
                //     text: 'Wing Image',
                //     type: "multipleimagepicker",
                //     freeze: 0,
                //     active: 1,
                //     sorttable: 0,
                //     filter: 0,
                //     disableflex: 1,
                //     filterfieldtype: Config.getHtmlcontorls()['lookup'],
                //     defaultvalue: '',
                //     tblsize: Config.getTblgridsizeclasses()[15]
                // },
                {
                    field: "propertyname",
                    text: "Property Name",
                    type: Config.getHtmlcontorls()["text"],
                    freeze: 0,
                    active: 1,
                    sorttable: 1,
                    filter: 0,
                    filterfieldtype: Config.getHtmlcontorls()["lookup"],
                    defaultvalue: "",
                    tblsize: Config.getTblgridsizeclasses()[15]

                },
                {
                    field: "floorcount",
                    text: "Floor(s)",
                    type: Config.getHtmlcontorls()["number-count"],
                    freeze: 0,
                    active: 1,
                    sorttable: 1,
                    filter: 0,
                    filterfieldtype: Config.getHtmlcontorls()["lookup"],
                    defaultvalue: "",
                },
                {
                    field: "unitcount",
                    text: "Unit(s)",
                    type: Config.getHtmlcontorls()["number-count"],
                    freeze: 0,
                    active: 1,
                    sorttable: 1,
                    filter: 0,
                    filterfieldtype: Config.getHtmlcontorls()["lookup"],
                    defaultvalue: "",
                },
                {
                    "field": "amenities",
                    "text": "Amenities",
                    "type": "text-array",
                    "freeze": 0,
                    "active": 1,
                    "sorttable": 0,
                    "filter": 1,
                    "filterfieldtype": "multipleselectdropdown",
                    'filterfield': 'amenitiestype',
                    "masterdata": "amenitiestype",
                    "masterdatafield": "amenitiestype",
                    "formdatafield": "amenitiestypeid",
                    "defaultvalue": [],
                    "masterdatadependancy": false,
                    "staticfilter": { "isactive": 1 }
                },
            ]
        }
    }

    getFormFieldOrder() {
        return {
            "rightsidebarsize": 400,
            "pagename": "wing",
            "formname": "Wing",
            "alias": "wing",
            "dataview": "tab",
            "formfields": [
                {
                    "tab": "Wing",
                    "formFields": [
                        {
                            "field": "wingname", "text": "Wing Name", "type": "input-text", "disabled": false, "defaultvisibility": true, "required": true, "gridsize": 375, "capitalcase": true,
                        },

                        // {
                        //     "field": "floorcount",
                        //     "text": "Number of Floors",
                        //     "type": "number-input",
                        //     "disabled": false,
                        //     "defaultvisibility": true,
                        //     "required": true,
                        //     "gridsize": 375
                        // },
                        // {
                        //     "field": "unitcount",
                        //     "text": "Number of Units",
                        //     "type": "number-input",
                        //     "disabled": false,
                        //     "defaultvisibility": true,
                        //     "required": true,
                        //     "gridsize": 375
                        // },

                        // {
                        //     "field": "amenities",
                        //     "text": "Amenities",
                        //     "type": "multipleselectdropdown",
                        //     "disabled": false,
                        //     "defaultvisibility": true,
                        //     "required": false,
                        //     "gridsize": 375,
                        //     "masterdata": "amenitiestype",
                        //     "masterdatafield": "amenitiestype",
                        //     "formdatafield": "amenities",
                        //     "cleanable": true,
                        //     "searchable": true,
                        //     "masterdatadependancy": false,
                        //     "staticfilter": {
                        //         "isactive": 1
                        //     }
                        // },
                        {
                            "field": "wingimage",
                            "text": "Wing Images",
                            "type": "multipleimagepicker",
                            "disabled": false,
                            "defaultvisibility": true,
                            "required": false,
                            "filetypes": Config.images,
                            "gridsize": 375
                        },

                    ]
                }
            ]
        };
    }


}

export class PropertyFloor {
    constructor() {
        this._id
        this.propertyid = { type: mongoose.Schema.Types.ObjectId, ref: "tblproperty" }
        this.propertyname = { type: String, required: [true, 'Property is required'] }
        this.wingid = { type: mongoose.Schema.Types.ObjectId, ref: "tblpropertywing" }
        this.wingname = { type: String, required: [true, 'Wingname is required'] }
        this.floor = { type: String, default: "", required: [true, 'Floor is required'] }
        this.floorarea = { type: String, default: "", }
        this.isactive = { type: Number, default: 1 }
        this.unitcount = { type: Number, default: 0 }
        this.areacount = { type: Number, default: 0 }
        this.floorplan = Config.getImageModel()
        this.amenities = [{
            amenitiesid: { type: mongoose.Schema.Types.ObjectId, ref: "tblamenitiestypemaster" },
            amenities: { type: String },
        }]
        this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: "recordinfo" }
    }
    getDataName() {
        return "Floor"
    }

    getIndexes() {
        return [[{ propertyid: 1, wingid: 1, floor: 1 }, { unique: 1 }]]
    }

    getFieldOrder() {
        const Config = new _Config()
        return {
            fields: [
                {
                    field: 'action_button',
                    text: '',
                    type: Config.getHtmlcontorls()['action_button'],
                    freeze: 1,
                    active: 1,
                    sorttable: 0,
                    filter: 0,
                    disableflex: 1,
                    filterfieldtype: Config.getHtmlcontorls()['lookup'],
                    defaultvalue: '',
                    tblsize: 10
                },
                {
                    field: 'isactive',
                    text: 'Status',
                    type: Config.getHtmlcontorls()['isactive'],
                    freeze: 1,
                    active: 1,
                    sorttable: 0,
                    filter: 0,
                    disableflex: 1,
                    filterfieldtype: Config.getHtmlcontorls()['lookup'],
                    defaultvalue: '',
                    tblsize: 15

                }, {
                    field: "wingname",
                    text: "Wing Name",
                    type: Config.getHtmlcontorls()["text"],
                    freeze: 0,
                    active: 1,
                    sorttable: 1,
                    filter: 0,
                    filterfieldtype: Config.getHtmlcontorls()["multipleselectdropdown"],
                    apipath: "property/wing", //api path
                    masterdata: "wing",
                    masterdatafield: "wingname",
                    formdatafield: "wingid",
                    staticfilter: { isactive: 1, },
                    viewfilter: 1,
                    tblsize: 20
                },
                {
                    field: "floor",
                    text: "Floor",
                    type: Config.getHtmlcontorls()["text"],
                    freeze: 0,
                    active: 1,
                    sorttable: 1,
                    filter: 0,
                    disableflex: 1,
                    filterfieldtype: Config.getHtmlcontorls()["lookup"],
                    defaultvalue: "",
                    tblsize: 15

                },

                {
                    field: "unitcount",
                    text: "Unit(s)",
                    type: Config.getHtmlcontorls()["number-count"],
                    freeze: 0,
                    active: 1,
                    sorttable: 1,
                    filter: 0,

                    filterfieldtype: Config.getHtmlcontorls()["lookup"],
                    defaultvalue: "",
                    tblsize: 15

                },
                // {
                //     "field": "amenities",
                //     "text": "Amenities",
                //     "type": "text-array",
                //     "freeze": 0,
                //     "active": 1,
                //     "sorttable": 0,
                //     "filter": 1,
                //     "filterfieldtype": "multipleselectdropdown",
                //     'filterfield': 'amenitiestype',
                //     "masterdata": "amenitiestype",
                //     "masterdatafield": "amenitiestype",
                //     "formdatafield": "amenitiestypeid",
                //     "defaultvalue": [],
                //     "masterdatadependancy": false,
                //     "staticfilter": { "isactive": 1 }
                // },
                {
                    field: "floorarea",
                    text: "Floor Area(Sq. Ft)",
                    type: Config.getHtmlcontorls()["text"],
                    freeze: 0,
                    active: 1,
                    sorttable: 1,
                    filter: 0,
                    disableflex: 1,
                    filterfieldtype: Config.getHtmlcontorls()["lookup"],
                    defaultvalue: "",
                    tblsize: 15

                },
                {
                    field: "floorplan",
                    text: "Floor Plan",
                    type: Config.getHtmlcontorls()["image"],
                    freeze: 0,
                    active: 1,
                    sorttable: 0,
                    filter: 0,
                    filterfieldtype: Config.getHtmlcontorls()["image"],
                    defaultvalue: "",
                    tblsize: 15

                },
                // {
                //     "field": "areatype",
                //     "text": "Area Type",
                //     "type": "text-array",
                //     "isonlyfilter": 1,
                //     "freeze": 0,
                //     "active": 0,
                //     "sorttable": 0,
                //     "filter": 1,
                //     "filterfieldtype": "multipleselectdropdown",
                //     'filterfield': 'areatype',
                //     // "apipath": "property/wing",
                //     "masterdata": "areatype",
                //     "masterdatafield": "areatype",
                //     "formdatafield": "areatypeid",
                //     "defaultvalue": [],
                //     "masterdatadependancy": false,
                //     "staticfilter": { "isactive": 1 }
                // },
                // {
                //     "field": "amenities",
                //     "text": "Amenities",
                //     "type": "multipleselectdropdown",
                //     "disabled": false,
                //     "defaultvisibility": true,
                //     "required": true,
                //     "gridsize": 375,
                //     "masterdata": "amenitiestype",
                //     "masterdatafield": "amenitiestype",
                //     "formdatafield": "amenitiestype",
                //     "cleanable": true,
                //     "searchable": true,
                //     "masterdatadependancy": false,
                //     "staticfilter": {
                //         "isactive": 1
                //     }
                // },

            ]
        }
    }

    getFormFieldOrder() {
        return {
            "rightsidebarsize": 400,
            "pagename": "Floor",
            "formname": "floor",
            "alias": "floor",
            "dataview": "tab",
            "formfields": [
                {
                    "tab": "Floor",
                    "formFields": [
                        {
                            'field': 'wingid',
                            'text': 'Wing Name',
                            'type': Config.getHtmlcontorls()["kDropDown"],
                            'disabled': false,
                            'defaultvisibility': true,
                            'required': true,
                            'gridsize': 375,
                            'masterdata': 'property/wing',
                            'masterdatafield': 'wingname',
                            'formdatafield': 'wingname',
                            'cleanable': true,
                            'searchable': true,
                            'masterdatadependancy': false,
                            // "staticfilter": { "propertyid": $propertyid }
                        },
                        {
                            "field": "floor",
                            "text": "Floor Name",
                            "type": "input-text",
                            "disabled": false,
                            "defaultvisibility": true,
                            "required": true,
                            "gridsize": 375,

                        },

                        // {
                        //     "field": "unitcount",
                        //     "text": "Number of Units",
                        //     "type": "number-input",
                        //     "disabled": false,
                        //     "defaultvisibility": true,
                        //     "required": true,
                        //     "gridsize": 375
                        // },
                        {
                            "field": "floorarea",
                            "text": "Floor Area(Sq. Ft)",
                            "type": "number-input",
                            "disabled": false,
                            "defaultvisibility": true,
                            "required": true,
                            "gridsize": 375,

                        },

                        // {
                        //     "field": "areatypeid",
                        //     "text": "Area Type",
                        //     "type": "multipleselectdropdown",
                        //     "disabled": false,
                        //     "defaultvisibility": true,
                        //     "required": false,
                        //     "gridsize": 375,
                        //     "masterdata": "areatype",
                        //     "masterdatafield": "areatype",
                        //     "formdatafield": "areatype",
                        //     "cleanable": true,
                        //     "searchable": true,
                        //     "masterdatadependancy": false,
                        //     "staticfilter": {
                        //         "isactive": 1
                        //     }
                        // },
                        // {
                        //     "field": "amenities",
                        //     "text": "Amenities",
                        //     "type": "multipleselectdropdown",
                        //     "disabled": false,
                        //     "defaultvisibility": true,
                        //     "required": true,
                        //     "gridsize": 375,
                        //     "masterdata": "amenitiestype",
                        //     "masterdatafield": "amenitiestype",
                        //     "formdatafield": "amenities",
                        //     "cleanable": true,
                        //     "searchable": true,
                        //     "masterdatadependancy": false,
                        //     "staticfilter": {
                        //         "isactive": 1
                        //     }
                        // },
                        {
                            'field': 'floorplan',
                            'text': 'Floor Plan',
                            'type': Config.getHtmlcontorls()["file"],
                            'disabled': false,
                            'defaultvisibility': true,
                            'required': false,
                            'filetypes': Config.pdfAndImage,
                            'defaultvalue': {},
                            "gridsize": 375
                        },
                        // {
                        //     "field": "occupancystatusid",
                        //     "text": "Occupancy Status",
                        //     "type": "dropdown",
                        //     "disabled": false,
                        //     "defaultvisibility": true,
                        //     "required": false,
                        //     "gridsize": 375,
                        //     "masterdata": "occupancystatus",
                        //     "masterdataarray": [
                        //         { "label": "Fully Occupied", "value": '1' },
                        //         { "label": "Haf Occupied", "value": '2' },
                        //         { "label": "Other", "value": '3' },
                        //     ],
                        //     "defaultvalue": '1',
                        //     "formdatafield": "occupancystatus",
                        //     "cleanable": true,
                        //     "searchable": true,
                        //     "masterdatadependancy": false
                        // },
                    ]
                }
            ]
        }
    }
}

export class PropertyUnit {
    constructor() {
        this._id
        this.propertyid = { type: mongoose.Schema.Types.ObjectId, ref: "tblproperty" }
        this.propertyname = { type: String, required: [true, 'Property is required'] }
        this.wingid = { type: mongoose.Schema.Types.ObjectId, ref: "tblpropertywing" }
        this.wingname = { type: String, required: [true, 'wingname is required'] }
        this.floorid = { type: mongoose.Schema.Types.ObjectId, ref: "tblpropertyfloor" }
        this.floor = { type: String, required: [true, 'Floor is required'] }
        this.unitname = { type: String, required: [true, 'unit is required'] }
        this.isactive = { type: Number, default: 1 }
        this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: "recordinfo" }
    }

    getDataName() {
        return "Unit"
    }

    getIndexes() {
        return [[{ propertyid: 1, wingid: 1, floorid: 1, unitname: 1 }, { unique: 1 }]]
    }

    getFieldOrder() {
        const Config = new _Config()
        return {
            fields: [
                {
                    field: 'action_button',
                    text: '',
                    type: Config.getHtmlcontorls()['action_button'],
                    freeze: 1,
                    active: 1,
                    sorttable: 0,
                    filter: 0,
                    disableflex: 1,
                    filterfieldtype: Config.getHtmlcontorls()['lookup'],
                    defaultvalue: '',
                    tblsize: 10
                },
                {
                    field: 'isactive',
                    text: 'Status',
                    type: Config.getHtmlcontorls()['isactive'],
                    freeze: 1,
                    active: 1,
                    sorttable: 0,
                    filter: 0,
                    disableflex: 1,
                    filterfieldtype: Config.getHtmlcontorls()['lookup'],
                    defaultvalue: '',
                    tblsize: 15
                },
                {
                    field: "wingname",
                    text: "Wing Name",
                    type: Config.getHtmlcontorls()["text"],
                    freeze: 0,
                    active: 1,
                    sorttable: 1,
                    filter: 0,
                    defaultvalue: '',
                    staticfilter: { isactive: 1 },
                    viewfilter: 1,
                    tblsize: 15
                },
                {
                    field: "floor",
                    text: "Floor",
                    type: Config.getHtmlcontorls()["text"],
                    freeze: 0,
                    active: 1,
                    sorttable: 1,
                    filter: 0,
                    filterfieldtype: Config.getHtmlcontorls()["lookup"],
                    defaultvalue: "",
                    tblsize: 15

                },
                {
                    field: "unitname",
                    text: "Unit",
                    type: Config.getHtmlcontorls()["text"],
                    freeze: 0,
                    active: 1,
                    sorttable: 1,
                    filter: 0,
                    filterfieldtype: Config.getHtmlcontorls()["lookup"],
                    defaultvalue: "",
                    tblsize: 15

                },
                {
                    field: "unitbuiltarea",
                    text: "Unit",
                    type: Config.getHtmlcontorls()["text"],
                    freeze: 0,
                    active: 1,
                    sorttable: 1,
                    filter: 0,
                    filterfieldtype: Config.getHtmlcontorls()["lookup"],
                    defaultvalue: "",
                    tblsize: 7

                },
                {
                    field: "unitcarpetarea",
                    text: "Unit",
                    type: Config.getHtmlcontorls()["text"],
                    freeze: 0,
                    active: 1,
                    sorttable: 1,
                    filter: 0,
                    filterfieldtype: Config.getHtmlcontorls()["lookup"],
                    defaultvalue: "",
                    tblsize: 7

                },
            ]
        }
    }

    getFormFieldOrder() {
        return {
            "rightsidebarsize": 400,
            "pagename": "Unit",
            "formname": "unit",
            "alias": "unit",
            "dataview": "tab",
            "formfields": [
                {
                    "tab": "Unit",
                    "formFields": [

                        {
                            'field': 'wingid',
                            'text': 'Wing Name',
                            'type': Config.getHtmlcontorls()["kDropDown"],
                            'disabled': false,
                            'defaultvisibility': true,
                            'required': true,
                            'gridsize': 375,
                            'masterdata': 'property/wing',
                            'masterdatafield': 'wingname',
                            'formdatafield': 'wingname',
                            'cleanable': true,
                            'searchable': true,
                            'onchangefill': ['floorid'],
                            'masterdatadependancy': false,

                        },
                        {
                            'field': 'floorid',
                            'text': 'Floor',
                            'type': Config.getHtmlcontorls()["kDropDown"],
                            'disabled': false,
                            'defaultvisibility': true,
                            'required': true,
                            'gridsize': 375,
                            'masterdata': 'property/floor',
                            'masterdatafield': 'floor',
                            'formdatafield': 'floor',
                            'cleanable': true,
                            'searchable': true,
                            "dependentfilter": {
                                "wingid": "wingid"
                            },
                            "masterdatadependancy": true,
                        },
                        {
                            "field": "unitname",
                            "text": "Unit Name",
                            "type": "input-text",
                            "disabled": false,
                            "defaultvisibility": true,
                            "required": true,
                            "gridsize": 375
                        },
                        {
                            "field": "flattypeid",
                            "text": "Unit Type",
                            "type": "dropdown",
                            "disabled": false,
                            "defaultvisibility": true,
                            "required": false,
                            "gridsize": 375,
                            "masterdata": "flattype",
                            "masterdataarray": [
                                { "label": "1 BHK", "value": '1' },
                                { "label": "2 BHK", "value": '2' },
                                { "label": "3 BHK", "value": '3' },
                            ],
                            "defaultvalue": '1',
                            "formdatafield": "flattype",
                            "cleanable": true,
                            "searchable": true,
                            "masterdatadependancy": false
                        },
                        {
                            "field": "unitbuiltarea",
                            "text": "Flat Built Area",
                            "type": "input-text",
                            "disabled": false,
                            "defaultvisibility": true,
                            "required": false,
                            "gridsize": 375
                        },
                        {
                            "field": "unitcarpetarea",
                            "text": "Flat Carpet Area",
                            "type": "input-text",
                            "disabled": false,
                            "defaultvisibility": true,
                            "required": false,
                            "gridsize": 375
                        },
                        // {
                        //     "field": "occupancystatus",
                        //     "text": "Occupancy Status",
                        //     "type": "dropdown",
                        //     "disabled": false,
                        //     "defaultvisibility": true,
                        //     "required": false,
                        //     "gridsize": 375,
                        //     "masterdata": "occupancystatus",
                        //     "masterdataarray": [
                        //         { "label": "Fully Occupied", "value": '1' },
                        //         { "label": "Haf Occupied", "value": '2' },
                        //         { "label": "Other", "value": '3' },
                        //     ],
                        //     "defaultvalue": '1',
                        //     "formdatafield": "occupancystatus",
                        //     "cleanable": true,
                        //     "searchable": true,
                        //     "masterdatadependancy": false
                        // },
                        // {
                        //     "field": "parkingspaceallocated",
                        //     "text": "Parking Space Allocated",
                        //     "type": "dropdown",
                        //     "disabled": false,
                        //     "defaultvisibility": true,
                        //     "required": false,
                        //     "gridsize": 375,
                        //     "masterdata": "parkingspaceallocated",
                        //     "masterdataarray": Config.getYesNoType(),
                        //     "defaultvalue": '1',
                        //     "formdatafield": "parkingspaceallocated",
                        //     "cleanable": true,
                        //     "searchable": true,
                        //     "masterdatadependancy": false
                        // },
                    ]
                }
            ]
        }
    }
}

export class PropertyArea {
    constructor() {
        this._id
        this.propertyid = { type: mongoose.Schema.Types.ObjectId, ref: "tblproperty" }
        this.propertyname = { type: String, required: [true, 'Property is required'] }
        this.wingid = { type: mongoose.Schema.Types.ObjectId, ref: "tblpropertybuilding" }
        this.wingname = { type: String, default: "" }
        this.floorid = { type: mongoose.Schema.Types.ObjectId, ref: "tblpropertyfloor" }
        this.floor = { type: String, default: "" }
        this.area = { type: String, required: true }
        this.areatypeid = { type: mongoose.Schema.Types.ObjectId, ref: "tblareatypemaster" }
        this.areatype = { type: String, required: [true, 'Area Type is required'] }
        this.areaplan = { type: String, default: "" }
        this.commonarea = { type: Number, default: 0 }
        this.image = { type: Object, default: "" }
        this.description = { type: String }
        this.isactive = { type: Number, default: 1 }
        this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: "recordinfo" }
    }

    getDataName() {
        return "Area"
    }

    getIndexes() {
        return [[{ propertyid: 1, wingid: 1, wingid: 1, floorid: 1, area: 1 }, { unique: 1 }]]
    }

    getFieldOrder() {
        const Config = new _Config()
        return {
            fields: [
                {
                    field: 'action_button',
                    text: '',
                    type: Config.getHtmlcontorls()['action_button'],
                    freeze: 1,
                    active: 1,
                    sorttable: 0,
                    filter: 0,
                    disableflex: 1,
                    filterfieldtype: Config.getHtmlcontorls()['lookup'],
                    defaultvalue: '',
                    tblsize: 10
                },
                {
                    field: 'isactive',
                    text: 'Status',
                    type: Config.getHtmlcontorls()['isactive'],
                    freeze: 1,
                    active: 1,
                    sorttable: 0,
                    filter: 0,
                    disableflex: 1,
                    filterfieldtype: Config.getHtmlcontorls()['lookup'],
                    defaultvalue: '',
                    tblsize: 15
                },
                {
                    field: "areatype",
                    text: "Area Type",
                    type: Config.getHtmlcontorls()["text"],
                    freeze: 0,
                    active: 1,
                    sorttable: 1,
                    filter: 0,
                    defaultvalue: "",
                    tblsize: 15
                },
                {
                    field: "area",
                    text: "Area",
                    type: Config.getHtmlcontorls()["text"],
                    freeze: 0,
                    active: 1,
                    sorttable: 1,
                    filter: 0,
                    filterfieldtype: Config.getHtmlcontorls()["lookup"],
                    defaultvalue: "",
                    tblsize: 15
                },
                {
                    field: "floor",
                    text: "Floor",
                    type: Config.getHtmlcontorls()["text"],
                    freeze: 0,
                    active: 1,
                    sorttable: 1,
                    filter: 0,
                    defaultvalue: '',
                    staticfilter: { isactive: 1 },
                    tblsize: 15
                },

                {
                    field: "wingname",
                    text: "Wing Name",
                    type: Config.getHtmlcontorls()["text"],
                    freeze: 0,
                    active: 1,
                    sorttable: 1,
                    filter: 0,
                    defaultvalue: '',
                    tblsize: 20
                    // staticfilter: { isactive: 1 },

                },
            ]
        }
    }

    getFormFieldOrder() {
        return {
            "rightsidebarsize": 400,
            "pagename": "Area",
            "formname": "area",
            "alias": "Area",
            "dataview": "tab",
            "formfields": [

                {
                    "tab": "Area",
                    "formFields": [
                        {
                            "field": "commonarea",
                            "text": "Common area?",
                            "type": "checkbox",
                            "disabled": false,
                            "required": false,
                            "defaultvisibility": true,
                            "gridsize": 375
                        },

                        {
                            'field': 'wingid',
                            'text': 'Wing Name',
                            'type': Config.getHtmlcontorls()["kDropDown"],
                            'disabled': false,
                            'defaultvisibility': true,
                            'required': true,
                            'gridsize': 375,
                            'masterdata': 'property/wing',
                            'masterdatafield': 'wingname',
                            'formdatafield': 'wingname',
                            'cleanable': true,
                            'searchable': true,
                            'onchangefill': ['floorid'],
                            'masterdatadependancy': false,
                            'condition': {
                                'commonarea': [0]
                            }
                        },
                        {
                            'field': 'floorid',
                            'text': 'Floor',
                            'type': Config.getHtmlcontorls()["kDropDown"],
                            'disabled': false,
                            'defaultvisibility': true,
                            'required': true,
                            'gridsize': 375,
                            'masterdata': 'property/floor',
                            'masterdatafield': 'floor',
                            'formdatafield': 'floor',
                            'cleanable': true,
                            'searchable': true,
                            "dependentfilter": {
                                "wingid": "wingid"
                            },
                            "masterdatadependancy": true,
                            'condition': {
                                'commonarea': [0]
                            }
                        },


                        {
                            "field": "areatypeid",
                            "text": "Area Type",
                            "type": "dropdown",
                            "disabled": false,
                            "defaultvisibility": true,
                            "required": true,
                            "gridsize": 375,
                            "masterdata": "areatype",
                            "masterdatafield": "areatype",
                            "formdatafield": "areatype",
                            "cleanable": true,
                            "searchable": true,
                            "masterdatadependancy": false,
                            "staticfilter": {
                                "isactive": 1
                            }
                        },
                        {
                            "field": "area",
                            "text": "Area Name",
                            "type": "input-text",
                            "disabled": false,
                            "defaultvisibility": true,
                            "required": true,
                            "gridsize": 375
                        },
                        {
                            'field': 'image',
                            'text': 'Image',
                            'type': "multipleimagepicker",
                            'disabled': false,
                            'defaultvisibility': true,
                            'required': false,
                            'filetypes': ["png"],
                            'gridsize': 375,

                        },
                        {
                            "field": "description",
                            "text": "Description",
                            "height": 400,
                            "type": "htmleditor",
                            "disabled": false,
                            "defaultvisibility": true,
                            "required": false,
                            'condition': {
                                'commonarea': [1]
                            }
                        },
                    ]
                },


            ]
        }
    }
}


export class PropertyFacility {
    constructor() {
        this._id
        this.facility = { type: String, required: [true, 'Facility is required'] }
        this.propertyid = { type: mongoose.Schema.Types.ObjectId, ref: "tblproperty" }
        this.property = { type: String, required: [true, 'Property is required'] }
        this.areaid = { type: mongoose.Schema.Types.ObjectId, ref: "tblpropertyarea" }
        this.area = { type: String, default: "" }
        this.capacitycount = { type: String, required: true }
        this.charges = { type: String } // per slot
        //information
        this.capacitydescription = { type: String }
        this.amenities = { type: String }
        this.description = { type: String }
        this.rules_regulations = { type: String }
        //contact
        this.contact = { type: String, trim: true }
        this.contact_countrycode = { type: String, trim: true }
        this.email = { type: String }
        this.areaplan = { type: String, default: "" }
        this.facilityimage = [Config.getImageModel()]
        //timeslot
        this.timeslot = [{
            starttime: { type: String, required: true },
            endtime: { type: String, required: true }
        }]
        this.disableslot = [{
            starttime: { type: String },
            endtime: { type: String },
            slotid: { type: mongoose.Schema.Types.ObjectId },
            isdisabled: { type: Number, default: 1 }
        }]
        this.iscommonarea = { type: Number, default: 0 }
        this.isbookable = { type: Number, default: 0 }
        //rating
        this.rating = [{
            customerid: { type: mongoose.Schema.Types.ObjectId, ref: "tblcustomer" },
            customer: { type: String },
            rating: { type: String },
            date: { type: String }
        }]
        this.isactive = { type: Number, default: 1 }
        this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: "recordinfo" }
    }

    getDataName() {
        return "Facility"
    }

    getIndexes() {
        return [[{ propertyid: 1, facility: 1 }, { unique: 1 }]]
    }

    getFieldOrder() {
        const Config = new _Config()
        return {
            fields: [
                {
                    field: 'action_button',
                    text: '',
                    type: Config.getHtmlcontorls()['action_button'],
                    freeze: 1,
                    active: 1,
                    sorttable: 0,
                    filter: 0,
                    disableflex: 1,
                    filterfieldtype: Config.getHtmlcontorls()['lookup'],
                    defaultvalue: '',
                    tblsize: 10
                },
                {
                    field: 'isactive',
                    text: 'Status',
                    type: Config.getHtmlcontorls()['isactive'],
                    freeze: 1,
                    active: 1,
                    sorttable: 0,
                    filter: 0,
                    disableflex: 1,
                    filterfieldtype: Config.getHtmlcontorls()['lookup'],
                    defaultvalue: '',
                    tblsize: 15
                },
                {
                    field: "facility",
                    text: "Facility",
                    type: Config.getHtmlcontorls()["text"],
                    freeze: 0,
                    active: 1,
                    sorttable: 1,
                    filter: 0,
                    filterfield: "areaid",
                    filterfieldtype: Config.getHtmlcontorls()["dropdown"],
                    apipath: "facility", //api path
                    masterdata: "facility",
                    masterdatafield: "facility",
                    formdatafield: "facility",
                    defaultvalue: [],
                    tblsize: 15
                    // staticfilter: { isactive: 1 },
                },
                // {
                //     field: ["wing", "floor"],
                //     text: "Wing / Floor",
                //     type: Config.getHtmlcontorls()["field-group"],
                //     freeze: 0,
                //     active: 1,
                //     sorttable: 0,
                //     filter: 0,
                //     filterfieldtype: Config.getHtmlcontorls()["field-group"],
                //     apipath: "property/building", //api path
                //     masterdata: "building",
                //     masterdatafield: "buildingname",
                //     formdatafield: "buildingid",
                //     onchangefill: ["wingname"],
                //     onchangedata: ["buildingname"],
                //     defaultvalue: [],
                //     tblsize: 15
                //     // staticfilter: { isactive: 1 },
                // },

                // {
                //     field: "area",
                //     text: "Area",
                //     type: Config.getHtmlcontorls()["text"],
                //     freeze: 0,
                //     active: 1,
                //     sorttable: 1,
                //     filter: 1,
                //     filterfieldtype: Config.getHtmlcontorls()["dropdown"],
                //     'masterdata': 'property/area',
                //     'masterdatafield': 'area',
                //     'formdatafield': 'area',
                //     filterfield: "areaid",
                //     defaultvalue: [],
                //     staticfilter: { isactive: 1 },
                //     masterdatadependancy: true,
                //     // dependentfilter: { wingid: "wingid" },
                //     tblsize: 15

                // },
                {
                    "field": "area",
                    "text": "Area",
                    "type": Config.getHtmlcontorls()["text"],
                    "freeze": 0,
                    "active": 0,
                    "sorttable": 1,
                    "isonlyfilter": 1,
                    "sortby": "area",
                    "filter": 1,
                    "filterfieldtype": "dropdown",
                    "filterfield": "areaid",
                    'masterdata': 'property/area',
                    'masterdatafield': 'area',
                    'formdatafield': 'area',
                    "tblsize": 15
                },

                {
                    field: "capacitycount",
                    text: "Capacity (Persons)",
                    type: Config.getHtmlcontorls()["text"],
                    freeze: 0,
                    active: 1,
                    sorttable: 1,
                    filter: 0,
                    filterfieldtype: Config.getHtmlcontorls()["lookup"],
                    defaultvalue: "",
                    tblsize: 15
                },
                {
                    field: "charges",
                    text: "Charges (₹) Per Slot",
                    type: Config.getHtmlcontorls()["text"],
                    freeze: 0,
                    active: 1,
                    sorttable: 1,
                    filter: 0,
                    filterfieldtype: Config.getHtmlcontorls()["text"],
                    defaultvalue: "",
                    tblsize: Config.getTblgridsizeclasses()["tbl-w100"]
                },
                {
                    field: "contact",
                    text: "Contact",
                    type: Config.getHtmlcontorls()["text"],
                    freeze: 0,
                    active: 1,
                    sorttable: 0,
                    filter: 0,
                    filterfieldtype: Config.getHtmlcontorls()["text"],
                    defaultvalue: "",
                    tblsize: Config.getTblgridsizeclasses()["tbl-w100"]
                },
                {
                    field: "isbookable",
                    text: "Is Bookable?",
                    type: Config.getHtmlcontorls()["text"],
                    freeze: 0,
                    active: 0,
                    sorttable: 0,
                    filter: 1,
                    filterfield: 'isbookable',
                    masterdata: 'isbookable',
                    formdatafield: 'isbookable',
                    masterdatafield: 'isbookable',
                    filterfieldtype: Config.getHtmlcontorls()["dropdown"],
                    'masterdataarray': Config.getYesNoType(),
                    defaultvalue: "",
                    tblsize: Config.getTblgridsizeclasses()["tbl-w100"]
                },
                {
                    field: "email",
                    text: "Email",
                    type: Config.getHtmlcontorls()["text"],
                    freeze: 0,
                    active: 1,
                    sorttable: 0,
                    filter: 0,
                    filterfieldtype: Config.getHtmlcontorls()["text"],
                    defaultvalue: "",
                    tblsize: Config.getTblgridsizeclasses()["tbl-w100"]
                },
                // {
                //     field: "bookfacility",
                //     text: "Book",
                //     buttonname: 'Book Facility',
                //     type: Config.getHtmlcontorls()["button-action"],
                //     freeze: 0,
                //     active: 1,
                //     sorttable: 0,
                //     filter: 0,
                //     filterfieldtype: Config.getHtmlcontorls()["image"],
                //     defaultvalue: "",
                //     tblsize: Config.getTblgridsizeclasses()["tbl-w100"]
                // },
                // {
                //     field: "checkavailablity",
                //     text: "Availability",
                //     buttonname: 'Check Availability',
                //     type: Config.getHtmlcontorls()["button-action"],
                //     freeze: 0,
                //     active: 1,
                //     sorttable: 0,
                //     filter: 0,
                //     filterfieldtype: Config.getHtmlcontorls()["image"],
                //     defaultvalue: "",
                //     tblsize: Config.getTblgridsizeclasses()["tbl-w100"]
                // },
            ]
        }
    }

    getFormFieldOrder() {
        return {
            "rightsidebarsize": 800,
            "pagename": "Facility",
            "formname": "Facility",
            "alias": "facility",
            "dataview": "tab",
            "formfields": [
                {
                    "tab": "Facility Details",
                    "formFields": [
                        {
                            "field": "facility",
                            "text": "Facility Name",
                            "type": "input-text",
                            "disabled": false,
                            "defaultvisibility": true,
                            "required": true,
                            "capitalcase": true,
                            "gridsize": 375,
                        },
                        // {
                        //     "field": "iscommonarea",
                        //     "text": "is Common",
                        //     "type": "checkbox",
                        //     "disabled": false,
                        //     "required": false,
                        //     "defaultvisibility": true,
                        //     "gridsize": 350,
                        // },
                        // {
                        //     'field': 'wingid',
                        //     'text': 'Wing Name',
                        //     'type': 'dropdown',
                        //     'disabled': false,
                        //     'defaultvisibility': true,
                        //     'required': true,
                        //     'gridsize': 375,
                        //     'masterdata': 'property/wing',
                        //     'masterdatafield': 'wingname',
                        //     'formdatafield': 'wing',
                        //     'cleanable': true,
                        //     'searchable': true,
                        //     'onchangefill': ['floorid'],
                        //     'masterdatadependancy': false,
                        //     'condition': {
                        //         'iscommonarea': [1]
                        //     }
                        // },
                        // {
                        //     'field': 'floorid',
                        //     'text': 'Floor',
                        //     'type': 'dropdown',
                        //     'disabled': false,
                        //     'defaultvisibility': true,
                        //     'required': true,
                        //     'gridsize': 375,
                        //     'masterdata': 'property/floor',
                        //     'masterdatafield': 'floor',
                        //     'formdatafield': 'floor',
                        //     'cleanable': true,
                        //     'searchable': true,
                        //     "dependentfilter": { "wingid": "wingid" },
                        //     "masterdatadependancy": true,
                        //     'condition': {
                        //         'iscommonarea': [1]
                        //     }
                        // },
                        {
                            'field': 'areaid',
                            'text': 'Area',
                            'type': 'dropdown',
                            'disabled': false,
                            'defaultvisibility': true,
                            'required': true,
                            'gridsize': 375,
                            'masterdata': 'property/area',
                            'masterdatafield': 'area',
                            'formdatafield': 'area',
                            'cleanable': true,
                            'searchable': true,

                            'masterdatadependancy': false,
                            // 'condition': {
                            //     'iscommonarea': [1]
                            // }
                        },
                        {
                            "field": "isbookable",
                            "text": "is Bookable",
                            "type": "checkbox",
                            "disabled": false,
                            "required": false,
                            "defaultvisibility": true,
                            "gridsize": 375,
                        },

                        // {
                        //   "field": "areatypeid",
                        //   "text": "Area Type",
                        //   "type": "dropdown",
                        //   "disabled": false,
                        //   "defaultvisibility": true,
                        //   "required": true,
                        //   "gridsize": 375,
                        //   "masterdata": "areatype",
                        //   "masterdatafield": "areatype",
                        //   "formdatafield": "areatype",
                        //   "cleanable": true,
                        //   "searchable": true,
                        //   "masterdatadependancy": false,
                        //   "staticfilter": {"isactive": 1}
                        // },
                        // {
                        //   "field": "facility",
                        //   "text": "Facility Name",
                        //   "type": "input-text",
                        //   "disabled": false,
                        //   "defaultvisibility": true,
                        //   "required": true,
                        //   "gridsize": 375,
                        // },
                        {
                            "field": "capacitycount",
                            "text": "Capacity",
                            "type": "number-input",
                            "disabled": false,
                            "suffixtext": "Persons",
                            "defaultvisibility": true,
                            "required": false,
                            "gridsize": 375,
                        },
                        {
                            "field": "charges",
                            "text": "Charges (₹)",
                            "type": "number-input",
                            "disabled": false,
                            "defaultvisibility": true,
                            "required": false,
                            "gridsize": 375,
                            'condition': {
                                'isbookable': [1]
                            }
                        },
                        // {
                        //   "field": "timeslot",
                        //   "text": "Time slot",
                        //   "type": "multipletimeslotpicker",
                        //   "disabled": false,
                        //   "defaultvisibility": true,
                        //   "required": true,
                        //   "gridsize": 375,
                        //   'condition': {
                        //     'ispropertycommonarea': [1]
                        //   }
                        // },
                        // {
                        //   'field': 'image',
                        //   'text': 'Image',
                        //   'type': "multipleimagepicker",
                        //   'disabled': false,
                        //   'defaultvisibility': true,
                        //   'required': false,
                        //   'filetypes': ["png"],
                        //   'gridsize': 375,
                        //   'condition': {
                        //     'ispropertycommonarea': [1]
                        //   }
                        // },
                        {
                            "field": "contact",
                            "text": "Contact Person Number",
                            "type": "number-input",
                            "prefixtext": "code",
                            "disabled": false,
                            "defaultvisibility": true,
                            "required": true,
                            "gridsize": 375,
                        },
                        {
                            "field": "email",
                            "text": "Email",
                            "type": "input-text",
                            "disabled": false,
                            'regxtype': 'email',
                            "defaultvisibility": true,
                            "required": true,
                            "gridsize": 375,
                        },
                        {
                            "field": "amenities",
                            "text": "Amenities",
                            "type": "input-text",
                            "disabled": false,
                            "regex": '.*',
                            "defaultvisibility": true,
                            "required": true,
                            "gridsize": 375,
                        },
                        {
                            "field": "capacitydescription",
                            "text": "Capacity Description",
                            "height": 400,
                            "gridsize": 800,
                            "type": "input-textarea",
                            "disabled": false,
                            "defaultvisibility": true,
                            "required": false,
                        },
                        {
                            "field": "description",
                            "text": "Description",
                            "height": 400,
                            "gridsize": 800,
                            "type": "input-textarea",
                            "disabled": false,
                            "defaultvisibility": true,
                            "required": false,
                        },
                        {
                            "field": "rules_regulations",
                            "text": "Rules & Regulations",
                            "height": 400,
                            "gridsize": 800,
                            "type": "input-textarea",
                            "disabled": false,
                            "defaultvisibility": true,
                            "required": false,
                        },
                        {
                            "field": "facilityimage",
                            "text": "Facility Image",
                            "type": "multipleimagepicker",
                            "freeze": 0,
                            "active": 1,
                            "sorttable": 0,
                            "filter": 0,
                            "gridsize": 800,
                            "defaultvalue": "",
                        },
                    ]
                },
                {
                    "tab": "Time Slot",
                    "allowmultipleentries": true,
                    "tabid": "timeslot",
                    "uniquekey": "endtime",
                    "required": true,
                    'condition': {
                        'isbookable': [1]
                    },
                    "formFields": [
                        {
                            "field": "starttime",
                            "text": "Start Time",
                            "type": "timepicker",
                            "disabled": false,
                            "defaultvisibility": true,
                            "required": true,
                            "gridsize": 350,
                        },
                        {
                            "field": "endtime",
                            "text": "End Time",
                            "type": "timepicker",
                            "disabled": false,
                            "defaultvisibility": true,
                            "required": true,
                            "gridsize": 350,
                        },
                    ],
                },

                // {
                //     "tab": "Time slot",
                //     "formFields": [

                //         {
                //             "field": "endtime",
                //             "text": "End Time",
                //             "type": "timepicker",
                //             "disabled": false,
                //             "defaultvisibility": true,
                //             "required": true,
                //             "gridsize": 375,
                //             'condition': {
                //                 'ispropertycommonarea': [1]
                //             }
                //         },
                //         {
                //             'field': 'time',
                //             'text': 'Add Slot',
                //             'type': 'button',
                //             'disabled': false,
                //             'required': true,
                //             'defaultvisibility': true,
                //             'condition': {
                //                 'ispropertycommonarea': [1]
                //             }
                //         },
                //     ]
                // },
                // {
                //     "tab": "Other",
                //     "formFields": [

                //     ]
                // }
            ]
        };
        // return {
        //     "rightsidebarsize": 400,
        //     "pagename": "Facility",
        //     "formname": "Facility",
        //     "alias": "facility",
        //     "dataview": "tab",
        //     "formfields": [

        //         {
        //             "tab": "Area Details",
        //             "formFields": [
        //                 {
        //                     "field": "ispropertycommonarea",
        //                     "text": " isProperty common Area",
        //                     "type": "checkbox",
        //                     "disabled": false,
        //                     "required": false,
        //                     "defaultvisibility": true,
        //                     "gridsize": 1150
        //                 },
        //                 {
        //                     'field': 'wingid',
        //                     'text': 'Wing Name',
        //                     'type': Config.getHtmlcontorls()["kDropDown"],
        //                     'disabled': false,
        //                     'defaultvisibility': true,
        //                     'required': true,
        //                     'gridsize': 375,
        //                     'masterdata': 'property/wing',
        //                     'masterdatafield': 'wingname',
        //                     'formdatafield': 'wingname',
        //                     'cleanable': true,
        //                     'searchable': true,
        //                     'onchangefill': ['floorid'],
        //                     'masterdatadependancy': false,
        //                     'condition': {
        //                         'commonarea': [0]
        //                     }
        //                 },
        //                 {
        //                     'field': 'floorid',
        //                     'text': 'Floor',
        //                     'type': Config.getHtmlcontorls()["kDropDown"],
        //                     'disabled': false,
        //                     'defaultvisibility': true,
        //                     'required': true,
        //                     'gridsize': 375,
        //                     'masterdata': 'property/floor',
        //                     'masterdatafield': 'floor',
        //                     'formdatafield': 'floor',
        //                     'cleanable': true,
        //                     'searchable': true,
        //                     "dependentfilter": {
        //                         "wingid": "wingid"
        //                     },
        //                     "masterdatadependancy": true,
        //                     'condition': {
        //                         'commonarea': [0]
        //                     }
        //                 },


        //                 {
        //                     "field": "areatypeid",
        //                     "text": "Area Type",
        //                     "type": "dropdown",
        //                     "disabled": false,
        //                     "defaultvisibility": true,
        //                     "required": true,
        //                     "gridsize": 375,
        //                     "masterdata": "areatype",
        //                     "masterdatafield": "areatype",
        //                     "formdatafield": "areatype",
        //                     "cleanable": true,
        //                     "searchable": true,
        //                     "masterdatadependancy": false,
        //                     "staticfilter": {
        //                         "isactive": 1
        //                     }
        //                 },
        //                 {
        //                     "field": "facility",
        //                     "text": "Facility Name",
        //                     "type": "input-text",
        //                     "disabled": false,
        //                     "defaultvisibility": true,
        //                     "required": true,
        //                     "gridsize": 375
        //                 },
        //                 {
        //                     "field": "capacitycount",
        //                     "text": "Capacity",
        //                     "type": "number-input",
        //                     "disabled": false,
        //                     "defaultvisibility": true,
        //                     "required": false,
        //                     "gridsize": 375,
        //                     'condition': {
        //                         'ispropertycommonarea': [1]
        //                     }
        //                 },
        //                 {
        //                     "field": "charges",
        //                     "text": "Charges",
        //                     "type": "number-input",
        //                     "disabled": false,
        //                     "defaultvisibility": true,
        //                     "required": false,
        //                     "gridsize": 375,
        //                     'condition': {
        //                         'ispropertycommonarea': [1]
        //                     }
        //                 },
        //                 {
        //                     "field": "timeslot",
        //                     "text": "Time slot",
        //                     "type": "multipletimeslotpicker",
        //                     "disabled": false,
        //                     "defaultvisibility": true,
        //                     "required": true,
        //                     "gridsize": 375,
        //                     'condition': {
        //                         'ispropertycommonarea': [1]
        //                     }
        //                 },
        //                 {
        //                     'field': 'image',
        //                     'text': 'Image',
        //                     'type': "multipleimagepicker",
        //                     'disabled': false,
        //                     'defaultvisibility': true,
        //                     'required': false,
        //                     'filetypes': ["png"],
        //                     'gridsize': 375,
        //                     'condition': {
        //                         'ispropertycommonarea': [1]
        //                     }
        //                 },
        //                 {
        //                     "field": "description",
        //                     "text": "Description",
        //                     "height": 400,
        //                     "type": "htmleditor",
        //                     "disabled": false,
        //                     "defaultvisibility": true,
        //                     "required": false,
        //                     'condition': {
        //                         'ispropertycommonarea': [1]
        //                     }
        //                 },
        //             ]
        //         },

        //         // {
        //         //     "tab": "Time slot",
        //         //     "formFields": [

        //         //         {
        //         //             "field": "endtime",
        //         //             "text": "End Time",
        //         //             "type": "timepicker",
        //         //             "disabled": false,
        //         //             "defaultvisibility": true,
        //         //             "required": true,
        //         //             "gridsize": 375,
        //         //             'condition': {
        //         //                 'ispropertycommonarea': [1]
        //         //             }
        //         //         },
        //         //         {
        //         //             'field': 'time',
        //         //             'text': 'Add Slot',
        //         //             'type': 'button',
        //         //             'disabled': false,
        //         //             'required': true,
        //         //             'defaultvisibility': true,
        //         //             'condition': {
        //         //                 'ispropertycommonarea': [1]
        //         //             }
        //         //         },
        //         //     ]
        //         // },
        //         // {
        //         //     "tab": "Other",
        //         //     "formFields": [


        //         //     ]
        //         // }
        //     ]
        // }

    }
}


export class PropertyGate {
    constructor() {
        this._id
        this.propertyid = { type: mongoose.Schema.Types.ObjectId, ref: "tblproperty" }
        this.propertyname = { type: String, required: [true, 'Property is required'] }
        this.gatename = { type: String, default: "", }
        this.gateno = { type: String, required: [true, 'Gateno is required'] }
        this.isactive = { type: Number, default: 1 }
        this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: "recordinfo" }
    }

    getDataName() {
        return "Gate"
    }

    getIndexes() {
        return [[{ propertyid: 1, gateno: 1 }, { unique: 1 }]]
    }

    getFieldOrder() {
        const Config = new _Config()
        return {
            fields: [
                {
                    field: 'action_button',
                    text: '',
                    type: Config.getHtmlcontorls()['action_button'],
                    freeze: 1,
                    active: 1,
                    sorttable: 0,
                    filter: 0,
                    disableflex: 1,
                    filterfieldtype: Config.getHtmlcontorls()['lookup'],
                    defaultvalue: '',
                    tblsize: 10
                },
                {
                    field: 'isactive',
                    text: 'Status',
                    type: Config.getHtmlcontorls()['isactive'],
                    freeze: 1,
                    active: 1,
                    sorttable: 0,
                    filter: 0,
                    disableflex: 1,
                    filterfieldtype: Config.getHtmlcontorls()['lookup'],
                    defaultvalue: '',
                    tblsize: 15
                },
                {
                    field: "gateno",
                    text: "Gate No",
                    type: Config.getHtmlcontorls()["text"],
                    freeze: 0,
                    active: 1,
                    sorttable: 1,
                    disableflex: 0,
                    filter: 0,
                    filterfieldtype: Config.getHtmlcontorls()["lookup"],
                    defaultvalue: "",
                    tblsize: 15
                },

            ]
        }
    }

    getFormFieldOrder() {
        return {
            "rightsidebarsize": 400,
            "pagename": "gate",
            "formname": "Gate",
            "alias": "gate",
            "dataview": "tab",
            "formfields": [
                {
                    "tab": "Gate",
                    "formFields": [
                        {
                            "field": "gateno",
                            "text": "Gate Name",
                            "type": "input-text",
                            "disabled": false,
                            "defaultvisibility": true,
                            "required": true,
                            "gridsize": 375
                        },
                    ]
                }
            ]
        }
    }
}



export class PropertyParkingSlot {
    constructor() {
        this._id
        this.propertyid = { type: mongoose.Schema.Types.ObjectId, ref: "tblproperty" }
        this.propertyname = { type: String, required: true }
        this.parkingzoneid = { type: mongoose.Schema.Types.ObjectId, ref: "tblparkingzonemaster" }
        this.parkingzone = { type: String, required: true }
        this.parkingslot = { type: String, required: true }
        this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: "recordinfo" }
    }


    getIndexes() {
        return [[{ propertyid: 1, parkingslot: 1 }, { unique: 1 }]]
    }

    getFieldOrder() {
        const Config = new _Config()
        return {
            fields: [
                {
                    field: 'action_button',
                    text: '',
                    type: Config.getHtmlcontorls()['action_button'],
                    freeze: 1,
                    active: 1,
                    sorttable: 0,
                    filter: 0,
                    disableflex: 1,
                    filterfieldtype: Config.getHtmlcontorls()['lookup'],
                    defaultvalue: '',
                    tblsize: 10
                },
                {
                    field: 'isactive',
                    text: 'Status',
                    type: Config.getHtmlcontorls()['isactive'],
                    freeze: 1,
                    active: 1,
                    sorttable: 0,
                    filter: 0,
                    disableflex: 1,
                    filterfieldtype: Config.getHtmlcontorls()['lookup'],
                    defaultvalue: '',
                    tblsize: 15
                },
                {
                    field: "propertyname",
                    text: "Property Name",
                    type: Config.getHtmlcontorls()["text"],
                    freeze: 0,
                    active: 1,
                    sorttable: 1,
                    filter: 0,
                    sortby: 'propertyname',
                    filterfieldtype: Config.getHtmlcontorls()["lookup"],
                    defaultvalue: "",
                    tblsize: 15
                },
                {
                    field: "parkingslot",
                    text: "Parking Slot",
                    type: Config.getHtmlcontorls()["text"],
                    freeze: 0,
                    active: 1,
                    sorttable: 1,
                    filter: 1,
                    filterfieldtype: Config.getHtmlcontorls()["lookup"],
                    defaultvalue: "",
                    tblsize: 15
                }
            ]
        }
    }

    getFormFieldOrder() {
        return {
            "rightsidebarsize": 400,
            "pagename": "parkingslot",
            "formname": "Parking Slot",
            "alias": "parking",
            "dataview": "tab",
            "formfields": [
                {
                    "tab": "Parking Slot",
                    "formFields": [
                        {
                            "field": "parkingslot",
                            "text": "Parking Sloot",
                            "type": "input-text",
                            "disabled": false,
                            "defaultvisibility": true,
                            "required": true,
                            "gridsize": 375
                        },
                    ]
                }
            ]
        }
    }
}





