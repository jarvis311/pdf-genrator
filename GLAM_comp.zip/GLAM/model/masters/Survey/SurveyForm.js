import mongoose from 'mongoose'
import _Config from '../../../config/Config.js'


export default class SurveyForm {
    constructor() {
        this._id
        this.surveyform = { type: String, require: true, unique: true }
        this.privateorpublic = { type: Number }//1 for private 2 for public
        this.surveytypeid = { type: mongoose.Schema.Types.ObjectId, ref: 'tblsurveytype' }
        this.surveytype = { type: String, require: true }
        this.description = { type: String }
        this.formjson = { type: Array, require: true }
        this.themeid = { type: mongoose.Schema.Types.ObjectId, ref: 'tblsurveytheme' }
        this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: 'recordinfo' }
        this.submitlimit = { type: Number, default: 1 }

    }
    getDataName() {
        return "Survey Form"
    }
    getFieldOrder() {
        const Config = new _Config()

        return {
            fields: [
                {
                    'field': 'surveyform',
                    'text': 'Survey Name',
                    'type': Config.getHtmlcontorls()['text'],
                    'freeze': 1,
                    'active': 1,
                    'sorttable': 1,
                    'filter': 1,
                    'filterfieldtype': Config.getHtmlcontorls()['lookup'],
                    'defaultvalue': '',
                    'tblsize': Config.getTblgridsizeclasses()['tbl-w200']
                },
                {
                    'field': 'surveytype',
                    'text': 'Survey Type',
                    'type': Config.getHtmlcontorls()['text'],
                    'freeze': 0,
                    'active': 1,
                    'sorttable': 1,
                    'filter': 1,
                    'filterfieldtype': Config.getHtmlcontorls()['lookup'],
                    'defaultvalue': '',
                    'tblsize': Config.getTblgridsizeclasses()['tbl-w250']
                },
                {
                    'field': 'preview',
                    'text': 'Preview',
                    'type': Config.getHtmlcontorls()['modal-eye'],
                    'freeze': 0,
                    'active': 1,
                    'sorttable': 0,
                    'filter': 0,
                    'filterfieldtype': Config.getHtmlcontorls()['modal-eye'],
                    'defaultvalue': '',
                    'tblsize': Config.getTblgridsizeclasses()['tbl-w200']
                },
            ]
        }
    }


    getFormFieldOrder() {
        return {
            "rightsidebarsize": 1200,
            "pagename": "surveyform",
            "formname": "Survey Form",
            "alias": "surveyform",
            "dataview": "tab",
            "formfields": [
                {
                    "tab": "",
                    "formFields": [
                        {
                            "field": "surveytypeid",
                            "text": "Sruvey Type",
                            "type": "dropdown",
                            "disabled": false,
                            "defaultvisibility": true,
                            "required": true,
                            "gridsize": 375,
                            "masterdata": "surveytype",
                            "masterdatafield": "name",
                            "formdatafield": "surveytype",
                            "cleanable": true,
                            "searchable": true,
                            "masterdatadependancy": false,
                            "staticfilter": { "isactive": 1 }
                        },
                    ]
                },
                {
                    "tab": "",
                    "formFields": [
                        {
                            'field': 'rating',
                            'text': 'Rating',
                            'type': 'checkbox',
                            'disabled': false,
                            'required': true,
                            'defaultvisibility': true,
                            'gridsize': 375,
                        },
                    ]
                },
                {
                    "tab": "",
                    "formFields": [
                        {
                            "field": "title",
                            "text": "Rating title",
                            "type": "input-text",
                            "disabled": false,
                            "defaultvisibility": true,
                            "required": true,
                            "gridsize": 375,
                            'condition': {
                                'rating': [1]
                            }
                        },
                    ],
                },
                {
                    "tab": "",
                    "formFields": [
                        {
                            'field': 'categoricalscale',
                            'text': 'Categorical Scale',
                            'type': 'checkbox',
                            'disabled': false,
                            'required': true,
                            'defaultvisibility': true,
                            'gridsize': 375,
                        },
                    ]
                },
                {
                    "tab": "",
                    "formFields": [
                        {
                            "field": "categoricalscaletitle",
                            "text": "Categorical Scale title",
                            "type": "input-text",
                            "disabled": false,
                            "defaultvisibility": true,
                            "required": true,
                            "gridsize": 375,
                            'condition': {
                                'categoricalscale': [1]
                            }
                        },
                    ],
                },
                {
                    "tab": "",
                    "formFields": [
                        {
                            'field': 'yesno',
                            'text': 'Agree/Disagree',
                            'type': 'checkbox',
                            'disabled': false,
                            'required': true,
                            'defaultvisibility': true,
                            'gridsize': 375,
                        },
                    ]
                },
                {
                    "tab": "",
                    "formFields": [
                        {
                            "field": "yesnotitle",
                            "text": "Yes No title",
                            "type": "input-text",
                            "disabled": false,
                            "defaultvisibility": true,
                            "required": true,
                            "gridsize": 375,
                            'condition': {
                                'yesno': [1]
                            }
                        },
                    ],
                },
                {
                    "tab": "",
                    "formFields": [
                        {
                            'field': 'standard',
                            'text': 'Standard 5-Point Scale',
                            'type': 'checkbox',
                            'disabled': false,
                            'required': true,
                            'defaultvisibility': true,
                            'gridsize': 375,
                        },
                    ]
                },
                {
                    "tab": "",
                    "formFields": [
                        {
                            "field": "Standardtitle",
                            "text": "Standard title",
                            "type": "input-text",
                            "disabled": false,
                            "defaultvisibility": true,
                            "required": true,
                            "gridsize": 375,
                            'condition': {
                                'standard': [1]
                            }
                        },
                    ],
                },
            ]

        };

    }



}