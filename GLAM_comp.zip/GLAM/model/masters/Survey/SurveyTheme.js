import _Config from '../../config/Config.js'

export default class SurveyTheme {
    constructor() {
        this._id
        this.themename = { type: String }
        this.themeurl = { type: String }
    }
    getDataName() {
        return "Survey Theme"
    }
}