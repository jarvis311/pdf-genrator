import mongoose from 'mongoose'

export default class SurveyType
{
    constructor(){
        this._id
        this.surveytype = {type: String,required: true}
        this.ispublic = {type : Number, default:0}
    }
    getDataName() {
        return "Survey Type"
    }
}