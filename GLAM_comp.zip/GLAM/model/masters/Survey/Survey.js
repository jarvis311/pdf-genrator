import mongoose from 'mongoose'
import { Config } from '../../../config/Init.js'

export default class Survey
{
    constructor(){
        this._id
        this.surveytypeid = {type: mongoose.Schema.Types.ObjectId,required: true,ref:"tblsurveytype"}
        this.surveytype = {type: String,required: true}
        this.surveyformid = {type: mongoose.Schema.Types.ObjectId,required: true,ref : "tblsurveyform"}
        this.surveyform = {type: String,required: true}
        this.surveyformfor = {type: String,required: true}
        this.formjson = { type : Array, require : true}
        this.ispublic = {type : Number, require :true}   //0-no   1-yes
        this.department = [
            {
                departmentid : {type: mongoose.Schema.Types.ObjectId,required: true,ref : "tbldepartmentmaster"},
                department : {type: String,required: true}
            }
        ]
        this.assignedto = [
            {
                personid : {type: mongoose.Schema.Types.ObjectId,required: true,ref : "tblpersonmaster"},
                person : {type: String,required: true},
                date : {type :Array}
            }
        ]
        // this.customer = [
        //     {
        //         customerid : {type: mongoose.Schema.Types.ObjectId,required: true,ref : "tblpersonmaster"},
        //         customer : {type: String,required: true}
        //     }
        // ]
        this.customerid = {type: mongoose.Schema.Types.ObjectId,ref : "tblpersonmaster"},
        this.customer = {type: String}
        this.projectid = {type: mongoose.Schema.Types.ObjectId,ref : "tblprojectmaster"},
        this.project = {type: String}

        this.responseaccesspersons = [
            {
                personid : {type: mongoose.Schema.Types.ObjectId,required: true,ref : "tblpersonmaster"},
                person : {type: String,required: true}
            }
        ]
        this.duedate = {type : String, require :false}
        this.submitlimit = {type : Number, require :false}
        this.emailsend = {type : Number, default : 0}
        this.url = {type : String, require :false}
        this.description = { type : String}
        this.recordinfo =  {type : mongoose.Schema.Types.Mixed, ref: 'recordinfo'}
    }
    getDataName() {
        return "Survey"
    }
    getFieldOrder() {

        return {
            fields: [
                {
                    'field': 'surveytype',
                    'text': 'Survey Type',
                    'type': Config.getHtmlcontorls()['text'],
                    'freeze': 1,
                    'active': 1,
                    'sorttable': 1,
                    'filter': 1,
                    'filterfieldtype': Config.getHtmlcontorls()['lookup'],
                    'defaultvalue': '',
                    'tblsize': Config.getTblgridsizeclasses()['tbl-w200']
                },
                {
                    'field': 'surveyform',
                    'text': 'Survey Form',
                    'type': Config.getHtmlcontorls()['text'],
                    'freeze': 0,
                    'active': 1,
                    'sorttable': 1,
                    'filter': 1,
                    'filterfieldtype': Config.getHtmlcontorls()['lookup'],
                    'defaultvalue': '',
                    'tblsize': Config.getTblgridsizeclasses()['tbl-w250']
                },
                {
                    'field' : 'preview',
                    'text' : 'Preview',
                    'type' : Config.getHtmlcontorls()['modal-eye'],
                    'freeze' : 0,
                    'active' : 1,
                    'sorttable' : 0,
                    'filter' : 0,
                    'filterfieldtype' : Config.getHtmlcontorls()['modal-eye'],
                    'defaultvalue' : '',
                    'tblsize' : Config.getTblgridsizeclasses()['tbl-w200']
                },
                {
                    'field' : 'response',
                    'text' : 'Response',
                    'type' : Config.getHtmlcontorls()['modal-eye'],
                    'freeze' : 0,
                    'active' : 1,
                    'sorttable' : 0,
                    'filter' : 0,
                    'filterfieldtype' : Config.getHtmlcontorls()['modal-eye'],
                    'defaultvalue' : '',
                    'tblsize' : Config.getTblgridsizeclasses()['tbl-w200']
                },
                {
                    'field' : 'department',
                    'text' : 'Department',
                    'type' : Config.getHtmlcontorls()['modal-eye'],
                    'freeze' : 0,
                    'active' : 1,
                    'sorttable' : 0,
                    'filter' : 0,
                    'filterfieldtype' : Config.getHtmlcontorls()['modal-eye'],
                    'defaultvalue' : '',
                    'tblsize' : Config.getTblgridsizeclasses()['tbl-w200']
                },
                {
                    'field' : 'assignedto',
                    'text' : 'Assigned To',
                    'type' : Config.getHtmlcontorls()['modal-eye'],
                    'freeze' : 0,
                    'active' : 1,
                    'sorttable' : 0,
                    'filter' : 0,
                    'filterfieldtype' : Config.getHtmlcontorls()['modal-eye'],
                    'defaultvalue' : '',
                    'tblsize' : Config.getTblgridsizeclasses()['tbl-w200']
                },
                {
                    'field' : 'customer',
                    'text' : 'Customer',
                    'type' : Config.getHtmlcontorls()['text'],
                    'freeze' : 0,
                    'active' : 1,
                    'sorttable' : 0,
                    'filter' : 0,
                    'filterfieldtype' : Config.getHtmlcontorls()['lookup'],
                    'defaultvalue' : '',
                    'tblsize' : Config.getTblgridsizeclasses()['tbl-w200']
                },
                {
                    'field' : 'project',
                    'text' : 'Project',
                    'type' : Config.getHtmlcontorls()['text'],
                    'freeze' : 0,
                    'active' : 1,
                    'sorttable' : 0,
                    'filter' : 0,
                    'filterfieldtype' : Config.getHtmlcontorls()['lookup'],
                    'defaultvalue' : '',
                    'tblsize' : Config.getTblgridsizeclasses()['tbl-w200']
                },
                {
                    'field' : 'responseaccesspersons',
                    'text' : 'Response Access Person',
                    'type' : Config.getHtmlcontorls()['modal-eye'],
                    'freeze' : 0,
                    'active' : 1,
                    'sorttable' : 0,
                    'filter' : 0,
                    'filterfieldtype' : Config.getHtmlcontorls()['modal-eye'],
                    'defaultvalue' : '',
                    'tblsize' : Config.getTblgridsizeclasses()['tbl-w200']
                },
                {
                    'field': 'duedate',
                    'text': 'Due Date',
                    'type': Config.getHtmlcontorls()['text'],
                    'freeze': 0,
                    'active': 1,
                    'sorttable': 1,
                    'filter': 1,
                    'filterfieldtype': Config.getHtmlcontorls()['datepicker'],
                    'defaultvalue': '',
                    'tblsize': Config.getTblgridsizeclasses()['tbl-w250']
                },
                {
                    'field': 'emailsend',
                    'text': 'Email send',
                    'type': Config.getHtmlcontorls()['text'],
                    'freeze': 0,
                    'active': 1,
                    'sorttable': 1,
                    'filter': 1,
                    'filterfieldtype': Config.getHtmlcontorls()['lookup'],
                    'defaultvalue': '',
                    'tblsize': Config.getTblgridsizeclasses()['tbl-w250']
                },
                {
                    'field': 'url',
                    'text': 'URL',
                    'type': Config.getHtmlcontorls()['text'],
                    'freeze': 0,
                    'active': 1,
                    'sorttable': 1,
                    'filter': 1,
                    'filterfieldtype': Config.getHtmlcontorls()['lookup'],
                    'defaultvalue': '',
                    'tblsize': Config.getTblgridsizeclasses()['tbl-w250']
                },
                {
                    'field': 'submitlimit',
                    'text': 'Submit Limit',
                    'type': Config.getHtmlcontorls()['text'],
                    'freeze': 0,
                    'active': 1,
                    'sorttable': 1,
                    'filter': 1,
                    'filterfieldtype': Config.getHtmlcontorls()['lookup'],
                    'defaultvalue': '',
                    'tblsize': Config.getTblgridsizeclasses()['tbl-w250']
                },
            ]
        }
    }
}