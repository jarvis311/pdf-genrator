import mongoose from 'mongoose'
import _Config from '../../../config/Config.js'


export default class AdvancedSalary {
    constructor() {
        this._id
        this.surveyid = { type: mongoose.Schema.Types.ObjectId, ref: 'tblsurvey' }
        this.personid =  { type: mongoose.Schema.Types.ObjectId, ref: 'tblpersonmaster' }
        this.person =  { type : String, require : true}
        this.formjson = { type : Array, require : true}
        this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: 'recordinfo' }
    }
    getDataName() {
        return "Survey Record"
    }
}