import mongoose from "mongoose"
import _Config from "../../config/Config.js"

export default class Holiday {
    constructor() {
        this._id
        this.holidayname = { type: String, required: true, unique: true, trim: true }
        this.holidaytypeid = { type: mongoose.Schema.Types.ObjectId, ref: "tblholidaytypemaster" }
        this.holidaytype = { type: String, required: true, trim: true }
        this.religionid = { type: String, ref: "tblreligionmaster" }
        this.religion = { type: String, trim: true }
        this.shortcode = { type: String, required: true, unique: true, trim: true }
        this.occasiondate = { type: Date, required: true }
        this.samedateforallyears = { type: String, required: true, trim: true }
        this.description = { type: String, trim: true }
        this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: "recordinfo" }
    }

    setID(id) {
        this._id = id
    }
    setHolidayName(holidayname) {
        this.holidayname = holidayname
    }
    setHolidayTypeId(holidaytypeid) {
        this.holidaytypeid = holidaytypeid
    }
    setHolidayType(holidaytype) {
        this.holidaytype = holidaytype
    }
    setReligionId(religionid) {
        this.religionid = religionid
    }
    setReligion(religion) {
        this.religion = religion
    }
    setShortCode(shortcode) {
        this.shortcode = shortcode
    }
    setOccasionDate(occasiondate) {
        this.occasiondate = occasiondate
    }
    setSameDateForAllYears(samedateforallyears) {
        this.samedateforallyears = samedateforallyears
    }
    setDescription(description) {
        this.description = description
    }
    setRecordinfo(recordinfo) {
        this.recordinfo = recordinfo
    }

    getID() {
        return this._id
    }
    getHolidayName() {
        return this.holidayname
    }
    getHolidayTypeId() {
        return this.holidaytypeid
    }
    getHolidayType() {
        return this.holidaytype
    }
    getReligionId() {
        return this.religionid
    }
    getReligion() {
        return this.religion
    }
    getShortCode() {
        return this.shortcode
    }
    getOccasionDate() {
        return this.occasiondate
    }
    getSameDateForAllYears() {
        return this.samedateforallyears
    }
    getDescription() {
        return this.description
    }
    getRecordinfo() {
        return this.recordinfo
    }
    getFieldOrder() {
        const Config = new _Config()

        return {
            fields: [
                {
                    field: "holidayname",
                    text: "Holiday Name",
                    type: Config.getHtmlcontorls()["text"],
                    freeze: 1,
                    active: 1,
                    sorttable: 1,
                    filter: 1,
                    filterfieldtype: Config.getHtmlcontorls()["lookup"],
                    defaultvalue: "",
                    tblsize: Config.getTblgridsizeclasses()["tbl-min-w200"]
                },
                {
                    field: "occasiondate",
                    text: "Holiday Date",
                    type: Config.getHtmlcontorls()["text"],
                    freeze: 0,
                    active: 1,
                    sorttable: 1,
                    filter: 1,
                    filterfieldtype: Config.getHtmlcontorls()["datepicker"],
                    defaultvalue: "",
                    tblsize: Config.getTblgridsizeclasses()["tbl-min-w160"]
                },
                {
                    field: "holidaytype",
                    text: "Holiday Type",
                    type: Config.getHtmlcontorls()["text"],
                    freeze: 0,
                    active: 1,
                    sorttable: 1,
                    filter: 1,
                    filterfieldtype: Config.getHtmlcontorls()["lookup"],
                    defaultvalue: "",
                    tblsize: Config.getTblgridsizeclasses()["tbl-min-w200"]
                },
                {
                    field: "shortcode",
                    text: "Short Code",
                    type: Config.getHtmlcontorls()["text"],
                    freeze: 0,
                    active: 1,
                    sorttable: 1,
                    filter: 1,
                    filterfieldtype: Config.getHtmlcontorls()["lookup"],
                    defaultvalue: "",
                    tblsize: Config.getTblgridsizeclasses()["tbl-min-w140"]
                },
                {
                    field: "religion",
                    text: "Religion",
                    type: Config.getHtmlcontorls()["text"],
                    freeze: 0,
                    active: 1,
                    sorttable: 1,
                    filter: 1,
                    filterfieldtype: Config.getHtmlcontorls()["lookup"],
                    defaultvalue: "",
                    tblsize: Config.getTblgridsizeclasses()["tbl-min-w150"]
                },
                {
                    field: "samedateforallyears",
                    text: "Same Date For All Years",
                    type: Config.getHtmlcontorls()["text"],
                    freeze: 0,
                    active: 1,
                    sorttable: 1,
                    filter: 1,
                    filterfieldtype: Config.getHtmlcontorls()["lookup"],
                    defaultvalue: "",
                    tblsize: Config.getTblgridsizeclasses()["tbl-min-w250"]
                },
                {
                    field: "description",
                    text: "Description",
                    type: Config.getHtmlcontorls()["modal-eye"],
                    freeze: 0,
                    active: 1,
                    sorttable: 0,
                    filter: 0,
                    defaultvalue: "",
                    tblsize: Config.getTblgridsizeclasses()["tbl-w120"]
                }
            ]
        }
    }
}
