import mongoose from 'mongoose'
import { Config } from '../../config/Init.js'

export default class Day {
  constructor() {
    this._id
    this.day = { type: String, required: true, trim: true, index: { unique: true, collation: { locale: 'en', strength: 1 } } }
    this.isactive = { type: Number, required: true, default: 1 } // 1 - active, 0 - deactive
    this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: 'recordinfo' }
  }

  getDataName() {
    return "Day"
  }

}

