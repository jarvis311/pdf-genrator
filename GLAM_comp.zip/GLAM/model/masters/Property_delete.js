import mongoose from "mongoose"
import _Config from "../../config/Config.js"

export default class PropertyCommonDelete {
    constructor() {
        this._id
        this.personid = { type: mongoose.Schema.Types.ObjectId }
        this.brandname = { type: String, default: "", trim: true }
        this.property_id = { type: String, default: "", trim: true }
        this.propertyname = { type: String, default: "", trim: true }
        this.prefix = { type: String, default: "", trim: true}
        //this.uniqueno = { type: String, default: "", required: true, trim: true }
        this.propertycontactno = { type: String, default: "",trim: true }
        this.propertyemail = { type: String, default: "", trim: true }
        this.website = { type: String, default: "", trim: true }
        this.maincontactperson = { type: String, default: "", trim: true }
        this.maincontactpersonemail = { type: String, default: "", trim: true }
        this.maincontactpersonnumber = { type: String, default: "",  trim: true }
       //this.designationid = { type: mongoose.Schema.Types.ObjectId, ref: "tbldesignationmaster" }
        this.mainpersondesignation = { type: String, default: "", trim: true }
        this.propertyimage = { type: String, default: "", trim: true }
        this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: "recordinfo" }
    }
}
