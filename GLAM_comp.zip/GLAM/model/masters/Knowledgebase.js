import mongoose from "mongoose"
import _Config from "../../config/Config.js"
const Config = new _Config()

export default class Knowledgebase {
  constructor() {
    this._id
    this.title = { type: String, required: true, trim: true, index: { unique: true, collation: { locale: 'en', strength: 1 } } }
    this.description = { type: Array }
    this.video = Config.getImageModel()
    this.videodate = { type: Date, default: Date.now }
    this.sender = { type: String, required: true }
    this.senderid = { type: mongoose.Schema.Types.ObjectId }
    this.propertyid = { type: mongoose.Schema.Types.ObjectId, ref: "tblpropertymaster" }
    this.property = { type: String, required: true }
    this.isactive = { type: Number, required: true, default: 0 } // 1 - active, 0 - deactive
    this.forgatekeeper = { type: Number, required: true, default: 0 }
    this.forcustomer = { type: Number, required: true, default: 1 }
    this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: "recordinfo" }
  }

  getDataName() {
    return "Knowledge Base"
  }

  getFieldOrder() {

    return {
      fields: [
        {
          'field': 'action_button',
          'text': '',
          'type': Config.getHtmlcontorls()['action_button'],
          'freeze': 1,
          'active': 1,
          'sorttable': 0,
          'filter': 0,
          'disableflex': 1,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': Config.getTblgridsizeclasses()[8]
        },
        {
          'field': 'isactive',
          'text': 'Status',
          'type': Config.getHtmlcontorls()['isactive'],
          'freeze': 0,
          'active': 1,
          'sorttable': 0,
          'filter': 0,
          'disableflex': 1,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': Config.getTblgridsizeclasses()[15]
        },
        {
          'field': 'title',
          'text': 'title',
          'type': Config.getHtmlcontorls()['text'],
          'freeze': 0,
          'active': 1,
          'sorttable': 1,
          'sortby': 'title',
          'filter': 0,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': Config.getTblgridsizeclasses()[165]
        },
        {
          "field": "fromdate",
          "text": "From Date & Time",
          "type": "datetimepicker",
          "freeze": 0,
          "active": 0,
          "sorttable": 1,
          "sortby": "fromdate",
          "filter": 1,
          "filterfield": "fromdate",
          "filterfieldtype": "datetimepicker",
          "isonlyfilter": 1,
          "defaultvalue": "",
          "tblsize": 28
        },
        {
          "field": "todate",
          "text": "To Date & Time",
          "type": "datetimepicker",
          "freeze": 0,
          "active": 0,
          "sorttable": 1,
          "sortby": "todate",
          "filter": 1,
          "filterfield": "todate",
          "filterfieldtype": "datetimepicker",
          "isonlyfilter": 1,
          "defaultvalue": "",
          "tblsize": 28
        },
        // {
        //   'field': 'description',
        //   'text': 'Description',
        //   'type': Config.getHtmlcontorls()['text'],
        //   'freeze': 0,
        //   'active': 1,
        //   'sorttable': 1,
        //   'sortby': 'description',
        //   'filter': 1,
        //   'filterfieldtype': Config.getHtmlcontorls()['lookup'],
        //   'defaultvalue': '',
        //   'tblsize': Config.getTblgridsizeclasses()[15]
        // },
        // {
        //   'field': 'video',
        //   'text': 'Video',
        //   'type': Config.getHtmlcontorls()['text'],
        //   'freeze': 0,
        //   'active': 1,
        //   'sorttable': 0,
        //   'filter': 0,
        //   'filterfieldtype': Config.getHtmlcontorls()['lookup'],
        //   'defaultvalue': '',
        //   'tblsize': Config.getTblgridsizeclasses()[15]
        // }
      ]
    }
  }

  getFormFieldOrder() {
    return {
      "rightsidebarsize": Config.getModalsizeclasses()['775'],
      "pagename": 'knowledgebase',
      "formname": 'Knowledge Base',
      "alias": 'knowledgebase',
      "dataview": "tab",
      'formfields': [
        {
          "tab": "knowledgebase",
          "formFields": [
            {
              'field': 'title',
              'text': 'Title',
              'type': Config.getHtmlcontorls()['kInputText'],
              'disabled': false,
              'defaultvisibility': true,
              'required': true,
              'gridsize': Config.getFieldSize()['k375'],
            }, {
              'field': 'video',
              'text': 'File',
              'type': "file",
              'disabled': false,
              'defaultvisibility': true,
              'required': true,
              'filetypes': [
                ...Config.images,
                ...Config.allowedVideo
              ],
              'gridsize': 375,
              "freeze": 0,
              "active": 1,
              "sorttable": 0,
              "filter": 0,
              "defaultvalue": {}
            },
            {
              "field": "forgatekeeper",
              "text": "For Gatekeeper",
              "type": "checkbox",
              "disabled": false,
              "required": false,
              "defaultvisibility": true,
              "gridsize": 180
            },
            {
              "field": "forcustomer",
              "text": "For Customer",
              "type": "checkbox",
              "disabled": false,
              "required": false,
              "defaultvisibility": true,
              "gridsize": 180
            },
            {
              "field": "description",
              "text": "Description",
              "height": 400,
              "type": "htmleditor",
              "disabled": false,
              "defaultvisibility": true,
              "required": true,
            },
            {
              'field': 'isactive',
              'text': 'Status',
              'type': Config.getHtmlcontorls()['kDropDown'],
              'disabled': false,
              'defaultvisibility': true,
              'required': true,
              'gridsize': Config.getFieldSize()['k375'],
              'masterdata': 'isactive',
              'masterdataarray': Config.getStatustype(),
              'defaultvalue': 1,
              'formdatafield': 'isactive',
              'cleanable': true,
              'searchable': true,
              'masterdatadependancy': false,
            },
          ]
        }
      ],
    }
  }

}
