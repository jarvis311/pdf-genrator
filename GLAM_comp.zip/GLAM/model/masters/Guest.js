import mongoose from "mongoose"
import _Config from "../../config/Config.js"
const Config = new _Config()

export default class Guest {

  constructor() {
    this._id
    this.guestname = { type: String, required: true, trim: true} ,
    this.mobilenumber = { type: String, maxLength: 15 },
    this.customerid = { type: mongoose.Schema.Types.ObjectId, ref: "tblcustomer" }
    this.customer = { type: String }
    this.islongdurationvisit = { type: Number,enum: [0, 1],default: 0}    // 0-no , 1-yes
    this.startdate = {type:Date}
    this.enddate = { type:Date}
    this.note = { type: String }
    this.propertyid = { type: mongoose.Schema.Types.ObjectId, ref: "tblpropertymaster" }
    this.property = { type: String }
    this.wingid = { type: mongoose.Schema.Types.ObjectId, ref: "tblpropertywing" }
    this.wing = { type: String }
    this.floorid = { type: mongoose.Schema.Types.ObjectId, ref: "tblpropertyfloor" }
    this.floor = { type: String }
    this.unitid = { type: mongoose.Schema.Types.ObjectId, ref: "tblpropertyunit" }
    this.unit = { type: String }
    this.areaid = { type: mongoose.Schema.Types.ObjectId, ref: "tblpropertyarea" }
    this.area = { type: String }
    this.weekdays={type: Array},
    this.time={type: Array},
    this.starttime = {type: String},
    this.endtime = {type: String},
    this.allowtime = [{
        startdate: { type: Date },
        enddate: { type: Date }
      }],
    this.guesttype= {type:Number}
    this.pickdate = [{ type:String}]
    this.allowanytime = { type:Number,enum: [0, 1],default: 0} // 0-no , 1-yes
    this.allowdays = [{type:String}]
    this.otp = { type:String}
    this.visitorcategoryid = { type: mongoose.Schema.Types.ObjectId, ref: "tblvisitorcategory" }
    this.visitorcategory = { type: String }
    this.deliverycompanyid = { type: mongoose.Schema.Types.ObjectId, ref: "tbldeliverycompany" }
    this.deliverycompany = { type: String }
    this.iscollectfromgate = { type: Number,enum: [0, 1],default: 0} // 0-no , 1-yes
    this.isactive = { type: Number, required: true, default: 1 } // 1 - active, 0 - deactive
    this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: "recordinfo" }
  }

  getDataName() {
    return "Guest"
  }

  getFieldOrder() {
    return {
      fields: [
        {
          'field': 'action_button',
          'text': '',
          'type': Config.getHtmlcontorls()['action_button'],
          'freeze': 1,
          'active': 1,
          'sorttable': 0,
          'filter': 0,
          'disableflex': 1,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': Config.getTblgridsizeclasses()[10]
        },
        {
          'field': 'status',
          'text': 'Status',
          'type': Config.getHtmlcontorls()['isactive'],
          'freeze': 0,
          'active': 1,
          'sorttable': 0,
          'filter': 0,
          'disableflex': 1,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': Config.getTblgridsizeclasses()[15]
        },
        {
          'field': 'title',
          'text': 'title',
          'type': Config.getHtmlcontorls()['text'],
          'freeze': 0,
          'active': 1,
          'sorttable': 1,
          'sortby': 'title',
          'filter': 1,
          'disableflex': 1,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': Config.getTblgridsizeclasses()[15]
        },
        {
          'field': 'descriprtion',
          'text': 'Descriprtion',
          'type': Config.getHtmlcontorls()['text'],
          'freeze': 0,
          'active': 1,
          'sorttable': 1,
          'sortby': 'descriprtion',
          'filter': 1,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': Config.getTblgridsizeclasses()[15]
        },
        {
          'field': 'image',
          'text': 'Image',
          'type': Config.getHtmlcontorls()['text'],
          'freeze': 0,
          'active': 1,
          'sorttable': 0,
          'filter': 0,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': Config.getTblgridsizeclasses()[15]
        }
      ]
    }
  }

  getFormFieldOrder() {
    return {
      "rightsidebarsize": Config.getModalsizeclasses()['xs'],
      "pagename": 'country',
      "formname": 'Country',
      "alias": 'country',
      "dataview": "country",
      'formfields': [
        {
          "tab": "country",
          "formFields": [
            {
              'field': 'country',
              'text': 'Country Name',
              'type': Config.getHtmlcontorls()['kInputText'],
              'disabled': false,
              'defaultvisibility': true,
              'required': true,
              'gridsize': Config.getFieldSize()['k375'],
            },
            {
              'field': 'stateid',
              'text': 'State Name',
              'type': Config.getHtmlcontorls()['kDropDown'],
              'disabled': false,
              'defaultvisibility': true,
              'required': true,
              'gridsize': Config.getFieldSize()['k375'],
              'masterdata': 'state',
              'masterdatafield': 'state',
              'formdatafield': 'state',
              'cleanable': true,
              'searchable': true,

              'masterdatadependancy': false,
              'staticfilter': { 'isactive': 1 },
            },
            {
              'field': 'isactive',
              'text': 'Status',
              'type': Config.getHtmlcontorls()['kDropDown'],
              'disabled': false,
              'defaultvisibility': true,
              'required': true,
              'gridsize': Config.getFieldSize()['k375'],
              'masterdata': 'isactive',
              'masterdataarray': Config.getStatustype(),
              'defaultvalue': 1,
              'formdatafield': 'isactive',
              'cleanable': true,
              'searchable': true,
              'masterdatadependancy': false,
            },
          ]
        }
      ],
    }
  }

}
