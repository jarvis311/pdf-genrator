import mongoose from 'mongoose'
import { Config } from '../../config/Init.js'

export default class Pincode {
  constructor() {
    this._id
    this.pincode = { type: String, required: true, unique: true, trim: true }
    this.cityid = { type: mongoose.Schema.Types.ObjectId, ref: 'tblcitymaster' }
    this.city = { type: String, required: true, trim: true }
    this.stateid = { type: mongoose.Schema.Types.ObjectId, ref: 'tblstatemaster' }
    this.state = { type: String, required: true, trim: true }
    this.countryid = { type: mongoose.Schema.Types.ObjectId, ref: 'tblcountrymaster' }
    this.country = { type: String, required: true, trim: true }
    this.isactive = { type: Number, required: true, default: 1 } // 1 - active, 0 - deactive
    this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: 'recordinfo' }
  }

  compoundIndex() {
    return [
      { pincode: 1, city: 1 }
    ]
  }

  getDataName() {
    return "Pincode"
  }

  getFieldOrder() {
    return {
      fields: [
        {
          'field': 'action_button',
          'text': '',
          'type': Config.getHtmlcontorls()['action_button'],
          'freeze': 1,
          'active': 1,
          'sorttable': 0,
          'filter': 0,
          'disableflex': 1,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': 8
        },
        {
          'field': 'isactive',
          'text': 'Status',
          'type': Config.getHtmlcontorls()['isactive'],
          'freeze': 1,
          'active': 1,
          'sorttable': 0,
          'filter': 0,
          'disableflex': 1,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': 15
        },
        {
          'field': 'pincode',
          'text': 'Pincode',
          'type': Config.getHtmlcontorls()['text'],
          'freeze': 1,
          'active': 1,
          'sorttable': 1,
          'sortby': 'pincode',
          'filter': 0,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': 15
        },
        // {
        //   'field': 'area',
        //   'text': 'Area',
        //   'type': Config.getHtmlcontorls()['text'],
        //   'freeze': 1,
        //   'active': 1,
        //   'sorttable': 1,
        //   'sortby': 'area',
        //   'filter': 0,
        //   'filterfieldtype': Config.getHtmlcontorls()['lookup'],
        //   'defaultvalue': '',
        //   'tblsize': 60
        // },
        {
          'field': 'city',
          'text': 'City',
          'type': Config.getHtmlcontorls()['text'],
          'freeze': 1,
          'active': 1,
          'sorttable': 1,
          'sortby': 'city',
          'filter': 0,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': 15
        }
      ]

    }
  }

  getFormFieldOrder() {
    return {
      "rightsidebarsize": Config.getModalsizeclasses()['xs'],
      "pagename": 'pincode',
      "formname": 'Pincode',
      "alias": 'pincode',
      "dataview": "tab",
      'formfields': [
        {
          "tab": "Pincode",
          "formFields": [
            {
              'field': 'pincode',
              'text': 'Pincode',
              'type': Config.getHtmlcontorls()['kInputText'],
              'disabled': false,
              'defaultvisibility': true,
              'required': true,
              'gridsize': Config.getFieldSize()['k375'],
              'maxlength': 6,
              'minlength': 6,
              "capitalcase": true
            },
            {
              'field': 'countryid',
              'text': 'Country',
              'type': Config.getHtmlcontorls()['kDropDown'],
              'disabled': false,
              'defaultvisibility': true,
              'required': true,
              'gridsize': Config.getFieldSize()['k375'],
              'masterdata': 'country',
              'masterdatafield': 'country',
              'formdatafield': 'country',
              'cleanable': true,
              'searchable': true,
              'onchangefill': ['stateid'],
              'onchangedata': ['stateid'],
              'staticfilter': { 'isactive': 1 },
            },
            {
              'field': 'stateid',
              'text': 'State',
              'type': Config.getHtmlcontorls()['kDropDown'],
              'disabled': false,
              'defaultvisibility': true,
              'required': true,
              'gridsize': Config.getFieldSize()['k375'],
              'masterdata': 'state',
              'masterdatafield': 'state',
              'formdatafield': 'state',
              'cleanable': true,
              'searchable': true,
              'onchangefill': ['cityid'],
              'dependentfilter': {
                'countryid': 'countryid',
              },
              'onchangedata': ['stateid'],
              'staticfilter': { 'isactive': 1 },
            },
            {
              'field': 'cityid',
              'text': 'City',
              'type': Config.getHtmlcontorls()['kDropDown'],
              'disabled': false,
              'defaultvisibility': true,
              'required': true,
              'gridsize': Config.getFieldSize()['k375'],
              'masterdata': 'city',
              'masterdatafield': 'city',
              'formdatafield': 'city',
              'cleanable': true,
              'searchable': true,
              'dependentfilter': {
                'stateid': 'stateid',
              },
              'masterdatadependancy': true,
              'staticfilter': { 'isactive': 1 },
            },
            // {
            //   'field': 'area',
            //   'text': 'Area',
            //   'type': Config.getHtmlcontorls()['kInputText'],
            //   'disabled': false,
            //   'defaultvisibility': true,
            //   'required': true,
            //   'gridsize': Config.getFieldSize()['k375'],
            // },
            {
              'field': 'isactive',
              'text': 'Status',
              'type': Config.getHtmlcontorls()['kDropDown'],
              'disabled': false,
              'defaultvisibility': true,
              'required': true,
              'gridsize': Config.getFieldSize()['k375'],
              'masterdata': 'status',
              'masterdataarray': Config.getStatustype(),
              'defaultvalue': 1,
              'formdatafield': 'status',
              'cleanable': true,
              'searchable': true,
              'onchangedata': ['statusid'],
              'masterdatadependancy': false,
            },
          ]
        }
      ],
    };
  }
}


///state - maharashtrua - id
///city import - state fix with fix maharashtra starte id

