import mongoose from 'mongoose'
import _Config from "../../../config/Config.js"
const Config = new _Config()

export default class Items {
    constructor() {
        this._id
        this.assetname = { type: String, required: true }
        this.assetcost = { type: Number, required: true }
        this.assetqrcode = { type: Number }
        this.assetdescription = { type: String, required: true }
        this.seriesid = { type: mongoose.Schema.Types.ObjectId, ref: 'tblseriesmaster', maxLength: 50 }
        this.assetid = { type: String, maxLength: 50 }
        this.maxid = { type: Number, maxLength: 50 }
        this.serialnumber = { type: String, required: true, unique: true }
        this.wingfloororarea = { type: Number }
        this.wing = { type: String }
        this.wingid = { type: mongoose.Schema.Types.ObjectId, ref: 'tblpropertywing' }
        this.floor = { type: String }
        this.floorid = { type: mongoose.Schema.Types.ObjectId, ref: 'tblpropertyfloor' }
        this.area = { type: String }
        this.areaid = { type: mongoose.Schema.Types.ObjectId, ref: 'tblpropertyarea' }
        this.model = { type: String, required: true }
        this.assettype = { type: String }
        this.assettypeid = { type: mongoose.Schema.Types.ObjectId, ref: 'tblassettypemaster', }
        this.assetcategory = { type: String }
        this.assetcategoryid = { type: mongoose.Schema.Types.ObjectId, ref: 'tblAssetcategorymaster' }
        this.capacity = { type: Number }
        this.capacityunit = { type: String }
        this.capacityunitid = { type: mongoose.Schema.Types.ObjectId, ref: 'tblAssetcapacityunitmaster' }
        this.assetstatus = { type: String }
        this.assetstatusid = { type: mongoose.Schema.Types.ObjectId, ref: 'tblAssetstatusmaster', required: true }
        this.backgroundcolor = { type: String, required: true }
        this.purchasedate = { type: Date }
        this.underwarranty = { type: Number }
        this.warrantyexpiry = { type: Date }
        this.assignedto = [
            {
                wingid: { type: mongoose.Schema.Types.ObjectId, ref: "tblpropertywing", default: Config.dummyObjid },
                wing: { type: String, default: "" },
                floorid: { type: mongoose.Schema.Types.ObjectId, ref: "tblproperty", default: Config.dummyObjid },
                floor: { type: String, default: "" },
                areaid: { type: mongoose.Schema.Types.ObjectId, ref: "tblpropertyarea", default: Config.dummyObjid },
                area: { type: String, default: "" },
                date: { type: String }
            }
        ]
        this.missingreason = { type: String }
        this.assineehistory = [
            {
                currentwingid: { type: mongoose.Schema.Types.ObjectId, ref: "tblpropertywing", default: Config.dummyObjid },
                currentwing: { type: String },
                currentfloorid: { type: mongoose.Schema.Types.ObjectId, ref: "tblproperty", default: Config.dummyObjid },
                currentfloor: { type: String },
                currentareaid: { type: mongoose.Schema.Types.ObjectId, ref: "tblpropertyarea", default: Config.dummyObjid },
                currentarea: { type: String },
                currentdate: { type: String },
                conditionnameid: { type: mongoose.Schema.Types.ObjectId, ref: 'tblconditionmaster' },
                conditionname: { type: String },
                assetstatusid: { type: mongoose.Schema.Types.ObjectId }, // for assigee, seat or status
                assetstatus: { type: String },
                changeid: { type: mongoose.Schema.Types.ObjectId },
                change: { type: String },
                message: { type: String },
                assigneetype: { type: Number }, // 1 - insert, 2 - delete (assignee)     
                date: { type: String },
                assignto: { type: String },
                backgroundcolor: { type: String },
            }
        ]
        this.repairreplacehistory = [
            {
                vendorid: { type: mongoose.Schema.Types.ObjectId, ref: 'tblvendormaster' },
                vendor: { type: String },
                vendorstaffid: { type: mongoose.Schema.Types.ObjectId, ref: 'tblvendormaster' },
                vendorstaff: { type: String },
                employeeid: { type: mongoose.Schema.Types.ObjectId, ref: 'tblvendormaster' },
                employee: { type: String },
                date: { type: String },
                expecteddate: { type: String },
                contactno: { type: String },
                contactno_countrycode: { type: String },
                id: { type: Number },
                isrepair: { type: Number }, // 1- repair, 2- replace
                contactperson: { type: String },
            }
        ]
        this.lastassigneddate = { type: String }
        this.lastassignedbyid = { type: mongoose.Schema.Types.ObjectId, ref: 'tblpersonmaster' }
        this.lastassignedby = { type: String }
        this.isimportentry = { type: Number }
        this.soldscrapnote = { type: String }
        this.soldscrapdate = { type: Date }
        this.startdate = { type: Date }
        this.enddate = { type: Date }
        this.followups = [
            {
                followupstage: { type: String },
                followupdate: { type: String },
                followuptime: { type: String },
                followuptitle: { type: String },
                followupattachment: { type: Object },
                id: { type: Number }
            }
        ]
        this.clockin = { type: Number, default: 1 }   // 1-in,2-out
        this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: 'recordinfo' }
    }
    getDataName() {
        return "Asset"
    }
    getFieldOrder() {
        return {
            fields: [
                {
                    'field': 'action_button',
                    'text': '',
                    'type': Config.getHtmlcontorls()['action_button'],
                    'freeze': 1,
                    'active': 1,
                    'sorttable': 0,
                    'filter': 0,
                    'disableflex': 1,
                    'filterfieldtype': Config.getHtmlcontorls()['lookup'],
                    'defaultvalue': '',
                    'tblsize': Config.getTblgridsizeclasses()[10]
                },
                {
                    'field': 'assetstatus',
                    'text': 'Asset Status',
                    'type': 'status',
                    'freeze': 0,
                    'active': 1,
                    'sorttable': 1,
                    'sortby': 'assetstatus',
                    'filter': 1,
                    'filterfieldtype': Config.getHtmlcontorls()['dropdown'],
                    'filterfield': 'assetstatusid',
                    "masterdata": "assetstatus",
                    "masterdatafield": "assetstatus",
                    "formdatafield": "assetstatusid",
                    'tblsize': Config.getTblgridsizeclasses()[20]
                },

                {
                    'field': 'assetname',
                    'text': 'Asset Name',
                    'type': Config.getHtmlcontorls()['text'],
                    'freeze': 0,
                    'active': 1,
                    'sorttable': 1,
                    'sortby': 'assetname',
                    'filter': 0,
                    'filterfieldtype': Config.getHtmlcontorls()['lookup'],
                    'defaultvalue': '',
                    'tblsize': Config.getTblgridsizeclasses()[20]
                },
                {
                    'field': 'assetcost',
                    'text': 'Asset Cost',
                    'type': Config.getHtmlcontorls()['text'],
                    'freeze': 0,
                    'active': 1,
                    'sorttable': 1,
                    'sortby': 'assetcost',
                    'filter': 0,
                    'filterfieldtype': Config.getHtmlcontorls()['lookup'],
                    'defaultvalue': '',
                    'tblsize': Config.getTblgridsizeclasses()[20]
                },
                {
                    'field': 'assetdescription',
                    'text': 'Asset Description',
                    'type': Config.getHtmlcontorls()['text'],
                    'freeze': 0,
                    'active': 1,
                    'sorttable': 1,
                    'sortby': 'assetdescription',
                    'filter': 0,
                    'filterfieldtype': Config.getHtmlcontorls()['lookup'],
                    'defaultvalue': '',
                    'tblsize': Config.getTblgridsizeclasses()[40]
                },

                {
                    'field': 'serialnumber',
                    'text': 'Serial Number',
                    'type': Config.getHtmlcontorls()['text'],
                    'freeze': 0,
                    'active': 1,
                    'sorttable': 1,
                    'sortby': 'serialnumber',
                    'filter': 0,
                    'filterfieldtype': Config.getHtmlcontorls()['lookup'],
                    'defaultvalue': '',
                    'tblsize': Config.getTblgridsizeclasses()[20]
                },

                {
                    'field': 'assetfor',
                    'text': 'Asset For',
                    'type': 'assetfor',
                    'freeze': 0,
                    'active': 1,
                    'sorttable': 0,
                    'sortby': 'assetfor',
                    'filter': 0,
                    'filterfieldtype': Config.getHtmlcontorls()['dropdown'],
                    // 'filterfield': 'wingid',
                    // "masterdata": "property/wing",
                    // "masterdatafield": "wingname",
                    // "formdatafield": "wingid",
                    // "onchangefill": ["floorid"],
                    'tblsize': Config.getTblgridsizeclasses()[25]
                },
                // {
                //     'field': 'wing',
                //     'text': 'Wing',
                //     'type': Config.getHtmlcontorls()['text'],
                //     'freeze': 0,
                //     'active': 1,
                //     'sorttable': 1,
                //     'sortby': 'wing',
                //     'filter': 1,
                //     'filterfieldtype': Config.getHtmlcontorls()['dropdown'],
                //     'filterfield': 'wingid',
                //     "masterdata": "property/wing",
                //     "masterdatafield": "wingname",
                //     "formdatafield": "wingid",
                //     "onchangefill": ["floorid"],
                //     'tblsize': Config.getTblgridsizeclasses()[20]
                // },
                // {
                //     'field': 'floor',
                //     'text': 'Floor',
                //     'type': Config.getHtmlcontorls()['text'],
                //     'freeze': 0,
                //     'active': 1,
                //     'sorttable': 1,
                //     'sortby': 'floor',
                //     'filter': 1,
                //     "filterfieldtype": Config.getHtmlcontorls()['dropdown'],
                //     'filterfield': 'floorid',
                //     "masterdata": "property/floor",
                //     "dependentfilter": { "wingid": "wingid" },
                //     "masterdatafield": "floor",
                //     "formdatafield": "floorid",
                //     "masterdatadependancy": true,
                //     "onchangefill": ["areaid"],
                //     'tblsize': Config.getTblgridsizeclasses()[20]
                // },
                // {
                //     'field': 'area',
                //     'text': 'Area',
                //     'type': Config.getHtmlcontorls()['text'],
                //     'freeze': 0,
                //     'active': 1,
                //     'sorttable': 1,
                //     'sortby': 'area',
                //     'filter': 1,
                //     "dependentfilter": { "floorid": "floorid", "wingid": "wingid" },
                //     "masterdatadependancy": true,
                //     'filterfieldtype': Config.getHtmlcontorls()['dropdown'],
                //     'filterfield': 'areaid',
                //     "masterdata": "property/area",
                //     "masterdatafield": "area",
                //     "formdatafield": "areaid",
                //     'tblsize': Config.getTblgridsizeclasses()[20]
                // },
                {
                    'field': 'model',
                    'text': 'Model',
                    'type': Config.getHtmlcontorls()['text'],
                    'freeze': 0,
                    'active': 1,
                    'sorttable': 1,
                    'sortby': 'model',
                    'filter': 0,
                    'filterfieldtype': Config.getHtmlcontorls()['lookup'],
                    'defaultvalue': '',
                    'tblsize': Config.getTblgridsizeclasses()[20]
                },
                {
                    'field': 'assettype',
                    'text': 'Asset Type',
                    'type': Config.getHtmlcontorls()['text'],
                    'freeze': 0,
                    'active': 1,
                    'sorttable': 1,
                    'sortby': 'assettype',
                    'filter': 1,
                    'filterfieldtype': Config.getHtmlcontorls()['dropdown'],
                    'filterfield': 'assettypeid',
                    "masterdata": "assettype",
                    "masterdatafield": "assettype",
                    "formdatafield": "assettypeid",
                    'tblsize': Config.getTblgridsizeclasses()[20]
                },
                {
                    'field': 'assetcategory',
                    'text': 'Asset Category',
                    'type': Config.getHtmlcontorls()['text'],
                    'freeze': 0,
                    'active': 1,
                    'sorttable': 1,
                    'sortby': 'assetcategory',
                    'filter': 1,
                    'filterfieldtype': Config.getHtmlcontorls()['dropdown'],
                    'filterfield': 'assetcategoryid',
                    "masterdata": "assetcategory",
                    "masterdatafield": "assetcategory",
                    "formdatafield": "assetcategoryid",
                    'tblsize': Config.getTblgridsizeclasses()[20]
                },
                {
                    'field': 'capacity',
                    'text': 'Capacity',
                    'type': 'text',
                    'freeze': 0,
                    'active': 1,
                    'sorttable': 1,
                    'sortby': 'capacity',
                    'filter': 0,
                    'filterfieldtype': Config.getHtmlcontorls()['lookup'],
                    'defaultvalue': '',
                    'tblsize': Config.getTblgridsizeclasses()[20]
                },
                {
                    'field': 'capacityunit',
                    'text': 'Capacity Unit',
                    'type': Config.getHtmlcontorls()['text'],
                    'freeze': 0,
                    'active': 1,
                    'sorttable': 1,
                    'sortby': 'capacityunit',
                    'filter': 1,
                    'filterfieldtype': Config.getHtmlcontorls()['dropdown'],
                    'filterfield': 'capacityunitid',
                    "masterdata": "assetcapacityunit",
                    "masterdatafield": "assetcapacityunit",
                    "formdatafield": "capacityunitid",
                    'tblsize': Config.getTblgridsizeclasses()[20]
                },
                {
                    'field': 'assetstatus',
                    'text': 'Asset Status',
                    'type': Config.getHtmlcontorls()['text'],
                    'freeze': 0,
                    'active': 1,
                    'sorttable': 1,
                    'sortby': 'assetstatus',
                    'filter': 1,
                    'filterfieldtype': Config.getHtmlcontorls()['dropdown'],
                    'filterfield': 'assetstatusid',
                    "masterdata": "assetstatus",
                    "masterdatafield": "assetstatus",
                    "formdatafield": "assetstatusid",
                    'tblsize': Config.getTblgridsizeclasses()[20]
                },

                {
                    'field': 'purchasedate',
                    'text': 'Purchase Date',
                    'type': Config.getHtmlcontorls()['text'],
                    'freeze': 0,
                    'active': 1,
                    'sorttable': 1,
                    'sortby': 'purchasedate',
                    'filter': 1,
                    'filterfieldtype': Config.getHtmlcontorls()['datepicker'],
                    'filterfield': 'purchasedate',
                    'tblsize': Config.getTblgridsizeclasses()[20]
                },
                {
                    'field': 'warrantyexpiry',
                    'text': 'Warranty Expiry',
                    'type': Config.getHtmlcontorls()['text'],
                    'freeze': 0,
                    'active': 1,
                    'sorttable': 1,
                    'sortby': 'warrantyexpiry',
                    'filter': 1,
                    'filterfieldtype': Config.getHtmlcontorls()['datepicker'],
                    'filterfield': 'warrantyexpiry',
                    'tblsize': Config.getTblgridsizeclasses()[20]
                },
            ]
        }
    }
    getFormFieldOrder() {
        const Config = new _Config()

        return {
            "rightsidebarsize": Config.getModalsizeclasses()['775'],
            "pagename": 'assets',
            "formname": 'Asset(s)',
            "alias": 'assets',
            "dataview": "tab",
            'formfields': [
                {
                    "tab": "Asset(s)",
                    "formFields":
                        [

                            {
                                'field': 'assetname',
                                'text': 'Asset Name',
                                'type': Config.getHtmlcontorls()['input-text'],
                                'disabled': false,
                                'defaultvisibility': true,
                                'required': true,
                                'defaultvalue': '',
                                'gridsize': Config.getFieldSize()['k375'],
                            },

                            {
                                'field': 'assetdescription',
                                'text': 'Asset Description',
                                'type': Config.getHtmlcontorls()['kInputTextArea'],
                                'disabled': false,
                                'defaultvisibility': true,
                                'required': true,
                                'maxcharacters': 50,
                                'gridsize': Config.getFieldSize()['k375'],
                            },

                            {
                                'field': 'assetcost',
                                'text': 'Asset Cost',
                                'type': Config.getHtmlcontorls()['number-input'],
                                'defaultvalue': 0,
                                'gridsize': Config.getFieldSize()['k375'],
                                'disabled': false,
                                'defaultvisibility': true,
                                'required': true,
                            },
                            {
                                'field': 'serialnumber',
                                'text': 'Serial Number',
                                'type': Config.getHtmlcontorls()['input-text'],
                                'defaultvalue': '',
                                'disabled': false,
                                'defaultvisibility': true,
                                'required': true,
                                'maxcharacters': 18,
                                'gridsize': Config.getFieldSize()['k375'],
                            },
                            {
                                'field': 'wingfloororarea',
                                'text': 'Wing & Floor or Area',
                                'type': 'radio',
                                'disabled': false,
                                'defaultvisibility': true,
                                'required': false,
                                'gridsize': 775,
                                'defaultvalue': 0,
                                'masterdata': 'wingfloororarea',
                                'masterdataarray': [
                                    { 'label': 'Wing & Floor', 'value': 0 },
                                    { 'label': 'Area', 'value': 1 },
                                ],
                            },
                            {
                                "field": "wingid",
                                "text": "Wing",
                                "type": "dropdown",
                                "disabled": false,
                                "defaultvisibility": true,
                                "required": false,
                                "gridsize": 375,
                                "masterdata": "property/wing",
                                "masterdatafield": "wingname",
                                "formdatafield": "wing",
                                'required': true,
                                "cleanable": true,
                                "searchable": true,
                                "onchangefill": ["floorid"],
                                "condition": { "wingfloororarea": [0] },
                                "masterdatadependancy": false,
                                "staticfilter": { "isactive": 1 }
                            },
                            {
                                "field": "floorid",
                                "text": "Floor",
                                "type": "dropdown",
                                "disabled": false,
                                "defaultvisibility": true,
                                "required": false,
                                "gridsize": 375,
                                'required': true,
                                "masterdata": "property/floor",
                                "masterdatafield": "floor",
                                "formdatafield": "floor",
                                "cleanable": true,
                                "searchable": true,
                                "dependentfilter": { "wingid": "wingid" },
                                "condition": { "wingfloororarea": [0] },
                                "masterdatadependancy": true,
                                "staticfilter": { "isactive": 1 },
                            },
                            {
                                "field": "areaid",
                                "text": "Area",
                                "type": "dropdown",
                                "disabled": false,
                                "defaultvisibility": true,
                                "required": false,
                                "gridsize": 375,
                                'required': true,
                                "masterdata": "property/area",
                                "masterdatafield": "area",
                                "formdatafield": "area",
                                "cleanable": true,
                                "searchable": true,
                                "condition": { "wingfloororarea": [1] },
                                "masterdatadependancy": false,
                                "staticfilter": { "isactive": 1 },
                            },
                            {
                                'field': 'model',
                                'text': 'Model Number',
                                'type': Config.getHtmlcontorls()['kInputText'],
                                'disabled': false,
                                'defaultvisibility': true,
                                'required': true,
                                'maxcharacters': 25,
                                'gridsize': Config.getFieldSize()['k375'],
                            },
                            {
                                'field': 'assettypeid',
                                'text': 'Asset type',
                                'type': Config.getHtmlcontorls()['kDropDown'],
                                'disabled': false,
                                'defaultvisibility': true,
                                'gridsize': Config.getFieldSize()['k375'],
                                'masterdata': 'assettype',
                                'masterdatafield': 'assettype',
                                'formdatafield': 'assettype',
                                'cleanable': true,
                                'searchable': true,
                                "masterdatadependancy": false,
                            },
                            {
                                "field": "assetcategoryid",
                                "text": "Asset Category",
                                "type": "dropdown",
                                "disabled": false,
                                "defaultvisibility": true,
                                "required": true,
                                "gridsize": 375,
                                "masterdata": "assetcategory",
                                "masterdatafield": "assetcategory",
                                "formdatafield": "assetcategory",
                                "cleanable": true,
                                "searchable": true,
                                "masterdatadependancy": false,
                                "staticfilter": { "isactive": 1 }
                            },
                            {
                                "field": "capacity",
                                "text": "Capacity",
                                'type': Config.htmlcontorls['number-input'],
                                'gridsize': Config.getFieldSize()['k375'],
                                'decimalpoint': 0,
                                'disabled': false,
                                'defaultvisibility': true,
                            },
                            {
                                "field": "capacityunitid",
                                "text": "Capacity Unit",
                                "type": "dropdown",
                                "disabled": false,
                                "defaultvisibility": true,
                                "required": false,
                                "gridsize": 375,
                                "masterdata": "assetcapacityunit",
                                "masterdatafield": "assetcapacityunit",
                                "formdatafield": "capacityunit",
                                "cleanable": true,
                                "searchable": true,
                                "masterdatadependancy": false,
                                "staticfilter": { "isactive": 1 }
                            },
                            {
                                "field": "purchasedate",
                                "text": "Purchase Date",
                                "type": "datepicker",
                                "disabled": false,
                                "defaultvisibility": true,
                                "required": false,
                                "gridsize": 375
                            },
                            {
                                'field': 'underwarranty',
                                'text': 'Under Warranty',
                                'type': 'checkbox',
                                'disabled': false,
                                'required': false,
                                'defaultvalue': 0,
                                'defaultvisibility': true,
                                'gridsize': 150,
                            },
                            {
                                "field": "warrantyexpiry",
                                "text": "Warranty Expiry",
                                "type": "datepicker",
                                "disabled": false,
                                "defaultvisibility": true,
                                "required": true,
                                "gridsize": 375,
                                "condition": {
                                    "underwarranty": [1]
                                }
                            },

                        ]
                }
            ],
        }
    }
}