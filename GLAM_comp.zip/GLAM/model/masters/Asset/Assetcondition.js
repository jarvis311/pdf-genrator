import mongoose from 'mongoose'
import { Config } from '../../../config/Init.js'

export default class AssetCondition {
  constructor() {
    this._id
    this.assetcondition = { type: String, required: true, trim: true, index: { unique: true, collation: { locale: 'en', strength: 1 } } }
    this.isactive = { type: Number, required: true, default: 1 } // 1 - active, 0 - deactive
    this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: 'recordinfo' }
  }

  getDataName() {
    return "Asset Condition"
  }

  getFieldOrder() {
    return {
      fields: [
        {
          'field': 'action_button',
          'text': '',
          'type': Config.getHtmlcontorls()['action_button'],
          'freeze': 1,
          'active': 1,
          'sorttable': 0,
          'filter': 0,
          'disableflex': 1,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': 8
        },
        {
          'field': 'isactive',
          'text': 'Status',
          'type': Config.getHtmlcontorls()['isactive'],
          'freeze': 0,
          'active': 1,
          'sorttable': 0,
          'filter': 0,
          'disableflex': 1,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': 15
        },
        {
          'field': 'assetcondition',
          'text': 'Asset Condition',
          'type': Config.getHtmlcontorls()['text'],
          'freeze': 0,
          'active': 1,
          'sorttable': 1,
          'filter': 0,
          'sortby': 'assetcondition',
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': 165
        }
      ]
    }
  }

  getFormFieldOrder() {
    return {
      "rightsidebarsize": 400,
      "pagename": "assetcondition",
      "formname": "Asset Condition",
      "alias": "assetcondition",
      "dataview": "tab",
      "formfields": [
        {
          "tab": "condition",
          "formFields": [
            {
              "field": "assetcondition",
              "text": "Asset Condition ",
              "type": "input-text",
              "disabled": false,
              "defaultvisibility": true,
              "required": true,
              "gridsize": 375,
              "capitalcase": true
            },
          ]
        }
      ]
    }
  }
}

