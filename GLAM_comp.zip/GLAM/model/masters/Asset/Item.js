import mongoose from 'mongoose'
import _Config from "../../../config/Config.js"
const Config = new _Config()

export default class Items {
    constructor() {
        this._id
        // this.itemname = { type: String, required: true, index: true, unique: true }
        // this.assetcategoryid = { type: mongoose.Schema.Types.ObjectId, ref: 'tblAssetcategorymaster' }
        // this.assetcategory = { type: String, required: [true, 'Asset Category is required'] }
        // this.assettypes = [{
        //     assettype: { type: String },
        //     assettypeid: { type: String }
        // }]
        // this.assetimage = { type: Object, default: {} }
        // this.brand = { type: String }
        // this.model = { type: String }
        // this.assetdescription = { type: String }
        // this.isasset = { type: Number } //
        // this.taxgroup = { type: String },
        //     this.hsncode = { type: String },
        //     this.taxprefrence = { type: Number } // 1 - Taxable 2 - Non - Taxable  3 - Out Of Scope 4 - Non-Gst Supply
        // this.seriesid = { type: mongoose.Schema.Types.ObjectId, ref: 'tblseriesmaster', maxLength: 50 }
        // this.maxid = { type: Number, maxLength: 50 }
        // this.assetconditionid = { type: mongoose.Schema.Types.ObjectId }
        // this.assetcondition = { type: String }
        // // this.assetid = { type: String, required: [true, "Assetid is required"], maxLength: 50 }
        // this.propertyid = { type: mongoose.Schema.Types.ObjectId, ref: 'tblbranchmaster' }
        // this.property = { type: String }
        // this.wingid = { type: mongoose.Schema.Types.ObjectId, ref: 'tblpropertywing' }
        // this.wing = { type: String }
        // this.floorid = { type: mongoose.Schema.Types.ObjectId, ref: 'tblpropertyfloor' }
        // this.floor = { type: String }

        this.assetcode = { type: Number, required: true, index: true, unique: true }
        this.assetname = { type: String, required: true }
        this.assetdescription = { type: String, required: true }
        this.additionaldescription = { type: String, required: true }
        this.serialnumber = { type: String, required: true }
        this.inventorynumber = { type: String }
        this.placedinarea = { type: Number, default: 0 }
        this.wing = { type: String }
        this.wingid = { type: mongoose.Schema.Types.ObjectId, ref: 'tblpropertywing' }
        this.floor = { type: String }
        this.floorid = { type: mongoose.Schema.Types.ObjectId, ref: 'tblpropertyfloor' }
        this.area = { type: String }
        this.areaid = { type: mongoose.Schema.Types.ObjectId, ref: 'tblpropertyarea', required: true }
        this.model = { type: String, required: true }
        this.assettype = { type: String }
        this.assettypeid = { type: mongoose.Schema.Types.ObjectId, ref: 'tblassettypemaster', }
        this.assetcategory = { type: String }
        this.assetcategoryid = { type: mongoose.Schema.Types.ObjectId, ref: 'tblAssetcategorymaster' }
        this.capacity = { type: Number }
        this.capacityunit = { type: String }
        this.capacityunitid = { type: mongoose.Schema.Types.ObjectId, ref: 'tblAssetcapacityunitmaster' }
        this.assetstatus = { type: String }
        this.assetstatusid = { type: mongoose.Schema.Types.ObjectId, ref: 'tblAssetstatusmaster', required: true }
        this.backgroundcolor = { type: String, required: true }
        this.purchasedate = { type: Date }
        this.underwarranty = { type: Number }
        this.warrantyexpiry = { type: Date }
        this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: 'recordinfo' }
    }
    getDataName() {
        return "Asset"
    }
    getFieldOrder() {
        return {
            fields: [
                {
                    'field': 'action_button',
                    'text': '',
                    'type': Config.getHtmlcontorls()['action_button'],
                    'freeze': 1,
                    'active': 1,
                    'sorttable': 0,
                    'filter': 0,
                    'disableflex': 1,
                    'filterfieldtype': Config.getHtmlcontorls()['lookup'],
                    'defaultvalue': '',
                    'tblsize': Config.getTblgridsizeclasses()[10]
                },
                {
                    'field': 'assetstatus',
                    'text': 'Asset Status',
                    'type': 'status',
                    'freeze': 0,
                    'active': 1,
                    'sorttable': 1,
                    'sortby': 'assetstatus',
                    'filter': 1,
                    'filterfieldtype': Config.getHtmlcontorls()['dropdown'],
                    'filterfield': 'assetstatusid',
                    "masterdata": "assetstatus",
                    "masterdatafield": "assetstatus",
                    "formdatafield": "assetstatusid",
                    'tblsize': Config.getTblgridsizeclasses()[20]
                },
                {
                    'field': 'assetcode',
                    'text': 'Asset Code',
                    'type': Config.getHtmlcontorls()['text'],
                    'freeze': 0,
                    'active': 1,
                    'sorttable': 1,
                    'sortby': 'assetcode',
                    'filter': 0,
                    'filterfieldtype': Config.getHtmlcontorls()['lookup'],
                    'defaultvalue': '',
                    'tblsize': Config.getTblgridsizeclasses()[20]
                },
                {
                    'field': 'assetname',
                    'text': 'Asset Name',
                    'type': Config.getHtmlcontorls()['text'],
                    'freeze': 0,
                    'active': 1,
                    'sorttable': 1,
                    'sortby': 'assetname',
                    'filter': 0,
                    'filterfieldtype': Config.getHtmlcontorls()['lookup'],
                    'defaultvalue': '',
                    'tblsize': Config.getTblgridsizeclasses()[20]
                },
                {
                    'field': 'assetdescription',
                    'text': 'Asset Description',
                    'type': Config.getHtmlcontorls()['text'],
                    'freeze': 0,
                    'active': 1,
                    'sorttable': 1,
                    'sortby': 'assetdescription',
                    'filter': 0,
                    'filterfieldtype': Config.getHtmlcontorls()['lookup'],
                    'defaultvalue': '',
                    'tblsize': Config.getTblgridsizeclasses()[40]
                },
                {
                    'field': 'additionaldescription',
                    'text': 'Additional Description',
                    'type': Config.getHtmlcontorls()['text'],
                    'freeze': 0,
                    'active': 1,
                    'sorttable': 1,
                    'sortby': 'additionaldescription',
                    'filter': 0,
                    'filterfieldtype': Config.getHtmlcontorls()['lookup'],
                    'defaultvalue': '',
                    'tblsize': Config.getTblgridsizeclasses()[40]
                },
                {
                    'field': 'serialnumber',
                    'text': 'Serial Number',
                    'type': Config.getHtmlcontorls()['text'],
                    'freeze': 0,
                    'active': 1,
                    'sorttable': 1,
                    'sortby': 'serialnumber',
                    'filter': 0,
                    'filterfieldtype': Config.getHtmlcontorls()['lookup'],
                    'defaultvalue': '',
                    'tblsize': Config.getTblgridsizeclasses()[20]
                },
                {
                    'field': 'inventorynumber',
                    'text': 'Inventory Number',
                    'type': Config.getHtmlcontorls()['text'],
                    'freeze': 0,
                    'active': 1,
                    'sorttable': 1,
                    'sortby': 'inventorynumber',
                    'filter': 0,
                    'filterfieldtype': Config.getHtmlcontorls()['lookup'],
                    'defaultvalue': '',
                    'tblsize': Config.getTblgridsizeclasses()[20]
                },
                {
                    'field': 'wing',
                    'text': 'Wing',
                    'type': Config.getHtmlcontorls()['text'],
                    'freeze': 0,
                    'active': 1,
                    'sorttable': 1,
                    'sortby': 'wing',
                    'filter': 1,
                    'filterfieldtype': Config.getHtmlcontorls()['dropdown'],
                    'filterfield': 'wingid',
                    "masterdata": "property/wing",
                    "masterdatafield": "wingname",
                    "formdatafield": "wingid",
                    "onchangefill": ["floorid"],
                    'tblsize': Config.getTblgridsizeclasses()[20]
                },
                {
                    'field': 'floor',
                    'text': 'Floor',
                    'type': Config.getHtmlcontorls()['text'],
                    'freeze': 0,
                    'active': 1,
                    'sorttable': 1,
                    'sortby': 'floor',
                    'filter': 1,
                    "filterfieldtype": Config.getHtmlcontorls()['dropdown'],
                    'filterfield': 'floorid',
                    "masterdata": "property/floor",
                    "dependentfilter": { "wingid": "wingid" },
                    "masterdatafield": "floor",
                    "formdatafield": "floorid",
                    "masterdatadependancy": true,
                    "onchangefill": ["areaid"],
                    'tblsize': Config.getTblgridsizeclasses()[20]
                },
                {
                    'field': 'area',
                    'text': 'Area',
                    'type': Config.getHtmlcontorls()['text'],
                    'freeze': 0,
                    'active': 1,
                    'sorttable': 1,
                    'sortby': 'area',
                    'filter': 1,
                    "dependentfilter": { "floorid": "floorid", "wingid": "wingid" },
                    "masterdatadependancy": true,
                    'filterfieldtype': Config.getHtmlcontorls()['dropdown'],
                    'filterfield': 'areaid',
                    "masterdata": "property/area",
                    "masterdatafield": "area",
                    "formdatafield": "areaid",
                    'tblsize': Config.getTblgridsizeclasses()[20]
                },
                {
                    'field': 'model',
                    'text': 'Model',
                    'type': Config.getHtmlcontorls()['text'],
                    'freeze': 0,
                    'active': 1,
                    'sorttable': 1,
                    'sortby': 'model',
                    'filter': 0,
                    'filterfieldtype': Config.getHtmlcontorls()['lookup'],
                    'defaultvalue': '',
                    'tblsize': Config.getTblgridsizeclasses()[20]
                },
                {
                    'field': 'assettype',
                    'text': 'Asset Type',
                    'type': Config.getHtmlcontorls()['text'],
                    'freeze': 0,
                    'active': 1,
                    'sorttable': 1,
                    'sortby': 'assettype',
                    'filter': 1,
                    'filterfieldtype': Config.getHtmlcontorls()['dropdown'],
                    'filterfield': 'assettypeid',
                    "masterdata": "assettype",
                    "masterdatafield": "assettype",
                    "formdatafield": "assettypeid",
                    'tblsize': Config.getTblgridsizeclasses()[20]
                },
                {
                    'field': 'assetcategory',
                    'text': 'Asset Category',
                    'type': Config.getHtmlcontorls()['text'],
                    'freeze': 0,
                    'active': 1,
                    'sorttable': 1,
                    'sortby': 'assetcategory',
                    'filter': 1,
                    'filterfieldtype': Config.getHtmlcontorls()['dropdown'],
                    'filterfield': 'assetcategoryid',
                    "masterdata": "assetcategory",
                    "masterdatafield": "assetcategory",
                    "formdatafield": "assetcategoryid",
                    'tblsize': Config.getTblgridsizeclasses()[20]
                },
                {
                    'field': 'capacity',
                    'text': 'Capacity',
                    'type': 'text',
                    'freeze': 0,
                    'active': 1,
                    'sorttable': 1,
                    'sortby': 'capacity',
                    'filter': 0,
                    'filterfieldtype': Config.getHtmlcontorls()['lookup'],
                    'defaultvalue': '',
                    'tblsize': Config.getTblgridsizeclasses()[20]
                },
                {
                    'field': 'capacityunit',
                    'text': 'Capacity Unit',
                    'type': Config.getHtmlcontorls()['text'],
                    'freeze': 0,
                    'active': 1,
                    'sorttable': 1,
                    'sortby': 'capacityunit',
                    'filter': 1,
                    'filterfieldtype': Config.getHtmlcontorls()['dropdown'],
                    'filterfield': 'capacityunitid',
                    "masterdata": "assetcapacityunit",
                    "masterdatafield": "assetcapacityunit",
                    "formdatafield": "capacityunitid",
                    'tblsize': Config.getTblgridsizeclasses()[20]
                },
                {
                    'field': 'assetstatus',
                    'text': 'Asset Status',
                    'type': Config.getHtmlcontorls()['text'],
                    'freeze': 0,
                    'active': 1,
                    'sorttable': 1,
                    'sortby': 'assetstatus',
                    'filter': 1,
                    'filterfieldtype': Config.getHtmlcontorls()['dropdown'],
                    'filterfield': 'assetstatusid',
                    "masterdata": "assetstatus",
                    "masterdatafield": "assetstatus",
                    "formdatafield": "assetstatusid",
                    'tblsize': Config.getTblgridsizeclasses()[20]
                },

                {
                    'field': 'purchasedate',
                    'text': 'Purchase Date',
                    'type': Config.getHtmlcontorls()['text'],
                    'freeze': 0,
                    'active': 1,
                    'sorttable': 1,
                    'sortby': 'purchasedate',
                    'filter': 1,
                    'filterfieldtype': Config.getHtmlcontorls()['datepicker'],
                    'filterfield': 'purchasedate',
                    'tblsize': Config.getTblgridsizeclasses()[20]
                },
                {
                    'field': 'warrantyexpiry',
                    'text': 'Warranty Expiry',
                    'type': Config.getHtmlcontorls()['text'],
                    'freeze': 0,
                    'active': 1,
                    'sorttable': 1,
                    'sortby': 'warrantyexpiry',
                    'filter': 1,
                    'filterfieldtype': Config.getHtmlcontorls()['datepicker'],
                    'filterfield': 'warrantyexpiry',
                    'tblsize': Config.getTblgridsizeclasses()[20]
                },
            ]
        }
    }
    getFormFieldOrder() {
        const Config = new _Config()

        return {
            "rightsidebarsize": Config.getModalsizeclasses()['775'],
            "pagename": 'asset',
            "formname": 'Asset(s)',
            "alias": 'asset',
            "dataview": "tab",
            'formfields': [
                {
                    "tab": "Asset(s)",
                    "formFields":
                        [
                            {
                                'field': 'assetcode',
                                'text': 'Asset Code',
                                'type': Config.getHtmlcontorls()['number-input'],
                                'defaultvalue': 0,
                                'gridsize': Config.getFieldSize()['k375'],
                                'disabled': false,
                                'defaultvisibility': true,
                                'required': true,
                            },
                            {
                                'field': 'assetname',
                                'text': 'Asset Name',
                                'type': Config.getHtmlcontorls()['input-text'],
                                'disabled': false,
                                'defaultvisibility': true,
                                'required': true,
                                'defaultvalue': '',
                                'gridsize': Config.getFieldSize()['k375'],
                            },
                            {
                                'field': 'assetdescription',
                                'text': 'Asset Description',
                                'type': Config.getHtmlcontorls()['kInputTextArea'],
                                'disabled': false,
                                'defaultvisibility': true,
                                'required': true,
                                'gridsize': Config.getFieldSize()['k375'],
                            },
                            {
                                'field': 'additionaldescription',
                                'text': 'Additional Description',
                                'type': Config.getHtmlcontorls()['kInputTextArea'],
                                'disabled': false,
                                'defaultvisibility': true,
                                'gridsize': Config.getFieldSize()['k375'],
                            },
                            {
                                'field': 'serialnumber',
                                'text': 'Serial Number',
                                'type': Config.getHtmlcontorls()['input-text'],
                                'defaultvalue': '',
                                'disabled': false,
                                'defaultvisibility': true,
                                'required': true,
                                'gridsize': Config.getFieldSize()['k375'],
                            },

                            {
                                'field': 'inventorynumber',
                                'text': 'Inventory Number',
                                'type': Config.getHtmlcontorls()['input-text'],
                                'defaultvalue': '',
                                'disabled': false,
                                'defaultvisibility': true,
                                'gridsize': Config.getFieldSize()['k375'],
                            },
                            {
                                'field': 'placedinarea',
                                'text': 'Placed in Area?',
                                'type': 'checkbox',
                                'disabled': false,
                                'required': false,
                                'defaultvisibility': true,
                                'gridsize': Config.getFieldSize()['k750'],
                            },
                            {
                                "field": "wingid",
                                "text": "Wing",
                                "type": "dropdown",
                                "disabled": false,
                                "defaultvisibility": true,
                                "required": false,
                                "gridsize": 375,
                                "masterdata": "property/wing",
                                "masterdatafield": "wingname",
                                "formdatafield": "wing",
                                'required': true,
                                "cleanable": true,
                                "searchable": true,
                                "onchangefill": ["floorid"],
                                "masterdatadependancy": false,
                                "staticfilter": { "isactive": 1 },
                                "condition": { "placedinarea": [0] }
                            },
                            {
                                "field": "floorid",
                                "text": "Floor",
                                "type": "dropdown",
                                "disabled": false,
                                "defaultvisibility": true,
                                "required": false,
                                "gridsize": 375,
                                'required': true,
                                "masterdata": "property/floor",
                                "masterdatafield": "floor",
                                "formdatafield": "floor",
                                "cleanable": true,
                                "searchable": true,
                                "dependentfilter": { "wingid": "wingid" },
                                "masterdatadependancy": true,
                                "staticfilter": { "isactive": 1 },
                                "onchangefill": ["areaid"],
                                "condition": { "placedinarea": [0] }
                            },
                            {
                                "field": "areaid",
                                "text": "Area",
                                "type": "dropdown",
                                "disabled": false,
                                "defaultvisibility": true,
                                "required": false,
                                "gridsize": 375,
                                'required': true,
                                "masterdata": "property/area",
                                "masterdatafield": "area",
                                "formdatafield": "area",
                                "cleanable": true,
                                "searchable": true,
                                "dependentfilter": { "floorid": "floorid", "wingid": "wingid" },
                                "masterdatadependancy": true,
                                "staticfilter": { "isactive": 1 },
                                "condition": { "placedinarea": [0] }
                            },
                            {
                                'field': 'model',
                                'text': 'Model Number',
                                'type': Config.getHtmlcontorls()['kInputText'],
                                'disabled': false,
                                'defaultvisibility': true,
                                'required': true,
                                'gridsize': Config.getFieldSize()['k375'],
                            },
                            {
                                'field': 'assettypeid',
                                'text': 'Asset type',
                                'type': Config.getHtmlcontorls()['kDropDown'],
                                'disabled': false,
                                'defaultvisibility': true,
                                'gridsize': Config.getFieldSize()['k375'],
                                'masterdata': 'assettype',
                                'masterdatafield': 'assettype',
                                'formdatafield': 'assettype',
                                'cleanable': true,
                                'searchable': true,
                                "masterdatadependancy": false,
                            },
                            {
                                "field": "assetcategoryid",
                                "text": "Asset Category",
                                "type": "dropdown",
                                "disabled": false,
                                "defaultvisibility": true,
                                "required": true,
                                "gridsize": 375,
                                "masterdata": "assetcategory",
                                "masterdatafield": "assetcategory",
                                "formdatafield": "assetcategory",
                                "cleanable": true,
                                "searchable": true,
                                "masterdatadependancy": false,
                                "staticfilter": { "isactive": 1 }
                            },
                            {
                                "field": "capacity",
                                "text": "Capacity",
                                'type': Config.htmlcontorls['number-input'],
                                'gridsize': Config.getFieldSize()['k375'],
                                'decimalpoint': 0,
                                'disabled': false,
                                'defaultvisibility': true,
                            },
                            {
                                "field": "capacityunitid",
                                "text": "Capacity Unit",
                                "type": "dropdown",
                                "disabled": false,
                                "defaultvisibility": true,
                                "required": false,
                                "gridsize": 375,
                                "masterdata": "assetcapacityunit",
                                "masterdatafield": "assetcapacityunit",
                                "formdatafield": "capacityunit",
                                "cleanable": true,
                                "searchable": true,
                                "masterdatadependancy": false,
                                "staticfilter": { "isactive": 1 }
                            },
                            {
                                "field": "assetstatusid",
                                "text": "Asset Status",
                                "type": "dropdown",
                                "disabled": false,
                                "defaultvisibility": true,
                                "required": false,
                                "gridsize": 375,
                                "masterdata": "assetstatus",
                                "masterdatafield": "assetstatus",
                                "formdatafield": "assetstatus",
                                "cleanable": true,
                                "searchable": true,
                                "masterdatadependancy": false,
                                "staticfilter": { "isactive": 1 },
                                "storeextrakeys": { "backgroundcolor": "backgroundcolor" },
                            },
                            {
                                "field": "purchasedate",
                                "text": "Purchase Date",
                                "type": "datepicker",
                                "disabled": false,
                                "defaultvisibility": true,
                                "required": false,
                                "gridsize": 375
                            },
                            {
                                'field': 'underwarranty',
                                'text': 'Under Warranty',
                                'type': 'checkbox',
                                'disabled': false,
                                'required': false,
                                'defaultvalue': 0,
                                'defaultvisibility': true,
                                'gridsize': 150,
                            },
                            {
                                "field": "warrantyexpiry",
                                "text": "Warranty Expiry",
                                "type": "datepicker",
                                "disabled": false,
                                "defaultvisibility": true,
                                "required": true,
                                "gridsize": 375,
                                "condition": {
                                    "underwarranty": [1]
                                }
                            },

                        ]
                }
            ],
        }
    }
}