import mongoose from "mongoose"
import _Config from "../../config/Config.js"
const Config = new _Config()

export default class Country {
  constructor() {
    this._id
    this.countrycode = { type: String, required: true, trim: true, unique: true }
    this.countrydialcode = { type: String, required: true }
    // this.flag = { type: String, required: true }
    this.country = { type: String, required: true, trim: true, unique: true }
    this.isactive = { type: Number, required: true, default: 1 } // 1 - active, 0 - deactive
    this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: "recordinfo" }
  }

  getDataName() {
    return "Country"
  }


  getFieldOrder() {

    return {
      fields: [
        {
          'field': 'action_button',
          'text': '',
          'type': Config.getHtmlcontorls()['action_button'],
          'freeze': 1,
          'active': 1,
          'sorttable': 0,
          'filter': 0,
          'disableflex': 1,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': 8
        },
        {
          'field': 'isactive',
          'text': 'Status',
          'type': Config.getHtmlcontorls()['isactive'],
          'freeze': 1,
          'active': 1,
          'sorttable': 0,
          'filter': 0,
          'disableflex': 1,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': 15
        },
        {
          'field': 'country',
          'text': 'Country',
          'type': Config.getHtmlcontorls()['text'],
          'freeze': 1,
          'active': 1,
          'sorttable': 1,
          'sortby': 'country',
          'filter': 0,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': 100
        },
        {
          'field': 'countrycode',
          'text': 'Country Short Code',
          'type': Config.getHtmlcontorls()['text'],
          'freeze': 1,
          'active': 1,
          'sorttable': 1,
          'sortby': 'countrycode',
          'filter': 0,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': 30
        },
        {
          'field': 'countrydialcode',
          'text': 'Country Dial Code',
          'type': Config.getHtmlcontorls()['text'],
          'freeze': 1,
          'active': 1,
          'sorttable': 1,
          'sortby': 'countrydialcode',
          'filter': 0,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': 35
        }
        // {
        //   'field': 'flag',
        //   'text': 'Flag',
        //   'type': Config.getHtmlcontorls()['text'],
        //   'freeze': 1,
        //   'active': 1,
        //   'sorttable': 0,
        //   'filter': 1,
        //   'filterfieldtype': Config.getHtmlcontorls()['lookup'],
        //   'defaultvalue': '',
        //   'tblsize': Config.getTblgridsizeclasses()[15]
        // }
      ]
    }
  }

  getFormFieldOrder() {
    return {
      "rightsidebarsize": Config.getModalsizeclasses()['xs'],
      "pagename": 'country',
      "formname": 'Country',
      "alias": 'country',
      "dataview": "country",
      'formfields': [
        {
          "tab": "country",
          "formFields": [
            {
              'field': 'country',
              'text': 'Country Name',
              'type': Config.getHtmlcontorls()['kInputText'],
              'disabled': false,
              'defaultvisibility': true,
              'required': true,
              'gridsize': Config.getFieldSize()['k375'],
              "capitalcase": true
            },
            {
              'field': 'countrycode',
              'text': 'Country Short Code',
              'type': Config.getHtmlcontorls()['kInputText'],
              'disabled': false,
              'defaultvisibility': true,
              'required': true,
              'gridsize': Config.getFieldSize()['k375'],

            },
            {
              'field': 'countrydialcode',
              'text': 'Country Dial Code',
              'type': Config.getHtmlcontorls()['kInputText'],
              'disabled': false,
              'defaultvisibility': true,
              'required': true,
              'gridsize': Config.getFieldSize()['k375'],
              "regxtype": "countrydialcode"

            },
            // {
            //   'field': 'flag',
            //   'text': 'Flag',
            //   'type': Config.getHtmlcontorls()['kInputText'],
            //   'disabled': false,
            //   'defaultvisibility': true,
            //   'required': true,
            //   'gridsize': Config.getFieldSize()['k375'],
            // },
            {
              'field': 'isactive',
              'text': 'Status',
              'type': Config.getHtmlcontorls()['kDropDown'],
              'disabled': false,
              'defaultvisibility': true,
              'required': true,
              'gridsize': Config.getFieldSize()['k375'],
              'masterdata': 'status',
              'masterdataarray': Config.getStatustype(),
              'defaultvalue': 1,
              'formdatafield': 'status',
              'cleanable': true,
              'searchable': true,
              'onchangedata': ['statusid'],
              'masterdatadependancy': false,
            },
          ]
        }
      ],
    }
  }

}
