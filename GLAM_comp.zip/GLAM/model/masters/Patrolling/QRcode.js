import mongoose from 'mongoose'
import { Config } from '../../../config/Init.js'

export default class QRcode {
    constructor() {
        this._id
        this.propertyid = { type: mongoose.Schema.Types.ObjectId, ref: "tblpropertymaster" }
        this.property = { type: String, trim: true }
        this.qrname = { type: String, trim: true, required: true }
        this.qrcode = { type: String, required: true, trim: true, index: { unique: true, collation: { locale: 'en', strength: 1 } } }
        this.isactive = { type: Number, required: true, default: 1 } // 1 - active, 0 - deactive
        this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: 'recordinfo' }
    }

    getDataName() {
        return "QRcode"
    }

    getIndexes() {
        return [[{ qrname: 1, propertyid: 1 }, { unique: 1 }]]
    }

    getFieldOrder() {
        return {
            fields: [
                {
                    'field': 'action_button',
                    'text': '',
                    'type': Config.getHtmlcontorls()['action_button'],
                    'freeze': 1,
                    'active': 1,
                    'sorttable': 0,
                    'filter': 0,
                    'disableflex': 1,
                    'filterfieldtype': Config.getHtmlcontorls()['lookup'],
                    'defaultvalue': '',
                    'tblsize': 8
                },
                {
                    'field': 'isactive',
                    'text': 'Status',
                    'type': Config.getHtmlcontorls()['isactive'],
                    'freeze': 0,
                    'active': 1,
                    'sorttable': 0,
                    'filter': 0,
                    'disableflex': 1,
                    'filterfieldtype': Config.getHtmlcontorls()['lookup'],
                    'defaultvalue': '',
                    'tblsize': 15
                },
                {
                    'field': 'qrname',
                    'text': 'QRcode Name',
                    'type': Config.getHtmlcontorls()['text'],
                    'freeze': 0,
                    'active': 1,
                    'sorttable': 1,
                    'filter': 0,
                    'sortby': 'qrname',
                    'filterfieldtype': Config.getHtmlcontorls()['lookup'],
                    'defaultvalue': '',
                    'tblsize': 20
                },
                {
                    'field': 'qrcode',
                    'text': 'Download QR Code',
                    'type': "download-button",
                    'freeze': 0,
                    'active': 1,
                    'sorttable': 0,
                    'filter': 0,
                    'filterfieldtype': Config.getHtmlcontorls()['lookup'],
                    'defaultvalue': '',
                    'tblsize': 158
                }
            ]
        }
    }

    getFormFieldOrder() {
        return {
            "rightsidebarsize": 400,
            "pagename": "qrcode",
            "formname": "QRcode",
            "alias": "qrcode",
            "dataview": "tab",
            "formfields": [
                {
                    "tab": "amenities",
                    "formFields": [
                        {
                            "field": "qrname",
                            "text": "QRcode Name",
                            "type": "input-text",
                            "disabled": false,
                            "defaultvisibility": true,
                            "required": true,
                            "gridsize": 375,
                            "capitalcase": true
                        },
                    ]
                }
            ]
        }
    }
}

