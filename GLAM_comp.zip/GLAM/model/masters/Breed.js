import mongoose from 'mongoose'
import { Config } from '../../config/Init.js'

export default class Breed {
  constructor() {
    this._id
    this.breed = { type: String, required: true, trim: true, index: { unique: true, collation: { locale: 'en', strength: 1 } } }
    this.pettypeid = { type: mongoose.Schema.Types.ObjectId, ref: 'tblpettypemaster' }
    this.pettype = { type: String, required: true }
    this.isactive = { type: Number, required: true, default: 1 } // 1 - active, 0 - deactive
    this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: 'recordinfo' }
  }

  getDataName() {
    return "Breed";
  }

  getFieldOrder() {
    return {
      fields: [
        {
          'field': 'action_button',
          'text': '',
          'type': Config.getHtmlcontorls()['action_button'],
          'freeze': 1,
          'active': 1,
          'sorttable': 0,
          'filter': 0,
          'disableflex': 1,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': 8
        },
        {
          'field': 'isactive',
          'text': 'Status',
          'type': Config.getHtmlcontorls()['isactive'],
          'freeze': 0,
          'active': 1,
          'sorttable': 0,
          'filter': 0,
          'disableflex': 1,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': 15
        },
        {
          'field': 'breed',
          'text': 'Breed Name',
          'type': Config.getHtmlcontorls()['text'],
          'freeze': 0,
          'active': 1,
          'sorttable': 1,
          'sortby': 'breed',
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': 65
        },
        {
          'field': 'pettype',
          'text': 'Pet Type',
          'type': Config.getHtmlcontorls()['text'],
          'freeze': 0,
          'active': 1,
          'sorttable': 1,
          'sortby': 'pettype',
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': 100
        }
      ]
    }
  }

  getFormFieldOrder() {
    return {
      "rightsidebarsize": Config.getModalsizeclasses()['xs'],
      "pagename": 'breed',
      "formname": 'Breed',
      "alias": 'breed',
      "dataview": "tab",
      'formfields': [
        {
          "tab": "Areatype",
          "formFields": [
            {
              'field': 'breed',
              'text': 'Breed',
              'type': Config.getHtmlcontorls()['kInputText'],
              'disabled': false,
              'defaultvisibility': true,
              'required': true,
              'gridsize': Config.getFieldSize()['k375'],
            },
            {
              "field": "pettypeid",
              "text": "Pet Type",
              "type": "dropdown",
              "disabled": false,
              "defaultvisibility": true,
              "required": true,
              "gridsize": 375,
              "masterdata": "pettype",
              "masterdatafield": "pettype",
              "formdatafield": "pettype",
              "cleanable": true,
              "searchable": true,
              "masterdatadependancy": false,
              "staticfilter": { "isactive": 1 }
            },
            {
              'field': 'isactive',
              'text': 'Status',
              'type': Config.getHtmlcontorls()['kDropDown'],
              'disabled': false,
              'defaultvisibility': true,
              'required': true,
              'gridsize': Config.getFieldSize()['k375'],
              'masterdata': 'isactive',
              'masterdataarray': Config.getStatustype(),
              'defaultvalue': 1,
              'formdatafield': 'isactive',
              'cleanable': true,
              'searchable': true,
              'masterdatadependancy': false,
            },
          ]
        }
      ],
    }
  }
}

