import mongoose from "mongoose";

export default class Device {
    constructor () {
        this._id;
        this.uid = { type: mongoose.Schema.Types.ObjectId, required: false, trim: true, ref: "tblusermaster" };
        this.useragent = { type: String, required: false, trim: true };
        this.os = { type: String, required: false, trim: true };
        this.osversion = { type: String, required: false, trim: true };
        this.ipaddress = { type: String, required: false, trim: true };
        this.macaddress = { type: String, required: false, trim: true };
        this.deviceid = { type: String, required: false, trim: true };
        this.devicemodelname = { type: String, required: false, trim: true };
        this.browsername = { type: String, required: false, trim: true };
        this.entrydate = { type: Date, required: false };
        this.appversion = { type: String, required: false, trim: true };
        this.appupdate = { type: Date, required: false };
        this.timestamp = { type: Date, required: false };
        this.devicename = { type: String, required: false };
    }
}