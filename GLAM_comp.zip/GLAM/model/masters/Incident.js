import mongoose from "mongoose"
import _Config from "../../config/Config.js"
const Config = new _Config()

export default class Incident {
  constructor() {
    this._id
    this.title = { type: String, required: true, trim: true }
    this.propertyid = { type: mongoose.Schema.Types.ObjectId, ref: "tblpropertymaster" }
    this.property = { type: String }
    this.senderid = { type: mongoose.Schema.Types.ObjectId, ref: "tblcustomer" }
    this.sender = { type: String, required: true }
    this.location = { type: String, required: true }
    this.description = { type: String, required: false }
    this.images = [Config.getImageModel()]
    this.date = { type: Date, default: Date.now }
    this.isactive = { type: Number, required: true, default: 1 } // 1 - active, 0 - deactive
    this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: "recordinfo" }
  }

  getDataName() {
    return "Incident"
  }

  getFieldOrder() {
    return {
      fields: [
        {
          'field': 'action_button',
          'text': '',
          'type': Config.getHtmlcontorls()['action_button'],
          'freeze': 1,
          'active': 1,
          'sorttable': 0,
          'filter': 0,
          'disableflex': 1,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': Config.getTblgridsizeclasses()[8]
        },
        {
          'field': 'isactive',
          'text': 'Status',
          'type': Config.getHtmlcontorls()['isactive'],
          'freeze': 1,
          'active': 1,
          'sorttable': 0,
          'filter': 0,
          'disableflex': 1,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': 15
        },
        {
          'field': 'title',
          'text': 'title',
          'type': Config.getHtmlcontorls()['text'],
          'freeze': 0,
          'active': 1,
          'sorttable': 1,
          'sortby': 'title',
          'filter': 0,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': Config.getTblgridsizeclasses()[20]
        },
        {
          'field': 'location',
          'text': 'Location',
          'type': Config.getHtmlcontorls()['text'],
          'freeze': 0,
          'active': 1,
          'sorttable': 1,
          'sortby': 'descriprtion',
          'filter': 1,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': Config.getTblgridsizeclasses()[15]
        },
        {
          'field': 'date',
          'text': 'Incident Date',
          'type': Config.getHtmlcontorls()['text'],
          'freeze': 0,
          'active': 1,
          'sorttable': 1,
          'sortby': 'formatedate',
          'filter': 0,
          'defaultvalue': '',
          'tblsize': Config.getTblgridsizeclasses()[20]
        },
        {
          "field": "fromdate",
          "text": "From Date",
          "type": "datepicker",
          "freeze": 0,
          "active": 0,
          "sorttable": 1,
          "sortby": "fromdate",
          "filter": 1,
          "filterfield": "fromdate",
          "filterfieldtype": "datepicker",
          "isonlyfilter": 1,
          "defaultvalue": "",
          "tblsize": 28
        },
        {
          "field": "todate",
          "text": "To Date",
          "type": "datepicker",
          "freeze": 0,
          "active": 0,
          "sorttable": 1,
          "sortby": "todate",
          "filter": 1,
          "filterfield": "todate",
          "filterfieldtype": "datepicker",
          "isonlyfilter": 1,
          "defaultvalue": "",
          "tblsize": 28
        },

        {
          'field': 'description',
          'text': 'Description',
          'type': Config.getHtmlcontorls()['text'],
          'freeze': 0,
          'active': 1,
          'sorttable': 1,
          'sortby': 'description',
          'filter': 1,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': Config.getTblgridsizeclasses()[110]
        },

      ]
    }
  }

  getFormFieldOrder() {
    return {
      "rightsidebarsize": Config.getModalsizeclasses()['xs'],
      "pagename": 'incident',
      "formname": 'Incident',
      "alias": 'incident',
      "dataview": "tab",
      'formfields': [
        {
          "tab": "incident",
          "formFields": [
            {
              'field': 'title',
              'text': 'Incident Title',
              'type': Config.getHtmlcontorls()['kInputText'],
              'disabled': false,
              'defaultvisibility': true,
              'required': true,
              'gridsize': Config.getFieldSize()['k375'],
            },
            {
              'field': 'location',
              'text': 'Incident Location',
              'type': Config.getHtmlcontorls()['kInputText'],
              'disabled': false,
              'defaultvisibility': true,
              'required': true,
              'gridsize': Config.getFieldSize()['k375'],
            },
            {
              'field': 'images',
              'text': 'Photo',
              'type': "multipleimagepicker",
              'disabled': false,
              'defaultvisibility': true,
              'required': false,
              'filetypes': Config.images,
              'gridsize': 375,
              "freeze": 0,
              "active": 1,
              "sorttable": 0,
              "filter": 0,
              "defaultvalue": ""
            },
            {
              'field': 'description',
              'text': 'Description',
              'type': Config.getHtmlcontorls()['kInputTextArea'],
              'disabled': false,
              'maxcharacters': 50,
              'defaultvisibility': true,
              'required': false,
              'gridsize': Config.getFieldSize()['k375'],
            },
          ]
        }
      ],
    }
  }

}
