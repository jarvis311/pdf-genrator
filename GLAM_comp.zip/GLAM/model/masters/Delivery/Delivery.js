import mongoose from 'mongoose'
import { Config } from '../../../config/Init.js'

export default class Cab {
  constructor() {
    this._id
    this.customerid = { type: mongoose.Schema.Types.ObjectId, ref: "tblcustomer" }
    this.customer = { type: String, required: true }
    this.propertyid = { type: mongoose.Schema.Types.ObjectId, ref: "tblpropertymaster" }
    this.property = { type: String, trim: true, required: true }
    this.cabdate = { type: Date, required: true }
    this.deliverycompanyid = {type: mongoose.Schema.Types.ObjectId, ref: "tblcabcategory" }
    this.deliverycompany = {type:String,required:true}
    this.deliveryperson = { type:String,required:false,trim:true}
    this.notes = { type:String,trim: true ,required:false}
    this.contact = { type: String, trim: true }
    this.contact_countrycode = { type: String, trim: true }
    this.alternatecontact = { type: String, trim: true }
    this.alternatecontact_countrycode = { type: String, trim: true }
    this.ownedproperties = [{
      propertyid: { type: mongoose.Schema.Types.ObjectId, ref: "tblpropertymaster" },
      property: { type: String },
      unitid: { type: mongoose.Schema.Types.ObjectId, ref: "tblpropertyunit" },
      unit: { type: String },
      wingid: { type: mongoose.Schema.Types.ObjectId, ref: "tblpropertywing" },
      wing: { type: String },
      floorid: { type: mongoose.Schema.Types.ObjectId, ref: "tblpropertyfloor" },
      floor: { type: String },
      customerid: { type: mongoose.Schema.Types.ObjectId, ref: "tblcustomer" },
      customer: { type: String }
    }]
    this.startdate = {type:Date}
    this.enddate = { type:Date}
    this.status = { type: Number, default: 0 } // 0-pending ,1-verify gatekeeper, 2-out gatekeeper
    this.deliverypersonindate = { type: Date }
    this.deliverypersonoutdate = { type: Date }
    this.isentry = {type:Number,required:true} //1-customer 2-gatekeeper
    this.isactive = { type: Number, required: true, default: 1 } // 1 - active, 0 - deactive
    this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: "recordinfo" }
    this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: 'recordinfo' }
  }

  getDataName() {
    return "Cab"
  }

  getFieldOrder() {
    return {
      fields: [
        {
          'field': 'action_button',
          'text': '',
          'type': Config.getHtmlcontorls()['action_button'],
          'freeze': 1,
          'active': 1,
          'sorttable': 0,
          'filter': 0,
          'disableflex': 1,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': 10
        },
        {
          'field': 'isactive',
          'text': 'Status',
          'type': Config.getHtmlcontorls()['isactive'],
          'freeze': 1,
          'active': 1,
          'sorttable': 0,
          'filter': 0,
          'disableflex': 1,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': 15
        },
        {
          'field': 'cab',
          'text': 'Cab',
          'type': Config.getHtmlcontorls()['text'],
          'freeze': 1,
          'active': 1,
          'sorttable': 1,
          'sortby': 'cabcategory',
          'filter': 0,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': 10
        }
      ]
    }
  }

  getFormFieldOrder() {
    return {
      "rightsidebarsize": Config.getModalsizeclasses()['xs'],
      "pagename": 'cabcategory',
      "formname": 'cabcategory',
      "alias": 'cabcategory',
      "dataview": "tab",
      'formfields': [
        {
          "tab": "cabcategory",
          "formFields": [
            {
              'field': 'cabcategory',
              'text': 'Cab Category Name',
              'type': Config.getHtmlcontorls()['kInputText'],
              'disabled': false,
              'defaultvisibility': true,
              'required': true,
              'gridsize': Config.getFieldSize()['k375'],
            },
            {
              'field': 'isactive',
              'text': 'Status',
              'type': Config.getHtmlcontorls()['kDropDown'],
              'disabled': false,
              'defaultvisibility': true,
              'required': true,
              'gridsize': Config.getFieldSize()['k375'],
              'masterdata': 'status',
              'masterdataarray': Config.getStatustype(),
              'defaultvalue': 1,
              'formdatafield': 'status',
              'cleanable': true,
              'searchable': true,
              'onchangedata': ['statusid'],
              'masterdatadependancy': false,
            },
          ]
        }
      ],
    }
  }
}

