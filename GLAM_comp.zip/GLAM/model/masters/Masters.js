import mongoose from "mongoose"
import _Config from "../../config/Config.js"
import { Config } from "../../config/Init.js"

export class TaskCategory {
    constructor() {
        this._id
        this.name = { type: String, required: true, trim: true }
        this.showbuffertime = { type: Number, default: 0 }
        this.showinguestbuddy = { type : Number, default : 0}
        this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: "recordinfo" }
    }

    getFieldOrder() {
        const Config = new _Config()

        return {
            fields: [
                {
                    field: "name",
                    text: "Task Category",
                    type: Config.getHtmlcontorls()["text"],
                    freeze: 0,
                    active: 1,
                    sorttable: 1,
                    filter: 1,
                    filterfieldtype: Config.getHtmlcontorls()["lookup"],
                    defaultvalue: "",
                    tblsize: Config.getTblgridsizeclasses()["tbl-min-w150"]
                }
            ]
        }
    }
}

export class TaskType {
    constructor() {
        this._id
        this.name = { type: String, required: true }
        this.isdayshow = { type: Number }
        this.isexpiry = { type: Number }
        this.iseventbase = { type: Number }
        this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: "recordinfo" }
    }

    getFieldOrder() {
        const Config = new _Config()

        return {
            fields: [
                {
                    field: "name",
                    text: "Task Type",
                    type: Config.getHtmlcontorls()["text"],
                    freeze: 0,
                    active: 1,
                    sorttable: 1,
                    filter: 1,
                    filterfieldtype: Config.getHtmlcontorls()["lookup"],
                    defaultvalue: "",
                    tblsize: Config.getTblgridsizeclasses()["tbl-min-w150"]
                }
            ]
        }
    }
}

export class EventBased {
    constructor() {
        this._id
        this.name = { type: String, required: true }
        this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: "recordinfo" }
    }

    getFieldOrder() {
        const Config = new _Config()

        return {
            fields: [
                {
                    field: "name",
                    text: "Event Based",
                    type: Config.getHtmlcontorls()["text"],
                    freeze: 0,
                    active: 1,
                    sorttable: 1,
                    filter: 1,
                    filterfieldtype: Config.getHtmlcontorls()["lookup"],
                    defaultvalue: "",
                    tblsize: Config.getTblgridsizeclasses()["tbl-min-w150"]
                }
            ]
        }
    }
}

export class Day {
    constructor() {
        this._id
        this.name = { type: String, required: true }
        this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: "recordinfo" }
    }

    getFieldOrder() {
        const Config = new _Config()

        return {
            fields: [
                {
                    field: "name",
                    text: "Day",
                    type: Config.getHtmlcontorls()["text"],
                    freeze: 0,
                    active: 1,
                    sorttable: 1,
                    filter: 1,
                    filterfieldtype: Config.getHtmlcontorls()["lookup"],
                    defaultvalue: "",
                    tblsize: Config.getTblgridsizeclasses()["tbl-min-w150"]
                }
            ]
        }
    }
}

export class Priority {
    constructor() {
        this._id
        this.name = { type: String, required: true }
        this.color = { r: { type: Number, required: true }, g: { type: Number, required: true }, b: { type: Number, required: true }, a: { type: Number, required: true } }
        this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: "recordinfo" }
    }

    getFieldOrder() {
        const Config = new _Config()

        return {
            fields: [
                {
                    field: "name",
                    text: "Priority",
                    type: Config.getHtmlcontorls()["text"],
                    freeze: 0,
                    active: 1,
                    sorttable: 1,
                    filter: 1,
                    filterfieldtype: Config.getHtmlcontorls()["text"],
                    defaultvalue: "",
                    tblsize: Config.getTblgridsizeclasses()["tbl-min-w150"]
                }
            ]
        }
    }
}

export class BreakType {
    constructor() {
        this._id
        this.name = { type: String, required: true }
        this.alias = { type: String, required: true }
        this.svg = { type: String, required: true }
        this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: "recordinfo" }
    }

    getFieldOrder() {
        const Config = new _Config()

        return {
            fields: [
                {
                    field: "name",
                    text: "Break Type",
                    type: Config.getHtmlcontorls()["text"],
                    freeze: 0,
                    active: 1,
                    sorttable: 1,
                    filter: 1,
                    filterfieldtype: Config.getHtmlcontorls()["lookup"],
                    defaultvalue: "",
                    tblsize: Config.getTblgridsizeclasses()["tbl-min-w150"]
                },
                {
                    field: "svg",
                    text: "Icon",
                    type: Config.getHtmlcontorls()["text"],
                    freeze: 0,
                    active: 1,
                    sorttable: 0,
                    filter: 0,
                    filterfieldtype: Config.getHtmlcontorls()["lookup"],
                    defaultvalue: "",
                    tblsize: Config.getTblgridsizeclasses()["tbl-min-w150"]
                }
            ]
        }
    }
}

export class TimeZone {
    constructor() {
        this._id
        this.timezonedisplayname = { type: String, required: true }
        this.country = { type: String, required: true }
        this.countrycode = { type: String, required: true }
        this.timezone = { type: String, required: true }
        this.offsettype = { type: String, required: true }
        this.offset = { type: String, required: true }
        this.offsetdata = { type: Array, default: [] }
        this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: "recordinfo" }
    }

    getFieldOrder() {
        const Config = new _Config()

        return {
            fields: [
                {
                    field: "country",
                    text: "Country",
                    type: Config.getHtmlcontorls()["text"],
                    freeze: 1,
                    active: 1,
                    sorttable: 1,
                    filter: 1,
                    filterfieldtype: Config.getHtmlcontorls()["lookup"],
                    defaultvalue: "",
                    tblsize: Config.getTblgridsizeclasses()["tbl-min-w150"]
                },
                {
                    field: "countrycode",
                    text: "Country Code",
                    type: Config.getHtmlcontorls()["text"],
                    freeze: 0,
                    active: 1,
                    sorttable: 1,
                    filter: 1,
                    filterfieldtype: Config.getHtmlcontorls()["lookup"],
                    defaultvalue: "",
                    tblsize: Config.getTblgridsizeclasses()["tbl-min-w150"]
                },
                {
                    field: "timezone",
                    text: "Timezone",
                    type: Config.getHtmlcontorls()["text"],
                    freeze: 0,
                    active: 1,
                    sorttable: 1,
                    filter: 1,
                    filterfieldtype: Config.getHtmlcontorls()["lookup"],
                    defaultvalue: "",
                    tblsize: Config.getTblgridsizeclasses()["tbl-min-w150"]
                }
            ]
        }
    }
}

export class TimeZoneData {
    constructor() {
        this._id
        this.timezonename = { type: String, required: true }
        this.timezone = { type: String, required: true }
        this.code = { type: String, required: true }
        this.offset = { type: String, required: true }
        this.text = { type: String, required: true }
        this.gmt = { type: String, required: true }
    }

    // getFieldOrder() {
    //     const Config = new _Config()

    //     return {
    //         fields: [
    //             {
    //                 field: "country",
    //                 text: "Country",
    //                 type: Config.getHtmlcontorls()["text"],
    //                 freeze: 1,
    //                 active: 1,
    //                 sorttable: 1,
    //                 filter: 1,
    //                 filterfieldtype: Config.getHtmlcontorls()["lookup"],
    //                 defaultvalue: "",
    //                 tblsize: Config.getTblgridsizeclasses()["tbl-min-w150"]
    //             },
    //             {
    //                 field: "countrycode",
    //                 text: "Country Code",
    //                 type: Config.getHtmlcontorls()["text"],
    //                 freeze: 0,
    //                 active: 1,
    //                 sorttable: 1,
    //                 filter: 1,
    //                 filterfieldtype: Config.getHtmlcontorls()["lookup"],
    //                 defaultvalue: "",
    //                 tblsize: Config.getTblgridsizeclasses()["tbl-min-w150"]
    //             },
    //             {
    //                 field: "timezone",
    //                 text: "Timezone",
    //                 type: Config.getHtmlcontorls()["text"],
    //                 freeze: 0,
    //                 active: 1,
    //                 sorttable: 1,
    //                 filter: 1,
    //                 filterfieldtype: Config.getHtmlcontorls()["lookup"],
    //                 defaultvalue: "",
    //                 tblsize: Config.getTblgridsizeclasses()["tbl-min-w150"]
    //             }
    //         ]
    //     }
    // }
}

export class RoomAction {
    constructor() {
        this._id
        this.name = { type: String, required: true }
        this.svg = { type: String, required: true }
        this.categoryid = { type : mongoose.Schema.Types.ObjectId, default : Config.dummyObjid }
        this.showinmodel = { type: Number }
        this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: "recordinfo" }
    }

    getFieldOrder() {
        const Config = new _Config()

        return {
            fields: [
                {
                    field: "name",
                    text: "Room Action",
                    type: Config.getHtmlcontorls()["text"],
                    freeze: 0,
                    active: 1,
                    sorttable: 1,
                    filter: 1,
                    filterfieldtype: Config.getHtmlcontorls()["lookup"],
                    defaultvalue: "",
                    tblsize: Config.getTblgridsizeclasses()["tbl-min-w150"]
                },
                {
                    field: "svg",
                    text: "Icon",
                    type: Config.getHtmlcontorls()["text"],
                    freeze: 0,
                    active: 1,
                    sorttable: 0,
                    filter: 0,
                    filterfieldtype: Config.getHtmlcontorls()["lookup"],
                    defaultvalue: "",
                    tblsize: Config.getTblgridsizeclasses()["tbl-min-w150"]
                }
            ]
        }
    }
}

export class Damages {
    constructor() {
        this._id
        this.name = { type: String, required: true }
    }

    getFieldOrder() {
        const Config = new _Config()

        return {
            fields: [
                {
                    field: "name",
                    text: "Damages",
                    type: Config.getHtmlcontorls()["text"],
                    freeze: 0,
                    active: 1,
                    sorttable: 1,
                    filter: 1,
                    filterfieldtype: Config.getHtmlcontorls()["lookup"],
                    defaultvalue: "",
                    tblsize: Config.getTblgridsizeclasses()["tbl-min-w150"]
                }
            ]
        }
    }
}

export class TaskEvent {
    constructor() {
        this._id
        this.taskevent = { type: String, trim: true }
        this.showtasktype = { type: Number, default: 0 }
        this.showserviceprofile = { type: Number, default: 0 }
        this.showbeforeaftertype = { type: Number, default: 0 }
        this.showprofiletype = { type: Number, default: 0 }
        this.showmindays = { type: Number, default: 0 }
    }

    getFieldOrder() {
        const Config = new _Config()
        return {
            fields: [

            ]
        }
    }
}

export class OffsetType {
    constructor() {
        this._id
        this.offsettype = { type: String, required: true, unique: true, trim: true }
    }
}

export class LostAndFoundCategory {
    constructor() {
        this._id
        this.name = { type: String, required: true }
        this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: "recordinfo" }
    }

    getFieldOrder() {
        const Config = new _Config()

        return {
            fields: [
                {
                    field: "name",
                    text: "Lost And Found Category",
                    type: Config.getHtmlcontorls()["text"],
                    freeze: 0,
                    active: 1,
                    sorttable: 1,
                    filter: 1,
                    filterfieldtype: Config.getHtmlcontorls()["lookup"],
                    defaultvalue: "",
                    tblsize: Config.getTblgridsizeclasses()["tbl-min-w150"]
                }
            ]
        }
    }
}

export class LostAndFoundStatus {
    constructor() {
        this._id
        this.name = { type: String, required: true }
        this.alias = { type: String, required: true }
        this.type = { type: Number, default:0 } // Lost and Found : 0=>Both, 1=>Lost, 2=>Found
        this.svg = { type : String, required : true}
        this.backgroundcolor = {
            r: { type: Number },
            g: { type: Number },
            b: { type: Number },
            a: { type: Number }
        }
        this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: "recordinfo" }
    }

    getFieldOrder() {
        const Config = new _Config()

        return {
            fields: [
                {
                    field: "name",
                    text: "Lost And Found Status",
                    type: Config.getHtmlcontorls()["text"],
                    freeze: 0,
                    active: 1,
                    sorttable: 1,
                    filter: 1,
                    filterfieldtype: Config.getHtmlcontorls()["lookup"],
                    defaultvalue: "",
                    tblsize: Config.getTblgridsizeclasses()["tbl-min-w150"]
                }
            ]
        }
    }
}
