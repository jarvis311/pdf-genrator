import mongoose from "mongoose"
export default class Tokenexpiry {
    constructor() {
        this._id
        this.flieldname = { type: String, required: true, trim: true }
        this.filepath = { type: String, required: true, trim: true }
        this.fileurl = { type: String, required: true, trim: true }
        this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: "recordinfo" }
    }
}
