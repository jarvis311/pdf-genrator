import mongoose from "mongoose"

export default class MongoDBCloudWatchLogs {
	constructor() {
		this._id
		this.date = { type: Date, default: Date.now }
		this.logcount = { type: Number, default: 0 }
	}
}
