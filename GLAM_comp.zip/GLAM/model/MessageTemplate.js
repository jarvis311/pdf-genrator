import { Config } from "../config/Init.js"
import mongoose from "mongoose"

export default class MessageTemplate {
    constructor() {
        this._id
        this.platformid = { type: mongoose.Schema.Types.ObjectId, ref: "tblmessageplatform" }
        this.platform = { type: String, trim: true }

        this.templatename = { type: String, trim: true, required: true }
        this.message = { type: String, trim: true, required: true }
        this.files = [
            {
                name: { type: String, trim: true },
                url: { type: String, trim: true },
                size: { type: Number },
                thumbnail: { type: String, trim: true },
                filetype: { type: String, trim: true },
                type: { type: String, trim: true }
            }
        ]

        this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: "recordinfo" }
    }

    getFieldOrder() {
        return {
            fields: [
                {
                    field: "platform",
                    text: "Platform",
                    type: Config.getHtmlcontorls()["text"],
                    freeze: 1,
                    active: 1,
                    sorttable: 1,
                    filter: 1,
                    filterfieldtype: Config.getHtmlcontorls()["lookup"],
                    defaultvalue: "",
                    tblsize: Config.getTblgridsizeclasses()["tbl-min-w120"]
                },
                {
                    field: "templatename",
                    text: "Template Name",
                    type: Config.getHtmlcontorls()["text"],
                    freeze: 0,
                    active: 1,
                    sorttable: 1,
                    filter: 1,
                    filterfieldtype: Config.getHtmlcontorls()["lookup"],
                    defaultvalue: "",
                    tblsize: Config.getTblgridsizeclasses()["tbl-min-w120"]
                },
                {
                    field: "files",
                    text: "Media",
                    type: Config.getHtmlcontorls()["modal-file"],
                    modalsize: Config.getModalsizeclasses()["sm"],
                    freeze: 0,
                    active: 1,
                    sorttable: 0,
                    filter: 0,
                    tblsize: Config.getTblgridsizeclasses()["tbl-min-w100"]
                },
                {
                    field: "message",
                    text: "Message",
                    type: Config.getHtmlcontorls()["text"],
                    freeze: 0,
                    active: 1,
                    sorttable: 0,
                    filter: 1,
                    filterfieldtype: Config.getHtmlcontorls()["lookup"],
                    defaultvalue: "",
                    tblsize: Config.getTblgridsizeclasses()["tbl-min-w100"]
                }
            ]
        }
    }
}
