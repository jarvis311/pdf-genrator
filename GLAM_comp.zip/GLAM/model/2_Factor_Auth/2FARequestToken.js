import mongoose from "mongoose"

export default class TwoFARequestToken {
    constructor() {
        this._id
        this.personid = { type: mongoose.Schema.Types.ObjectId, ref: "tblpersonmaster" }
        this.requestid = { type: String, trim: true, required: true }
        this.twoFAmode = { type: String, trim: true, required: true }
        this.time = { type: Date, default: Date.now }
        this.isexpired = { type: Number, default: 0 }
    }
}
