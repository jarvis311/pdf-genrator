import mongoose from "mongoose"
import _Config from "../config/Config.js"

export default class maxIdIncreament {
    constructor() {
        this._id
        this.maxid = { type: Number , default:0}
        this.tablename = {type: String, unique: true, required: true}
        this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: "recordinfo" }                
    }
}
