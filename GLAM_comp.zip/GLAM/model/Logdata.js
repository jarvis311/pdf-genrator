export default class Logdata {
    constructor() {
        this._id
        this.tblname = { type: String, required: true, trim: true }
        this.dataary = { type: String, required: true, trim: true }
        this.operation = { type: String, required: true, trim: true }
        this.errorcode = { type: String, required: true, trim: true }
        this.errormsg = { type: String, required: true, trim: true }
        this.pagename = { type: String, required: true, trim: true }
        this.platform = { type: String, required: true, trim: true }
        this.ipaddress = { type: String, required: true, trim: true }
        this.logdatetime = { type: String, required: true, trim: true }
    }

}
