import mongoose from "mongoose"
import _Config from "../config/Config.js"

export default class ErrorLog {
	constructor() {
		this._id
		this.url = { type: String, default: "", trim: true }
		this.filename = { type: String, default: "", trim: true }
		this.linenumber = { type: Number, default: 0 }
		this.error = { type: String, default: "", trim: true }
		this.errorstack = { type: mongoose.Schema.Types.Mixed }
		this.headers = { type: mongoose.Schema.Types.Mixed }
		this.body = { type: mongoose.Schema.Types.Mixed }
		this.time = { type: Date, default: Date.now }
	}

	getFieldOrder() {
		const Config = new _Config()
		return {
			fields: [
				{
					field: "time",
					text: "Date/Time",
					type: Config.getHtmlcontorls()["datetimepicker"],
					freeze: 1,
					active: 1,
					sorttable: 1,
					filter: 0,
					filterfieldtype: Config.getHtmlcontorls()["lookup"],
					defaultvalue: "",
					tblsize: Config.getTblgridsizeclasses()["tbl-w150"]
				},
				{
					field: "url",
					text: "URL",
					type: Config.getHtmlcontorls()["text"],
					freeze: 0,
					active: 1,
					sorttable: 0,
					filter: 0,
					filterfieldtype: Config.getHtmlcontorls()["lookup"],
					defaultvalue: "",
					tblsize: Config.getTblgridsizeclasses()["tbl-w150"]
				},
				{
					field: "filename",
					text: "File Name",
					type: Config.getHtmlcontorls()["text"],
					freeze: 0,
					active: 1,
					sorttable: 1,
					filter: 0,
					filterfieldtype: Config.getHtmlcontorls()["lookup"],
					defaultvalue: "",
					tblsize: Config.getTblgridsizeclasses()["tbl-w150"]
				},
				{
					field: "linenumber",
					text: "Line Number",
					type: Config.getHtmlcontorls()["text"],
					freeze: 0,
					active: 1,
					sorttable: 1,
					filter: 0,
					filterfieldtype: Config.getHtmlcontorls()["lookup"],
					defaultvalue: "",
					tblsize: Config.getTblgridsizeclasses()["tbl-w150"]
				},
				{
					field: "error",
					text: "Error Name",
					type: Config.getHtmlcontorls()["text"],
					freeze: 0,
					active: 1,
					sorttable: 0,
					filter: 0,
					filterfieldtype: Config.getHtmlcontorls()["lookup"],
					defaultvalue: "",
					tblsize: Config.getTblgridsizeclasses()["tbl-w150"]
				},
				{
					field: "errorstack",
					text: "Error Stack",
					type: Config.getHtmlcontorls()["modal-eye"],
					freeze: 0,
					active: 1,
					sorttable: 0,
					filter: 0,
					filterfieldtype: Config.getHtmlcontorls()["lookup"],
					defaultvalue: "",
					tblsize: Config.getTblgridsizeclasses()["tbl-w150"]
				}
			]
		}
	}
}
