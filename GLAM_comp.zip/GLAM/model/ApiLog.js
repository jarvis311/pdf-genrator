import mongoose from "mongoose"

export default class ApiLog {
    constructor() {
        this._id
        this.url = { type: String }
        this.headers = { type: mongoose.Schema.Types.Mixed }
        this.payload = { type: mongoose.Schema.Types.Mixed }
        this.date = { type: Date, default: Date.now }
        this.datestr = { type: String }
    }

}
