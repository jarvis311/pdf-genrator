import mongoose from "mongoose"

export default class ComplaintChatHistory {
    constructor() {
        this._id
        this.complaintid = { type: mongoose.Schema.Types.ObjectId }
        this.personid = { type: mongoose.Schema.Types.ObjectId, ref: "tblpersonmaster" }
        this.propertyid = { type: mongoose.Schema.Types.ObjectId, ref: "tblproperty" }
        this.time = { type: Date, trim: true }
    }

}
