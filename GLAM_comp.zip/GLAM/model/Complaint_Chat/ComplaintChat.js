import mongoose from "mongoose"

export default class ComplaintChat {
    constructor() {
        this._id
            this.complaintid = { type: mongoose.Schema.Types.ObjectId, required: true }
            this.categoryid = { type: mongoose.Schema.Types.ObjectId }
            this.personid = { type: mongoose.Schema.Types.ObjectId, required: true }
            this.person = { type: String, required: true, trim: true }
            this.profilepic = { type: String }
            this.message = { type: String }
            this.files = [
                {
                    name: { type: String, trim: true },
                    url: { type: String, trim: true },
                    size: { type: Number },
                    thumbnail: { type: String, trim: true }
                }
            ]
            this.type = { type: Number, required: true } // 1->Text, 2->Images, 3->Videos, 4->Document
            this.time = { type: Date, required: true, default: Date.now }
            this.reactions = [
                {
                    reaction: { type: String, trim: true },
                    reactionid: { type: String, trim: true },
                    reactorid: { type: mongoose.Schema.Types.ObjectId, ref: "tblpersonmaster" }
                }
            ]
            this.seenpersons = [
                {
                    person: { type: String, trim: true },
                    personid: { type: String, trim: true },
                }
            ]
            // this.mentions = [
            //     {
            //         personid: { type: mongoose.Schema.Types.ObjectId, ref: "tblpersonmaster" },
            //         personname: {type: String, trim: true },
            //         profilepic : { type: String, trim: true}
            //     }
            // ]
            this.reminders = [
                {
                    notes: { type: String, trim: true },
                    datetime: { type: String, trim: true },
                    reminderbyuid : {type: mongoose.Schema.Types.ObjectId, ref: "tblpersonmaster"},
                    remindertype: {type: Number}
                }
            ]
            this.isreminder = {type: Number, default: 0 }
            this.isimportant = { type: Number, default: 0 }
            this.isurgent = { type: Number, default: 0 }

            this.repliedtoid = { type: String, trim: true }
            this.replytomessage = { type: String, trim: true }
            this.replytotype = { type: String, trim: true }
            this.replyisimportant = { type: Number, default: 0 }
            this.replyisurgent = { type: Number, default: 0 }
            this.replytorecordinfo = { type: mongoose.Schema.Types.Mixed, ref: "recordinfo" }

            this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: "recordinfo" }
        }
}
