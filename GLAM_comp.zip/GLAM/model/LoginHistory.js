export default class LoginHistory {
    constructor() {
        this._id
        this.username = { type: String, required: true, trim: true }
        this.email = { type: String, required: true, trim: true }
        this.browsername = { type: String, required: true, trim: true }
        this.browserversion = { type: String, required: true, trim: true }
        this.browserplatform = { type: String, required: true, trim: true }
        this.browsericon = { type: String, required: true, trim: true }
        this.domainname = { type: String, required: true, trim: true }
        this.ipaddress = { type: String, required: true, trim: true }
        this.platform = { type: String, required: true, trim: true }
        this.datetime = { type: String, required: true, trim: true }
        this.status = { type: String, required: true, trim: true }
        this.message = { type: String, required: true, trim: true }
        this.entry_date = { type: String, required: true, trim: true }
        this.isoentry_date = { type: Date, required: true }
    }

}
