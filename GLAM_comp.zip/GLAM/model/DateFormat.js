import mongoose from "mongoose"

export default class DateFromat {

    constructor() {
        this._id
        this.format = { type: String, default: "YYYY-MM-DD" },
        this.datewiseformat = { type: Number, default: 1 }
    }
}
