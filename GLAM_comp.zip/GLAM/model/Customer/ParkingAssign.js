import mongoose from 'mongoose'
import { Config } from '../../config/Init.js'

export default class ParkingAssign {
  constructor() {
    this._id
    this.customerid = { type: mongoose.Schema.Types.ObjectId, ref: "tblcustomer" },
      this.customer = { type: String, required: true }
    this.parkingzoneid = { type: mongoose.Schema.Types.ObjectId, ref: "tblparkingzonemaster" }
    this.parkingzone = { type: String, required: true }
    this.parkingslotid = { type: mongoose.Schema.Types.ObjectId, ref: "tblparking" },
      this.parkingslot = { type: String, required: true },
      this.propertyid = { type: mongoose.Schema.Types.ObjectId, ref: "tblproperty" },
      this.property = { type: String, required: true },
      this.wingid = { type: mongoose.Schema.Types.ObjectId, ref: "tblpropertybuilding" },
      this.wing = { type: String, required: true },
      this.floorid = { type: mongoose.Schema.Types.ObjectId, ref: "tblpropertyfloor" },
      this.floor = { type: String, required: true },
      this.unitid = { type: mongoose.Schema.Types.ObjectId, ref: "tblpropertyunit" },
      this.unit = { type: String, required: true },
      this.profilepic = Config.getImageModel()
    this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: 'recordinfo' }
  }

  getDataName() {
    return "parking"
  }

  getFieldOrder() {
    return {
      fields: [
        {
          'field': 'action_button',
          'text': '',
          'type': Config.getHtmlcontorls()['action_button'],
          'freeze': 1,
          'active': 1,
          'sorttable': 0,
          'filter': 0,
          'disableflex': 1,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': 10
        },
        {
          'field': 'isactive',
          'text': 'Status',
          'type': Config.getHtmlcontorls()['isactive'],
          'freeze': 1,
          'active': 1,
          'sorttable': 0,
          'filter': 0,
          'disableflex': 1,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': 15
        },
        {
          'field': 'name',
          'text': 'Name',
          'type': Config.getHtmlcontorls()['text'],
          'freeze': 0,
          'active': 1,
          'sorttable': 1,
          'sortby': 'name',
          'filter': 0,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': 10
        },
        {
          'field': 'type',
          'text': 'Type',
          'type': Config.getHtmlcontorls()['text'],
          'freeze': 0,
          'active': 1,
          'sorttable': 1,
          'sortby': 'type',
          'filter': 0,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': 10
        },
        {
          'field': 'breed',
          'text': 'Breed',
          'type': Config.getHtmlcontorls()['text'],
          'freeze': 0,
          'active': 1,
          'sorttable': 1,
          'sortby': 'breed',
          'filter': 0,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': 10
        }
      ]
    }
  }

  getFormFieldOrder() {
    return {
      "rightsidebarsize": Config.getModalsizeclasses()['xs'],
      "pagename": 'areatype',
      "formname": 'Area Type',
      "alias": 'areatype',
      "dataview": "tab",
      'formfields': [
        {
          "tab": "Areatype",
          "formFields": [
            {
              'field': 'areatype',
              'text': 'Area Type',
              'type': Config.getHtmlcontorls()['kInputText'],
              'disabled': false,
              'defaultvisibility': true,
              'required': true,
              'gridsize': Config.getFieldSize()['k375'],
            },
            {
              'field': 'isactive',
              'text': 'Status',
              'type': Config.getHtmlcontorls()['kDropDown'],
              'disabled': false,
              'defaultvisibility': true,
              'required': true,
              'gridsize': Config.getFieldSize()['k375'],
              'masterdata': 'isactive',
              'masterdataarray': Config.getStatustype(),
              'defaultvalue': 1,
              'formdatafield': 'isactive',
              'cleanable': true,
              'searchable': true,
              'masterdatadependancy': false,
            },
          ]
        }
      ],
    }
  }
}

