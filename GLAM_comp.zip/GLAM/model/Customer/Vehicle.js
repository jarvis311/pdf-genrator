import mongoose from 'mongoose'
import { Config } from '../../config/Init.js'

export default class Vehicle {
  constructor() {
    this._id
    this.propertyid = { type: mongoose.Schema.Types.ObjectId, ref: "tblpropertymaster" }
    this.property = { type: String }
    this.customerid = { type: mongoose.Schema.Types.ObjectId, ref: "tblcustomer" }
    this.customer = { type: String }
    this.vehicletypeid = { type: mongoose.Schema.Types.ObjectId, ref: "tblvehicletypemaster" }
    this.vehicletype = { type: String }
    this.vehicleimage = { type: Object, default: true }
    this.vehiclename = { type: String, trim: true }
    this.vehiclenumber = { type: String }
    this.allotedparking = { type: String }
    this.isactive = { type: Number, required: true, default: 1 }
    this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: 'recordinfo' }
  }

  getDataName() {
    return "Vehicle"
  }

  getFieldOrder() {
    return {
      "fields": [
        {
          "field": "action_button",
          "text": "",
          "type": "action_button",
          "freeze": 1,
          "active": 1,
          "sorttable": 0,
          "filter": 0,
          "disableflex": 1,
          "filterfieldtype": "lookup",
          "defaultvalue": "",
        },
        {
          "field": "isactive",
          "text": "Status",
          "type": "isactive",
          "freeze": 1,
          "active": 1,
          "sorttable": 0,
          "filter": 0,
          "disableflex": 1,
          "filterfieldtype": "lookup",
          "defaultvalue": "",
        },
        {
          "field": "customer",
          "text": "Customer Name",
          "type": "text",
          'disabled': false,
          'defaultvisibility': true,
          'cleanable': true,
          'searchable': true,
          "freeze": 1,
          "active": 1,
          "sorttable": 1,
          "sortby": "customer",
          "filter": 1,
          'filterfield': 'customerid',
          "filterfieldtype": "dropdown",
          "masterdata": "customer",
          "masterdatafield": "personname",
          "formdatafield": "customer",
          "defaultvalue": "",
        },
        {
          'field': 'vehicletype',
          'text': 'Vehicle Type',
          'type': "text",
          "freeze": 1,
          "active": 1,
          "sorttable": 1,
          "filter": 1,
          'filterfield': 'vehicletypeid',
          "filterfieldtype": "dropdown",
          'masterdata': 'vehicletype',
          'masterdatafield': 'vehicletype',
          "formdatafield": "vehicletype",
          'defaultvalue': "",
        },
        {
          "field": "vehiclenumber",
          "text": "Vehicle Number",
          "type": "text",
          "freeze": 1,
          "active": 1,
          "sorttable": 1,
          "filter": 0,
          "defaultvalue": "",
        },
        {
          "field": "allotedparking",
          "text": "Alloted Parking",
          "type": "text",
          "freeze": 1,
          "active": 1,
          "sorttable": 1,
          "filter": 0,
          "defaultvalue": "",
        },
      ]
    };
  }

  getFormFieldOrder() {
    return {
      "rightsidebarsize": 400,
      "pagename": "vehicle",
      "formname": "Vehicle",
      "alias": "vehicle",
      "dataview": "tab",
      "formfields": [
        {
          "tab": "Vehicle",
          "formFields": [
            {
              'field': 'customerid',
              'text': 'Customer Name',
              'type': "dropdown",
              'disabled': false,
              'defaultvisibility': true,
              'required': true,
              'gridsize': 375,
              'masterdata': 'customer',
              'masterdatafield': 'personname',
              "formdatafield": "customer",
              'defaultvalue': "",
              'cleanable': true,
              'searchable': true,
              'masterdatadependancy': false,
            },
            {
              "field": "vehiclename",
              "text": "Vehicle Name",
              "type": "input-text",
              "disabled": false,
              "defaultvisibility": true,
              "required": true,
              "gridsize": 375,
            },
            {
              "field": "vehiclenumber",
              "text": "Vehicle Number",
              "type": "input-text",
              "disabled": false,
              "defaultvisibility": true,
              "required": false,
              "gridsize": 375,
              "regxtype": "vehiclenumber"
            },
            {
              "field": "vehicleimage",
              "text": "Vehicle Image",
              "type": "file",
              "filetypes": Config.images,
              "disabled": false,
              "defaultvisibility": true,
              "required": false,
              "gridsize": 375
            },
            {
              "field": "allotedparking",
              "text": "Alloted Parking",
              "type": "input-text",
              "disabled": false,
              "defaultvisibility": true,
              "required": true,
              "gridsize": 375,
            },
            {
              'field': 'vehicletypeid',
              'text': 'Vehicle Type',
              'type': "dropdown",
              'disabled': false,
              'defaultvisibility': true,
              'required': true,
              'gridsize': 375,
              'masterdata': 'vehicletype',
              'masterdatafield': 'vehicletype',
              "formdatafield": "vehicletype",
              'defaultvalue': "",
              'cleanable': true,
              'searchable': true,
              'masterdatadependancy': false,
            },
          ]
        }
      ]
    };
  }
}

