import mongoose from 'mongoose'
import { Config } from '../../config/Init.js'

export default class pet {
  constructor() {
    this._id
    this.propertyid = { type: mongoose.Schema.Types.ObjectId, ref: 'tblpropertymaster' }
    this.property = { type: String, required: true }
    this.customerid = { type: mongoose.Schema.Types.ObjectId, ref: 'tblcustomer' }
    this.customer = { type: String, required: true }
    this.petname = { type: String, required: true, trim: true }
    this.pettypeid = { type: mongoose.Schema.Types.ObjectId, ref: 'tblpettypemaster' }
    this.pettype = { type: String, required: true }
    this.breedid = { type: mongoose.Schema.Types.ObjectId, ref: 'tblbreedmaster' }
    this.breed = { type: String }
    this.petpic = Config.getImageModel()
    this.dateofbirth = { type: Date, trim: true }
    this.identificationfeature = { type: String, required: true }
    this.contact = { type: String, trim: true }
    this.contact_countrycode = { type: String, trim: true }
    this.alternatecontact = { type: String, trim: true }
    this.alternatecontact_countrycode = { type: String, trim: true }
    this.ownedproperties = [{
      propertyid: { type: mongoose.Schema.Types.ObjectId, ref: "tblpropertymaster" },
      property: { type: String },
      unitid: { type: mongoose.Schema.Types.ObjectId, ref: "tblpropertyunit" },
      unit: { type: String },
      wingid: { type: mongoose.Schema.Types.ObjectId, ref: "tblpropertywing" },
      wing: { type: String },
      floorid: { type: mongoose.Schema.Types.ObjectId, ref: "tblpropertyfloor" },
      floor: { type: String },
      customerid: { type: mongoose.Schema.Types.ObjectId, ref: "tblcustomer" },
      customer: { type: String }
    }]
    this.weekdays = { type: Array },
      this.time = { type: Array },
      this.starttime = { type: String },
      this.endtime = { type: String },
      this.allowtime = [{
        startdate: { type: Date },
        enddate: { type: Date }
      }],
      this.status = { type: Number, default: 0 } // 0-default ,1-in gatekeeper, 2-out gatekeeper
    this.petindate = { type: Date }
    this.petoutdate = { type: Date }
    this.guesttype = { type: Number }
    this.pickdate = [{ type: String }]
    this.allowanytime = { type: Number, enum: [0, 1], default: 0 } // 0-no , 1-yes
    this.allowdays = [{ type: String }]
    this.otp = { type: String }
    this.isactive = { type: Number, required: true, default: 1 }
    this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: 'recordinfo' }
  }

  getDataName() {
    return "Pet"
  }

  getIndexes() {
    return [[{ propertyid: 1, customerid: 1, petname: 1 }, { unique: 1 }]]
  }

  getFieldOrder() {
    return {
      fields: [
        {
          'field': 'action_button',
          'text': '',
          'type': Config.getHtmlcontorls()['action_button'],
          'freeze': 1,
          'active': 1,
          'sorttable': 0,
          'filter': 0,
          'disableflex': 1,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': 8
        },
        {
          'field': 'isactive',
          'text': 'Status',
          'type': Config.getHtmlcontorls()['isactive'],
          'freeze': 1,
          'active': 1,
          'sorttable': 0,
          'filter': 0,
          'disableflex': 1,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': 15
        },
        {
          "field": "petpic",
          "text": "Pet Picture",
          "type": Config.getHtmlcontorls()["image"],
          "freeze": 0,
          "active": 1,
          "sorttable": 0,
          "filter": 0,
          "defaultvalue": "",
          'tblsize': 8,
          "tblsize": 20
        },
        {
          "field": "petname",
          "text": "Pet Name",
          'type': Config.getHtmlcontorls()['text'],
          'freeze': 0,
          'active': 1,
          'sorttable': 1,
          'sortby': 'name',
          'filter': 0,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': 20
        },

        {
          'field': 'pettype',
          'text': 'Pet Type',
          'type': Config.getHtmlcontorls()['text'],
          'freeze': 0,
          'active': 1,
          'sorttable': 1,
          'sortby': 'pettype',
          'filter': 1,
          'filterfieldtype': Config.getHtmlcontorls()['kDropDown'],
          "masterdata": "pettype",
          "masterdatafield": "pettype",
          "filterfield": "pettypeid",
          "formdatafield": "pettype",
          "defaultvalue": "",
          "masterdatadependancy": false,
          'tblsize': 20
        },
        {
          "field": "customer",
          "text": "Customer",
          'type': Config.getHtmlcontorls()['text'],
          'freeze': 0,
          'active': 1,
          'sorttable': 1,
          'sortby': 'customer',
          'filter': 1,
          'filterfieldtype': Config.getHtmlcontorls()['kDropDown'],
          "masterdata": "customer",
          "masterdatafield": "personname",
          "filterfield": "customerid",
          "formdatafield": "customer",
          "defaultvalue": "",
          "projection": { "personname": 1 },
          "masterdatadependancy": false,
          'tblsize': 20
        },
        {
          'field': 'breed',
          'text': 'Breed',
          'type': Config.getHtmlcontorls()['text'],
          'freeze': 0,
          'active': 1,
          'sorttable': 1,
          'sortby': 'breed',
          'filter': 1,
          'filterfieldtype': Config.getHtmlcontorls()['kDropDown'],
          "masterdata": "breed",
          "masterdatafield": "breed",
          "filterfield": "breedid",
          "formdatafield": "breed",
          "defaultvalue": "",
          "masterdatadependancy": false,
          'defaultvalue': '',
          'tblsize': 85
        }

      ]
    }
  }

  getFormFieldOrder() {
    return {
      "rightsidebarsize": Config.getModalsizeclasses()['xs'],
      "pagename": 'pets',
      "formname": 'Pets',
      "alias": 'pets',
      "dataview": "tab",
      'formfields': [
        {
          "tab": "Pets",
          "formFields": [

            {
              "field": "petname",
              "text": "Pet Name",
              "type": Config.getHtmlcontorls()["kInputText"],
              "disabled": false,
              "defaultvisibility": true,
              "required": true,
              "gridsize": Config.getFieldSize()["k375"]
            },
            {
              "field": "customerid",
              "text": "Customer",
              "type": "dropdown",
              "disabled": false,
              "defaultvisibility": true,
              "required": true,
              "gridsize": 375,
              "masterdata": "customer",
              "masterdatafield": "personname",
              "formdatafield": "customer",
              "cleanable": true,
              "searchable": true,
              "masterdatadependancy": false,

              "staticfilter": { "isactive": 1 }
            },

            {
              "field": "petpic",
              "text": "Pet Picture",
              "type": "file",
              "filetypes": Config.images,
              "disabled": false,
              "defaultvisibility": true,
              "required": false,
              "gridsize": 375
            },
            {
              "field": "pettypeid",
              "text": "Pet Type",
              "type": "dropdown",
              "disabled": false,
              "defaultvisibility": true,
              "required": true,
              "gridsize": 375,
              "masterdata": "pettype",
              "masterdatafield": "pettype",
              "formdatafield": "pettype",
              "cleanable": true,
              "searchable": true,
              "masterdatadependancy": false,
              "onchangefill": ["breedid"],
              "staticfilter": { "isactive": 1 }
            },
            {
              "field": "breedid",
              "text": "Breed",
              "type": "dropdown",
              "disabled": false,
              "defaultvisibility": true,
              "required": true,
              "gridsize": 375,
              "masterdata": "breed",
              "masterdatafield": "breed",
              "formdatafield": "breed",
              "cleanable": true,
              "searchable": true,
              "dependentfilter": { "pettypeid": "pettypeid" },
              "masterdatadependancy": true,
              "staticfilter": { "isactive": 1 }
            },
            {
              "field": "dateofbirth",
              "text": "DOB",
              "type": "datepicker",
              "disabled": false,
              "defaultvisibility": true,
              "required": true,
              "gridsize": 375
            },
            {
              "field": "identificationfeature",
              "text": "Identification Feature",
              "type": Config.getHtmlcontorls()["kInputTextArea"],
              "disabled": false,
              "defaultvisibility": true,
              "required": true,
              "gridsize": Config.getFieldSize()["k375"]
            }
          ]
        }
      ],
    }
  }
}

