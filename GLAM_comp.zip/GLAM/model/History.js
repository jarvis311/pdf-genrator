export default class History {
    constructor() {
        this._id
        this.ipaddress = { type: String, required: true, trim: true }
        this.platform = { type: String, required: true, trim: true }
        this.datetime = { type: String, required: true, trim: true }
        this.data = { type: String, required: true, trim: true }
        this.url = { type: String, required: true, trim: true }
    }

}
