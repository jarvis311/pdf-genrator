import mongoose from "mongoose"
export default class EmailLogs {
	constructor() {
		this._id
		this.smtpid = { type: mongoose.Schema.Types.ObjectId, ref: "tblemailsmtp" }
		this.host = { type: String, trim: true, default: "" }
		this.port = { type: String, trim: true, default: "" }
		this.from = { type: String, trim: true, default: "" }
		this.to = { type: Array, default: [] }
		this.bcc = { type: Array, default: [] }
		this.cc = { type: Array, default: [] }
		this.subject = { type: String, trim: true, default: "" }
		this.body = { type: String, trim: true, default: "" }
		this.status = { type: Number, default: 0 } // 1: success, 2: failed
		this.datetime = { type: Date, default: Date.now }
		this.data = {type : Object}
	}
}
