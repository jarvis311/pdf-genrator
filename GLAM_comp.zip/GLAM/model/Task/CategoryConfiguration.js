import mongoose from "mongoose"
import _Config from "../../config/Config.js"
import { Config } from "../../config/Init.js"

export default class CategoryConfiguration {
    constructor() {
        this._id
        this.propertyid = { type: mongoose.Schema.Types.ObjectId, ref: "tblproperty" }
        this.propertyname = { type: String, trim: true }
        this.categoryid = { type: mongoose.Schema.Types.ObjectId, ref: "tbltaskcategory" }
        this.category = { type: String, required: true, trim: true }
        this.categoryalias = { type: String, required: true, trim: true }
        this.personid = { type: mongoose.Schema.Types.ObjectId, default: Config.dummyObjid }
        this.person = { type: String, trim: true }
        this.designationid = { type: mongoose.Schema.Types.ObjectId, ref: "tbldesignationmaster", default: Config.dummyObjid }
        this.designation = { type: String, trim: true }

        this.isreminder = { type: Number, default: 0 }
        this.reminderhours = { type: Number, default: 0 }
        this.reminderminutes = { type: Number, default: 0 }
        this.reminderisshow = { type: Number, default: 0 }

        this.isafterreminder = { type: Number, default: 0 }
        this.afterreminderhours = { type: Number, default: 0 }
        this.afterreminderminutes = { type: Number, default: 0 }
        this.afterreminderisshow = { type: Number, default: 0 }

        this.photosrequired = { type: Number, default: 0 }
        this.photosrequiredisshow = { type: Number, default: 0 }

        this.carryforward = { type: Number, default: 0 }
        this.carryforwardisshow = { type: Number, default: 0 }

        this.inspectioncarryforward = { type: Number, default: 0 }
        this.inspectioncarryforwardisshow = { type: Number, default: 0 }

        this.notifyifdone = { type: Number, default: 0 }
        this.notifyifdonepersons = [
            {
                personid: { type: mongoose.Schema.Types.ObjectId },
                personname: { type: String, trim: true }
            }
        ]
        this.notifyifdonedepartment = [
            {
                departmentid: { type: mongoose.Schema.Types.ObjectId, ref: "tbldepartmentmaster" },
                department: { type: String, trim: true }
            }
        ]
        this.notifyifdonedesignation = [
            {
                designationid: { type: mongoose.Schema.Types.ObjectId, ref: "tbldesignationmaster" },
                designation: { type: String, trim: true }
            }
        ]
        this.notifyifdoneisshow = { type: Number, default: 0 }

        this.notifyifnot = { type: Number, default: 0 }
        this.notifyifnotpersons = [
            {
                // personid: { type: mongoose.Schema.Types.ObjectId, ref: "tblpersonmaster" },
                personid: { type: mongoose.Schema.Types.ObjectId },
                personname: { type: String, trim: true }
            }
        ]
        this.notifyifnotdonedepartment = [
            {
                departmentid: { type: mongoose.Schema.Types.ObjectId, ref: "tbldepartmentmaster" },
                department: { type: String, trim: true }
            }
        ]
        this.notifyifnotdonedesignation = [
            {
                designationid: { type: mongoose.Schema.Types.ObjectId, ref: "tbldesignationmaster" },
                designation: { type: String, trim: true }
            }
        ]
        this.notifyifnotisshow = { type: Number, default: 0 }
        this.notifyifnotbuffertime = { type: Date, trim: true, default: "" }
        this.notifyifnotbufferhours = { type: Number, default: 0 }
        this.notifyifnotbufferminutes = { type: Number, default: 0 }

        this.notifyifnotaccepted = { type: Number, default: 0 }
        this.notifyifnotacceptedpersons = [
            {
                // personid: { type: mongoose.Schema.Types.ObjectId, ref: "tblpersonmaster" },
                personid: { type: mongoose.Schema.Types.ObjectId },
                personname: { type: String, trim: true }
            }
        ]
        this.notifyifnotaccepteddepartment = [
            {
                departmentid: { type: mongoose.Schema.Types.ObjectId, ref: "tbldepartmentmaster" },
                department: { type: String, trim: true }
            }
        ]
        this.notifyifnotaccepteddesignation = [
            {
                designationid: { type: mongoose.Schema.Types.ObjectId, ref: "tbldesignationmaster" },
                designation: { type: String, trim: true }
            }
        ]
        this.notifyifnotacceptedisshow = { type: Number, default: 0 }
        this.notifyifnotacceptedbuffertime = { type: Date, trim: true, default: "" }
        this.notifyifnotacceptedbufferhours = { type: Number, default: 0 }
        this.notifyifnotacceptedbufferminutes = { type: Number, default: 0 }

        //for inspector(notify if not accepted)

        this.notifyifnotacceptedforinspector = { type: Number, default: 0 }
        this.notifyifnotacceptedinspectorpersons = [
            {
                // personid: { type: mongoose.Schema.Types.ObjectId, ref: "tblpersonmaster" },
                personid: { type: mongoose.Schema.Types.ObjectId },
                personname: { type: String, trim: true }
            }
        ]
        this.notifyifnotacceptedinspectordepartment = [
            {
                departmentid: { type: mongoose.Schema.Types.ObjectId, ref: "tbldepartmentmaster" },
                department: { type: String, trim: true }
            }
        ]
        this.notifyifnotacceptedinspectordesignation = [
            {
                designationid: { type: mongoose.Schema.Types.ObjectId, ref: "tbldesignationmaster" },
                designation: { type: String, trim: true }
            }
        ]
        this.notifyifnotacceptedinspectorisshow = { type: Number, default: 0 }
        this.notifyifnotacceptedinspectorbuffertime = { type: Date, trim: true, default: "" }
        this.notifyifnotacceptedinspectorbufferhours = { type: Number, default: 0 }
        this.notifyifnotacceptedinspectorbufferminutes = { type: Number, default: 0 }

        this.dualauthentication = { type: Number, default: 0 }
        this.dualauthenticationpersons = [
            {
                // personid: { type: mongoose.Schema.Types.ObjectId, ref: "tblpersonmaster" },
                personid: { type: mongoose.Schema.Types.ObjectId },
                personname: { type: String, trim: true }
            }
        ]
        this.dualauthenticationdepartment = [
            {
                departmentid: { type: mongoose.Schema.Types.ObjectId, ref: "tbldepartmentmaster" },
                department: { type: String, trim: true }
            }
        ]
        this.dualauthenticationdesignation = [
            {
                designationid: { type: mongoose.Schema.Types.ObjectId, ref: "tbldesignationmaster" },
                designation: { type: String, trim: true }
            }
        ]
        this.dualauthenticationisshow = { type: Number, default: 0 }
        this.dualauthenticationbuffertime = { type: Date, trim: true, default: "" }
        this.dualauthenticationbufferhours = { type: Number, default: 0 }
        this.dualauthenticationbufferminutes = { type: Number, default: 0 }

        this.dualauthenticationwithphoto = { type: Number, default: 0 }
        this.dualauthenticationwithphotopersons = [
            {
                // personid: { type: mongoose.Schema.Types.ObjectId, ref: "tblpersonmaster" },
                personid: { type: mongoose.Schema.Types.ObjectId },
                personname: { type: String, trim: true }
            }
        ]
        this.dualauthenticationwithphotodepartment = [
            {
                departmentid: { type: mongoose.Schema.Types.ObjectId, ref: "tbldepartmentmaster" },
                department: { type: String, trim: true }
            }
        ]
        this.dualauthenticationwithphotodesignation = [
            {
                designationid: { type: mongoose.Schema.Types.ObjectId, ref: "tbldesignationmaster" },
                designation: { type: String, trim: true }
            }
        ]
        this.dualauthenticationwithphotoisshow = { type: Number, default: 0 }
        this.dualauthenticationwithphotobuffertime = { type: Date, trim: true, default: "" }
        this.dualauthenticationwithphotobufferhours = { type: Number, default: 0 }
        this.dualauthenticationwithphotobufferminutes = { type: Number, default: 0 }

        //open reminder assignee
        this.assigneeopenreminder = { type: Number, default: 0 }
        this.assigneeopenreminderisshow = { type: Number, default: 0 }
        this.assigneeopenreminderbuffertime = { type: Date, trim: true, default: "" }
        this.assigneeopenreminderbufferhours = { type: Number, default: 0 }
        this.assigneeopenreminderbufferminutes = { type: Number, default: 0 }

        // paused reminder assignee
        this.assigneepausedreminder = { type: Number, default: 0 }
        this.assigneepausedreminderisshow = { type: Number, default: 0 }
        this.assigneepausedreminderbuffertime = { type: Date, trim: true, default: "" }
        this.assigneepausedreminderbufferhours = { type: Number, default: 0 }
        this.assigneepausedreminderbufferminutes = { type: Number, default: 0 }

        //open reminder inspector
        this.inspectoropenreminder = { type: Number, default: 0 }
        this.inspectoropenreminderisshow = { type: Number, default: 0 }
        this.inspectoropenreminderbuffertime = { type: Date, trim: true, default: "" }
        this.inspectoropenreminderbufferhours = { type: Number, default: 0 }
        this.inspectoropenreminderbufferminutes = { type: Number, default: 0 }

        // paused reminder inspector
        this.inspectorpausedreminder = { type: Number, default: 0 }
        this.inspectorpausedreminderisshow = { type: Number, default: 0 }
        this.inspectorpausedreminderbuffertime = { type: Date, trim: true, default: "" }
        this.inspectorpausedreminderbufferhours = { type: Number, default: 0 }
        this.inspectorpausedreminderbufferminutes = { type: Number, default: 0 }

        this.estdeviation = { type: Number, default: 0 }
        this.estdeviationisshow = { type: Number, default: 0 }
        this.estdeviationpercentage = { type: Number, default: 0 } // number in percentage

        this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: "recordinfo" }
    }

    getFieldOrder() {
        const Config = new _Config()
        return {
            fields: []
        }
    }
}
