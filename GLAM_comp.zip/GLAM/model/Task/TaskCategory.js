import mongoose from "mongoose"
import _Config from "../../config/Config.js"
import { Config } from "../../config/Init.js"

export class _TaskCategory {
    constructor() {
        this._id
        this.taskcategory = { type: String, required: true, trim: true }
        this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: "recordinfo" }
    }

    getFieldOrder() {
        const Config = new _Config()

        return {
            fields: [
                {
                    field: "name",
                    text: "Task Category",
                    type: Config.getHtmlcontorls()["text"],
                    freeze: 0,
                    active: 1,
                    sorttable: 1,
                    filter: 1,
                    filterfieldtype: Config.getHtmlcontorls()["lookup"],
                    defaultvalue: "",
                    tblsize: Config.getTblgridsizeclasses()["tbl-min-w150"]
                }
            ]
        }
    }

    getDataName() {
        return "Task Category"
    }
}