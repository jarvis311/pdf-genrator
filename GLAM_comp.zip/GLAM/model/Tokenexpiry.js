export default class Tokenexpiry {
    constructor() {
        this._id
        this.unqkey = { type: String, required: true, trim: true, unique: true }
        this.uid = { type: String, required: true, trim: true }
        this.iss = { type: String, required: true, trim: true }
        this.useragent = { type: String, required: true, trim: true }
        this.exp = { type: String, required: true, trim: true }
        this.entry_date = { type: String, required: true, trim: true }
        this.isvalid = { type: Number, default: 1 }
        this.token = { type: String, required: true, trim: true }
        this.update_date = { type: String, trim: true }
    }

    getIndexes() {
        return [{ uid: 1, unqkey: 1, token: 1, isvalid: 1 }]
    }
}
