import { Config } from "../../config/Init.js"
import _Config from "../../config/Config.js"
import mongoose from "mongoose"

export default class Employee {
  constructor() {
    // Employee Overviews
    this._id
    this.seriesid = { type: mongoose.Schema.Types.ObjectId, ref: "tblseriesmaster" }
    this.maxid = { type: Number }
    this.employee_id = { type: String, required: true, unique: [true, 'Employee ID already exists.'] }

    this.dateformat = { type: Number, trim: true }
    this.timeformat = { type: Number, trim: true }
    this.firstname = { type: String, required: true, trim: true }
    this.middlename = { type: String, trim: true }
    this.lastname = { type: String, required: true, trim: true }
    this.personname = { type: String, required: true, trim: true }
    this.personemail = { type: String, trim: true, unique: [true, 'Email already exists.'] }
    this.password = { type: String, required: true, trim: true }
    this.isresetpassword = { type: Number, default: 0 }
    this.contact = { type: String, trim: true, required: true, unique: [true, 'Contact already exists.'] }
    this.contact_countrycode = { type: String, trim: true }
    this.alternatecontact = { type: String, trim: true }
    this.alternatecontact_countrycode = { type: String, trim: true }
    this.profilepicture = Config.getImageModel()
    this.genderid = { type: mongoose.Schema.Types.ObjectId, ref: "tblgendermaster" }
    this.gender = { type: String, trim: true }
    this.dateofbirth = { type: Date, trim: true }
    this.addressline1 = { type: String, trim: true }
    this.addressline2 = { type: String, trim: true }
    this.countryid = { type: mongoose.Schema.Types.ObjectId, ref: "tblcountrymaster" }
    this.country = { type: String, trim: true }
    this.stateid = { type: mongoose.Schema.Types.ObjectId, ref: "tblstatemaster" }
    this.state = { type: String, trim: true }
    this.cityid = { type: mongoose.Schema.Types.ObjectId, ref: "tblcitymaster" }
    this.city = { type: String, trim: true }
    this.pincodeid = { type: mongoose.Schema.Types.ObjectId, ref: "tblpincodemaster" }
    this.pincode = { type: String, trim: true }
    this.area = { type: String, trim: true }
    this.emergencyname = { type: String, trim: true }
    this.emergencycontact = { type: String, trim: true }
    this.username = { type: String, trim: true, required: true, unique: [true, 'Username already exists.'] }
    this.property = [
      {
        propertyid: { type: mongoose.Schema.Types.ObjectId, ref: "tblproperty" },
        property: { type: String, required: true },
        isselected: { type: Number, default: 0 }
      }
    ]
    this.isactive = { type: Number, default: 1 }
    this.isdelete = { type: Number, default: 0 }
    this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: "recordinfo" }

    // Policy Master
    this.department = [
      {
        departmentid: { type: mongoose.Schema.Types.ObjectId },
        department: { type: String }
      }
    ]
    this.userrole = [
      {
        userroleid: { type: mongoose.Schema.Types.ObjectId },
        userrole: { type: String, required: true }
      }
    ]
    this.reportingtoid = { type: mongoose.Schema.Types.ObjectId, ref: "tblemployee", default: Config.dummyObjid }
    this.reportingto = { type: String, trim: true, default: "" }
    this.qrcode = { type: String, trim: true }
    this.passcode = { type: String, trim: true }
    //Documents
    this.documents = [Config.getImageModel()]
    this.isadmin = { type: Number, default: 0 }

    // Invalid Login
    this.invalidlogincount = { type: Number, default: 0 }
    this.accountlocktime = { type: Date, default: null }

    // 2FA Configuration
    this.is2FAenable = { type: Number, default: 0 } // 2FA enable
    this.temp_2FA_secret = { type: String, default: "" }
    this.secret_2FA = { type: String, default: "" }
    this.recoverycodes = { type: Array, default: [] }
    this.requestid = { type: String }

    this.isterminated = { type: Number, default: 0 } // 0 - not terminated employee | 1 - terminated employee
  }


  getDataName() {
    return "Employee"
  }

  getFieldOrder() {
    const Config = new _Config()
    return {
      fields: [
        {
          'field': 'action_button',
          'text': '',
          'type': Config.getHtmlcontorls()['action_button'],
          'freeze': 1,
          'active': 1,
          'sorttable': 0,
          'filter': 0,
          'disableflex': 1,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': 8
        },
        {
          'field': 'isactive',
          'text': 'Status',
          'type': Config.getHtmlcontorls()['isactive'],
          'freeze': 1,
          'active': 1,
          'sorttable': 0,
          'filter': 0,
          'disableflex': 1,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': 15
        },
        {
          "field": "personname",
          "text": "Person Name",
          'type': 'person-name',

          "freeze": 0,
          "active": 1,
          "sorttable": 1,
          "filter": 0,
          "filterfieldtype": Config.getHtmlcontorls()["multipleselectdropdown"],
          "masterdatafield": "personname",
          "formdatafield": "_id",
          "defaultvalue": [],
          "tblsize": Config.getTblgridsizeclasses()["tbl-w150"]
        },
        // {
        //   "field": "profilepic",
        //   "text": "Profile Picture",
        //   "type": Config.getHtmlcontorls()["image"],
        //   "freeze": 0,
        //   "active": 1,
        //   "sorttable": 0,
        //   "filter": 0,
        //   "defaultvalue": "",
        //   "tblsize": Config.getTblgridsizeclasses()["tbl-w120"]
        // },
        {
          "field": "contact",
          "text": "Contact",
          "type": Config.getHtmlcontorls()["text"],
          "freeze": 0,
          "active": 1,
          "sorttable": 1,
          "filter": 0,
          "filterfieldtype": Config.getHtmlcontorls()["lookup"],
          "defaultvalue": "",
          "tblsize": Config.getTblgridsizeclasses()["tbl-w140"]
        },
        {
          "field": "personemail",
          "text": "Email",
          "type": Config.getHtmlcontorls()["text"],
          "freeze": 0,
          "active": 1,
          "sorttable": 1,
          "filter": 0,
          "filterfieldtype": Config.getHtmlcontorls()["lookup"],
          "defaultvalue": "",
          "tblsize": Config.getTblgridsizeclasses()["tbl-w140"]
        },


        {
          'field': ['userrole'],
          'text': 'User Role',
          'type': "taglist",
          "forlisttag": "userrole",
          'freeze': 0,
          'active': 1,
          'sorttable': 0,
          'sortby': 'wing',
          "filter": 1,
          'filterfield': 'userrole',
          "filterfieldtype": "multipleselectdropdown",
          "apipath": "masters/userrole",
          "masterdata": "userrole",
          "masterdatafield": "userrole",
          "formdatafield": "userrole.userroleid",
          "defaultvalue": [],
          "arrayfieldkey": "userrole",
          "tblsize": Config.getTblgridsizeclasses()["tbl-w140"]
        },
        // {
        //   "field": "property",
        //   "text": "Property",
        //   "type": "text-array",
        //   "textarrayfiledname": "property",
        //   "freeze": 0,
        //   "active": 1,
        //   "sorttable": 0,
        //   "filter": 0,
        //   "filterfieldtype": Config.getHtmlcontorls()["lookup"],
        //   "defaultvalue": "",
        //   "tblsize": Config.getTblgridsizeclasses()["tbl-w140"]
        // },
        {
          'field': ['property'],
          'text': 'Property',
          'type': "taglist",
          "forlisttag": "property",
          'freeze': 0,
          'active': 1,
          'sorttable': 0,
          'sortby': 'wing',
          'filter': 0,
          "filterfieldtype": Config.getHtmlcontorls()["lookup"],
          "defaultvalue": "",
          "tblsize": 50
        },
        // {
        //   "field": "department",
        //   "text": "Department",
        //   "type": Config.getHtmlcontorls()['text-array'],
        //   "freeze": 0,
        //   "active": 1,
        //   "sorttable": 0,
        //   "filter": 1,
        //   'filterfield': 'department',
        //   "filterfieldtype": "multipleselectdropdown",
        //   "apipath": "department",
        //   "masterdata": "department",
        //   "masterdatafield": "department",
        //   "formdatafield": "department.departmentid",
        //   "defaultvalue": [],
        //   "arrayfieldkey": "department"
        // },
        {
          'field': ['department'],
          'text': 'Department',
          'type': "taglist",
          "forlisttag": "department",
          'freeze': 0,
          'active': 1,
          'sorttable': 0,
          'sortby': 'wing',
          "filter": 1,
          'filterfield': 'department',
          "filterfieldtype": "multipleselectdropdown",
          "apipath": "department",
          "masterdata": "department",
          "masterdatafield": "department",
          "formdatafield": "department.departmentid",
          "defaultvalue": [],
          "arrayfieldkey": "department",
          "tblsize": Config.getTblgridsizeclasses()["tbl-w140"]
        },
        {
          "field": "is2FAenable",
          "text": "2FA Enable",
          "type": Config.getHtmlcontorls()["switch"],
          "freeze": 0,
          "active": 1,
          "sorttable": 0,
          "filter": 0,
          "filterfieldtype": Config.getHtmlcontorls()["dropdown"],
          "formdatafield": "is2FAenable",
          "masterdataarray": [
            {
              label: "Active",
              value: 1
            },
            {
              label: "Inactive",
              value: 0
            }
          ],
          "defaultvalue": "",
          "tblsize": Config.getTblgridsizeclasses()["tbl-w110"]
        },
        {
          "field": "isterminated",
          "text": "Terminated",
          "type": Config.getHtmlcontorls()["switch"],
          "freeze": 0,
          "active": 1,
          "sorttable": 0,
          "filter": 0,
          "filterfieldtype": Config.getHtmlcontorls()["dropdown"],
          "formdatafield": "isactive",
          "masterdataarray": [
            {
              label: "Active",
              value: 1
            },
            {
              label: "Inactive",
              value: 0
            }
          ],
          "defaultvalue": "",
          "tblsize": Config.getTblgridsizeclasses()["tbl-w110"]
        }
      ]
    }
  }


  getFormFieldOrder() {
    return {
      "rightsidebarsize": 1200,
      "pagename": "employee",
      "formname": "Employee",
      "alias": "employee",
      "dataview": "tab",
      "formfields": [
        {
          "tab": "Personal Information",
          "formFields": [
            {
              "field": "employee_id",
              "text": "EmployeeID",
              "type": "input-text",
              "disabled": false,
              "defaultvisibility": true,
              "required": true,// demo
              "gridsize": 375
            },
            {
              "field": "firstname",
              "text": "First Name",
              "type": "input-text",
              "disabled": false,
              "defaultvisibility": true,
              "required": true,// demo
              "gridsize": 375,
              "regex": "[a-zA-Z ]",
              "capitalcase": true
            },
            {
              "field": "lastname",
              "text": "Last Name",
              "type": "input-text",
              "disabled": false,
              "defaultvisibility": true,
              "required": true,// demo
              "gridsize": 375,
              "regex": "[a-zA-Z ]",
              "capitalcase": true
            },

            {
              "field": "contact",
              "text": "Contact No",
              "type": "number-input",
              "disabled": false,
              "defaultvisibility": true,
              'prefixtext': 'code',
              "required": true,// demo
              "gridsize": 375
            },
            {
              "field": "alternatecontact",
              "text": "Alternate Contact No",
              "type": "number-input",
              "disabled": false,
              "defaultvisibility": true,
              'prefixtext': 'code',
              "required": false,
              "gridsize": 375
            },
            {
              "field": "personemail",
              "text": "Email ID",
              "type": "input-text",
              "disabled": false,
              "defaultvisibility": true,
              'regxtype': 'email',
              "required": false,
              "gridsize": 375
            },
            {
              "field": "username",
              "text": "User Name",
              "type": "input-text",
              "disabled": false,
              "defaultvisibility": true,
              "required": true,// demo
              'minlength': 3,
              "gridsize": 375
            },
            {
              "field": "password",
              "text": "Password",
              "type": "input-text",
              "obscure": true,
              "disabled": false,
              "defaultvisibility": true,
              "required": true,// demo
              'minlength': 3,
              "gridsize": 375
            },
            {
              "field": "confirmpassword",
              "text": "Confirm password",
              "type": "input-text",
              "obscure": true,
              "disabled": false,
              "defaultvisibility": true,
              "required": true,// demo
              "gridsize": 375
            },
            {
              "field": "dateofbirth",
              "text": "DOB",
              "type": "datepicker",
              "disabled": false,
              "defaultvisibility": true,
              "required": true,// demo
              "gridsize": 375
            },
            {
              "field": "profilepicture",
              "text": "Profile Picture",
              "type": "file",
              "filetypes": Config.images,
              "disabled": false,
              "defaultvisibility": true,
              "required": false,
              "gridsize": 375
            }
          ]
        },
        {
          "tab": "Other Detail",
          "formFields": [
            {
              "field": "property",
              "masterdata": "property",
              "masterdatafield": "propertyname",
              "formdatafield": "property",
              "text": "Property",
              "type": "multipleselectdropdown",
              "disabled": false,
              "defaultvisibility": true,
              "required": true,// demo
              "gridsize": 375,
              "filter": 1,
              "filterfieldtype": "multipleselectdropdown",
              "cleanable": true,
              "searchable": true,
              "masterdatadependancy": false,
              "staticfilter": { "isactive": 1, }
            },
            {
              "field": "userrole",
              "text": "User Role",
              "type": "multipleselectdropdown",
              "disabled": false,
              "defaultvisibility": true,
              "required": true,// demo
              "gridsize": 375,
              "filter": 1,
              "filterfieldtype": "multipleselectdropdown",
              "masterdata": "userrolehierarchywise",
              "masterdatafield": "userrole",
              "formdatafield": "userrole",
              "cleanable": true,
              "searchable": true,
              "masterdatadependancy": false,
              "staticfilter": { "isactive": 1 }
            },
            {
              "field": "department",
              "text": "Department",
              "type": "multipleselectdropdown",
              "disabled": false,
              "defaultvisibility": true,
              "required": true,// demo
              "gridsize": 375,
              "filter": 1,
              "masterdata": "department",
              "masterdatafield": "department",
              "formdatafield": "department",
              "cleanable": true,
              "searchable": true,
              "masterdatadependancy": false,
              "staticfilter": { "isactive": 1 }
            },
            {
              "field": "reportingtoid",
              "text": "Reporting To",
              "type": "dropdown",
              "disabled": false,
              "defaultvisibility": true,
              "required": true,// demo
              "gridsize": 375,
              "masterdata": "employee",
              "masterdatafield": "reportingto",
              "formdatafield": "reportingto",
              "projection": {
                "reportingtoid": "\$_id",
                "reportingto": "\$personname"
              },
              "cleanable": true,
              "searchable": true,
              "masterdatadependancy": false,
              "staticfilter": { "isactive": 1, 'isterminated': 0 }
            },
          ]
        },
        {
          "tab": "Address Information",
          "formFields": [
            {
              "field": "addressline1",
              "text": "Flat, House no., Building, Street",
              "type": "input-text",
              "disabled": false,
              "defaultvisibility": true,
              "required": true,
              "gridsize": 375
          },
          {
              "field": "addressline2",
              "text": "Area, Landmark",
              "type": "input-text",
              "disabled": false,
              "defaultvisibility": true,
              "required": true,
              "gridsize": 375
          },
            {
              "field": "area",
              "text": "Area, Landmark",
              "type": "input-text",
              "disabled": false,
              "defaultvisibility": true,
              "required": false,
              "gridsize": 375
            },
            {
              "field": "pincode",
              "text": "Pincode",
              "type": "number-input",
              "disabled": false,
              "defaultvisibility": true,
              "required": true,// demo
              "gridsize": 375,
            },
            {
              "field": "stateid",
              "text": "State",
              "type": "dropdown",
              "disabled": false,
              "defaultvisibility": true,
              "required": true,// demo
              "gridsize": 375,
              "masterdata": "state",
              "masterdatafield": "state",
              "formdatafield": "state",
              "cleanable": true,
              "searchable": true,
              "onchangefill": ["cityid"],
              "dependentfilter": { "countryid": "countryid" },
              "masterdatadependancy": false,
              "defaultvalue": "66acd3cb6a781176246a9637",
              "staticfilter": { "isactive": 1 }
            },
            {
              "field": "cityid",
              "text": "City",
              "type": "dropdown",
              "disabled": false,
              "defaultvisibility": true,
              "required": true,// demo
              "gridsize": 375,
              "masterdata": "city",
              "masterdatafield": "city",
              "formdatafield": "city",
              "cleanable": true,
              "searchable": true,
              "dependentfilter": { "stateid": "stateid" },
              "masterdatadependancy": false,
              "defaultvalue": "6710b1a7d57b9665bf472274",
              "staticfilter": { "isactive": 1 }
            }
          ]
        },
        {
          "tab": "Document",
          "formFields": [
            {
              "field": "documents",
              "text": "Document Name",
              "type": "multipleFilePickerfieldwithtitle",
              "disabled": false,
              "defaultvisibility": true,
              "required": true,// demo
              "gridsize": 375,
              "filetypes": [...Config.pdfExtension, ...Config.images, ...Config.docExtension],

            }
          ]
        }
      ]
    };
  }

}
