import { Config } from "../../config/Init.js"
import _Config from "../../config/Config.js"
import mongoose from "mongoose"

export default class GateKepper {
  constructor() {
    // getkeeper Overviews
    this._id
    this.dateformat = { type: Number, trim: true }
    this.timeformat = { type: Number, trim: true }
    this.firstname = { type: String, required: true, trim: true }
    this.middlename = { type: String, trim: true }
    this.lastname = { type: String, required: true, trim: true }
    this.personname = { type: String, required: true, trim: true }
    this.personemail = { type: String, trim: true }
    this.username = { type: String, trim: true, required: true, unique: [true, 'Username already exists.'] }
    this.password = { type: String, required: true, trim: true }
    this.isresetpassword = { type: Number, default: 0 }
    this.contact = { type: String, trim: true, required: true, unique: [true, 'Contact already exists.'] }
    this.contact_countrycode = { type: String, trim: true }
    this.alternatecontact = { type: String, trim: true }
    this.alternatecontact_countrycode = { type: String, trim: true }
    this.profilepicture = Config.getImageModel()
    this.genderid = { type: mongoose.Schema.Types.ObjectId, ref: "tblgendermaster" }
    this.gender = { type: String, trim: true }
    this.dateofbirth = { type: Date, trim: true }
    this.addressline1 = { type: String, trim: true }
    this.addressline2 = { type: String, trim: true }
    this.stateid = { type: mongoose.Schema.Types.ObjectId, ref: "tblstatemaster" }
    this.state = { type: String, trim: true }
    this.cityid = { type: mongoose.Schema.Types.ObjectId, ref: "tblcitymaster" }
    this.city = { type: String, trim: true }
    this.pincodeid = { type: mongoose.Schema.Types.ObjectId, ref: "tblpincodemaster" }
    this.pincode = { type: String, trim: true }
    this.area = { type: String, trim: true }

    this.emergencyname = { type: String, trim: true }
    this.emergencycontact = { type: String, trim: true }

    this.propertyid = { type: mongoose.Schema.Types.ObjectId, ref: "tblproperty" },
      this.property = { type: String }

    // this.gate = [{
    //   gateid: { type: mongoose.Schema.Types.ObjectId, ref: "tblgatemaster" },
    //   gate: { type: String, trim: true }
    // }]

    this.isactive = { type: Number, default: 1 }
    this.isdelete = { type: Number, default: 0 }
    this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: "recordinfo" }


    this.reportingtos = [
      {
        reportingtoid: { type: mongoose.Schema.Types.ObjectId, ref: "tblgatekeeper", default: Config.dummyObjid },
        reportingto: { type: String, trim: true, default: "" }
      }
    ]
    this.approvetos = [
      {
        approvetoid: { type: mongoose.Schema.Types.ObjectId, ref: "tblgatekeeper", default: Config.dummyObjid },
        approveto: { type: String, trim: true, default: "" }
      }
    ]
    this.reportingtoid = { type: mongoose.Schema.Types.ObjectId, ref: "tblgatekeeper", default: Config.dummyObjid }
    this.reportingto = { type: String, trim: true, default: "" }
    this.approvetoid = { type: mongoose.Schema.Types.ObjectId, ref: "tblgatekeeper", default: Config.dummyObjid }
    this.approveto = { type: String, trim: true, default: "" }

    // Documents
    this.documents = this.documents = [{
      doc: Config.getImageModel(),
      name: { type: String }
    }]

    this.clockindate = { type: Date }
    this.clockoutdate = { type: Date }

    // Invalid Login
    this.invalidlogincount = { type: Number, default: 0 }
    this.accountlocktime = { type: Date, default: null }

    // 2FA Configuration
    this.is2FAenable = { type: Number, default: 0 } // 2FA enable
    this.temp_2FA_secret = { type: String, default: "" }
    this.secret_2FA = { type: String, default: "" }
    this.recoverycodes = { type: Array, default: [] }
    this.requestid = { type: String }

    this.isterminated = { type: Number, default: 0 } // 0 - not terminated | 1 - terminated 
  }

  getDataName() {
    return "GateKepper"
  }

  getFieldOrder() {
    const Config = new _Config()
    return {
      "fields": [
        {
          "field": "action_button",
          "text": "",
          "type": "action_button",
          "freeze": 1,
          "active": 1,
          "sorttable": 0,
          "filter": 0,
          "disableflex": 1,
          "filterfieldtype": "lookup",
          "defaultvalue": "",
          "tblsize": 8
        },
        {
          "field": "isactive",
          "text": "Status",
          "type": "isactive",
          "freeze": 1,
          "active": 1,
          "sorttable": 0,
          "filter": 0,
          "disableflex": 1,
          "filterfieldtype": "lookup",
          "defaultvalue": "",
          "tblsize": 15
        },
        {
          "field": "personname",
          "text": "Person Name",
          'type': 'person-name',

          "freeze": 0,
          "active": 1,
          "sorttable": 1,
          "filter": 0,
          "filterfieldtype": "multipleselectdropdown",
          "masterdatafield": "personname",
          "formdatafield": "_id",
          "defaultvalue": []
        },
        // {
        //   "field": "profilepicture",
        //   "text": "Profile Picture",
        //   "type": "image",
        //   "freeze": 0,
        //   "active": 1,
        //   "sorttable": 0,
        //   "filter": 0,
        //   "defaultvalue": ""
        // },
        {
          "field": "contact",
          "text": "Contact",
          "type": "text",
          "freeze": 0,
          "active": 1,
          "sorttable": 1,
          "filter": 0,
          "filterfieldtype": "lookup",
          "defaultvalue": ""
        },
        {
          "field": "personemail",
          "text": "Email",
          "type": "text",
          "freeze": 0,
          "active": 1,
          "sorttable": 1,
          "filter": 0,
          "filterfieldtype": "lookup",
          "defaultvalue": ""
        },

        {
          "field": "propertyid",
          "masterdata": "property",
          "masterdatafield": "propertyname",
          "formdatafield": "property",
          "text": "Property",
          "type": "dropdown",
          "freeze": 0,
          "active": 1,
          "sorttable": 1,
          "filter": 0,
          "disabled": false,
          "filterfieldtype": "lookup",
          "defaultvalue": "",
          "defaultvisibility": true,
          "required": true,
          "gridsize": 375,
          "filter": 1,
          // 'onchangefill': ['gate'],
          "filterfieldtype": "dropdown",
          "cleanable": true,
          "searchable": true,
          "masterdatadependancy": false,
          "staticfilter": { "isactive": 1 }
        },


        // {
        //   "field": "gate",
        //   "text": "Gates",
        //   "type": "text-array",
        //   "freeze": 0,
        //   "active": 1,
        //   "sorttable": 0,
        //   "filter": 1,
        //   "filterfield": "gate",
        //   "filterfieldtype": "multipleselectdropdown",
        //   "apipath": "property/gate",
        //   "masterdata": "property/gate",
        //   "masterdatafield": "gateno",
        //   "formdatafield": "gateno",
        //   "defaultvalue": [],
        //   "arrayfieldkey": "gate"
        // },
        {
          "field": "reportingto",
          "text": "Reporting To",
          "type": "text",
          "freeze": 0,
          "active": 1,
          "sorttable": 1,
          "filter": 0,
          "filterfieldtype": "lookup",
          "defaultvalue": ""
        },
        {
          "field": "is2FAenable",
          "text": "2FA Enable",
          "type": "switch",
          "freeze": 0,
          "active": 1,
          "sorttable": 0,
          "filter": 0,
          "filterfieldtype": "dropdown",
          "formdatafield": "is2FAenable",
          "masterdataarray": [
            { "label": "Active", "value": 1 },
            { "label": "Inactive", "value": 0 }
          ],
          "defaultvalue": ""
        },
        {
          "field": "isterminated",
          "text": "Terminated",
          "type": "switch",
          "freeze": 0,
          "active": 1,
          "sorttable": 0,
          "filter": 0,
          "filterfieldtype": "dropdown",
          "formdatafield": "isactive",
          "masterdataarray": [
            { "label": "Active", "value": 1 },
            { "label": "Inactive", "value": 0 }
          ],
          "defaultvalue": ""
        }
      ]
    }
  }


  getFormFieldOrder() {
    return {
      "rightsidebarsize": 1200,
      "pagename": "gatekeeper",
      "formname": "Gatekeeper",
      "alias": "gatekeeper",
      "dataview": "tab",
      "formfields": [
        {
          "tab": "Personal Information",
          "formFields": [
            {
              "field": "firstname",
              "text": "First Name",
              "type": "input-text",
              "disabled": false,
              "defaultvisibility": true,
              "required": true,
              "capitalcase": true,
              "gridsize": 375
            },
            {
              "field": "lastname",
              "text": "Last Name",
              "type": "input-text",
              "disabled": false,
              "defaultvisibility": true,
              "required": true,
              "capitalcase": true,
              "gridsize": 375
            },
            {
              "field": "genderid",
              "text": "Gender",
              "type": "dropdown",
              "disabled": false,
              "defaultvisibility": true,
              "required": true,
              "gridsize": 375,
              "masterdata": "gender",
              "masterdataarray": [
                { "label": "Male", "value": "66a1e97c238fdcb94369331d" },
                { "label": "Female", "value": "66a1e97c238fdcb94369300d" },
                { "label": "Other", "value": "66a1e97c238fdcb94369130d" }
              ],
              "defaultvalue": "66a1e97c238fdcb94369331d",
              "formdatafield": "gender",
              "cleanable": true,
              "searchable": true,
              "masterdatadependancy": false
            },
            {
              "field": "contact",
              "text": "Contact No",
              "type": "number-input",
              "disabled": false,
              "defaultvisibility": true,
              "prefixtext": "code",
              "required": true,
              "gridsize": 375
            },
            {
              "field": "alternatecontact",
              "text": "Alternate Contact No",
              "type": "number-input",
              "disabled": false,
              "defaultvisibility": true,
              "prefixtext": "code",
              "required": false,
              "gridsize": 375
            },
            {
              "field": "personemail",
              "text": "Email Address",
              "type": "input-text",
              "disabled": false,
              "defaultvisibility": true,
              // "regex": "^(([^<>()[]\\.,;:s@\"]+(.[^<>()[]\\.,;:s@\"]+)*)|(\".+\"))@(([[0-9]{1,3}.[0-9]{1,3}.[0-9]{1,3}.[0-9]{1,3}])|(([a-zA-Z-0-9]+.)+[a-zA-Z]{2,}))",
              "required": true,
              "gridsize": 375,
              "regxtype": "email"
            },
            {
              "field": "username",
              "text": "User Name",
              "type": "input-text",
              "disabled": false,
              "defaultvisibility": true,
              "required": true,
              "gridsize": 375
            },
            {
              "field": "password",
              "text": "Password",
              "type": "input-text",
              "obscure": true,
              "disabled": false,
              "defaultvisibility": true,
              "required": true,
              "gridsize": 375
            },
            {
              "field": "confirmpassword",
              "text": "Confirm password",
              "type": "input-text",
              "obscure": true,
              "disabled": false,
              "defaultvisibility": true,
              "required": true,
              "gridsize": 375
            },
            {
              "field": "dateofbirth",
              "text": "DOB",
              "type": "datepicker",
              "disabled": false,
              "defaultvisibility": true,
              "required": true,
              "gridsize": 375
            },
            {
              "field": "profilepicture",
              "text": "Profile Picture",
              "type": "file",
              "filetypes": Config.images,
              "disabled": false,
              "defaultvisibility": true,
              "required": false,
              "gridsize": 375
            }
          ]
        },
        {
          "tab": "Other Detail",
          "formFields": [
            {
              "field": "propertyid",
              "masterdata": "property",
              "masterdatafield": "propertyname",
              "formdatafield": "property",
              "text": "Property",
              "type": "dropdown",
              "disabled": false,
              "defaultvisibility": true,
              "required": true,
              "gridsize": 375,
              "filter": 1,
              // 'onchangefill': ['gate'],
              "filterfieldtype": "dropdown",
              "cleanable": true,
              "searchable": true,
              "masterdatadependancy": false,
              "staticfilter": { "isactive": 1 }
            },
            // {
            //   "field": "gate",
            //   "masterdata": "property/gate",
            //   "masterdatafield": "gate",
            //   "formdatafield": "gate",
            //   "text": "Gate",
            //   "type": "multipleselectdropdown",
            //   "disabled": false,
            //   "defaultvisibility": true,
            //   "required": true,
            //   "gridsize": 375,
            //   "filter": 1,
            //   "filterfieldtype": "multipleselectdropdown",
            //   "cleanable": true,
            //   "searchable": true,
            //   "projection": { "gateid": "\$_id", "gate": "\$gateno" },
            //   'dependentfilter': { 'propertyid': 'propertyid' },
            //   "masterdatadependancy": true,
            //   "staticfilter": { "isactive": 1 }
            // },
            {
              "field": "reportingtoid",
              "text": "Reporting To",
              "type": "dropdown",
              "disabled": false,
              "defaultvisibility": true,
              "required": true,
              "gridsize": 375,
              "masterdata": "employee",
              "masterdatafield": "reportingto",
              "formdatafield": "reportingto",
              "projection": {
                "reportingtoid": "\$_id",
                "reportingto": "\$personname"
              },
              "cleanable": true,
              "searchable": true,
              "masterdatadependancy": false,
              "staticfilter": { "isactive": 1 }
            }
          ]
        },
        {
          "tab": "Address Information",
          "formFields": [
            {
              "field": "addressline1",
              "text": "Flat, House no., Building, Street",
              "type": "input-text",
              "disabled": false,
              "defaultvisibility": true,
              "required": true,
              "gridsize": 375
          },
          {
              "field": "addressline2",
              "text": "Area, Landmark",
              "type": "input-text",
              "disabled": false,
              "defaultvisibility": true,
              "required": true,
              "gridsize": 375
          },
            {
              "field": "area",
              "text": "Area, Landmark",
              "type": "input-text",
              "disabled": false,
              "defaultvisibility": true,
              "required": false,
              "gridsize": 375
            },
            {
              "field": "pincode",
              "text": "Pincode",
              "type": "number-input",
              "disabled": false,
              "defaultvisibility": true,
              "required": true,
              "gridsize": 375
            },
            {
              "field": "stateid",
              "text": "State",
              "type": "dropdown",
              "disabled": false,
              "defaultvisibility": true,
              "required": true,
              "gridsize": 375,
              "masterdata": "state",
              "masterdatafield": "state",
              "formdatafield": "state",
              "cleanable": true,
              "searchable": true,
              "onchangefill": ["cityid"],
              "dependentfilter": { "countryid": "countryid" },
              "masterdatadependancy": false,
              "defaultvalue": "66acd3cb6a781176246a9637",
              "staticfilter": { "isactive": 1 }
            },
            {
              "field": "cityid",
              "text": "City",
              "type": "dropdown",
              "disabled": false,
              "defaultvisibility": true,
              "required": true,
              "gridsize": 375,
              "masterdata": "city",
              "masterdatafield": "city",
              "formdatafield": "city",
              "cleanable": true,
              "searchable": true,
              "dependentfilter": { "stateid": "stateid" },
              "masterdatadependancy": false,
              "defaultvalue": "6710b1a7d57b9665bf472274",
              "staticfilter": { "isactive": 1 }
            }
          ]
        },
        {
          "tab": "Document",
          "formFields": [
            {
              "field": "documents",
              "text": "Document Name",
              "type": "multipleFilePickerfieldwithtitle",
              "disabled": false,
              "defaultvisibility": true,
              "required": true,
              "gridsize": 375
            }
          ]
        }
      ]
    };
  }

}
