import mongoose from 'mongoose';
import { Config } from '../../config/Init.js'

export default class VendorStaff {
    constructor() {
        // vendor Overviews
        this.isactive = { type: Number, default: 1 }
        this._id
        this.seriesid = { type: mongoose.Schema.Types.ObjectId, ref: "tblseriesmaster" }
        this.maxid = { type: Number }
        this.propertyid = { type: mongoose.Schema.Types.ObjectId, ref: 'tblpropertymanster' },
            this.property = { type: String },
            this.vendorcompanyid = { type: mongoose.Schema.Types.ObjectId, ref: "tblvendormaster", required: true },
            this.vendorcompany = { type: String, trim: true },
            this.staffname = { type: String, required: true }
        this.firstname = { type: String, required: true }
        this.lastname = { type: String, required: true }
        this.profilepic = Config.getImageModel()
        this.roleid = { type: mongoose.Schema.Types.ObjectId, ref: "tblvisitorcategorymaster", required: true },
            this.role = { type: String, trim: true },
            this.email = { type: String, trim: true, required: true },
            this.contactno = { type: Number, required: true },
            this.contactno_countrycode = { type: Number, required: true },
            this.alternatecontact = { type: String, trim: true },
            this.alternatecontact_countrycode = { type: String, trim: true }
        this.addressline1 = { type: String, trim: true }
        this.addressline2 = { type: String, trim: true }
        this.stateid = { type: mongoose.Schema.Types.ObjectId, ref: "tblstatemaster", required: true },
            this.state = { type: String, trim: true },
            this.cityid = { type: mongoose.Schema.Types.ObjectId, ref: "tblcitymaster", required: true },
            this.city = { type: String, trim: true },
            this.code = { type: String, trim: true },
            this.postalcode = { type: Number, required: true },
            this.postalcodeid = { type: mongoose.Schema.Types.ObjectId, ref: "tblpincodemaster" },
            // Documents   
            this.documents = [{
                doc: Config.getImageModel(),
                name: { type: String }
            }]
        this.status = { type: Number, default: 0 } // 0-pending ,1-verify in gatekeeper, 2-out gatekeeper
        this.vendorindate = { type: Date }
        this.vendoroutdate = { type: Date }
        this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: "recordinfo" }
    }

    getDataName() {
        return "Vendor Staff"
    }


    getFieldOrder() {

        return {
            fields: [
                {
                    "field": "action_button",
                    "text": "",
                    "type": "action_button",
                    "freeze": 1,
                    "active": 1,
                    "sorttable": 0,
                    "filter": 0,
                    "disableflex": 1,
                    "filterfieldtype": "lookup",
                    "defaultvalue": "",
                    "tblsize": 7
                },
                {
                    "field": "isactive",
                    "text": "Status",
                    "type": "isactive",
                    "freeze": 1,
                    "active": 1,
                    "sorttable": 0,
                    "filter": 0,
                    "disableflex": 1,
                    "filterfieldtype": "lookup",
                    "defaultvalue": "",
                    "tblsize": 15
                },
                {
                    "field": "vendorcompany",
                    "text": "Vendor",
                    "type": "text",
                    "disabled": false,
                    "defaultvisibility": true,
                    "required": true,
                    "gridsize": 375,
                    "masterdata": "vendor",
                    "masterdatafield": "companyname",
                    "formdatafield": "vendorcompany",
                    "cleanable": true,
                    "searchable": true,
                    "active": 1,
                    "filter": 1,
                    "filterfield": "vendorcompanyid",
                    "filterfieldtype": "dropdown",
                    "masterdatadependancy": false,
                    "projection": { "companyname": 1 },
                    "staticfilter": { "isactive": 1 }
                },
                {
                    "field": "staffname",
                    "text": "Person Name",
                    "type": "text",
                    "freeze": 0,
                    "active": 1,
                    "sorttable": 1,
                    "filter": 0,
                    "sortby": "staffname",
                    "filterfieldtype": "lookup",
                    "defaultvalue": "",
                    "tblsize": 20
                },
                {
                    "field": "role",
                    "text": "Role/Position",
                    "type": "dropdown",
                    "disabled": false,
                    "defaultvisibility": true,
                    "required": true,
                    "gridsize": 375,
                    "masterdata": "vendorstaffdesignation",
                    "masterdatafield": "vendorstaffdesignation",
                    "formdatafield": "role",
                    "filter": 1,
                    "filterfield": "roleid",
                    "filterfieldtype": "dropdown",
                    "active": 0,
                    "cleanable": true,
                    "searchable": true,
                    "masterdatadependancy": false,
                    "projection": { "vendorstaffdesignation": 1 },
                    "staticfilter": { "isactive": 1 }
                },
                {
                    "field": "email",
                    "text": "Email ID",
                    "type": "text",
                    "freeze": 0,
                    "active": 1,
                    "sorttable": 1,
                    "filter": 0,
                    "sortby": "lastname",
                    "filterfieldtype": "lookup",
                    "defaultvalue": "",
                    "tblsize": 20
                },
                {
                    "field": "contactno",
                    "text": "Contact No.",
                    "type": "text",
                    "freeze": 0,
                    "active": 1,
                    "sorttable": 1,
                    "filter": 0,
                    "sortby": "contactno",
                    "filterfieldtype": "lookup",
                    "defaultvalue": "",
                    "tblsize": 20
                },
                {
                    "field": "alternatecontact",
                    "text": "Alternate Contact No.",
                    "type": "text",
                    "freeze": 0,
                    "active": 1,
                    "sorttable": 1,
                    "filter": 0,
                    "sortby": "alternatecontact",
                    "filterfieldtype": "lookup",
                    "defaultvalue": "",
                    "tblsize": 20
                },
            ]
        }
    }

    getFormFieldOrder() {
        return {
            "rightsidebarsize": 760,
            "pagename": 'vendorstaff',
            "formname": 'Vendor Staff',
            "alias": 'vendorstaff',
            "dataview": "tab",
            'formfields': [
                {
                    "tab": "Vendor Staff",
                    "formFields": [
                        { "field": "profilepic", "text": "Profile Picture", "type": "file", "filetypes": Config.images, "disabled": false, "defaultvisibility": true, "required": false, "gridsize": 375 },
                        {
                            "field": "vendorcompanyid",
                            "text": "Vendor",
                            "type": "dropdown",
                            "disabled": false,
                            "defaultvisibility": true,
                            "required": true,
                            "gridsize": 375,
                            "masterdata": "vendor",
                            "masterdatafield": "companyname",
                            "formdatafield": "vendorcompany",
                            "cleanable": true,
                            "searchable": true,
                            "masterdatadependancy": false,
                            "projection": { "companyname": 1 },
                            "staticfilter": { "isactive": 1 }
                        },
                        {
                            "field": "firstname",
                            "text": "First Name",
                            "type": "input-text",
                            "disabled": false,
                            "defaultvisibility": true,
                            "required": true,
                            "capitalcase": true,
                            "gridsize": 375,
                        },
                        {
                            "field": "lastname",
                            "text": "Last Name",
                            "type": "input-text",
                            "disabled": false,
                            "defaultvisibility": true,
                            "required": true,
                            "capitalcase": true,
                            "gridsize": 375,
                        },
                        {
                            "field": "roleid",
                            "text": "Role/Position",
                            "type": "dropdown",
                            "disabled": false,
                            "defaultvisibility": true,
                            "required": true,
                            "gridsize": 375,
                            "masterdata": "vendorstaffdesignation",
                            "masterdatafield": "vendorstaffdesignation",
                            "formdatafield": "role",
                            "cleanable": true,
                            "searchable": true,
                            "masterdatadependancy": false,
                            "projection": { "vendorstaffdesignation": 1 },
                            "staticfilter": { "isactive": 1 }
                        },
                        {
                            "field": "email",
                            "text": "Email ID",
                            "type": "input-text",
                            "disabled": false,
                            "defaultvisibility": true,
                            'regxtype': 'email',
                            "required": false,
                            "gridsize": 375
                        },
                        {
                            "field": "contactno",
                            "text": "Contact No",
                            "type": "number-input",
                            "disabled": false,
                            "defaultvisibility": true,
                            "decimalpoint": 0,
                            'prefixtext': 'code',
                            "required": true,
                            "gridsize": 375
                        },
                        {
                            "field": "alternatecontact",
                            "text": "Alternate Contact No.",
                            "type": "number-input",
                            "disabled": false,
                            "defaultvisibility": true,
                            "decimalpoint": 0,
                            'prefixtext': 'code',
                            "required": false,
                            "gridsize": 375
                        },
                        {
                            "field": "addressline1",
                            "text": "Flat, House no., Building, Street",
                            "type": "input-text",
                            "disabled": false,
                            "defaultvisibility": true,
                            "required": true,
                            "gridsize": 375
                        },
                        {
                            "field": "addressline2",
                            "text": "Area, Landmark",
                            "type": "input-text",
                            "disabled": false,
                            "defaultvisibility": true,
                            "required": true,
                            "gridsize": 375
                        },
                        { "field": "postalcode", "text": "Pin Code", "type": "number-input", "disabled": false, "defaultvisibility": true, "required": true, "gridsize": 375, },
                        {
                            "field": "stateid",
                            "text": "State",
                            "type": "dropdown",
                            "disabled": false,
                            "defaultvisibility": true,
                            "required": true,
                            "gridsize": 375,
                            "masterdata": "state",
                            "masterdatafield": "state",
                            "formdatafield": "state",
                            "cleanable": true,
                            "searchable": true,
                            "onchangefill": ['cityid'],
                            "masterdatadependancy": false,
                            "defaultvalue": "66acd3cb6a781176246a9637",
                            "staticfilter": { "isactive": 1 }
                        },
                        {
                            "field": "cityid",
                            "text": "City",
                            "type": "dropdown",
                            "disabled": false,
                            "defaultvisibility": true,
                            "required": true,
                            "gridsize": 375,
                            "masterdata": "city",
                            "masterdatafield": "city",
                            "formdatafield": "city",
                            "cleanable": true,
                            "searchable": true,
                            'dependentfilter': {
                                'stateid': 'stateid',
                            },
                            "masterdatadependancy": true,
                            "defaultvalue": "6710b1a7d57b9665bf472274",
                            "staticfilter": { "isactive": 1 }
                        },

                    ]

                },
                {
                    "tab": "Document",
                    "formFields": [
                        {
                            "field": "documents",
                            "text": "Document Name",
                            "type": "multipleFilePickerfieldwithtitle",
                            "disabled": false,
                            'filetypes': [...Config.images, ...Config.pdfExtension, ...Config.docExtension],
                            "defaultvisibility": true,
                            "required": true,
                            "gridsize": 375
                        }
                    ]
                }
            ]
        };
    }
}



















