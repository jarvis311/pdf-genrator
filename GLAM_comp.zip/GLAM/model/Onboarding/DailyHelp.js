import mongoose from 'mongoose';
import { Config } from '../../config/Init.js'

export default class DailyHelp {
    constructor() {
        // person Overviews
        this._id
        this.firstname = { type: String, required: true, trim: true }
        this.middlename = { type: String, trim: true }
        this.lastname = { type: String, required: true, trim: true }
        this.personname = { type: String, required: true, trim: true }
        this.personemail = { type: String, trim: true }
        this.contact = { type: String, trim: true }
        this.alternatecontact = { type: String, trim: true }
        this.businesscontact = { type: String, trim: true }
        this.countrycode = { type: String, trim: true }
        this.profilepic = Config.getImageModel()
        this.genderid = { type: mongoose.Schema.Types.ObjectId, ref: "tblgendermaster" }
        this.gender = { type: String, trim: true }
        this.dateofbirth = { type: Date, trim: true }
        this.addressline1 = { type: String, trim: true }
        this.addressline2 = { type: String, trim: true }
        //address details
        this.businessaddress = { type: String, trim: true }
        this.countryid = { type: mongoose.Schema.Types.ObjectId, ref: "tblcountrymaster" }
        this.country = { type: String, trim: true }
        this.stateid = { type: mongoose.Schema.Types.ObjectId, ref: "tblstatemaster" }
        this.state = { type: String, trim: true }
        this.cityid = { type: mongoose.Schema.Types.ObjectId, ref: "tblcitymaster" }
        this.city = { type: String, trim: true }
        this.pincodeid = { type: mongoose.Schema.Types.ObjectId, ref: "tblpincodemaster" }
        this.pincode = { type: String, trim: true }
        this.area = { type: String, trim: true }
        this.nationalityid = { type: mongoose.Schema.Types.ObjectId, ref: "tblnationalitymaster" }
        this.nationality = { type: String, trim: true }
        this.emergencyname = { type: String, trim: true }
        this.emergencycontact = { type: String, trim: true }
        this.websiteURL = { type: String, trim: true },
            this.isactive = { type: Number, default: 1 }
        this.isdelete = { type: Number, default: 0 }
        this.dailyhelpcategory = { type: String, trim: true },//category type
            this.dailyhelpcategoryid = { type: mongoose.Schema.Types.ObjectId, ref: "tbldeliverytypemaster" }
        this.propertyid = { type: mongoose.Schema.Types.ObjectId, ref: 'tblproperty' },
            this.property = { type: String }
        //timeslot
        this.timeslot = [{
            starttime: { type: String, required: true },
            endtime: { type: String, required: true }
        }]
        this.disableslot = [{
            starttime: { type: String },
            endtime: { type: String },
            slotid: { type: mongoose.Schema.Types.ObjectId },
            isdisabled: { type: Number, default: 1 }
        }]
        this.workin = [{
            customerid: { type: mongoose.Schema.Types.ObjectId, ref: 'tblcustomer' },
            customer: { type: String },
            propertyid: { type: mongoose.Schema.Types.ObjectId, ref: 'tblproperty' },
            property: { type: String },
            wingid: { type: mongoose.Schema.Types.ObjectId, ref: 'tblpropertywing' },
            wing: { type: String },
            unitid: { type: mongoose.Schema.Types.ObjectId, ref: 'tblpropertyunit' },
            unit: { type: String },
            starttime: { type: Date, default: Date.now }
        }]
        //rating
        this.rating = [{
            customerid: { type: mongoose.Schema.Types.ObjectId, ref: "tblcustomer" },
            customer: { type: String },
            rating: { type: String },
            date: { type: String },
            description: { type: String }
        }]
        this.isapproved = { type: Number, default: 0 }       // 0-pending 1- approved 2- rejected
        this.rejectreason = { type: String, default: "" }
        this.iscancel = { type: Number, default: 0 }
        this.cancelreason = { type: String, default: "" }
        this.bankName = { type: String, trim: true },        //bank details
            this.accountNumber = { type: String, trim: true },
            this.ifscCode = { type: String, trim: true },
            this.paymentTerms = { type: String, trim: true },
            this.certificationsAndLicenses = [{
                documentName: { type: String, trim: true },
                documentFile: { type: String, trim: true }
            }],
            this.codeOfConduct = { type: String, trim: true },    //terms and condition
            this.signature = { type: String, trim: true },
            // Documents
            this.documents = [{
                doc: Config.getImageModel(),
                name: { type: String }
            }]
        this.isactive = { type: Number, default: 1 }
        this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: "recordinfo" }
    }

    getDataName() {
        return "Daily Help"
    }

    getFieldOrder() {

        return {
            fields: [
                {
                    field: 'action_button',
                    text: '',
                    type: Config.getHtmlcontorls()['action_button'],
                    freeze: 1,
                    active: 1,
                    sorttable: 0,
                    filter: 0,
                    disableflex: 1,
                    filterfieldtype: Config.getHtmlcontorls()['lookup'],
                    defaultvalue: '',
                    tblsize: 8
                },
                {
                    'field': 'isactive',
                    'text': 'Status',
                    'type': Config.getHtmlcontorls()['isactive'],
                    'freeze': 1,
                    'active': 1,
                    'sorttable': 0,
                    'filter': 0,
                    'disableflex': 1,
                    'filterfieldtype': Config.getHtmlcontorls()['lookup'],
                    'defaultvalue': '',
                    'tblsize': Config.getTblgridsizeclasses()[15]
                },
                {
                    field: "dailyhelpcategory",
                    text: "Dailyhelp Category",
                    'type': Config.getHtmlcontorls()['text'],
                    'freeze': 0,
                    'active': 1,
                    'sorttable': 0,
                    'filter': 0,
                    "defaultvisibility": true,
                    'filterfieldtype': Config.getHtmlcontorls()['lookup'],
                    'defaultvalue': '',
                    tblsize: 25
                },

                {
                    'field': 'personname',
                    'text': 'Person Name',
                    'type': Config.getHtmlcontorls()['text'],
                    'freeze': 0,
                    'active': 1,
                    'sorttable': 1,
                    'filter': 0,
                    'sortby': 'personname',
                    "defaultvisibility": true,
                    'filterfieldtype': Config.getHtmlcontorls()['lookup'],
                    'defaultvalue': '',
                    tblsize: 15
                },
                {
                    'field': 'gender',
                    'text': 'Gender',
                    'type': Config.getHtmlcontorls()['text'],
                    'freeze': 0,
                    'active': 1,
                    'sorttable': 1,
                    'filter': 0,
                    'sortby': 'gender',
                    "defaultvisibility": true,
                    'filterfieldtype': Config.getHtmlcontorls()['lookup'],
                    'defaultvalue': '',
                    tblsize: 15
                },
                {
                    field: "contact",
                    text: "Contact",
                    type: Config.getHtmlcontorls()["text"],
                    freeze: 0,
                    active: 1,
                    sorttable: 1,
                    filter: 0,
                    filterfieldtype: Config.getHtmlcontorls()["lookup"],
                    defaultvalue: "",
                    tblsize: 20
                },
                {
                    field: "alternatecontact",
                    text: "Alternate Contact",
                    type: Config.getHtmlcontorls()["text"],
                    freeze: 0,
                    active: 1,
                    sorttable: 1,
                    filter: 0,
                    filterfieldtype: Config.getHtmlcontorls()["lookup"],
                    defaultvalue: "",
                    tblsize: 20
                },
                {
                    field: "personemail",
                    text: "Email",
                    type: Config.getHtmlcontorls()["text"],
                    freeze: 0,
                    active: 1,
                    sorttable: 1,
                    filter: 0,
                    filterfieldtype: Config.getHtmlcontorls()["lookup"],
                    defaultvalue: "",
                    tblsize: 75
                },


            ]
        }
    }

    getFormFieldOrder() {
        return {
            "rightsidebarsize": Config.getModalsizeclasses()['xs'],
            "pagename": 'dailyhelp',
            "formname": 'Daily Help',
            "alias": 'dailyhelp-',
            "dataview": "tab",
            'formfields': [
                {
                    "tab": "Daily Help",
                    "formFields": [
                        {
                            "field": "dailyhelpcategoryid",
                            "text": "Dailyhelp Category",
                            "type": "dropdown",
                            "disabled": false,
                            "defaultvisibility": true,
                            "required": true,
                            "gridsize": 375,
                            "masterdata": "dailyhelpcategory",
                            "masterdatafield": "category",
                            "formdatafield": "dailyhelpcategory",
                            "cleanable": true,
                            "searchable": true,
                            "masterdatadependancy": false,
                            "gridsize": 375

                            // "staticfilter": { "isactive": 1 }
                        },
                        {
                            "field": "firstname", "text": "First Name", "type": "input-text", "disabled": false, "defaultvisibility": true, "required": true, "gridsize": 375, "capitalize": true,
                        },
                        {
                            "field": "lastname", "text": "Last Name", "type": "input-text", "disabled": false, "defaultvisibility": true, "required": true, "gridsize": 375, "capitalize": true,
                        },
                        { "field": "dateofbirth", "text": "DOB", "type": "datepicker", "disabled": false, "defaultvisibility": true, "required": true, "gridsize": 375 },
                        {
                            "field": "genderid",
                            "text": "Gender",
                            "type": "dropdown",
                            "disabled": false,
                            "defaultvisibility": true,
                            "required": true,
                            "gridsize": 375,
                            "masterdata": "gender",
                            "masterdataarray": [
                                { "label": "Male", "value": "66a1e97c238fdcb94369331d" },
                                { "label": "Female", "value": "66a1e97c238fdcb94369300d" },
                                { "label": "Other", "value": "66a1e97c238fdcb94369130d" }
                            ],
                            "defaultvalue": "66a1e97c238fdcb94369331d",
                            "masterdatafield": "label",
                            "formdatafield": "gender",
                            "cleanable": true,
                            "searchable": true,
                            "masterdatadependancy": false
                        },
                        {
                            "field": "contact",
                            "text": "Mobile Number",
                            "type": "number-input",
                            "disabled": false,
                            "defaultvisibility": true,
                            "prefixtext": "code",
                            "required": true,
                            "gridsize": 375
                        },
                        {
                            "field": "alternatecontact",
                            "text": "Phone Number",
                            "type": "number-input",
                            "disabled": false,
                            "defaultvisibility": true,
                            "prefixtext": "code",
                            "required": false,
                            "gridsize": 375
                        },
                        {
                            "field": "personemail",
                            "text": "Email Address",
                            "type": "input-text",
                            "disabled": false,
                            "defaultvisibility": true,
                            // "regex": "^(([^<>()[]\\.,;:s@\"]+(.[^<>()[]\\.,;:s@\"]+)*)|(\".+\"))@(([[0-9]{1,3}.[0-9]{1,3}.[0-9]{1,3}.[0-9]{1,3}])|(([a-zA-Z-0-9]+.)+[a-zA-Z]{2,}))",
                            "required": false,
                            "gridsize": 375,
                            "regxtype": "email"
                        },
                        {
                            "field": "nationalityid",
                            "text": "Nationality",
                            "type": "dropdown",
                            "disabled": false,
                            "defaultvisibility": true,
                            "required": true,
                            "gridsize": 375,
                            "masterdata": "nationality",
                            "masterdatafield": "nationality",
                            "formdatafield": "nationality",
                            "cleanable": true,
                            "searchable": true,
                            "masterdatadependancy": false,
                            "defaultvalue": "67382488171652f20e1a0754",
                            "staticfilter": { "isactive": 1 }
                        },
                        {
                            "field": "addressline1",
                            "text": "Flat, House no., Building, Street",
                            "type": "input-text",
                            "disabled": false,
                            "defaultvisibility": true,
                            "required": true,
                            "gridsize": 375
                        },
                        {
                            "field": "addressline2",
                            "text": "Area, Landmark",
                            "type": "input-text",
                            "disabled": false,
                            "defaultvisibility": true,
                            "required": false,
                            "gridsize": 375
                        },
                        { "field": "pincode", "text": "Pincode", "type": "number-input", "disabled": false, "defaultvisibility": true, "required": true, "gridsize": 375 },

                        {
                            "field": "stateid",
                            "text": "State",
                            "type": "dropdown",
                            "disabled": false,
                            "defaultvisibility": true,
                            "required": true,
                            "gridsize": 375,
                            "masterdata": "state",
                            "masterdatafield": "state",
                            "formdatafield": "state",
                            "cleanable": true,
                            "searchable": true,
                            "onchangefill": ['cityid'],
                            "masterdatadependancy": false,
                            "defaultvalue": "66acd3cb6a781176246a9637",
                            "staticfilter": { "isactive": 1 }
                        },
                        {
                            "field": "cityid",
                            "text": "City",
                            "type": "dropdown",
                            "disabled": false,
                            "defaultvisibility": true,
                            "required": true,
                            "gridsize": 375,
                            "masterdata": "city",
                            "masterdatafield": "city",
                            "formdatafield": "city",
                            "cleanable": true,
                            "searchable": true,
                            'dependentfilter': {
                                'stateid': 'stateid',
                            },
                            "masterdatadependancy": false,
                            "defaultvalue": "6710b1a7d57b9665bf472274",
                            "staticfilter": { "isactive": 1 }
                        },


                    ]
                },

            ]
        };
    }
}



















