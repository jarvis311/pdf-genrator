import mongoose from 'mongoose';
import { Config } from '../../config/Init.js'

export default class Vendor {
  constructor() {
    // vendor Overviews
    this._id
    this.firstname = { type: String, required: true }
    this.lastname = { type: String, required: true }
    this.personname = { type: String }
    this.ismsmeregistered = { type: Number, default: 0 }
    this.profilepicture = Config.getImageModel()
    this.alternatecontact = { type: String, trim: true }
    this.alternatecontact_countrycode = { type: String, trim: true }
    this.stateid = { type: mongoose.Schema.Types.ObjectId, ref: "tblstatemaster" },
    this.state = { type: String, trim: true },
    this.cityid = { type: mongoose.Schema.Types.ObjectId, ref: "tblcitymaster" },
    this.city = { type: String, trim: true },
    this.pincodeid = { type: mongoose.Schema.Types.ObjectId, ref: "tblpincodemaster" },
    this.pincode = { type: String, trim: true },
    this.companyname = { type: String, trim: true, required: true, unique: [true, 'Companyname already exists.'] }
    this.area = { type: String, trim: true }
    this.contactno = { type: String, required: true, unique: [true, 'Contact already exists.'] }
    this.contactno_countrycode = { type: String }
    this.addressline1 = { type: String, trim: true }
    this.addressline2 = { type: String, trim: true }
    this.email = { type: String, trim: true }
    this.facebook = { type: String, trim: true }
    this.gstin_uin = { type: String, trim: true }
    this.gsttreatmentid = { type: mongoose.Schema.Types.ObjectId, ref: "tblgsttreatmentmaster" }
    this.gsttreatment = { type: String, trim: true }
    this.isgstnumber = { type: Number, default: 0 }
    this.msmeregtypeid = { type: mongoose.Schema.Types.ObjectId, ref: "tblmsmeregtypemaster" }
    this.msmeregtype = { type: String, trim: true }
    this.msme_registration_number = { type: String, trim: true }
    this.pan_no = { type: String, trim: true }
    this.sourceofsupply = { type: String, trim: true }
    this.sourceofsupplyid = { type: mongoose.Schema.Types.ObjectId }
    this.skypename = { type: String, trim: true }
    this.twitter = { type: String, trim: true }
    this.websiteurl = { type: String, trim: true }
    this.propertyid = { type: mongoose.Schema.Types.ObjectId, ref: 'tblproperty' },
      this.property = { type: String }
    this.code = { type: String }
    this.isactive = { type: Number, default: 1 }
    this.isdelete = { type: Number, default: 0 }
    this.workin = [{
      customerid: { type: mongoose.Schema.Types.ObjectId, ref: 'tblcustomer' },
      customer: { type: String },
      propertyid: { type: mongoose.Schema.Types.ObjectId, ref: 'tblproperty' },
      property: { type: String },
      wingid: { type: mongoose.Schema.Types.ObjectId, ref: 'tblpropertywing' },
      wing: { type: String },
      unitid: { type: mongoose.Schema.Types.ObjectId, ref: 'tblpropertyunit' },
      unit: { type: String },
      starttime: { type: Date, default: Date.now },
      isactive: { type: Number, default: 1 }
    }]

    //rating
    this.rating = [{
      customerid: { type: mongoose.Schema.Types.ObjectId, ref: "tblcustomer" },
      customer: { type: String },
      rating: { type: String },
      date: { type: String },
      description: { type: String }
    }]

    // Documents
    this.documents = [{
      doc: Config.getImageModel(),
      name: { type: String }
    }]
    this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: "recordinfo" }
  }

  getDataName() {
    return "Vendor"
  }


  getFieldOrder() {

    return {
      fields: [
        {
          "field": "action_button",
          "text": "",
          "type": "action_button",
          "freeze": 1,
          "active": 1,
          "sorttable": 0,
          "filter": 0,
          "disableflex": 1,
          "filterfieldtype": "lookup",
          "defaultvalue": "",
          "tblsize": 7
        },
        {
          "field": "isactive",
          "text": "Status",
          "type": "isactive",
          "freeze": 1,
          "active": 1,
          "sorttable": 0,
          "filter": 0,
          "disableflex": 1,
          "filterfieldtype": "lookup",
          "defaultvalue": "",
          "tblsize": 15
        },
        // {
        //   "field": "firstname",
        //   "text": "First Name",
        //   "type": "text",
        //   "freeze": 0,
        //   "active": 1,
        //   "sorttable": 1,
        //   "filter": 0,
        //   "sortby": "firstname",
        //   "filterfieldtype": "lookup",
        //   "defaultvalue": "",
        //   "tblsize": 20
        // },
        // {
        //   "field": "lastname",
        //   "text": "Last Name",
        //   "type": "text",
        //   "freeze": 0,
        //   "active": 1,
        //   "sorttable": 1,
        //   "filter": 0,
        //   "sortby": "lastname",
        //   "filterfieldtype": "lookup",
        //   "defaultvalue": "",
        //   "tblsize": 20
        // },
        {
          "field": "personname",
          "text": "Person Name",
          'type': 'person-name',

          "freeze": 0,
          "active": 1,
          "sorttable": 1,
          "filter": 0,
          "sortby": "personname",
          "filterfieldtype": "lookup",
          "defaultvalue": "",
          "tblsize": 40
        },
        {
          "field": "email",
          "text": "Email ID",
          "type": "text",
          "freeze": 0,
          "active": 1,
          "sorttable": 1,
          "filter": 0,
          "sortby": "lastname",
          "filterfieldtype": "lookup",
          "defaultvalue": "",
          "tblsize": 25
        },
        {
          "field": "companyname",
          "text": "Company Name",
          "type": "text",
          "freeze": 0,
          "active": 1,
          "sorttable": 1,
          "filter": 0,
          "sortby": "companyname",
          "filterfieldtype": "lookup",
          "defaultvalue": "",
          "tblsize": 30
        },
        {
          "field": "contactno",
          "text": "Contact No",
          "type": "text",
          "freeze": 0,
          "active": 1,
          "sorttable": 0,
          "filter": 0,
          "sortby": "contactno",
          "filterfieldtype": "lookup",
          "defaultvalue": "",
          "tblsize": 20
        },
        {
          "field": "alternatecontact",
          "text": "Alternative Contact No",
          "type": "text",
          "freeze": 0,
          "active": 1,
          "sorttable": 0,
          "filter": 0,
          "sortby": "alternatecontact",
          "filterfieldtype": "lookup",
          "defaultvalue": "",
          "tblsize": 20
        },
        {
          "field": "gsttreatment",
          "text": "GST Treatment",
          "type": "dropdown",
          "disabled": false,
          "defaultvisibility": true,
          "required": true,
          "gridsize": 375,
          "masterdata": "gsttreatment",
          "masterdatafield": "gsttreatment",
          "formdatafield": "gsttreatment",
          "cleanable": true,
          "searchable": true,
          "active": 0,
          "filter": 1,
          "filterfield": "gsttreatmentid",
          "filterfieldtype": "dropdown",
          "masterdatadependancy": false,
          "staticfilter": { "isactive": 1 },
          "storeextrakeys": {
            "isgstnumber": "isgstnumber"
          }
        },

        {
          "field": "sourceofsupply",
          "text": "Source of Supply",
          "type": "dropdown",
          "disabled": false,
          "defaultvisibility": true,
          "required": true,
          "gridsize": 375,
          "masterdata": "state",
          "masterdatafield": "state",
          "formdatafield": "sourceofsupply",
          "active": 0,
          "cleanable": true,
          "searchable": true,
          "filter": 1,
          "filterfield": "sourceofsupplyid",
          "filterfieldtype": "dropdown",
          "masterdatadependancy": false,
          "staticfilter": { "isactive": 1 }
        },
        {
          'field': 'ismsmeregistered',
          'text': 'Is MSME registered?',
          'type': 'text',
          "masterdata": "ismsmeregistered",
          "masterdatafield": "ismsmeregistered",
          'masterdataarray': Config.getYesNoType(),
          'disabled': false,
          'required': false,
          "cleanable": true,
          "searchable": true,
          'defaultvisibility': true,
          "actice": 0,
          "formdatafield": "ismsmeregistered",
          "filter": 1,
          "filterfield": "ismsmeregistered",
          "filterfieldtype": "dropdown",
          'gridsize': 700,
        },
        {
          "field": "msmeregtype",
          "text": "MSME/Udyam Registration Type",
          'condition': {
            'ismsmeregistered': [1]
          },
          "type": "text",
          "disabled": false,
          "defaultvisibility": true,
          "required": true,
          "gridsize": 375,
          "masterdata": "msmeregtype",
          "masterdatafield": "msmeregtype",
          "formdatafield": "msmeregtype",
          "filter": 1,
          "filterfield": "msmeregtypeid",
          "filterfieldtype": "dropdown",
          "cleanable": true,
          "searchable": true,
          "masterdatadependancy": false,
          "staticfilter": { "isactive": 1 }
        },
      ]
    }
  }

  getFormFieldOrder() {
    return {
      "rightsidebarsize": 770,
      "pagename": 'vendor',
      "formname": 'Vendor',
      "alias": 'vendor',
      "dataview": "tab",
      'formfields': [
        {
          "tab": "Vendor",
          "formFields": [
            {
              "field": "firstname",
              "text": "First Name",
              "type": "input-text",
              "disabled": false,
              "defaultvisibility": true,
              "required": true,
              "capitalcase": true,
              "gridsize": 375,
            },
            {
              "field": "lastname",
              "text": "Last Name",
              "type": "input-text",
              "disabled": false,
              "defaultvisibility": true,
              "required": true,
              "capitalcase": true,
              "gridsize": 375,
            },
            {
              "field": "email",
              "text": "Email ID",
              "type": "input-text",
              "disabled": false,
              "defaultvisibility": true,
              'regxtype': 'email',
              "required": true,
              "gridsize": 375
            },
            {
              "field": "companyname",
              "text": "Company Name",
              "type": "input-text",
              "disabled": false,
              "defaultvisibility": true,
              "required": true,
              "capitalcase": true,
              "gridsize": 375,
            },
            {
              "field": "profilepicture",
              "text": "Profile Picture",
              "type": "file",
              "filetypes": Config.images,
              "disabled": false,
              "defaultvisibility": true,
              "required": false,
              "gridsize": 375
            },
            {
              "field": "contactno",
              "text": "Contact No",
              "type": "number-input",
              "disabled": false,
              "defaultvisibility": true,
              'prefixtext': 'code',
              "required": true,
              "gridsize": 375
            },
            {
              "field": "alternatecontact",
              "text": "Alternate Contact No",
              "type": "number-input",
              "disabled": false,
              "defaultvisibility": true,
              'prefixtext': 'code',
              "required": false,
              "gridsize": 375
            },
            {
              "field": "currentaddress",
              "text": "Flat, House no., Building, Street",
              "type": "input-text",
              "disabled": false,
              "defaultvisibility": true,
              "required": true,
              "gridsize": 375
            },
            { "field": "area", "text": "Area, Landmark", "type": "input-text", "disabled": false, "defaultvisibility": true, "required": true, "gridsize": 375 },
            { "field": "pincode", "text": "Pincode", "type": "number-input", "disabled": false, "defaultvisibility": true, "required": true, "gridsize": 375 },
            {
              "field": "stateid",
              "text": "State",
              "type": "dropdown",
              "disabled": false,
              "defaultvisibility": true,
              "required": true,
              "gridsize": 375,
              "masterdata": "state",
              "masterdatafield": "state",
              "formdatafield": "state",
              "cleanable": true,
              "searchable": true,
              "onchangefill": ['cityid'],
              "masterdatadependancy": false,
              "defaultvalue": "66acd3cb6a781176246a9637",
              "staticfilter": { "isactive": 1 }
            },
            {
              "field": "cityid",
              "text": "City",
              "type": "dropdown",
              "disabled": false,
              "defaultvisibility": true,
              "required": true,
              "gridsize": 375,
              "masterdata": "city",
              "masterdatafield": "city",
              "formdatafield": "city",
              "cleanable": true,
              "searchable": true,
              'dependentfilter': {
                'stateid': 'stateid',
              },
              "masterdatadependancy": true,
              "defaultvalue": "6710b1a7d57b9665bf472274",
              "staticfilter": { "isactive": 1 }
            },
          ]
        },
        {
          "tab": "Other Details",
          "formFields": [
            {
              "field": "gsttreatmentid",
              "text": "GST Treatment",
              "type": "dropdown",
              "disabled": false,
              "defaultvisibility": true,
              "required": true,
              "gridsize": 375,
              "masterdata": "gsttreatment",
              "masterdatafield": "gsttreatment",
              "formdatafield": "gsttreatment",
              "cleanable": true,
              "searchable": true,
              "masterdatadependancy": false,
              "staticfilter": { "isactive": 1 },
              "storeextrakeys": {
                "isgstnumber": "isgstnumber"
              }
            },
            {
              "field": "gstin_uin",
              "tooltip": "GST Identification Number or Unique Identification Number",
              "text": "GSTIN / UIN",
              "type": "input-text",
              "disabled": false,
              "defaultvisibility": false,
              "required": true,
              "gridsize": 375,
              "condition": {
                "isgstnumber": [1]
              }
            },
            {
              "field": "sourceofsupplyid",
              "text": "Source of Supply",
              "type": "dropdown",
              "disabled": false,
              "defaultvisibility": true,
              "required": true,
              "gridsize": 375,
              "masterdata": "state",
              "masterdatafield": "state",
              "formdatafield": "sourceofsupply",
              "cleanable": true,
              "searchable": true,
              "masterdatadependancy": false,
              "staticfilter": { "isactive": 1 }
            },
            { "field": "pan_no", "text": "PAN", "type": "input-text", "disabled": false, "defaultvisibility": true, "required": true, "gridsize": 375, "allcapital": true, "regxtype": "pancard", },
            {
              'field': 'ismsmeregistered',
              'text': 'This vendor is MSME registered',
              'type': 'checkbox',
              'disabled': false,
              'required': false,
              'defaultvisibility': true,
              'gridsize': 700,
            },
            {
              "field": "msmeregtypeid",
              "text": "MSME/Udyam Registration Type",
              'condition': {
                'ismsmeregistered': [1]
              },
              "type": "dropdown",
              "disabled": false,
              "defaultvisibility": true,
              "required": true,
              "gridsize": 375,
              "masterdata": "msmeregtype",
              "masterdatafield": "msmeregtype",
              "formdatafield": "msmeregtype",
              "cleanable": true,
              "searchable": true,
              "masterdatadependancy": false,
              "staticfilter": { "isactive": 1 }
            },
            {
              "field": "msme_registration_number",
              "text": "MSME/Udyam Registration Number",
              'condition': {
                'ismsmeregistered': [1]
              },
              "type": "input-text",
              "disabled": false,
              "defaultvisibility": true,
              "required": true,
              "gridsize": 375,
              "tooltip": "Enter the number in the format UDYAM-XX-00-000000. Include the prefix UDYAM and hyphen (-) as shown in the sample format."
            },
            { "field": "websiteurl", "text": "Website URL", "type": "input-text", "disabled": false, "defaultvisibility": true, "required": false, "gridsize": 375, /* "regex": "^(https?:\/\/)?(www\.)?([a-zA-Z0-9\-]+\.[a-zA-Z]{2,})(\/[^\s]*)?$"  */ },
            { "field": "twitter", "text": "Twitter", "type": "input-text", "disabled": false, "defaultvisibility": true, "required": false, "gridsize": 375, /* "regex": "^(https?:\/\/)?(www\.)?([a-zA-Z0-9\-]+\.[a-zA-Z]{2,})(\/[^\s]*)?$"  */ },
            { "field": "skypename", "text": "Skype Name/Number", "type": "input-text", "disabled": false, "defaultvisibility": true, "required": false, "gridsize": 375 },
            { "field": "facebook", "text": "Facebook", "type": "input-text", "disabled": false, "defaultvisibility": true, "required": false, "gridsize": 375, /* "regex": "^(https?:\/\/)?(www\.)?([a-zA-Z0-9\-]+\.[a-zA-Z]{2,})(\/[^\s]*)?$" */ }
          ]
        },
        {
          "tab": "Document",
          "formFields": [
            {
              "field": "documents",
              "text": "Document Name",
              "type": "multipleFilePickerfieldwithtitle",
              "disabled": false,
              'filetypes': [...Config.images, ...Config.pdfExtension, ...Config.docExtension],
              "defaultvisibility": true,
              "required": true,
              "gridsize": 375
            }
          ]
        }
      ]
    };
  }
}