import { Config } from '../../config/Init.js'
import mongoose from "mongoose"

export default class CustomerMaster {
  constructor() {
    // customer Overviews
    this._id
    this.dateformat = { type: Number, trim: true }
    this.timeformat = { type: Number, trim: true }
    this.firstname = { type: String, required: true, trim: true }
    this.middlename = { type: String, trim: true }
    this.lastname = { type: String, trim: true }
    this.personname = { type: String, trim: true }
    this.personemail = { type: String, trim: true }
    this.contact = { type: String,required:true, unique: [true, 'Contact already exists.'], trim: true }
    this.contact_countrycode = { type: String, trim: true }
    this.alternatecontact = { type: String, trim: true }
    this.alternatecontact_countrycode = { type: String, trim: true }
    this.profilepic = { type: Object, trim: true }
    this.genderid = { type: mongoose.Schema.Types.ObjectId, ref: "tblgendermaster" }
    this.gender = { type: String, trim: true }
    this.nationalityid = { type: mongoose.Schema.Types.ObjectId, ref: "tblnationalitymaster" }
    this.nationality = { type: String, trim: true }
    this.customertypeid = { type: mongoose.Schema.Types.ObjectId, ref: "tblcustomertypemaster" }
    this.customertype = { type: String, trim: true }
    this.committeedesignationid = { type: mongoose.Schema.Types.ObjectId, ref: "tblcommitteemembersmaster" }
    this.committeedesignation = { type: String, trim: true }
    this.dateofbirth = { type: Date, trim: true }
    this.addressline1 = { type: String, trim: true }
    this.addressline2 = { type: String, trim: true }
    this.countryid = { type: mongoose.Schema.Types.ObjectId, ref: "tblcountrymaster" }
    this.country = { type: String, trim: true }
    this.stateid = { type: mongoose.Schema.Types.ObjectId, ref: "tblstatemaster" }
    this.state = { type: String, trim: true }
    this.cityid = { type: mongoose.Schema.Types.ObjectId, ref: "tblcitymaster" }
    this.city = { type: String, trim: true }
    this.pincodeid = { type: mongoose.Schema.Types.ObjectId, ref: "tblpincodemaster" }
    this.pincode = { type: String, trim: true }
    this.emergencyname = { type: String, trim: true }
    this.emergencycontact = { type: String, trim: true }
    this.ownedproperties = [{
      propertyid: { type: mongoose.Schema.Types.ObjectId, ref: "tblpropertymaster" },
      property: { type: String },
      unitid: { type: mongoose.Schema.Types.ObjectId, ref: "tblpropertyunit" },
      unit: { type: String },
      wingid: { type: mongoose.Schema.Types.ObjectId, ref: "tblpropertywing" },
      wing: { type: String },
      floorid: { type: mongoose.Schema.Types.ObjectId, ref: "tblpropertyfloor" },
      floor: { type: String },
      customerid: { type: mongoose.Schema.Types.ObjectId, ref: "tblcustomer" },
      customer: { type: String }
    }]
    this.familymember = [
      {
        memberid: { type: mongoose.Schema.Types.ObjectId, ref: "tblcustomer" },
        firstname: { type: String, required: true },
        lastname: { type: String },
        personname: { type: String }
      }
    ]
    this.iskids = { type: Number, default: 0 },
      this.relationid = { type: mongoose.Schema.Types.ObjectId, ref: "tblrelationmaster" },
      this.relation = { type: String },
      this.isactive = { type: Number, default: 1 }
    this.isdelete = { type: Number, default: 0 }
    this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: "recordinfo" }
    this.userrole = [
      {
        userroleid: { type: mongoose.Schema.Types.ObjectId },
        userrole: { type: String }
      }
    ]
    // Documents   
    this.documents = [{
      doc: Config.getImageModel(),
      name: { type: String }
    }]
    // Invalid Login
    this.invalidlogincount = { type: Number, default: 0 }
    this.accountlocktime = { type: Date, default: null }
    // 2FA Configuration
    this.is2FAenable = { type: Number, default: 0 } // 2FA enable
    this.customertype = { type: Number, default: 0 } // 0-customer,1-familymember,2-tenant
    this.tenant = [
      {
        tenantid: { type: mongoose.Schema.Types.ObjectId, ref: "tbltenantmaster" },
        tenant: { type: String }
      }
    ]
    this.temp_2FA_secret = { type: String, default: "" }
    this.secret_2FA = { type: String, default: "" }
    this.recoverycodes = { type: Array, default: [] }
    this.isterminated = { type: Number, default: 0 } // 0 - not terminated  | 1 - terminated 
  }


  getDataName() {
    return "Customer"
  }


  getFieldOrder() {
    return {
      fields: [
        {
          "field": "action_button",
          "text": "",
          "type": "action_button",
          "freeze": 1,
          "active": 1,
          "sorttable": 0,
          "filter": 0,
          "disableflex": 1,
          "filterfieldtype": "lookup",
          "defaultvalue": "",
          "tblsize": 8
        },
        {
          "field": "isactive",
          "text": "Status",
          "type": "isactive",
          "freeze": 1,
          "active": 1,
          "sorttable": 0,
          "filter": 0,
          "disableflex": 1,
          "filterfieldtype": "lookup",
          "defaultvalue": "",
          "tblsize": 15
        },
        {
          "field": "personname",
          "text": "Full Name",
          'type': 'person-name',

          "freeze": 0,
          "active": 1,
          "sorttable": 1,
          "filter": 0,
          "filterfieldtype": "input-text",
          "masterdatafield": "personname",
          "formdatafield": "_id",
          "defaultvalue": []
        },
        {
          "field": "customertype",
          "text": "Customer Type",
          "type": "text",
          "freeze": 0,
          "active": 1,
          "sorttable": 1,
          "filter": 0,
          "filterfieldtype": "lookup",
          "defaultvalue": ""
        },
        {
          "field": "committeedesignation",
          "text": "Committee Designation",
          "type": "text",
          "freeze": 0,
          "active": 1,
          "sorttable": 1,
          "filter": 0,
          "filterfieldtype": "lookup",
          "defaultvalue": ""
        },
        {
          "field": "nationality",
          "text": "Nationality",
          "type": "text",
          "freeze": 0,
          "active": 1,
          "sorttable": 1,
          "filter": 0,
          "filterfieldtype": "lookup",
          "defaultvalue": ""
        },
        {
          "field": "contact",
          "text": "Mobile Number",
          "type": "text",
          "freeze": 0,
          "active": 1,
          "sorttable": 1,
          "filter": 0,
          "filterfieldtype": "lookup",
          "defaultvalue": ""
        },
        {
          "field": "alternatecontact",
          "text": "Phone Number",
          "type": "text",
          "freeze": 0,
          "active": 1,
          "sorttable": 1,
          "filter": 0,
          "filterfieldtype": "lookup",
          "defaultvalue": ""
        },
        {
          "field": "personemail",
          "text": "Email Address",
          "type": "text",
          "freeze": 0,
          "active": 1,
          "sorttable": 1,
          "filter": 0,
          "filterfieldtype": "lookup",
          "defaultvalue": ""
        },
        {
          "field": "wing",
          "text": "Wing",
          "type": "text-array",
          "isonlyfilter": 1,
          "freeze": 0,
          "active": 0,
          "sorttable": 0,
          "filter": 1,
          "filterfieldtype": "multipleselectdropdown",
          "filterfield": "wing",
          "masterdata": "property/wing",
          "masterdatafield": "wingname",
          "formdatafield": "wingid",
          "formdatafield": "wingid",
          "defaultvalue": [],
          "onchangefill": [
            "floor"
          ],
          "masterdatadependancy": false,
          "staticfilter": {
            "isactive": 1
          }
        },
        {
          "field": "floor",
          "text": "Floor",
          "type": "text-array",
          "isonlyfilter": 1,
          "freeze": 0,
          "active": 0,
          "sorttable": 0,
          "filter": 1,
          "filterfieldtype": "multipleselectdropdown",
          "filterfield": "floor",
          "masterdata": "property/floor",
          "masterdatafield": "floor",
          "formdatafield": "floorid",
          "defaultvalue": [],
          "onchangefill": [
            "unit"
          ],
          "dependentfilter": {
            "wingid": "wing.wingid"
          },
          "masterdatadependancy": true,
          "staticfilter": {
            "isactive": 1
          }
        },
        {
          "field": "unit",
          "text": "Unit",
          "type": "text-array",
          "isonlyfilter": 1,
          "freeze": 0,
          "active": 0,
          "sorttable": 0,
          "filter": 1,
          "filterfieldtype": "multipleselectdropdown",
          "filterfield": "unit",
          "masterdata": "property/unit",
          "masterdatafield": "unitname",
          "formdatafield": "unitid",
          "defaultvalue": [],
          "dependentfilter": {
            "wingid": "wing.wingid",
            "floorid": "floor.floorid"
          },
          "masterdatadependancy": true,
          "staticfilter": {
            "isactive": 1
          }
        },
        {
          "field": "property",
          "text": "Property Name",
          "type": "text",
          "freeze": 0,
          "active": 1,
          "sorttable": 1,
          "filter": 0,
          "filterfieldtype": "lookup",
          "defaultvalue": ""
        },
        {
          "field": "uniteno",
          "text": "Unit No",
          "type": "noticefor",
          "freeze": 0,
          "active": 1,
          "sorttable": 0,
          "sortby": "noticefor",
          "filter": 0,
          "tblsize": 60
        },
        {
          "field": "is2FAenable",
          "text": "2FA Enable",
          "type": "switch",
          "freeze": 0,
          "active": 1,
          "sorttable": 0,
          "filter": 0,
          "filterfieldtype": "dropdown",
          "formdatafield": "is2FAenable",
          "masterdataarray": [
            { "label": "Active", "value": 1 },
            { "label": "Inactive", "value": 0 }
          ],
          "defaultvalue": ""
        }
      ]
    }
  }

  getFormFieldOrder() {
    return {

      "rightsidebarsize": 1200,
      "pagename": "customer",
      "formname": "Customer",
      "alias": "customer",
      "dataview": "tab",
      "formfields": [
        {
          "tab": "Customer Details",
          "formFields": [
            { "field": "profilepic", "text": "Profile Picture", "type": "file", "filetypes": Config.images, "disabled": false, "defaultvisibility": true, "required": false, "gridsize": 375 },
            { "field": "firstname", "text": "First Name", "type": "input-text", "disabled": false, "capitalcase": true, "defaultvisibility": true, "required": true, "gridsize": 375 },
            { "field": "lastname", "text": "Last Name", "type": "input-text", "disabled": false, "capitalcase": true, "defaultvisibility": true, "required": true, "gridsize": 375 },
            { "field": "dateofbirth", "text": "DOB", "type": "datepicker", "disabled": false, "defaultvisibility": true, "required": true, "gridsize": 375 },
            {
              "field": "genderid",
              "text": "Gender",
              "type": "dropdown",
              "disabled": false,
              "defaultvisibility": true,
              "required": true,
              "gridsize": 375,
              "masterdata": "gender",
              "masterdataarray": [
                { "label": "Male", "value": "66a1e97c238fdcb94369331d" },
                { "label": "Female", "value": "66a1e97c238fdcb94369300d" },
                { "label": "Other", "value": "66a1e97c238fdcb94369130d" }
              ],
              "defaultvalue": "66a1e97c238fdcb94369331d",
              "masterdatafield": "label",
              "formdatafield": "gender",
              "cleanable": true,
              "searchable": true,
              "masterdatadependancy": false
            },
            {
              "field": "contact",
              "text": "Mobile Number",
              "type": "number-input",
              "disabled": false,
              "defaultvisibility": true,
              "prefixtext": "code",
              "required": true,
              "gridsize": 375
            },
            {
              "field": "alternatecontact",
              "text": "Phone Number",
              "type": "number-input",
              "disabled": false,
              "defaultvisibility": true,
              "prefixtext": "code",
              "required": false,
              "gridsize": 375
            },
            {
              "field": "personemail",
              "text": "Email Address",
              "type": "input-text",
              "disabled": false,
              "defaultvisibility": true,
              // "regex": "^(([^<>()[]\\.,;:s@\"]+(.[^<>()[]\\.,;:s@\"]+)*)|(\".+\"))@(([[0-9]{1,3}.[0-9]{1,3}.[0-9]{1,3}.[0-9]{1,3}])|(([a-zA-Z-0-9]+.)+[a-zA-Z]{2,}))",
              "required": false,
              "gridsize": 375,
              "regxtype": "email"
            },
            {
              "field": "nationalityid",
              "text": "Nationality",
              "type": "dropdown",
              "disabled": false,
              "defaultvisibility": true,
              "required": true,
              "gridsize": 375,
              "masterdata": "nationality",
              "masterdatafield": "nationality",
              "formdatafield": "nationality",
              "cleanable": true,
              "searchable": true,
              "masterdatadependancy": false,
              "defaultvalue": "67382488171652f20e1a0754",
              "staticfilter": { "isactive": 1 }
            },
            // {
            //   "field": "customertypeid",
            //   "text": "Customer Type",
            //   "type": "dropdown",
            //   "disabled": false,
            //   "defaultvisibility": true,
            //   "required": true,
            //   "gridsize": 375,
            //   "masterdata": "customertype",
            //   "masterdatafield": "customertype",
            //   "formdatafield": "customertype",
            //   "cleanable": true,
            //   "searchable": true,
            //   "masterdatadependancy": false,
            //   "defaultvalue": "673830ca3a0b1ff806822310",
            //   "staticfilter": {"isactive": 1}
            // },
            // {"field": "currentaddress", "text": "Area, Landmark", "type": "input-textarea", "disabled": false, "defaultvisibility": true, "required": true, "gridsize": 375},
            {
              "field": "addressline1",
              "text": "Flat, House no., Building, Street",
              "type": "input-text",
              "disabled": false,
              "defaultvisibility": true,
              "required": true,
              "gridsize": 375
            },
            {
              "field": "addressline2",
              "text": "Area, Landmark",
              "type": "input-text",
              "disabled": false,
              "defaultvisibility": true,
              "required": true,
              "gridsize": 375
            },
            { "field": "pincode", "text": "Pincode", "type": "number-input", "disabled": false, "defaultvisibility": true, "required": true, "gridsize": 375 },

            {
              "field": "countryid",
              "text": "Country",
              "type": "dropdown",
              "disabled": false,
              "defaultvisibility": true,
              "required": true,
              "gridsize": 375,
              "masterdata": "country",
              "masterdatafield": "country",
              "formdatafield": "country",
              "cleanable": true,
              "searchable": true,
              "onchangefill": ['stateid'],
              "masterdatadependancy": false,
              "defaultvalue": "670fac1d244906d4e2dc7308",
              "staticfilter": { "isactive": 1 }
            },
            {
              "field": "stateid",
              "text": "State",
              "type": "dropdown",
              "disabled": false,
              "defaultvisibility": true,
              "required": true,
              "gridsize": 375,
              "masterdata": "state",
              "masterdatafield": "state",
              "formdatafield": "state",
              "cleanable": true,
              "searchable": true,
              "onchangefill": ['cityid'],
              "masterdatadependancy": true,
              "dependentfilter": { "countryid": "countryid" },
              "defaultvalue": "66acd3cb6a781176246a9637",
              "staticfilter": { "isactive": 1 }
            },
            {
              "field": "cityid",
              "text": "City",
              "type": "dropdown",
              "disabled": false,
              "defaultvisibility": true,
              "required": true,
              "gridsize": 375,
              "masterdata": "city",
              "masterdatafield": "city",
              "formdatafield": "city",
              "cleanable": true,
              "searchable": true,
              'dependentfilter': {
                'stateid': 'stateid',
              },
              "masterdatadependancy": true,
              "defaultvalue": "6710b1a7d57b9665bf472274",
              "staticfilter": { "isactive": 1 }
            },
            {
              "field": "committeedesignationid",
              "text": "Committee Designation",
              "type": "dropdown",
              "disabled": false,
              "defaultvisibility": true,
              "required": false,
              "gridsize": 375,
              "masterdata": "committeemembers",
              "masterdatafield": "committeemembers",
              "formdatafield": "committeedesignation",
              "cleanable": true,
              "searchable": true,
              "masterdatadependancy": false,
              "staticfilter": { "isactive": 1 }
            },
          ]
        },
        {
          "tab": "Property Assign",
          "allowmultipleentries": true,
          "tabid": "ownedproperties",
          "uniquekey": "unitid",
          "required": true,
          "formFields": [
            {
              "field": "propertyid",
              "text": "Property",
              "type": "dropdown",
              "disabled": false,
              "defaultvisibility": true,
              "required": true,
              "gridsize": 375,
              "masterdata": "property",
              "masterdatafield": "propertyname",
              "formdatafield": "property",
              "cleanable": true,
              "searchable": true,
              "onchangefill": ["wingid"],
              "masterdatadependancy": false,
              "staticfilter": { "isactive": 1 }
            },
            {
              "field": "wingid",
              "text": "Wing",
              "type": "dropdown",
              "disabled": false,
              "defaultvisibility": true,
              "required": true,
              "gridsize": 375,
              "masterdata": "property/wing",
              "masterdatafield": "wingname",
              "formdatafield": "wing",
              "cleanable": true,
              "searchable": true,
              "dependentfilter": { "propertyid": "propertyid" },
              "onchangefill": ["floorid"],
              "masterdatadependancy": true,
              "staticfilter": { "isactive": 1 }
            },
            {
              "field": "floorid",
              "text": "Floor",
              "type": "dropdown",
              "disabled": false,
              "defaultvisibility": true,
              "required": true,
              "gridsize": 375,
              "masterdata": "property/floor",
              "masterdatafield": "floor",
              "formdatafield": "floor",
              "cleanable": true,
              "searchable": true,
              "onchangefill": ["unitid"],
              "dependentfilter": { "wingid": "wingid" },
              "masterdatadependancy": true,
              "staticfilter": { "isactive": 1 },
            },
            {
              "field": "unitid",
              "text": "Unit",
              "type": "dropdown",
              "disabled": false,
              "defaultvisibility": true,
              "required": true,
              "gridsize": 375,
              "masterdata": "property/unit",
              "masterdatafield": "unitname",
              "formdatafield": "unit",
              "cleanable": true,
              "searchable": true,
              "dependentfilter": { "wingid": "wingid", "floorid": "floorid" },
              "masterdatadependancy": true,
              "staticfilter": { "isactive": 1 },
            },
          ]
        },
        {
          "tab": "Documents",
          "allowmultipleentries": false,
          "tabid": "ownedproperties",
          "uniquekey": "unitid",
          "required": false,
          "formFields": [
            {
              "field": "documents",
              "text": "Document Name",
              "type": "multipleFilePickerfieldwithtitle",
              "disabled": false,
              'filetypes': [...Config.images, ...Config.pdfExtension, ...Config.docExtension],
              "defaultvisibility": true,
              "required": true,
              "gridsize": 375,
            }
          ],
        },
      ]
    }
  }



  getTenantFieldOrder() {
    return {
      fields: [
        {
          "field": "action_button",
          "text": "",
          "type": "action_button",
          "freeze": 1,
          "active": 1,
          "sorttable": 0,
          "filter": 0,
          "disableflex": 1,
          "filterfieldtype": "lookup",
          "defaultvalue": "",
          "tblsize": 8
        },
        {
          "field": "isactive",
          "text": "Status",
          "type": "isactive",
          "freeze": 1,
          "active": 1,
          "sorttable": 0,
          "filter": 0,
          "disableflex": 1,
          "filterfieldtype": "lookup",
          "defaultvalue": "",
          "tblsize": 15
        },
        {
          "field": "personname",
          "text": "Full Name",
          'type': 'person-name',

          "freeze": 0,
          "active": 1,
          "sorttable": 1,
          "filter": 0,
          "filterfieldtype": "input-text",
          "masterdatafield": "personname",
          "formdatafield": "_id",
          "defaultvalue": []
        },
        // {
        //   "field": "customertype",
        //   "text": "Customer Type",
        //   "type": "text",
        //   "freeze": 0,
        //   "active": 1,
        //   "sorttable": 1,
        //   "filter": 0,
        //   "filterfieldtype": "lookup",
        //   "defaultvalue": ""
        // },
        // {
        //   "field": "committeedesignation",
        //   "text": "Committee Designation",
        //   "type": "text",
        //   "freeze": 0,
        //   "active": 1,
        //   "sorttable": 1,
        //   "filter": 0,
        //   "filterfieldtype": "lookup",
        //   "defaultvalue": ""
        // },

        {
          "field": "gender",
          "text": "Gender",
          "type": "text",
          "freeze": 0,
          "active": 1,
          "sorttable": 1,
          "filter": 0,
          "filterfieldtype": "lookup",
          "defaultvalue": ""
        },
        {
          "field": "contact",
          "text": "Mobile Number",
          "type": "text",
          "freeze": 0,
          "active": 1,
          "sorttable": 1,
          "filter": 0,
          "filterfieldtype": "lookup",
          "defaultvalue": ""
        },
        {
          "field": "alternatecontact",
          "text": "Phone Number",
          "type": "text",
          "freeze": 0,
          "active": 1,
          "sorttable": 1,
          "filter": 0,
          "filterfieldtype": "lookup",
          "defaultvalue": ""
        },
        {
          "field": "personemail",
          "text": "Email Address",
          "type": "text",
          "freeze": 0,
          "active": 1,
          "sorttable": 1,
          "filter": 0,
          "filterfieldtype": "lookup",
          "defaultvalue": ""
        },
        {
          "field": "dateofbirth",
          "text": "Date of Birth",
          "type": "text",
          "freeze": 0,
          "active": 1,
          "sorttable": 1,
          "filter": 0,
          "filterfieldtype": "lookup",
          "defaultvalue": ""
        },
        {
          "field": "nationality",
          "text": "Nationality",
          "type": "text",
          "freeze": 0,
          "active": 1,
          "sorttable": 1,
          "filter": 0,
          "filterfieldtype": "lookup",
          "defaultvalue": ""
        },
        {
          "field": "wing",
          "text": "Wing",
          "type": "text-array",
          "isonlyfilter": 1,
          "freeze": 0,
          "active": 0,
          "sorttable": 0,
          "filter": 1,
          "filterfieldtype": "multipleselectdropdown",
          "filterfield": "wing",
          "masterdata": "property/wing",
          "masterdatafield": "wingname",
          "formdatafield": "wingid",
          "defaultvalue": [],
          "onchangefill": [
            "floor"
          ],
          "masterdatadependancy": false,
          "staticfilter": {
            "isactive": 1
          }
        },
        {
          "field": "floor",
          "text": "Floor",
          "type": "text-array",
          "isonlyfilter": 1,
          "freeze": 0,
          "active": 0,
          "sorttable": 0,
          "filter": 1,
          "filterfieldtype": "multipleselectdropdown",
          "filterfield": "floor",
          "masterdata": "property/floor",
          "masterdatafield": "floor",
          "formdatafield": "floorid",
          "defaultvalue": [],
          "onchangefill": [
            "unit"
          ],
          "dependentfilter": {
            "wingid": "wing.wingid"
          },
          "masterdatadependancy": true,
          "staticfilter": {
            "isactive": 1
          }
        },
        {
          "field": "unit",
          "text": "Unit",
          "type": "text-array",
          "isonlyfilter": 1,
          "freeze": 0,
          "active": 0,
          "sorttable": 0,
          "filter": 1,
          "filterfieldtype": "multipleselectdropdown",
          "filterfield": "unit",
          "masterdata": "property/unit",
          "masterdatafield": "unitname",
          "formdatafield": "unitid",
          "defaultvalue": [],
          "dependentfilter": {
            "wingid": "wing.wingid",
            "floorid": "floor.floorid"
          },
          "masterdatadependancy": true,
          "staticfilter": {
            "isactive": 1
          }
        },
        // {
        //   "field": "property",
        //   "text": "Property Name",
        //   "type": "text",
        //   "freeze": 0,
        //   "active": 1,
        //   "sorttable": 1,
        //   "filter": 0,
        //   "filterfieldtype": "lookup",
        //   "defaultvalue": ""
        // },
        // {
        //   "field": "uniteno",
        //   "text": "Unit No",
        //   "type": "noticefor",
        //   "freeze": 0,
        //   "active": 1,
        //   "sorttable": 0,
        //   "sortby": "noticefor",
        //   "filter": 0,
        //   "tblsize": 60
        // },
        // {
        //   "field": "is2FAenable",
        //   "text": "2FA Enable",
        //   "type": "switch",
        //   "freeze": 0,
        //   "active": 1,
        //   "sorttable": 0,
        //   "filter": 0,
        //   "filterfieldtype": "dropdown",
        //   "formdatafield": "is2FAenable",
        //   "masterdataarray": [
        //     { "label": "Active", "value": 1 },
        //     { "label": "Inactive", "value": 0 }
        //   ],
        //   "defaultvalue": ""
        // }
      ]
    }
    // return {

    //   "rightsidebarsize": 1200,
    //   "pagename": "customer",
    //   "formname": "Customer",
    //   "alias": "customer",
    //   "dataview": "tab",
    //   "formfields": [
    //     {
    //       "tab": "Customer Details",
    //       "formFields": [
    //         { "field": "firstname", "text": "First Name", "type": "input-text", "disabled": false, "capitalcase": true, "defaultvisibility": true, "required": true, "gridsize": 375 },
    //         { "field": "lastname", "text": "Last Name", "type": "input-text", "disabled": false, "capitalcase": true, "defaultvisibility": true, "required": true, "gridsize": 375 },
    //         { "field": "dateofbirth", "text": "DOB", "type": "datepicker", "disabled": false, "defaultvisibility": true, "required": true, "gridsize": 375 },
    //         {
    //           "field": "genderid",
    //           "text": "Gender",
    //           "type": "dropdown",
    //           "disabled": false,
    //           "defaultvisibility": true,
    //           "required": true,
    //           "gridsize": 375,
    //           "masterdata": "gender",
    //           "masterdataarray": [
    //             { "label": "Male", "value": "66a1e97c238fdcb94369331d" },
    //             { "label": "Female", "value": "66a1e97c238fdcb94369300d" },
    //             { "label": "Other", "value": "66a1e97c238fdcb94369130d" }
    //           ],
    //           "defaultvalue": "66a1e97c238fdcb94369331d",
    //           "masterdatafield": "label",
    //           "formdatafield": "gender",
    //           "cleanable": true,
    //           "searchable": true,
    //           "masterdatadependancy": false
    //         },
    //         {
    //           "field": "contact",
    //           "text": "Mobile Number",
    //           "type": "number-input",
    //           "disabled": false,
    //           "defaultvisibility": true,
    //           "prefixtext": "code",
    //           "required": true,
    //           "gridsize": 375
    //         },
    //         {
    //           "field": "alternatecontact",
    //           "text": "Phone Number",
    //           "type": "number-input",
    //           "disabled": false,
    //           "defaultvisibility": true,
    //           "prefixtext": "code",
    //           "required": false,
    //           "gridsize": 375
    //         },
    //         {
    //           "field": "personemail",
    //           "text": "Email Address",
    //           "type": "input-text",
    //           "disabled": false,
    //           "defaultvisibility": true,
    //           // "regex": "^(([^<>()[]\\.,;:s@\"]+(.[^<>()[]\\.,;:s@\"]+)*)|(\".+\"))@(([[0-9]{1,3}.[0-9]{1,3}.[0-9]{1,3}.[0-9]{1,3}])|(([a-zA-Z-0-9]+.)+[a-zA-Z]{2,}))",
    //           "required": false,
    //           "gridsize": 375,
    //           "regxtype": "email"
    //         },
    //         {
    //           "field": "nationalityid",
    //           "text": "Nationality",
    //           "type": "dropdown",
    //           "disabled": false,
    //           "defaultvisibility": true,
    //           "required": true,
    //           "gridsize": 375,
    //           "masterdata": "nationality",
    //           "masterdatafield": "nationality",
    //           "formdatafield": "nationality",
    //           "cleanable": true,
    //           "searchable": true,
    //           "masterdatadependancy": false,
    //           "defaultvalue": "67382488171652f20e1a0754",
    //           "staticfilter": { "isactive": 1 }
    //         },
    //         // {
    //         //   "field": "customertypeid",
    //         //   "text": "Customer Type",
    //         //   "type": "dropdown",
    //         //   "disabled": false,
    //         //   "defaultvisibility": true,
    //         //   "required": true,
    //         //   "gridsize": 375,
    //         //   "masterdata": "customertype",
    //         //   "masterdatafield": "customertype",
    //         //   "formdatafield": "customertype",
    //         //   "cleanable": true,
    //         //   "searchable": true,
    //         //   "masterdatadependancy": false,
    //         //   "defaultvalue": "673830ca3a0b1ff806822310",
    //         //   "staticfilter": {"isactive": 1}
    //         // },
    //         // {"field": "currentaddress", "text": "Area, Landmark", "type": "input-textarea", "disabled": false, "defaultvisibility": true, "required": true, "gridsize": 375},
    //         {
    //           "field": "addressline1",
    //           "text": "Flat, House no., Building, Street",
    //           "type": "input-text",
    //           "disabled": false,
    //           "defaultvisibility": true,
    //           "required": true,
    //           "gridsize": 375
    //         },
    //         {
    //           "field": "addressline2",
    //           "text": "Area, Landmark",
    //           "type": "input-text",
    //           "disabled": false,
    //           "defaultvisibility": true,
    //           "required": true,
    //           "gridsize": 375
    //         },
    //         { "field": "pincode", "text": "Pincode", "type": "number-input", "disabled": false, "defaultvisibility": true, "required": true, "gridsize": 375 },

    //         {
    //           "field": "countryid",
    //           "text": "Country",
    //           "type": "dropdown",
    //           "disabled": false,
    //           "defaultvisibility": true,
    //           "required": true,
    //           "gridsize": 375,
    //           "masterdata": "country",
    //           "masterdatafield": "country",
    //           "formdatafield": "country",
    //           "cleanable": true,
    //           "searchable": true,
    //           "onchangefill": ['stateid'],
    //           "masterdatadependancy": false,
    //           "defaultvalue": "670fac1d244906d4e2dc7308",
    //           "staticfilter": { "isactive": 1 }
    //         },
    //         {
    //           "field": "stateid",
    //           "text": "State",
    //           "type": "dropdown",
    //           "disabled": false,
    //           "defaultvisibility": true,
    //           "required": true,
    //           "gridsize": 375,
    //           "masterdata": "state",
    //           "masterdatafield": "state",
    //           "formdatafield": "state",
    //           "cleanable": true,
    //           "searchable": true,
    //           "onchangefill": ['cityid'],
    //           "masterdatadependancy": true,
    //           "dependentfilter": { "countryid": "countryid" },
    //           "defaultvalue": "66acd3cb6a781176246a9637",
    //           "staticfilter": { "isactive": 1 }
    //         },
    //         {
    //           "field": "cityid",
    //           "text": "City",
    //           "type": "dropdown",
    //           "disabled": false,
    //           "defaultvisibility": true,
    //           "required": true,
    //           "gridsize": 375,
    //           "masterdata": "city",
    //           "masterdatafield": "city",
    //           "formdatafield": "city",
    //           "cleanable": true,
    //           "searchable": true,
    //           'dependentfilter': {
    //             'stateid': 'stateid',
    //           },
    //           "masterdatadependancy": true,
    //           "defaultvalue": "6710b1a7d57b9665bf472274",
    //           "staticfilter": { "isactive": 1 }
    //         },
    //         {
    //           "field": "committeedesignationid",
    //           "text": "Committee Designation",
    //           "type": "dropdown",
    //           "disabled": false,
    //           "defaultvisibility": true,
    //           "required": false,
    //           "gridsize": 375,
    //           "masterdata": "committeemembers",
    //           "masterdatafield": "committeemembers",
    //           "formdatafield": "committeedesignation",
    //           "cleanable": true,
    //           "searchable": true,
    //           "masterdatadependancy": false,
    //           "staticfilter": { "isactive": 1 }
    //         },
    //       ]
    //     },
    //     {
    //       "tab": "Property Assign",
    //       "allowmultipleentries": true,
    //       "tabid": "ownedproperties",
    //       "uniquekey": "unitid",
    //       "required": true,
    //       "formFields": [
    //         {
    //           "field": "propertyid",
    //           "text": "Property",
    //           "type": "dropdown",
    //           "disabled": false,
    //           "defaultvisibility": true,
    //           "required": true,
    //           "gridsize": 375,
    //           "masterdata": "property",
    //           "masterdatafield": "propertyname",
    //           "formdatafield": "property",
    //           "cleanable": true,
    //           "searchable": true,
    //           "onchangefill": ["wingid"],
    //           "masterdatadependancy": false,
    //           "staticfilter": { "isactive": 1 }
    //         },
    //         {
    //           "field": "wingid",
    //           "text": "Wing",
    //           "type": "dropdown",
    //           "disabled": false,
    //           "defaultvisibility": true,
    //           "required": true,
    //           "gridsize": 375,
    //           "masterdata": "property/wing",
    //           "masterdatafield": "wingname",
    //           "formdatafield": "wing",
    //           "cleanable": true,
    //           "searchable": true,
    //           "dependentfilter": { "propertyid": "propertyid" },
    //           "onchangefill": ["floorid"],
    //           "masterdatadependancy": true,
    //           "staticfilter": { "isactive": 1 }
    //         },
    //         {
    //           "field": "floorid",
    //           "text": "Floor",
    //           "type": "dropdown",
    //           "disabled": false,
    //           "defaultvisibility": true,
    //           "required": true,
    //           "gridsize": 375,
    //           "masterdata": "property/floor",
    //           "masterdatafield": "floor",
    //           "formdatafield": "floor",
    //           "cleanable": true,
    //           "searchable": true,
    //           "onchangefill": ["unitid"],
    //           "dependentfilter": { "wingid": "wingid" },
    //           "masterdatadependancy": true,
    //           "staticfilter": { "isactive": 1 },
    //         },
    //         {
    //           "field": "unitid",
    //           "text": "Unit",
    //           "type": "dropdown",
    //           "disabled": false,
    //           "defaultvisibility": true,
    //           "required": true,
    //           "gridsize": 375,
    //           "masterdata": "property/unit",
    //           "masterdatafield": "unitname",
    //           "formdatafield": "unit",
    //           "cleanable": true,
    //           "searchable": true,
    //           "dependentfilter": { "wingid": "wingid", "floorid": "floorid" },
    //           "masterdatadependancy": true,
    //           "staticfilter": { "isactive": 1 },
    //         },
    //       ]
    //     },
    //   ]
    // }

    // return {
    //   fields: [
    //     {
    //       "field": "action_button",
    //       "text": "",
    //       "type": "action_button",
    //       "freeze": 1,
    //       "active": 1,
    //       "sorttable": 0,
    //       "filter": 0,
    //       "disableflex": 1,
    //       "filterfieldtype": "lookup",
    //       "defaultvalue": "",
    //       "tblsize": 8
    //     },
    //     {
    //       "field": "isactive",
    //       "text": "Status",
    //       "type": "isactive",
    //       "freeze": 1,
    //       "active": 1,
    //       "sorttable": 0,
    //       "filter": 0,
    //       "disableflex": 1,
    //       "filterfieldtype": "lookup",
    //       "defaultvalue": "",
    //       "tblsize": 15
    //     },
    //     {
    //       "field": "customer",
    //       "text": "Customer Name",
    //       "type": "text",
    //       "freeze": 0,
    //       "active": 1,
    //       "sorttable": 1,
    //       "filter": 0,
    //       'sortby': 'customer',
    //       "filterfieldtype": "input-text",
    //       "masterdatafield": "customer",
    //       "tblsize": 18.33,
    //     },
    //     {
    //       "field": "unit",
    //       "text": "Flat",
    //       "type": "text",
    //       "freeze": 0,
    //       "active": 1,
    //       "sorttable": 1,
    //       'sortby': 'flat',
    //       "filter": 0,
    //       "filterfieldtype": "lookup",
    //       "tblsize": 18.33,
    //       "defaultvalue": ""
    //     },
    //     {
    //       "field": "personname",
    //       "text": "Tenant Name",
    //       "type": "text",
    //       "freeze": 0,
    //       "active": 1,
    //       "sorttable": 1,
    //       'sortby': 'tenantname',
    //       "filter": 0,
    //       "filterfieldtype": "lookup",
    //       "tblsize": 18.33,
    //       "defaultvalue": ""
    //     },
    //     {
    //       "field": "dateofbirth",
    //       "text": "DOB",
    //       "type": "text",
    //       "freeze": 0,
    //       "active": 1,
    //       "sorttable": 0,
    //       'sortby': 'dateofbirth',
    //       "filter": 0,
    //       "filterfieldtype": "lookup",
    //       "tblsize": 18.33,
    //       "defaultvalue": ""
    //     },
    //     {
    //       "field": "gender",
    //       "text": "Gender",
    //       "type": "text",
    //       "freeze": 0,
    //       "active": 1,
    //       "sorttable": 1,
    //       'sortby': 'gender',
    //       "filter": 0,
    //       "filterfieldtype": "lookup",
    //       "tblsize": 18.33,
    //       "defaultvalue": ""
    //     },
    //     {
    //       "field": "contact",
    //       "text": "Mobile No.",
    //       "type": "text",
    //       "freeze": 0,
    //       "active": 1,
    //       "sorttable": 0,
    //       'sortby': 'mobileno',
    //       "filter": 0,
    //       "filterfieldtype": "lookup",
    //       "tblsize": 18.33,
    //       "defaultvalue": ""
    //     },
    //     {
    //       "field": "alternatecontact",
    //       "text": "Phone No.",
    //       "type": "text",
    //       "freeze": 0,
    //       "active": 1,
    //       "sorttable": 0,
    //       'sortby': 'phoneno',
    //       "filter": 0,
    //       "filterfieldtype": "lookup",
    //       "tblsize": 18.33,
    //       "defaultvalue": ""
    //     },
    //     {
    //       "field": "personemail",
    //       "text": "Email",
    //       "type": "text",
    //       "freeze": 0,
    //       "active": 1,
    //       "sorttable": 1,
    //       'sortby': 'email',
    //       "filter": 0,
    //       "filterfieldtype": "lookup",
    //       "tblsize": 18.33,
    //       "defaultvalue": ""
    //     },
    //     {
    //       "field": "nationality",
    //       "text": "Nationality",
    //       "type": "text",
    //       "freeze": 0,
    //       "active": 1,
    //       "sorttable": 1,
    //       'sortby': 'nationality',
    //       "filter": 0,
    //       "filterfieldtype": "lookup",
    //       "tblsize": 18.33,
    //       "defaultvalue": ""
    //     },
    //     {
    //       "field": "wing",
    //       "text": "Wing",
    //       "type": "text-array",
    //       "isonlyfilter": 1,
    //       "freeze": 0,
    //       "active": 0,
    //       "sorttable": 0,
    //       "filter": 1,
    //       "filterfieldtype": "multipleselectdropdown",
    //       "filterfield": "wing",
    //       "masterdata": "property/wing",
    //       "masterdatafield": "wingname",
    //       "formdatafield": "wingid",
    //       "defaultvalue": [],
    //       "onchangefill": [
    //         "floor"
    //       ],
    //       "masterdatadependancy": false,
    //       "staticfilter": {
    //         "isactive": 1
    //       }
    //     },
    //     {
    //       "field": "floor",
    //       "text": "Floor",
    //       "type": "text-array",
    //       "isonlyfilter": 1,
    //       "freeze": 0,
    //       "active": 0,
    //       "sorttable": 0,
    //       "filter": 1,
    //       "filterfieldtype": "multipleselectdropdown",
    //       "filterfield": "floor",
    //       "masterdata": "property/floor",
    //       "masterdatafield": "floor",
    //       "formdatafield": "floorid",
    //       "defaultvalue": [],
    //       "onchangefill": [
    //         "unit"
    //       ],
    //       "dependentfilter": {
    //         "wingid": "wing.wingid"
    //       },
    //       "masterdatadependancy": true,
    //       "staticfilter": {
    //         "isactive": 1
    //       }
    //     },
    //     {
    //       "field": "unit",
    //       "text": "Unit",
    //       "type": "text-array",
    //       "isonlyfilter": 1,
    //       "freeze": 0,
    //       "active": 0,
    //       "sorttable": 0,
    //       "filter": 1,
    //       "filterfieldtype": "multipleselectdropdown",
    //       "filterfield": "unit",
    //       "masterdata": "property/unit",
    //       "masterdatafield": "unitname",
    //       "formdatafield": "unitid",
    //       "defaultvalue": [],
    //       "dependentfilter": {
    //         "wingid": "wing.wingid",
    //         "floorid": "floor.floorid"
    //       },
    //       "masterdatadependancy": true,
    //       "staticfilter": {
    //         "isactive": 1
    //       }
    //     },
    //   ]
    // }
  }

  getTenantFormFieldOrder() {
    return {
      "rightsidebarsize": 1200,
      "pagename": "customer",
      "formname": "Tenant",
      "alias": "customer",
      "dataview": "tab",
      "formfields": [
        {
          "tab": "Tenant Details",
          "formFields": [
            { "field": "firstname", "text": "First Name", "type": "input-text", "disabled": false, "capitalcase": true, "defaultvisibility": true, "required": true, "gridsize": 375 },
            { "field": "lastname", "text": "Last Name", "type": "input-text", "disabled": false, "capitalcase": true, "defaultvisibility": true, "required": true, "gridsize": 375 },
            { "field": "dateofbirth", "text": "DOB", "type": "datepicker", "disabled": false, "defaultvisibility": true, "required": true, "gridsize": 375 },
            {
              "field": "genderid",
              "text": "Gender",
              "type": "dropdown",
              "disabled": false,
              "defaultvisibility": true,
              "required": true,
              "gridsize": 375,
              "masterdata": "gender",
              "masterdataarray": [
                { "label": "Male", "value": "66a1e97c238fdcb94369331d" },
                { "label": "Female", "value": "66a1e97c238fdcb94369300d" },
                { "label": "Other", "value": "66a1e97c238fdcb94369130d" }
              ],
              "defaultvalue": "66a1e97c238fdcb94369331d",
              "masterdatafield": "label",
              "formdatafield": "gender",
              "cleanable": true,
              "searchable": true,
              "masterdatadependancy": false
            },
            { "field": "contact", "text": "Mobile Number", "type": "number-input", "disabled": false, "defaultvisibility": true, "prefixtext": "code", "required": true, "gridsize": 375 },
            { "field": "alternatecontact", "text": "Phone Number", "type": "number-input", "disabled": false, "defaultvisibility": true, "prefixtext": "code", "required": false, "gridsize": 375 },
            {
              "field": "personemail",
              "text": "Email Address",
              "type": "input-text",
              "disabled": false,
              "defaultvisibility": true,
              // "regex": "^(([^<>()[]\\.,;:s@\"]+(.[^<>()[]\\.,;:s@\"]+)*)|(\".+\"))@(([[0-9]{1,3}.[0-9]{1,3}.[0-9]{1,3}.[0-9]{1,3}])|(([a-zA-Z-0-9]+.)+[a-zA-Z]{2,}))",
              "required": false,
              "gridsize": 375,
              "regxtype": "email"
            },
            {
              "field": "nationalityid",
              "text": "Nationality",
              "type": "dropdown",
              "disabled": false,
              "defaultvisibility": true,
              "required": true,
              "gridsize": 375,
              "masterdata": "nationality",
              "masterdatafield": "nationality",
              "formdatafield": "nationality",
              "cleanable": true,
              "searchable": true,
              "masterdatadependancy": false,
              "defaultvalue": "67382488171652f20e1a0754",
              "staticfilter": { "isactive": 1 }
            },
            // {
            //   "field": "customertypeid",
            //   "text": "Customer Type",
            //   "type": "dropdown",
            //   "disabled": false,
            //   "defaultvisibility": true,
            //   "required": true,
            //   "gridsize": 375,
            //   "masterdata": "customertype",
            //   "masterdatafield": "customertype",
            //   "formdatafield": "customertype",
            //   "cleanable": true,
            //   "searchable": true,
            //   "masterdatadependancy": false,
            //   "defaultvalue": "673830ca3a0b1ff806822310",
            //   "staticfilter": {"isactive": 1}
            // },
            // {"field": "currentaddress", "text": "Area, Landmark", "type": "input-textarea", "disabled": false, "defaultvisibility": true, "required": true, "gridsize": 375},
            { "field": "addressline1", "text": "Flat, House no., Building, Street", "type": "input-text", "disabled": false, "defaultvisibility": true, "required": true, "gridsize": 375 },
            { "field": "addressline2", "text": "Area, Landmark", "type": "input-text", "disabled": false, "defaultvisibility": true, "required": true, "gridsize": 375 },
            { "field": "pincode", "text": "Pincode", "type": "number-input", "disabled": false, "defaultvisibility": true, "required": true, "gridsize": 375 },

            {
              "field": "countryid",
              "text": "Country",
              "type": "dropdown",
              "disabled": false,
              "defaultvisibility": true,
              "required": true,
              "gridsize": 375,
              "masterdata": "country",
              "masterdatafield": "country",
              "formdatafield": "country",
              "cleanable": true,
              "searchable": true,
              "onchangefill": ['stateid'],
              "masterdatadependancy": false,
              "defaultvalue": "670fac1d244906d4e2dc7308",
              "staticfilter": { "isactive": 1 }
            },
            {
              "field": "stateid",
              "text": "State",
              "type": "dropdown",
              "disabled": false,
              "defaultvisibility": true,
              "required": true,
              "gridsize": 375,
              "masterdata": "state",
              "masterdatafield": "state",
              "formdatafield": "state",
              "cleanable": true,
              "searchable": true,
              "onchangefill": ['cityid'],
              "masterdatadependancy": true,
              "dependentfilter": { "countryid": "countryid" },
              "defaultvalue": "66acd3cb6a781176246a9637",
              "staticfilter": { "isactive": 1 }
            },
            {
              "field": "cityid",
              "text": "City",
              "type": "dropdown",
              "disabled": false,
              "defaultvisibility": true,
              "required": true,
              "gridsize": 375,
              "masterdata": "city",
              "masterdatafield": "city",
              "formdatafield": "city",
              "cleanable": true,
              "searchable": true,
              'dependentfilter': {
                'stateid': 'stateid',
              },
              "masterdatadependancy": true,
              "defaultvalue": "6710b1a7d57b9665bf472274",
              "staticfilter": { "isactive": 1 }
            },
            { "field": "profilepic", "text": "Profile Picture", "type": "file", "filetypes": Config.images, "disabled": false, "defaultvisibility": true, "required": false, "gridsize": 375 }
          ]
        },
        {
          "tab": "Property Assign",
          "allowmultipleentries": true,
          "tabid": "ownedproperties",
          "uniquekey": "unitid",
          "required": true,
          "formFields": [
            {
              "field": "customerid",
              "text": "Customer",
              "type": "dropdown",
              "disabled": false,
              "defaultvisibility": true,
              "required": true,
              "gridsize": 375,
              "masterdata": "customer",
              "masterdatafield": "personname",
              "formdatafield": "customer",
              "cleanable": true,
              "searchable": true,
              "onchangefill": ["unitid"],
              "masterdatadependancy": false,
              "staticfilter": { "isactive": 1 }
            },
            // {
            //   "field": "wingid",
            //   "text": "Wing",
            //   "type": "dropdown",
            //   "disabled": false,
            //   "defaultvisibility": true,
            //   "required": true,
            //   "gridsize": 375,
            //   "masterdata": "property/wing",
            //   "masterdatafield": "wingname",
            //   "formdatafield": "wing",
            //   "cleanable": true,
            //   "searchable": true,
            //   "dependentfilter": { "propertyid": "propertyid" },
            //   "onchangefill": ["floorid"],
            //   "masterdatadependancy": true,
            //   "staticfilter": { "isactive": 1 }
            // },
            // {
            //   "field": "floorid",
            //   "text": "Floor",
            //   "type": "dropdown",
            //   "disabled": false,
            //   "defaultvisibility": true,
            //   "required": true,
            //   "gridsize": 375,
            //   "masterdata": "property/floor",
            //   "masterdatafield": "floor",
            //   "formdatafield": "floor",
            //   "cleanable": true,
            //   "searchable": true,
            //   "onchangefill": ["unitid"],
            //   "dependentfilter": { "wingid": "wingid" },
            //   "masterdatadependancy": true,
            //   "staticfilter": { "isactive": 1 },
            // },
            {
              "field": "unitid",
              "text": "Unit",
              "type": "dropdown",
              "disabled": false,
              "defaultvisibility": true,
              "required": true,
              "gridsize": 375,
              "masterdata": "customer/unit",
              "masterdatafield": "unit",
              "formdatafield": "unit",
              "cleanable": true,
              "searchable": true,
              'storeextrakeys': {
                "propertyid": "propertyid",
                "property": "property",
                "wingid": "wingid",
                "wing": "wing",
                "floorid": "floorid",
                "floor": "floor",
              },
              "dependentfilter": {
                "_id": "customerid",
              },
              // "masterdatadependancy": true,
              "staticfilter": { "isactive": 1 },
            },
          ],
        },
        {
          "tab": "Documents",
          "allowmultipleentries": false,
          "tabid": "ownedproperties",
          "uniquekey": "unitid",
          "required": false,
          "formFields": [
            {
              "field": "documents",
              "text": "Document Name",
              "type": "multipleFilePickerfieldwithtitle",
              "disabled": false,
              "defaultvisibility": true,
              "required": true,
              "gridsize": 375,
            }
          ],
        },
      ]
    }


    // return {
    //   "rightsidebarsize": 800,
    //   "pagename": "customer",
    //   "formname": "Tenant",
    //   "alias": "customer",
    //   "dataview": "tab",
    //   "formfields": [
    //     {
    //       "tab": "Tenant Details",
    //       "formFields": [
    //         {
    //           "field": "customerid",
    //           "text": "Flat Owner",
    //           "type": "dropdown",
    //           "disabled": false,
    //           "defaultvisibility": true,
    //           "required": true,
    //           "gridsize": 375,
    //           "masterdata": "customer",
    //           "masterdatafield": "personname",
    //           "formdatafield": "customer",
    //           "onchangefill": ["unitid"],
    //           "cleanable": true,
    //           "searchable": true,
    //           "masterdatadependancy": false,
    //           "staticfilter": { "isactive": 1 }
    //         },
    //         {
    //           "field": "unitid",
    //           "text": "Flat",
    //           "type": "dropdown",
    //           "disabled": false,
    //           "defaultvisibility": true,
    //           "required": false,
    //           "gridsize": 375,
    //           "masterdata": "customer/unit", // case for getting data from selected customer
    //           "masterdatafield": "unit",
    //           "formdatafield": "unit",
    //           "cleanable": true,
    //           "searchable": true,
    //           "storeextrakeys": { "wingid": "wingid", "wing": "wing", "floorid": "floorid", "floor": "floor" },
    //           "masterdatadependancy": false,
    //           "storemasterdatabyfield": true,
    //           "staticfilter": { "isactive": 1 },
    //           "attributes": ["wing", "floor"]
    //         },
    //         {
    //           'field': 'customertype',
    //           'text': 'Is Tenant',
    //           'type': 'checkbox',
    //           'disabled': false,
    //           'required': false,
    //           'defaultvalue': 1,
    //           'defaultvisibility': false,
    //           'gridsize': 180,
    //         },
    //         {
    //           "field": "firstname",
    //           "text": "First Name",
    //           "type": "input-text",
    //           "disabled": false,
    //           "defaultvisibility": true,
    //           "required": true,
    //           "capitalcase": true,
    //           "gridsize": 375
    //         },
    //         {
    //           "field": "lastname",
    //           "text": "Last Name",
    //           "type": "input-text",
    //           "disabled": false,
    //           "defaultvisibility": true,
    //           "required": true,
    //           "capitalcase": true,
    //           "gridsize": 375
    //         },
    //         {
    //           "field": "dateofbirth",
    //           "text": "DOB",
    //           "type": "datepicker",
    //           "disabled": false,
    //           "defaultvisibility": true,
    //           "required": true,
    //           "gridsize": 375
    //         },
    //         {
    //           "field": "genderid",
    //           "text": "Gender",
    //           "type": "dropdown",
    //           "disabled": false,
    //           "defaultvisibility": true,
    //           "required": true,
    //           "gridsize": 375,
    //           "masterdata": "gender",
    //           "masterdataarray": [
    //             { "label": "Male", "value": "66a1e97c238fdcb94369331d" },
    //             { "label": "Female", "value": "66a1e97c238fdcb94369300d" },
    //             { "label": "Other", "value": "66a1e97c238fdcb94369130d" }
    //           ],
    //           "defaultvalue": "66a1e97c238fdcb94369331d",
    //           "masterdatafield": "label",
    //           "formdatafield": "gender",
    //           "cleanable": true,
    //           "searchable": true,
    //           "masterdatadependancy": false
    //         },
    //         {
    //           "field": "contact",
    //           "text": "Mobile Number",
    //           "type": "number-input",
    //           "disabled": false,
    //           "defaultvisibility": true,
    //           "prefixtext": "code",
    //           "required": true,
    //           "gridsize": 375
    //         },
    //         {
    //           "field": "alternatecontact",
    //           "text": "Phone Number",
    //           "type": "number-input",
    //           "disabled": false,
    //           "defaultvisibility": true,
    //           "prefixtext": "code",
    //           "required": false,
    //           "gridsize": 375
    //         },
    //         {
    //           "field": "personemail",
    //           "text": "Email Address",
    //           "type": "input-text",
    //           "disabled": false,
    //           "defaultvisibility": true,
    //           'regxtype': 'email',
    //           "required": false,
    //           "gridsize": 375
    //         },
    //         {
    //           "field": "nationalityid",
    //           "text": "Nationality",
    //           "type": "dropdown",
    //           "disabled": false,
    //           "defaultvisibility": true,
    //           "required": true,
    //           "gridsize": 375,
    //           "masterdata": "nationality",
    //           "masterdatafield": "nationality",
    //           "formdatafield": "nationality",
    //           "cleanable": true,
    //           "searchable": true,
    //           "masterdatadependancy": false,
    //           "defaultvalue": "67382488171652f20e1a0754",
    //           "staticfilter": { "isactive": 1 }
    //         },
    //         {
    //           "field": "addressline1",
    //           "text": "Flat, House no., Building, Street",
    //           "type": "input-text",
    //           "disabled": false,
    //           "defaultvisibility": true,
    //           "required": true,
    //           "gridsize": 375
    //         },
    //         {
    //           "field": "addressline2",
    //           "text": "Area, Landmark",
    //           "type": "input-text",
    //           "disabled": false,
    //           "defaultvisibility": true,
    //           "required": true,
    //           "gridsize": 375
    //         },
    //         {
    //           "field": "pincode",
    //           "text": "Pincode",
    //           "type": "number-input",
    //           "disabled": false,
    //           "defaultvisibility": true,
    //           "required": true,
    //           "gridsize": 375
    //         },
    //         {
    //           "field": "cityid",
    //           "text": "City",
    //           "type": "dropdown",
    //           "disabled": false,
    //           "defaultvisibility": true,
    //           "required": true,
    //           "gridsize": 375,
    //           "masterdata": "city",
    //           "masterdatafield": "city",
    //           "formdatafield": "city",
    //           "cleanable": true,
    //           "searchable": true,
    //           "dependentfilter": { "stateid": "stateid" },
    //           "masterdatadependancy": true,
    //           "defaultvalue": "6710b1a7d57b9665bf472274",
    //           "staticfilter": { "isactive": 1 }
    //         },
    //         {
    //           "field": "stateid",
    //           "text": "State",
    //           "type": "dropdown",
    //           "disabled": false,
    //           "defaultvisibility": true,
    //           "required": true,
    //           "gridsize": 375,
    //           "masterdata": "state",
    //           "masterdatafield": "state",
    //           "formdatafield": "state",
    //           "cleanable": true,
    //           "searchable": true,
    //           "onchangefill": ["cityid"],
    //           "dependentfilter": { "countryid": "countryid" },
    //           "masterdatadependancy": true,
    //           "defaultvalue": "66acd3cb6a781176246a9637",
    //           "staticfilter": { "isactive": 1 }
    //         },
    //         {
    //           "field": "countryid",
    //           "text": "Country",
    //           "type": "dropdown",
    //           "disabled": false,
    //           "defaultvisibility": true,
    //           "required": true,
    //           "gridsize": 375,
    //           "masterdata": "country",
    //           "masterdatafield": "country",
    //           "formdatafield": "country",
    //           "cleanable": true,
    //           "searchable": true,
    //           "onchangefill": ["stateid"],
    //           "masterdatadependancy": false,
    //           "defaultvalue": "670fac1d244906d4e2dc7308",
    //           "staticfilter": { "isactive": 1 }
    //         },

    //       ]
    //     },
    //   ]
    // }
  }
  getFamilyMemberFormFieldOrder() {
    return {
      "rightsidebarsize": 1200,
      "pagename": "customer",
      "formname": "Family Member",
      "alias": "customer",
      "dataview": "tab",
      "formfields": [
        {
          "tab": "Personal Details",
          "formFields": [
            { "field": "profilepic", "text": "Profile Picture", "type": "file", "filetypes": Config.images, "disabled": false, "defaultvisibility": true, "required": false, "gridsize": 375 },
            { "field": "firstname", "text": "First Name", "type": "input-text", "disabled": false, "capitalcase": true, "defaultvisibility": true, "required": true, "gridsize": 375 },
            { "field": "lastname", "text": "Last Name", "type": "input-text", "disabled": false, "capitalcase": true, "defaultvisibility": true, "required": true, "gridsize": 375 },
            { "field": "dateofbirth", "text": "DOB", "type": "datepicker", "disabled": false, "defaultvisibility": true, "required": true, "gridsize": 375 },
            {
              "field": "genderid",
              "text": "Gender",
              "type": "dropdown",
              "disabled": false,
              "defaultvisibility": true,
              "required": true,
              "gridsize": 375,
              "masterdata": "gender",
              "masterdataarray": [
                { "label": "Male", "value": "66a1e97c238fdcb94369331d" },
                { "label": "Female", "value": "66a1e97c238fdcb94369300d" },
                { "label": "Other", "value": "66a1e97c238fdcb94369130d" }
              ],
              "defaultvalue": "66a1e97c238fdcb94369331d",
              "masterdatafield": "label",
              "formdatafield": "gender",
              "cleanable": true,
              "searchable": true,
              "masterdatadependancy": false
            },
            { "field": "contact", "text": "Mobile Number", "type": "number-input", "disabled": false, "defaultvisibility": true, "prefixtext": "code", "required": true, "gridsize": 375 },
            {
              "field": "personemail",
              "text": "Email Address",
              "type": "input-text",
              "disabled": false,
              "defaultvisibility": true,
              // "regex": "^(([^<>()[]\\.,;:s@\"]+(.[^<>()[]\\.,;:s@\"]+)*)|(\".+\"))@(([[0-9]{1,3}.[0-9]{1,3}.[0-9]{1,3}.[0-9]{1,3}])|(([a-zA-Z-0-9]+.)+[a-zA-Z]{2,}))",
              "required": false,
              "gridsize": 375,
              "regxtype": "email"
            },
            {
              "field": "relationid",
              "text": "Relation",
              "type": "dropdown",
              "disabled": false,
              "defaultvisibility": true,
              "required": true,
              "gridsize": 375,
              "masterdata": "relation",
              "masterdatafield": "relation",
              "formdatafield": "city",
              "cleanable": true,
              "searchable": true,
              'dependentfilter': {
                'stateid': 'stateid',
              },
              "masterdatadependancy": false,
            },
          ]
        },
        {
          "tab": "Documents",
          "allowmultipleentries": false,
          "tabid": "ownedproperties",
          "uniquekey": "unitid",
          "required": false,
          "formFields": [
            {
              "field": "documents",
              "text": "Document Name",
              "type": "multipleFilePickerfieldwithtitle",
              "disabled": false,
              'filetypes': [...Config.images, ...Config.pdfExtension, ...Config.docExtension],
              "defaultvisibility": true,
              "required": true,
              "gridsize": 375
            }
          ],
        },
      ]
    }
  }
}