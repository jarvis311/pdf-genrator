import mongoose from "mongoose"
import { Config } from '../config/Init.js'


export default class CheckList {
    constructor() {
        this._id
        this.propertyid = { type: mongoose.Schema.Types.ObjectId, ref: "tblproperty" }
        this.property = { type: String, trim: true }
        this.checklist = { type: String, required: true, trim: true}
        this.checklisttypeid = { type: mongoose.Schema.Types.ObjectId, ref: "tblchecklisttypemaster" }
        this.checklisttype = { type: String, required: true, trim: true }
        this.assetcategoryid = { type:mongoose.Schema.Types.ObjectId , ref:"tblassetcategory" }
        this.assetcategory = { type:String, trim: true }
        this.isimagerequired = { type: Number, trim: true, default: 0 }
        this.checklists = [
            {
                question: { type:String, required: true, trim: true },
                ismandatory: { type: Number, default: 0 },
            }
        ]
        this.isactive = { type: Number, trim: true, default: 1 }
        this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: "recordinfo" }
    }

    getDataName() {
      return "Check List"
    }
  
    getIndexes() {
        return [{  checklist: 1,property:1 }]
    }

    getFieldOrder() {
        return {
          "fields": [
            {
              "field": "action_button",
              "text": "",
              "type": "action_button",
              "freeze": 1,
              "active": 1,
              "sorttable": 0,
              "filter": 0,
              "disableflex": 1,
              "filterfieldtype": "lookup",
              "defaultvalue": "",
              "tblsize": 10
            },
            {
              "field": "isactive",
              "text": "Status",
              "type": "isactive",
              "freeze": 1,
              "active": 1,
              "sorttable": 0,
              "filter": 0,
              "disableflex": 1,
              "filterfieldtype": "lookup",
              "defaultvalue": "",
              "tblsize": 15
            },
            {
              "field": "checklist",
              "text": "Checklist Name",
              "type": "text",
              "freeze": 1,
              "active": 1,
              "sorttable": 1,
              "filter": 0,
              "filterfieldtype": "lookup",
              "defaultvalue": ""
            },
            {
              'field': 'checklisttype',
              'text': 'Checklist Type',
              'type': "text",
              "freeze": 0,
              "active": 1,
              "sorttable": 1,
              "filter": 1,
              'filterfield': 'checklisttypeid',
              "filterfieldtype": "dropdown",
              'masterdata': 'checklisttype',
              'masterdatafield': 'checklisttype',
              "formdatafield": "checklisttype",
              'defaultvalue': "",
            },
            {
              'field': 'assetcategory',
              'text': 'Asset Category',
              'type': "text",
              "freeze": 0,
              "active": 1,
              "sorttable": 1,
              "filter": 1,
              'filterfield': 'assetcategoryid',
              "filterfieldtype": "dropdown",
              'masterdata': 'assetcategory',
              'masterdatafield': 'assetcategory',
              "formdatafield": "assetcategory",
              'defaultvalue': "",
            },
      
          ]
        };
    }

    getFormFieldOrder() {
       return {
        "rightsidebarsize": 780,
        "pagename": "checklist",
        "formname": "Checklist",
        "alias": "checklist",
        "dataview": "tab",
        "formfields": [
          {
            "tab": "CheckList",
            "formFields": [
              {
                "field": "checklist",
                "text": "Checklist",
                "type": "input-text",
                "disabled": false,
                "defaultvisibility": true,
                "required": true,
                "gridsize": 375,
              },
              {
                "field": "checklisttypeid",
                "text": "Checklist Type",
                "type": "dropdown",
                "disabled": false,
                "defaultvisibility": true,
                "required": true,
                "gridsize": 375,
                "masterdata": "checklisttype",
                "masterdatafield": "checklisttype",
                "formdatafield": "checklisttype",
                "cleanable": true,
                "searchable": true,
              },
              {
                "field": "assetcategoryid",
                "text": "Select Asset Category",
                "type": "dropdown",
                "disabled": false,
                "defaultvisibility": true,
                "required": false,
                "gridsize": 375,
                "masterdata": "assetcategory",
                "masterdatafield": "assetcategory",
                "formdatafield": "assetcategory",
                "cleanable": true,
                "searchable": true,
              },
              {
                "field": "isimagerequired",
                "text": "Image Required",
                "type": "checkbox",
                "disabled": false,
                "defaultvisibility": true,
                "required": false,
                "gridsize": 375,
              },
              {
                "field": "checklists",
                "text": "CheckList",
                "type": "multipleQuestionField",
                "disabled": false,
                "defaultvisibility": true,
                "required": true,
                "gridsize": 375,
              }
            ]
          },
        ]
      };
    }
}
