import mongoose from "mongoose"

export default class PersonChangeLog {
	constructor() {
		this._id
		this.logtype = { type: Number, default: 0 } // 1: Create, 2: Update, 3: Previlege Change, 4: Delete, 5: Password Update, 9: Password Reset, 6: Account Lock, 7: Account Unlock, 8: Credit Card Password Update, 10: Credit Card Password Reset, 11: PMS Connect Password Reset
		this.logname = { type: String, trim: true, default: "" }
		this.moduletypeid = { type: mongoose.Schema.Types.ObjectId }
		this.moduletype = { type: String, trim: true, default: "" }
		this.requestpersonid = { type: mongoose.Schema.Types.ObjectId }
		this.requestpersonname = { type: String, trim: true, default: "" }
		this.entrydate = { type: Date, default: Date.now }
		this.userid = { type: mongoose.Schema.Types.ObjectId }
		this.username = { type: String, trim: true, default: "" }
        this.userpassword = { type: String, trim: true, default: "" }
        this.usercreditcardpassword = { type: String, trim: true, default: "" }
		this.ipaddress = { type: String, trim: true, default: "" }
		this.useragent = { type: String, trim: true, default: "" }
		this.issuer = { type: String, trim: true, default: "" }
		this.requestbody = { type: mongoose.Schema.Types.Mixed, default: {} }
		this.requestheader = { type: mongoose.Schema.Types.Mixed, default: {} }
	}
}
