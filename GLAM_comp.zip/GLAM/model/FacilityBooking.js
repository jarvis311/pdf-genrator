import mongoose from 'mongoose'
import { Config } from '../config/Init.js'

export default class FacilityBooking {
  constructor() {
    this._id
    this.propertyid = { type: mongoose.Schema.Types.ObjectId, ref: 'tblpropertymaster' }
    this.property = { type: String, required: true, trim: true }
    this.seriesid = { type: mongoose.Schema.Types.ObjectId, ref: 'tblseriesmaster' }
    this.maxid = { type: Number }
    this.customerid = { type: mongoose.Schema.Types.ObjectId, ref: 'tblcustomer' }
    this.customer = { type: String, trim: true, required: true }
    this.facilityid = { type: mongoose.Schema.Types.ObjectId, ref: 'tblpropertyfacility' }
    this.facility = { type: String, trim: true, required: true }
    this.seriesno = { type: String, required: true }
    this.slot = [{
      starttime: { type: Date },
      endtime: { type: Date },
      slotid: { type: mongoose.Schema.Types.ObjectId },
      isbooked: { type: Number, default: 0 }, //0-not booking 1-booking
      isapproved: { type: Number, default: 0 } // 0-pending 1- approved 2- rejected
    }]
    this.bookingdate = { type: Date }
    this.approveorrejectpersonid = { type: mongoose.Schema.Types.ObjectId }
    this.approveorrejectperson = { type: String }
    this.approveorrejecttime = { type: Date }
    this.rejectreason = { type: String, default: "" }
    this.status = { type: Number, default: 0 } // 0 - pending && 1 - approvel && 2 - rejected
    this.isactive = { type: Number, default: 1 }
    this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: 'recordinfo' }
  }

  getDataName() {
    return "Facility Booking"
  }

  getFieldOrder() {
    return {
      fields: [
        {
          'field': 'action_button',
          'text': '',
          'type': Config.getHtmlcontorls()['action_button'],
          'freeze': 1,
          'active': 1,
          'sorttable': 0,
          'filter': 0,
          'disableflex': 1,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': 8
        },
        {
          "field": "status",
          "text": "Status",
          "type": Config.getHtmlcontorls()['status'],
          "freeze": 0,
          "active": 1,
          "sorttable": 1,
          "filter": 0,
          "filterfieldtype": Config.getHtmlcontorls()['input-text'],
          "defaultvalue": "",
          "tblsize": 30
        },
        {
          field: "facility",
          text: "Facility",
          type: Config.getHtmlcontorls()["text"],
          freeze: 0,
          active: 1,
          sorttable: 1,
          filter: 1,
          filterfield: 'facilityid',
          filterfieldtype: Config.getHtmlcontorls()["dropdown"],
          // apipath: "property/building", //api path
          masterdata: "facility",
          masterdatafield: "facility",
          formdatafield: "facility",
          tblsize: 15,
          // staticfilter: { isactive: 1 },
        },
        {
          'field': 'customer',
          'text': 'Customer Name',
          'type': Config.getHtmlcontorls()['text'],
          'freeze': 0,
          'active': 1,
          'sorttable': 1,
          'sortby': 'customer',
          'filter': 1,
          'filterfieldtype': Config.getHtmlcontorls()['dropdown'],
          'defaultvalue': '',
          filterfield: 'customerid',
          masterdata: "customer",
          masterdatafield: "personname",
          formdatafield: "customer",
          'tblsize': 15
        },
        {
          'field': 'bookingdate',
          'text': 'Booking Date',
          'type': Config.getHtmlcontorls()['text'],
          'freeze': 0,
          'active': 1,
          'sorttable': 1,
          'sortby': 'bookingdate',
          'filter': 0,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': 15
        },
        {
          'field': 'slot',
          'text': 'Booked Slot',
          'type': Config.getHtmlcontorls()['time-range-list'],
          'freeze': 0,
          'active': 1,
          'sorttable': 0,
          'sortby': '',
          'filter': 0,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': 30
        },
        {
          "field": "fromdate",
          "text": "From Date",
          "type": "datepicker",
          "freeze": 0,
          "active": 0,
          "sorttable": 1,
          "sortby": "fromdate",
          "filter": 1,
          "filterfield": "fromdate",
          "filterfieldtype": "datepicker",
          "isonlyfilter": 1,
          "defaultvalue": "",
          "tblsize": 28
        },
        {
          "field": "todate",
          "text": "To Date",
          "type": "datepicker",
          "freeze": 0,
          "active": 0,
          "sorttable": 1,
          "sortby": "todate",
          "filter": 1,
          "filterfield": "todate",
          "filterfieldtype": "datepicker",
          "isonlyfilter": 1,
          "defaultvalue": "",
          "tblsize": 28
        },

      
        // {
        //   "field": "status",
        //   "text": "Status",
        //   "type": Config.getHtmlcontorls()['status'],
        //   "freeze": 0,
        //   "active": 1,
        //   "sorttable": 1,
        //   "filter": 0,
        //   "filterfieldtype": Config.getHtmlcontorls()['input-text'],
        //   "defaultvalue": "",
        //   "tblsize": 25
        // }

        // {
        //   'field': 'action_button',
        //   'text': '',
        //   'type': Config.getHtmlcontorls()['action_button'],
        //   'freeze': 1,
        //   'active': 1,
        //   'sorttable': 0,
        //   'filter': 0,
        //   'disableflex': 1,
        //   'filterfieldtype': Config.getHtmlcontorls()['lookup'],
        //   'defaultvalue': '',
        //   'tblsize': 10
        // },
        // {
        //   'field': 'isactive',
        //   'text': 'Status',
        //   'type': Config.getHtmlcontorls()['isactive'],
        //   'freeze': 1,
        //   'active': 1,
        //   'sorttable': 0,
        //   'filter': 0,
        //   'disableflex': 1,
        //   'filterfieldtype': Config.getHtmlcontorls()['lookup'],
        //   'defaultvalue': '',
        //   'tblsize': 15
        // },
        // {
        //   'field': 'city',
        //   'text': 'City Name',
        //   'type': Config.getHtmlcontorls()['text'],
        //   'freeze': 1,
        //   'active': 1,
        //   'sorttable': 1,
        //   'sortby': 'city',
        //   'filter': 0,
        //   'filterfieldtype': Config.getHtmlcontorls()['lookup'],
        //   'defaultvalue': '',
        //   'tblsize': 10
        // },
        // {
        //   'field': 'state',
        //   'text': 'State Name',
        //   'type': Config.getHtmlcontorls()['text'],
        //   'freeze': 1,
        //   'active': 1,
        //   'sorttable': 1,
        //   'sortby': 'state',
        //   'filter': 0,
        //   'filterfieldtype': Config.getHtmlcontorls()['lookup'],
        //   'defaultvalue': '',
        //   'tblsize': 10
        // },
        // {
        //   'field': 'country',
        //   'text': 'Country Name',
        //   'type': Config.getHtmlcontorls()['text'],
        //   'freeze': 1,
        //   'active': 1,
        //   'sorttable': 1,
        //   'sortby': 'country',
        //   'filter': 1,
        //   'filterfieldtype': Config.getHtmlcontorls()['lookup'],
        //   'defaultvalue': '',
        //   'tblsize': 10
        // }
      ]
    }
  }

  getFormFieldOrder() {
    return {
      "rightsidebarsize": Config.getModalsizeclasses()['xs'],
      "pagename": 'facilitybooking',
      "formname": 'Facility Booking',
      "alias": 'facilitybooking',
      "dataview": "tab",
      'formfields': [
        {
          "tab": "Facility Booking",
          "formFields": [
            // {
            //   'field': 'city',
            //   'text': 'City Name',
            //   'type': Config.getHtmlcontorls()['kInputText'],
            //   'disabled': false,
            //   'defaultvisibility': true,
            //   'required': true,
            //   'gridsize': Config.getFieldSize()['k375'],
            // },
            // {
            //   'field': 'countryid',
            //   'text': 'Country',
            //   'type': Config.getHtmlcontorls()['kDropDown'],
            //   'disabled': false,
            //   'defaultvisibility': true,
            //   'required': true,
            //   'gridsize': Config.getFieldSize()['k375'],
            //   'masterdata': 'country',
            //   'masterdatafield': 'country',
            //   'formdatafield': 'country',
            //   'cleanable': true,
            //   'searchable': true,
            //   'onchangefill': ['stateid'],
            //   'staticfilter': { 'isactive': 1 },
            // },
            // {
            //   'field': 'stateid',
            //   'text': 'State Name',
            //   'type': Config.getHtmlcontorls()['kDropDown'],
            //   'disabled': false,
            //   'defaultvisibility': true,
            //   'required': true,
            //   'gridsize': Config.getFieldSize()['k375'],
            //   'masterdata': 'state',
            //   'masterdatafield': 'state',
            //   'formdatafield': 'state',
            //   'cleanable': true,
            //   'searchable': true,
            //   'dependentfilter': {
            //     'countryid': 'countryid',
            //   },
            //   'masterdatadependancy': false,
            //   'staticfilter': { 'isactive': 1 },
            // },
            // Config.getFormfields()['isactive']
          ]
        }
      ],
    }
  }
}

