import mongoose from "mongoose"
import _Config from "../config/Config.js"
const Config = new _Config()

export default class CommitteeMembers {
  constructor() {
    this._id
    this.committeemembers = { type: String, trim: true, unique: true }
    this.isactive = { type: Number, required: true, default: 1 } // 1 - active, 0 - deactive
    this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: "recordinfo" }
  }


  getDataName() {
    return "committeemembers"
  }


  getFieldOrder() {

    return {
      fields: [
        {
          'field': 'action_button',
          'text': '',
          'type': Config.getHtmlcontorls()['action_button'],
          'freeze': 1,
          'active': 1,
          'sorttable': 0,
          'filter': 0,
          'disableflex': 1,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': Config.getTblgridsizeclasses()[10]
        },
        {
          'field': 'isactive',
          'text': 'Status',
          'type': Config.getHtmlcontorls()['isactive'],
          'freeze': 1,
          'active': 1,
          'sorttable': 0,
          'filter': 0,
          'disableflex': 1,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': Config.getTblgridsizeclasses()[15]
        },
        {
          'field': 'committeemembers',
          'text': 'Committee Members Name',
          'type': Config.getHtmlcontorls()['text'],
          'freeze': 1,
          'active': 1,
          'sorttable': 1,
          'sortby': 'committeemembers',
          'filter': 0,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': 165
        },

      ]
    }
  }

  getFormFieldOrder() {
    return {
      "rightsidebarsize": Config.getModalsizeclasses()['xs'],
      "pagename": 'committeemembers',
      "formname": 'Committee Members',
      "alias": 'committeemembers',
      "dataview": "committeemembers",
      'formfields': [
        {
          "tab": "committeemembers",
          "formFields": [
            {
              'field': 'committeemembers',
              'text': 'Committee Members Name',
              'type': Config.getHtmlcontorls()['kInputText'],
              'disabled': false,
              'defaultvisibility': true,
              'required': true,
              'gridsize': Config.getFieldSize()['k375'],
              "capitalcase": true
            },
            {
              'field': 'isactive',
              'text': 'Status',
              'type': Config.getHtmlcontorls()['kDropDown'],
              'disabled': false,
              'defaultvisibility': true,
              'required': true,
              'gridsize': Config.getFieldSize()['k375'],
              'masterdata': 'status',
              'masterdataarray': Config.getStatustype(),
              'defaultvalue': 1,
              'formdatafield': 'status',
              'cleanable': true,
              'searchable': true,
              'onchangedata': ['statusid'],
              'masterdatadependancy': false,
            },
          ]
        }
      ],
    }
  }

}