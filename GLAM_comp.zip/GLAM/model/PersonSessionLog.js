import mongoose from "mongoose"

export default class PersonSessionLog {
	constructor() {
		this._id
		this.moduletypeid = { type: mongoose.Schema.Types.ObjectId }
		this.moduletype = { type: String, trim: true, default: "" }
		this.logtype = { type: Number, default: 0 } // 1: Person Login, 2: Person Logout, 3: Person Invalid Login, 
		this.logname = { type: String, trim: true, default: "" }
		this.userid = { type: mongoose.Schema.Types.ObjectId }
		this.username = { type: String, trim: true, default: "" }
		this.ipaddress = { type: String, trim: true, default: "" }
		this.useragent = { type: String, trim: true, default: "" }
		this.issuer = { type: String, trim: true, default: "" }
		this.requestbody = { type: mongoose.Schema.Types.Mixed, default: {} }
		this.requestheader = { type: mongoose.Schema.Types.Mixed, default: {} }
		this.entrydate = { type: Date, default: Date.now }
	}
}
