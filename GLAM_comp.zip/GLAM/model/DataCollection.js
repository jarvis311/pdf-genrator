export default class DataCollection {
	constructor() {
		this._id
		this.tablename = { type: String, required: true, unique: true, trim: true }
		this.schemaurl = { type: String, trim: true, default: "" }
		this.isactive = { type: Number, default: 1 }
	}
}
