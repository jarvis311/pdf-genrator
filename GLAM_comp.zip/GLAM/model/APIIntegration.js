import mongoose from "mongoose"

export default class APIIntegration {
    constructor() {
        this._id
        this.platformid = { type: mongoose.Schema.Types.ObjectId, ref: "tblmessageplatform" }
        this.platform = { type: String, trim: true, unique: true }
        this.url = { type: String, trim: true, required: true }
        this.virtualnumberurl = { type: String, trim: true }
        this.calllisturl = { type: String, trim: true }
        this.username = { type: String, trim: true, required: true }
        this.password = { type: String, trim: true, required: true }
    }
}
