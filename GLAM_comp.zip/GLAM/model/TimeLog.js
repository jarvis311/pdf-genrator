import  mongoose  from 'mongoose'
import _Config from '../config/Config.js'

const Config = new _Config()

export default class TimeLog
{ 
    constructor(){
        this._id
        this.starttime = {type: String}
        this.midtime = {type : String}
        this.endtime = {type : String}
        this.estimatedhour = {type : Number}
        this.estimatedmin = {type : Number}
        this.duration = {type: Number, default:0}
        this.running = {type: Boolean}
        this.personid = {type : mongoose.Schema.Types.ObjectId, ref:'tblpersonmaster'}
        this.person = {type : String}   
        this.timerstate = {type : String}
        this.reasonid = {type : String, required:false}
        this.reason = {type : String, default:''}
        this.reasondescription = {type : String, default:''}
        this.isreview = {type: Number}
        this.followup = {type : String}
        this.complaintid = {type : mongoose.Schema.Types.ObjectId, ref:'tblcomplaint'}
        this.omplaint = { type:String}

        ///PAUSE ACTIVITY
        this.timehistory = [
            {
                time:{type:String},
                type:{type:Number}, //1 start 2 pause 3 end
                menualid:{type:String, default : ''},
                menualreasonid:{type:String, default : ''},
                menualreason:{type:String, default : ''},
                deleted:{type:Number, default : 0},

                edited:{type:Number, default : 0}, //if log is edited 1
                editeddetails : [
                    {
                        editpersonid : {type : String},
                        editperson : {type : String},
                        time : {type : String},
                    }
                ],

                // time history approvals
                status:{type:Number, default : 0}, // 0 pending, 1 approve, 2 reject
                approvaldate : {type:String},
                approvingpersonid : {type:String},
                approvingperson : {type:String},
                rejectreason : {type:String},
                requestedbyid : {type:String},
                requestedby : {type:String},
                deleterequest :{type:Number, default : 0},
                updatedtime:{type:String},
                updated : {type : Number},
                updateid : {type : String}
            }
        ]

        this.menualtimeloghistory = [
            {
                time:{type:String},
                menualid:{type:String, default : ''},
                action:{type:Number, default : 0},  // 0 pending, 1 insert, 2 update, 3 delete
                menualpersonid:{type:String},
                menualperson:{type:String},
                menualreasonid:{type:String},
                menualreason:{type:String},
                rejectreason:{type:String},
            }
        ]
        this.testcases = [
            {
                status : {type: Number,required: false,default:0},
                testcaseid : {type: mongoose.Schema.Types.ObjectId, ref :'tbltestcasemaster',required: true},
                addbyqa:{type: Number,required: true,default:0},
                testcase : {type: String,required: true},
            }
        ]
        this.recordinfo = {type : mongoose.Schema.Types.Mixed, ref: 'recordinfo'},
        this.scripted = {type :Number}
        this.type = {type : Number, default : 1} //  1 = support ticket
    }
    getDataName() {
        return "Time log"
    }
    //doubt
    getFieldOrder(){
        return {

            fields : [
            {
                'field' : 'requesttype',
                'text' : 'Request Type',
                'type' : Config.getHtmlcontorls()['text'],
                'freeze' : 0,
                'active' : 1,
                'sorttable' : 1,
                'filter' : 0,
                'defaultvalue' : '',
                'filterfieldtype' : Config.getHtmlcontorls()['input-text'],
                'tblsize' : Config.getTblgridsizeclasses()['tbl-min-w130']
            },
            {
                'field' : 'person',
                'text' : 'Employee Name',
                'type' : Config.getHtmlcontorls()['text'],
                'freeze' : 1,
                'active' : 1,
                'sorttable' : 1,
                'filter' : 0,
                'defaultvalue' : '',
                'tblsize' : Config.getTblgridsizeclasses()['tbl-w200']
            },
            {
                'field' : 'duration',
                'text' : 'Timelog Duration',
                'type' : Config.getHtmlcontorls()['text'],
                'freeze' : 0,
                'active' : 1,
                'filter' : 0,
                'sorttable' : 0,
                'filterfieldtype' : Config.getHtmlcontorls()['number-input'],
                'defaultvalue' : '',
                'tblsize' : Config.getTblgridsizeclasses()['tbl-w250']
            },
            {
                'field' : 'status',
                'text' : 'Status',
                'type' : 'text',
                'freeze' : 0,
                'active' : 1,
                'sorttable' : 1,
                'filter' : 0,
                'filterfieldtype' : Config.getHtmlcontorls()['number-input'],
                'defaultvalue' : '',
                'tblsize' : Config.getTblgridsizeclasses()['tbl-min-w400']
            },
            {
                'field' : 'reason',
                'text' : 'Reason',
                'type' : Config.getHtmlcontorls()['input-text'],
                'freeze' : 0,
                'active' : 1,
                'sorttable' : 1,
                'filter' : 0,
                'defaultvalue' : '',
                'filterfieldtype' : Config.getHtmlcontorls()['input-text'],
                'tblsize' : Config.getTblgridsizeclasses()['tbl-min-w300']
            },
            {
                'field' : 'task',
                'text' : 'Task Name',
                'type' : Config.getHtmlcontorls()['text'],
                'freeze' : 0,
                'active' : 1,
                'sorttable' : 1,
                'filter' : 0,
                'defaultvalue' : '',
                'tblsize' : Config.getTblgridsizeclasses()['tbl-w180']
            },
            {
                'field' : 'project',
                'text' : 'Project',
                'type' : Config.getHtmlcontorls()['text'],
                'freeze' : 0,
                'active' : 1,
                'filter' : 0,
                'sorttable' : 1,
                'masterdata' : 'project',
                'masterdatafield': 'projectname',
                'defaultvalue' : '',
                'tblsize' : Config.getTblgridsizeclasses()['tbl-w140'],
                'staticfilter' : { 'default' : 0 }
            },
            {
                'field' : 'module',
                'text' : 'Module',
                'type' : Config.getHtmlcontorls()['text'],
                'freeze' : 0,
                'active' : 1,
                'sorttable' : 1,
                'filter' : 0,
                'defaultvalue' : '',
                'tblsize' : Config.getTblgridsizeclasses()['tbl-w140']
            },
            
            ]

        }
        
    }

    getTodoTimeFieldOrder(){
        return {

            fields : [
            {
                'field' : 'requesttype',
                'text' : 'Request Type',
                'type' : Config.getHtmlcontorls()['text'],
                'freeze' : 0,
                'active' : 1,
                'sorttable' : 1,
                'filter' : 0,
                'defaultvalue' : '',
                'filterfieldtype' : Config.getHtmlcontorls()['input-text'],
                'tblsize' : Config.getTblgridsizeclasses()['tbl-min-w130']
            },
            {
                'field' : 'person',
                'text' : 'Employee Name',
                'type' : Config.getHtmlcontorls()['text'],
                'freeze' : 1,
                'active' : 1,
                'sorttable' : 1,
                'filter' : 0,
                'defaultvalue' : '',
                'tblsize' : Config.getTblgridsizeclasses()['tbl-w200']
            },
            {
                'field' : 'duration',
                'text' : 'Timelog Duration',
                'type' : Config.getHtmlcontorls()['text'],
                'freeze' : 0,
                'active' : 1,
                'filter' : 0,
                'sorttable' : 0,
                'filterfieldtype' : Config.getHtmlcontorls()['number-input'],
                'defaultvalue' : '',
                'tblsize' : Config.getTblgridsizeclasses()['tbl-w250']
            },
            {
                'field' : 'status',
                'text' : 'Status',
                'type' : 'text',
                'freeze' : 0,
                'active' : 1,
                'sorttable' : 1,
                'filter' : 0,
                'filterfieldtype' : Config.getHtmlcontorls()['number-input'],
                'defaultvalue' : '',
                'tblsize' : Config.getTblgridsizeclasses()['tbl-min-w400']
            },
            {
                'field' : 'reason',
                'text' : 'Reason',
                'type' : Config.getHtmlcontorls()['input-text'],
                'freeze' : 0,
                'active' : 1,
                'sorttable' : 1,
                'filter' : 0,
                'defaultvalue' : '',
                'filterfieldtype' : Config.getHtmlcontorls()['input-text'],
                'tblsize' : Config.getTblgridsizeclasses()['tbl-min-w300']
            },
            {
                'field' : 'task',
                'text' : 'Task Name',
                'type' : Config.getHtmlcontorls()['text'],
                'freeze' : 0,
                'active' : 1,
                'sorttable' : 1,
                'filter' : 0,
                'defaultvalue' : '',
                'tblsize' : Config.getTblgridsizeclasses()['tbl-w180']
            },
            {
                'field' : 'todocategory',
                'text' : 'Todo Category',
                'type' : Config.getHtmlcontorls()['text'],
                'freeze' : 0,
                'active' : 1,
                'filter' : 0,
                'sorttable' : 1,
                'masterdata' : 'todocategory',
                'masterdatafield': 'name',
                'defaultvalue' : '',
                'tblsize' : Config.getTblgridsizeclasses()['tbl-w140'],
                'staticfilter' : { 'status' : 1 }
            }            
            ]

        }
        
    }

    getSupportTicketTimeFieldOrder(){
        return {

            fields : [
            {
                'field' : 'requesttype',
                'text' : 'Request Type',
                'type' : Config.getHtmlcontorls()['text'],
                'freeze' : 0,
                'active' : 1,
                'sorttable' : 1,
                'filter' : 0,
                'defaultvalue' : '',
                'filterfieldtype' : Config.getHtmlcontorls()['input-text'],
                'tblsize' : Config.getTblgridsizeclasses()['tbl-min-w130']
            },
            {
                'field' : 'person',
                'text' : 'Employee Name',
                'type' : Config.getHtmlcontorls()['text'],
                'freeze' : 1,
                'active' : 1,
                'sorttable' : 1,
                'filter' : 0,
                'defaultvalue' : '',
                'tblsize' : Config.getTblgridsizeclasses()['tbl-w200']
            },
            {
                'field' : 'duration',
                'text' : 'Timelog Duration',
                'type' : Config.getHtmlcontorls()['text'],
                'freeze' : 0,
                'active' : 1,
                'filter' : 0,
                'sorttable' : 0,
                'filterfieldtype' : Config.getHtmlcontorls()['number-input'],
                'defaultvalue' : '',
                'tblsize' : Config.getTblgridsizeclasses()['tbl-w250']
            },
            {
                'field' : 'status',
                'text' : 'Status',
                'type' : 'text',
                'freeze' : 0,
                'active' : 1,
                'sorttable' : 1,
                'filter' : 0,
                'filterfieldtype' : Config.getHtmlcontorls()['number-input'],
                'defaultvalue' : '',
                'tblsize' : Config.getTblgridsizeclasses()['tbl-min-w400']
            },
            {
                'field' : 'reason',
                'text' : 'Reason',
                'type' : Config.getHtmlcontorls()['input-text'],
                'freeze' : 0,
                'active' : 1,
                'sorttable' : 1,
                'filter' : 0,
                'defaultvalue' : '',
                'filterfieldtype' : Config.getHtmlcontorls()['input-text'],
                'tblsize' : Config.getTblgridsizeclasses()['tbl-min-w300']
            },
            {
                'field' : 'task',
                'text' : 'Task Name / Subject',
                'type' : Config.getHtmlcontorls()['text'],
                'freeze' : 0,
                'active' : 1,
                'sorttable' : 1,
                'filter' : 0,
                'defaultvalue' : '',
                'tblsize' : Config.getTblgridsizeclasses()['tbl-w180']
            },
            {
                'field' : 'supportcategory',
                'text' : 'Support Category',
                'type' : Config.getHtmlcontorls()['text'],
                'freeze' : 0,
                'active' : 1,
                'filter' : 0,
                'sorttable' : 1,
                'masterdata' : 'supportcategory',
                'masterdatafield': 'name',
                'defaultvalue' : '',
                'tblsize' : Config.getTblgridsizeclasses()['tbl-w140'],
            },
            {
                'field' : 'ticketid',
                'text' : 'Ticket Id',
                'type' : Config.getHtmlcontorls()['text'],
                'freeze' : 0,
                'active' : 1,
                'filter' : 0,
                'sorttable' : 1,
                'defaultvalue' : '',
                'tblsize' : Config.getTblgridsizeclasses()['tbl-w140'],
            }                    
            ]

        }
        
    }

    getTrainingTimeFieldOrder(){
        return {

            fields : [
            {
                'field' : 'requesttype',
                'text' : 'Request Type',
                'type' : Config.getHtmlcontorls()['text'],
                'freeze' : 0,
                'active' : 1,
                'sorttable' : 1,
                'filter' : 0,
                'defaultvalue' : '',
                'filterfieldtype' : Config.getHtmlcontorls()['input-text'],
                'tblsize' : Config.getTblgridsizeclasses()['tbl-min-w130']
            },
            {
                'field' : 'person',
                'text' : 'Employee Name',
                'type' : Config.getHtmlcontorls()['text'],
                'freeze' : 1,
                'active' : 1,
                'sorttable' : 1,
                'filter' : 0,
                'defaultvalue' : '',
                'tblsize' : Config.getTblgridsizeclasses()['tbl-w200']
            },
            {
                'field' : 'duration',
                'text' : 'Timelog Duration',
                'type' : Config.getHtmlcontorls()['text'],
                'freeze' : 0,
                'active' : 1,
                'filter' : 0,
                'sorttable' : 0,
                'filterfieldtype' : Config.getHtmlcontorls()['number-input'],
                'defaultvalue' : '',
                'tblsize' : Config.getTblgridsizeclasses()['tbl-w250']
            },
            {
                'field' : 'status',
                'text' : 'Status',
                'type' : 'text',
                'freeze' : 0,
                'active' : 1,
                'sorttable' : 1,
                'filter' : 0,
                'filterfieldtype' : Config.getHtmlcontorls()['number-input'],
                'defaultvalue' : '',
                'tblsize' : Config.getTblgridsizeclasses()['tbl-min-w400']
            },
            {
                'field' : 'reason',
                'text' : 'Reason',
                'type' : Config.getHtmlcontorls()['input-text'],
                'freeze' : 0,
                'active' : 1,
                'sorttable' : 1,
                'filter' : 0,
                'defaultvalue' : '',
                'filterfieldtype' : Config.getHtmlcontorls()['input-text'],
                'tblsize' : Config.getTblgridsizeclasses()['tbl-min-w300']
            },
            {
                'field' : 'trainingname',
                'text' : 'Training',
                'type' : Config.getHtmlcontorls()['input-text'],
                'freeze' : 0,
                'active' : 1,
                'sorttable' : 0,
                'filter' : 0,
                'defaultvalue' : '',
                'filterfieldtype' : Config.getHtmlcontorls()['input-text'],
                'tblsize' : Config.getTblgridsizeclasses()['tbl-min-w300']
            },      
            ]

        }
        
    }

}