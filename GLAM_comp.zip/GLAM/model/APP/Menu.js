export default class Device{
    constructor(){
        this._id
    }
}