import mongoose from "mongoose"

export default class FavoriteService {
    constructor() {
        this._id
        this.personid = { type: mongoose.Schema.Types.ObjectId, ref: "tblpersonmaster", unique: true }
        this.services = { type: mongoose.Schema.Types.Mixed }
    }
}
