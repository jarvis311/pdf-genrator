import mongoose from "mongoose"
import _Config from "../../config/Config.js"

export default class Icon {
    constructor() {
        this._id
        this.iconname = { type: String, required: true, unique: true, trim: true }
        this.iconstyle = { type: String, required: true, trim: true }
        this.iconclass = { type: String, required: true, trim: true }
        this.iconunicode = { type: String, required: true, unique: true, trim: true }
        this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: "recordinfo" }
    }

    getFieldOrder() {
        const Config = new _Config()

        return {
            fields: [
                {
                    field: "iconname",
                    text: "Icon Name",
                    type: Config.getHtmlcontorls()["text"],
                    freeze: 1,
                    active: 1,
                    sorttable: 1,
                    filter: 1,
                    filterfieldtype: Config.getHtmlcontorls()["lookup"],
                    defaultvalue: "",
                    tblsize: Config.getTblgridsizeclasses()["tbl-w150"]
                },
                {
                    field: "icon",
                    text: "Icon",
                    type: Config.getHtmlcontorls()["icon"],
                    freeze: 0,
                    active: 1,
                    sorttable: 0,
                    filter: 0,
                    filterfieldtype: Config.getHtmlcontorls()["dropdown"],
                    defaultvalue: "",
                    tblsize: Config.getTblgridsizeclasses()["tbl-w150"]
                }
            ]
        }
    }
}
