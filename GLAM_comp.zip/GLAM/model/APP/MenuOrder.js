import mongoose from "mongoose"

export default class MenuOrder {
    constructor() {
        this._id
        this.personid = { type: mongoose.Schema.Types.ObjectId, ref: "tblpersonmaster", unique: true }
        this.menus = { type: mongoose.Schema.Types.Mixed }
        this.dashboardmenu = { type: mongoose.Schema.Types.Mixed }
    }
}
