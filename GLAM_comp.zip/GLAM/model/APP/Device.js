export default class Device {
	constructor() {
		this._id
		this.uid = { type: String, required: true, trim: true }
		this.platform = { type: String, required: true, trim: true }
		this.moduletypeid = { type: String, required: true, trim: true }
		this.useragent = { type: String, required: true, trim: true }
		this.os = { type: String, required: true, trim: true }
		this.osversion = { type: String, required: true, trim: true }
		this.ipaddress = { type: String, required: true, trim: true }
		this.macaddress = { type: String, required: true, trim: true }
		this.deviceid = { type: String, trim: true }
		this.devicemodelname = { type: String, required: true, trim: true }
		this.edate = { type: Date, default: Date.now }
		this.appversion = { type: String, required: true, trim: true }
		this.appupdate = { type: Date, default: Date.now }
		this.token = { type: String, required: true, trim: true }
	}

	getIndexes(){
		return [{uid : 1, moduletypeid : 1}]
	}
}
