import mongoose from "mongoose"

export default class ZohoServicesModel {
    constructor() {
        this._id
        this.name = { type: String, required: true, trim: true }
        this.baseurl = { type: String, required: true, trim: true }
        this.scops = { type: Array, default: [] }
        this.status = { type: Number }
        this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: "recordinfo" }
    }
}