export default class ZohoToken {
    constructor() {
        this._id
        this.token_type = { type: String, required: false, trim: true }
        this.access_token = { type: String, required: false, trim: true }
        this.scope = { type: String, required: false, trim: true }
        this.expires_in = { type: String, required: false, trim: true }
        this.api_domain = { type: String, required: false, trim: true }
        this.expiry = { type: Date, required: false, trim: true }
    }
}