import { Config } from "../../config/Init.js"

export default class ZohoApiHistory {
    constructor() {
        this._id
        this.req_url = { type: String, required: false, trim: true }
        this.req_params = { type: String, required: false, trim: true }
        this.req_body = { type: String, required: false, trim: true }
        this.req_time = { type: Date, required: false, trim: true }
        this.req_for = { type: String, required: false, trim: true }
        this.req_operation = { type: String, required: false, trim: true }
        this.subdomain = { type: String, required: false, trim: true }
        this.res_status = { type: String, required: false, trim: true }
        this.res_body = { type: String, required: false, trim: true }
        this.res_time = { type: Date, required: false, trim: true }
        this.execution_time = { type: String, required: false, trim: true }
    }

    getFieldOrder() {
        return {
            fields: [
                {
                    'field': 'req_url',
                    'text': 'Request Url',
                    'type': Config.getHtmlcontorls()['text'],
                    'freeze': 1,
                    'active': 1,
                    'sorttable': 0,
                    'sortby': 'employeeid',
                    'filter': 1,
                    'filterfieldtype': Config.getHtmlcontorls()['lookup'],
                    'defaultvalue': '',
                    'tblsize': 25
                },
                {
                    'field': 'req_for',
                    'text': 'Request For',
                    'type': Config.getHtmlcontorls()['text'],
                    'freeze': 1,
                    'active': 1,
                    'sorttable': 0,
                    'sortby': 'name',
                    'filter': 1,
                    'filterfieldtype': Config.getHtmlcontorls()['lookup'],
                    'defaultvalue': 0,
                    'tblsize': 10
                },
                {
                    'field': 'req_operation',
                    'text': 'Request Operation',
                    'type': Config.getHtmlcontorls()['text'],
                    'freeze': 1,
                    'active': 1,
                    'sorttable': 0,
                    'filter': 1,
                    'filterfieldtype': Config.getHtmlcontorls()['lookup'],
                    'defaultvalue': 0,
                    'tblsize': 15,
                    'staticfilter': { status: 1 }
                },
                {
                    'field': 'req_time',
                    'text': 'Request Time',
                    'type': Config.getHtmlcontorls()['time'],
                    'freeze': 1,
                    'active': 1,
                    'sorttable': 0,
                    'filter': 1,
                    'filterfieldtype': Config.getHtmlcontorls()['lookup'],
                    'defaultvalue': '',
                    'tblsize': 10
                },
                {
                    'field': 'res_time',
                    'text': 'Response Time',
                    'type': Config.getHtmlcontorls()['time'],
                    'freeze': 1,
                    'active': 1,
                    'sorttable': 0,
                    'sortby': 'email',
                    'filter': 1,
                    'filterfieldtype': Config.getHtmlcontorls()['lookup'],
                    'defaultvalue': 0,
                    'tblsize': 10
                },
                {
                    'field': 'execution_time',
                    'text': 'Total Execution Time',
                    'type': Config.getHtmlcontorls()['text'],
                    'freeze': 1,
                    'active': 1,
                    'sorttable': 0,
                    'sortby': 'email',
                    'filter': 1,
                    'filterfieldtype': Config.getHtmlcontorls()['lookup'],
                    'defaultvalue': 0,
                    'tblsize': 10
                },
                {
                    'field': 'res_status',
                    'text': 'Response Status Code',
                    'type': Config.getHtmlcontorls()['text'],
                    'freeze': 1,
                    'active': 1,
                    'sorttable': 0,
                    'sortby': 'contact',
                    'filter': 1,
                    'filterfieldtype': Config.getHtmlcontorls()['lookup'],
                    'defaultvalue': 0,
                    'tblsize': 10
                },
                {
                    'field': '',
                    'text': 'Req./Res. Body',
                    'type': Config.getHtmlcontorls()['open'],
                    'freeze': 1,
                    'active': 1,
                    'sorttable': 0,
                    'sortby': 'email',
                    'filter': 1,
                    'filterfieldtype': Config.getHtmlcontorls()['lookup'],
                    'defaultvalue': 0,
                    'tblsize': 10
                },
            ]
        }
    }

    getContractFieldOrder() {
        return {
            fields: [
                {
                    'field': 'paymenttype',
                    'text': 'Payment Type',
                    'type': Config.getHtmlcontorls()['text'],
                    'freeze': 1,
                    'active': 1,
                    'sorttable': 0,
                    'sortby': 'paymenttype',
                    'filter': 0,
                    'filterfieldtype': Config.getHtmlcontorls()['lookup'],
                    'defaultvalue': '',
                    'tblsize': 25
                },
                {
                    'field': 'contractno',
                    'text': 'Contract No',
                    'type': Config.getHtmlcontorls()['text'],
                    'freeze': 1,
                    'active': 1,
                    'sorttable': 0,
                    'sortby': 'paymentcode',
                    'filter': 0,
                    'filterfieldtype': Config.getHtmlcontorls()['lookup'],
                    'defaultvalue': 0,
                    'tblsize': 10
                },
                {
                    'field': 'paymentcode',
                    'text': 'Payment Code',
                    'type': Config.getHtmlcontorls()['text'],
                    'freeze': 1,
                    'active': 1,
                    'sorttable': 0,
                    'sortby': 'paymentcode',
                    'filter': 0,
                    'filterfieldtype': Config.getHtmlcontorls()['lookup'],
                    'defaultvalue': 0,
                    'tblsize': 10
                },
                {
                    'field': 'frequency',
                    'text': 'Frequency',
                    'type': Config.getHtmlcontorls()['text'],
                    'freeze': 1,
                    'active': 1,
                    'sorttable': 0,
                    'filter': 0,
                    'filterfieldtype': Config.getHtmlcontorls()['lookup'],
                    'defaultvalue': 0,
                    'tblsize': 15,
                },
                {
                    'field': 'amount',
                    'text': 'Amount',
                    'type': Config.getHtmlcontorls()['text'],
                    'freeze': 1,
                    'active': 1,
                    'sorttable': 0,
                    'sortby': 'amount',
                    'filter': 0,
                    'filterfieldtype': Config.getHtmlcontorls()['lookup'],
                    'defaultvalue': 0,
                    'tblsize': 10
                },
                {
                    'field': 'from',
                    'text': 'From',
                    'type': Config.getHtmlcontorls()['text'],
                    'freeze': 1,
                    'active': 1,
                    'sorttable': 0,
                    'sortby': 'from',
                    'filter': 0,
                    'filterfieldtype': Config.getHtmlcontorls()['lookup'],
                    'defaultvalue': '',
                    'tblsize': 10
                },
                {
                    'field': 'to',
                    'text': 'To',
                    'type': Config.getHtmlcontorls()['text'],
                    'freeze': 1,
                    'active': 1,
                    'sorttable': 0,
                    'sortby': 'to',
                    'filter': 0,
                    'filterfieldtype': Config.getHtmlcontorls()['lookup'],
                    'defaultvalue': 0,
                    'tblsize': 10
                },
                {
                    'field': 'status',
                    'text': 'Status',
                    'type': Config.getHtmlcontorls()['sap_status'],
                    'freeze': 1,
                    'active': 1,
                    'sorttable': 0,
                    'sortby': 'status',
                    'filter': 0,
                    'filterfieldtype': Config.getHtmlcontorls()['lookup'],
                    'defaultvalue': 0,
                    'tblsize': 10,
                    'disable': 1
                }
            ]
        }
    }
}