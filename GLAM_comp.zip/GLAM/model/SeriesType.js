import mongoose from "mongoose"

import _Config from "../config/Config.js"
const Config = new _Config()

export default class SeriesType {
    constructor() {
        this._id
        this.seriestype = { type: String, trim: true }
        this.hasproperty = { type: Number }
        this.hasdaterange = { type: Number }
    }


    getDataName() {
        return "Series Type"
    }

    getFieldOrder() {
        return {
            fields: [
                {
                    'field': 'action_button',
                    'text': '',
                    'type': Config.getHtmlcontorls()['action_button'],
                    'freeze': 1,
                    'active': 1,
                    'sorttable': 0,
                    'filter': 0,
                    'disableflex': 1,
                    'filterfieldtype': Config.getHtmlcontorls()['lookup'],
                    'defaultvalue': '',
                    'tblsize': 8
                },
                // {
                //     'field': 'isactive',
                //     'text': 'Status',
                //     'type': Config.getHtmlcontorls()['isactive'],
                //     'freeze': 1,
                //     'active': 1,
                //     'sorttable': 0,
                //     'filter': 0,
                //     'disableflex': 1,
                //     'filterfieldtype': Config.getHtmlcontorls()['lookup'],
                //     'defaultvalue': '',
                //     'tblsize': 15
                // },
                {
                    'field': 'seriestype',
                    'text': 'Series Type',
                    'type': Config.getHtmlcontorls()['text'],
                    'freeze': 1,
                    'active': 1,
                    'sorttable': 1,
                    'sortby': 'seriestype',
                    'filter': 0,
                    'filterfieldtype': Config.getHtmlcontorls()['lookup'],
                    'defaultvalue': '',
                    'tblsize': 20
                },
                {
                    'field': 'hasproperty',
                    'text': 'Has Property',
                    'type': Config.getHtmlcontorls()['switch'],
                    'freeze': 1,
                    'active': 1,
                    'sorttable': 0,
                    'filter': 0,
                    'filterfieldtype': Config.getHtmlcontorls()['checkbox'],
                    'defaultvalue': 0,
                    'tblsize': 15
                },
                {
                    'field': 'hasdaterange',
                    'text': 'Has Date Range',
                    'type': Config.getHtmlcontorls()['switch'],
                    'freeze': 1,
                    'active': 1,
                    'sorttable': 0,
                    'filter': 0,
                    'filterfieldtype': Config.getHtmlcontorls()['checkbox'],
                    'defaultvalue': 0,
                    'tblsize': 142
                },
            ]
        }
    }

    getFormFieldOrder() {
        return {
            "rightsidebarsize": Config.getModalsizeclasses()['xs'],
            "pagename": 'seriestype',
            "formname": 'Series Type',
            "alias": 'seriestype',
            "dataview": "tab",
            'formfields': [
                {
                    "tab": "Areatype",
                    "formFields": [
                        {
                            'field': 'seriestype',
                            'text': 'Series Type',
                            'type': Config.getHtmlcontorls()['kInputText'],
                            'disabled': false,
                            'defaultvisibility': true,
                            'required': true,
                            'gridsize': Config.getFieldSize()['k375'],
                        },
                        {
                            'field': 'hasproperty',
                            'text': 'Has Property',
                            'type': Config.getHtmlcontorls()['kCheckBox'],
                            'disabled': false,
                            'required': false,
                            'defaultvisibility': true,
                            'gridsize': Config.getFieldSize()['k375'],
                        },
                        {
                            'field': 'hasdaterange',
                            'text': 'Has Date Range',
                            'type': Config.getHtmlcontorls()['kCheckBox'],
                            'disabled': false,
                            'required': false,
                            'defaultvisibility': true,
                            'gridsize': Config.getFieldSize()['k375'],
                        },
                    ]
                }
            ],
        }
    }
}
