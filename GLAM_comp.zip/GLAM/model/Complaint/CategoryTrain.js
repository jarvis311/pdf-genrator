import mongoose from 'mongoose'
import { Config } from '../../config/Init.js'

export default class categorytrain {
  constructor() {
    this._id
    this.complaincategroyid = {type:mongoose.Schema.Types.ObjectId,ref:'tblcategorymaster'}
    this.complaintcategory = { type:String,required:true}
    this.keyword = {type:Array}
    this.subject = { type: String, required: true }
    this.isactive = { type: Number, default: 1 }
    this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: 'recordinfo' }
  }

  getDataName() {
    return "Category"
  }

  getFieldOrder() {
    return {
      fields: [
        {
          'field': 'action_button',
          'text': '',
          'type': Config.getHtmlcontorls()['action_button'],
          'freeze': 1,
          'active': 1,
          'sorttable': 0,
          'filter': 0,
          'disableflex': 1,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': 8
        },
        {
          'field': 'isactive',
          'text': 'Status',
          'type': Config.getHtmlcontorls()['isactive'],
          'freeze': 1,
          'active': 1,
          'sorttable': 0,
          'filter': 0,
          'disableflex': 1,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': 15
        },
        {
          'field': 'categorytrain',
          'text': 'Complaint Category',
          'type': Config.getHtmlcontorls()['text'],
          'freeze': 1,
          'active': 1,
          'sorttable': 1,
          'sortby': 'categorytrain',
          'filter': 0,
          'disableflex': 2,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': 10
        },
        {
          'field': 'reopenwindowduration',
          'text': 'Reopen Window Duration (Min)',
          'type': Config.getHtmlcontorls()['text'],
          'freeze': 1,
          'active': 1,
          'sorttable': 1,
          'sortby': 'reopenwindowduration',
          'filter': 0,
          'disableflex': 2,
          'filterfieldtype': Config.getHtmlcontorls()['lookup'],
          'defaultvalue': '',
          'tblsize': 10
        }
      ]
    }
  }

  getFormFieldOrder() {
    return {
      "rightsidebarsize": Config.getModalsizeclasses()['xs'],
      "pagename": 'categorytrain',
      "formname": 'Complaint Category',
      "alias": 'categorytrain',
      "dataview": "tab",
      'formfields': [
        {
          "tab": "categorytrain",
          "formFields": [
            {
              'field': 'categorytrain',
              'text': 'Complaint Category',
              'type': Config.getHtmlcontorls()['kInputText'],
              'disabled': false,
              'defaultvisibility': true,
              'required': true,
              'gridsize': Config.getFieldSize()['k375'],
              "capitalcase": true
            },
            {
              "field": "reopenwindowduration",
              "text": "Reopen Window Duration (Min)",
              "type": "number-input",
              "disabled": false,
              "defaultvisibility": true,
              "required": true,
              "gridsize": 375
            },
            {
              'field': 'isactive',
              'text': 'Status',
              'type': Config.getHtmlcontorls()['kDropDown'],
              'disabled': false,
              'defaultvisibility': true,
              'required': true,
              'gridsize': Config.getFieldSize()['k375'],
              'masterdata': 'isactive',
              'masterdataarray': Config.getStatustype(),
              'defaultvalue': 1,
              'formdatafield': 'isactive',
              'cleanable': true,
              'searchable': true,
              'masterdatadependancy': false,
            },
          ]
        }
      ],
    }
  }
}