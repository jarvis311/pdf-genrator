import mongoose from 'mongoose'
import _Config from '../../config/Config.js'

export default class ComplaintStage {
    constructor() {
        this._id
        this.stage = { type: String, required: [true, 'stage is required'], unique: true }
        this.timetracking = { type: Number, default: 0 }
        this.iscomplete = { type: Number, default: 0 },
        this.displaystage = [{
            stageid: { type: mongoose.Schema.Types.ObjectId, ref: 'tblcomplaintstage' },
            stage: { type: String },
            iscomplete : {type: Number},
            timetracking : { type:Number },
            backgroundcolor :{ r: { type: Number, required: true }, g: { type: Number, required: true }, b: { type: Number, required: true }, a: { type: Number, required: true } }
        }]
        this.backtracking = { type: Number, default: 0 },
        this.backgroundcolor = { r: { type: Number, required: true }, g: { type: Number, required: true }, b: { type: Number, required: true }, a: { type: Number, required: true } }
        this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: 'recordinfo' }
    }

    getDataName() {
        return "Complaint Stage"
    }

    getFieldOrder() {
        const Config = new _Config()

        return {
            fields: [
                {
                    'field': 'stage',
                    'text': 'Stage',
                    'type': Config.getHtmlcontorls()['text'],
                    'freeze': 1,
                    'active': 1,
                    'sorttable': 1,
                    'filter': 0,
                    'filterfieldtype': Config.getHtmlcontorls()['lookup'],
                    'defaultvalue': '',
                    'tblsize': 44
                },
                {
                    'field': 'backgroundcolor',
                    'text': 'Background Color',
                    'type': Config.getHtmlcontorls()['color'],
                    'freeze': 0,
                    'active': 1,
                    'sorttable': 0,
                    'filter': 0,
                    'filterfieldtype': Config.getHtmlcontorls()['lookup'],
                    'defaultvalue': '',
                    'tblsize': 35
                },
                {
                    'field': 'timetracking',
                    'text': 'Time Tracking',
                    'type': Config.getHtmlcontorls()['switch'],
                    'freeze': 0,
                    'active': 1,
                    'sorttable': 1,
                    'filter': 0,
                    'filterfieldtype': Config.getHtmlcontorls()['lookup'],
                    'defaultvalue': '',
                    'tblsize': 35
                },
                {
                    'field': 'iscomplete',
                    'text': 'Is Complete',
                    'type': Config.getHtmlcontorls()['switch'],
                    'freeze': 0,
                    'active': 1,
                    'sorttable': 1,
                    'filter': 0,
                    'filterfieldtype': Config.getHtmlcontorls()['lookup'],
                    'defaultvalue': '',
                    'tblsize': 35
                },
                {
                    'field': 'backtracking',
                    'text': 'Backtracking',
                    'type': Config.getHtmlcontorls()['switch'],
                    'freeze': 0,
                    'active': 1,
                    'sorttable': 1,
                    'filter': 0,
                    'filterfieldtype': Config.getHtmlcontorls()['lookup'],
                    'defaultvalue': '',
                    'tblsize': 35
                }
            ]
        }
    }
}

