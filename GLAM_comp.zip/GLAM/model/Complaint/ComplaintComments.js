import  mongoose  from 'mongoose'
import _Config from '../../config/Config.js'

export default class ComplaintComments
{ 
    constructor(){
        this._id
        this.parentcommentid = {type : String}
        this.complaintticketid = {type : mongoose.Schema.Types.ObjectId, ref:'tbltask'}
        this.complaintticket = {type : String,required:true} 
        this.comment = {type: String}
        this.comment_time = {type: String}
        this.personid = {type : mongoose.Schema.Types.ObjectId, ref:'tblusermaster'}
        this.person = {type : String}
        this.propertyid = {type:mongoose.Schema.Types.ObjectId, ref:'tblproperty'}
        this.property = {type:String}
        this.parentcommentpersonid = {type : String}
        this.parentcommentperson = {type : String}
        this.parentcomment = {type: String}
        this.tagpersons = [
            {
                tagpersonid :{type : mongoose.Schema.Types.ObjectId, ref:'tblusermaster'},
                tagperson : {type : String},
            }
        ]
        this.recordinfo = {type : mongoose.Schema.Types.Mixed, ref: 'recordinfo'}
    }
}