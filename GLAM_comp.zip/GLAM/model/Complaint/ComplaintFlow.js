import mongoose from 'mongoose'
import _Config from '../../config/Config.js'

export default class ComplaintFlow
{ 
    constructor(){

        this._id
        this.complaintcategoryid = {type : mongoose.Schema.Types.ObjectId,ref:'tblsupportcategorymaster'}
        this.complaintcategory = {type : String, required:[true, 'Complaint category is required']}


        this.propertyid = {type:mongoose.Schema.Types.ObjectId,ref:'tblproperty'}
        this.property = {type:String,required:true}
        this.complaintflow = [{
            title:{type:String},
            departmentid : {type : mongoose.Schema.Types.ObjectId, ref:'tbldepartmentmaster'},
            department : {type : String},
            designation : [
                {
                    designationid :  {type: mongoose.Schema.Types.ObjectId, ref :'tbldesignationmaster'},
                    designation : {type: String,required: true,maxLength: 50},
                }
            ],
            alerttype : [
                {
                    alerttypeid :  {type: mongoose.Schema.Types.ObjectId, ref :'tblalertmaster'},
                    alerttype : {type: String,required: true,maxLength: 50},
                }
            ],//Notification = 1,  Mail = 2, Chat = 3, Whatsapp = 4
            assignedperson : [
                {
                    assignedpersonid : {type : mongoose.Schema.Types.ObjectId, ref:'tblemployee'},
                    assignedperson : {type : String},
                }
            ],            
            accepttime  : {type : Number, required : true, default : 0},
            solvetime  : {type : Number, required : true, default : 0},

            // backtracking : {type : Number},
            // iscomplete : {type : Number},
            id : {type : String},
            type: {type : String},
            source : {type : String},
            target : {type : String},
            position : {
                x : Number,
                y : Number,
            }
        }]
        this.connection = [{type:Object}]
        this.recordinfo = {type : mongoose.Schema.Types.Mixed, ref: 'recordinfo'}
    }

    getDataName() {
        return "Complaint Flow"
    }

}