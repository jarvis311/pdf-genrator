import  mongoose  from 'mongoose'
import _Config from '../../config/Config.js'


export default class ComplaintStatus
{ 
    constructor(){
        this._id
        this.status = {type : String, default: 1}
        this.statustype = {type : String},
        this.order = {type:Number}
        this.recordinfo = {type : mongoose.Schema.Types.Mixed, ref: 'recordinfo'}
    }

}