import mongoose from 'mongoose'
import _Config from '../../config/Config.js'
import IISMethods from '../../config/IISMethods.js'
import { Config } from '../../config/Init.js'

const IISMethod = new IISMethods()

export default class Complaint {
    constructor() {
        this._id
        this.ownerid = { type: mongoose.Schema.Types.ObjectId }
        // this.owner = { type: String, required: [true, 'Owner is required'] }
        this.owner = { type: String }
        this.profilepicture = { type: Object },
            this.complainttypeid = { type: mongoose.Schema.Types.ObjectId, ref: "tblcomplainttype" }
        this.complainttype = { type: String }
        this.complaintcategoryid = { type: mongoose.Schema.Types.ObjectId, ref: 'tblcomplaintcategorymaster' }
        this.complaintcategory = { type: String, required: true }
        this.subject = { type: String, required: true }
        this.description = { type: String, required: true }
        this.propertyid = { type: mongoose.Schema.Types.ObjectId, ref: "tblpropertymaster" }
        this.propertyname = { type: String, require: true }
        this.images = [new _Config().getImageModel()]
        this.duedate = { type: Date, require: true, default: Date.now }
        this.behalfpersonid = { type: mongoose.Schema.Types.ObjectId, ref: "tblemployee" }
        this.behalfperson = { type: String }
        this.area = [{
            areaid: { type: mongoose.Schema.Types.ObjectId, ref: "tblpropertyarea" },
            area: { type: String },
            commonarea: { type: Number, default: 0 },
            wingid: { type: mongoose.Schema.Types.ObjectId, ref: "tblpropertywing" },
            wing: { type: String },
            floorid: { type: mongoose.Schema.Types.ObjectId, ref: "tblpropertyfloor" },
            floor: { type: String },
        }]
        this.wing = [{
            wingid: { type: mongoose.Schema.Types.ObjectId, ref: "tblpropertywing" },
            wing: { type: String },
        }]
        this.floor = [{
            floorid: { type: mongoose.Schema.Types.ObjectId, ref: "tblpropertyfloor" },
            floor: { type: String },
            wingid: { type: mongoose.Schema.Types.ObjectId, ref: "tblpropertywing" },
            wing: { type: String },
        }]
        this.unit = [{
            unitid: { type: mongoose.Schema.Types.ObjectId, ref: "tblpropertyunit" },
            unit: { type: String },
            wingid: { type: mongoose.Schema.Types.ObjectId, ref: "tblpropertywing" },
            wing: { type: String },
            floorid: { type: mongoose.Schema.Types.ObjectId, ref: "tblpropertyfloor" },
            floor: { type: String },
        }]
        //supporters
        this.assignedto = [
            {
                assignedtoid: { type: mongoose.Schema.Types.ObjectId, ref: 'tblemployee', required: true, maxLength: 50 },
                assignedto: { type: String, required: true, maxLength: 50 },
            }
        ]
        this.assignproperty = [{
            wingid: { type: mongoose.Schema.Types.ObjectId, ref: "tblpropertywing" },
            wing: { type: String },
            floorid: { type: mongoose.Schema.Types.ObjectId, ref: "tblpropertyfloor" },
            floor: { type: String },
            unitid: { type: mongoose.Schema.Types.ObjectId, ref: "tblpropertyunit" },
            unit: { type: String }
        }
        ]
        this.seriesid = { type: mongoose.Schema.Types.ObjectId, ref: 'tblseriesmaster', required: true, maxLength: 50 }
        this.maxid = { type: Number, required: true, maxLength: 50 }
        this.ticketid = { type: String, required: [true, "Ticketid is required"], maxLength: 50 }
        this.attechment = { type: String }
        this.complaintpriorityid = { type: mongoose.Schema.Types.ObjectId, ref: 'tblcomplaintpriority' }
        this.complaintpriority = { type: String }
        this.complaintprioritycolor = { type: String }
        this.serialid = { type: String }
        this.reopen = { type: String, default: 0 }
        this.timestamp = { type: Number }
        this.workhours = { type: Number, required: false, default: 0 }
        this.workminutes = { type: Number, required: false, default: 0 }
        // Documents
        this.documents = [Config.getImageModel()]
        this.log = [
            {
                statusid: { type: mongoose.Schema.Types.ObjectId, ref: 'tblcomplaintstage' },
                status: { type: String },
                backgroundcolor: { type: String, default: "#ab056e" },
                personid: { type: mongoose.Schema.Types.ObjectId },
                person: { type: String },
                logdatetime: { type: String },
                assignedto: { type: mongoose.Schema.Types.Mixed },
                logtype: { type: Number },
                message: { type: String }
            }
        ]
        this.employeeid = { type: mongoose.Schema.Types.ObjectId, ref: 'tblemployee' }
        this.employee = { type: String }
        this.isskip = { type: Number, default: 0 }
        this.rating = { type: Number }
        this.completereason = { type: String }
        this.reopenreason = { type: String }
        this.order = { type: Number }

        //rating
        this.rating = [{
            customerid: { type: mongoose.Schema.Types.ObjectId, ref: "tblcustomer" },
            customer: { type: String },
            profilepicture: { type: Object },
            rating: { type: String },
            date: { type: String }
        }]
        this.status = { type: String }
        this.statusid = { type: mongoose.Schema.Types.ObjectId, ref: 'tblcomplaintstage' }
        this.backgroundcolor = { type: String, default: "#ab056e" }
        this.acceptedtime = { type: String }
        this.acceptedtimestamp = { type: String }
        this.accepted = { type: Number, default: 0 }
        this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: 'recordinfo' }
    }

    getDataName() {
        return "Complaint"
    }
    getFieldOrder() {
        const Config = new _Config()

        return {
            fields: [
                {
                    'field': 'action_button',
                    'text': '',
                    'type': Config.getHtmlcontorls()['action_button'],
                    'freeze': 1,
                    'active': 1,
                    'sorttable': 0,
                    'filter': 0,
                    'disableflex': 1,
                    'filterfieldtype': Config.getHtmlcontorls()['lookup'],
                    'defaultvalue': '',
                    'tblsize': Config.getTblgridsizeclasses()[8]
                },
                {
                    'field': 'complaintpriority',
                    'text': 'Priority',
                    'type': Config.getHtmlcontorls()['kPriority'],
                    'freeze': 1,
                    'active': 1,
                    'sorttable': 1,
                    'filter': 0,
                    'filterfieldtype': Config.getHtmlcontorls()['lookup'],
                    'defaultvalue': '',
                    'tblsize': Config.getTblgridsizeclasses()[10]
                },
                {
                    'field': 'status',
                    'text': 'Status',
                    'type': Config.getHtmlcontorls()['kStatus'],
                    'freeze': 1,
                    'active': 1,
                    'sorttable': 1,
                    'filter': 0,
                    'filterfieldtype': Config.getHtmlcontorls()['lookup'],
                    'defaultvalue': '',
                    // 'disableflex': 1,
                    'tblsize': Config.getTblgridsizeclasses()[15]
                },
                {
                    'field': 'unseenmessagecount',
                    'text': 'Chat',
                    'type': Config.getHtmlcontorls()['kChat'],
                    'freeze': 1,
                    'active': 1,
                    'sorttable': 1,
                    'filter': 0,
                    'filterfieldtype': Config.getHtmlcontorls()['lookup'],
                    'defaultvalue': '',
                    'tblsize': Config.getTblgridsizeclasses()[10]
                },
                {
                    'field': 'ticketid',
                    'text': 'Ticket Id',
                    'type': Config.getHtmlcontorls()['text'],
                    'freeze': 0,
                    'active': 1,
                    'sorttable': 1,
                    'filter': 0,
                    'filterfieldtype': Config.getHtmlcontorls()['lookup'],
                    'defaultvalue': '',
                    'tblsize': Config.getTblgridsizeclasses()[20]
                },
                {
                    'field': 'subject',
                    'text': 'Subject',
                    'type': Config.getHtmlcontorls()['text'],
                    'freeze': 0,
                    'active': 1,
                    'sorttable': 1,
                    'filter': 0,
                    'filterfieldtype': Config.getHtmlcontorls()['lookup'],
                    'defaultvalue': '',
                    'tblsize': Config.getTblgridsizeclasses()[25]
                },
                {
                    'field': 'duedate',
                    'text': 'Due Date',
                    'type': Config.getHtmlcontorls()['text'],
                    'freeze': 0,
                    'active': 1,
                    'sorttable': 1,
                    'filter': 0,
                    'filterfieldtype': Config.getHtmlcontorls()['lookup'],
                    'defaultvalue': '',
                    'tblsize': Config.getTblgridsizeclasses()[15]
                },
                {
                    'field': 'owner',
                    'text': 'Owner',
                    'type': Config.getHtmlcontorls()['text'],
                    'freeze': 0,
                    'active': 1,
                    'sorttable': 1,
                    'filter': 0,
                    'filterfieldtype': Config.getHtmlcontorls()['lookup'],
                    'defaultvalue': '',
                    'tblsize': Config.getTblgridsizeclasses()[20]
                },
                {
                    'field': 'assignedto',
                    'text': 'Assigned To',
                    'type': Config.getHtmlcontorls()['text-array'],
                    'freeze': 0,
                    'active': 1,
                    'sorttable': 0,
                    'filter': 0,
                    'filterfieldtype': Config.getHtmlcontorls()['lookup'],
                    'defaultvalue': '',
                    'tblsize': 67
                },
                /// Filters
                {
                    'field': 'status',
                    'text': 'Complaint Status',
                    'type': 'status',
                    'freeze': 0,
                    'active': 0,
                    'sorttable': 1,
                    'isonlyfilter': 1,
                    'sortby': 'assetstatus',
                    'filter': 1,
                    'filterfieldtype': Config.getHtmlcontorls()['dropdown'],
                    'filterfield': 'statusid',
                    "masterdata": "complaintstage",
                    "masterdatafield": "stage",
                    "formdatafield": "status",
                    'tblsize': Config.getTblgridsizeclasses()[25]
                },

            ]
        }
    }

    getFormFieldOrder() {
        return {
            "rightsidebarsize": 400,
            "pagename": "complaint",
            "formname": "Complaint",
            "alias": "complaint",
            "dataview": "tab",
            "formfields": [
                {
                    "tab": "complaint",
                    "formFields": [
                        {
                            "field": "complaintcategoryid",
                            "text": "Category",
                            "type": "dropdown",
                            "disabled": false,
                            "defaultvisibility": true,
                            "required": true,
                            "gridsize": 375,
                            "masterdata": "complaintcategory",
                            "masterdatafield": "complaintcategory",
                            "formdatafield": "complaintcategory",
                            "cleanable": true,
                            "searchable": true,
                            "masterdatadependancy": false,
                            // "staticfilter": { "isactive": 1 }
                        },
                        {
                            "field": "ownerid",
                            "text": "Owner",
                            "type": "dropdown",
                            "disabled": false,
                            "defaultvisibility": true,
                            "required": true,
                            "gridsize": 375,
                            "masterdata": "customer",
                            "masterdatafield": "personname",
                            "formdatafield": "owner",
                            "cleanable": true,
                            "searchable": true,
                            "masterdatadependancy": false,
                            // "staticfilter": { "isactive": 1 }
                        },
                        {
                            'field': 'isskip',
                            'text': 'Employee Assign',
                            'type': 'checkbox',
                            'disabled': false,
                            'defaultvisibility': true,
                            'required': false,
                            'gridsize': 375,
                            'defaultvalue': 0,
                        },
                        {
                            "field": "employeeid",
                            "text": "Assignee",
                            "type": "dropdown",
                            "disabled": false,
                            "defaultvisibility": true,
                            "required": true,
                            "gridsize": 375,
                            "masterdata": "employee",
                            "masterdatafield": "personname",
                            "formdatafield": "employee",
                            "cleanable": true,
                            "searchable": true,
                            // "dependentfilter": { "complaintcategoryid": "complaintcategoryid" },
                            "defaultvalue": null,
                            "masterdatadependancy": false,
                            "condition": { "isskip": [1] },
                            "staticfilter": { "isactive": 1 },
                            "projection": { 'personname': 1 },
                        },
                        {
                            "field": "complaintpriorityid",
                            "text": "Priority",
                            "type": "dropdown",
                            "disabled": false,
                            "defaultvisibility": true,
                            "required": true,
                            "gridsize": 375,
                            "masterdata": "complaintpriority",
                            "masterdatafield": "complaintpriority",
                            "formdatafield": "complaintpriority",
                            "storeextrakeys": {
                                "complaintprioritycolor": "backgroundcolor",
                            },
                            "cleanable": true,
                            "searchable": true,
                            "masterdatadependancy": false,
                            "staticfilter": { "isactive": 1 }
                        },
                        {
                            "field": "complainttypeid",
                            "text": "Complaint Type",
                            "type": "dropdown",
                            "disabled": false,
                            "defaultvisibility": true,
                            "required": true,
                            "gridsize": 375,
                            "masterdata": "complainttype",
                            "masterdatafield": "complainttype",
                            "formdatafield": "complainttype",
                            "cleanable": true,
                            "searchable": true,
                            "masterdatadependancy": false,
                            "staticfilter": { "isactive": 1 }
                        },

                        {
                            "field": "duedate",
                            "text": "Due Date",
                            "type": "datepicker",
                            "disabled": false,
                            "defaultvisibility": true,
                            "required": true,
                            "defaultvalue": new Date().toISOString(),
                            "gridsize": 375
                        },
                        { "field": "subject", "text": "Subject", "type": "input-text", "disabled": false, "defaultvisibility": true, "required": true, "gridsize": 375 },
                        { "field": "description", "text": "Description", "type": "input-text", "disabled": false, "defaultvisibility": true, "required": true, "gridsize": 375 },

                        {
                            'field': 'images',
                            'text': 'Attachments',
                            'type': "multipleimagepicker",
                            'disabled': false,
                            'defaultvisibility': true,
                            'required': false,
                            'filetypes': ["png"],
                            'gridsize': 375,
                        },
                    ]
                },
            ]
        }
    }
}