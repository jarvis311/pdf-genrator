import mongoose from 'mongoose'
import _Config from '../../config/Config.js'

export default class SupportTicketStageFlow
{ 
    constructor(){

        this._id
        this.complaintcategoryid = {type : mongoose.Schema.Types.ObjectId,ref:'tblcomplaintcategorymaster'}
        this.complaintcategory = {type : String, required:[true, 'Complaint category is required']}
        this.propertyid = {type:mongoose.Schema.Types.ObjectId,ref:'tblproperty'}
        this.property = {type:String,required:true}
        this.complaintflow = [{
            stageid : {type : mongoose.Schema.Types.ObjectId, ref:'tblcomplaintstage'},
            stage : {type : String},
            id : {type : String},
            backgroundcolor : { r : {type: Number}, g : {type: Number}, b: {type: Number}, a : {type: Number} },
            textcolor : { r : {type: Number}, g : {type: Number}, b: {type: Number}, a : {type: Number} },
            timetracking : {type : Number}, 
            backtracking : {type : Number},
            iscomplete : {type : Number},
            type: {type : String},
            source : {type : String},
            target : {type : String},
            position : {
                x : Number,
                y : Number,
            }
        }]
        this.recordinfo = {type : mongoose.Schema.Types.Mixed, ref: 'recordinfo'}
    }

    getDataName() {
        return "Complaint Stage Flow"
    }
}