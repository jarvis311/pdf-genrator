import mongoose from "mongoose"

export default class ComplaintStatusActionLog {
    constructor() {
        this._id
        this.complaintid = { type: mongoose.Schema.Types.ObjectId}
        this.statusid = { type: mongoose.Schema.Types.ObjectId }
        this.status = { type: String, trim: true }
        this.statustype = { type: String, trim: true }
        this.entrydateadded = { type: Number, default: 0 }
        this.time = { type: Number, default: 0 } // seconds
        this.date = { type: Date }
        this.updateddate = { type: Date }
        this.firstlogdate = { type: Date }
        this.iscurrentstatus = { type: Number }
        this.statusorder = { type: Number }
        this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: "recordinfo" }
    }

    getIndexes(){
        return [{complaintid : 1}]
    }
}
