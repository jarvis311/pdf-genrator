import  mongoose  from 'mongoose'
import _Config from '../../config/Config.js'

export default class ComplaintLog
{ 
    constructor(){
        this._id
        this.complaintticketid = {type : mongoose.Schema.Types.ObjectId, ref:'tblcomplaint'}
        this.complaintticket = {type : String} 
        this.ownerid = {type : mongoose.Schema.Types.ObjectId, ref:'tblusermaster'}
        this.owner = {type : String, required : [true,'Owner is required']}
        this.logdatetime = {type: String}
        this.isactive = {type :String}
        this.statusid = {type : mongoose.Schema.Types.ObjectId, ref:'tblcomplaintstage'}
        this.recordinfo = {type : mongoose.Schema.Types.Mixed, ref: 'recordinfo'}
    }
}