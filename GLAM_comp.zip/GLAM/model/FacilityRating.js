import mongoose from "mongoose"

export default class FacilityRating {
	constructor() {
		this._id
		this.customerid = { type: mongoose.Schema.Types.ObjectId, ref: "tblgatekeeper" }
        this.customer = { type:String,require:true}
        this.propertyid = { type: mongoose.Schema.Types.ObjectId, ref: "tblproperty" }
        this.property = { type:String,require:true}
        this.facilityid = { type: mongoose.Schema.Types.ObjectId, ref: "tblpropertyfacility" }
        this.facility = { type:String,require:true}
        this.rating = { type: Number }
		this.time = { type: Date, default: Date.now }
        this.recordinfo = { type: mongoose.Schema.Types.Mixed, ref: 'recordinfo' }
	}
}
