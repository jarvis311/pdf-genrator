import { IISMethods, Config,MainDB, FieldConfig } from "../../../../config/Init.js"
import _Userrights from "../../../../model/masters/UserManagement/Userrights.js"
import _MenuAssign from "../../../../model/masters/Menu/MenuAssign.js"
import _MenuDesign from "../../../../model/masters/Menu/MenuDesign.js"
import _Employee from '../../../../model/Onboarding/Employee.js'


const TableName = "tblmenudesignmaster"
const PageName = "MenuDesign"
const FormName = "MenuDesign"
const FltPageCollection = "menudesignmaster"

//admin and if available in design and assign => Design
//admin and if not available in design => Assign
//user and if available in design => Design and Rights
//user and if not available in design => Assign and Rights

export default class MenuDesignMaster {
	// List Menu Design
	async ListDesignMenu(req, res, next) {
		try {
            const ObjectId = IISMethods.getobjectid()
            let { moduletypeid } = req.body
            var menuData = []

            const pipeline = [
                { $match: { _id: new ObjectId(req.headers.uid) } }
                // {
                //     $project: {
                //         "name": 1, "email": 1, "contact": 1,
                //         "userrole": 1, "profilepic": 1, "status": 1, "dateofbirth": 1,
                //     }
                // },
            ]

            let resp = await MainDB.getmenual('tblemployee', new _Employee(), pipeline)
            let userdata = resp.ResultData[0]

            if (userdata && userdata.isactive == 1) {
                let isadmin = await MainDB.IsSuperAdmin(userdata._id.toString())
                menuData = await MainDB.getMenu(moduletypeid, userdata, isadmin)
            }

            var ResponseBody = {}
            ResponseBody.pagename = "menudesign"
            ResponseBody.status = 200
            ResponseBody.message = Config.resstatuscode['200']
            ResponseBody.data = menuData
            req.ResponseBody = ResponseBody
            next()

        }
        catch (err) {
            req.ResponseBody = { status: 500, message: Config.resstatuscode["500"], err }
            next()
        }
	}

	// Insert Menu Design
	async InsertMenuDesign(req, res, next) {
		try {
            var ResponseBody = {}

            const isAdmin = await MainDB.IsSuperAdmin(req.headers.uid)

            const designData = req.body.menudesigndata

            // Convert Menu Design Data to Linear
            const linerdesignData = []

            for (const designObj of designData) {
                designObj.title = designObj.menuname

                if (designObj.isparent === 1) {
                    if (Array.isArray(designObj.children) && designObj.children.length) {
                        for (const childrenObj of designObj.children) {
                            childrenObj.title = childrenObj.menuname
                            childrenObj.parentid = designObj.menuid
                            childrenObj.moduleid = designObj.moduleid

                            linerdesignData.push(childrenObj)
                        }
                    } else {
                        delete designObj.children
                    }

                    linerdesignData.push(designObj)
                }
            }

            req.body.menudesigndata = linerdesignData

            if (isAdmin) {
                req.body.isdefaultmenu = 1
            }

            const menudesignPipeline = { userid: req.headers.uid, moduletypeid: req.body.moduletypeid }
            const menudesign = await MainDB.FindOne("tblmenudesignmaster", new _MenuDesign(), menudesignPipeline)

            if (menudesign) {
                req.body._id = menudesign._id

                const resp = await MainDB.executedata("u", new _MenuDesign(), 'tblmenudesignmaster', req.body)

                ResponseBody.status = resp.status
                ResponseBody.message = resp.message
            } else {
                const resp = await MainDB.executedata("i", new _MenuDesign(), 'tblmenudesignmaster', req.body)

                ResponseBody.status = resp.status
                ResponseBody.message = resp.message
            }

            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.resstatuscode["500"], err }
            next()
        }
	}


	async ResetAllDesign(req, res, next) {
        try {

            var ResponseBody = {}
            const deleteResp = await MainDB.DeleteMany('tblmenudesignmaster', new _MenuDesign(), { isdefaultmenu: 0 })

            ResponseBody.message = deleteResp.status == 200 ? "Applied" : ""
            ResponseBody.status = deleteResp.status
            req.ResponseBody = ResponseBody
            next()
        }
        catch (err) {
            req.ResponseBody = { status: 500, message: Config.resstatuscode["500"], err }
            next()
        }
    }

}
