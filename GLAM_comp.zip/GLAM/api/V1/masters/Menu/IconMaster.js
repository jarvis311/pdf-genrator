import { IISMethods,MainDB, Config } from "../../../../config/Init.js"
import _Icon from "../../../../model/masters/Menu/Icon.js"
import _Menu from "../../../../model/masters/Menu/Menu.js"
import _MenuAssign from "../../../../model/masters/Menu/MenuAssign.js"
import _MenuDesign from "../../../../model/masters/Menu/MenuDesign.js"
import _Module from '../../../../model/masters/Menu/Module.js'

const TableName = "tbliconmaster"
const PageName = "Icon"
const FormName = "Icon"
const FltPageCollection = "iconmaster"

export default class IconMaster {
	// List
	async ListIcon(req, res, next) {
		try {
            const ResponseBody = {}
            var pipeline = []
            const { searchtext = "", paginationinfo: { pageno = 1, nextpageid = "", pagelimit = 20, filter = {}, sort = {}, projection = {} } } = req.body || {}

            const requiredPage = {
                pageno: pageno,
                nextpageid: nextpageid,
                skip: (pageno - 1) * pagelimit,
                pagelimit: pagelimit
            }
            const sortData = Object.keys(sort).length !== 0 ? sort : { _id: -1 }
            pipeline = IISMethods.GetPipelineForFilter(filter)

			if (searchtext !== "") {
				pipeline.push(...IISMethods.GetGlobalSearchFilter(new _Icon(), searchtext))
			}

			const resp = await MainDB.getmenual(TableName, new _Icon(), pipeline, requiredPage, sortData, true,"",projection) 

			ResponseBody.pagename = PageName
			ResponseBody.formname = FormName
			ResponseBody.fltpagecollection = FltPageCollection
			ResponseBody.status = 200
			ResponseBody.message = Config.getResponsestatuscode()["200"]
			ResponseBody.data = resp.ResultData
			ResponseBody.currentpage = resp.currentpage
			ResponseBody.nextpage = resp.nextpage
			ResponseBody.fieldorder = resp.fieldorderdata
            ResponseBody.totaldocs = resp.totaldocs
            ResponseBody.formfieldorderdata = resp.formfieldorderdata 

			req.ResponseBody = ResponseBody
			next()
		} catch (err) {
			req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
			next()
		}
	}

	// Insert
	async InsertIcon(req, res, next) {
		try {
			const ResponseBody = {}

			// req.body.iconimage.url = await IISMethods.movefileS3(req.body.iconimage.url, 'Icon/' + req.body.iconimage.name)

			const resp = await MainDB.executedata("i", new _Icon(), TableName, req.body)

			ResponseBody.status = resp.status
			ResponseBody.message = resp.message
			ResponseBody.data = resp.data

			req.ResponseBody = ResponseBody
			next()
		} catch (err) {
			req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
			next()
		}
	}

	// Update
	async UpdateIcon(req, res, next) {
		 try {

            var ResponseBody = {}
            const ObjectId = IISMethods.getobjectid()

            const pipeline = [{ $match: { '_id': ObjectId(req.body._id) } }]
            const record = await MainDB.getmenual(TableName, new _Icon(), pipeline)

            var RecordInfo = record.ResultData[0].recordinfo
            RecordInfo.updateuid = req.headers.uid
            RecordInfo.updateby = req.headers.personname
            RecordInfo.updatedate = IISMethods.getdatetimeisostr()
            req.body.recordinfo = RecordInfo

            if (req.body?.iconimage?.url != record.ResultData[0].iconimage.url) {
               // req.body.iconimage.url = await IISMethods.movefileS3(req.body.iconimage.url, 'Icon/' + req.body.iconimage.name)
            }

            const resp = await MainDB.executedata('u', new _Icon(), TableName, req.body)

            ResponseBody.status = resp.status
            ResponseBody.data = resp.data
            ResponseBody.message = resp.message

            //change in tblmodulemaster
            const modulemasterupdatepipeline = [{ iconid: req.body._id }, { $set: { iconimage: req.body.iconimage } }]
            await MainDB.UpdateMany('tblmodulemaster', new _Module(), modulemasterupdatepipeline)

            //change in tblmenumaster
            const menumasterupdatepipeline = [{ iconid: req.body._id }, { $set: { iconimage: req.body.iconimage } }]
            await MainDB.UpdateMany('tblmenumaster', new _Menu(), menumasterupdatepipeline)

            //change in menudesign
            const menudesignupdatepipeline = [
                { 'menudesigndata.iconid': req.body._id },
                {
                    $set: {
                        'menudesigndata.$.iconimage': req.body.iconimage,
                    }
                }
            ]
            await MainDB.UpdateMany('tblmenudesignmaster', new _MenuDesign(), menudesignupdatepipeline)

            //Change in tblmenuassignmaster
            await MainDB.UpdateMany('tblmenuassignmaster', new _MenuAssign(), menumasterupdatepipeline)

            req.ResponseBody = ResponseBody
            next()
        }
        catch (err) {
            req.ResponseBody = { status: 500, message: Config.resstatuscode["500"], err }
            next()
        }
	}

	// Delete
	async DeleteIcon(req, res, next) {
		try {

            var ResponseBody = {}
            //Dependency Check
            const menuObjModel = await MainDB.createmodel('tblmenumaster', new _Menu())
            const moduleObjModel = await MainDB.createmodel('tblmodulemaster', new _Module())
            const menuAssignObjModel = await MainDB.createmodel('tblmenuassignmaster', new _MenuAssign())
            var dependency = [
                [menuObjModel['objModel'], { iconid: req.body._id }, "Menu"],
                [moduleObjModel['objModel'], { iconid: req.body._id }, "Module"],
                [menuAssignObjModel['objModel'], { iconid: req.body._id }, "Menu Assign"]
            ]

            const resp = await MainDB.executedata('d', new _Icon(), TableName, req.body, true, dependency)

            ResponseBody.status = resp.status
            ResponseBody.message = resp.message

            req.ResponseBody = ResponseBody
            next()
        }
        catch (err) {
            req.ResponseBody = { status: 500, message: Config.resstatuscode["500"], err }
            next()
        }
	}
}
