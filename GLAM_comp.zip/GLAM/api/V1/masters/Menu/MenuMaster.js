import { IISMethods,MainDB, Config} from "../../../../config/Init.js"
import _ModuleType from "../../../../model/masters/Menu/Moduletype.js"
import _UserRights from "../../../../model/masters/UserManagement/Userrights.js"
import _Icon from "../../../../model/masters/Menu/Icon.js"
import _Menu from "../../../../model/masters/Menu/Menu.js"
import _MenuAssign from "../../../../model/masters/Menu/MenuAssign.js"
import _MenuDesign from "../../../../model/masters/Menu/MenuDesign.js"

const TableName = "tblmenumaster"
const PageName = "Menu"
const FormName = "Menu"
const FltPageCollection = "menumaster"

export default class MenuMaster {
	// List Menu
	async ListMenu(req, res, next) {
		try {
            const ResponseBody = {}
            var pipeline = []
            const { searchtext = "", paginationinfo: { pageno = 1, nextpageid = "", pagelimit = 20, filter = {}, sort = {}, projection = {} } } = req.body || {}

            const requiredPage = {
                pageno: pageno,
                nextpageid: nextpageid,
                skip: (pageno - 1) * pagelimit,
                pagelimit: pagelimit
            }
            const sortData = Object.keys(sort).length !== 0 ? sort : { _id: -1 }
            pipeline = IISMethods.GetPipelineForFilter(filter)

			if (searchtext !== "") {
				pipeline.push(...IISMethods.GetGlobalSearchFilter(new _Menu(), searchtext))
			}

			const resp = await MainDB.getmenual(TableName, new _Menu(), pipeline, requiredPage, sortData, true,"",projection)

			ResponseBody.pagename = PageName
			ResponseBody.formname = FormName
			ResponseBody.fltpagecollection = FltPageCollection
			ResponseBody.status = 200
			ResponseBody.message = Config.getResponsestatuscode()["200"]
			ResponseBody.data = resp.ResultData
		    ResponseBody.currentpage = resp.currentpage
            ResponseBody.nextpage = resp.nextpage
            ResponseBody.totaldocs = resp.totaldocs
			ResponseBody.fieldorder = resp.fieldorderdata
			ResponseBody.formfieldorderdata = resp.formfieldorderdata 

			req.ResponseBody = ResponseBody
			next()
		} catch (err) {
			req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
			next()
		}
	}

	// Insert Menu
	async InsertMenu(req, res, next) {
		try {
            const ObjectId = IISMethods.getobjectid()
            var ResponseBody = {}

            const pipelineForIcon = [{ $match: { _id: new ObjectId(req.body.iconid) } }]
            let respicon = await MainDB.getmenual('tbliconmaster', new _Icon(), pipelineForIcon)
            respicon = respicon.ResultData[0]

            //Setting Icon Data
            req.body.iconid = respicon._id
            req.body.iconimage = respicon.iconimage

            const resp = await MainDB.executedata('i', new _Menu(), TableName, req.body)
           
            ResponseBody.status = resp.status
            ResponseBody.message = resp.message
			ResponseBody.data = resp.data

            req.ResponseBody = ResponseBody
            next()
        }
        catch (err) {
            req.ResponseBody = { status: 500, message: Config.resstatuscode["500"], err }
            next()
        }
	}

	// Update Menu
	async UpdateMenu(req, res, next) {
		try {

            var ResponseBody = {}
            const ObjectId = IISMethods.getobjectid()
            const pipeline = [{ $match: { '_id': new ObjectId(req.body._id) } }]
            const record = await MainDB.getmenual(TableName, new _Menu(), pipeline)

            var RecordInfo = record.ResultData[0].recordinfo
            RecordInfo.updateuid = req.headers.uid
            RecordInfo.updateby = req.headers.personname
            RecordInfo.updatedate = IISMethods.getdatetimeisostr()
            req.body.recordinfo = RecordInfo

            const moduletypes = req.body.moduletype.map((item) => item.moduletypeid)

            const pipelineForcheckmenuassign = [{ $match: { menuid: new ObjectId(req.body._id) } }]
            let resultofcheckmenuassign = await MainDB.getmenual('tblmenuassignmaster', new _MenuAssign(), pipelineForcheckmenuassign)
            resultofcheckmenuassign = resultofcheckmenuassign.ResultData

            const checkAssign = resultofcheckmenuassign.map((item) => moduletypes.includes(item.moduletypeid));

            if (!checkAssign.every(Boolean)) {
                ResponseBody.status = 404
                ResponseBody.message = Config.errmsg['menualreadyassign']
            } else {
                const pipelineForIcon = [{ $match: { _id: new ObjectId(req.body.iconid) } }]
                let respicon = await MainDB.getmenual('tbliconmaster', new _Icon(), pipelineForIcon)
                respicon = respicon.ResultData[0]

                //Setting Icon Data
                req.body.iconid = respicon?._id
                req.body.iconimage = respicon?.iconimage

                req.body.recordinfo = RecordInfo

                var resp

                resp = await MainDB.executedata('u', new _Menu(), TableName, req.body)
                ResponseBody.status = resp.status
                ResponseBody.message = resp.message
                ResponseBody.data = resp.data

                if (resp && resp.status == 200) {

                    //change in userrights
                    const userrightsUpdatePipeline = [{ alias: req.body.alias }, { $set: { formname: req.body.formname, } }]
                    await MainDB.UpdateMany('tbluserrights', new _UserRights(), userrightsUpdatePipeline)

                    //change in menu design table
                    const menudesignupdatepipeline = [
                        { 'menudesigndata.menuid': req.body._id },
                        {
                            $set: {
                                'menudesigndata.$.menuname': req.body.menuname,
                                'menudesigndata.$.formname': req.body.formname,
                                'menudesigndata.$.iconid': req.body.iconid,
                                'menudesigndata.$.iconimage': req.body.iconimage,
                                'menudesigndata.$.alias': req.body.alias,
                                'menudesigndata.$.containright': req.body.containright,
                                'menudesigndata.$.defaultopen': req.body.defaultopen,
                                'menudesigndata.$.displayinsidebar': req.body.displayinsidebar,
                                'menudesigndata.$.moduletypeid': req.body.moduletypeid,
                                'menudesigndata.$.canhavechild': req.body.canhavechild,
                            }
                        }
                    ]
                    await MainDB.UpdateMany('tblmenudesignmaster', new _MenuDesign(), menudesignupdatepipeline)

                    //Change in tblmenuassignmaster
                    const menuassignUpdatePipeline = [
                        { menuid: req.body._id },
                        {
                            $set:
                            {
                                menuname: req.body.menuname,
                                formname: req.body.formname,
                                iconid: req.body.iconid,
                                iconimage: req.body.iconimage,
                                alias: req.body.alias,
                                containright: req.body.containright,
                                defaultopen: req.body.defaultopen,
                                displayinsidebar: req.body.displayinsidebar,
                                moduletypeid: req.body.moduletypeid,
                                canhavechild: req.body.canhavechild,
                                forios: req.body.forios,
                                forandroid: req.body.forandroid
                            }
                        }
                    ]
                    await MainDB.UpdateMany('tblmenuassignmaster', new _MenuAssign(), menuassignUpdatePipeline)
                }
            }

            req.ResponseBody = ResponseBody
            next()
        }
        catch (err) {
            req.ResponseBody = { status: 500, message: Config.resstatuscode["500"], err }
            next()
        }
	}

	// Delete Menu
	async DeleteMenu(req, res, next) {
		try {
            var ResponseBody = {}

            // Menu Assign
            //Dependency Check
            const menuAssignObjModel = await MainDB.createmodel('tblmenuassignmaster', new _MenuAssign())

            var dependency = [[menuAssignObjModel['objModel'], { menuid: req.body._id }, "MenuAssign"]]

            const resp = await MainDB.executedata('d', new _Menu(), TableName, req.body, true, dependency)

            ResponseBody.status = resp.status
            ResponseBody.message = resp.message

            req.ResponseBody = ResponseBody
            next()
        }
        catch (err) {
            req.ResponseBody = { status: 500, message: Config.resstatuscode["500"], err }
            next()
        }
	}


	async MasterMenu(req, res, next) {
        var ResponseBody = {}
        var menuData
        const ObjectId = IISMethods.getobjectid()

        const loginPlatformType = parseInt(req.headers.platform);
        const moduleTypeId = loginPlatformType === 1 ? Config.moduletype['web'] :
            loginPlatformType === 2 ? Config.moduletype['app'] :
                loginPlatformType === 3 ? Config.moduletype['app'] :
                    Config.moduletype['app'];

        const person = await MainDB.getEmployeeData(req.headers.uid)
		
        const menupipline = [{ $match: { "moduletype.moduletypeid": ObjectId(moduleTypeId), ismaster: 1 } }, { $sort: { menuname: 1 } }]
        const searchtext = req.body.searchtext || ""
        if (searchtext !== "") {
            menupipline.push(...IISMethods.GetGlobalSearchFilter(new _Menu(), searchtext, ["menuname"]))
        }
        const assignResp = await MainDB.getmenual('tblmenumaster', new _Menu(), menupipline)

        const assignResponseData = assignResp.ResultData

        if (person.isadmin) {
            menuData = assignResponseData
        } else {
            var rightsResponseData = []

            //Get user rights with userid
            const rightsRespwithuser = await MainDB.getmenual('tbluserrights', new _UserRights(), [
                { $match: { personid: person._id.toString() } },
                { $match: { moduletypeid: moduleTypeId } },
                { $match: { $or: [{ allviewright: 1 }, { selfviewright: 1 }] } },])

            if (rightsRespwithuser.ResultData.length == 0) {

                let rolesFrom = person.userrole.map(function (rl) { return rl.userroleid.toString() })

                var userrightswithrolepipeline = [
                    { $match: { moduletypeid: moduleTypeId } },
                    { $match: { $or: [{ allviewright: 1 }, { selfviewright: 1 }] } },
                    { $match: { userroleid: { $in: rolesFrom } } }
                ]

                const rightsRespwithuserrole = await MainDB.getmenual('tbluserrights', new _UserRights(), userrightswithrolepipeline)
                rightsResponseData = rightsRespwithuserrole.ResultData
            }
            else {
                rightsResponseData = rightsRespwithuser.ResultData
            }

            menuData = assignResponseData.filter((menu) => rightsResponseData.find((item) => item.alias == menu.alias))
        }

        ResponseBody.pagename = "Master Menu"
        ResponseBody.status = 200
        ResponseBody.message = Config.resstatuscode['200']
        ResponseBody.data = menuData

        req.ResponseBody = ResponseBody
        next()
    }

}
