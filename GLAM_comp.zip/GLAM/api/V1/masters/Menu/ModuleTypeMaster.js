import { IISMethods, Config, MainDB } from "../../../../config/Init.js"
import _ModuleType from "../../../../model/masters/Menu/Moduletype.js"

const TableName = "tblmoduletype"
const PageName = "Module Type"
const FormName = "Module Type"

export default class ModuleTypeMaster {
	// List
	async ListModuleType(req, res, next) {
		try {
            var ResponseBody = {}
            var pipeline = []
            const { searchtext = "", paginationinfo: { pageno = 1, nextpageid = "", pagelimit = 20, filter = {}, sort = {}, projection = {} } } = req.body || {}

            const requiredPage = {
                pageno: pageno,
                nextpageid: nextpageid,
                skip: (pageno - 1) * pagelimit,
                pagelimit: pagelimit
            }
            const sortData = Object.keys(sort).length !== 0 ? sort : { _id: -1 }
            pipeline = IISMethods.GetPipelineForFilter(filter)

			if (req.headers.pagename != "releasemaster") {
				pipeline.push({ $match: { isrelease: 0 } })
			}

			const resp = await MainDB.getmenual(TableName, new _ModuleType(), pipeline, requiredPage, sortData, true, "", projection)

			ResponseBody.pagename = PageName
			ResponseBody.formname = FormName
			ResponseBody.status = 200
			ResponseBody.message = Config.getResponsestatuscode()["200"]
			ResponseBody.data = resp.ResultData

			req.ResponseBody = ResponseBody
			next()
		} catch (err) {
			req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
			next()
		}
	}

	// End ModuleType Master
}
