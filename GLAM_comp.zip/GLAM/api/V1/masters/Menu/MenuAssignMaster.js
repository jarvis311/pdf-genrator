import { IISMethods, MainDB,Config } from "../../../../config/Init.js"
import _Icon from "../../../../model/masters/Menu/Icon.js"
import _Menu from "../../../../model/masters/Menu/Menu.js"
import _MenuAssign from "../../../../model/masters/Menu/MenuAssign.js"
import _MenuDesign from "../../../../model/masters/Menu/MenuDesign.js"

const TableName = "tblmenuassignmaster"
const PageName = "menuassign"
const FormName = "menuassign"
const FltPageCollection = "menuassignmaster"

export default class MenuAssignMaster {

	// List Menu Assign
		async ListMenuAssign(req, res, next) {
			try {

				var ResponseBody = {}
				const ObjectId = IISMethods.getobjectid()
				var PaginationInfo = req.body.paginationinfo
	
				const { moduletypeid = "", moduleid = "" } = PaginationInfo.filter

				const menuassignPipeline = [{ $match: { moduletypeid: moduletypeid } }]
				const menuassignResp = await MainDB.getmenual(TableName, new _MenuAssign(), menuassignPipeline)
	
				const menuPipeline = [{ $match: { "moduletype.moduletypeid": ObjectId(moduletypeid) } }, { $sort: { menuname: 1 } }]

				const searchtext = req.body.searchtext || ""
				if (searchtext !== "") {
					menuPipeline.push(...IISMethods.GetGlobalSearchFilter(new _MenuAssign(), searchtext))
				}

				const menuResp = await MainDB.getmenual("tblmenumaster", new _Menu(), menuPipeline)
	
				let Menu = []
	
				menuResp.ResultData.forEach((menu) => {
					menu.isassigned = 0
					menu.isparent = 0
					menu.parentid = ""
	
	
					const menuassign = menuassignResp.ResultData.find((menuassign) => menu._id.toString() === menuassign.menuid.toString() && menuassign.moduleid.toString() == moduleid.toString())
					if (menuassign) {
	
						menu.isassigned = 1
						menu.isparent = menuassign.isparent
						menu.parentid = menuassign.parentid || ""
	
						Menu.push(menu)
	
					} else {
	
						const otherAssigned = menuassignResp.ResultData.find((menuassign) => menu._id.toString() == menuassign.menuid.toString() && menuassign.moduleid.toString() != moduleid.toString())
	
						if (otherAssigned == undefined) {
							Menu.push(menu)
						}
					}
	
				})
	
				const MenuAssign = new _MenuAssign()
					
				ResponseBody.pagename = PageName
				ResponseBody.formname = FormName
				ResponseBody.fltpagecollection = FltPageCollection
				ResponseBody.status = 200
				ResponseBody.message = Config.getResponsestatuscode()["200"]
				ResponseBody.data = Menu
				ResponseBody.totaldocs = menuResp.totaldocs;
				ResponseBody.fieldorder = MenuAssign.getFieldOrder()
	
				req.ResponseBody = ResponseBody
				next()
			}
			catch (err) {
				req.ResponseBody = { status: 500, message: Config.resstatuscode["500"], err }
				next()
			}
		}


	// Update Menu Assign
	async UpdateMenuAssign(req, res, next) {
		try {

            var ResponseBody = {}
            const ObjectId = IISMethods.getobjectid()
            const recordpipeline = [{ $match: { '_id': ObjectId(req.body._id) } }]
            const record = await MainDB.getmenual('tblmenuassignmaster', new _MenuAssign(), recordpipeline)

            //TODO: add moduletype to pipeline
            const pipeline = { 'moduleid': req.body.moduleid, 'moduletypeid': req.body.moduletypeid }

            var RecordInfo = {}
            RecordInfo.updateuid = req.headers.uid
            RecordInfo.updateby = req.headers.personname
            RecordInfo.updatedate = IISMethods.getdatetimeisostr()
            req.body.recordinfo = RecordInfo

            var assigningData = []

            req.body.data.forEach(data => {
                let MenuAssign = data
                MenuAssign.recordinfo = RecordInfo
                MenuAssign.moduleid = req.body.moduleid
                MenuAssign.moduletypeid = req.body.moduletypeid
                assigningData.push(MenuAssign)
            })

            //Deleting previous assign data
            await MainDB.DeleteMany('tblmenuassignmaster', new _MenuAssign(), pipeline)

            //inserting new assign data
            const resp = await MainDB.InsertMany('tblmenuassignmaster', new _MenuAssign(), assigningData)

            ResponseBody.status = resp.status
            ResponseBody.message = resp.message

            req.ResponseBody = ResponseBody
            next()
        }
        catch (err) {
            req.ResponseBody = { status: 500, message: Config.resstatuscode["500"], err }
            next()
        }
	}

}
