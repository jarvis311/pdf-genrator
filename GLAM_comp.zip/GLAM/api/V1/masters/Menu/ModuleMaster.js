import { IISMethods, Config,MainDB } from "../../../../config/Init.js"
import _ModuleType from "../../../../model/masters/Menu/Moduletype.js"
import _Icon from "../../../../model/masters/Menu/Icon.js"
import _MenuAssign from "../../../../model/masters/Menu/MenuAssign.js"
import _MenuDesign from "../../../../model/masters/Menu/MenuDesign.js"
import _Module from '../../../../model/masters/Menu/Module.js'

const TableName = "tblmodulemaster"
const PageName = "Module"
const FormName = "Module"
const FltPageCollection = "modulemaster"

export default class ModuleMaster {
	// List Module
	async ListModule(req, res, next) {
		try {
			var ResponseBody = {}
			 
			var PaginationInfo = req.body.paginationinfo
            const ObjectId = IISMethods.getobjectid()

            const requiredPage = { pageno: PaginationInfo.pageno, skip: (PaginationInfo.pageno - 1) * PaginationInfo.pagelimit, pagelimit: PaginationInfo.pagelimit }
            var pipeline = []
            var sort = (Object.keys(PaginationInfo.sort).length !== 0 ? PaginationInfo.sort : { '_id': -1 })

            if (PaginationInfo.filter.moduletypeid) {
                pipeline.push({ $match: { "moduletype.moduletypeid": ObjectId(PaginationInfo.filter.moduletypeid) } })
                delete PaginationInfo.filter.moduletypeid
            }

            pipeline = IISMethods.GetPipelineForFilter(PaginationInfo.filter)

            const searchtext = req.body.searchtext || ""
            if (searchtext !== "") {
                pipeline.push(...IISMethods.GetGlobalSearchFilter(new _Module(), searchtext))
            }
            let projection = PaginationInfo.projection ? PaginationInfo.projection : {}

            const resp = await MainDB.getmenual(TableName, new _Module(), pipeline, requiredPage, sort, true, "", projection)

			ResponseBody.pagename = PageName
			ResponseBody.formname = FormName
			ResponseBody.fltpagecollection = FltPageCollection
			ResponseBody.status = 200
			ResponseBody.message = Config.getResponsestatuscode()["200"]
			ResponseBody.data = resp.ResultData
            ResponseBody.currentpage = resp.currentpage
            ResponseBody.nextpage = resp.nextpage
            ResponseBody.totaldocs = resp.totaldocs
			ResponseBody.fieldorder = resp.fieldorderdata
            ResponseBody.formfieldorderdata = resp.formfieldorderdata 

			req.ResponseBody = ResponseBody
			next()
		} catch (err) {
			req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
			next()
		}
	}

	// Insert Module
	async InsertModule(req, res, next) {
		try {
			const ObjectId = IISMethods.getobjectid()
            var ResponseBody = {}

            const pipelineIcon = [{ $match: { _id: ObjectId(req.body.iconid) } }]
            let respicon = await MainDB.getmenual('tbliconmaster', new _Icon(), pipelineIcon)
            respicon = respicon.ResultData[0]

            if (!respicon) {
                ResponseBody.status = 400
                ResponseBody.message = Config.errmsg["invalidicon"]
            } else {
                //Setting Icon Data
                req.body.iconid = respicon._id
                req.body.iconimage = respicon.iconimage

                const resp = await MainDB.executedata('i', new _Module(), TableName, req.body)
                
                ResponseBody.status = resp.status
                ResponseBody.message = resp.message
				ResponseBody.data = resp.data
            }

            req.ResponseBody = ResponseBody
            next()
		} catch (err) {
			req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
			next()
		}
	}

	// Update Module
	async UpdateModule(req, res, next) {
		try {
			var ResponseBody = {}
            const ObjectId = IISMethods.getobjectid()
            const pipeline = [{ $match: { '_id': ObjectId(req.body._id) } }]
            const record = await MainDB.getmenual(TableName, new _Module(), pipeline)

            var RecordInfo = record.ResultData[0].recordinfo
            RecordInfo.updateuid = req.headers.uid
            RecordInfo.updateby = req.headers.personname
            RecordInfo.updatedate = IISMethods.getdatetimeisostr()
            req.body.recordinfo = RecordInfo

            const pipelineForIcon = [{ $match: { '_id': ObjectId(req.body.iconid) } }]
            let respicon = await MainDB.getmenual('tbliconmaster', new _Icon(), pipelineForIcon)
            respicon = respicon.ResultData[0]

            if (!respicon) {
                ResponseBody.status = 400
                ResponseBody.message = Config.errmsg["invalidicon"]
            } else {
                //Setting Icon Data
                req.body.iconid = respicon._id
                req.body.iconimage = respicon.iconimage

                const resp = await MainDB.executedata('u', new _Module(), TableName, req.body)

                if (resp.status == 200) {

                    //Change in tblmenuassignmaster
                    const menuassignUpdatePipeline = [
                        { moduleid: req.body._id },
                        { $set: { module: req.body.module } }
                    ]
                    await MainDB.UpdateMany('tblmenuassignmaster', new _MenuAssign(), menuassignUpdatePipeline)

                    //Change in tblmenudesignmaster
                    const menuDesignUpdatePipeline = [
                        { 'menudesigndata.moduleid': req.body._id },
                        {
                            $set: {
                                'menudesigndata.$.module': req.body.module,
                                'menudesigndata.$.moduletypeid': req.body.moduletypeid,
                                'menudesigndata.$.iconimage': req.body.iconimage,
                                'menudesigndata.$.iconid': req.body.iconid
                            }
                        }
                    ]
                    await MainDB.UpdateMany('tblmenudesignmaster', new _MenuDesign(), menuDesignUpdatePipeline)
                }
                ResponseBody.status = resp.status
                ResponseBody.data = resp.data
                ResponseBody.message = resp.message
            }

            req.ResponseBody = ResponseBody
            next()
		} catch (err) {
			req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
			next()
		}
	}

	// Delete Module
	async DeleteModule(req, res, next) {
		try {
            var ResponseBody = {}
            ResponseBody.status = 401
            ResponseBody.message = Config.resstatuscode['401']

            const menuassignObjModel = await MainDB.createmodel("tblmenuassignmaster", new _MenuAssign())
            const menudesignObjModel = await MainDB.createmodel("tblmenudesignmaster", new _MenuDesign())
            
            var dependency = [
                [menuassignObjModel['objModel'], { moduleid: req.body._id }, "MenuAssign"],
                [menudesignObjModel['objModel'], { "menudesigndata.moduleid": req.body._id }, "MenuDesign"],
            ]

            const resp = await MainDB.executedata('d', new _Module(), TableName, req.body, true, dependency)

            ResponseBody.status = resp.status
            ResponseBody.message = resp.message

            req.ResponseBody = ResponseBody
            next()
        }
        catch (err) {
            req.ResponseBody = { status: 500, message: Config.resstatuscode["500"], err }
            next()
        }
	}
}
