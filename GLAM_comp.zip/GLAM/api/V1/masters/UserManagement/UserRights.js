import { IISMethods,MainDB, Config } from "../../../../config/Init.js"
import _Menu from "../../../../model/masters/Menu/Menu.js"
import _Userrights from "../../../../model/masters/UserManagement/Userrights.js"
import _MenuAssign from "../../../../model/masters/Menu/MenuAssign.js"

const TableName = "tbluserrights"
const PageName = "userrights"
const FormName = "User Rights"
const FltPageCollection = "userrights"

class UserRights {
	// List User Rights
	async ListUserrights(req, res, next) {
		try {
            var ResponseBody = {}
            const ObjectId = IISMethods.getobjectid()
            var pipeline = []
            const personid = req.body.personid
			let propertyid = req.headers.propertyid 

            // const loginPlatformType = parseInt(req.body.moduleType);
            const moduleTypeId = req.body.moduletypeid == Config.moduletype['app'] ? Config.moduletype['app'] : Config.moduletype['web'];

            if (personid != '' && personid != 'undefined' && personid != 'null') {
                pipeline.push({ $match: { personid: personid, moduletypeid: moduleTypeId,propertyid: propertyid } })
            }
            else {
                pipeline.push({ $match: { userroleid: req.body.userroleid, moduletypeid: moduleTypeId,propertyid: propertyid } })
            }

            pipeline.push({ "$sort": { "formname": req.body.sort } })

            var resp = await MainDB.getmenual('tbluserrights', new _Userrights(), pipeline)

            if (resp.ResultData.length == 0 && personid) {
                let rolePipeline = [{ $match: { userroleid: req.body.userroleid, moduletypeid: moduleTypeId,propertyid: propertyid } }]
                resp = await MainDB.getmenual('tbluserrights', new _Userrights(), rolePipeline)
            }

            const UserRights = new _Userrights()

            // menu assign data
            let menuassignpipeline = [{ $match: { moduletypeid: moduleTypeId } }, { $sort: { _id: 1 } }, { $project: { 'alias': 1, 'moduleid': 1 } }]
            const menuassign = await MainDB.getmenual('tblmenuassignmaster', new _MenuAssign(), menuassignpipeline)

            // menu data
            let menupipeline = [
                { $match: { 'containright': 1 }, $match: { "moduletype.moduletypeid": new ObjectId(moduleTypeId) } },
                {
                    "$addFields": {
                        "allviewright": 0, "selfviewright": 0, "alladdright": 0, "selfaddright": 0, "alleditright": 0, "selfeditright": 0,
                        "alldelright": 0, "selfdelright": 0, "allexportdata": 0, "allimportdata": 0,
                        "allprintright": 0, "selfprintright": 0, "requestright": 0, "changepriceright": 0, "allfinancialdata": 0, "selffinancialdata": 0
                    }
                },
                { "$unset": ["iconid", "iconimage", "moduletypeid", "moduletype", "defaultopen", "containright", "recordinfo", "__v",] },
                { "$sort": { "formname": req.body.sort } },
            ]
            const menuResp = await MainDB.getmenual('tblmenumaster', new _Menu(), menupipeline)

            let newdata = []
            if (resp.ResultData.length == 0) {
                newdata = menuResp.ResultData
            }
            else {
                //get menu data and match with rights
                var combineData = []

                //add from rights only if it exists in menu
                resp.ResultData.forEach(function (rightObj) {
                    var isExist = menuResp.ResultData.find(menuObj => menuObj.alias == rightObj.alias)
                    if (isExist !== undefined) {
                        combineData.push(rightObj)
                    }
                })

                //add from menu if new menu found
                menuResp.ResultData.forEach(function (menuObj) {
                    var isExist = resp.ResultData.find(rightObj => rightObj.alias == menuObj.alias)
                    if (isExist === undefined) {
                        combineData.push(menuObj)
                    }
                })
                newdata = combineData
            }

            for (const iterator of newdata) {
                let menufind = menuassign.ResultData.find((o) => o.alias == iterator.alias)
                if (menufind) {
                    iterator.moduleid = menufind.moduleid
                } else {
                    iterator.moduleid = ""
                }
            }


            ResponseBody.status = 200
            ResponseBody.message = Config.resstatuscode['200']
            ResponseBody.data = newdata
            ResponseBody.pagename = "userrights"
            ResponseBody.fieldorder = UserRights.getFieldOrder()

            req.ResponseBody = ResponseBody
            next()
        }
        catch (err) {
            console.log(err)
        }
	}

	// Update rights
	async UpdateUserrights(req, res, next) {
		 try {
			const ObjectId = IISMethods.getobjectid()
            // const personid = req.body.personid === "*" ? Config.getAllPersonid() : req.body.personid
            const personid = req.body.personid
			let propertyid = req.headers.propertyid
            const moduleTypename = req.body.moduletypeid === Config.moduletype['app'] ? 'app' : 'Web';

            var RecordInfo = {
                entryuid: req.headers.uid,
                entryby: req.headers.personname,
                entrydate: IISMethods.getdatetimeisostr(),
                timestamp: IISMethods.GetTimestamp(),
                isactive: 1
            }

            var newData = []

            req.body.data.forEach(data => {
                let UserRights = Object.assign(new _Userrights(), data)
                delete UserRights._id
                UserRights.personid = personid
                UserRights.moduletypeid = req.body.moduletypeid
				UserRights.propertyid = propertyid
                UserRights.moduletype = moduleTypename
                req.body.personid == '' || req.body.personid == null ? UserRights.userroleid = req.body.userroleid : UserRights.userroleid = ''
                UserRights.recordinfo = RecordInfo
                newData.push(UserRights)
            })

            var delpipeline = {}

            if (req.body.personid != '') {
                delpipeline = {
                    'moduletypeid': req.body.moduletypeid,
                    'personid': personid,
					'propertyid': ObjectId(propertyid),
                }
            }
            else {
                delpipeline = {
                    'moduletypeid': req.body.moduletypeid,
                    'userroleid': req.body.userroleid,
					'propertyid': ObjectId(propertyid)
                }
            }

            let isblank = 1

            //check if all zero
            req.body.data.some(function (data) {
                if (data.alladdright === 1 || data.alldelright === 1 || data.alleditright === 1 ||
                    data.allprintright === 1 || data.allviewright === 1 || data.requestright === 1 || data.selfaddright === 1 ||
                    data.selfdelright === 1 || data.selfeditright === 1 || data.selfprintright === 1 || data.selfviewright === 1 ||
                    data.allexportdata === 1 || data.allimportdata === 1) {
                    isblank = 0
                    return true;
                }
            })

            var resp

            //TODO :

            //Deleting previous assign data
            resp = await MainDB.DeleteMany('tbluserrights', new _Userrights(), delpipeline)

            if (isblank === 0) {
                //inserting new assign data
                resp = await MainDB.InsertMany('tbluserrights', new _Userrights(), newData)
            }

            var ResponseBody = {}
            ResponseBody.status = resp.status
            ResponseBody.message = resp.message

            req.ResponseBody = ResponseBody
            next()
        }
        catch (err) {
            console.log(err)
        }
	}
}

export default UserRights
