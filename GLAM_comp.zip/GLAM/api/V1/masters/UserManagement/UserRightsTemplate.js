import { IISMethods, Config ,MainDB} from "../../../../config/Init.js"
import _UserRightsTemplate from "../../../../model/masters/UserManagement/UserRightsTemplate.js"

const TableName = "tbluserrightstemplate"

class UserRightsTemplate {
	// Template Rights
	async ListTemplateRights(req, res, next) {
		try {
			const ResponseBody = {}
			const ObjectId = IISMethods.getobjectid()

			const {
				searchtext = "",
				paginationinfo: { projection = {}, nextpageid = "", pageno = 1, pagelimit = 10, filter = {}, sort = {} }
			} = req.body || {} 

			const requiredPage = {
				nextpageid: nextpageid,
                pageno: pageno,
                skip: (pageno - 1) * pagelimit,
				pagelimit: pagelimit
			}

			const sortData = Object.keys(sort).length !== 0 ? sort : { _id: -1 }

			const pipeline = IISMethods.GetPipelineForFilter(filter)

			if (searchtext !== "") {
				pipeline.push(...IISMethods.GetGlobalSearchFilter(new _UserRightsTemplate(), searchtext))
			}

			if (req.body._id) {
				pipeline.push({
					$match: {
						_id: ObjectId(req.body._id),
					}
				})
			}
			// else if (!filter.propertyid) {
			// 	pipeline.push(
			// 		{
			// 			$match: {
			// 				propertyid: ObjectId(req.headers.propertyid),
			// 			}
			// 		}
			// 	)
			// }
			var isAdmin = await MainDB.IsAdmin(req.headers.uid)

            var objuids = []
            if (!isAdmin) {
                if (!req.userauth.rights.all && req.userauth.rights.self) {
                    pipeline.push({ $match: { "recordinfo.entryuid": req.headers.uid } })
                } else {
                    req.userauth.uid.forEach(function (uid) {
                        objuids.push(uid)
                    })
                    pipeline.push({ $match: { "recordinfo.entryuid": { $in: objuids } } })
                }
            }

			const resp = await MainDB.getmenual(TableName, new _UserRightsTemplate(), pipeline, requiredPage, sortData, true, "", projection) 

			ResponseBody.data = resp.ResultData
			ResponseBody.nextpage = resp.nextpage
			ResponseBody.pagename = "User Rights Template"
			ResponseBody.formname = "User Rights Template"
			ResponseBody.fltpagecollection = "userrightstemplate"
			ResponseBody.status = 200
			ResponseBody.message = Config.getResponsestatuscode()["200"]
			const DefaultUserRights = new _UserRightsTemplate()
			if (req.body._id) {
				ResponseBody.fieldorder = DefaultUserRights.getRightsOrder()
			} else {
				ResponseBody.fieldorder = resp.fieldorderdata
			}
			req.ResponseBody = ResponseBody
			next()
		} catch (err) {
			req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
			next()
		}
	}

	async InsertTemplateRights(req, res, next) {
		try {
			const ResponseBody = {}
			const ObjectId = IISMethods.getobjectid()

			const TemplateRightsPipeline = [
				{
					$match: {
						templatename: req.body.templatename,
						moduletypeid: ObjectId(req.body.moduletypeid),
						// propertyid: ObjectId(req.headers.propertyid)
					}
				}
			]
			const defaultuserrightsResp = await MainDB.getmenual(TableName, new _UserRightsTemplate(), TemplateRightsPipeline)

			if (!defaultuserrightsResp.ResultData.length) {
				// req.body.propertyid = req.headers.propertyid
				// req.body.property = req.headers.propertyname
				const resp = await MainDB.executedata("i", new _UserRightsTemplate(), TableName, req.body)

				ResponseBody.status = resp.status
				ResponseBody.message = resp.message
			} else {

				ResponseBody.status = 400
				ResponseBody.message = Config.getErrmsg()["isexist"]
			}

			req.ResponseBody = ResponseBody
			next()
		} catch (err) {
			req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
			next()
		}
	}

	async UpdateTemplateRights(req, res, next) {
		try {
			const ResponseBody = {}
			const ObjectId = IISMethods.getobjectid()

			const Pipeline = {
				_id: req.body._id
			}
			const Resp = await MainDB.FindOne(TableName, new _UserRightsTemplate(), Pipeline)

			if (Resp) {

				const TemplateRightsPipeline = [
					{
						$match: {
							_id: { $ne: ObjectId(req.body._id) },
							templatename: req.body.templatename,
							moduletypeid: ObjectId(req.body.moduletypeid),
							// propertyid: ObjectId(req.headers.propertyid)
						}
					}
				]
				const defaultuserrightsResp = await MainDB.getmenual(TableName, new _UserRightsTemplate(), TemplateRightsPipeline)

				if (!defaultuserrightsResp.ResultData.length) {
					// req.body.propertyid = req.headers.propertyid
					// req.body.property = req.headers.propertyname
					const RecordInfo = Resp.recordinfo
					RecordInfo.updateuid = req.headers.uid
					RecordInfo.updateby = req.headers.personname
					RecordInfo.updatedate = IISMethods.getdatetimestr()
					req.body.recordinfo = RecordInfo

					const resp = await MainDB.executedata("u", new _UserRightsTemplate(), TableName, req.body)

					ResponseBody.status = resp.status
					ResponseBody.message = resp.message
				} else {

					ResponseBody.status = 400
					ResponseBody.message = Config.getErrmsg()["isexist"]
				}
			} else {
				ResponseBody.status = 404
				ResponseBody.message = Config.getErrmsg()["notexist"]
			}


			req.ResponseBody = ResponseBody
			next()
		} catch (err) {
			req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
			next()
		}
	}

	//Delete
	async DeleteTemplateRights(req, res, next) {
		try {
			const ResponseBody = {}

			const resp = await MainDB.executedata("d", new _UserRightsTemplate(), TableName, req.body)

			ResponseBody.status = resp.status
			ResponseBody.message = resp.message

			req.ResponseBody = ResponseBody; next()
		} catch (err) {

			req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }; next()
		}
	}
}

export default UserRightsTemplate
