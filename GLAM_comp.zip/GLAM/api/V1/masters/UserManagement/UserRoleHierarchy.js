import { IISMethods, Config,MainDB } from "../../../../config/Init.js"
import _UserRoleHierarchy from "../../../../model/masters/UserManagement/UserRoleHierarchy.js"
import _Userrole from "../../../../model/masters/UserManagement/Userrole.js"

const TableName = "tbluserrolehierarchy"
const PageName = "User Role Hierarchy"
const FormName = "User Role Hierarchy"
const FltPageCollection = "userrolehierarchy"

export default class UserRoleHierarchy {

    async ListUserRoleHierarchy(req, res, next) {
        try {
            const ResponseBody = {}
            const ObjectId = IISMethods.getobjectid()
            
            var hierarchydata = []

            const resp = await MainDB.FindOne("tbluserrolehierarchy", new _UserRoleHierarchy(), {})

            const userrolepipeline = [{ $match: { _id: new ObjectId(Config.adminutype) } }]

            //get super admin user role
            const userroleresp = await MainDB.getmenual('tbluserrolemaster', new _Userrole(), userrolepipeline)

            const adminuserrolename = userroleresp.ResultData[0].userrole

            if (!resp) {
                hierarchydata = { _id: Config.adminutype, id: "superadmin", name: adminuserrolename, title: adminuserrolename, children: [] }
            } else {
                hierarchydata = Object.assign(resp.userrolehierarchy)
            }


            ResponseBody.pagename = PageName
            ResponseBody.formname = FormName
            ResponseBody.fltpagecollection = FltPageCollection
            ResponseBody.message = Config.getResponsestatuscode()["200"]
            ResponseBody.status = 200
            ResponseBody.data = hierarchydata

            req.ResponseBody = ResponseBody; next()
        } catch (err) {
            
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }; next()
        }
    }

    //add hierarchy
    async UpdateUserRoleHirarchy(req, res, next) {
        try {
              //Deleting previous assign data
              const delpipeline = {}
              await MainDB.DeleteMany('tbluserrolehierarchy', new _UserRoleHierarchy(), delpipeline)
  
              const resp = await MainDB.executedata('i', new _UserRoleHierarchy(), 'tbluserrolehierarchy', req.body)
  
              var ResponseBody = {}
              ResponseBody.status = resp.status
              ResponseBody.data = resp.data
              ResponseBody.message = Config.errmsg['update']
  
              req.ResponseBody = ResponseBody
              next()
        } catch (err) {
            
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }; next()
        }
    }
}
