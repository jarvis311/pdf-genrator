import { MainDB, IISMethods, Config } from "../../../../config/Init.js"
import _NotificationSetting from "../../../../model/masters/Configurations/NotificationSetting.js"
import _Userrights from "../../../../model/masters/UserManagement/Userrights.js"
import _Userrole from "../../../../model/masters/UserManagement/Userrole.js"
import _employee from "../../../../model/Onboarding/Employee.js"

const TableName = "tbluserrolemaster"
const PageName = "userrole"
const FormName = "userrole"
const FltPageCollection = "userrolemaster"

export default class UserroleMaster {
	// List Userrole
	async ListUserRole(req, res, next) {
		try {
			const ResponseBody = {}
			const ObjectId = IISMethods.getobjectid()

			const {
				searchtext = "",
				paginationinfo: { nextpageid = "", pageno = 1, pagelimit = 10, filter = {}, sort = {}, projection = {} }
			} = req.body || {}

			const requiredPage = {
				nextpageid: nextpageid,
                pageno: pageno,
                skip: (pageno - 1) * pagelimit,
				pagelimit: pagelimit
			}

			const sortData = Object.keys(sort).length !== 0 ? sort : { userrole: 1 }

			const pipeline = IISMethods.GetPipelineForFilter(filter)

			if (searchtext !== "") {
				pipeline.push(...IISMethods.GetGlobalSearchFilter(new _Userrole(), searchtext))
			}

			const resp = await MainDB.getmenual(TableName, new _Userrole(), pipeline, requiredPage, sortData, true, "", projection)

			ResponseBody.pagename = PageName
			ResponseBody.formname = FormName
			ResponseBody.fltpagecollection = FltPageCollection
			ResponseBody.status = 200
			ResponseBody.message = Config.getResponsestatuscode()["200"]
			ResponseBody.data = resp.ResultData
			ResponseBody.fieldorder = resp.fieldorderdata
			ResponseBody.currentpage = resp.currentpage
			ResponseBody.nextpage = resp.nextpage
			ResponseBody.formfieldorderdata = resp.formfieldorderdata 

			req.ResponseBody = ResponseBody
			next()
		} catch (err) {
			req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
			next()
		}
	}

	async ListUserRoleHireachywise(req, res, next) {
		try {
			const ResponseBody = {}
			const ObjectId = IISMethods.getobjectid()

			const {
				searchtext = "",
				paginationinfo: { nextpageid = "", pageno = 1, pagelimit = 10, filter = {}, sort = {}, projection = {} }
			} = req.body || {}

			const requiredPage = {
				nextpageid: nextpageid,
                pageno: pageno,
                skip: (pageno - 1) * pagelimit,
				pagelimit: pagelimit
			}

			const sortData = Object.keys(sort).length !== 0 ? sort : { userrole: 1 }

			const pipeline = IISMethods.GetPipelineForFilter(filter)

			if (searchtext !== "") {
				pipeline.push(...IISMethods.GetGlobalSearchFilter(new _Userrole(), searchtext))
			}

			const userRoleIds = await MainDB.getBottomUserroles(req.headers.uid) 

			if (userRoleIds) {
				const objectIdUserRoleIds = userRoleIds.map((role) => ObjectId(role))
				pipeline.push({ $match: { _id: { $in: objectIdUserRoleIds } } })
			}

			const resp = await MainDB.getmenual(TableName, new _Userrole(), pipeline, requiredPage, sortData, true, "", projection)

			ResponseBody.pagename = PageName
			ResponseBody.formname = FormName
			ResponseBody.fltpagecollection = FltPageCollection
			ResponseBody.status = 200
			ResponseBody.message = Config.getResponsestatuscode()["200"]
			ResponseBody.data = resp.ResultData
			ResponseBody.fieldorder = resp.fieldorderdata
			ResponseBody.currentpage = resp.currentpage
			ResponseBody.nextpage = resp.nextpage
			ResponseBody.totaldocs = resp.totaldocs
			ResponseBody.formfieldorderdata = resp.formfieldorderdata 

			req.ResponseBody = ResponseBody
			next()
		} catch (err) {
			req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
			next()
		}
	}
	// Insert Userrole
	async InsertUserRole(req, res, next) {
		try {
			const ResponseBody = {}
			req.body.alias = req.body.userrole.toLowerCase()

			const resp = await MainDB.executedata("i", new _Userrole(), TableName, req.body)

			ResponseBody.status = resp.status
			ResponseBody.message = resp.message

			req.ResponseBody = ResponseBody
			next()
		} catch (err) {
			req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
			next()
		}
	}

	// Update Userrole
	async UpdateUserRole(req, res, next) {
		try {
			const ResponseBody = {}

			const pipeline = { _id: req.body._id }
			const userrole = await MainDB.FindOne(TableName, new _Userrole(), pipeline)

			if (userrole) {
				// record info Update data set
				const RecordInfo = userrole.recordinfo
				RecordInfo.updateuid = req.headers.uid
				RecordInfo.updateby = req.headers.personname
				RecordInfo.updatedate = IISMethods.getdatetimestr()
				req.body.recordinfo = RecordInfo

				

				const resp = await MainDB.executedata("u", new _Userrole(), TableName, req.body)

				// Update Dependency
				const updatePipeline = {
					tblpersonmaster: [{ "userrole.userroleid": req.body._id }, { $set: { "userrole.$.userrole": req.body.userrole } }],
					//tblnotificationsettingmaster: [{ userroleid: req.body._id }, { $set: { userrole: req.body.userrole } }]
				}

				const updateModelObj = {
					tblemployee: new _employee(),
					//tblnotificationsettingmaster: new _NotificationSetting()
				}

				const tempArray = []
				for (const key in updateModelObj) {
					tempArray.push(MainDB.UpdateMany(key, updateModelObj[key], updatePipeline[key]))
				}
				await Promise.all(tempArray)

				ResponseBody.status = resp.status
				ResponseBody.message = resp.message
				ResponseBody.data = resp.data
			} else {
				ResponseBody.status = 404
				ResponseBody.message = Config.getErrmsg()["notexist"]
			}

			req.ResponseBody = ResponseBody
			next()
		} catch (err) {
			req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
			next()
		}
	}

	// Delete Userrole
	async DeleteUserRole(req, res, next) {
		try {
			const ResponseBody = {}

			if (req.body._id.toString() !== Config.getAdminutype()) {
			// if (isAdmin) {
				// Dependency Check
				const dependencyObj = {
					tbluserrights: new _Userrights()
				}
				// Dependency Array
				const dependency = []
				for (const key in dependencyObj) {
					const ObjModel = await MainDB.createmodel(key, dependencyObj[key])

					// if (key === "tblnotificationsettingmaster" || key === "tbluserrights") {
					if ( key === "tbluserrights") {
						dependency.push([ObjModel["objModel"], { userroleid: req.body._id }, Config.apipagename[key]])
					}
				}

				const resp = await MainDB.executedata("d", new _Userrole(), TableName, req.body, true, dependency)

				ResponseBody.status = resp.status
				ResponseBody.message = resp.message
				ResponseBody.existdataPagename = resp.existdataPagename
			} else {
				ResponseBody.status = 401
				ResponseBody.message = Config.getErrmsg()["cannotdeleteauperadmin"]
			}

			req.ResponseBody = ResponseBody
			next()
		} catch (err) {
			req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
			next()
		}
	}
}
