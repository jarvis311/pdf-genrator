
import { IISMethods, MainDB, Config } from "../../../config/Init.js"
import _Committee from "../../../model/masters/Commitee.js"

export default class CopyMaster {

    async CopyMaster(req, res, next) {
        try {
            const ResponseBody = {}
            const pagename = req.headers.pagename

            const { insertResp, successCount, errorCount, insertData, matchdata, headerData } = await getCopyMasterData(pagename, req.headers, req.body)

            ResponseBody.status = insertResp.status
            ResponseBody.message = insertResp.status === 200 ?  (successCount ? Config.getErrmsg()["copysuccess"] : Config.getErrmsg()["overwritesuccess"]) : insertResp.message
            ResponseBody.successdatacount = successCount
            ResponseBody.overwritecount = errorCount
            ResponseBody.overwritedata = matchdata
            ResponseBody.successdata = insertData
            ResponseBody.headerdata = headerData

            req.ResponseBody = ResponseBody; next()
        } catch (err) {

            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }; next()
        }
    }

    //ListProperty After Excluding Given Property
    async ListCopyProperty(req, res, next) {
        try {
            const ResponseBody = {}
            const ObjectId = IISMethods.getobjectid()

            const pagename = req.headers.pagename

            let { propertyid = "" } = req.body

            if (propertyid === "") {
                propertyid = Config.dummyObjid
            }

            let pipeline = []

            if (pagename === "taskchecklist" || pagename === "taskscheduler") {
                pipeline.push(
                    {
                        $project: {
                            propertyname: 1
                        }
                    },
                    {
                        $sort: {
                            propertyname: 1
                        }
                    }
                )
            } else {
                pipeline.push(
                    {
                        $match: {
                            _id: { $ne: ObjectId(propertyid) }
                        }
                    },
                    {
                        $project: {
                            propertyname: 1
                        }
                    },
                    {
                        $sort: {
                            propertyname: 1
                        }
                    }
                )
            }

            const personPipeline = { _id: ObjectId(req.headers.uid) }
            const person = await SubDBPool[req.headers["subdomainname"]].FindOne("tblpersonmaster", new _Person(), personPipeline)

            const personAssignedProperties = await IISMethods.getPersonPropertyIds(person, true) 
            pipeline.push(
                {
                    $match: {
                        // _id: { $in: person.property.map((obj) => ObjectId(obj.propertyid)) } 
                        _id: { $in: personAssignedProperties } 
                    }
                }
            )

            const resp = await SubDBPool[req.headers["subdomainname"]].getmenual("tblproperty", new PropertyCommon(), pipeline)

            ResponseBody.status = 200
            ResponseBody.message = Config.getResponsestatuscode()["200"]
            ResponseBody.data = resp.ResultData

            req.ResponseBody = ResponseBody; next()
        } catch (err) {


            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }; next()
        }
    }

    async BulkCopyTerms(req, res, next) {
        try {
            const ResponseBody = {}
            ResponseBody.status = 401

            const TableName = "tblproperty"
            const ObjectId = IISMethods.getobjectid()
            ResponseBody.message = Config.getResponsestatuscode()["401"]

            const fromPropertyId = req.body.frompropertyid
            const toPropertyIds = req.body.topropertyids

            const pipeline = [
                {
                    $match: { _id: ObjectId(fromPropertyId) }
                }
            ]
            const fromResp = await SubDBPool[req.headers["subdomainname"]].getmenual(TableName, new PropertyCommon(), pipeline)
            const fromResult = fromResp.ResultData

            if (fromResult.length) {
                const updateResp = await SubDBPool[req.headers["subdomainname"]].UpdateMany(TableName, new PropertyCommon(), [
                    { _id: { $in: toPropertyIds.map((obj) => ObjectId(obj)) } },
                    {
                        $set: {
                            agelimit: fromResult[0].agelimit,
                            mobilecheckindescription: fromResult[0].mobilecheckindescription,
                            mobilecheckincardaccesscount: fromResult[0].mobilecheckincardaccesscount,
                            mobilecheckincardaccesslimit: fromResult[0].mobilecheckincardaccesslimit
                        }
                    }
                ])

                ResponseBody.status = updateResp.status
                ResponseBody.message = updateResp.message
            } else {
                ResponseBody.status = 404
                ResponseBody.message = Config.getResponsestatuscode()["404"]
            }
            req.ResponseBody = ResponseBody; next()
        } catch (err) {

            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }; next()
        }
    }
}
