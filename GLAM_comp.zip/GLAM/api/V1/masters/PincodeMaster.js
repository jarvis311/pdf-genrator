import { IISMethods,MainDB, Config } from "../../../config/Init.js"
import _City from "../../../model/masters/City.js"
import _Pincode from '../../../model/masters/PincodeMaster.js'

const TableName = "tblpincodemaster"
const PageName = "pincode"
const FormName = "pincode"
const FltPageCollection = "citymaster"

export default class PincodeMaster {

	// List Pincode
     async ListPincode(req, res, next) {
        try {

            var ResponseBody = {}
            var PaginationInfo = req.body.paginationinfo
            let changeMessage = 0
            let listarea = PaginationInfo.filter.listarea
            delete PaginationInfo.filter.listarea

            const requiredPage = { pageno: PaginationInfo.pageno, skip: (PaginationInfo.pageno - 1) * PaginationInfo.pagelimit, pagelimit: PaginationInfo.pagelimit }
            let fieldorder = req.body.paginationinfo.isfieldorder ? req.body.paginationinfo.isfieldorder : 0

            var pipeline = []
            var sort = (Object.keys(PaginationInfo.sort).length !== 0 ? PaginationInfo.sort : { '_id': -1 })

            pipeline.push(...IISMethods.GetPipelineForFilter(PaginationInfo.filter))

            const searchtext = req.body.searchtext || ""
            if (searchtext !== "") {
                pipeline.push(...IISMethods.GetGlobalSearchFilter(new _Pincode(), searchtext))
            }

            let projection = PaginationInfo.projection ? PaginationInfo.projection : {}

            const resp = await MainDB.getmenual(TableName, new _Pincode(), pipeline, requiredPage, sort, fieldorder,"", projection)

            ResponseBody.status = 200
            ResponseBody.pagename = PageName
            ResponseBody.formname = FormName
			ResponseBody.fltpagecollection = FltPageCollection
            ResponseBody.data = resp.ResultData
            ResponseBody.currentpage = resp.currentpage
            ResponseBody.nextpage = resp.nextpage
            ResponseBody.totaldocs = resp.totaldocs
            ResponseBody.fieldorder = resp.fieldorderdata
            ResponseBody.formfieldorderdata = resp.formfieldorderdata 

            req.ResponseBody = ResponseBody
            next()

        }
        catch (err) {
            req.ResponseBody = { status: 500, message: Config.resstatuscode["500"], err }
            next()
        }
    }
	

    // Insert Pincode
    async InsertPincode(req, res, next) {
        try {
            var ResponseBody = {}
            var resp

            resp = await MainDB.executedata('i', new _Pincode(), TableName, req.body)

            ResponseBody.status = resp.status
            ResponseBody.message = resp.message
            ResponseBody.data = resp.data


            req.ResponseBody = ResponseBody
            next()
        }
        catch (err) {
            req.ResponseBody = { status: 500, message: Config.resstatuscode["500"], err }
            next()
        }
    }

	// Update Pincode
      async UpdatePincode(req, res, next) {
        try {

            const ObjectId = IISMethods.getobjectid()


                const pipelinedata = [{ $match: { '_id': ObjectId(req.body._id) } }]
                const record = await MainDB.getmenual(TableName, new _Pincode(), pipelinedata)

                var RecordInfo = record.ResultData?.[0]?.recordinfo
                RecordInfo.updateuid = req.headers.uid
                RecordInfo.updateby = req.headers.personname
                RecordInfo.updatedate = IISMethods.getdatetimestr()
                req.body.recordinfo = RecordInfo

                const resp = await MainDB.executedata('u', new _Pincode(), TableName, req.body)

                var ResponseBody = {}
                ResponseBody.status = resp.status
                ResponseBody.data = resp.data
                ResponseBody.message = resp.message

            req.ResponseBody = ResponseBody
            next()
        }
        catch (err) {
            req.ResponseBody = { status: 500, message: Config.resstatuscode["500"], err }
            next()
        }
    }


	  //Delete pincode
      async DeletePincode(req, res, next) {
        try {
            var ResponseBody = {}

            const resp = await MainDB.executedata('d', new _Pincode(), TableName, req.body)

            ResponseBody.status = resp.status
            ResponseBody.message = resp.message
            req.ResponseBody = ResponseBody
            next()
        }
        catch (err) {
            req.ResponseBody = { status: 500, message: Config.resstatuscode["500"], err }
            next()
        }
    }


}
