import { Config, MainDB, IISMethods } from "../../../config/Init.js"
import _BreedMaster from '../../../model/masters/Breed.js'
import _BusinessStructureMaster from '../../../model/masters/BusinessStructure.js'
import _CategoryMaster from '../../../model/masters/VisitorCategorys.js'
import _ChecklisttypeMaster from '../../../model/masters/CheckListType.js'
import _Citymaster from '../../../model/masters/City.js'
import _Countrymaster from '../../../model/masters/Country.js'
import _Pincodemaster from '../../../model/masters/PincodeMaster.js'
import _Statemaster from '../../../model/masters/State.js'
import _DailyhelpCategorymaster from '../../../model/masters/DailyhelpCategory.js' 
import _DeliveryTypeMaster from '../../../model/masters/City.js'
import _DesignationMaster from '../../../model/masters/Designation.js'
import _Event from '../../../model/masters/Event.js'
import _EventCategoryMaster from '../../../model/masters/EventCategory.js'
import _DeliveryCompanyMaster from '../../../model/masters/DeliveryCompany.js'
import { PropertyArea, Propertycommon,PropertyFacility,PropertyFloor, PropertyUnit, PropertyWing } from "../../../model/masters/Property/PropertyMaster.js"
import _Employee from '../../../model/Onboarding/Employee.js'
import _Customer from '../../../model/Onboarding/Customer.js'
import _Task from '../../../model/masters/Task/Task.js'
import _Asset from '../../../model/masters/Asset/Asset.js'
import _pettype from '../../../model/masters/PetType.js'
import _Complaintcategory from '../../../model/Complaint/ComplaintCategory.js'
import _AreatypeMaster from '../../../model/masters/Property/AreaType.js'
import _Complaint from '../../../model/Complaint/Complaint.js'
import _GateKeeper from '../../../model/Onboarding/GateKeeper.js'
import _Vendor from '../../../model/Onboarding/Vendor.js'
import _Dailyhelp from '../../../model/Onboarding/DailyHelp.js'
import _Checklist from '../../../model/CheckList.js'
import _Visitor from '../../../model/GateKeeper/Visitor.js'
import _FacilityBooking from '../../../model/FacilityBooking.js'
import _ComplaintPriority from '../../../model/Complaint/ComplaintPriority.js'
import _ComplaintType from '../../../model/Complaint/ComplaintType.js'
import _ComplaintChat from '../../../model/Complaint_Chat/ComplaintChat.js'
import _ComplaintStage from '../../../model/Complaint/ComplaintStage.js'
import _VendorStaff from '../../../model/Onboarding/VendorStaff.js'
import _Notice from '../../../model/masters/Notice.js'
import _Knowledgebase from '../../../model/masters/Knowledgebase.js'
import _Incident from '../../../model/masters/Incident.js'


export default class DeleteMaster {

    async DeleteMaster(req, res, next) {
        try {
            const ResponseBody = {}

            async function getDeleteMasterData(pagename, headers, body) {

                const ObjectId = IISMethods.getobjectid()
                let selectedIds = body.selectedids || []
                const filter = body.filter || {}
                const searchtext = body.searchtext || ""
                const selecteddataflag = body.selecteddataflag


                let successCount = 0
                let successData = []
                let errorCount = 0
                let errorData = []
                let dependency = []
                let headerData = []

                if (selectedIds.length || selecteddataflag === 0) {
                    //Dependency must be added Hierarchy-Wise
                    const modelObj = {
                        asset: {
                            tablename: "tblasset",
                            model: new _Asset(),
                            subdependencyobj: {
                                // tblasset :new _Asset()
                            },
                            subdependencykey: {
                                // tblasset :"assetid"
                            },
                            fielddata: [
                                { field: "asset", text: "assetname" },
                                { field: "message", text: "Message" }
                            ]
                        }, 
                        task: {
                            tablename: "tbltask",
                            model: new _Task(),
                            subdependencyobj: {
                               // tbltask :new _Task()
                            },
                            subdependencykey: {
                               // tbltask :"assetid"
                            },
                            fielddata: [
                                { field: "task", text: "title" },
                                { field: "message", text: "Message" }
                            ]
                        }, 
                        customer: {
                            tablename: "tblcustomer",
                            model: new _Customer(),
                            subdependencyobj: {
                                 tblcustomer :new _Customer()
                            },
                            subdependencykey: {
                                tblcustomer : "ownedproperties.customerid"
                            },
                            fielddata: [
                                { field: "personname", text: "personname" },
                                { field: "message", text: "Message" }
                            ]
                        },
                        employee: {
                            tablename: "tblemployee",
                            model: new _Employee(),
                            subdependencyobj: {
                                tblemployee :new _Employee()
                            },
                            subdependencykey: {
                                tblemployee :"reportingtoid"
                            },
                            fielddata: [
                                { field: "personname", text: "personname" },
                                { field: "message", text: "Message" }
                            ]
                        },
                        gatekeeper: {
                            tablename: "tblgatekeeper",
                            model: new _GateKeeper(),
                            subdependencyobj: {
                                // tblasset :new _Asset()
                            },
                            subdependencykey: {
                                // tblasset :"assetid"
                            },
                            fielddata: [
                                { field: "personname", text: "personname" },
                                { field: "message", text: "Message" }
                            ]
                        },
                        vendormaster: {
                            tablename: "tblvendormaster",
                            model: new _Vendor(),
                            subdependencyobj: {
                                // tblasset :new _Asset()
                            },
                            subdependencykey: {
                                // tblasset :"assetid"
                            },
                            fielddata: [
                                { field: "personname", text: "personname" },
                                { field: "message", text: "Message" }
                            ]
                        },
                        vendorstaffmaster: {
                            tablename: "tblvendorstaffmaster",
                            model: new _VendorStaff(),
                            subdependencyobj: {
                                // tblasset :new _Asset()
                            },
                            subdependencykey: {
                                // tblasset :"assetid"
                            },
                            fielddata: [
                                { field: "personname", text: "personname" },
                                { field: "message", text: "Message" }
                            ]
                        },
                        notice: {
                            tablename: "tblnoticemaster",
                            model: new _Notice(),
                            subdependencyobj: {
                                //  tblcustomer :new _Customer()
                            },
                            subdependencykey: {
                                // tblcustomer : "ownedproperties.customerid"
                            },
                            fielddata: [
                                { field: "title", text: "title" },
                                { field: "message", text: "Message" }
                            ]
                        },
                        knowledgebase: {
                            tablename: "tblknowledgebasemaster",
                            model: new _Knowledgebase(),
                            subdependencyobj: {
                                //  tblcustomer :new _Customer()
                            },
                            subdependencykey: {
                                // tblcustomer : "ownedproperties.customerid"
                            },
                            fielddata: [
                                { field: "title", text: "title" },
                                { field: "message", text: "Message" }
                            ]
                        },
                        incident: {
                            tablename: "tblincidentmaster",
                            model: new _Incident(),
                            subdependencyobj: {
                                //  tblcustomer :new _Customer()
                            },
                            subdependencykey: {
                                // tblcustomer : "ownedproperties.customerid"
                            },
                            fielddata: [
                                { field: "title", text: "title" },
                                { field: "message", text: "Message" }
                            ]
                        },
                        event: {
                            tablename: "tbleventmaster",
                            model: new _Event(),
                            subdependencyobj: {
                                //  tblcustomer :new _Customer()
                            },
                            subdependencykey: {
                                // tblcustomer : "ownedproperties.customerid"
                            },
                            fielddata: [
                                { field: "title", text: "title" },
                                { field: "message", text: "Message" }
                            ]
                        },
                        customer: {
                            tablename: "tblcustomer",
                            model: new _Customer(),
                            subdependencyobj: {
                                 tblcustomer :new _Customer()
                            },
                            subdependencykey: {
                                tblcustomer : "ownedproperties.customerid"
                            },
                            fielddata: [
                                { field: "personname", text: "personname" },
                                { field: "message", text: "Message" }
                            ]
                        },
                        breedmaster: {
                            tablename: "tblbreedmaster",
                            model: new _BreedMaster(),
                            subdependencyobj: {
                                tblcustomer :new _Customer()
                            },
                            subdependencykey: {
                                tblcustomer :"breedid"
                            },
                            fielddata: [
                                { field: "breed", text: "Breed Name" },
                                { field: "message", text: "Message" }
                            ]
                        }, 
                        businessstructure: {
                            tablename: "tblbusinessstructuremaster",
                            model: new _BusinessStructureMaster(),
                            subdependencyobj: {
                                tblvendormaster:new _Vendor(),
                                tbldailyhelpmaster:new _Dailyhelp(),
                            },
                            subdependencykey: {
                                tblvendormaster:"businessstructureid",
                                tbldailyhelpmaster:"businessstructureid"
                            },
                            fielddata: [
                                { field: "businessstructure", text: "Business Structure Name" },
                                { field: "message", text: "Message" }
                            ]
                        },
                        category: {
                            tablename: "tblvisitorcategorymaster",
                            model: new _CategoryMaster(),
                            subdependencyobj: {
                                tblvisitormaster:new _Vendor(),
                            },
                            subdependencykey: {
                                tblvisitormaster:"categoryid"
                            },
                            fielddata: [
                                { field: "category", text: "Category Name" },
                                { field: "message", text: "Message" }
                            ]
                        },
                        checklist: {
                            tablename: "tblchecklisttypemaster",
                            model: new _ChecklisttypeMaster(),
                            subdependencyobj: {
                                tblchecklist:new _Checklist()
                            },
                            subdependencykey: {
                                tblchecklist:"checklisttypeid"
                            },
                            fielddata: [
                                { field: "checklisttype", text: "Checklist Type Name" },
                                { field: "message", text: "Message" }
                            ]
                        }, 
                        city: {
                            tablename: "tblcitymaster",
                            model: new _Citymaster(),
                            subdependencyobj: {
                                tblpropertymaster : new Propertycommon(),
                                tblemployee : new _Employee(),
                                tblcustomer :new _Customer(),
                                tblgatekeeper :new _GateKeeper()
                            },
                            subdependencykey: {
                                tblpropertymaster: "cityid",
                                tblemployee : "cityid",
                                tblcustomer :"cityid",
                                tblgatekeeper :"cityid"
                            },
                            fielddata: [
                                { field: "name", text: "Additional Charge Name" },
                                { field: "additionalchargestype", text: "Additional Charges Type" }
                            ]
                        },
                        country: {
                            tablename: "tblcountrymaster",
                            model: new _Countrymaster(),
                            subdependencyobj: {
                                tblpropertymaster : new Propertycommon(),
                                tblcitymaster: new _Citymaster(),
                                tblstatemaster:new _Statemaster(),
                                tblemployee : new _Employee(),
                                tblcustomer :new _Customer(),
                                tblgatekeeper :new _GateKeeper()
                            },
                            subdependencykey: {
                                tblpropertymaster: "countryid",
                                tblcitymaster:"countryid",
                                tblstatemaster:"countryid",
                                tblemployee : "countryid",
                                tblcustomer :"countryid",
                                tblgatekeeper :"countryid"
                            },
                            fielddata: [
                                { field: "name", text: "Name" },
                                { field: "message", text: "Message" }
                            ]
                        },
                        pincode: {
                            tablename: "tblpincodemaster",
                            model: new _Pincodemaster(),
                            subdependencyobj: {
                                tblpropertymaster : new Propertycommon(),
                                tblemployee : new _Employee(),
                                tblcustomer :new _Customer(),
                                tblgatekeeper :new _GateKeeper()
                            },
                            subdependencykey: {
                                tblpropertymaster: "pincodeid",
                                tblemployee : "pincodeid",
                                tblcustomer :"pincodeid",
                                tblgatekeeper :"pincodeid"
                            },
                            fielddata: [
                                { field: "resolution", text: "Resolution Master" },
                                { field: "message", text: "Message" }
                            ]
                        },
                        state: {
                            tablename: "tblstatemaster",
                            model: new _Statemaster(),
                            subdependencyobj: {
                                tblpropertymaster : new Propertycommon(),
                                tblcitymaster: new _Citymaster(),
                                tblemployee : new _Employee(),
                                tblcustomer :new _Customer(),
                                tblgatekeeper :new _GateKeeper()
                            },
                            subdependencykey: {
                                tblpropertymaster: "countryid",
                                tblcitymaster:"countryid",
                                tblemployee : "countryid",
                                tblcustomer :"countryid",
                                tblgatekeeper :"countryid"
                            },
                            fielddata: [
                                { field: "name", text: "Guest Mood" },
                                { field: "message", text: "Message" }
                            ]
                        },
                        dailyhelpcategory: {
                            tablename: "tbldailyhelpcategorymaster",
                            model: new _DailyhelpCategorymaster(),
                            subdependencyobj: {
                                tbldailyhelpmaster : new _Dailyhelp()
                            },
                            subdependencykey: {
                                tbldailyhelpmaster : "dailyhelpcategoryid"
                            },
                            fielddata: [
                                { field: "dailyhelpcategory", text: "Dailyhelp Category Name" },
                                { field: "message", text: "Message" }
                            ]
                        },
                        deliverytype: {
                            tablename: "tbldeliverytypemaster",
                            model: new _DeliveryTypeMaster(),
                            subdependencyobj: {
                                tbldailyhelpmaster : new _Dailyhelp(),
                                tblvendormaster:new _Vendor()
                            },
                            subdependencykey: {
                                tbldailyhelpmaster:"deliverytypeid",
                                tblvendormaster:"deliverytypeid"
                            },
                            fielddata: [
                                { field: "deliverytype", text: "Delivery Type Name" },
                                { field: "message", text: "Message" }
                            ]
                        },
                        deliverycompany: {
                            tablename: "tbldeliverycompnaymaster",
                            model: new _DeliveryCompanyMaster(),
                            subdependencyobj: {
                                tblvisitor : new _Visitor()
                            },
                            subdependencykey: {
                                tblvisiotr: "deliverycompanyid"
                            },
                            fielddata: [
                                { field: "name", text: "Shelf Name" },
                                { field: "message", text: "Message" }
                            ]
                        },
                        designation: {
                            tablename: "tbldesignationmaster",
                            model: new _DesignationMaster(),
                            subdependencyobj: {
                               tblpropertymaster : new Propertycommon(),
                               tblemployee : new _Employee(),
                               tblcustomer :new _Customer(),
                               tblgatekeeper :new _GateKeeper(),
                               tblchecklist :new _Checklist(),
                               tbldailyhelp:new _Dailyhelp()
                            },
                            subdependencykey: {
                                tblpropertymaster: "designationid",
                                tblemployee : "designationid",
                                tblcustomer :"designationid",
                                tblgatekeeper :"designationid",
                                tblchecklist :"designationid",
                                tbldailyhelp:"designationid"                                
                            },
                            fielddata: [
                                { field: "name", text: "Name" },
                                { field: "message", text: "Message" }
                            ]
                        },
                        areatype: {
                            tablename: "tblareatypemaster",
                            model: new _AreatypeMaster(),
                            subdependencyobj: {
                                tblpropertyarea : new PropertyArea
                            },
                            subdependencykey: {
                                tblpropertyarea: "areatypeid"
                            },
                            fielddata: [
                                { field: "name", text: "Guest Mood" },
                                { field: "message", text: "Message" }
                            ]
                        },
                        pettype: {
                            tablename: "tblpettypemaster",
                            model: new _pettype(),
                            subdependencyobj: {
                                tblcustomer : new _Customer()
                            },
                            subdependencykey: {
                                tblcustomer: "pettypeid"
                            },
                            fielddata: [
                                { field: "name", text: "Guest Mood" },
                                { field: "message", text: "Message" }
                            ]
                        },
                        complaintcategory: {
                            tablename: "tblcomplaintcategorymaster",
                            model: new _Complaintcategory(),
                            subdependencyobj: {
                                tblcomplaint : new _Complaint()
                            },
                            subdependencykey: {
                                tblcomplaint: "complaintcategoryid"
                            },
                            fielddata: [
                                { field: "name", text: "Guest Mood" },
                                { field: "message", text: "Message" }
                            ]
                        },
                        complainttype: {
                            tablename: "tblcomplainttype",
                            model: new _ComplaintType(),
                            subdependencyobj: {
                                tblcomplaint : new _Complaint()
                            },
                            subdependencykey: {
                                tblcomplaint: "complainttypeid"
                            },
                            fielddata: [
                                { field: "name", text: "Guest Mood" },
                                { field: "message", text: "Message" }
                            ]
                        },
                        complaintstage: {
                            tablename: "tblcomplaintstage",
                            model: new _ComplaintStage(),
                            subdependencyobj: {
                                tblcomplaint : new _Complaint()
                            },
                            subdependencykey: {
                                tblcomplaint: "statusid"
                            },
                            fielddata: [
                                { field: "name", text: "Guest Mood" },
                                { field: "message", text: "Message" }
                            ]
                        },
                        complaintpriority: {
                            tablename: "tblcomplaintpriority",
                            model: new _ComplaintPriority(),
                            subdependencyobj: {
                                tblcomplaint : new _Complaint()
                            },
                            subdependencykey: {
                                tblcomplaint: "complaintpriorityid"
                            },
                            fielddata: [
                                { field: "name", text: "Guest Mood" },
                                { field: "message", text: "Message" }
                            ]
                        },
                        propertymaster:{
                            tablename: "tblpropertymaster",
                            model: new Propertycommon(),
                            subdependencyobj: {
                                tblemployee : new _Employee(),
                                tblcustomer :new _Customer(),
                                tblgatekeeper :new _GateKeeper(),
                                tblchecklist :new _Checklist(),
                                tblfacilitybooking:new _FacilityBooking(),
                                tblcomplaint: new _Complaint(),
                                tbldailyhelp :new _Dailyhelp(),
                                tblvendor:new _Vendor()
                            },
                            subdependencykey: {
                                tblemployee : "property.propertyid",
                                tblcustomer :"ownedproperties.propertyid",
                                tblgatekeeper :"propertyid",
                                tblchecklist:"propertyid",
                                tblfacilitybooking:"propertyid",
                                tblcomplaint:"propertyid",
                                tbldailyhelp:"propertyid",
                                tblvendor:"propertyid"
                            },
                            fielddata: [
                                { field: "propertyname", text: "Property Name" },
                                { field: "message", text: "Message" }
                            ]
                        },
                        wing: {
                            tablename: "tblpropertywing",
                            model: new PropertyWing(),
                            subdependencyobj: {
                                 tblcustomer :new _Customer()
                            },
                            subdependencykey: {
                                tblcustomer :"ownedproperties.wingid",
                            },
                            fielddata: [
                                { field: "personname", text: "personname" },
                                { field: "message", text: "Message" }
                            ]
                        },
                        floor: {
                            tablename: "tblpropertyfloor",
                            model: new PropertyFloor(),
                            subdependencyobj: {
                                 tblcustomer :new _Customer()
                            },
                            subdependencykey: {
                                tblcustomer :"ownedproperties.floorid",
                            },
                            fielddata: [
                                { field: "personname", text: "personname" },
                                { field: "message", text: "Message" }
                            ]
                        },
                        unit: {
                            tablename: "tblpropertyunit",
                            model: new PropertyUnit(),
                            subdependencyobj: {
                                 tblcustomer :new _Customer()
                            },
                            subdependencykey: {
                                tblcustomer :"ownedproperties.unitid",
                            },
                            fielddata: [
                                { field: "personname", text: "personname" },
                                { field: "message", text: "Message" }
                            ]
                        },
                        facility: {
                            tablename: "tblpropertyfacility",
                            model: new PropertyFacility(),
                            subdependencyobj: {
                                //  tblcustomer :new _Customer()
                            },
                            subdependencykey: {
                                // tblcustomer :"ownedproperties.unitid",
                            },
                            fielddata: [
                                { field: "facility", text: "facility" },
                                { field: "message", text: "Message" }
                            ]
                        },
                        complaint: {
                            tablename: "tblcomplaint",
                            model: new _Complaint(),
                            subdependencyobj: {
                                tblcomplaintchat : new _ComplaintChat()
                            },
                            subdependencykey: {
                                tblcomplaintchat: "complaintid"
                            },
                            fielddata: [
                                { field: "name", text: "Guest Mood" },
                                { field: "message", text: "Message" }
                            ]
                        },
                    }

                    let deletedData = []

                    const tablename = modelObj[pagename].tablename
                    const model = modelObj[pagename].model

                    if (selecteddataflag === 0) {

                        let pipeline = []

                        if (Object.keys(filter).length) {
                            pipeline = pipeline.concat(IISMethods.GetPipelineForFilter(filter))
                        }
                        if (searchtext !== "") {
                            pipeline.push(...IISMethods.GetGlobalSearchFilter(model, searchtext))
                        }

                        const resp = await MainDB.getmenual(tablename, model, pipeline)
                        const resultData = resp.ResultData
                        

                        //********** rights manage for delete (all self)  ***********/
                        if (req.userauth?.rights?.all == 1) {
                            selectedIds = resultData.map(obj => obj._id.toString())
                        } else if (req.userauth?.rights?.self == 1) {
                            selectedIds = resultData.filter(dataObj => dataObj.recordinfo?.entryuid == req.headers.uid).map((obj) => obj._id.toString())
                        }
                        //********** rights manage for delete (all self)  ***********/

                    } else if (selecteddataflag === 1) {
                        if (pagename == "complaint") {

                            let pipeline = body.iscompany == 1 ? [{ $match: { companyid: ObjectId(body.companyid) } }] : [{ $match: { propertyid: ObjectId(body.propertyid) } }]

                            selectedIds = selectedIds.map(obj => ObjectId(obj))

                                pipeline.push({
                                    $match: {
                                        _id: { $in: selectedIds }, complaintstarttime: { $eq: null }
                                    }
                                })

                            if (Object.keys(filter).length) {
                                pipeline = pipeline.concat(IISMethods.GetPipelineForFilter(filter))
                            }
                            if (searchtext !== "") {
                                pipeline.push(...IISMethods.GetGlobalSearchFilter(model, searchtext))
                            }

                            const resp = await MainDB.getmenual(tablename, model, pipeline)
                            const resultData = resp.ResultData
                            selectedIds = resultData.map(obj => obj._id.toString())
                        }

                    }

                    const subDependencyObj = modelObj[pagename].subdependencyobj
                    const subdependencykey = modelObj[pagename].subdependencykey
                    headerData = modelObj[pagename].fielddata

                    let resp = {}

                    if (selectedIds.length) {
                        if (Object.keys(subDependencyObj).length) {

                            const getDataPromise = [];
                            const deletedDataPromise = [];

                            for (let id of selectedIds) {

                                dependency = []
                                
                                for (const key in subDependencyObj) {
                                    const ObjModel = await MainDB.createmodel(key, subDependencyObj[key])
                                    dependency.push([ObjModel["objModel"], { [subdependencykey[key]]: id }, Config.apipagename[key].pagename])
                                }
                                
                                const pipeline = { _id: id }

                                const datapipeline = [{ $match: { _id: ObjectId(id) } }]

                                const getdata = MainDB.getmenual(tablename, model, datapipeline)
                                getDataPromise.push(getdata)

                                if(pagename == "customer" || pagename == "employee" || pagename == "gatekeeper" || pagename == "vendormaster" || pagename == "vendorstaffmaster"){
                                    const updatedata = { _id: id, isdelete: 1,isactive:0 }
                                    deletedData = MainDB.executedata("u", model, tablename, updatedata, true, dependency)
                                    deletedDataPromise.push(deletedData)
                                }else{
                                    deletedData = MainDB.executedata("d", model, tablename, pipeline, true, dependency)
                                    deletedDataPromise.push(deletedData)
                                }
                            }
                            const deleteRespData = await Promise.all(deletedDataPromise)
                            const getRespData = await Promise.all(getDataPromise)

                            const UpdatePromise = []
                            for (let i = 0; i < deleteRespData.length; i++) {
                                const deleteData = deleteRespData[i];
                                if (deleteData.status === 200) {
                                    successCount++

                                    if (pagename === "propertyarea") {
                                        // Change in tblpropertywing
                                        const wingUpdatePipeline = [{ _id: ObjectId(getRespData[i]?.ResultData[0]?.wingid) }, { $inc: { areacount: -1 } }]
                                        UpdatePromise.push(MainDB.Update("tblpropertywing", new PropertyWing(), wingUpdatePipeline))

                                        // Change in tblpropertyfloor
                                        const floorUpdatePipeline = [{ _id: ObjectId(getRespData[i]?.ResultData[0]?.floorid) }, { $inc: { areacount: -1 } }]
                                        UpdatePromise.push(MainDB.Update("tblpropertyfloor", new PropertyFloor(), floorUpdatePipeline))
                                    } else if (pagename == "floor") {
                                        // Change in tblpropertywing
                                        const buildingUpdatePipeline = [{ _id: floorRes.wingid }, { $inc: { floorcount: -1 } }]
                                        const updateBuildingPromise = MainDB.Update("tblpropertywing", new PropertyWing(), buildingUpdatePipeline)

                                        await Promise.all([updateBuildingPromise])
                                    } else if (pagename == "unit") {
                                        // Change in tblpropertywing
                                        const unitUpdatePipeline = [{ _id: unitRes.wingid }, { $inc: { unitcount: -1 } }]
                                        const updateUnitPromise = MainDB.Update("tblpropertywing", new PropertyWing(), unitUpdatePipeline)

                                        const floorUpdatePipeline = [{ _id: unitRes.floorid }, { $inc: { unitcount: -1 } }]
                                        const updateFloorPromise = MainDB.Update("tblpropertyfloor", new PropertyFloor(), floorUpdatePipeline)

                                        await Promise.all([updateUnitPromise, updateFloorPromise])
                                    }

                                }
                                else {
                                    errorCount++
                                    const errorPipeline = { _id: selectedIds[i] }
                                    const errorRecord = await MainDB.FindOne(tablename, model, errorPipeline)
                                    const errorResp = { ...errorRecord._doc }

                                    errorResp.message = deleteData.message
                                    errorData.push(errorResp)
                                }
                            }
                            if (UpdatePromise.length > 0) {
                                await Promise.all(UpdatePromise)
                            }

                        }
                        else {

                            const pipeline = { _id: { $in: selectedIds.map(obj => ObjectId(obj)) } }

                            deletedData = await MainDB.DeleteMany(tablename, model, pipeline)

                            if (deletedData.status === 200) {
                                successCount = selectedIds.length
                            }
                        }

                        resp = { status: 200, message: Config.getErrmsg()["delete"] }

                        if (successCount === 0 && errorCount > 0) {

                            resp = { status: 400, message: Config.getErrmsg()["notdeleted"] }
                        }
                    }
                    else {
                        resp = { status: 404, message: Config.getErrmsg()["nodatafound"] }
                        headerData = []
                    }
                    
                    console.log(JSON.stringify(errorData))
                    return { resp, successCount, successData, errorCount, errorData, headerData, dependency }
                }
                else {
                    let resp = { status: 404, message: Config.getErrmsg()["nodatafound"] }
                    return { resp, successCount, successData, errorCount, errorData, headerData, dependency }
                }
            }

            const pagename = req.headers.pagename

            const { resp, successCount, successData, errorCount, errorData, headerData, dependency } = await getDeleteMasterData(pagename, req.headers, req.body)

            ResponseBody.status = resp.status
            ResponseBody.message = resp.message
            ResponseBody.successdatacount = successCount
            ResponseBody.successdata = successData
            ResponseBody.errordatacount = errorCount
            ResponseBody.errordata = errorData
            ResponseBody.headerdata = headerData

            req.ResponseBody = ResponseBody; next()
        } catch (err) {

            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }; next()
        }
    }
}