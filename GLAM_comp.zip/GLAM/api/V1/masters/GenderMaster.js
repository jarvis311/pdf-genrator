import { IISMethods,MainDB, Config } from "../../../config/Init.js"
import _Gender from "../../../model/masters/Gender.js"


const TableName = "tblgendermaster"
const PageName = "gender"
const FormName = "gender"
const FltPageCollection = "gendermaster"

export default class GenderMaster {
	// List gender
	async ListGender(req, res, next) {
		try {
            var ResponseBody = {}
            var PaginationInfo =  req.body.paginationinfo
            
            const requiredPage = {pageno : PaginationInfo.pageno, skip : (PaginationInfo.pageno - 1) * PaginationInfo.pagelimit, pagelimit : PaginationInfo.pagelimit}
            var pipeline = []
            var sort = (Object.keys(PaginationInfo.sort).length !== 0 ? PaginationInfo.sort : {'_id' :-1})
            let projection = PaginationInfo.projection ? PaginationInfo.projection : {}
            let fieldorder = req.body.paginationinfo.isfieldorder ? req.body.paginationinfo.isfieldorder : 0

            pipeline = IISMethods.GetPipelineForFilter(PaginationInfo.filter)

            const searchtext = req.body.searchtext || ""
            if (searchtext !== "") {
                pipeline.push(...IISMethods.GetGlobalSearchFilter(new _Gender(), searchtext))
            }
                        
            const resp = await MainDB.getmenual(TableName, new _Gender(), pipeline, requiredPage, sort, fieldorder,"", projection)
              
            ResponseBody.pagename = PageName
            ResponseBody.formname = FormName
			ResponseBody.fltpagecollection = FltPageCollection
            ResponseBody.status = 200
            ResponseBody.message = Config.getResponsestatuscode()['200']
            ResponseBody.data = resp.ResultData
            ResponseBody.currentpage = resp.currentpage
            ResponseBody.nextpage = resp.nextpage
            ResponseBody.totaldocs = resp.totaldocs;
            ResponseBody.fieldorder = resp.fieldorderdata   
            ResponseBody.formfieldorderdata = resp.formfieldorderdata            

            req.ResponseBody = ResponseBody
            next()
		} catch (err) {
			req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
			next()
		}
	}

}
