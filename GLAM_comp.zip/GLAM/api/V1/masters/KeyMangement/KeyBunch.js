import { IISMethods, MainDB, Config } from "../../../../config/Init.js"
import _KeyBunch from "../../../../model/masters/KeyMangement/KeyBunch.js"
import _Key from '../../../../model/masters/KeyMangement/Key.js'

const TableName = "tblkeybunchmaster"
const PageName = "keybunch"
const FormName = "keybunch"
const FltPageCollection = "keybunchmaster"

export default class KeyBunchMaster {
    // List Key
    async ListKeyBunchMaster(req, res, next) {
        try {
            var ResponseBody = {}
            var PaginationInfo = req.body.paginationinfo

            const ObjectId = IISMethods.getobjectid()

            const requiredPage = { pageno: PaginationInfo.pageno, skip: (PaginationInfo.pageno - 1) * PaginationInfo.pagelimit, pagelimit: PaginationInfo.pagelimit }
            var pipeline = []
            var sort = (Object.keys(PaginationInfo.sort).length !== 0 ? PaginationInfo.sort : { '_id': -1 })
            let projection = PaginationInfo.projection ? PaginationInfo.projection : {}
            let fieldorder = req.body.paginationinfo.isfieldorder ? req.body.paginationinfo.isfieldorder : 0

            pipeline = IISMethods.GetPipelineForFilter(PaginationInfo.filter)

            const searchtext = req.body.searchtext || ""
            if (searchtext !== "") {
                pipeline.push(...IISMethods.GetGlobalSearchFilter(new _KeyBunch(), searchtext))
            }

            if (req.headers.propertyid) {
                pipeline.push({ $match: { propertyid: ObjectId(req.headers.propertyid) } })
            }

            const resp = await MainDB.getmenual(TableName, new _KeyBunch(), pipeline, requiredPage, sort, fieldorder, "", projection)

            ResponseBody.pagename = PageName
            ResponseBody.formname = FormName
            ResponseBody.fltpagecollection = FltPageCollection
            ResponseBody.status = 200
            ResponseBody.message = Config.getResponsestatuscode()['200']
            ResponseBody.data = resp.ResultData
            ResponseBody.currentpage = resp.currentpage
            ResponseBody.nextpage = resp.nextpage
            ResponseBody.totaldocs = resp.totaldocs;
            ResponseBody.fieldorder = resp.fieldorderdata
            ResponseBody.formfieldorderdata = resp.formfieldorderdata

            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

    // Insert Key
    async InsertKeyBunchMaster(req, res, next) {
        try {
            const ResponseBody = {}

            req.body.propertyid = req.headers.propertyid
            req.body.property = req.headers.property


            const resp = await MainDB.executedata("i", new _KeyBunch(), TableName, req.body)

            ResponseBody.status = resp.status
            ResponseBody.message = resp.message
            ResponseBody.data = resp.data

            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

    // Update Key
    async UpdateKeyBunchMaster(req, res, next) {
        try {
            // for optional selection suggested by Arpit A
            if (req.body.assigntogatekeeper == 1) {
                req.body.assinee = req.body.gatekeeper.map(item => ({
                    assineeid: item.gatekeeperid,
                    assinee: item.gatekeeper
                }))
            } else {
                req.body.assinee = req.body.employee.map(item => ({
                    assineeid: item.employeeid,
                    assinee: item.employee
                }))
            }
            const ObjectId = IISMethods.getobjectid()
            var ResponseBody = {}

            const pipeline = [{ $match: { '_id': ObjectId(req.body._id) } }]
            const record = await MainDB.getmenual(TableName, new _KeyBunch(), pipeline)

            var RecordInfo = record.ResultData[0].recordinfo
            RecordInfo.updateuid = req.headers.uid
            RecordInfo.updateby = req.headers.personname
            RecordInfo.updatedate = IISMethods.getdatetimeisostr()
            req.body.recordinfo = RecordInfo

            const resp = await MainDB.executedata('u', new _KeyBunch(), TableName, req.body)

            // if (resp.status === 200) {
            //     // Update Dependency
            //     const updatePipeline = [
            //         { keyid: req.body._id },
            //         { $set: { key: req.body.key } }
            //     ]
            //     const updateModelObj = {
            //         tblvendorstaffmaster: new _VendorStaff()
            //     }

            //     const tempArray = []
            //     for (const key in updateModelObj) {
            //         tempArray.push(MainDB.UpdateMany(key, updateModelObj[key], updatePipeline))
            //     }
            //     await Promise.all(tempArray)
            // }
            var ResponseBody = {}

            ResponseBody.status = resp.status
            ResponseBody.data = resp.data
            ResponseBody.message = resp.message

            req.ResponseBody = ResponseBody
            next()
        }
        catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

    // Delete Key
    async DeleteKeyBunchMaster(req, res, next) {
        try {
            const ResponseBody = {}

            //Dependency Check
            // const vendorstaffObjModel = await MainDB.createmodel('tblvendorstaffmaster', new _VendorStaff())

            // var dependency = [
            //     [vendorstaffObjModel['objModel'], { keyid: req.body._id }, "vendorstaff"]
            // ]

            const resp = await MainDB.executedata('d', new _KeyBunch(), TableName, req.body)

            ResponseBody.status = resp.status
            ResponseBody.message = resp.message

            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

    async KeyManageMaster(req, res, next) {
        try {
            const ResponseBody = {};
            const ObjectId = IISMethods.getobjectid();

            const keyIds = req.body._id ? [req.body._id] : []
            delete req.body.logs

            let message = ''
            if (req.body.status == 1) {
                message = `The Key has been assigned to ${req.body.assignperson}.`;
            } else if (req.body.status == 2) {
                message = `The Key has been recollected from ${req.body.recollectperson}.`;
            }


            // Handle keybunchid if provided
            if (IISMethods.ValidateObjectId(req.body.keybunchid)) {
                const pipeline = [{ $match: { '_id': ObjectId(req.body.keybunchid) } }];
                const keybunchResp = await MainDB.getmenual("tblkeybunchmaster", new _KeyBunch(), pipeline);

                if (keybunchResp?.ResultData?.length > 0) {
                    const { keybunch, logs } = keybunchResp.ResultData[0]
                    req.body.logs = logs

                    // Add existing key IDs to the list
                    if (keybunch.key && Array.isArray(keybunch.key)) {
                        for (const obj of keybunch.key) {
                            if (obj.keyid) keyIds.push(obj.keyid)
                        }
                    }

                    // Add logs for key management

                    req.body.logs?.push({
                        assignpersonid: req.body.assignpersonid,
                        assignperson: req.body.assignperson,
                        date: new Date(),
                        logtype: 1, // Action type (e.g., assign or recollect)
                        status: req.body.status,
                        recollectpersonid: req.body.recollectpersonid || null, // Default to empty string
                        recollectperson: req.body.recollectperson || '', // Default to empty string
                        message: message
                    })

                    let keybunchObj = {
                        _id: req.body.keybunchid,
                        key: req.body.key,
                        logs: req.body.logs,
                        status: req.body.status,
                        assignpersonid: req.body.assignpersonid,
                        assignperson: req.body.assignperson,
                        recollectpersonid: req.body.recollectpersonid,
                        recollectperson: req.body.recollectperson
                    }
                    // Update key bunch details
                    await MainDB.executedata('u', new _KeyBunch(), "tblkeybunchmaster", keybunchObj)
                    delete req.body.logs
                }
            }

            // Update key details

            const keyPipeline = [
                { _id: { $in: keyIds } },
                {
                    $set: req.body, $push: {
                        logs: {
                            assignpersonid: req.body.assignpersonid || null,
                            assignperson: req.body.assignperson,
                            date: new Date(),
                            logtype: 1,
                            status: req.body.status,
                            recollectpersonid: req.body.recollectpersonid || null,
                            recollectperson: req.body.recollectperson,
                            message: message
                        }
                    }
                }];
            const resp = await MainDB.UpdateMany("tblkeymaster", new _Key(), keyPipeline)

            ResponseBody.status = resp.status
            ResponseBody.message = resp.message

            req.ResponseBody = ResponseBody
            next();
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }


}
