import { IISMethods, MainDB, Config } from "../../../../config/Init.js"
import _Key from "../../../../model/masters/KeyMangement/Key.js"

const TableName = "tblkeymaster"
const PageName = "keymaster"
const FormName = "keymaster"
const FltPageCollection = "keymaster"

export default class KeyMaster {
    // List Key
    async ListKeyMaster(req, res, next) {
        try {
            var ResponseBody = {}
            const ObjectId = IISMethods.getobjectid()
            var PaginationInfo = req.body.paginationinfo

            const requiredPage = { pageno: PaginationInfo.pageno, skip: (PaginationInfo.pageno - 1) * PaginationInfo.pagelimit, pagelimit: PaginationInfo.pagelimit }
            var pipeline = []
            var sort = (Object.keys(PaginationInfo.sort).length !== 0 ? PaginationInfo.sort : { '_id': -1 })
            let projection = PaginationInfo.projection ? PaginationInfo.projection : {}
            let fieldorder = req.body.paginationinfo.isfieldorder ? req.body.paginationinfo.isfieldorder : 0


            pipeline = IISMethods.GetPipelineForFilter(PaginationInfo.filter)

            const searchtext = req.body.searchtext || ""
            if (searchtext !== "") {
                pipeline.push(...IISMethods.GetGlobalSearchFilter(new _Key(), searchtext))
            }

            if(req.headers.propertyid){
                pipeline.push({$match:{propertyid:ObjectId(req.headers.propertyid)}})
            }

            const resp = await MainDB.getmenual(TableName, new _Key(), pipeline, requiredPage, sort, fieldorder, "", projection)

            ResponseBody.pagename = PageName
            ResponseBody.formname = FormName
            ResponseBody.fltpagecollection = FltPageCollection
            ResponseBody.status = 200
            ResponseBody.message = Config.getResponsestatuscode()['200']
            ResponseBody.data = resp.ResultData
            ResponseBody.currentpage = resp.currentpage
            ResponseBody.nextpage = resp.nextpage
            ResponseBody.totaldocs = resp.totaldocs;
            ResponseBody.fieldorder = resp.fieldorderdata
            ResponseBody.formfieldorderdata = resp.formfieldorderdata

            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

    // Insert Key
    async InsertKeyMaster(req, res, next) {
        try {
            const ResponseBody = {}
            req.body.propertyid = req.headers.propertyid
            req.body.property = req.headers.property

            const resp = await MainDB.executedata("i", new _Key(), TableName, req.body)

            ResponseBody.status = resp.status
            ResponseBody.message = resp.message
            ResponseBody.data = resp.data

            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

    // Update Key
    async UpdateKeyMaster(req, res, next) {
        try {

            const ObjectId = IISMethods.getobjectid()
            var ResponseBody = {}

            const pipeline = [{ $match: { '_id': ObjectId(req.body._id) } }]
            const record = await MainDB.getmenual(TableName, new _Key(), pipeline)

            var RecordInfo = record.ResultData[0].recordinfo
            RecordInfo.updateuid = req.headers.uid
            RecordInfo.updateby = req.headers.personname
            RecordInfo.updatedate = IISMethods.getdatetimeisostr()
            req.body.recordinfo = RecordInfo

            const resp = await MainDB.executedata('u', new _Key(), TableName, req.body)

            // if (resp.status === 200) {
            //     // Update Dependency
            //     const updatePipeline = [
            //         { keyid: req.body._id },
            //         { $set: { key: req.body.key } }
            //     ]
            //     const updateModelObj = {
            //         tblvendorstaffmaster: new _VendorStaff()
            //     }
                
            //     const tempArray = []
            //     for (const key in updateModelObj) {
            //         tempArray.push(MainDB.UpdateMany(key, updateModelObj[key], updatePipeline))
            //     }
            //     await Promise.all(tempArray)
            // }
            var ResponseBody = {}

            ResponseBody.status = resp.status
            ResponseBody.data = resp.data
            ResponseBody.message = resp.message

            req.ResponseBody = ResponseBody
            next()
        }
        catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

    // Delete Key
    async DeleteKeyMaster(req, res, next) {
        try {
            const ResponseBody = {}

            //Dependency Check
            // const vendorstaffObjModel = await MainDB.createmodel('tblvendorstaffmaster', new _VendorStaff())

            // var dependency = [
            //     [vendorstaffObjModel['objModel'], { keyid: req.body._id }, "vendorstaff"]
            // ]

            const resp = await MainDB.executedata('d', new _Key(), TableName, req.body)

            ResponseBody.status = resp.status
            ResponseBody.message = resp.message

            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

}
