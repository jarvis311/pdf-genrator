import { IISMethods, MainDB, Config, FieldConfig } from "../../../config/Init.js"
import _Visitor from "../../../model/GateKeeper/Visitor.js"
import _LogManage from '../../../model/GateKeeper/LogManage.js'
import _GateKeeper from '../../../model/Onboarding/GateKeeper.js'
import _Incident from '../../../model/masters/Incident.js'
import _Guest from '../../../model/masters/Guest.js'
import _Asset from '../../../model/masters/Asset/Asset.js'
import _Approve from '../../../model/Approve.js'

const TableName = "tblvisitormaster"
const PageName = "visitor"
const FormName = "Visitor"
const FltPageCollection = "visitormaster"

export default class VisitorMaster {
    // List visitor
    async ListVisitorMaster(req, res, next) {
        try {
            var ResponseBody = {}
            var PaginationInfo = req.body.paginationinfo

            const requiredPage = { pageno: PaginationInfo.pageno, skip: (PaginationInfo.pageno - 1) * PaginationInfo.pagelimit, pagelimit: PaginationInfo.pagelimit }
            var pipeline = []
            var sort = (Object.keys(PaginationInfo.sort).length !== 0 ? PaginationInfo.sort : { '_id': -1 })
            let projection = PaginationInfo.projection ? PaginationInfo.projection : {}
            let fieldorder = req.body.paginationinfo.isfieldorder ? req.body.paginationinfo.isfieldorder : 0

            pipeline = IISMethods.GetPipelineForFilter(PaginationInfo.filter)

            const searchtext = req.body.searchtext || ""
            if (searchtext !== "") {
                pipeline.push(...IISMethods.GetGlobalSearchFilter(new _Visitor(), searchtext))
            }

            const resp = await MainDB.getmenual(TableName, new _Visitor(), pipeline, requiredPage, sort, fieldorder, "", projection)

            ResponseBody.pagename = PageName
            ResponseBody.formname = FormName
            ResponseBody.fltpagecollection = FltPageCollection
            ResponseBody.status = 200
            ResponseBody.message = Config.getResponsestatuscode()['200']
            ResponseBody.data = resp.ResultData
            ResponseBody.currentpage = resp.currentpage
            ResponseBody.nextpage = resp.nextpage
            ResponseBody.fieldorder = resp.fieldorderdata

            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }


    //unique visitor
    async ListUniqueVisitorMaster(req, res, next) {
        try {
            var ResponseBody = {}
            var PaginationInfo = req.body.paginationinfo

            const requiredPage = { pageno: PaginationInfo.pageno, skip: (PaginationInfo.pageno - 1) * PaginationInfo.pagelimit, pagelimit: PaginationInfo.pagelimit }
            var pipeline = []
            var sort = (Object.keys(PaginationInfo.sort).length !== 0 ? PaginationInfo.sort : { '_id': -1 })
            let projection = PaginationInfo.projection ? PaginationInfo.projection : {}
            let fieldorder = req.body.paginationinfo.isfieldorder ? req.body.paginationinfo.isfieldorder : 0

            pipeline = IISMethods.GetPipelineForFilter(PaginationInfo.filter)

            pipeline.push({
                $group: {
                    _id: "$personname",
                    document: { $first: "$$ROOT" }
                }
            });

            pipeline.push({
                $replaceRoot: { newRoot: "$document" }
            });

            const searchtext = req.body.searchtext || ""
            if (searchtext !== "") {
                pipeline.push(...IISMethods.GetGlobalSearchFilter(new _Visitor(), searchtext))
            }

            const resp = await MainDB.getmenual(TableName, new _Visitor(), pipeline, requiredPage, sort, fieldorder, "", projection)

            ResponseBody.pagename = PageName
            ResponseBody.formname = FormName
            ResponseBody.fltpagecollection = FltPageCollection
            ResponseBody.status = 200
            ResponseBody.message = Config.getResponsestatuscode()['200']
            ResponseBody.data = resp.ResultData
            ResponseBody.currentpage = resp.currentpage
            ResponseBody.nextpage = resp.nextpage
            ResponseBody.fieldorder = resp.fieldorderdata

            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

    // Insert Vendor
    async InsertVisitorMaster(req, res, next) {
        try {
            const ResponseBody = {}

            let ObjectId = IISMethods.getobjectid()

            //Get person
            let person
            if (req.body.apptype || req.headers.pagename) {
                const personResp = await MainDB.getPersonData({ apptype: req.headers.apptype, personid: [req.headers.uid], pagename: req.headers.pagename })
                person = personResp[0]
            }

            if (person.clockoutdate || !person.clockindate) {
                ResponseBody.status = 400
                ResponseBody.message = Config.errmsg['notclockin']
            } else {
                // 28-11-2024
                // const visitorpipeline = [{ $match: { "propertyid": ObjectId(req.headers.propertyid), "contact": req.body.contact,'clockin':1 } }]
                // const visitorResp = await MainDB.getmenual('tblvisitormaster', new _Visitor(), visitorpipeline)

                // if (visitorResp.ResultData.length > 0) {
                //     ResponseBody.status = 400
                //     ResponseBody.message = Config.errmsg['alreadyin']
                    
                //     req.ResponseBody = ResponseBody
                //     return next()
                // }

                    const resp = await MainDB.executedata("i", new _Visitor(), TableName, req.body)

                    if (resp.status == 200) {
                        //
                        var LogData = {}
                        LogData.Date = IISMethods.getdatetimeisostr()

                        var tablename = 'DeviceLogsvisitor_' + IISMethods.getCurrentMonth(LogData.Date).toString() + '_' + IISMethods.getCurrentYear(LogData.Date).toString()

                        let date = IISMethods.getdateandtimeformiso(LogData.Date)

                        LogData.DeviceLogId = IISMethods.GetTimestamp()
                        LogData.LogDetail = null
                        LogData.deleted = 0
                        LogData.propertyid = req.body.propertyid
                        LogData.property = req.headers.property
                        LogData.gatekeeperid = req.headers.uid
                        LogData.categoryid = req.body.categoryid
                        LogData.category = req.body.category
                        LogData.visitorid = resp.data._id
                        LogData.visitor = resp.data?.personname
                        LogData.clockintype = 0
                        LogData.LogDate = new Date()
                        LogData.gatekeeper = req.headers.personname
                        LogData.recordinfo = resp.data.recordinfo

                        let tblpipeline = [{ $match: { visitorid: ObjectId(resp.data._id) } },
                        { "$addFields": { "datelog": { $substr: ["$LogDate", 0, 10] } } },
                        { $match: { 'datelog': LogData.Date.slice(0, 10) } },
                        { $match: { 'deleted': { $ne: 1 } } },
                        ]
                        const tblresp = await MainDB.getmenual(tablename, new _LogManage(), tblpipeline)

                        // let duration = []
                        // let find = false
                        // var data = 0

                        // if (tblresp.ResultData.length) {
                        //     data = IISMethods.getTimeDifference(tblresp.ResultData[tblresp.ResultData.length - 1].LogDate, req.body.LogDate)
                        // }

                        // if (req.body.clockin == 1) {
                        //     const resp = await MainDB.executedata('i', new _LogManage(), tablename, LogData)

                        //     if (resp.status == 200) {
                        //         var obj = {
                        //             _id: resp.data._id,
                        //             clockin: 1
                        //         }
                        //         await MainDB.executedata('u', new _Visitor(), TableName, obj)
                        //     }
                        // }
                    }

                    ResponseBody.status = resp.status
                    ResponseBody.message = resp.message
            }

            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }


    async VisitorClockInOut(req, res, next) {
        try {
            var ResponseBody = {}

            let ObjectId = IISMethods.getobjectid()

            const visitorPipeline = [{ $match: { _id: ObjectId(req.body.visitorid) } }]
            const visitorResp = await MainDB.getmenual('tblvisitormaster', new _Visitor(), visitorPipeline)
            const visitor = visitorResp.ResultData[0]

            // if ((gatekeeper && visitor && gatekeeper.isactive == 1 && req.body.visitorid) || req.headers.apptype == 1) {
            if (visitor) {

                var LogData = {}
                LogData.Date = IISMethods.getdatetimeisostr()

                var tablename = 'DeviceLogsvisitor_' + IISMethods.getCurrentMonth(LogData.Date).toString() + '_' + IISMethods.getCurrentYear(LogData.Date).toString()

                let date = IISMethods.getdateandtimeformiso(LogData.Date)

                LogData.DeviceLogId = IISMethods.GetTimestamp()
                LogData.LogDetail = null
                LogData.deleted = 0
                LogData.propertyid = req.body.propertyid
                LogData.property = req.body.property
                LogData.gatekeeperid = req.headers.uid
                LogData.categoryid = req.body.categoryid
                LogData.visitorid = visitor._id
                LogData.visitor = visitor.personname
                LogData.clockintype = req.body.clockin
                LogData.LogDate = new Date()
                LogData.gatekeeper = req.headers.personname
                LogData.recordinfo = req.body.recordinfo
                LogData.visitorimage = visitor.visitorimage

                //already exist or not
                // await MainDB.getmenual(tablename, new _LogManage(), tblpipeline)

                //insert log
                const resp = await MainDB.executedata('i', new _LogManage(), tablename, LogData)

                //update clockin value in gatekeeper table
                if (resp.status == 200) {
                    let objVisitor = {
                        _id: ObjectId(req.body.visitorid),
                        clockin: req.body.clockin
                    }

                    if(req.body.clockin == 1){
                        objVisitor.visitorin = new Date()
                        ResponseBody.status = 200
                        ResponseBody.message = Config.errmsg['visitorin']
                    }else{
                        objVisitor.visitorout = new Date()
                        ResponseBody.status = 200
                        ResponseBody.message = Config.errmsg['visitorout']
                    }

                    await MainDB.executedata('u', new _Visitor(), TableName, objVisitor)

                } else {
                    ResponseBody.status = 404
                    ResponseBody.message = Config.getErrmsg()['nodatafound']
                }

            } else {
                ResponseBody.status = 404
                ResponseBody.message = Config.getErrmsg()['nodatafound']
            }

            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }


    async PreApproveVisitorAllow(req, res, next) {
        try {
            var ResponseBody = {}

            let ObjectId = IISMethods.getobjectid()

            const pipeline = [{ $match: { propertyid: ObjectId(req.headers.propertyid), otp: req.body.otp } }]
            const approveResp = await MainDB.getmenual("tblapprovemaster", new _Approve(), pipeline)


            if (approveResp.ResultData.length > 0) {
                const { startdate, enddate,  wingid, wing, floorid, floor, unitid, unit, areaid, area,mobilenumber,approvetype,picture,name,customerid,customer,age,breed,pettype,relation} = approveResp.ResultData[0]

                const isexpired = IISMethods.isDateBetween(startdate, req.body.entrydate, enddate)

                if (isexpired) {

                    let VisitorData = {
                            gatekeeperid: req.headers.uid,
                            gatekeeper: req.headers.personname,
                            // categoryid:  "66ac9e63ee40a69efde098eb",
                            // category: "STAFF",
                            propertyid: req.headers.propertyid,
                            property: req.headers.property,
                            propertydetails: [
                                {
                                    wingid: wingid,
                                    wing: wing,
                                    floorid: floorid,
                                    floor: floor,
                                    unitid: unitid,
                                    unit: unit,
                                    areaid: areaid,
                                    area: area
                                }
                            ],
                            contact: mobilenumber,
                            isverify: 1,
                            personname: name,
                            approvetype:approvetype,
                            name:name,
                            visitorimage:picture,
                            customerid:customerid,
                            customer:customer,
                            age,
                            breed,
                            pettype,
                            relation,
                            // deliverycompanyid:  "66aca218be064cab4199b4b1",
                            // deliverycompany: "Shadowfax",
                            clockin: 0,
                            recordinfo:req.body.recordinfo,
                            isactive: 1
                        }
                    

                    const VisitorResp = await MainDB.executedata("i", new _Visitor(), TableName, VisitorData)
 
                    if (VisitorResp.status == 200) {
                        var LogData = {}
                        LogData.Date = IISMethods.getdatetimeisostr()

                        var tablename = 'DeviceLogsvisitor_' + IISMethods.getCurrentMonth(LogData.Date).toString() + '_' + IISMethods.getCurrentYear(LogData.Date).toString()

                        let date = IISMethods.getdateandtimeformiso(LogData.Date)

                        LogData.DeviceLogId = IISMethods.GetTimestamp()
                        LogData.LogDetail = null
                        LogData.deleted = 0
                        LogData.propertyid = req.headers.propertyid
                        LogData.property = req.headers.property
                        LogData.gatekeeperid = req.headers.uid
                        LogData.gatekeeper = req.headers.personname
                        // LogData.categoryid = req.body.categoryid
                        LogData.visitorid = VisitorResp.data._id
                        LogData.clockintype = 0
                        LogData.LogDate = new Date()
                        LogData.recordinfo = req.body.recordinfo

                        //already exist or not
                        let tblpipeline = [{ $match: { visitorid: ObjectId(req.body.visitorid) } },
                        { "$addFields": { "datelog": { $substr: ["$LogDate", 0, 10] } } },
                        { $match: { 'datelog': LogData.Date.slice(0, 10) } },
                        { $match: { 'deleted': { $ne: 1 } } },
                        ]
                        const tblresp = await MainDB.getmenual(tablename, new _LogManage(), tblpipeline)

                        //insert log
                        const resp = await MainDB.executedata('i', new _LogManage(), tablename, LogData)

                        ResponseBody.status = resp.status
                        ResponseBody.message = resp.message
                        //update clockin value in gatekeeper table
                        // if (resp.status == 200) {
                        //     var objVisitor = {
                        //         _id: ObjectId(req.body.visitorid),
                        //         clockin: req.body.clockin
                        //     }
                        //     await MainDB.executedata('u', new _Visitor(), TableName, objVisitor)

                        //     ResponseBody.status = 200
                        //     ResponseBody.message = Config.getErrmsg()['visitorin']
                        // } else {
                        //     ResponseBody.status = 404
                        //     ResponseBody.message = Config.getErrmsg()['nodatafound']
                        // }
                    } else {
                        ResponseBody.status = VisitorResp.status
                        ResponseBody.message = VisitorResp.message
                    }
                } else {
                    ResponseBody.status = 400
                    ResponseBody.message = Config.getErrmsg()['visitorexpired'] 
                    ResponseBody.data = []
                }
            }

            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }


    async AssetClockInOut(req, res, next) {
        try {
            var ResponseBody = {}

            let ObjectId = IISMethods.getobjectid()

            const pipeline = [{ $match: { propertyid: ObjectId(req.headers.propertyid), assetcode: req.body.otp } }]
            const AssetResp = await MainDB.getmenual("tblasset", new _Asset(), pipeline)

            if (AssetResp.ResultData.length > 0) {
                const {  wingid, wing, floorid, floor, unitid, unit, areaid, area,mobilenumber,guestname } = AssetResp.ResultData[0]

 
                    if (VisitorResp.status == 200) {
                        var LogData = {}
                        LogData.Date = IISMethods.getdatetimeisostr()

                        var tablename = 'DeviceLogsvisitor_' + IISMethods.getCurrentMonth(LogData.Date).toString() + '_' + IISMethods.getCurrentYear(LogData.Date).toString()

                        let date = IISMethods.getdateandtimeformiso(LogData.Date)

                        LogData.DeviceLogId = IISMethods.GetTimestamp()
                        LogData.LogDetail = null
                        LogData.deleted = 0
                        LogData.propertyid = req.headers.propertyid
                        LogData.property = req.headers.property
                        LogData.gatekeeperid = req.headers.uid
                        LogData.gatekeeper = req.headers.personname
                        // LogData.categoryid = req.body.categoryid
                        LogData.visitorid = AssetResp.ResultData[0]._id
                        LogData.clockintype = 1
                        LogData.LogDate = new Date()
                        LogData.recordinfo = req.body.recordinfo
                        LogData.visitorout = new Date()

                        //insert log
                        const resp = await MainDB.executedata('i', new _LogManage(), tablename, LogData)

                        //update clockin value in gatekeeper table
                        if (resp.status == 200) {
                            assineehistory.push({
                                assigneeid : obj.assignedtoid,
                                assignee : obj.assignedto,
                                changebyid : req.headers.uid,
                                changeby : req.headers.personname,
                                assetstatusid : req.body.assetstatusid,
                                assetstatus : req.body.assetstatus,
                                historytype : 1,
                                assigneetype : 2,
                                date : IISMethods.getdatetimeisostr(),
                                conditionnameid  : req.body.conditionnameid,
                                conditionname  : req.body.conditionname,
                                cid : timestamp
                            })

                            var objVisitor = {
                                _id: AssetResp.ResultData[0]._id,
                                clockin: req.body.clockin,
                                assineehistory:req.body.assineehistory
                            }
                            await MainDB.executedata('u', new _Asset(), "tblasset", objVisitor)

                            ResponseBody.status = 200
                            ResponseBody.message = Config.getErrmsg()['visitorin']
                        } else {
                            ResponseBody.status = 404
                            ResponseBody.message = Config.getErrmsg()['nodatafound']
                        }
                    } else {
                        ResponseBody.status = VisitorResp.status
                        ResponseBody.message = VisitorResp.message
                    }

            }

            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

    async VisitorCount(req, res, next) {
        try {
            var ResponseBody = {}
            let ObjectId = IISMethods.getobjectid()

            let timezone = req.headers.timezone || FieldConfig.timezone

            const getkeeperPipeline = [{ $match: { "propertyid": ObjectId(req.body.propertyid) } }]
            const getkeeperResp = await MainDB.getmenual('tblgatekeeper', new _GateKeeper(), getkeeperPipeline)

            const gatekeeper = getkeeperResp.ResultData[0]

            if (gatekeeper && gatekeeper.isactive == 1 && req.body.propertyid) {

                var LogData = {}
                LogData.Date = IISMethods.getdatetimeisostr()

                var tablename = 'DeviceLogsvisitor_' + IISMethods.getCurrentMonth(LogData.Date).toString() + '_' + IISMethods.getCurrentYear(LogData.Date).toString()

                const Logpipeline = [
                    {
                        $addFields: {
                            _LogDate: {
                                $dateToString: {
                                    format: "%Y-%m-%d",
                                    date: "$LogDate",
                                    timezone: timezone
                                }
                            }
                        }
                    },
                    {
                        $match: {
                            propertyid: ObjectId(req.body.propertyid)
                        }
                    },
                    {
                        $sort: {
                            "LogDate": -1
                        }
                    }
                ]

                const LogmangeResp = await MainDB.getmenual(tablename, new _LogManage(), Logpipeline)

                const personIdCounts = {};
                const visitiorids = []
                const VisitorClockin = []
                const VisitorClockout = []

                const Staffids = []
                const StaffClockin = []
                const StaffClockout = []

                const Taxiids = []
                const TaxiClockin = []
                const TaxiClockout = []

                // Iterate over the fetched data to count occurrences of each personid

                for (const obj of LogmangeResp.ResultData) {
                    const { visitorid, clockintype, _LogDate } = obj;

                    if (!personIdCounts[obj.visitorid]) {
                        if (obj.clockintype === 1) {
                            if (obj.categoryid?.toString() == Config.getStaffid()) {
                                StaffClockin.push(obj)
                                Staffids.push(obj.visitorid)
                            } else if (obj.categoryid?.toString() == Config.getTaxiid()) {
                                TaxiClockin.push(obj)
                                Taxiids.push(obj.visitorid)
                            }
                            else {
                                VisitorClockin.push(obj)
                                visitiorids.push(obj.visitorid)
                            }
                        } else if (obj.clockintype === 2 && obj._LogDate === LogData.Date.slice(0, 10)) {
                            if (obj.categoryid?.toString() == Config.getStaffid()) {
                                StaffClockout.push(obj)
                                Staffids.push(obj.visitorid)
                            } else if (obj.categoryid?.toString() == Config.getTaxiid()) {
                                TaxiClockout.push(obj)
                                Taxiids.push(obj.visitorid)
                            }
                            else {
                                VisitorClockout.push(obj);
                                visitiorids.push(obj.visitorid);
                            }
                        }
                        personIdCounts[visitorid] = { clockin: 1 }
                    }
                }

                const visitorPipeline = [{ $match: { _id: { $in: visitiorids }, "propertyid": ObjectId(req.body.propertyid) } }]
                const visitorResp = await MainDB.getmenual('tblvisitormaster', new _Visitor(), visitorPipeline)

                const IncidentResp = await MainDB.getmenual("tblincidentmaster", new _Incident(), [{ $match: {} }])


                const data = [{
                    "title": "Visitor",
                    "countlist": [
                        [
                            {
                                "label": "Total",
                                "count": VisitorClockin.length + VisitorClockout.length,
                                "gradientlist": [
                                    "0xFF51B6E7",
                                    "0xFF51B6E7",
                                    "0xFF42A9DE",
                                    "0xFF1C87C8",
                                    "0xFF0E7AC0",
                                ],
                                "gradientstoplist": [
                                    "0.0",
                                    "0.06",
                                    "0.33",
                                    "0.83",
                                    "1.0",
                                ]
                            },
                            {
                                "label": "In",
                                "count": VisitorClockin.length,
                                "gradientlist": [
                                    "0xFF9EC051",
                                    "0xFF9EC051",
                                    "0xFF87B84B",
                                    "0xFF70B046",
                                    "0xFF68AD44",
                                    "0xFF68AD44",
                                ],
                                "gradientstoplist": [
                                    "0.0",
                                    "0.04",
                                    "0.29",
                                    "0.62",
                                    "0.83",
                                    "1.0",
                                ]
                            },
                            {
                                "label": "Out",
                                "count": VisitorClockout.length,
                                "gradientlist": [
                                    "0xFFD8688E",
                                    "0xFFC7517C",
                                    "0xFFAC2C60",
                                    "0xFFA21E56",
                                ],
                                "gradientstoplist": [
                                    "0.0",
                                    "0.26",
                                    "0.74",
                                    "1.0",
                                ]
                            },
                        ]
                    ]
                },
                {
                    "title": "Staff",
                    "countlist": [
                        [
                            {
                                "label": "Total",
                                "count": StaffClockin.length + StaffClockout.length,
                                "gradientlist": [
                                    "0xFF51B6E7",
                                    "0xFF51B6E7",
                                    "0xFF42A9DE",
                                    "0xFF1C87C8",
                                    "0xFF0E7AC0",
                                ],
                                "gradientstoplist": [
                                    "0.0",
                                    "0.06",
                                    "0.33",
                                    "0.83",
                                    "1.0",
                                ]
                            },
                            {
                                "label": "In",
                                "count": StaffClockin.length,
                                "gradientlist": [
                                    "0xFF9EC051",
                                    "0xFF9EC051",
                                    "0xFF87B84B",
                                    "0xFF70B046",
                                    "0xFF68AD44",
                                    "0xFF68AD44",
                                ],
                                "gradientstoplist": [
                                    "0.0",
                                    "0.04",
                                    "0.29",
                                    "0.62",
                                    "0.83",
                                    "1.0",
                                ]
                            },
                            {
                                "label": "Out",
                                "count": StaffClockout.length,
                                "gradientlist": [
                                    "0xFFD8688E",
                                    "0xFFC7517C",
                                    "0xFFAC2C60",
                                    "0xFFA21E56",
                                ],
                                "gradientstoplist": [
                                    "0.0",
                                    "0.26",
                                    "0.74",
                                    "1.0",
                                ]
                            },
                        ],
                        [
                            {
                                "label": "Calls",
                                "count": "14",
                                "gradientlist": [
                                    "0xFF51B6E7",
                                    "0xFF51B6E7",
                                    "0xFF42A9DE",
                                    "0xFF1C87C8",
                                    "0xFF0E7AC0",
                                ],
                                "gradientstoplist": [
                                    "0.0",
                                    "0.06",
                                    "0.33",
                                    "0.83",
                                    "1.0",
                                ]
                            },
                            {
                                "label": "Guest Parking",
                                "count": "14",
                                "gradientlist": [
                                    "0xFF9EC051",
                                    "0xFF9EC051",
                                    "0xFF87B84B",
                                    "0xFF70B046",
                                    "0xFF68AD44",
                                    "0xFF68AD44",
                                ],
                                "gradientstoplist": [
                                    "0.0",
                                    "0.04",
                                    "0.29",
                                    "0.62",
                                    "0.83",
                                    "1.0",
                                ]
                            },
                            {
                                "label": "Incident",
                                "count": IncidentResp.ResultData.length,
                                "gradientlist": [
                                    "0xFFD8688E",
                                    "0xFFC7517C",
                                    "0xFFAC2C60",
                                    "0xFFA21E56",
                                ],
                                "gradientstoplist": [
                                    "0.0",
                                    "0.26",
                                    "0.74",
                                    "1.0",
                                ]
                            },
                        ]
                    ]
                },]

                // var data = {
                //     visitor:visitorResp.ResultData,
                //     totalvisitor: VisitorClockin.length + VisitorClockout.length,
                //     totalvisitorcount: VisitorClockin.length,
                //     totalvisitoroutcount: VisitorClockout.length
                // }

                ResponseBody.status = 200
                ResponseBody.message = Config.resstatuscode['200']
                ResponseBody.data = data
                ResponseBody.count = {
                    totalvisitor: VisitorClockin.length + VisitorClockout.length,
                    totalstaff: StaffClockin.length + StaffClockout.length,
                    totaltaxi: TaxiClockin.length + TaxiClockout.length
                }
                // ResponseBody.visitor = visitorResp.ResultData

            } else {
                ResponseBody.status = 404
                ResponseBody.message = Config.getErrmsg()['nodatafound']
            }

            req.ResponseBody = ResponseBody
            next()

        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

    async VisitorInOutList(req, res, next) {
        try {
            var ResponseBody = {}
            let ObjectId = IISMethods.getobjectid()

            let timezone = req.headers.timezone || FieldConfig.timezone
            var PaginationInfo = req.body.paginationinfo

            // if(req.body.propertyid)
            // const getkeeperPipeline = [{ $match: { "propertyid": ObjectId(req.headers.propertyid) } }]
            // const getkeeperResp = await MainDB.getmenual('tblgatekeeper', new _GateKeeper(), getkeeperPipeline)

            // const gatekeeper = getkeeperResp.ResultData[0]

            if (req.headers.propertyid) {

                var LogData = {}
                LogData.Date = IISMethods.getdatetimeisostr()

                var tablename = 'DeviceLogsvisitor_' + IISMethods.getCurrentMonth(LogData.Date).toString() + '_' + IISMethods.getCurrentYear(LogData.Date).toString()

                var Logpipeline = []

                // 0-visitor 1-staff 2-taxi
                if (req.body.isstaff == 1) {
                    Logpipeline.push({ $match: { categoryid: ObjectId(Config.getStaffid()) } })
                } else if (req.body.istaff == 2) {
                    Logpipeline.push({ $match: { categoryid: ObjectId(Config.getTaxiid()) } })
                }

                Logpipeline.push(
                    {
                        $addFields: {
                            _LogDate: {
                                $dateToString: {
                                    format: "%Y-%m-%d",
                                    date: "$LogDate",
                                    timezone: timezone
                                }
                            }
                        }
                    },
                    {
                        $match: {
                            propertyid: ObjectId(req.headers.propertyid)
                        }
                    },
                    {
                        $sort: {
                            "LogDate": -1
                        }
                    }
                )

                const LogmangeResp = await MainDB.getmenual(tablename, new _LogManage(), Logpipeline)

                const personIdCounts = {};
                const visitiorids = []
                const VisitorClockin = []
                const VisitorClockout = []

                // Iterate over the fetched data to count occurrences of each personid

                for (const obj of LogmangeResp.ResultData) {
                    const { visitorid, clockintype, _LogDate } = obj;

                    if (!personIdCounts[obj.visitorid]) {
                        if (obj.clockintype === 1) {
                            VisitorClockin.push(obj)
                            visitiorids.push(obj.visitorid)
                        } else if (obj.clockintype === 2 && obj._LogDate === LogData.Date.slice(0, 10)) {
                            VisitorClockout.push(obj)
                            visitiorids.push(obj.visitorid)
                        }
                        personIdCounts[visitorid] = { clockin: 1 }
                    }
                }

                const requiredPage = { pageno: PaginationInfo.pageno, skip: (PaginationInfo.pageno - 1) * PaginationInfo.pagelimit, pagelimit: PaginationInfo.pagelimit }
                var sort = (Object.keys(PaginationInfo.sort).length !== 0 ? PaginationInfo.sort : { '_id': -1 })
                let projection = PaginationInfo.projection ? PaginationInfo.projection : {}
                let fieldorder = req.body.paginationinfo.isfieldorder ? req.body.paginationinfo.isfieldorder : 0

                let visitorPipeline = []

                // Add the date filter to the pipeline
                visitorPipeline.push(...IISMethods.getDateFilterByOrFilter({fromdate: req.body.fromdate,todate: req.body.todate,filterkey1: "visitorin",filterkey2:"visitorout",timezone: req.headers.timezone,isequal:1}))
            
                // Append the result of GetPipelineForFilter to the existing pipeline
                visitorPipeline.push(...IISMethods.GetPipelineForFilter(PaginationInfo.filter))
                
                // Add the final match stage for filtering by `visitiorids` and `propertyid`
                visitorPipeline.push({ $match: {propertyid: ObjectId(req.headers.propertyid)}});

                const visitorResp = await MainDB.getmenual('tblvisitormaster', new _Visitor(), visitorPipeline, requiredPage, sort, fieldorder, "", projection)

                ResponseBody.status = 200
                ResponseBody.message = Config.resstatuscode['200']
                ResponseBody.pagename = "Visitorinout"
                ResponseBody.formname = "Visitor In/Out"
                ResponseBody.fltpagecollection = "visitorinout"
                ResponseBody.data = visitorResp.ResultData
                ResponseBody.fieldorder = visitorResp.fieldorderdata
                ResponseBody.currentpage = visitorResp.currentpage
                ResponseBody.nextpage = visitorResp.nextpage
                ResponseBody.totaldocs = visitorResp.totaldocs
                ResponseBody.fieldorder = visitorResp.fieldorderdata
           
            } else {
                ResponseBody.status = 400
                ResponseBody.message = Config.getErrmsg()['nodatafound']
            }

            req.ResponseBody = ResponseBody
            next()

        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }


    // Update Visitor
    async UpdateVisitorMaster(req, res, next) {
        try {

            const ObjectId = IISMethods.getobjectid()
            var ResponseBody = {}

            const pipeline = [{ $match: { '_id': ObjectId(req.body._id) } }]
            const record = await MainDB.getmenual(TableName, new _Visitor(), pipeline)

            var RecordInfo = record.ResultData[0].recordinfo
            RecordInfo.updateuid = req.headers.uid
            RecordInfo.updateby = req.headers.personname
            RecordInfo.updatedate = IISMethods.getdatetimeisostr()
            req.body.recordinfo = RecordInfo

            const resp = await MainDB.executedata('u', new _Visitor(), TableName, req.body)

            var ResponseBody = {}
            ResponseBody.status = resp.status
            ResponseBody.data = resp.data
            ResponseBody.message = resp.message

            req.ResponseBody = ResponseBody
            next()
        }
        catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        } 
    }


    async PreApproveGuest(req, res, next) {
        try {
            const ResponseBody = {}
            const ObjectId = IISMethods.getobjectid()

            ResponseBody.status = 400
            ResponseBody.message = Config.getResponsestatuscode()['400']

            const pipeline = [{ $match: { propertyid: ObjectId(req.headers.propertyid), otp: req.body.otp } }]
            const approveResp = await MainDB.getmenual("tblapprovemaster", new _Approve(), pipeline)

            if (approveResp.ResultData.length > 0) {
                const { startdate, enddate,approvetype } = approveResp.ResultData[0]
                let isexpired = IISMethods.isDateBetween(startdate, req.body.entrydate, enddate)

                if(approvetype == 4){
                    isexpired = true
                }
                
                if (isexpired) {
                    ResponseBody.status = 200
                    ResponseBody.message = "Successfully Approved"
                    ResponseBody.data = approveResp.ResultData[0]
                } else {
                    ResponseBody.status = 400
                    ResponseBody.message = "Code Is Expired"
                    ResponseBody.data = []
                }
            } else {
                ResponseBody.status = 404
                ResponseBody.message = "approver not found or OTP invalid"
                ResponseBody.data = []
            }

            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

    // Delete Visitor
    async DeleteVisitorMaster(req, res, next) {
        try {
            const ResponseBody = {}

            const resp = await MainDB.executedata("d", new _Visitor(), TableName, req.body)

            ResponseBody.status = resp.status
            ResponseBody.message = resp.message

            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

}
