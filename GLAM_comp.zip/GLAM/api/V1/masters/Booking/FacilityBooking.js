import { IISMethods, MainDB, Config, FieldConfig } from "../../../../config/Init.js"
import _FacilityBooking from "../../../../model/FacilityBooking.js"
import _FacilityBookingReq from '../../../../model/FacilityBookingReq.js'
import _FacilityRating from '../../../../model/FacilityRating.js'
import { PropertyFacility } from '../../../../model/masters/Property/PropertyMaster.js'
import _Series from '../../../../model/masters/Series.js'

const TableName = "tblfacilitybooking"
const PageName = "facilitybooking"
const FormName = "facilitybooking"
const FltPageCollection = "facilitybooking"

export default class FacilityBooking {
    // List facilitybooking
    async ListFacilityBooking(req, res, next) {
        try {
            var ResponseBody = {}
            var PaginationInfo = req.body.paginationinfo

            const ObjectId = IISMethods.getobjectid()

            const requiredPage = { pageno: PaginationInfo.pageno, skip: (PaginationInfo.pageno - 1) * PaginationInfo.pagelimit, pagelimit: PaginationInfo.pagelimit }
            var pipeline = []
            var sort = (Object.keys(PaginationInfo.sort).length !== 0 ? PaginationInfo.sort : { '_id': -1 })
            let projection = PaginationInfo.projection ? PaginationInfo.projection : {}
            let fieldorder = PaginationInfo.isfieldorder ? PaginationInfo.isfieldorder : 0

            const searchtext = req.body.searchtext || ""
            if (searchtext !== "") {
                pipeline.push(...IISMethods.GetGlobalSearchFilter(new _FacilityBooking(), searchtext))
            }

            if (PaginationInfo.filter) {
                if (PaginationInfo.filter.hasOwnProperty('fromdate') || PaginationInfo.filter.hasOwnProperty('todate')) {


                    if (PaginationInfo.filter.hasOwnProperty('fromdate') && PaginationInfo.filter.hasOwnProperty('todate')) {
                        const fromdate = new Date(PaginationInfo.filter["fromdate"]);
                        const todate = new Date(PaginationInfo.filter["todate"]);
                        pipeline.push(...IISMethods.getDateFilter({ 'fromdate': fromdate, 'todate': todate, 'filterkey': 'bookingdate', 'timezone': FieldConfig.timezone, isequal:true}));
                    } else if (PaginationInfo.filter.hasOwnProperty('fromdate')) {
                        const fromdate = new Date(PaginationInfo.filter["fromdate"]);

                        const filterkey = 'bookingdate'
                        pipeline.push({
                            $match: {
                                [`${filterkey}`]: {
                                    $gte: fromdate
                                },
                            },
                        })

                    } else if (PaginationInfo.filter.hasOwnProperty('todate')) {
                        const todate = new Date(PaginationInfo.filter["todate"]);
                        const filterkey = 'bookingdate'

                        pipeline.push({
                            $match: {
                                [`${filterkey}`]: {
                                    $lte: todate
                                },
                            },
                        })
                    }
                }

                delete PaginationInfo.filter["fromdate"]
                delete PaginationInfo.filter["todate"]

                pipeline.push(...IISMethods.GetPipelineForFilter(PaginationInfo.filter))
            }       

            const resp = await MainDB.getmenual(TableName, new _FacilityBooking(), pipeline, requiredPage, sort, fieldorder, "", projection)

            ResponseBody.pagename = PageName
            ResponseBody.formname = FormName
            ResponseBody.fltpagecollection = FltPageCollection
            ResponseBody.status = 200
            ResponseBody.message = Config.getResponsestatuscode()['200']
            ResponseBody.data = resp.ResultData
            ResponseBody.currentpage = resp.currentpage
            ResponseBody.nextpage = resp.nextpage
            ResponseBody.totaldocs = resp.totaldocs;
            ResponseBody.fieldorder = resp.fieldorderdata
            ResponseBody.formfieldorderdata = resp.formfieldorderdata

            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

    // Insert facilitybooking
    async InsertFacilityBooking(req, res, next) {
        try {
            const ObjectId = IISMethods.getobjectid()
            const ResponseBody = {}

            // GET SERIES FROM SERIES TABLE
            const seriesPipeline = [{ $match: { seriestype: "facilitybooking", propertyid: new ObjectId(req.headers.propertyid) } }, { $limit: 1 }]
            const seriesResp = await MainDB.getmenual('tblseriesmaster', new _Series(), seriesPipeline)

            ResponseBody.status = 400
            ResponseBody.message = Config.errmsg['reqseries']

            req.body.propertyid = req.headers.propertyid
            req.body.property = req.headers.property

            if (seriesResp.ResultData.length) {
                if (req.body.facilityid && req.body.slot) {

                    const pipeline = [{ $match: { 'propertyid': ObjectId(req.headers.propertyid), '_id': ObjectId(req.body.facilityid), 'isactive': 1 } }, { $project: { _id: 1 } }]
                    const facilityResp = await MainDB.getmenual("tblpropertyfacility", new PropertyFacility(), pipeline)

                    if (facilityResp.ResultData.length) {

                        const SlotCondition = req.body.slot?.map(slot => ({ "slot.starttime": { $lt: new Date(slot.endtime) }, "slot.endtime": { $gt: new Date(slot.starttime) } }))

                        const bookingpipeline = [
                            {
                                $match: {
                                    facilityid: ObjectId(req.body.facilityid)
                                }
                            },
                            {
                                $unwind: "$slot"
                            },
                            {
                                $match: {
                                    $or: SlotCondition
                                }
                            }
                        ]

                        const bookingResp = await MainDB.getmenual(TableName, new _FacilityBooking(), bookingpipeline)

                        if (!bookingResp.ResultData?.length) {

                            let seriesid = await MainDB.getseriesno(new ObjectId(req.headers.propertyid), seriesResp.ResultData[0]._id, 'facilitybooking', new PropertyFacility())
                            let maxid = await MainDB.getmaxid(seriesResp.ResultData[0]._id, 'facilitybooking', new PropertyFacility())

                            req.body.seriesid = seriesResp.ResultData[0]._id
                            req.body.maxid = maxid
                            req.body.seriesno = seriesid

                            const resp = await MainDB.executedata("i", new _FacilityBooking(), TableName, req.body)

                            //booking log 
                            if (resp.status == 200) {
                                const ReqLog = {
                                    propertyid: req.headers.propertyid,
                                    customerid: req.headers.uid,
                                    facilityid: req.body.facilityid,
                                    slot: req.body.slot,
                                    isapproved: 0,
                                    isbooking: 0,
                                    isrequest: 1,
                                    req_body: JSON.stringify(req.body)
                                }
                                await MainDB.executedata("i", new _FacilityBookingReq(), "tblfacilitybookingreq", ReqLog)
                            }

                            ResponseBody.status = resp.status
                            ResponseBody.message = resp.message
                            ResponseBody.data = resp.data
                        } else {
                            ResponseBody.status = 400
                            ResponseBody.message = Config.errmsg['alreadybooked']
                        }
                    } else {
                        ResponseBody.status = 404
                        ResponseBody.message = Config.errmsg['nodatafound']
                    }
                } else {
                    ResponseBody.status = 400
                    ResponseBody.message = Config.getResponsestatuscode()["400"]
                }
            }else {
                ResponseBody.status = 400
                ResponseBody.message = Config.errmsg['seriesnotfound']
            }
            
            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

    // Update facilitybooking
    async UpdateFacilityBooking(req, res, next) {
        try {
            console.log(1111);
            
            const ObjectId = IISMethods.getobjectid()
            var ResponseBody = {}

            const pipeline = [{ $match: { '_id': ObjectId(req.body._id) } }]
            const record = await MainDB.getmenual(TableName, new _FacilityBooking(), pipeline)

            var RecordInfo = record.ResultData[0].recordinfo

            RecordInfo.updateuid = req.headers.uid
            RecordInfo.updateby = req.headers.personname
            RecordInfo.updatedate = IISMethods.getdatetimeisostr()
            req.body.recordinfo = RecordInfo

            // if (record.ResultData[0].status == 0) {
            const resp = await MainDB.executedata('u', new _FacilityBooking(), TableName, req.body)
            ResponseBody.status = resp.status
            ResponseBody.data = resp.data
            ResponseBody.message = resp.message
            // } else {
            //     ResponseBody.status = 400
            //     ResponseBody.message = Config.errmsg['noteditable']
            // }

            req.ResponseBody = ResponseBody
            next()
        }
        catch (err) {
            console.log(err);
            
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

    async ApproveRejectFacilityBooking(req, res, next) {
        try {
            const ObjectId = IISMethods.getobjectid()
            var ResponseBody = {}

            const pipeline = [{ $match: { '_id': ObjectId(req.body._id) } }]
            const facilitybookingResp = await MainDB.getmenual(TableName, new _FacilityBooking(), pipeline)

            var facilitybooking = facilitybookingResp.ResultData[0]

            if (facilitybooking) {

                for (var obj of facilitybooking.slot) {
                    obj.isapproved = req.body.status
                }

                req.body.slot = facilitybooking.slot
                const resp = await MainDB.executedata('u', new _FacilityBooking(), TableName, req.body)

                //booking log manage
                if (resp.status == 200) {
                    const ReqLog = {
                        propertyid: req.headers.propertyid,
                        customerid: req.headers.customerid,
                        facilityid: req.body.facilityid,
                        slot: resp.data?.slot,
                        status: resp.data?.status,
                        rejectreason: resp.data?.rejectreason,
                        req_body: JSON.stringify(req.body)
                    }
                    await MainDB.executedata("i", new _FacilityBookingReq(), "tblfacilitybookingreq", ReqLog)
                }

                ResponseBody.status = resp.status
                ResponseBody.data = resp.data
                ResponseBody.message = resp.message
            } else {
                ResponseBody.status = 404
                ResponseBody.message = Config.errmsg['nodatafound']
            }

            req.ResponseBody = ResponseBody
            next()

        }catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

    //Facility Rating
    async ListFacilityRating(req, res, next) {
        try {
            var ResponseBody = {}
            var PaginationInfo = req.body.paginationinfo

            const requiredPage = { pageno: PaginationInfo.pageno, skip: (PaginationInfo.pageno - 1) * PaginationInfo.pagelimit, pagelimit: PaginationInfo.pagelimit }
            var pipeline = []
            var sort = (Object.keys(PaginationInfo.sort).length !== 0 ? PaginationInfo.sort : { '_id': -1 })
            let projection = PaginationInfo.projection ? PaginationInfo.projection : {}

            pipeline = IISMethods.GetPipelineForFilter(PaginationInfo.filter)

            const searchtext = req.body.searchtext || ""
            if (searchtext !== "") {
                pipeline.push(...IISMethods.GetGlobalSearchFilter(new _FacilityRating(), searchtext))
            }

            const resp = await MainDB.getmenual("tblfacilityrating", new _FacilityRating(), pipeline, requiredPage, sort, true, "", projection)


            ResponseBody.pagename = "facilityrating"
            ResponseBody.formname = "Facilityrating"
            ResponseBody.fltpagecollection = "facilityrating"
            ResponseBody.status = 200
            ResponseBody.message = Config.getResponsestatuscode()['200']
            ResponseBody.data = resp.ResultData
            ResponseBody.currentpage = resp.currentpage
            ResponseBody.nextpage = resp.nextpage
            ResponseBody.totaldocs = resp.totaldocs;
            ResponseBody.fieldorder = resp.fieldorderdata
            ResponseBody.formfieldorderdata = resp.formfieldorderdata

            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }


    //insert facility rating
    async InsertFacilityRating(req, res, next) {
        try {
            const ResponseBody = {}
            const ObjectId = IISMethods.getobjectid()

            const resp = await MainDB.executedata("i", new _FacilityRating(), "tblfacilityrating", req.body)

            //also update in facility
            if (resp.status == 200) {

                const rating = {
                    customerid: resp.data?.customerid,
                    customer: resp.data?.customer,
                    rating: resp.data?.rating,
                    date: resp.data?.date
                }

                const updatePipeline = [{ _id: new ObjectId(req.body.facilityid) }, { $push: { rating: rating } }]
                await MainDB.Update("tblpropertyfacility", new PropertyFacility(), updatePipeline)
            }

            ResponseBody.status = resp.status
            ResponseBody.message = resp.message
            ResponseBody.data = resp.data

            req.ResponseBody = ResponseBody
            next()
        }
        catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }


    //already booking slot
    async ListAssignSlot(req, res, next) {
        try {
            const ObjectId = IISMethods.getobjectid()
            var ResponseBody = {}
            // Checks if the required fields (month, year, propertyid, and facilityid) are present 
            if (req.body.month && req.body.year && req.headers.propertyid && req.body.facilityid) {

                // Destructures startdate and enddate 
                const { startdate, enddate } = IISMethods.getStartAndEndDate(req.body.month, req.body.year)

                const pipeline = [
                    {
                        $match: {
                            'propertyid': ObjectId(req.headers.propertyid),
                            'facilityid': ObjectId(req.body.facilityid),
                        },
                    },
                    { $unwind: "$slot" },
                    {
                        $addFields: {
                            _fromdate: {
                                $dateToString: {
                                    format: "%Y-%m-%d %H:%M",
                                    date: "$slot.starttime",
                                    timezone: FieldConfig.timezone
                                }
                            },
                            _todate: {
                                $dateToString: {
                                    format: "%Y-%m-%d %H:%M",
                                    date: "$slot.endtime",
                                    timezone: FieldConfig.timezone
                                }
                            }
                        }
                    },
                    {
                        $match: {
                            $and: [
                                {
                                    _fromdate: {
                                        "$gte": IISMethods.getFormatWiseDate(startdate, 10, true)
                                    },
                                    _todate: {
                                        "$lte": IISMethods.getFormatWiseDate(enddate, 10, true)
                                    }
                                }
                            ]
                        }
                    },
                    {
                        $project: { "isapproved": 1, "_fromdate": 1, "_todate": 1, "slot": 1 }
                    }
                ]


                // Gets the facilitybooking data based on the provided propertyid and facilityid
                const facilitybookingResp = await MainDB.getmenual(TableName, new _FacilityBooking(), pipeline)

                const facilitypipeline = [
                    { $match: { "_id": ObjectId(req.body.facilityid), "propertyid": ObjectId(req.headers.propertyid) } }, {
                        $addFields: {
                            timeslot: {
                                $map: {
                                    input: "$timeslot",
                                    as: "slot",
                                    in: {
                                        slotid: "$$slot._id",
                                        starttime: "$$slot.starttime",
                                        endtime: "$$slot.endtime",
                                        isrequest: "$$slot.isrequest",
                                        isbooked: 0,
                                        ismaintenance:0
                                    }
                                }
                            }
                        }
                    }, { $project: { "disableslot": 1, "timeslot": 1 } }
                ]
                const facilityResp = await MainDB.getmenual("tblpropertyfacility", new PropertyFacility(), facilitypipeline)

                // Initialize totalslot as 0 and disableslot as an empty array
                let totalslot = 0
                let disableslot = []
                let allotment= []

                if (facilityResp.ResultData && facilityResp.ResultData.length) {
                    allotment = facilityResp.ResultData[0]?.timeslot
                    totalslot = facilityResp.ResultData[0]?.timeslot?.length

                    // If disableslot is present, filter disableslot to exclude slots with start times before the startdate
                    if (facilityResp.ResultData[0]?.disableslot) {
                        disableslot = facilityResp.ResultData[0].disableslot.filter(slot => slot.starttime?.slice(0, 10) >= startdate);
                    }
                }

                // This will generate an array of dates between the provided start and end dates

                const daterange = IISMethods.getDatesInRange(startdate, enddate);
                const data = {};
                
                // Initialize the date range with default values
                for (const obj of daterange) {
                    const formattedDate = obj.date.toISOString().slice(0, 10);
                
                    if (!data[formattedDate]) {
                        data[formattedDate] = {
                            date: formattedDate,
                            slot: allotment.map(slot => ({
                                ...slot, // Copy slot structure
                                isbooked: 0, // Default to not booked
                                ismaintenance: 0 // Default to no maintenance
                            })),
                            count: 0,
                            avaliableslot: totalslot
                        };
                    }
                }
                
                // Update the data with disabled slots
                if (disableslot?.length) {
                    for (const disabled of disableslot) {
                        const startDate = disabled.starttime.slice(0, 10);
                        const endDate = disabled.endtime.slice(0, 10);

                        if (data[startDate]) {
                            for (const slot of data[startDate].slot) {
                                if (slot.slotid.toString() === disabled.slotid?.toString()) {
                                    slot.isbooked = 0;
                                    slot.ismaintenance = 1;
                                    break; // Exit the loop after updating the slot
                                }
                            }
                        }
                
                        // Ensure the disabled slot is marked for all relevant dates
                        // for (const key in data) {
                        //     if (key >= startDate && key <= endDate) {
                        //         const slotToDisable = data[key].slot.find(slot => slot.slotid === disabled.slotid);
                        //         if (slotToDisable) {
                        //             slotToDisable.isbooked = 1;
                        //             slotToDisable.ismaintenance = 1;
                        //             data[key].count++;
                        //             data[key].avaliableslot = Math.max(0, totalslot - data[key].count);
                        //         }
                        //     }
                        // }
                    }
                }
                
                // Update the data with facility booking response
                if (facilitybookingResp.ResultData && facilitybookingResp.ResultData.length) {
                    for (const Obj of facilitybookingResp.ResultData) {
                        if (Obj.slot.isapproved != 2) {
                            const objDate = Obj._fromdate.slice(0, 10);
                            if (data[objDate]) {
                                for (const slot of data[objDate].slot) {
                                    if (slot.slotid.toString() === Obj.slot.slotid?.toString()) {
                                        slot.isbooked = 1;
                                        slot.ismaintenance = 0;
                                        break; // Exit the loop after updating the slot
                                    }
                                }
                            }
                        }
                    }
                }
                
                // Convert the data object to an array
                const newdata = Object.keys(data).map(key => ({
                    date: new Date(data[key].date),
                    slot: data[key].slot,
                    count: data[key].count,
                    avaliableslot: data[key].avaliableslot
                }));

                // const daterange = IISMethods.getDatesInRange(startdate, enddate)
                // const data = {}

                // for (const obj of daterange) {
                //     const formattedDate = obj.date.toISOString().slice(0, 10);

                //     // Initialize data for the formattedDate if it doesn't exist
                //     if (!data[formattedDate]) {
                //         data[formattedDate] = {
                //             date: formattedDate,
                //             slot: allotment,
                //             count: 0,
                //             avaliableslot: totalslot
                //         };
                //     }

                //     if (disableslot?.length) {
                //         const disabled = disableslot.find(disabled => formattedDate === disabled.starttime.slice(0, 10) && formattedDate === disabled.endtime.slice(0, 10))

                //         if (disabled) {
                //             // Push the disabled slot to the corresponding date
                //             // for (let slot of data[formattedDate].slot) {
                //             //     if (slot.slotid === disabled.slotid) {
                //             //         slot.isbooked = 1
                //             //         slot.ismaintenance = 1
                //             //         break; // Exit the loop once the match is found and updated
                //             //     }
                //             // }

                //             // Increase the slot count for that date
                //             data[formattedDate].count += 1

                //             // Update available slots if totalslot is defined and greater than or equal to 1
                //             if (totalslot >= 1) {
                //                 data[formattedDate].avaliableslot = totalslot - data[formattedDate].count
                //             }
                //         }
                //     }
                // }


                // if (facilitybookingResp.ResultData && facilitybookingResp.ResultData.length) {
                //     for (const Obj of facilitybookingResp.ResultData) {
                //         // Only process bookings where the slot's approval status is not equal to 2
                //         if (Obj.slot.isapproved != 2) {
                //             // Extract the date from _fromdate and slice it to the "YYYY-MM-DD" format
                //             const objDate = Obj._fromdate.slice(0, 10)
                //             if (data[objDate]) {
                //             // console.log("🚀 ~ FacilityBooking ~ ListAssignSlot ~ data[objDate]:", data[objDate])
                //             // console.log("🚀 ~ FacilityBooking ~ ListAssignSlot ~ Obj.slot.slotid:", Obj.slot.slotid)

                //                 for (var avaliableslot of data[objDate].slot) {
                //                     console.log("calling 1",avaliableslot)
                //                     if (avaliableslot.slotid.toString() == Obj.slot.slotid.toString()) {
                //                         avaliableslot.isbooked = 1
                //                         avaliableslot.ismaintenance = 0
                //                     }
                //                 }
                //             }
                //         }
                //     }
                // }

                // var newdata = []
                // console.log("🚀 ~ FacilityBooking ~ ListAssignSlot ~ data:", JSON.stringify(data))


                // // Loop through each key in the 'data' object
                // for (const key in data) {
                //     newdata.push({
                //         date: new Date(data[key].date),
                //         slot: data[key].slot,
                //         count: data[key].count,
                //         avaliableslot: data[key].avaliableslot
                //     })
                // }

                ResponseBody.status = 200
                ResponseBody.data = newdata
                ResponseBody.message = 'ok'

                req.ResponseBody = ResponseBody
                next()

            } else {
                ResponseBody.status = 200
                ResponseBody.message = Config.errmsg['nodatafound']
            }
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }


    // Delete facilitybooking 
    // async DeleteFacilityBooking(req, res, next) {
    //     try {
    //         const ResponseBody = {}

    //         const resp = await MainDB.executedata('d', new _FacilityBooking(), TableName, req.body)

    //         if (resp.status == 200) {
    //             const ReqLog = {
    //                 propertyid: req.body.propertyid,
    //                 customerid: req.body._id,
    //                 facilityid: req.body.facilityid,
    //                 slot: req.body.slot,
    //                 isapproved: 0,
    //                 isbooking: 0,
    //                 req_body: JSON.stringify(req.body),
    //                 iscancel:1
    //             }
    //             await MainDB.executedata("i", new _FacilityBookingReq(), "tblfacilitybookingreq", ReqLog)
    //         }

    //         ResponseBody.status = resp.status
    //         ResponseBody.message = resp.message

    //         req.ResponseBody = ResponseBody
    //         next()
    //     } catch (err) {
    //         req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
    //         next()
    //     }
    // }

}
