import { IISMethods, MainDB, Config, FieldConfig } from "../../../../config/Init.js"
import _DailyhelpBooking from "../../../../model/masters/DailyhelpBooking.js"
import _DailyhelpBookingReq from '../../../../model/masters/DailyhelpBookingReq.js'
import _DailyhelpRating from '../../../../model/masters/DailyhelpRating.js'
import _Dailyhelp from '../../../../model/Onboarding/DailyHelp.js'
import _Customer from '../../../../model/Onboarding/Customer.js'
import _Series from '../../../../model/masters/Series.js'

const TableName = "tbldailyhelpbooking"
const PageName = "dailyhelpbooking"
const FormName = "dailyhelpbooking"
const FltPageCollection = "dailyhelpbooking"

export default class DailyhelpBooking {
    // List dailyhelpbooking
    async ListDailyhelpBooking(req, res, next) {
        try {
            var ResponseBody = {}
            var PaginationInfo = req.body.paginationinfo

            const ObjectId = IISMethods.getobjectid()

            const requiredPage = { pageno: PaginationInfo.pageno, skip: (PaginationInfo.pageno - 1) * PaginationInfo.pagelimit, pagelimit: PaginationInfo.pagelimit }
            var pipeline = []
            var sort = (Object.keys(PaginationInfo.sort).length !== 0 ? PaginationInfo.sort : { '_id': -1 })
            let projection = PaginationInfo.projection ? PaginationInfo.projection : {}
            let fieldorder = PaginationInfo.isfieldorder ? PaginationInfo.isfieldorder : 0

            pipeline = IISMethods.GetPipelineForFilter(PaginationInfo.filter)

            const searchtext = req.body.searchtext || ""
            if (searchtext !== "") {
                pipeline.push(...IISMethods.GetGlobalSearchFilter(new _DailyhelpBooking(), searchtext))
            }

            const resp = await MainDB.getmenual(TableName, new _DailyhelpBooking(), pipeline, requiredPage, sort, fieldorder, "", projection)

            ResponseBody.pagename = PageName
            ResponseBody.formname = FormName
            ResponseBody.fltpagecollection = FltPageCollection
            ResponseBody.status = 200
            ResponseBody.message = Config.getResponsestatuscode()['200']
            ResponseBody.data = resp.ResultData
            ResponseBody.currentpage = resp.currentpage
            ResponseBody.nextpage = resp.nextpage
            ResponseBody.totaldocs = resp.totaldocs;
            ResponseBody.fieldorder = resp.fieldorderdata
            ResponseBody.formfieldorderdata = resp.formfieldorderdata

            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

    // Insert dailyhelpbooking
    async InsertDailyhelpBooking(req, res, next) {
        try {
            const ObjectId = IISMethods.getobjectid()
            const ResponseBody = {}

            ResponseBody.status = 400
            ResponseBody.message = Config.errmsg['reqseries']

            // GET SERIES FROM SERIES TABLE
            const seriesPipeline = [{ $match: { seriestype: "dailyhelpbooking", propertyid: new ObjectId(req.headers.propertyid) } }, { $limit: 1 }]
            const seriesResp = await MainDB.getmenual('tblseriesmaster', new _Series(), seriesPipeline)

            if(!seriesResp.ResultData.length){
                if (req.body.propertyid && req.body.customerid && req.body.dailyhelpid && req.body.slot) {

                    const pipeline = [{ $match: { 'propertyid': ObjectId(req.body.propertyid), '_id': ObjectId(req.body.dailyhelpid), 'isactive': 1 } }]
                    const dailyhelpResp = await MainDB.getmenual("tbldailyhelp", new _Dailyhelp(), pipeline)
    
                    if (dailyhelpResp.ResultData.length) {
    
                        const SlotCondition = req.body.slot?.map(slot => ({ "slot.starttime": { $lt: new Date(slot.endtime) }, "slot.endtime": { $gt: new Date(slot.starttime) } }))
    
                        const bookingpipeline = [
                            {
                                $match: {
                                    dailyhelpid: ObjectId(req.body.dailyhelpid)
                                }
                            },
                            {
                                $unwind: "$slot"
                            },
                            {
                                $match: {
                                    $or: SlotCondition
                                }
                            }
                        ]
                        const bookingResp = await MainDB.getmenual(TableName, new _DailyhelpBooking(), bookingpipeline)
    
                        if (!bookingResp.ResultData?.length) {
    
                            let seriesid = await MainDB.getseriesno(new ObjectId(req.headers.propertyid), seriesResp.ResultData[0]._id, 'dailyhelp', new _Dailyhelp())
                            let maxid = await MainDB.getmaxid(seriesResp.ResultData[0]._id, 'dailyhelp', new _Dailyhelp())
    
                            req.body.seriesid = seriesResp.ResultData[0]._id
                            req.body.maxid = maxid
                            req.body.seriesno = seriesid
    
                            const resp = await MainDB.executedata("i", new _DailyhelpBooking(), TableName, req.body)
    
                            if (resp.status == 200) {
                                const ReqLog = {
                                    propertyid: req.body.propertyid,
                                    customerid: req.body.customerid,
                                    dailyhelpid: req.body.dailyhelpid,
                                    slot: req.body.slot,
                                    isapproved: 0,
                                    isbooking: 0,
                                    isrequest: 1,
                                    req_body: JSON.stringify(req.body)
                                }
                                await MainDB.executedata("i", new _DailyhelpBookingReq(), "tbldailyhelpbookingreq", ReqLog)
    
                                //add more details of customer
                                const customerpipeline = [{ $match: { '_id': ObjectId(req.body.customerid), 'property.propertyid': ObjectId(req.body.propertyid) } }]
                                const customerResp = await MainDB.getmenual("tblcustomer", new _Customer(), customerpipeline)
    
                                if (customerResp.ResultData.length) {
    
                                    let workin = {
                                        customerid: resp.data?.customerid,
                                        customer: resp.data?.customer,
                                        propertyid: resp.data?.propertyid,
                                        property: resp.data?.property
                                    }
    
                                    for (var obj of customerResp.ResultData[0]?.property) {
                                        if (obj.propertyid == req.body.propertyid) {
                                            workin.wingid = obj?.wingid,
                                                workin.wing = obj?.wing,
                                                workin.unitid = obj?.unitid,
                                                workin.unit = obj?.unit
                                        }
                                    }
                                    const updatePipeline = [{ _id: new ObjectId(req.body.dailyhelpid) }, { $push: { workin: workin } }]
                                    await MainDB.Update("tbldailyhelp", new _Dailyhelp(), updatePipeline)
                                }
                            }
    
                            ResponseBody.status = resp.status
                            ResponseBody.message = resp.message
                            ResponseBody.data = resp.data
                        } else {
                            ResponseBody.status = 400
                            ResponseBody.message = Config.errmsg['alreadybooked']
                        }
                    } else {
                        ResponseBody.status = 404
                        ResponseBody.message = Config.errmsg['nodatafound']
                    }
                } else {
                    ResponseBody.status = 400
                    ResponseBody.message = Config.getResponsestatuscode()["400"]
                }
            }else{
                ResponseBody.status = 400
                ResponseBody.message = Config.errmsg['seriesnotfound']
            }

           

            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

    // Update Dailyhelpbooking
    async UpdateDailyhelpBooking(req, res, next) {
        try {

            const ObjectId = IISMethods.getobjectid()
            var ResponseBody = {}

            const pipeline = [{ $match: { '_id': ObjectId(req.body._id) } }]
            const record = await MainDB.getmenual(TableName, new _DailyhelpBooking(), pipeline)

            var RecordInfo = record.ResultData[0].recordinfo


            RecordInfo.updateuid = req.headers.uid
            RecordInfo.updateby = req.headers.personname
            RecordInfo.updatedate = IISMethods.getdatetimeisostr()
            req.body.recordinfo = RecordInfo

            const resp = await MainDB.executedata('u', new _DailyhelpBooking(), TableName, req.body)

            if (resp.status == 200) {
               
                const ReqLog = {
                    propertyid: req.body.propertyid,
                    customerid: req.body.customerid,
                    facilityid: req.body.facilityid,
                    slot: resp.data?.slot,
                    isapproved: req.body.isapproved,
                    isbooking: req.body.isbooking,
                    iscancel: resp.data?.iscancel,
                    cancelreason: resp.data?.cancelreason,
                    isapproved: resp.data?.isapproved,
                    rejectreason: resp.data?.rejectreason,
                    req_body: JSON.stringify(req.body)
                }
                await MainDB.executedata("i", new _DailyhelpBookingReq(), "tbldailyhelpbookingreq", ReqLog)

                if(resp.data?.iscancel == 1){
                    
                }
            }

            var ResponseBody = {}
            ResponseBody.status = resp.status
            ResponseBody.data = resp.data
            ResponseBody.message = resp.message

            req.ResponseBody = ResponseBody
            next()
        }
        catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

    async ListDailyhelpRating(req, res, next) {
        try {
            var ResponseBody = {}
            var PaginationInfo = req.body.paginationinfo

            const requiredPage = { pageno: PaginationInfo.pageno, skip: (PaginationInfo.pageno - 1) * PaginationInfo.pagelimit, pagelimit: PaginationInfo.pagelimit }
            var pipeline = []
            var sort = (Object.keys(PaginationInfo.sort).length !== 0 ? PaginationInfo.sort : { '_id': -1 })
            let projection = PaginationInfo.projection ? PaginationInfo.projection : {}

            pipeline = IISMethods.GetPipelineForFilter(PaginationInfo.filter)

            const searchtext = req.body.searchtext || ""
            if (searchtext !== "") {
                pipeline.push(...IISMethods.GetGlobalSearchFilter(new _DailyhelpRating(), searchtext))
            }

            const resp = await MainDB.getmenual("tbldailyhelprating", new _DailyhelpRating(), pipeline, requiredPage, sort, true, "", projection)


            ResponseBody.pagename = "facilityrating"
            ResponseBody.formname = "Facilityrating"
            ResponseBody.fltpagecollection = "facilityrating"
            ResponseBody.status = 200
            ResponseBody.message = Config.getResponsestatuscode()['200']
            ResponseBody.data = resp.ResultData
            ResponseBody.currentpage = resp.currentpage
            ResponseBody.nextpage = resp.nextpage
            ResponseBody.totaldocs = resp.totaldocs;
            ResponseBody.fieldorder = resp.fieldorderdata
            ResponseBody.formfieldorderdata = resp.formfieldorderdata

            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }


    async InsertDailyhelpRating(req, res, next) {
        try {
            const ResponseBody = {}
            const ObjectId = IISMethods.getobjectid()

            const resp = await MainDB.executedata("i", new _DailyhelpRating(), "tbldailyhelprating", req.body)

            if (resp.status == 200) {

                const rating = {
                    customerid: resp.data?.customerid,
                    customer: resp.data?.customer,
                    rating: resp.data?.rating,
                    date: resp.data?.date
                }

                const updatePipeline = [{ _id: new ObjectId(req.body.dailyhelpid) }, { $push: { rating: rating } }]
                await MainDB.Update("tbldailyhelp", new _Dailyhelp(), updatePipeline)
            }

            ResponseBody.status = resp.status
            ResponseBody.message = resp.message
            ResponseBody.data = resp.data

            req.ResponseBody = ResponseBody
            next()
        }
        catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }


    async ListAssignSlot(req, res, next) {
        try {
            const ObjectId = IISMethods.getobjectid()
            var ResponseBody = {}
            
            if (req.body.month && req.body.year && req.body.propertyid && req.body.dailyhelpid) {

                const { startdate, enddate } = IISMethods.getStartAndEndDate(req.body.month, req.body.year)

                const pipeline = [
                    {
                        $match: {
                            'propertyid': ObjectId(req.body.propertyid),
                            'dailyhelpid': ObjectId(req.body.dailyhelpid)
                        },
                    },
                    { $unwind: "$slot" },
                    {
                        $addFields: {
                            _fromdate: {
                                $dateToString: {
                                    format: "%Y-%m-%d %H:%M",
                                    date: "$slot.starttime",
                                    timezone: FieldConfig.timezone
                                }
                            },
                            _todate: {
                                $dateToString: {
                                    format: "%Y-%m-%d %H:%M",
                                    date: "$slot.endtime",
                                    timezone: FieldConfig.timezone
                                }
                            }
                        }
                    },
                    {
                        $match: {
                            $and: [
                                {
                                    _fromdate: {
                                        "$gte": IISMethods.getFormatWiseDate(startdate, 10, true)
                                    },
                                    _todate: {
                                        "$lte": IISMethods.getFormatWiseDate(enddate, 10, true)
                                    }
                                }
                            ]
                        }
                    },
                    {
                        $project: { "isapproved": 1, "_fromdate": 1, "_todate": 1, "slot": 1 }
                    }
                ]

                const dailyhelpbookingResp = await MainDB.getmenual(TableName, new _DailyhelpBooking(), pipeline)


                const dailyhelppipeline = [
                    { $match: { "_id": ObjectId(req.body.facilityid), "propertyid": ObjectId(req.headers.propertyid) } }, {
                        $addFields: {
                            timeslot: {
                                $map: {
                                    input: "$timeslot",
                                    as: "slot",
                                    in: {
                                        slotid: "$$slot._id",
                                        starttime: "$$slot.starttime",
                                        endtime: "$$slot.endtime",
                                        isrequest: "$$slot.isrequest",
                                        isbooked: 0,
                                        ismaintenance:0
                                    }
                                }
                            }
                        }
                    }, { $project: { "disableslot": 1, "timeslot": 1 } }
                ]
                const dailyhelpResp = await MainDB.getmenual("tbldailyhelp", new _Dailyhelp(), dailyhelppipeline)

                let totalslot = 0
                let disableslot = []
                let allotment= []

                if (dailyhelpResp.ResultData && dailyhelpResp.ResultData.length) {
                    allotment = facilityResp.ResultData[0]?.timeslot
                    totalslot = dailyhelpResp.ResultData[0]?.slot?.length

                    if (dailyhelpResp.ResultData[0]?.disableslot) {
                        disableslot = dailyhelpResp.ResultData[0].disableslot.filter(slot => slot.starttime?.slice(0, 10) >= startdate);
                    }
                }

                const daterange = IISMethods.getDatesInRange(startdate, enddate)
                const data = {}


              // Initialize the date range with default values
              for (const obj of daterange) {
                const formattedDate = obj.date.toISOString().slice(0, 10);
            
                if (!data[formattedDate]) {
                    data[formattedDate] = {
                        date: formattedDate,
                        slot: allotment.map(slot => ({
                            ...slot, // Copy slot structure
                            isbooked: 0, // Default to not booked
                            ismaintenance: 0 // Default to no maintenance
                        })),
                        count: 0,
                        avaliableslot: totalslot
                    };
                }
            }

                if (facilitybookingResp.ResultData && facilitybookingResp.ResultData.length) {
                    for (const Obj of facilitybookingResp.ResultData) {
                        if (Obj.slot.isapproved != 2) {
                            const objDate = Obj._fromdate.slice(0, 10);
                            if (data[objDate]) {
                                for (const slot of data[objDate].slot) {
                                    if (slot.slotid.toString() === Obj.slot.slotid?.toString()) {
                                        slot.isbooked = 1;
                                        break; // Exit the loop after updating the slot
                                    }
                                }
                            }
                        }
                    }
                }


                // Convert the data object to an array
                const newdata = Object.keys(data).map(key => ({
                    date: new Date(data[key].date),
                    slot: data[key].slot,
                    count: data[key].count,
                    avaliableslot: data[key].avaliableslot
                }));

      
                ResponseBody.status = 200
                ResponseBody.data = newdata
                ResponseBody.message = 'ok'

                req.ResponseBody = ResponseBody
                next()

            }
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }
    // Delete facilitybooking 
    // async DeleteFacilityBooking(req, res, next) {
    //     try {
    //         const ResponseBody = {}

    //         const resp = await MainDB.executedata('d', new _DailyhelpBooking(), TableName, req.body)

    //         if (resp.status == 200) {
    //             const ReqLog = {
    //                 propertyid: req.body.propertyid,
    //                 customerid: req.body._id,
    //                 facilityid: req.body.facilityid,
    //                 slot: req.body.slot,
    //                 isapproved: 0,
    //                 isbooking: 0,
    //                 req_body: JSON.stringify(req.body),
    //                 iscancel:1
    //             }
    //             await MainDB.executedata("i", new _DailyhelpBookingReq(), "tblfacilitybookingreq", ReqLog)
    //         }

    //         ResponseBody.status = resp.status
    //         ResponseBody.message = resp.message

    //         req.ResponseBody = ResponseBody
    //         next()
    //     } catch (err) {
    //         req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
    //         next()
    //     }
    // }

}
