import { IISMethods, MainDB, Config,FieldConfig } from "../../../../config/Init.js"
import _FacilityRating from '../../../../model/FacilityRating.js'
import _VendorBooking from '../../../../model/masters/VendorBooking.js'
import _Vendor from '../../../../model/Onboarding/Vendor.js'
import _Customer from '../../../../model/Onboarding/Customer.js'

const TableName = "tblvendorbooking"
const PageName = "vendorbooking"
const FormName = "vendorbooking"
const FltPageCollection = "vendorbooking"

export default class VendorBooking {
    // List vendorbooking
    async ListVendorBooking(req, res, next) {
        try {
            var ResponseBody = {}
            var PaginationInfo = req.body.paginationinfo

            const ObjectId = IISMethods.getobjectid()

            const requiredPage = { pageno: PaginationInfo.pageno, skip: (PaginationInfo.pageno - 1) * PaginationInfo.pagelimit, pagelimit: PaginationInfo.pagelimit }
            var pipeline = []
            var sort = (Object.keys(PaginationInfo.sort).length !== 0 ? PaginationInfo.sort : { '_id': -1 })
            let projection = PaginationInfo.projection ? PaginationInfo.projection : {}
            let fieldorder = PaginationInfo.isfieldorder ? PaginationInfo.isfieldorder : 0

            pipeline = IISMethods.GetPipelineForFilter(PaginationInfo.filter)

            const searchtext = req.body.searchtext || ""
            if (searchtext !== "") {
                pipeline.push(...IISMethods.GetGlobalSearchFilter(new _VendorBooking(), searchtext))
            }

            const resp = await MainDB.getmenual(TableName, new _VendorBooking(), pipeline, requiredPage, sort, fieldorder, "", projection)

            ResponseBody.pagename = PageName
            ResponseBody.formname = FormName
            ResponseBody.fltpagecollection = FltPageCollection
            ResponseBody.status = 200
            ResponseBody.message = Config.getResponsestatuscode()['200']
            ResponseBody.data = resp.ResultData
            ResponseBody.currentpage = resp.currentpage
            ResponseBody.nextpage = resp.nextpage
            ResponseBody.totaldocs = resp.totaldocs;
            ResponseBody.fieldorder = resp.fieldorderdata
            ResponseBody.formfieldorderdata = resp.formfieldorderdata

            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

    // Insert vendorbooking
    async InsertVendorBooking(req, res, next) {
        try {
            const ObjectId = IISMethods.getobjectid()
            const ResponseBody = {}

            // GET SERIES FROM SERIES TABLE
            const seriesPipeline = [{ $match: { seriestype: "vendor", propertyid: new ObjectId(req.headers.propertyid) } }, { $limit: 1 }]
            const seriesResp = await MainDB.getmenual('tblseriesmaster', new _Series(), seriesPipeline)
    
            ResponseBody.status = 400
            ResponseBody.message = Config.errmsg['reqseries']
    
            if (seriesResp.ResultData.length && req.body.propertyid && req.body.customerid && req.body.vendorid) {

                const pipeline = [{ $match: { '_id': ObjectId(req.body.vendorid), 'isactive': 1 } }]
                const vendorResp = await MainDB.getmenual("tblvendormaster", new _Vendor(), pipeline)

                if (vendorResp.ResultData.length) {

                    const resp = await MainDB.executedata("i", new _VendorBooking(), TableName, req.body)

                    if (resp.status == 200) {

                        const customerpipeline = [{ $match: { '_id': ObjectId(req.body.customerid), 'property.propertyid': ObjectId(req.body.propertyid) } }]
                        const customerResp = await MainDB.getmenual("tblcustomer", new _Customer(), customerpipeline)

                        if (customerResp.ResultData.length) {

                            let workin = {
                                customerid: resp.data?.customerid,
                                customer: resp.data?.customer,
                                propertyid: resp.data?.propertyid,
                                property: resp.data?.property
                            }

                            for (var obj of customerResp.ResultData[0]?.property) {
                                if (obj.propertyid.toString() == req.body.propertyid) {
                                    workin.wingid = obj?.wingid,
                                        workin.wing = obj?.wing,
                                        workin.unitid = obj?.unitid,
                                        workin.unit = obj?.unit
                                }
                            }

                            const updatePipeline = [{ _id: new ObjectId(req.body.vendorid) }, { $push: { workin: workin } }]
                            await MainDB.Update("tblvendormaster", new _Vendor(), updatePipeline)
                        }
                    }

                    ResponseBody.status = resp.status
                    ResponseBody.message = resp.message
                    ResponseBody.data = resp.data
                } else {
                    ResponseBody.status = 404
                    ResponseBody.message = Config.errmsg['nodatafound']
                }
            } else {
                ResponseBody.status = 400
                ResponseBody.message = Config.getResponsestatuscode()["400"]
            }

            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

    // Update vendorbooking
    async UpdateVendorBooking(req, res, next) {
        try {

            const ObjectId = IISMethods.getobjectid()
            var ResponseBody = {}

            const pipeline = [{ $match: { '_id': ObjectId(req.body._id) } }]
            const record = await MainDB.getmenual(TableName, new _VendorBooking(), pipeline)

            var RecordInfo = record.ResultData[0].recordinfo

                RecordInfo.updateuid = req.headers.uid
                RecordInfo.updateby = req.headers.personname
                RecordInfo.updatedate = IISMethods.getdatetimeisostr()
                req.body.recordinfo = RecordInfo
            

            const resp = await MainDB.executedata('u', new _VendorBooking(), TableName, req.body)

            if (resp.status == 200) {

                const bookingResp = record.ResultData[0]

                const pipeline = [{ $match: { '_id': resp.data?.vendorid,'isactive':1 } }]
                const vendorResp = await MainDB.getmenual("tblvendormaster", new _Vendor(), pipeline)

                if(vendorResp.ResultData.length){

                    const customerpipeline = [{ $match: { '_id': resp.data?.customerid, 'property.propertyid': ObjectId(req.body.propertyid) } }]
                    const customerResp = await MainDB.getmenual("tblcustomer", new _Customer(), customerpipeline)
    
                    if (customerResp.ResultData.length) {
    
                        let workin = {
                            customerid: resp.data?.customerid,
                            customer: resp.data?.customer,
                            propertyid: resp.data?.propertyid,
                            property: resp.data?.property
                        }
    
                        for (var obj of customerResp.ResultData[0]?.property) {
                            if (obj.propertyid.toString() == req.body.propertyid) {
                                    workin.wingid = obj?.wingid,
                                    workin.wing = obj?.wing,
                                    workin.unitid = obj?.unitid,
                                    workin.unit = obj?.unit
                            }
                        }
                        
                        const updatePipeline = [
                            { _id: new ObjectId(resp.data?.vendorid), 'workin.customerid': resp.data?.customerid },
                            { $set: {
                                'workin.$.propertyid': workin?.propertyid,
                                'workin.$.property': workin?.property,
                                'workin.$.wingid': workin?.wingid,
                                'workin.$.wing': workin?.wing,
                                'workin.$.unitid': workin?.unitid,
                                'workin.$.unit': workin?.unit,
                                'workin.$.isactive': workin?.isactive
                            }}
                        ];
                        
                        await MainDB.Update("tblvendormaster", new _Vendor(), updatePipeline);
                       }  
                }
            }

            
            var ResponseBody = {}
            ResponseBody.status = resp.status
            ResponseBody.data = resp.data
            ResponseBody.message = resp.message

            req.ResponseBody = ResponseBody
            next()
        }
        catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

    //vendor rating
    async ListVendorRating(req, res, next) {
        try {
            var ResponseBody = {}
            var PaginationInfo = req.body.paginationinfo

            const requiredPage = { pageno: PaginationInfo.pageno, skip: (PaginationInfo.pageno - 1) * PaginationInfo.pagelimit, pagelimit: PaginationInfo.pagelimit }
            var pipeline = []
            var sort = (Object.keys(PaginationInfo.sort).length !== 0 ? PaginationInfo.sort : { '_id': -1 })
            let projection = PaginationInfo.projection ? PaginationInfo.projection : {}

            pipeline = IISMethods.GetPipelineForFilter(PaginationInfo.filter)

            const searchtext = req.body.searchtext || ""
            if (searchtext !== "") {
                pipeline.push(...IISMethods.GetGlobalSearchFilter(new _FacilityRating(), searchtext))
            }

            const resp = await MainDB.getmenual("tblvendorrating", new _FacilityRating(), pipeline, requiredPage, sort, true, "", projection)


            ResponseBody.pagename = "vendorrating"
            ResponseBody.formname = "Vendorrating"
            ResponseBody.fltpagecollection = "vendorrating"
            ResponseBody.status = 200
            ResponseBody.message = Config.getResponsestatuscode()['200']
            ResponseBody.data = resp.ResultData
            ResponseBody.currentpage = resp.currentpage
            ResponseBody.nextpage = resp.nextpage
            ResponseBody.totaldocs = resp.totaldocs;
            ResponseBody.fieldorder = resp.fieldorderdata
            ResponseBody.formfieldorderdata = resp.formfieldorderdata

            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }


    //add vendor rating
    async InsertVendorRating(req,res,next){
        try{
            const ResponseBody = {}
            const ObjectId = IISMethods.getobjectid()

			const resp = await MainDB.executedata("i", new _FacilityRating(), "tblvendorrating", req.body)

            if(resp.status == 200){

                  const rating = {
                        customerid:resp.data?.customerid,
                        customer:resp.data?.customer,
                        rating:resp.data?.rating,
                        date:resp.data?.date
                    }
                 
                const updatePipeline = [{ _id: new ObjectId(req.body.vendorid) }, { $push: { rating: rating } }]
                await MainDB.Update("tblvendor", new _Vendor(), updatePipeline)
            }

			ResponseBody.status = resp.status
			ResponseBody.message = resp.message
            ResponseBody.data = resp.data

			req.ResponseBody = ResponseBody
            next()
        }
        catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

}
