import { IISMethods,MainDB, Config,IISAutoTest } from "../../../config/Init.js"
import _City from "../../../model/masters/City.js"
import _Pincode from '../../../model/masters/PincodeMaster.js'
import {Propertycommon} from '../../../model/masters/Property/PropertyMaster.js'
import _Customer from '../../../model/Onboarding/Customer.js'
import _Gatekeeper from '../../../model/Onboarding/GateKeeper.js'
import _Employee from '../../../model/Onboarding/Employee.js'

const TableName = "tblcitymaster"
const PageName = "city"
const FormName = "city"
const FltPageCollection = "citymaster"

export default class CityMaster {
	// List city
	async ListCity(req, res, next) {
		try {
            
            var ResponseBody = {}
            var PaginationInfo =  req.body.paginationinfo

            const requiredPage = {pageno : PaginationInfo.pageno, skip : (PaginationInfo.pageno - 1) * PaginationInfo.pagelimit, pagelimit : PaginationInfo.pagelimit}
            var pipeline = []
            var sort = (Object.keys(PaginationInfo.sort).length !== 0 ? PaginationInfo.sort : {'_id' :-1})
            let projection = PaginationInfo.projection ? PaginationInfo.projection : {}
            let fieldorder = req.body.paginationinfo.isfieldorder ? req.body.paginationinfo.isfieldorder : 0

            pipeline = IISMethods.GetPipelineForFilter(PaginationInfo.filter)

            const searchtext = req.body.searchtext || ""
            if (searchtext !== "") {
                pipeline.push(...IISMethods.GetGlobalSearchFilter(new _City(), searchtext))
            }
            const resp = await MainDB.getmenual(TableName, new _City(), pipeline, requiredPage, sort, fieldorder,"", projection)
            console.log("🚀 ~ CityMaster ~ ListCity ~ pipeline:", JSON.stringify(pipeline))

            ResponseBody.pagename = PageName
            ResponseBody.formname = FormName
			ResponseBody.fltpagecollection = FltPageCollection
            ResponseBody.status = 200
            ResponseBody.message = Config.getResponsestatuscode()['200']
            ResponseBody.data = resp.ResultData
            ResponseBody.currentpage = resp.currentpage
            ResponseBody.nextpage = resp.nextpage
            ResponseBody.totaldocs = resp.totaldocs
            ResponseBody.fieldorder = resp.fieldorderdata   
            ResponseBody.formfieldorderdata = resp.formfieldorderdata            

            req.ResponseBody = ResponseBody
            next()
		} catch (err) {
			req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
			next()
		}
	}


	// Insert City
	async InsertCity(req, res, next) {
		try {
			const ResponseBody = {}
                        
			const resp = await MainDB.executedata("i", new _City(), TableName, req.body)

			ResponseBody.status = resp.status
			ResponseBody.message = resp.message
            ResponseBody.data = resp.data

			req.ResponseBody = ResponseBody
			next()
		} catch (err) {
			req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
			next()
		}
	}

	// Update City
	async UpdateCity(req, res, next) {
		 try {

            const ObjectId = IISMethods.getobjectid()
            var ResponseBody = {}

            const pipeline = [{ $match: { '_id': ObjectId(req.body._id) } }]
            const record = await MainDB.getmenual(TableName, new _City(), pipeline)
            
            var RecordInfo = record.ResultData[0].recordinfo
            RecordInfo.updateuid = req.headers.uid
            RecordInfo.updateby = req.headers.personname
            RecordInfo.updatedate = IISMethods.getdatetimeisostr()
            req.body.recordinfo = RecordInfo

             //Dependency Check
             const pincodeObjModel = await MainDB.createmodel('tblpincodemaster', new _Pincode())
             const propertyObjModel = await MainDB.createmodel('tblproperty', new Propertycommon())
             const customerObjModel = await MainDB.createmodel('tblcustomer', new _Customer())
             const employeeObjModel = await MainDB.createmodel('tblemployee', new _Employee())
             const gatekeeperObjModel = await MainDB.createmodel('tblgatekeeper', new _Gatekeeper())

             var dependency = [
                 [pincodeObjModel['objModel'], { cityid: req.body._id }, "Pincode"],
                 [propertyObjModel['objModel'], { cityid: req.body._id }, "Property"],
                 [customerObjModel['objModel'], { cityid: req.body._id }, "Customer"],
                 [employeeObjModel['objModel'], { cityid: req.body._id }, "Employee"],
                 [gatekeeperObjModel['objModel'], { cityid: req.body._id }, "Gatekeeper"],
             ]

            const resp = await MainDB.executedata('u', new _City(), TableName, req.body, true, dependency)

             if (resp == 200) {

                 // Update Dependency
                 const updatePipeline = [{ cityid: req.body._id },{ $set: { city: req.body.city } }]
                 
                 const updateModelObj = {
                     tblpropertymaster: new Propertycommon(),
                     tblemployee: new _Employee(),
                     tblcustomer: new _Customer(),
                     tblgatekeeper: new _Gatekeeper()
                 }
                 
                 const tempArray = []
                 for (const key in updateModelObj) {
                     tempArray.push(MainDB.UpdateMany(key, updateModelObj[key], updatePipeline))
                 }
                 await Promise.all(tempArray)
             }

            var ResponseBody = {}
            ResponseBody.status = resp.status
            ResponseBody.data = resp.data
            ResponseBody.message = resp.message

            req.ResponseBody = ResponseBody
            next()
        }
        catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
	}

	// Delete City
	async DeleteCity(req, res, next) {
		try {
			const ResponseBody = {}

            //Dependency Check
            const pincodeObjModel = await MainDB.createmodel('tblpincodemaster', new _Pincode())
            const propertyObjModel = await MainDB.createmodel('tblproperty', new Propertycommon())
            const customerObjModel = await MainDB.createmodel('tblcustomer', new _Customer())
            const employeeObjModel = await MainDB.createmodel('tblemployee', new _Employee())
            const gatekeeperObjModel = await MainDB.createmodel('tblgatekeeper', new _Gatekeeper())

            var dependency = [
                    [pincodeObjModel['objModel'], { cityid: req.body._id },"Pincode"],
                    [propertyObjModel['objModel'], { cityid: req.body._id },"Property"],
                    [customerObjModel['objModel'], { cityid: req.body._id },"Customer"],
                    [employeeObjModel['objModel'], { cityid: req.body._id },"Employee"],
                    [gatekeeperObjModel['objModel'], { cityid: req.body._id },"Gatekeeper"],
                ]
    
            const resp = await MainDB.executedata('d', new _City(), TableName, req.body, true, dependency)

			ResponseBody.status = resp.status
			ResponseBody.message = resp.message

			req.ResponseBody = ResponseBody
			next()
		} catch (err) {
			req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
			next()
		}
	}

}
