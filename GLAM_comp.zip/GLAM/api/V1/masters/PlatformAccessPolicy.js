import { IISMethods, Config } from "../../../config/Init.js"
import _Menu from "../../../model/masters/Menu.js"
import _PlatformAccessPolicy from "../../../model/staff_registration/PlatformAccessPolicy.js"
// import _Person from "../../../model/Person_new.js"

const TableName = "tblplatformaccesspolicy"
const PageName = "Platform Access Policy"
const FormName = "Platform Access Policy"
const FltPageCollection = "platformaccesspolicy"

export default class PlatformAccessPolicy {
	// List Platform Access Policy
	async ListPlatformAccessPolicy(req, res, next) {
		try {
			const ResponseBody = {}

			const {
				searchtext = "",
				paginationinfo: { projection = {}, nextpageid = "", pageno = 1, pagelimit = 10, filter = {}, sort = {} }
			} = req.body || {} 

			const requiredPage = {
				nextpageid: nextpageid,
                pageno: pageno,
                skip: (pageno - 1) * pagelimit,
				pagelimit: pagelimit
			}
			let fieldorder = req.body.paginationinfo.isfieldorder ? req.body.paginationinfo.isfieldorder : 0

			const sortData = Object.keys(sort).length !== 0 ? sort : { _id: -1 }

			const pipeline = IISMethods.GetPipelineForFilter(filter)

			if (searchtext !== "") {
				pipeline.push(...IISMethods.GetGlobalSearchFilter(new _PlatformAccessPolicy(), searchtext))
			}

			const resp = await MainDB.getmenual(TableName, new _PlatformAccessPolicy(), pipeline, requiredPage, sortData, fieldorder, "", projection) 
			
			ResponseBody.pagename = PageName
			ResponseBody.formname = FormName
			ResponseBody.fltpagecollection = FltPageCollection
			ResponseBody.status = 200
			ResponseBody.message = Config.getResponsestatuscode()["200"]
			ResponseBody.data = resp.ResultData
			ResponseBody.fieldorder = resp.fieldorderdata
			ResponseBody.currentpage = resp.currentpage
			ResponseBody.nextpage = resp.nextpage

			req.ResponseBody = ResponseBody
			next()
		} catch (err) {
			req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
			next()
		}
	}

	// Insert Platform Access Policy
	async InsertPlatformAccessPolicy(req, res, next) {
		try {
			const ResponseBody = {}

			const resp = await MainDB.executedata("i", new _PlatformAccessPolicy(), TableName, req.body)

			ResponseBody.status = resp.status
			ResponseBody.message = resp.message

			req.ResponseBody = ResponseBody
			next()
		} catch (err) {
			req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
			next()
		}
	}

	// Update Platform Access Policy
	async UpdatePlatformAccessPolicy(req, res, next) {
		try {
			const ResponseBody = {}
			const ObjectId = IISMethods.getobjectid()

			const pipeline = { _id: req.body._id }
			const platformaccesspolicy = await MainDB.FindOne(TableName, new _PlatformAccessPolicy(), pipeline)

			if (platformaccesspolicy) {
				// record info Update data set
				const RecordInfo = platformaccesspolicy.recordinfo
				RecordInfo.updateuid = req.headers.uid
				RecordInfo.updateby = req.headers.personname
				RecordInfo.updatedate = IISMethods.getdatetimestr()
				req.body.recordinfo = RecordInfo

				const resp = await MainDB.executedata("u", new _PlatformAccessPolicy(), TableName, req.body)

				const updatePipeline = [{ "platformaccesspolicy.policyid": req.body._id }, { $set: { "platformaccesspolicy.$[i].policyname": req.body.policyname } },
				{ arrayFilters: [{ "i.policyid": ObjectId(req.body._id) }] }]

				const updateModelObj = {
					tblpersonmaster: new _Person()
				}

				const tempArray = []
				for (const key in updateModelObj) {
					tempArray.push(MainDB.UpdateManyByFilter(key, updateModelObj[key], updatePipeline))
				}
				await Promise.all(tempArray)

				ResponseBody.status = resp.status
				ResponseBody.message = resp.message
				ResponseBody.data = resp.data
			} else {
				ResponseBody.status = 404
				ResponseBody.message = Config.getErrmsg()["notexist"]
			}

			req.ResponseBody = ResponseBody
			next()
		} catch (err) {
			req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
			next()
		}
	}

	// Delete Platform Access Policy
	async DeletePlatformAccessPolicy(req, res, next) {
		try {
			const ResponseBody = {}
			const ObjectId = IISMethods.getobjectid()
			// Dependency Check
			const dependencyObj = {
				tblpersonmaster: new _Person(),
			}

			// Dependency Array
			const dependency = []
			for (const key in dependencyObj) {
				const ObjModel = await MainDB.createmodel(key, dependencyObj[key])

				dependency.push([ObjModel["objModel"], { "platformaccesspolicy.policyid": ObjectId(req.body._id) }, Config.apipagename[key]])
			}

			const resp = await MainDB.executedata("d", new _PlatformAccessPolicy(), TableName, req.body, true, dependency)

			ResponseBody.status = resp.status
			ResponseBody.message = resp.message
			ResponseBody.existdataPagename = resp.existdataPagename

			req.ResponseBody = ResponseBody
			next()
		} catch (err) {
			req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
			next()
		}
	}

	// List Pagename
	async ListPlatformFormname(req, res, next) {
		try {
			const ResponseBody = {}
			const ObjectId = IISMethods.getobjectid()

			// Get Platform Access Policy
			const platformaccesspolicyPipeline = [{ $match: { _id: req.body._id ? ObjectId(req.body._id) : new ObjectId(), moduletypeid: ObjectId(req.body.moduletypeid) } }]
			const platformaccesspolicyResp = await MainDB.getmenual(TableName, new _PlatformAccessPolicy(), platformaccesspolicyPipeline)
			const platformaccesspolicy = platformaccesspolicyResp.ResultData[0]

			/***************************** Menu *****************************/
			const menuPipeline = [
				{ $match: { moduletypeid: ObjectId(req.body.moduletypeid), containright: 1, dashboardrights: 0 } },
				{
					$project: {
						formname: 1,
						alias: 1
					}
				},
				{
					$addFields: {
						allowips: [],
						denyips: []
					}
				},
				{ $sort: { formname: 1 } }
			]
			const menuResp = await MainDB.getmenual("tblmenumaster", new _Menu(), menuPipeline)
			/***************************** Menu *****************************/

			if (!platformaccesspolicy) {
				ResponseBody.data = menuResp.ResultData
			} else {
				const combineData = []

				// Add from rights only if it exists in menu
				for (const rightsObj of platformaccesspolicy.data) {
					const hasMenu = menuResp.ResultData.find((menuObj) => menuObj.alias === rightsObj.alias)

					if (hasMenu) {
						combineData.push(rightsObj)
					}
				}

				// Add from menu if new menu found
				for (const menuObj of menuResp.ResultData) {
					const hasRights = platformaccesspolicy.data.find((rightsObj) => rightsObj.alias === menuObj.alias)

					if (!hasRights) {
						combineData.push(menuObj)
					}
				}

				combineData.sort((a, b) => a.formname - b.formname)

				ResponseBody.data = combineData
			}

			ResponseBody.status = 200
			ResponseBody.message = Config.getResponsestatuscode()["200"]

			req.ResponseBody = ResponseBody
			next()
		} catch (err) {
			req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
			next()
		}
	}
}
