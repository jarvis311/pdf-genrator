import { IISMethods, Config, MainDB, FieldConfig } from '../../../../config/Init.js'
import _LogManage from '../../../../model/masters/Payroll/LogManage.js'
import { Propertycommon } from '../../../../model/masters/Property/PropertyMaster.js'
import _ClockinRequest from '../../../../model/masters/Payroll/ClockinRequest.js'
import _Gatekeeper from '../../../../model/Onboarding/GateKeeper.js'
import _Holiday from '../../../../model/masters/Holiday.js'
import _LogRegularizations from '../../../../model/masters/Payroll/LogRegularizations.js'
import _Visitor from '../../../../model/GateKeeper/Visitor.js'
import _Patrolling from '../../../../model/masters/Patrolling/Patrolling.js'

import _ from 'lodash'

export default class LogManageMaster {

    // START LogManage Master
    //List
    async MyLog(req, res, next) {
        try {
            const ResponseBody = {}

            const timezone = req.headers.timezone
            const personid = req.headers.uid
            let totaltime = 0

            const {
                paginationinfo: {
                    filter: { startdate = "" }
                }
            } = req.body

            const enddate = new Date(new Date(startdate).setUTCHours(23, 59, 59, 999))

            const dateFilter = IISMethods.getDateFilter({ fromdate: startdate, todate: enddate, filterkey: "LogDate", timezone })

            // log manage
            const logPipeline = [
                {
                    $match: {
                        UserId: personid,
                        logtype: { $in: [1, 2, 3] },
                        deleted: { $ne: 1 }
                    }
                },
                { $addFields: { _sortLogDate: { $cond: [{ $eq: ["$ActualLogDate", null] }, "$LogDate", "$ActualLogDate"] } } },
                ...dateFilter,
                { $sort: { _sortLogDate: 1 } },
                { $project: { _id: 1, LogDate: 1, logtype: 1, ActualLogDate: 1, ismanual: 1, logrequestid: 1, logrequeststatus: 1, islateclockin: 1, ispaid: 1 } }
            ]

            const TableName = "DeviceLogs_" + IISMethods.getCurrentMonth(startdate).toString() + "_" + IISMethods.getCurrentYear(startdate).toString()

            const resp = await MainDB.getmenual(TableName, new _LogManage(), logPipeline)

            const clockInOutData = resp.ResultData?.filter((data) => data.logtype == 1) //filter clock in-out data 

            //Resp data 
            const respData = []

            //Timer data  
            const timerData = []

            //************* Start clock in or out log ************* 
            let clockintime = 0
            let rejectLog = 0;
            for (let i = 0; i < clockInOutData.length; i++) {

                clockInOutData[i].letLogDate = clockInOutData[i].LogDate //letLogDate for sorting 
                //log date  

                //is in or out log = inoutlog -> 0 (IN) , 1 (OUT)
                if (i % 2 === 0) {
                    clockInOutData[i].inoutlog = 0

                    //calculate total time for clock in out logs
                    const clockindate = clockInOutData[i].ActualLogDate && clockInOutData[i].ActualLogDate !== null ? clockInOutData[i].ActualLogDate : clockInOutData[i].LogDate
                    const clockoutdate = clockInOutData[i + 1]?.ActualLogDate && clockInOutData[i + 1]?.ActualLogDate !== null ? clockInOutData[i + 1]?.ActualLogDate : clockInOutData[i + 1]?.LogDate ? clockInOutData[i + 1]?.LogDate : new Date()


                    const diff = IISMethods.getTimeDifference(clockindate, clockoutdate)//Diff in milliseconds 
                    const diffInSeconds = diff ? diff / 1000 : 0 //Diff in seconds 
                    clockInOutData[i].inoutlogtime = diffInSeconds

                    if (!clockInOutData[i + 1]?.logrequestid || clockInOutData[i + 1]?.logrequestid.toString() == Config.dummyObjid || (clockInOutData[i + 1]?.logrequestid.toString() != Config.dummyObjid && clockInOutData[i + 1]?.logrequeststatus == 1)) {
                        clockintime += diffInSeconds
                        rejectLog = 1
                    }

                } else {
                    clockInOutData[i].inoutlogtime = 0
                    clockInOutData[i].inoutlog = 1
                    if (!clockInOutData[i]?.logrequestid || clockInOutData[i]?.logrequestid.toString() == Config.dummyObjid || (clockInOutData[i]?.logrequestid.toString() != Config.dummyObjid && clockInOutData[i]?.logrequeststatus == 1) || (clockInOutData[i]?.logrequestid.toString() != Config.dummyObjid && clockInOutData[i]?.logrequeststatus == 2)) {
                        rejectLog = 1
                    }
                }

                const logDataObj = {
                    _id: clockInOutData[i]._id,
                    LogDate: clockInOutData[i].LogDate,
                    letLogDate: clockInOutData[i].letLogDate, //for sorting
                    inoutlog: clockInOutData[i].inoutlog, //inoutlog - 0 (in) , 1 (out) 
                    inoutlogtime: clockInOutData[i].inoutlogtime ? clockInOutData[i].inoutlogtime : 0, 
                    logtype: clockInOutData[i].logtype,
                    ismanual: clockInOutData[i].ismanual,
                    isactualdate: clockInOutData[i].ActualLogDate && clockInOutData[i].ActualLogDate !== null ? 1 : 0,
                    ActualLogDate: clockInOutData[i].ActualLogDate,
                    rejectedLog: rejectLog
                }

                respData.push(logDataObj)

            }

            //timer data 
            const clockInOutTimerData = {
                logtype: 1,
                time: clockintime,
                isstart: clockInOutData.length % 2 === 1 ? 1 : 0
            }

            totaltime += clockintime

            timerData.push(clockInOutTimerData)

            //************* End clock in or out log ************* 

            let isWeekOff = 0 //-> 1 = weekof, 2 = holiday  

            //Get Week off Data
            let personData
            if (req.body.apptype || req.headers.pagename) {
                const personResp = await MainDB.getPersonData({ apptype: req.headers.apptype, personid: [req.headers.uid], pagename: req.headers.pagename })
                personData = personResp[0]
            }


            const groupedData = [];

            for (let i = 0; i < respData.length; i += 2) {
                const obj1 = respData[i];
                const obj2 = respData[i + 1];

                if (obj1 && obj2) {
                    if (obj1.logtype == obj2.logtype) {
                        groupedData.push([obj1, obj2]);
                    } else {
                        groupedData.push([obj1]);
                        i -= 1
                    }
                } else if (obj1) {
                    groupedData.push([obj1]);
                }
            }

            ResponseBody.pagename = "My Log"
            ResponseBody.status = 200
            ResponseBody.message = Config.getResponsestatuscode()["200"]
            ResponseBody.data = respData
            ResponseBody.timerdata = timerData
            ResponseBody.isweekoff = isWeekOff

            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }; next()
        }
    }


    //Insert
    async InsertLogManageData(req, res, next) {
        try {
            const ResponseBody = {}
            const ObjectId = IISMethods.getobjectid()

            const requestIP = req.headers.ipaddress || req.headers["x-forwarded-for"] || req.headers["public-ip"] || req.connection.remoteAddress || req.body["public-ip"]

            const {
                autoclockout,
                propertyid = "",
                propertyname = "",
                latitude: reqlatitude,
                longitude: reqlongitude,
                personid,
                latereason = "",
            } = req.body

            let headerpropertyid = req.headers.propertyid || ""
            let headerpropertyname = req.headers.property || ""

            const clockinPropertyid = headerpropertyid ? headerpropertyid : propertyid

            const propertyPipeline = [{ $match: { _id: ObjectId(clockinPropertyid) } }, { $project: { propertyname: 1, location: 1, systemdate: 1 } }]
            const propertyResp = await MainDB.getmenual("tblpropertymaster", new Propertycommon(), propertyPipeline)

            let property = propertyResp.ResultData[0]
            headerpropertyname = property?.propertyname || headerpropertyname

            if (property) {
                const userid = personid ? personid : req.headers.uid

                let person
                if (req.body.apptype || req.headers.pagename) {
                    const personResp = await MainDB.getPersonData({ apptype: req.headers.apptype, personid: [userid], pagename: req.headers.pagename })
                    person = personResp[0]
                }

                if (person) {

                    let locationallowed = 1

                    /*------------------------------------------ Check Person Area Range ------------------------------------------*/

                    let latitude = 0
                    let longitude = 0
                    let arearange = 0

                    let outofrange = 0

                    latitude = property?.location?.latitude ? property.location.latitude : 0
                    longitude = property?.location?.longitude ? property.location.longitude : 0
                    arearange = property?.location?.arearange ? property.location.arearange : 0

                    const distance = IISMethods.calculateDistance(latitude, longitude, reqlatitude, reqlongitude)

                    outofrange = distance <= arearange ? 1 : 0

                    /*------------------------------------------ Check Person Area Range ------------------------------------------*/

                    if ((outofrange || locationallowed) && parseInt(autoclockout) !== 1) {

                        /*------------------------------------------ Date & Time ------------------------------------------*/
                        const timezone = property?.location?.timezone ? property.location.timezone : FieldConfig.timezone


                        const currentDate = new Date()
                        const currentTimezoneDate = IISMethods.getTimezoneWiseDate({ date: currentDate, timezone })

                        const nightshiftDate = parseInt(req.body.nightshift) ? new Date(new Date(currentDate).setUTCDate(currentDate.getUTCDate() - 1)) : new Date(currentDate)
                        const nightshiftTimezoneDate = IISMethods.getTimezoneWiseDate({ date: nightshiftDate, timezone })


                        /*------------------------------------------ Date & Time ------------------------------------------*/

                        /*------------------------------------------ Table Name ------------------------------------------*/

                        const LogDate = new Date(nightshiftDate).toISOString()

                        let TableName =
                            "DeviceLogs_" +
                            IISMethods.getCurrentMonth(nightshiftTimezoneDate).toString() +
                            "_" +
                            IISMethods.getCurrentYear(nightshiftTimezoneDate).toString()

                        /*------------------------------------------ Table Name ------------------------------------------*/


                        // /*------------------------------------------ Check Duplicate Punch ------------------------------------------*/
                        const previousLogPipeline = [
                            { $addFields: { _sortLogDate: { $cond: [{ $eq: ["$ActualLogDate", null] }, "$LogDate", "$ActualLogDate"] } } },
                            {
                                $match: {
                                    UserId: person._id.toString(),
                                    logtype: 1,
                                    deleted: 0,
                                    ismanual: 0
                                }
                            },
                            { $sort: { _sortLogDate: -1 } },
                            { $limit: 1 }
                        ]
                        const previousLogResp = await MainDB.getmenual(TableName, new _LogManage(), previousLogPipeline)
                        const previousLog = previousLogResp.ResultData[0]
                        const previousLogTime = previousLog?.ActualLogDate || previousLog?.LogDate || ""
                        const convertedPreviousLogTime = IISMethods.getFormatWiseDate(IISMethods.getTimezoneWiseDate({ date: previousLogTime, timezone }), 17)

                        let punchTime = 0

                        if (previousLogTime) {
                            new Date(previousLogTime).setUTCSeconds(0, 0)
                            punchTime = Math.abs(IISMethods.getTimeDifference(previousLogTime, currentDate))
                        }

                        // // /*------------------------------------------ Check Duplicate Punch ------------------------------------------*/
                        // if (!previousLogTime || punchTime > FieldConfig.duplicatepunchtime) {
                            // if (!previousLogTime || punchTime > 0) {

                            /*------------------------------------------ Insert Log ------------------------------------------*/
                            const clockLog = {
                                DeviceLogId: IISMethods.getDateFormats(LogDate, 12),
                                DeviceId: "",
                                UserId: person._id.toString(),
                                propertyname: propertyname,
                                C1: propertyid,
                                C3: req.body.address,
                                LogDate: req.body.LogDate,
                                ActualLogDate: new Date(currentDate),
                                notes: req.body.notes ? req.body.notes : "",
                                latitude: req.body.latitude ? req.body.latitude : "",
                                longitude: req.body.longitude ? req.body.longitude : "",
                                logtype: 1,
                                headerpropertyid: headerpropertyid,
                                headerpropertyname: headerpropertyname,
                                recordinfo: req.body.recordinfo,
                                latereason: latereason,
                                // latereasonicon: latereasonicon
                            }

                            let personupdate = {}

                            if (person.clockindate && !person.clockoutdate) {
                                // Clock Out

                                personupdate.clockoutdate = req.body.LogDate
                                personupdate.clocktype = 1

                                const clockinTimezoneDate = IISMethods.getTimezoneWiseDate({ date: person.clockindate, timezone })

                                TableName =
                                    "DeviceLogs_" +
                                    IISMethods.getCurrentMonth(clockinTimezoneDate).toString() +
                                    "_" +
                                    IISMethods.getCurrentYear(clockinTimezoneDate).toString()

                                const lastlogPipeline = [
                                    { $addFields: { _sortLogDate: { $cond: [{ $eq: ["$ActualLogDate", null] }, "$LogDate", "$ActualLogDate"] } } },
                                    {
                                        $match: {
                                            logtype: 1,
                                            deleted: 0,
                                            UserId: person._id.toString()
                                        }
                                    },
                                    { $sort: { _sortLogDate: -1 } },
                                    { $limit: 1 }
                                ]
                                const lastlogResp = await MainDB.getmenual(TableName, new _LogManage(), lastlogPipeline)
                                let lastlog = lastlogResp.ResultData[0]

                                if (!lastlog && new Date(clockinTimezoneDate).getUTCDate() === 1) {
                                    const clockindate = new Date(new Date(person.clockindate).setUTCDate(person.clockindate.getUTCDate() - 1))
                                    const clockinTimezoneDate = IISMethods.getTimezoneWiseDate({ date: clockindate, timezone })

                                    TableName =
                                        "DeviceLogs_" +
                                        IISMethods.getCurrentMonth(clockinTimezoneDate).toString() +
                                        "_" +
                                        IISMethods.getCurrentYear(clockinTimezoneDate).toString()

                                    const lastlogPipeline = [
                                        { $addFields: { _sortLogDate: { $cond: [{ $eq: ["$ActualLogDate", null] }, "$LogDate", "$ActualLogDate"] } } },
                                        {
                                            $match: {
                                                logtype: 1,
                                                deleted: 0,
                                                UserId: person._id.toString()
                                            }
                                        },
                                        { $sort: { _sortLogDate: -1 } },
                                        { $limit: 1 }
                                    ]
                                    const lastlogResp = await MainDB.getmenual(TableName, new _LogManage(), lastlogPipeline)
                                    lastlog = lastlogResp.ResultData[0]
                                }

                                if (lastlog) {

                                    // if (IISMethods.getFormatWiseDate(clockinTimezoneDate) !== IISMethods.getFormatWiseDate(currentTimezoneDate)) {
                                    //     TableName =
                                    //         "DeviceLogs_" +
                                    //         IISMethods.getCurrentMonth(clockinTimezoneDate).toString() +
                                    //         "_" +
                                    //         IISMethods.getCurrentYear(clockinTimezoneDate).toString()

                                    //     clockLog.LogDate = new Date(lastlog.LogDate)
                                    //     clockLog.ActualLogDate = new Date(currentDate)
                                    // }

                                    if (lastlog.logrequestid && lastlog.logrequestid.toString() !== Config.dummyObjid && lastlog.logrequeststatus === 0) {

                                        clockLog.personid = person._id
                                        clockLog.personname = person.personname
                                        clockLog.requestreason = lastlog.requestreason
                                        const clockinoutrequest = await MainDB.executedata(
                                            "i",
                                            new _ClockinRequest(),
                                            "tblclockinrequest",
                                            clockLog
                                        )

                                        clockLog.logrequestid = clockinoutrequest.data?._id
                                        clockLog.logrequeststatus = clockinoutrequest.data?.status
                                    }
                                }
                            } else {
                                // Clock In
                                req.headers.uid = person._id
                                personupdate.clockindate = req.body.LogDate
                                personupdate.clockoutdate = null
                                personupdate.clocktype = 2
                            }

                            // Actual Log Date
                            const actualLogDate = clockLog.ActualLogDate ? clockLog.ActualLogDate : clockLog.LogDate
                            const actualLogTimezoneDate = IISMethods.getTimezoneWiseDate({ date: actualLogDate, timezone })

                            const logPipeline = [
                                {
                                    $addFields: {
                                        _LogDate: {
                                            $dateToString: {
                                                format: "%Y-%m-%d",
                                                date: "$LogDate",
                                                timezone: timezone
                                            }
                                        },
                                        _sortLogDate: { $cond: [{ $eq: ["$ActualLogDate", null] }, "$LogDate", "$ActualLogDate"] }
                                    }
                                },
                                {
                                    $match: {
                                        _LogDate: IISMethods.getFormatWiseDate(actualLogTimezoneDate),
                                        UserId: person._id.toString(),
                                        logtype: 1,
                                        deleted: 0
                                    }
                                },
                                { $project: { _sortLogDate: 1 } }
                            ]

                            const logResp = await MainDB.getmenual(TableName, new _LogManage(), logPipeline)
                            const clockcount = logResp.ResultData.length

                            const resp = await MainDB.executedata("i", new _LogManage(), TableName, clockLog)

                            if (resp.status == 200) {
                                personupdate._id = userid

                                const personResp = await MainDB.getPersonDataUpdate({ apptype: req.headers.apptype, pagename: req.headers.pagename, personObj: personupdate })

                                ResponseBody.status = resp.status

                                if (personupdate.clocktype == 1) {
                                    ResponseBody.message = Config.getErrmsg()["clockout"]
                                } else {
                                    ResponseBody.message = Config.getErrmsg()["clockin"]
                                }
                            }
                            /*------------------------------------------ Insert Log ------------------------------------------*/

                            ResponseBody.status = resp.status
                            ResponseBody.data = {
                                clocktype: personupdate.clocktype
                            }
                        // } else {
                        //     ResponseBody.status = 401
                        //     ResponseBody.duplicatepunch = 1
                        //     ResponseBody.message = `Your last log was at ${convertedPreviousLogTime}.Please try again after 1 minutes.`
                        // }
                    } else {
                        ResponseBody.status = 400
                        ResponseBody.message = Config.getErrmsg()["youarenotinrange"]
                        ResponseBody.data = {
                            flag: 1,
                            latitude: parseFloat(latitude),
                            longitude: parseFloat(longitude),
                            arearange: parseFloat(arearange)
                        }
                    }
                } else {
                    ResponseBody.status = 404
                    ResponseBody.message = Config.getErrmsg()["personnotfound"]
                }
            } else {
                ResponseBody.status = 404
                ResponseBody.message = Config.getErrmsg()["propertynotfound"]
            }

            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }


    async Listlogregularizerequest(req, res, next) {
        try {
            let ObjectId = IISMethods.getobjectid()
            var ResponseBody = {}
            var pipeline = []
            const { searchtext = "", datefilteronapplieddate = 0, paginationinfo: { pageno = 1, nextpageid = "", pagelimit = 20, filter = {}, sort = {}, projection = {} }, fromdate = null, todate = null } = req.body || {}

            const requiredPage = {
                pageno: pageno,
                nextpageid: nextpageid,
                skip: (pageno - 1) * pagelimit,
                pagelimit: pagelimit
            }
            const sortData = Object.keys(sort).length !== 0 ? sort : { _id: -1 }
            const timezone = req.headers.timezone;

            if (fromdate && todate) {
                if (datefilteronapplieddate) {
                    pipeline.push(
                        {
                            $addFields: {
                                convertedentrydate: { $toDate: "$recordinfo.entrydate" },
                            },
                        },
                        ...IISMethods.getDateFilter({ fromdate, todate, filterkey: "convertedentrydate", timezone })
                    )
                } else {
                    pipeline.push(...IISMethods.getDateFilter({ fromdate: fromdate, todate: todate, filterkey: "LogDate", timezone }))
                }
            }

            pipeline.push(...IISMethods.GetPipelineForFilter(filter))

            // const searchtext = req.body.searchtext || ""
            if (searchtext !== "") {
                pipeline.push(...IISMethods.GetGlobalSearchFilter(new _LogRegularizations(), searchtext))
            }

            const resp = await MainDB.getmenual("tbllogregularization", new _LogRegularizations(), pipeline, requiredPage, sortData, true, "", projection)


            ResponseBody.pagename = "logregularization"
            ResponseBody.formname = "logregularization"
            ResponseBody.fltpagecollection = "logregularization"
            ResponseBody.status = 200
            ResponseBody.message = Config.getResponsestatuscode()["200"]
            ResponseBody.data = resp.ResultData
            ResponseBody.fieldorder = resp.fieldorderdata
            ResponseBody.currentpage = resp.currentpage
            ResponseBody.nextpage = resp.nextpage

            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }



    async Insertlogregularizerequest(req, res, next) {
        try {
            var ResponseBody = {}
            const ObjectId = IISMethods.getobjectid()

            let currentday = new Date().toISOString()
            let applydate = req.body.isnightshift ? new Date(new Date(req.body.logdate).setUTCDate(new Date(req.body.logdate).getUTCDate() + 1)).toISOString() : new Date(req.body.logdate).toISOString()


            if (new Date(currentday) >= new Date(applydate)) {

                req.body.personid = req.headers.uid
                req.body.personname = req.headers.personname

                const resp = await MainDB.executedata("i", new _LogRegularizations(), "tbllogregularization", req.body)

                ResponseBody.status = resp.status
                ResponseBody.message = resp.message

            } else {
                ResponseBody.status = 201
                ResponseBody.message = Config.errmsg['futurelog']
            }

            req.status = 200
            req.ResponseBody = ResponseBody
            next()

        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }


    async Updatelogregularizerequest(req, res, next) {
        try {

            const ObjectId = IISMethods.getobjectid()
            const pipeline = [{ $match: { '_id': ObjectId(req.body._id) } }]
            const record = await MainDB.getmenual("tbllogregularization", new _LogRegularizations(), pipeline)

            //record info
            var RecordInfo = record.ResultData[0].recordinfo
            RecordInfo.updateuid = req.headers.uid
            RecordInfo.updateby = req.headers.personname
            RecordInfo.updatedate = IISMethods.getdatetimeisostr()
            req.body.recordinfo = RecordInfo

            if (record.ResultData.length > 0) {

                if (req.headers.uid != record.ResultData[0]?._id?.toString()) {
                    if (req.body.status == 1) {
                        const ObjectId = IISMethods.getobjectid()

                        const timezone = req.headers.timezone

                        let {
                            logtype,
                            LogDate,
                            personid = "",
                            propertyid = "",
                            latereason = "",
                            latereasonicon = "",
                            propertyname = "",
                        } = req.body

                        const logmanage = {
                            DeviceLogId: new Date().getTime(),
                            DownloadDate: "",
                            DeviceId: "",
                            UserId: personid,
                            propertyname: propertyname,
                            C1: propertyid,
                            C2: "",
                            C3: "",
                            C4: "",
                            C5: "",
                            C6: "",
                            C7: "",
                            LogDate: LogDate,
                            ActualLogDate: "",
                            platform: "",
                            latitude: "",
                            longitude: "",
                            ismanual: 1,
                            deleted: 0,
                            logtype: 1,
                            latereason: latereason,
                            // latereasonicon: latereasonicon,
                            headerpropertyid: req.headers.propertyid,
                            headerpropertyname: req.headers.property,
                            recordinfo: req.body.recordinfo
                        }

                        LogDate = new Date(LogDate)

                        const currentTimezoneDate = IISMethods.getTimezoneWiseDate({ date: LogDate, timezone })

                        let TableName = "DeviceLogs_" + IISMethods.getCurrentMonth(LogDate).toString() + "_" + IISMethods.getCurrentYear(LogDate).toString()
                        // LogDate Filter
                        const startdate = new Date(new Date(LogDate).setUTCHours(0, 0, 0, 0))
                        const enddate = new Date(new Date(new Date(LogDate).setDate(new Date(LogDate).getDate() + 1)).setUTCHours(0, 0, 0, 0))

                        // Default Response
                        let resp = { status: 400, message: Config.getResponsestatuscode()["400"] }

                        let isError = 0

                        if (logtype === 1) {
                            if (!isError) {

                                let person
                                if (req.headers.apptype || req.headers.pagename) {
                                    const personResp = await MainDB.getPersonData({ apptype: req.headers.apptype, personid: [req.body.personid], pagename: req.headers.pagename })
                                    person = personResp[0]
                                }

                                if (person) {
                                    const clockinTimezoneDate = IISMethods.getTimezoneWiseDate({ date: person.clockindate, timezone })

                                    if (req.body.clockintype == 2) {

                                        TableName =
                                            "DeviceLogs_" +
                                            IISMethods.getCurrentMonth(clockinTimezoneDate).toString() +
                                            "_" +
                                            IISMethods.getCurrentYear(clockinTimezoneDate).toString()

                                        const lastlogPipeline = [
                                            {
                                                $match: {
                                                    logtype: 1,
                                                    deleted: 0,
                                                    UserId: person._id.toString()
                                                }
                                            },
                                            { $sort: { _id: -1 } },
                                            { $limit: 1 }
                                        ]
                                        const lastlogResp = await MainDB.getmenual(TableName, new _LogManage(), lastlogPipeline)
                                        let lastlog = lastlogResp.ResultData[0]

                                        if (!lastlog && new Date(clockinTimezoneDate).getUTCDate() === 1) {
                                            const clockindate = new Date(new Date(person.clockindate).setUTCDate(person.clockindate.getUTCDate() - 1))
                                            const clockinTimezoneDate = IISMethods.getTimezoneWiseDate({ date: clockindate, timezone })

                                            TableName =
                                                "DeviceLogs_" +
                                                IISMethods.getCurrentMonth(clockinTimezoneDate).toString() +
                                                "_" +
                                                IISMethods.getCurrentYear(clockinTimezoneDate).toString()

                                            const lastlogPipeline = [
                                                {
                                                    $match: {
                                                        logtype: 1,
                                                        deleted: 0,
                                                        UserId: person._id.toString()
                                                    }
                                                },
                                                { $sort: { _id: -1 } },
                                                { $limit: 1 }
                                            ]
                                            const lastlogResp = await MainDB.getmenual(TableName, new _LogManage(), lastlogPipeline)
                                            lastlog = lastlogResp.ResultData[0]
                                        }

                                        if (lastlog) {
                                            logmanage.nightshift = lastlog.nightshift

                                            const clockinTimezoneDate = IISMethods.getTimezoneWiseDate({ date: lastlog.LogDate, timezone })

                                            if (IISMethods.getFormatWiseDate(clockinTimezoneDate) !== IISMethods.getFormatWiseDate(currentTimezoneDate)) {
                                                TableName =
                                                    "DeviceLogs_" +
                                                    IISMethods.getCurrentMonth(clockinTimezoneDate).toString() +
                                                    "_" +
                                                    IISMethods.getCurrentYear(clockinTimezoneDate).toString()

                                                logmanage.LogDate = new Date(lastlog.LogDate)
                                                logmanage.ActualLogDate = new Date(LogDate)
                                            }
                                        }
                                    }

                                    const logPipeline = [
                                        { $match: { UserId: personid, deleted: 0, logtype: 1 } },
                                        {
                                            $addFields: {
                                                _sortLogDate: {
                                                    $cond: [{ $eq: ["$ActualLogDate", null] }, "$LogDate", "$ActualLogDate"]
                                                }
                                            }
                                        },
                                        { $sort: { _sortLogDate: -1 } }
                                    ]
                                    logPipeline.push(...IISMethods.getDateFilter({ fromdate: startdate, todate: enddate, filterkey: "LogDate", timezone: timezone }))

                                    let logResp = await MainDB.getmenual(TableName, new _LogManage(), logPipeline)
                                    let logData = logResp.ResultData

                                    if (logData.length % 2 === 1 && isnightshift) {
                                        logmanage.LogDate = logData[logData.length - 1].LogDate
                                    }

                                    resp = await MainDB.executedata("i", new _LogManage(), TableName, logmanage)

                                    const clockinlogPipeline = [
                                        { $match: { UserId: personid, deleted: 0, logtype: 1 } },
                                        {
                                            $addFields: {
                                                _sortLogDate: {
                                                    $cond: [{ $eq: ["$ActualLogDate", null] }, "$LogDate", "$ActualLogDate"]
                                                }
                                            }
                                        },
                                        { $sort: { _sortLogDate: -1 } }
                                    ]
                                    logResp = await MainDB.getmenual(TableName, new _LogManage(), clockinlogPipeline)
                                    logData = logResp.ResultData

                                    let personObj = {}

                                    if (logData.length) {
                                        if (logData.length % 2 === 1) {
                                            personObj = {
                                                _id: personid,
                                                lastclockinoutpropertyid: logData[0].C1,
                                                clockindate: logData[0].ActualLogDate ? logData[0].ActualLogDate : logData[0].LogDate,
                                                clockoutdate: null,
                                                nightshift: isnightshift ? 1 : 0
                                            }

                                            if (personObj.clockindate < person?.clockindate) {
                                                personObj.clockindate = person?.clockindate
                                            }
                                        } else {
                                            personObj = {
                                                _id: personid,
                                                lastclockinoutpropertyid: logData[1].C1,
                                                clockindate: logData[1].ActualLogDate ? logData[1].ActualLogDate : logData[1].LogDate,
                                                clockoutdate: logData[0].ActualLogDate ? logData[0].ActualLogDate : logData[0].LogDate,
                                                nightshift: isnightshift ? 1 : 0
                                            }

                                            if (personObj.clockoutdate < person?.clockoutdate) {
                                                personObj.clockoutdate = person?.clockoutdate
                                            }
                                        }
                                    } else {
                                        personObj = {
                                            _id: personid,
                                            clockindate: null,
                                            clockoutdate: null
                                        }
                                    }

                                    await MainDB.getPersonDataUpdate({ apptype: req.headers.apptype, pagename: req.headers.pagename, personObj: personObj })
                                }
                            } else {
                                resp = { status: 400, message: Config.getErrmsg()["nightshiftlogerror"] }
                            }
                        }
                    }
                } else {
                    ResponseBody.status = 400
                    ResponseBody.message = req.body.status == 1 ? Config.getErrmsg()["selfapprove"] : Config.getErrmsg()["selfreject"]
                }
            } else {
                ResponseBody.status = 404
                ResponseBody.message = Config.getErrmsg()["notexist"]
            }

            const resp = await MainDB.executedata('u', new _LogRegularizations(), "tbllogregularization", req.body)

            var ResponseBody = {}
            ResponseBody.status = resp.status
            ResponseBody.data = resp.data
            ResponseBody.message = resp.message

            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }


    //log calender
    async GetLogCalender(req, res, next) {
        try {
            const ResponseBody = {}
            const ObjectId = IISMethods.getobjectid()

            const paginationInfo = req.body.paginationinfo

            const { personid, date, propertyid } = paginationInfo.filter

            const timezone = req.headers.timezone

            const startDate = IISMethods.getMonthStartAndEndDate(date).startdate
            const endDate = IISMethods.getMonthStartAndEndDate(date).enddate

            //Get person
            let person
            if (req.headers.apptype || req.headers.pagename) {
                const personResp = await MainDB.getPersonData({ apptype: req.headers.apptype, personid: [req.headers.uid], pagename: req.headers.pagename })
                person = personResp[0]
            }

            if (person) {
                const personResult = person

                //Log date filter
                // const logDateFilter = IISMethods.getDateFilter({ fromdate: startDate, todate: endDate, filterkey: "LogDate", timezone: req.headers.timezone, isequal: true })
                const logDateFilter = IISMethods.getDateFilter({ fromdate: startDate, todate: endDate, filterkey: "LogDate", timezone: req.headers.timezone })

                //get Log data
                const logPipeline = [
                    ...logDateFilter,
                    { $match: { UserId: personid } },
                    {
                        $addFields: {
                            _sortLogDate: {
                                $cond: [{ $eq: ["$ActualLogDate", null] }, "$LogDate", "$ActualLogDate"]
                            }
                        }
                    },
                    { $sort: { _sortLogDate: 1 } },
                    {
                        $group: {
                            _id: { $dateToString: { format: "%Y-%m-%d", date: "$LogDate", timezone: timezone } },
                            logData: {
                                $push: {
                                    _id: "$_id",
                                    LogDate: "$LogDate",
                                    logtype: "$logtype",
                                    ActualLogDate: "$ActualLogDate",
                                    entrydate: "$recordinfo.entrydate",
                                    ismanual: "$ismanual"
                                }
                            }
                        }
                    }
                ] // Get Month wise logs pipeline
                const formatedStartDate = IISMethods.getFormatedDate(startDate)
                const fromTableName = "DeviceLogs_" + formatedStartDate.mm + "_" + formatedStartDate.year
                const logResp = await MainDB.getmenual(fromTableName, new _LogManage(), logPipeline)
                const logData = logResp.ResultData

                // Get Month Dates
                const daysofmonth = IISMethods.getDatesInRange(startDate, endDate)

                const logCalenderData = []

                //get visitor clockin/out data
                const InOutPipeline = [
                    ...logDateFilter,
                    { $match: { gatekeeperid: ObjectId(personid) } },
                    {
                        $addFields: {
                            _sortLogDate: {
                                $cond: [{ $eq: ["$ActualLogDate", null] }, "$LogDate", "$ActualLogDate"]
                            }
                        }
                    },
                    { $sort: { _sortLogDate: 1 } },
                    {
                        $group: {
                            _id: { $dateToString: { format: "%Y-%m-%d", date: "$LogDate", timezone: timezone } },
                            visitorin: {
                                $sum: {
                                    $cond: [{ $eq: ["$clockintype", 1] }, 1, 0]
                                }
                            },
                            visitorout: {
                                $sum: {
                                    $cond: [{ $eq: ["$clockintype", 2] }, 1, 0]
                                }
                            }
                        }
                    }
                ] // Get Month wise logs pipeline


                const visitorTableName = "DeviceLogsvisitor_" + formatedStartDate.mm + "_" + formatedStartDate.year
                const visitorlogResp = await MainDB.getmenual(visitorTableName, new _LogManage(), InOutPipeline)
                const visitorlogData = visitorlogResp.ResultData
                console.log("🚀 ~ GetLogCalender ~ visitorlogData:", JSON.stringify(InOutPipeline))


                for (let day of daysofmonth) {

                    //day wise run time data obj
                    const dayWiseDataObj = {
                        date: new Date(day.date),
                        logdata: [],
                        visitorin: Number(0),
                        visitorout: Number(0),
                        clockinouttime: Number(0),
                    }

                    // filter day wise log
                    const dayWiseLogData = logData.find((logdata) => logdata._id == IISMethods.getFormatWiseDate(new Date(day.date)))

                    //visitor log
                    const visitordayWiseLogData = visitorlogData.find((logdata) => logdata._id == IISMethods.getFormatWiseDate(new Date(day.date)))

                    let clockInOutData = []
                    let visitorInOutData = []

                    if (dayWiseLogData?.logData?.length) {
                        //Filter logs
                        clockInOutData = dayWiseLogData.logData.filter((data) => data.logtype == 1)
                    }

                    //************* Start clock in/out log *************
                    let clockintime = 0
                    let clockDifftemp = 0

                    let clocklogdata = [];
                    let deletedLog = clockInOutData.filter((log) => log.deleted == 1);
                    clockInOutData = clockInOutData.filter((log) => log.deleted != 1);

                    // for (let i = 0; i < clockInOutData.length; i++) {
                    //     // if (clockInOutData[i].deleted != 1) {
                    //     //calculation & is in out log for not deleted logs
                    //     //log date
                    //     clockInOutData[i].letLogDate =
                    //         clockInOutData[i]?.ActualLogDate && clockInOutData[i]?.ActualLogDate !== null
                    //             ? clockInOutData[i]?.ActualLogDate
                    //             : clockInOutData[i]?.LogDate

                    //     //is in or out log
                    //     if (i % 2 === 0) {
                    //         clockInOutData[i].inoutlog = 0 //inoutlog -> in logs > 0, out logs > 1

                    //         if (clockInOutData[i + 1] != undefined) {
                    //             //calculate total time for clock in out logs
                    //             const clockindate = clockInOutData[i]?.letLogDate
                    //             const clockoutdate =
                    //                 clockInOutData[i + 1]?.ActualLogDate && clockInOutData[i + 1].ActualLogDate !== null
                    //                     ? clockInOutData[i + 1].ActualLogDate
                    //                     : clockInOutData[i + 1]?.LogDate && clockInOutData[i + 1]?.LogDate !== null
                    //                         ? clockInOutData[i + 1].LogDate
                    //                         : new Date()

                    //             const diff = IISMethods.getTimeDifference(clockindate, clockoutdate)

                    //             const clockDiff = diff ? diff / 1000 : 0
                    //         }
                    //     } else {
                    //         clockInOutData[i].inoutlog = 1
                    //         if (
                    //             !clockInOutData[i]?.logrequestid ||
                    //             clockInOutData[i]?.logrequestid == Config.dummyObjid ||
                    //             (clockInOutData[i]?.logrequestid != Config.dummyObjid && clockInOutData[i]?.logrequeststatus == 1)
                    //         ) {
                    //             clockInOutData[i].rejectedLog = 1
                    //         }
                    //     }
                    //     clocklogdata.push(clockInOutData[i])
                    // }

                    for (let i = 0; i < clockInOutData.length; i++) {
                        // Determine the log date
                        clockInOutData[i].letLogDate =
                            clockInOutData[i]?.ActualLogDate && clockInOutData[i]?.ActualLogDate !== null
                                ? clockInOutData[i]?.ActualLogDate
                                : clockInOutData[i]?.LogDate;
                    
                        if (i % 2 === 0) {
                            // Mark as "in" log
                            clockInOutData[i].inoutlog = 0;
                    
                            if (clockInOutData[i + 1] != undefined) {
                                // Calculate time between "in" and the next "out" log
                                const clockindate = clockInOutData[i]?.LogDate;
                                const clockoutdate =
                                    clockInOutData[i + 1]?.ActualLogDate && clockInOutData[i + 1]?.ActualLogDate !== null
                                        ? clockInOutData[i + 1]?.LogDate
                                        : clockInOutData[i + 1]?.LogDate && clockInOutData[i + 1]?.LogDate !== null
                                            ? clockInOutData[i + 1].LogDate
                                            : new Date();
                    
                                const diff = IISMethods.getTimeDifference(clockindate, clockoutdate);
                                const clockDiff = diff ? diff / 1000 : 0;
                    
                                let clockot = 0;
                                let clocktime = clockDiff - clockot;
                                clockintime += clocktime;
                                clockDifftemp = clockintime ? clockintime / 60 : 0;
                    
                                // Mark rejected logs if conditions are met
                                if (
                                    (clockInOutData[i]?.logrequestid != Config.dummyObjid && clockInOutData[i]?.logrequeststatus == 1) ||
                                    !clockInOutData[i]?.logrequestid ||
                                    clockInOutData[i]?.logrequestid == Config.dummyObjid
                                ) {
                                    clockInOutData[i].rejectedLog = 1;
                                }
                            } else {
                                // Handle odd log without a matching "out" log (end of the day)
                                const clockindate = clockInOutData[i]?.LogDate;
                                const endOfDay = new Date(clockindate);
                                endOfDay.setHours(23, 59, 59, 999); // Set time to end of the day
                    
                                const diff = IISMethods.getTimeDifference(clockindate, endOfDay);
                                const clockDiff = diff ? diff / 1000 : 0;
                    
                                let clockot = 0;
                                let clocktime = clockDiff - clockot;
                                clockintime += clocktime;
                                clockDifftemp = clockintime ? clockintime / 60 : 0;
                            }
                        } else {
                            // Mark as "out" log
                            clockInOutData[i].inoutlog = 1;
                    
                            // Mark rejected logs if conditions are met
                            if (
                                !clockInOutData[i]?.logrequestid ||
                                clockInOutData[i]?.logrequestid == Config.dummyObjid ||
                                (clockInOutData[i]?.logrequestid != Config.dummyObjid && clockInOutData[i]?.logrequeststatus == 1)
                            ) {
                                clockInOutData[i].rejectedLog = 1;
                            }
                        }
                    
                        // Push the processed log to the result array
                        clocklogdata.push(clockInOutData[i]);
                    }
                    

                    dayWiseDataObj.logdata.push(...clocklogdata.concat(deletedLog))

                    dayWiseDataObj.clockinouttime = clockintime

                    if (visitordayWiseLogData) {
                        //Filter logs
                        dayWiseDataObj.visitorin = visitordayWiseLogData.visitorin
                        dayWiseDataObj.visitorout = visitordayWiseLogData.visitorout
                    }
                    logCalenderData.push(dayWiseDataObj)
                }
                //************* End clock in/out log *************

                ResponseBody.data = logCalenderData
                ResponseBody.status = 200
                ResponseBody.message = Config.getResponsestatuscode()["200"]

            }

            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

    //log calender
    async GetVisitorLogCalender(req, res, next) {
        try {
            const ResponseBody = {}
            const ObjectId = IISMethods.getobjectid()

            const paginationInfo = req.body.paginationinfo

            const { personid, date, propertyid } = paginationInfo.filter

            const timezone = req.headers.timezone

            //Get person
            let person
            if (req.body.apptype || req.headers.pagename) {
                const personResp = await MainDB.getPersonData({ apptype: req.headers.apptype, personid: [req.headers.uid], pagename: req.headers.pagename })
                person = personResp[0]
            }

            if (person) {
                const visitorPipeline = [
                    {
                        $match: {
                            gatekeeperid: new ObjectId(personid), // Properly cast to ObjectId
                        },
                    },
                ]

                // Add the date filter to the pipeline
                visitorPipeline.push( ...IISMethods.getSameDateTwoFilter({ date: date, filterkey: "visitorin", filterkey2: "visitorout", timezone: req.headers.timezone }))

                const visitorlogResp = await MainDB.getmenual("tblvisitormaster", new _Visitor(), visitorPipeline)

                ResponseBody.data = visitorlogResp?.ResultData
                ResponseBody.status = 200
                ResponseBody.message = Config.getResponsestatuscode()["200"]
            }

            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

    //log calender
    async GetPatrollingLogCalender(req, res, next) {
        try {
            const ResponseBody = {}
            const ObjectId = IISMethods.getobjectid()

            const paginationInfo = req.body.paginationinfo

            const { personid, date, propertyid } = paginationInfo.filter

            //Get person
            let person
            if (req.body.apptype || req.headers.pagename) {
                const personResp = await MainDB.getPersonData({ apptype: req.headers.apptype, personid: [req.headers.uid], pagename: req.headers.pagename })
                person = personResp[0]
            }

            if (person) {
                const patrollingpipeline = [
                    {
                        $match: {
                            personid: new ObjectId(personid),
                            propertyid: new ObjectId(req.headers.propertyid),
                        },
                    },
                    {
                        "$addFields": {
                            "_createdate": {
                                "$dateToString": {
                                    "format": "%Y-%m-%d",
                                    "date": "$createdate",
                                }
                            }
                        }
                    },
                    {
                        "$match": {
                            "_createdate": IISMethods.getDateFormats(date)
                        }
                    }
                ]

                // Add the date filter to the pipeline

                const patrollingResp = await MainDB.getmenual("tblpatrollingmaster", new _Patrolling(), patrollingpipeline)

                ResponseBody.data = patrollingResp?.ResultData
                ResponseBody.status = 200
                ResponseBody.message = Config.getResponsestatuscode()["200"]
            }

            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }



    //log calender
    async GetPropertyLogCalender(req, res, next) {
        try {
            const ResponseBody = {}
            const ObjectId = IISMethods.getobjectid()

            const paginationInfo = req.body.paginationinfo

            const { personid, date, propertyid } = paginationInfo.filter

            ResponseBody.status = 400
            ResponseBody.message = Config.getResponsestatuscode()["400"]

            const timezone = req.headers.timezone

            const startDate = IISMethods.getMonthStartAndEndDate(date).startdate
            const endDate = IISMethods.getMonthStartAndEndDate(date).enddate

            //Get person
            let person
            if (req.body.apptype || req.headers.pagename) {
                const personResp = await MainDB.getPersonData({ apptype: req.headers.apptype, personid: [req.headers.uid], pagename: req.headers.pagename })
                person = personResp[0]
            }

            if (person) {
                const personResult = person

                //Log date filter
                //const logDateFilter = IISMethods.getDateFilter({ fromdate: startDate, todate: endDate, filterkey: "LogDate", timezone: req.headers.timezone, isequal: true })
                const logDateFilter = IISMethods.getDateFilter({ fromdate: startDate, todate: endDate, filterkey: "LogDate", timezone: req.headers.timezone })

                // Get Log data
                const logPipeline = [
                    ...logDateFilter,
                    { $match: { headerpropertyid: req.headers.propertyid } },
                    {
                        $addFields: {
                            _sortLogDate: {
                                $cond: [{ $eq: ["$ActualLogDate", null] }, "$LogDate", "$ActualLogDate"]
                            }
                        }
                    },
                    { $sort: { _sortLogDate: 1 } },
                    {
                        // First group by date and userId
                        $group: {
                            _id: {
                                date: { $dateToString: { format: "%Y-%m-%d", date: "$LogDate", timezone: "Asia/Kolkata" } },
                                userid: "$UserId"
                            },
                            personid: { $first: "$UserId" },
                            person: { $first: "$recordinfo.entryby" },
                            logData: {
                                $push: {
                                    _id: "$_id",
                                    LogDate: "$LogDate",
                                    gatekeeperid: "$UserId",
                                    logtype: "$logtype",
                                    ActualLogDate: "$ActualLogDate",
                                    entrydate: "$recordinfo.entrydate",
                                    UserId: "$UserId",
                                    entryby: "$recordinfo.entryby",
                                }
                            }
                        }
                    },
                    {
                        // Group by date to create the desired structure
                        $group: {
                            _id: "$_id.date",
                            gatekeeper: {
                                $push: {
                                    name: "$person",
                                    logdata: "$logData",
                                    clockinouttime: 0
                                }
                            }
                        }
                    },
                    {
                        $project: {
                            _id: 0,
                            date: "$_id",
                            gatekeeper: 1
                        }
                    }
                ];


                const formatedStartDate = IISMethods.getFormatedDate(startDate)
                const fromTableName = "DeviceLogs_" + formatedStartDate.mm + "_" + formatedStartDate.year
                const logResp = await MainDB.getmenual(fromTableName, new _LogManage(), logPipeline)
                const logData = logResp.ResultData

                // Get Month Dates
                const daysofmonth = IISMethods.getDatesInRange(startDate, endDate)

                const logCalenderData = []

                //get visitor clockin/out data
                const InOutPipeline = [
                    ...logDateFilter,
                    { $match: { propertyid: ObjectId(req.headers.propertyid) } },
                    {
                        $addFields: {
                            _sortLogDate: {
                                $cond: [{ $eq: ["$ActualLogDate", null] }, "$LogDate", "$ActualLogDate"]
                            }
                        }
                    },
                    { $sort: { _sortLogDate: 1 } },
                    {
                        $group: {
                            _id: { $dateToString: { format: "%Y-%m-%d", date: "$LogDate", timezone: timezone } },
                            visitorin: {
                                $sum: {
                                    $cond: [{ $eq: ["$clockintype", 1] }, 1, 0]
                                }
                            },
                            visitorout: {
                                $sum: {
                                    $cond: [{ $eq: ["$clockintype", 2] }, 1, 0]
                                }
                            }
                        }
                    }
                ] // Get Month wise logs pipeline


                const visitorTableName = "DeviceLogsvisitor_" + formatedStartDate.mm + "_" + formatedStartDate.year
                const visitorlogResp = await MainDB.getmenual(visitorTableName, new _LogManage(), InOutPipeline)

                const visitorlogData = visitorlogResp.ResultData
                console.log("🚀 ~ GetPropertyLogCalender ~ visitorlogData:", JSON.stringify(visitorlogData))

                for (let day of daysofmonth) {

                    //day wise run time data obj
                    const dayWiseDataObj = {
                        date: new Date(day.date),
                        gatekeeper: [],
                        visitorin: Number(0),
                        visitorout: Number(0),
                        clockinouttime: Number(0),
                    }

                    // filter day wise log
                    const dayWiseLogData = logData.find((logdata) => logdata.date == IISMethods.getFormatWiseDate(new Date(day.date)))
                    const visitordayWiseLogData = visitorlogData.find((logdata) => logdata._id == IISMethods.getFormatWiseDate(new Date(day.date))) //visitor log

                    let clockInOutData = []


                    if (dayWiseLogData?.logData?.length) {
                        //Filter logs
                        clockInOutData = dayWiseLogData.logData.filter((data) => data.logtype == 1)
                    }

                    //************* Start clock in/out log *************
                    clockInOutData = clockInOutData.filter((log) => log.deleted != 1)
                    let deletedLog = clockInOutData.filter((log) => log.deleted == 1)


                    if (dayWiseLogData && dayWiseLogData.gatekeeper.length > 0) {
                        for (let gatekeeper of dayWiseLogData.gatekeeper) {
                            let clockInOutData = gatekeeper.logdata.filter((data) => data.logtype === 1 && data.deleted !== 1)

                            let clockintime = 0
                            let clockDifftemp = 0
                            let clocklogdata = []

                            for (let i = 0; i < clockInOutData.length; i++) {
                                clockInOutData[i].letLogDate = clockInOutData[i].ActualLogDate ?? clockInOutData[i].LogDate

                                if (i % 2 === 0) {
                                    clockInOutData[i].inoutlog = 0; // 'in' log

                                    
                                    if (clockInOutData[i + 1]) {
                                        const clockindate = clockInOutData[i].LogDate;
                                        const clockoutdate =
                                            clockInOutData[i + 1].LogDate ??
                                            clockInOutData[i + 1].LogDate ??
                                            new Date();

                                        const diff = IISMethods.getTimeDifference(clockindate, clockoutdate);
                                        const clockDiff = diff ? diff / 1000 : 0;

                                        let clocktime = clockDiff

                                        clockintime += clocktime;
                                        clockDifftemp = clockintime / 60;

                                        // Handle rejected logs based on conditions
                                        if (
                                            (clockInOutData[i].logrequestid !== Config.dummyObjid &&
                                                clockInOutData[i].logrequeststatus === 1) ||
                                            !clockInOutData[i].logrequestid ||
                                            clockInOutData[i].logrequestid === Config.dummyObjid
                                        ) {
                                            clockInOutData[i].rejectedLog = 1;
                                        }
                                    }
                                } else {
                                    clockInOutData[i].inoutlog = 1; // 'out' log

                                    if (
                                        !clockInOutData[i].logrequestid ||
                                        clockInOutData[i].logrequestid === Config.dummyObjid ||
                                        (clockInOutData[i].logrequestid !== Config.dummyObjid &&
                                            clockInOutData[i].logrequeststatus === 1)
                                    ) {
                                        clockInOutData[i].rejectedLog = 1;
                                    }
                                }

                                clocklogdata.push(clockInOutData[i]);
                            }

                            // Append processed data to gatekeeper in the day-wise object
                            dayWiseDataObj.gatekeeper.push({
                                name: gatekeeper.name,
                                logdata: clocklogdata,
                                clockinouttime: clockintime
                            });
                        }
                    }

                    if (dayWiseLogData?.gatekeeper.length) {
                        dayWiseDataObj.gatekeeper.push(...dayWiseLogData?.gatekeeper)
                    }

                    if (visitordayWiseLogData) {
                        //Filter logs
                        dayWiseDataObj.visitorin = visitordayWiseLogData.visitorin
                        dayWiseDataObj.visitorout = visitordayWiseLogData.visitorout
                    }
                    logCalenderData.push(dayWiseDataObj)
                }
                //************* End clock in/out log *************

                ResponseBody.data = logCalenderData
                ResponseBody.status = 200
                ResponseBody.message = Config.getResponsestatuscode()["200"]

            }

            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

    //log calender
    async GetPropertyVisitorLogCalender(req, res, next) {
        try {
            const ResponseBody = {}
            const ObjectId = IISMethods.getobjectid()

            const paginationInfo = req.body.paginationinfo

            const { date, propertyid } = paginationInfo.filter
            ResponseBody.status = 400
            ResponseBody.message = Config.getResponsestatuscode()["400"]

            //Get person
            let person
            if (req.body.apptype || req.headers.pagename) {
                const personResp = await MainDB.getPersonData({ apptype: req.headers.apptype, personid: [req.headers.uid], pagename: req.headers.pagename })
                person = personResp[0]
            }

            if (person) {
                const personResult = person

                //get visitor clockin/out data
                // const InOutPipeline = [
                //     {
                //         $addFields: {
                //             _LogDate: {
                //                 $dateToString: {
                //                     format: "%Y-%m-%d",
                //                     date: "$LogDate",
                //                     timezone: timezone
                //                 }
                //             }
                //         }
                //     },
                //     { $match: { _LogDate: IISMethods.getFormatWiseDate(new Date(date)), propertyid: ObjectId(req.headers.propertyid) } },
                //     {
                //         $addFields: {
                //             _sortLogDate: {
                //                 $cond: [{ $eq: ["$ActualLogDate", null] }, "$LogDate", "$ActualLogDate"]
                //             }
                //         }
                //     },
                //     { $sort: { _sortLogDate: 1 } },
                //     {
                //         $group: {
                //             _id: {
                //                 visitorid: "$visitorid",
                //                 date: {
                //                     $dateToString: {
                //                         format: "%Y-%m-%d",
                //                         date: "$LogDate",
                //                         timezone: "Asia/Kolkata"
                //                     }
                //                 }
                //             },
                //             visitorIn: {
                //                 $push: {
                //                     $cond: [
                //                         { $eq: ["$clockintype", 1] },
                //                         {
                //                             _id: "$_id",
                //                             LogDate: "$LogDate",
                //                             logtype: "$logtype",
                //                             visitorid: "$visitorid",
                //                             visitor: "$visitor",
                //                             profilepic: "$documents"
                //                         },
                //                         null
                //                     ]
                //                 }
                //             },
                //             visitorOut: {
                //                 $push: {
                //                     $cond: [
                //                         { $eq: ["$clockintype", 2] },
                //                         {
                //                             _id: "$_id",
                //                             LogDate: "$LogDate",
                //                             logtype: "$logtype",
                //                             visitorid: "$visitorid",
                //                             visitor: "$visitor",
                //                             profilepic: "$documents"
                //                         },
                //                         null
                //                     ]
                //                 }
                //             }
                //         }
                //     },
                //     {
                //         $addFields: {
                //             visitorIn: {
                //                 $filter: {
                //                     input: "$visitorIn",
                //                     cond: { $ne: ["$$this", null] }
                //                 }
                //             },
                //             visitorOut: {
                //                 $filter: {
                //                     input: "$visitorOut",
                //                     cond: { $ne: ["$$this", null] }
                //                 }
                //             }
                //         }
                //     },
                //     {
                //         $project: {
                //             _id: 0,
                //             visitorid: "$_id.visitorid",
                //             visitor: { $arrayElemAt: ["$visitorIn.visitor", 0] },
                //             profilepic: {
                //                 $ifNull: [{ $arrayElemAt: ["$visitorIn.profilepic", 0] }, null]
                //             },
                //             clockintime: {
                //                 $ifNull: [{ $arrayElemAt: ["$visitorIn.LogDate", 0] }, null]
                //             },
                //             clockouttime: {
                //                 $ifNull: [{ $arrayElemAt: ["$visitorOut.LogDate", 0] }, null]
                //             }
                //         }
                //     }
                // ]

                const visitorPipeline = []

                // Add the date filter to the pipeline
                visitorPipeline.push( ...IISMethods.getSameDateTwoFilter({ date: date, filterkey: "visitorin", filterkey2: "visitorout", timezone: req.headers.timezone }))

                // // Get Month wise logs pipeline
                // const formatedStartDate = IISMethods.getFormatedDate(startDate)

                // const visitorTableName = "DeviceLogsvisitor_" + formatedStartDate.mm + "_" + formatedStartDate.year
                const visitorlogResp = await MainDB.getmenual("tblvisitormaster", new _Visitor(), visitorPipeline)

                ResponseBody.data = visitorlogResp?.ResultData
                ResponseBody.status = 200
                ResponseBody.message = Config.getResponsestatuscode()["200"]
            }

            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

}