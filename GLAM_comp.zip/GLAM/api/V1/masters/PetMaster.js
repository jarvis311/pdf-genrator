import { IISMethods,MainDB, Config } from "../../../config/Init.js"
import _Pet from "../../../model/Customer/Pet.js"
import _Approve from '../../../model/Approve.js'
import _Customer from '../../../model/Onboarding/Customer.js'

const TableName = "tblpetmaster"
const PageName = "pets"
const FormName = "pets"
const FltPageCollection = "petsmaster"

export default class PetMaster {
	// List petmaster
	async ListPetMaster(req, res, next) {
		try {
            var ResponseBody = {}
            var PaginationInfo =  req.body.paginationinfo

            const requiredPage = {pageno : PaginationInfo.pageno, skip : (PaginationInfo.pageno - 1) * PaginationInfo.pagelimit, pagelimit : PaginationInfo.pagelimit}
            var pipeline = []
            var sort = (Object.keys(PaginationInfo.sort).length !== 0 ? PaginationInfo.sort : {'_id' :-1})
            let projection = PaginationInfo.projection ? PaginationInfo.projection : {}
            let fieldorder = req.body.paginationinfo.isfieldorder ? req.body.paginationinfo.isfieldorder : 0

            pipeline = IISMethods.GetPipelineForFilter(PaginationInfo.filter)

            const searchtext = req.body.searchtext || ""
            if (searchtext !== "") {
                pipeline.push(...IISMethods.GetGlobalSearchFilter(new _Pet(), searchtext))
            }

            if(req.body.isgatekeeper == 1){
                pipeline.push(
                    {
                        $group: {
                            _id: "$customerid",
                            customer: { $first: "$customer" },
                            documents: { $push: "$$ROOT" }
                        }
                    }
                ) 
            }
                        
            const resp = await MainDB.getmenual(TableName, new _Pet(), pipeline, requiredPage, sort, fieldorder,"", projection)
              
            ResponseBody.pagename = PageName
            ResponseBody.formname = FormName
			ResponseBody.fltpagecollection = FltPageCollection
            ResponseBody.status = 200
            ResponseBody.message = Config.getResponsestatuscode()['200']
            ResponseBody.data = resp.ResultData
            ResponseBody.currentpage = resp.currentpage
            ResponseBody.nextpage = resp.nextpage   
            ResponseBody.totaldocs = resp.totaldocs;
            ResponseBody.fieldorder = resp.fieldorderdata 
            ResponseBody.formfieldorderdata = resp.formfieldorderdata            

            req.ResponseBody = ResponseBody
            next()
		} catch (err) {
			req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
			next()
		}
	}

	// Insert pet
	async InsertPetMaster(req, res, next) {
		try {
			const ResponseBody = {}

            req.body.propertyid = req.headers.propertyid
            req.body.property = req.headers.property
            
            const pipelinedata = { _id: req.body.customerid }
            const customer = await MainDB.FindOne("tblcustomer", new _Customer(), pipelinedata)

            req.body.contact_countrycode = customer.contact_countrycode 
            req.body.contact = customer.contact
            req.body.alternatecontact = customer.alternatecontact
            req.body.alternatecontact_countrycode = customer.alternatecontact_countrycode
            req.body.ownedproperties = customer.ownedproperties

			const resp = await MainDB.executedata("i", new _Pet(), TableName, req.body)

            if (resp.status == 200) {

                const pets = [{
                    petid :resp.data._id,
                    petname: req.body.petname,
                    pettype: req.body.pettype,
                    breed: req.body.breed,
                    identificationfeature: req.body.identificationfeature,
                    dateofbirth:req.body.dateofbirth
                }]

                const updatePipeline = [{ _id: req.body.customerid }, { $push: { pet: pets } }]
                await MainDB.Update("tblcustomer", new _Customer(), updatePipeline)
            }

			ResponseBody.status = resp.status
			ResponseBody.message = resp.message
            ResponseBody.data = resp.data

			req.ResponseBody = ResponseBody
			next()
		} catch (err) {
			req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
			next()
		}
	}



    // Insert guest
	async ApprovePetMaster(req, res, next) {
		try {
			const ResponseBody = {}
                        
            const preapproveGuest = []
            const {startdate, enddate, starttime, endtime, weekdays} = req.body

            const daysMapping = {
                'Sun': 0,
                'Mon': 1,
                'Tue': 2,
                'Wed': 3,
                'Thu': 4,
                'Fri': 5,
                'Sat': 6
            };
        
            // Convert days of the week to numbers for easy comparison
            const days = weekdays.map(day => daysMapping[day]);
        
            const startDateObj = new Date(startdate);
            const endDateObj = new Date(enddate);
            const finalArray = [];
        
            // Parse start and end time for hour and minute extraction
            const { hours: startHour, minutes: startMinute } = IISMethods.parseTime(starttime);
            const { hours: endHour, minutes: endMinute } = IISMethods.parseTime(endtime);
        
            // Iterate through each date from startdate to enddate
            for (let currentDate = new Date(startDateObj); currentDate <= endDateObj; currentDate.setDate(currentDate.getDate() + 1)) {
                if (days.includes(currentDate.getDay())) {
                    // Set the start time for the current date
                    const formattedStartDate = new Date(currentDate);
                    formattedStartDate.setHours(startHour, startMinute, 0, 0);
        
                    // Set the end time for the current date
                    const formattedEndDate = new Date(currentDate);
                    formattedEndDate.setHours(endHour, endMinute, 59, 999);
        
                    // Push the formatted date object to the final array
                    finalArray.push({
                        startdate: formattedStartDate.toISOString(),
                        enddate: formattedEndDate.toISOString()
                    });
                }
            }

                const data = {
                    _id:req.body._id,
                    propertyid: req.headers.propertyid,
                    property: req.headers.property,
                    customerid: req.headers.uid,
                    customer: req.headers.personname,
                    name:req.body.petname,
                    pettypeid:req.body.pettypeid,
                    pettype:req.body.pettype,
                    breedid:req.body.breedid,
                    breed:req.body.breed,
                    picture:req.body.petpic,
                    dateofbirth:req.body.dateofbirth,
                    identificationfeature:req.body.identificationfeature,
                    allowtime: finalArray,
                    startdate: req.body.startdate,
                    enddate: req.body.enddate,
                    floor: req.body.floor,
                    floorid: req.body.floorid,
                    unit: req.body.unit,
                    unitid: req.body.unitid,
                    wing: req.body.wing,
                    wingid: req.body.wingid,
                    iscollectfromgate: req.body.iscollectfromgate,
                    weeks:weekdays,
                    starttime:starttime,
                    endtime:endtime,
                    approvetype:3,
                    otp: IISMethods.generatecode(6)
                }
                console.log("🚀 ~ PetMaster ~ ApprovePetMaster ~ approveData:", data)
            // const resp = await MainDB.executedata('u', new _Pet(), TableName, data)

            // if (resp.status == 200) {
               const d=  await MainDB.InsertMany("tblapprovemaster", new _Approve(), data)
               console.log("🚀 ~ PetMaster ~ ApprovePetMaster ~ d:", d)
            // }

			ResponseBody.status = 200
			ResponseBody.message = "OK"

			req.ResponseBody = ResponseBody
			next()
		} catch (err) {
			req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
			next()
		}
	}


    async manageParcel(req, res, next) {
        try {

            const ObjectId = IISMethods.getobjectid()
            var ResponseBody = {}

            const pipeline = [{ $match: { '_id': ObjectId(req.body._id) } }]
            const parcelResp = await MainDB.getmenual(TableName, new _Parcel(), pipeline)

            const parcel = parcelResp.ResultData[0]

            const currentdate = new Date()

            if (new Date(parcel.parceldate).toISOString().slice(0, 10) == currentdate.toISOString().slice(0, 10)) {

                const resp = await MainDB.executedata('u', new _Pet(), TableName, req.body)

                if (resp.status == 200) {
                    const parcelLog = {
                        gatekeeperid: req.headers.uid,
                        gatekeeper: req.headers.personname,
                        parcelid: req.body._id,
                        status: req.body.status,
                        collectdate: req.body.collectdate,
                        handoverdate: req.body.handoverdate,
                        iscollectfromgate: req.body.iscollectfromgate,
                        propertyid: req.headers.propertyid,
                        property: req.headers.property
                    }
                    await MainDB.executedata('i', new ParcelLog(), "tblparcellogmaster", parcelLog)
                }

                ResponseBody.status = resp.status
                ResponseBody.data = resp.data
                ResponseBody.message = resp.message
            } else {
                ResponseBody.status = 400
                ResponseBody.data = "The parcel's date does not align with the current date."
            }

            req.ResponseBody = ResponseBody
            next()
        }
        catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

	// Update pet
	async UpdatePetMaster(req, res, next) {
		 try {

            const ObjectId = IISMethods.getobjectid()
            var ResponseBody = {}

            const pipeline = [{ $match: { '_id': ObjectId(req.body._id) } }]
            const record = await MainDB.getmenual(TableName, new _Pet(), pipeline)
            
            var RecordInfo = record.ResultData[0].recordinfo
            RecordInfo.updateuid = req.headers.uid
            RecordInfo.updateby = req.headers.personname
            RecordInfo.updatedate = IISMethods.getdatetimeisostr()
            req.body.recordinfo = RecordInfo

            const resp = await MainDB.executedata('u', new _Pet(), TableName, req.body)

            if(resp.status == 200){
                const newpets = {
                    petname: req.body.petname,
                    pettype: req.body.pettype,
                    breed: req.body.breed,
                    identificationfeature: req.body.identificationfeature,
                    dateofbirth:req.body.dateofbirth
                }
    
                const customerObj = await MainDB.FindOne('tblcustomer', new _Customer(), { _id: req?.body?.customerid });
    
                if(customerObj){
                    const foundIndex = customerObj?.pet?.findIndex((obj) => obj?.petid.toString() == req?.body?._id);
    
                    if (foundIndex != -1) {
                        for (const key in newpets) {
                            customerObj.pet[foundIndex][key] = newpets[key];
                        }
                    } else {
                        customerObj?.pet?.push(newpets);
                    }
    
                     await MainDB.executedata("u", new _Customer(), "tblcustomer", customerObj)
                }
            }
       

            // Update Dependency
            // const updatePipeline = [
            //     {countryid: req.body._id},
            //     { $set: { country: req.body.country, } }
            // ]
            // const updateModelObj = {
            //     tblpersonmaster: new _Person(),
            //     tblcitymaster: new _City(),
            //     tblstatemaster: new _State(),
            // }
            // const tempArray = []
            // for (const key in updateModelObj) {
            //     if(key === "tblpersonmaster"){
            //         tempArray.push(MainDB.UpdateMany(key, updateModelObj[key],[{ countryid: req.body._id},{$set: {country: req.body.country,}}]))
            //         tempArray.push(MainDB.UpdateMany(key, updateModelObj[key],[{permanentaddresscountryid: req.body._id},{$set: {permanentaddresscountry: req.body.country,}}])
            //         )
            //     }
            //     tempArray.push(MainDB.UpdateMany(key, updateModelObj[key], updatePipeline))
            // }
            // await Promise.all(tempArray)

            var ResponseBody = {}
            ResponseBody.status = resp.status
            ResponseBody.data = resp.data
            ResponseBody.message = resp.message

            req.ResponseBody = ResponseBody
            next()
        }
        catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
	}

	// Delete vehicle 
	async DeletePetMaster(req, res, next) {
		try {
			const ResponseBody = {}

            const resp = await MainDB.executedata('d', new _Pet(), TableName, req.body)
            
			ResponseBody.status = resp.status
			ResponseBody.message = resp.message

			req.ResponseBody = ResponseBody
			next()
		} catch (err) {
			req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
			next()
		}
	}

}
