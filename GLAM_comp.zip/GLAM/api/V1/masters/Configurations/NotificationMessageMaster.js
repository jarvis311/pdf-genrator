import { Config, MainDB, IISMethods } from "../../../../config/Init.js"
import _NotificationCategoryData from "../../../../model/masters/Configurations/NotificationCategoryData.js"

const TableName = "tblnotificationcategorydata"
const PageName = "Notification Message"
const FormName = "Notification Message"
const FltPageCollection = "notificationcategorydata"

export default class NotificationMessageMaster {

    //List
    async ListNotificationMessageMaster(req, res, next) {
        try {
            const ResponseBody = {};
            const ObjectId = IISMethods.getobjectid()

            const {
                searchtext = "",
                paginationinfo: { nextpageid = "", pageno = 1, pagelimit = 10, filter = {}, sort = {}, projection = {} }
            } = req.body || {} 

            const sortData = Object.keys(sort).length !== 0 ? sort : { _id: -1 }

            const pipeline = IISMethods.GetPipelineForAndFilter(filter)
            if (searchtext !== "") {
                pipeline.push(...IISMethods.GetGlobalSearchFilter(new _NotificationCategoryData(), searchtext))
            }

            const resp = await MainDB.getmenual(TableName, new _NotificationCategoryData(), pipeline, {}, sortData, true) 

            ResponseBody.pagename = PageName
            ResponseBody.formname = FormName
            ResponseBody.fltpagecollection = FltPageCollection
            ResponseBody.data = resp.ResultData
            ResponseBody.fieldorder = resp.fieldorderdata
            ResponseBody.status = 200
            ResponseBody.message = Config.getResponsestatuscode()["200"]

            req.ResponseBody = ResponseBody; next()

        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }; next()
        }
    }


    async UpdateNotificationMessageMaster(req, res, next) {
        try {
            const ResponseBody = {}
            const ObjectId = IISMethods.getobjectid()

            // const promiseArray = []
            // for (const message of req.body.data) {
            //     promiseArray.push(MainDB.executedata("u", new _NotificationCategoryData(), TableName, message))
            // }

            // await Promise.all(promiseArray)

            const resp = await MainDB.executedata("u", new _NotificationCategoryData(), TableName, req.body)

            ResponseBody.status = resp.status
            ResponseBody.message = resp.message

            req.ResponseBody = ResponseBody
            next()

        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }
}