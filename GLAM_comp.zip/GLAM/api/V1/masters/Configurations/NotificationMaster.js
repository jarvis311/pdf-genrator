import { Config, MainDB } from "../../../../config/Init.js"
import _Notification from "../../../../model/masters/Configurations/Notification.js"

const TableName = "tblnotification"

export default class NotificationMaster {
    //List
    async ListNotification(req, res, next) {
        try {
            const ResponseBody = {}

            const pipeline = [{ $match: {} }]

            var isAdmin = await MainDB.IsAdmin(req.headers.uid)

            // if (req.headers.userroleid != Config.getAdminutype() && req.headers.masterlisting === 'false' && (req.userauth.rights.all || req.userauth.rights.self)) {
            if (!isAdmin && req.headers.masterlisting === 'false' && (req.userauth.rights.all || req.userauth.rights.self)) {
                pipeline.push({ $match: { $or: [{ 'recordinfo.entryuid': { "$in": req.userauth.uid } }] } })
            }
            const resp = await MainDB.getmenual(TableName, new _Notification(), pipeline)

            ResponseBody.status = 200
            ResponseBody.message = Config.getResponsestatuscode()["200"]
            ResponseBody.data = resp.ResultData
            
            req.ResponseBody = ResponseBody; next()
        } catch (err) {
            
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }; next()
        }
    }
}
