import { IISMethods, Config } from "../../../../config/Init.js"
// import Person from "../../../../model/Person_new.js"
import _NotificationSetting from "../../../../model/masters/Configurations/NotificationSetting.js"

const TableName = "tblnotificationsettingmaster"
const PageName = "Notification Setting"
const FormName = "Notification Setting"
const FltPageCollection = "notificationsetting"

export default class NotificationSettingMaster {
    // List
    async ListNotificationSetting(req, res, next) {
        try {
            const ResponseBody = {}

            const { paginationinfo: { nextpageid, pagelimit, pageno, filter, sort, projection } } = req.body || {}
            const requiredPage = {
                nextpageid: nextpageid,
                pagelimit: pagelimit,
                pageno: pageno,
                skip: (pageno - 1) * pagelimit
            }
            const sortData = Object.keys(sort).length !== 0 ? sort : { _id: -1 }

            const pipeline = IISMethods.GetPipelineForFilter(filter)
            var isAdmin = await MainDB.IsAdmin(req.headers.uid)

            // if (req.headers.userroleid != Config.getAdminutype() && req.headers.masterlisting === 'false' && (req.userauth.rights.all || req.userauth.rights.self)) {
            if (!isAdmin && req.headers.masterlisting === 'false' && (req.userauth.rights.all || req.userauth.rights.self)) {
                pipeline.push({ $match: { $or: [{ 'recordinfo.entryuid': { "$in": req.userauth.uid } }] } })
            }
            const resp = await MainDB.getmenual(TableName, new _NotificationSetting(), pipeline, requiredPage, sortData, true, "", projection)

            ResponseBody.pagename = PageName
            ResponseBody.formname = FormName
            ResponseBody.fltpagecollection = FltPageCollection
            ResponseBody.status = 200
            ResponseBody.message = Config.getResponsestatuscode()["200"]
            ResponseBody.data = resp.ResultData
            ResponseBody.currentpage = resp.currentpage
            ResponseBody.nextpage = resp.nextpage

            if (resp.fieldorderdata) {
                ResponseBody.fieldorder = resp.fieldorderdata
            } else {
                const ProcessImage = new _NotificationSetting()
                ResponseBody.fieldorder = ProcessImage.getFieldOrder()
            }

            req.ResponseBody = ResponseBody; next()
        } catch (err) {
            
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }; next()
        }
    }

    //Insert
    async InsertNotificationSetting(req, res, next) {
        try {
            const ResponseBody = {}
            ResponseBody.status = 401
            ResponseBody.message = Config.getResponsestatuscode()["401"]
            const ObjectId = IISMethods.getobjectid()
            const NotificationSetting = req.body
            let DelPipeline

            if (NotificationSetting.personid) DelPipeline = { personid: ObjectId(req.body.personid),notificationcategoryid: ObjectId(req.body.notificationcategoryid) , moduletypeid : Config.moduletype[req.headers.moduletype]}
            else if (NotificationSetting.userroleid) DelPipeline = { userroleid: ObjectId(req.body.userroleid),notificationcategoryid: ObjectId(req.body.notificationcategoryid), moduletypeid : Config.moduletype[req.headers.moduletype]}

			// Deleting previous assign data
            const DeleteResp = await MainDB.DeleteMany(TableName, new _NotificationSetting(), DelPipeline)

			if (DeleteResp.status === 200) {
				let isblank = 1

                const NotificationSettingArray = []

                for (let NotificationData of NotificationSetting.notificationdata) {
                    if (NotificationSetting.personid && NotificationSetting.personid.toString() !== Config.dummyObjid) {
                        NotificationSetting.userroleid = ObjectId(Config.dummyObjid)
                        NotificationSetting.userrole = ""
                    } else if (NotificationSetting.userroleid && NotificationSetting.userroleid.toString() !== Config.dummyObjid){
                        NotificationSetting.personid = ObjectId(Config.dummyObjid)
                    }

                    if(NotificationData.isselected === 1 || NotificationData.isshow === 1) {
                        isblank = 0

                        const NotificationSettingObj = {
                            personid: NotificationSetting.personid,
                            userroleid: NotificationSetting.userroleid,
                            userrole: NotificationSetting.userrole,
                            notificationcategoryid: NotificationSetting.notificationcategoryid,
                            notificationcategory: NotificationSetting.notificationcategory,
                            notificationcategorydataid: NotificationData.notificationcategorydataid,
                            notificationcategorydata: NotificationData.notificationcategorydata,
                            alias: NotificationData.alias,
                            isselected: NotificationData.isselected,
                            isshow: NotificationData.isshow, 
                            message: NotificationData.message,
                            interval: NotificationData?.interval,
                            nooftimerepeat: NotificationData?.nooftimerepeat,
    
                            // persons: NotificationSetting.persons ? NotificationSetting.persons: [],
                            persons: NotificationSetting.persons ? NotificationSetting.persons : NotificationData.persons ? NotificationData.persons : [],
                            departments: NotificationSetting.departments ? NotificationSetting.departments: [],
                            designations: NotificationSetting.designations ? NotificationSetting.designations: [],
    
                            recordinfo: {
                                entryuid: req.headers.uid,
                                entryby: req.headers.personname,
                                entrydate: IISMethods.getdatetimestr(),
                                timestamp: IISMethods.GetTimestamp()
                            }
                        }
                        
                        if(NotificationData?.audiourl){
                            const audioPath = IISMethods.getfilepath(req.headers.subdomainname, "audiourl")
                            NotificationSettingObj.audiourl = await IISMethods.uploadToS3(NotificationData?.audiourl, audioPath)
    
                            NotificationData.audiourl = NotificationSettingObj.audiourl 
                        }
                        NotificationSettingArray.push({...NotificationSettingObj})

                    }
                }

                if(isblank === 0 && NotificationSettingArray.length) {
                    const notificationsettingArray = Array.from(NotificationSettingArray.reduce((map, obj) => map.set(obj.alias, obj), new Map()).values())

                    const resp = await MainDB.InsertMany(TableName, new _NotificationSetting(), notificationsettingArray)

                    if(resp.status === 200){
                        if (NotificationSetting.userroleid && NotificationSetting.personid.toString() === Config.dummyObjid) {
    
                            const userRoleWisePersonIds = await MainDB.getmenual("tblpersonmaster", new Person(), [{ $match: { "userrole.userroleid": ObjectId(NotificationSetting.userroleid) } }])
                            const personIdsToUpAudios = userRoleWisePersonIds.ResultData?.map((data) => data._id)
    
                            if (personIdsToUpAudios?.length) {
                                for (const notificationData of NotificationSetting.notificationdata) {
                                    if (notificationData?.audiourl) {
                                        const upNotiSettingPipeline = [
                                            { personid: { $in: personIdsToUpAudios }, notificationcategorydataid: ObjectId(notificationData.notificationcategorydataid) },
                                            { $set: { audiourl: notificationData.audiourl } },
                                        ]
                                        const upNotiSettingResp = await MainDB.UpdateMany(TableName, new _NotificationSetting(), upNotiSettingPipeline)
                                    }
                                }
                            }
                        }
                    }

                    ResponseBody.status = resp.status
					ResponseBody.message = resp.message
                } else {
					ResponseBody.status = DeleteResp.status
					ResponseBody.message = DeleteResp.message
				}

            } else {
				ResponseBody.status = DeleteResp.status
				ResponseBody.message = DeleteResp.message
			}

           
            req.ResponseBody = ResponseBody; next()
        } catch (err) {
            
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }; next()
        }
    }

    //Update
    async UpdateNotificationSetting(req, res, next) {
        try {
            const ResponseBody = {}
            const Pipeline = {
                _id: { $ne: req.body._id },
                userroleid: req.body.userroleid,
                notificationcategorydataid: req.body.notificationcategorydataid
            }

            const NotificationSetting = await MainDB.FindOne(TableName, new _NotificationSetting(), Pipeline)

            if (!NotificationSetting) {
                const NotificationPipeline = { _id: req.body._id }
                const NotificationResp = await MainDB.FindOne(TableName, new _NotificationSetting(), NotificationPipeline)

                let RecordInfo = NotificationResp.recordinfo
                RecordInfo.updateuid = req.headers.uid
                RecordInfo.updateby = req.headers.personname
                RecordInfo.updatedate = IISMethods.getdatetimestr()
                req.body.recordinfo = RecordInfo

                const resp = await MainDB.executedata("u", new _NotificationSetting(), TableName, req.body)

                ResponseBody.data = resp.data
                ResponseBody.status = resp.status
                ResponseBody.message = resp.message
            } else {
                ResponseBody.status = 400
                ResponseBody.message = Config.getErrmsg()["isexist"]
            }
            req.ResponseBody = ResponseBody; next()
        } catch (err) {
            
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }; next()
        }
    }

    //Delete
    async DeleteNotificationSetting(req, res, next) {
        try {
            const ResponseBody = {}
            const resp = await MainDB.executedata("d", new _NotificationSetting(), TableName, req.body, true)
            ResponseBody.status = resp.status
            ResponseBody.message = resp.message
            req.ResponseBody = ResponseBody; next()
        } catch (err) {
            
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }; next()
        }
    }

    async ListNotificationData(req, res, next) {
        try {
            const ResponseBody = {}
            const ObjectId = IISMethods.getobjectid()
            const NotificationIds = req.body.userroleid.map((obj) => ObjectId(obj))
            const NotificationPipeline = [{ $match: { userroleid: { $in: NotificationIds } } }]
            const NotificationResp = await MainDB.getmenual(TableName, new _NotificationSetting(), NotificationPipeline)
            const NotificationData = []
            NotificationResp.ResultData.forEach((notification) => {
                const FindNotification = NotificationData.find((obj) => obj.notificationcategoryid.toString() == notification.notificationcategoryid.toString() && obj.notificationcategorydataid.toString() == notification.notificationcategorydataid.toString())
                if (!FindNotification) NotificationData.push(notification)
            })
            ResponseBody.status = 200
            ResponseBody.message = Config.getResponsestatuscode()["200"]
            ResponseBody.data = NotificationData
            req.ResponseBody = ResponseBody; next()
        } catch (err) {
            
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }; next()
        }
    }

    async AudioAddOrUpdate(req, res, next) {
        try {
            const ResponseBody = {}
            const ObjectId = IISMethods.getobjectid()

            //add or update bulk audio 
            if (req.body.notificationsettingids.length) {
                const audioPath = IISMethods.getfilepath(req.headers.subdomainname, "audiourl")
                req.body.audiourl = await IISMethods.uploadToS3(req.body.audiourl, audioPath)

                const updateNotiSettingPipeline = [
                    { _id: { $in: req.body.notificationsettingids.map((id) => ObjectId(id)) } },
                    { $set: { audiourl: req.body.audiourl } }
                ]
                const updateNotiSettingResp = await MainDB.UpdateMany(TableName, new _NotificationSetting(), updateNotiSettingPipeline)

                ResponseBody.status = updateNotiSettingResp.status
                ResponseBody.message = updateNotiSettingResp.message

            } else {
                ResponseBody.status = 400
                ResponseBody.message = Config.getErrmsg()["nodatafound"]
            }
           
            req.ResponseBody = ResponseBody; next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }; next()
        }
    }
}
