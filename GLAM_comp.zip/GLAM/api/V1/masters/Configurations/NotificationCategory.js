import { Config, MainDB, IISMethods, FieldConfig } from "../../../../config/Init.js"
import _NotificationCategory from "../../../../model/masters/Configurations/NotificationCategory.js"
import _NotificationSetting from "../../../../model/masters/Configurations/NotificationSetting.js"

const TableName = "tblnotificationcategory"

export default class NotificationCategoryList {
  
    //List
    async ListNotificationCategory(req, res, next) {
        try {

            const ResponseBody = {}

            const ObjectId = IISMethods.getobjectid()

            const allowedNotificationCategoryids = []

            // ***************************** userrole wise notification *****************************/
            const userroleSettingPipeline = [{ $match: { userroleid: ObjectId(req.headers.userroleid), isshow: 1 } }]
            const userroleSettingResp = await MainDB.getmenual("tblnotificationsettingmaster", new _NotificationSetting(), userroleSettingPipeline)

            for (const settingObj of userroleSettingResp.ResultData) {
                if (!allowedNotificationCategoryids.includes(settingObj.notificationcategoryid?.toString())) {
                    allowedNotificationCategoryids.push(settingObj.notificationcategoryid?.toString())
                }
            }
            // ***************************** userrole wise notification *****************************/


            // ***************************** person wise notification *****************************/
            const personSettingPipeline = [{ $match: { personid: ObjectId(req.headers.uid), isshow: 1 } }]
            const personSettingResp = await MainDB.getmenual("tblnotificationsettingmaster", new _NotificationSetting(), personSettingPipeline)


            for (const settingObj of personSettingResp.ResultData) {
                if (!allowedNotificationCategoryids.includes(settingObj.notificationcategoryid?.toString())) {
                    allowedNotificationCategoryids.push(settingObj.notificationcategoryid?.toString())
                }
            }
            // ***************************** person wise notification *****************************/

            const categoryPipeline = [{ $match: { _id: { $in: allowedNotificationCategoryids?.map((obj) => ObjectId(obj)) } } }];

            //Global serach
            const searchtext = req.body.searchtext
            if (searchtext) {
                categoryPipeline.push(...IISMethods.GetGlobalSearchFilter(new _NotificationCategory(), searchtext))
            }

            const categoryResp = await MainDB.getmenual(TableName, new _NotificationCategory(), categoryPipeline)

            for(const respObj of categoryResp.ResultData){
                respObj.svg = IISMethods.getImageUrl(respObj.svg)
            }

            ResponseBody.status = 200
            ResponseBody.message = Config.getResponsestatuscode()["200"]
            ResponseBody.data = categoryResp.ResultData

            req.ResponseBody = ResponseBody; next()
        } catch (err) {

            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }; next()
        }
    }

    async ListAllNotificationCategory(req, res, next) {
        try {
            
            const ResponseBody = {}

            const resp = await MainDB.getmenual("tblnotificationcategory", new _NotificationCategory(), [{ $sort: { name: 1 } }])

            for(const respObj of resp.ResultData){
                respObj.svg = IISMethods.getImageUrl(respObj.svg)
            }
      
            ResponseBody.status = 200
            ResponseBody.message = Config.getResponsestatuscode()["200"]
            ResponseBody.data = resp.ResultData

            req.ResponseBody = ResponseBody; next()
        } catch (err) {
            
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }; next()
        }
    }
}
