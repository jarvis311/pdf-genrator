import { Config, MainDB, IISMethods } from "../../../../config/Init.js"
import _NotificationCategoryData from "../../../../model/masters/Configurations/NotificationCategoryData.js"
import _NotificationSetting from "../../../../model/masters/Configurations/NotificationSetting.js"

const TableName = "tblnotificationcategorydata"

export default class NotificationCategoryDataList {
    //List
    async ListNotificationCategorySetting(req, res, next) {
        try {
            const ResponseBody = {}
            const ObjectId = IISMethods.getobjectid()

            const responseData = []

            // Person Wise Notification
            const personwisenotificationsettingPipeline = [
                { $match: { notificationcategoryid: ObjectId(req.body.notificationcategoryid), personid: ObjectId(req.body.personid) } }
            ]
            const personwisenotificationsettingResp = await MainDB.getmenual(
                "tblnotificationsettingmaster",
                new _NotificationSetting(),
                personwisenotificationsettingPipeline
            )

            if (personwisenotificationsettingResp.ResultData.length) {
                responseData.push(...personwisenotificationsettingResp.ResultData)
            } else {
                // Userrole wise notification setting
                const userrolewisenotificationsettingPipeline = [
                    { $match: { notificationcategoryid: ObjectId(req.body.notificationcategoryid), userroleid: ObjectId(req.body.userroleid) } }
                ]
                const userrolewisenotificationsettingResp = await MainDB.getmenual(
                    "tblnotificationsettingmaster",
                    new _NotificationSetting(),
                    userrolewisenotificationsettingPipeline
                )

                if (userrolewisenotificationsettingResp.ResultData.length) {
                    responseData.push(...userrolewisenotificationsettingResp.ResultData)
                }
            }

            for (const settingObj of responseData) {
                if (settingObj.audiourl) {
                    settingObj.audiourl = IISMethods.getImageUrl(settingObj.audiourl)
                }
            }

            ResponseBody.status = 200
            ResponseBody.message = Config.getResponsestatuscode()["200"]
            ResponseBody.data = responseData

            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

    // list for web setting
    async ListNotificationCategoryData(req, res, next) {
        try {
            const ResponseBody = {}
            const ObjectId = IISMethods.getobjectid()

            const pipeline = [
                {
                    $match: { notificationcategoryid: ObjectId(req.body.notificationcategoryid) }
                },
                {
                    $project: {
                        notificationcategorydataid: "$_id",
                        notificationcategorydata: "$name",
                        alias: "$alias"
                    }
                },
                {
                    $sort: { notificationcategorydata: 1 }
                }
            ]

            var isAdmin = await MainDB.IsAdmin(req.headers.uid)

            // if (req.headers.userroleid != Config.getAdminutype() && req.headers.masterlisting === "false" && (req.userauth.rights.all || req.userauth.rights.self)) {
            if (!isAdmin && req.headers.masterlisting === "false" && (req.userauth.rights.all || req.userauth.rights.self)) {
                pipeline.push({ $match: { $or: [{ "recordinfo.entryuid": { $in: req.userauth.uid } }] } })
            }
            const resp = await MainDB.getmenual(TableName, new _NotificationCategoryData(), pipeline)

            let settingbasedon = 0 // 1--> PersonWise, 2--> UserRoleWise 
            if (req.body.userroleid || req.body.personid) {
                let settingpipeline = []
                let settingresp = []

                if (req.body.personid) {
                    //priority give to person
                    settingbasedon = 1
                    settingpipeline = [{ $match: { personid: ObjectId(req.body.personid) } }]
                } else {
                    settingbasedon = 2
                    settingpipeline = [{ $match: { userroleid: ObjectId(req.body.userroleid) } }]
                }

                settingresp = await MainDB.getmenual("tblnotificationsettingmaster", new _NotificationSetting(), settingpipeline)

                if (settingresp.ResultData?.length === 0 && req.body.personid) {
                    settingbasedon = 2
                    const settingpipeline = [{ $match: { userroleid: ObjectId(req.body.userroleid) } }]
                    settingresp = await MainDB.getmenual("tblnotificationsettingmaster", new _NotificationSetting(), settingpipeline)
                }
                if (settingresp.ResultData?.length === 0) {
                    settingbasedon = 0
                }

                resp.ResultData.forEach((obj) => {
                    obj.isselected = 0

                    var subcategoryObject = settingresp.ResultData?.find((subobj) => subobj?.notificationcategorydataid?.toString() == obj._id.toString())

                    if (subcategoryObject?.isselected == 1) {
                        obj.isselected = 1
                    }

                    obj.departments = subcategoryObject?.departments ? subcategoryObject?.departments : []
                    obj.designations = subcategoryObject?.designations ? subcategoryObject?.designations : []
                    obj.persons = subcategoryObject?.persons ? subcategoryObject?.persons : []

                    obj.interval = subcategoryObject?.interval ? subcategoryObject?.interval : 0
                    obj.nooftimerepeat = subcategoryObject?.nooftimerepeat ? subcategoryObject?.nooftimerepeat : 0

                    obj.dataid = subcategoryObject?._id?.toString() ? subcategoryObject?._id?.toString() : Config.dummyObjid
                    obj.audiourl = subcategoryObject?.audiourl ? Config.s3baseurl + subcategoryObject?.audiourl : ""
                    
                    obj.isshow = subcategoryObject?.isshow ? subcategoryObject?.isshow : 0
                    obj.message = subcategoryObject?.message ? subcategoryObject?.message : ""
                })
            }

            ResponseBody.status = 200
            ResponseBody.message = Config.getResponsestatuscode()["200"]
            ResponseBody.settingbasedon = settingbasedon
            ResponseBody.data = resp.ResultData

            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }
    // list for web setting

    //notification setting for data
    async ListNotificationSettingData(req, res, next) {
        try {
            const ResponseBody = {}
            const ObjectId = IISMethods.getobjectid()

            const userroleWiseSettingPipeline = [
                {
                    $match: { userroleid: ObjectId(req.body.userroleid), isselected: 1 }
                }
            ]
            const userroleWiseSettingResp = await MainDB.getmenual(
                "tblnotificationsettingmaster",
                new _NotificationSetting(),
                userroleWiseSettingPipeline
            )

            let userroleWiseSettingData = userroleWiseSettingResp.ResultData

            let settingresp
            if (req.body.personid) {
                // get person wise setting
                const personWiseSettingPipeline = [{ $match: { personid: ObjectId(req.body.personid) } }]
                settingresp = await MainDB.getmenual("tblnotificationsettingmaster", new _NotificationSetting(), personWiseSettingPipeline)
            }

            userroleWiseSettingData.forEach((obj) => {
                obj.isselected = 0

                const subcategoryObject = settingresp?.ResultData?.find(
                    (subobj) => subobj?.notificationcategorydataid?.toString() == obj.notificationcategorydataid.toString()
                )

                if (subcategoryObject?.audiourl) {
                    obj.audiourl = IISMethods.getImageUrl(subcategoryObject.audiourl)
                } else if (obj.audiourl) {
                    obj.audiourl = IISMethods.getImageUrl(obj.audiourl)
                }

                if (subcategoryObject?.isselected == 1) {
                    obj.isselected = 1
                }
            })

            ResponseBody.data = userroleWiseSettingData
            ResponseBody.status = 200
            ResponseBody.message = Config.getResponsestatuscode()["200"]

            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }
}
