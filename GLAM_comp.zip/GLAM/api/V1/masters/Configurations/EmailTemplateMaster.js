import { IISMethods, Config } from "../../../../config/Init.js"
import _EmailTemplate from "../../../../model/masters/Configurations/EmailTemplate.js"

const TableName = "tblemailtemplatemaster"
const PageName = "Email Template"
const FormName = "Email Template"
const FltPageCollection = "emailtemplatemaster"

export default class EmailTemplateMaster {
	// List Email Template
	async ListEmailTemplate(req, res, next) {
		try {
			const ResponseBody = {}

			const {
				searchtext = "",
				paginationinfo: { pageno = 1, pagelimit = 20, filter = {}, sort = {}, projection = {} }
			} = req.body || {} 

			const requiredPage = {
				pageno: pageno,
				skip: (pageno - 1) * pagelimit,
				pagelimit: pagelimit
			}

			const sortData = Object.keys(sort).length !== 0 ? sort : { templatename: 1 }

			const pipeline = IISMethods.GetPipelineForFilter(filter)

			if (searchtext !== "") {
				pipeline.push(...IISMethods.GetGlobalSearchFilter(new _EmailTemplate(), searchtext))
			}

			const resp = await MainDB.getmenual(TableName, new _EmailTemplate(), pipeline, requiredPage, sortData, true, "", projection) 

			ResponseBody.pagename = PageName
			ResponseBody.formname = FormName
			ResponseBody.fltpagecollection = FltPageCollection
			ResponseBody.status = 200
			ResponseBody.message = Config.getResponsestatuscode()["200"]
			ResponseBody.data = resp.ResultData
			ResponseBody.fieldorder = resp.fieldorderdata
			ResponseBody.currentpage = resp.currentpage
			ResponseBody.nextpage = resp.nextpage

			req.ResponseBody = ResponseBody
			next()
		} catch (err) {
			req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
			next()
		}
	}

	// Insert Email Template
	async InsertEmailTemplate(req, res, next) {
		try {
			const ResponseBody = {}

			const resp = await MainDB.executedata("i", new _EmailTemplate(), TableName, req.body)

			ResponseBody.status = resp.status
			ResponseBody.message = resp.message

			req.ResponseBody = ResponseBody
			next()
		} catch (err) {
			req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
			next()
		}
	}

	// Update Email Template
	async UpdateEmailTemplate(req, res, next) {
		try {
			const ResponseBody = {}

			const emailtemplatePipeline = { _id: req.body._id }
			const emailtemplate = await MainDB.FindOne(TableName, new _EmailTemplate(), emailtemplatePipeline)

			if (emailtemplate) {
				const RecordInfo = emailtemplate.recordinfo
				RecordInfo.updateuid = req.headers.uid
				RecordInfo.updateby = req.headers.personname
				RecordInfo.updatedate = IISMethods.getdatetimestr()
				req.body.recordinfo = RecordInfo

				const resp = await MainDB.executedata("u", new _EmailSMTP(), TableName, req.body)

				ResponseBody.status = resp.status
				ResponseBody.message = resp.message
			} else {
				ResponseBody.status = 404
				ResponseBody.message = Config.getErrmsg()["notexist"]
			}

			req.ResponseBody = ResponseBody
			next()
		} catch (err) {
			req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
			next()
		}
	}

	// Delete Email Template
	async DeleteEmailTemplate(req, res, next) {
		try {
			const ResponseBody = {}

			const resp = await MainDB.executedata("d", new _EmailTemplate(), TableName, req.body)

			ResponseBody.status = resp.status
			ResponseBody.message = resp.message

			req.ResponseBody = ResponseBody
			next()
		} catch (err) {
			req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
			next()
		}
	}
}
