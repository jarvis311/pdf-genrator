import { IISMethods, Config } from "../../../../config/Init.js"
import _EmailSMTP from "../../../../model/masters/Configurations/EmailSMTP.js"

const TableName = "tblemailsmtp"
const PageName = "Email SMTP"
const FormName = "Email SMTP"
const FltPageCollection = "emailsmtp"

export default class EmailSMTP {
	// List Email SMTP
	async ListEmailSMTP(req, res, next) {
		try {
			const ResponseBody = {}

			const {
				searchtext = "",
				paginationinfo: { pageno = 1, pagelimit = 10, filter = {}, sort = {}, projection = {} }
			} = req.body || {} 

			const requiredPage = {
				pageno: pageno,
				skip: (pageno - 1) * pagelimit,
				pagelimit: pagelimit
			}

			const sortData = Object.keys(sort).length !== 0 ? sort : { sendername: -1 }

			const pipeline = IISMethods.GetPipelineForFilter(filter)

			if (searchtext !== "") {
				pipeline.push(...IISMethods.GetGlobalSearchFilter(new _EmailSMTP(), searchtext))
			}

			const resp = await MainDB.getmenual(TableName, new _EmailSMTP(), pipeline, requiredPage, sortData, true, "", projection) 

			ResponseBody.pagename = PageName
			ResponseBody.formname = FormName
			ResponseBody.fltpagecollection = FltPageCollection
			ResponseBody.status = 200
			ResponseBody.message = Config.getResponsestatuscode()["200"]
			ResponseBody.data = resp.ResultData
			ResponseBody.fieldorder = resp.fieldorderdata
			ResponseBody.currentpage = resp.currentpage
			ResponseBody.nextpage = resp.nextpage

			req.ResponseBody = ResponseBody
			next()
		} catch (err) {
			req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
			next()
		}
	}

	// Insert Email SMTP
	async InsertEmailSMTP(req, res, next) {
		try {
			const ResponseBody = {}

			const resp = await MainDB.executedata("i", new _EmailSMTP(), TableName, req.body)

			ResponseBody.status = resp.status
			ResponseBody.message = resp.message

			req.ResponseBody = ResponseBody
			next()
		} catch (err) {
			req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
			next()
		}
	}

	// Update Email SMTP
	async UpdateEmailSMTP(req, res, next) {
		try {
			const ResponseBody = {}

			const emailsmtpPipeline = { _id: req.body._id }
			const emailsmtp = await MainDB.FindOne(TableName, new _EmailSMTP(), emailsmtpPipeline)

			if (emailsmtp) {
				const RecordInfo = emailsmtp.recordinfo
				RecordInfo.updateuid = req.headers.uid
				RecordInfo.updateby = req.headers.personname
				RecordInfo.updatedate = IISMethods.getdatetimestr()
				req.body.recordinfo = RecordInfo

				const resp = await MainDB.executedata("u", new _EmailSMTP(), TableName, req.body)

				if (resp.status === 200 && req.body.default === 1) {
					const emailsmtpUpdatePipeline = [{ _id: { $ne: req.body._id } }, { $set: { default: 0 } }]
					await MainDB.UpdateManyByFilter(TableName, new _EmailSMTP(), emailsmtpUpdatePipeline)
				}

				ResponseBody.status = resp.status
				ResponseBody.message = resp.message
			} else {
				ResponseBody.status = 404
				ResponseBody.message = Confgi.getErrmsg()["notexist"]
			}

			req.ResponseBody = ResponseBody
			next()
		} catch (err) {
			req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
			next()
		}
	}

	// Delete Email SMTP
	async DeleteEmailSMTP(req, res, next) {
		try {
			const ResponseBody = {}

			const resp = await MainDB.executedata("d", new _EmailSMTP(), TableName, req.body)

			ResponseBody.status = resp.status
			ResponseBody.message = resp.message

			req.ResponseBody = ResponseBody
			next()
		} catch (err) {
			req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
			next()
		}
	}
}
