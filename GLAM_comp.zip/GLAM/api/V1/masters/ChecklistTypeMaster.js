import { IISMethods, MainDB, Config } from "../../../config/Init.js"
import _CheckListType from "../../../model/masters/CheckListType.js"
import _Checklist from '../../../model/CheckList.js'
import _Recurrencetype from '../../../model/masters/Recurrencetype.js'

const TableName = "tblchecklisttypemaster"
const PageName = "checklisttype"
const FormName = "Check List Type"
const FltPageCollection = "checklisttypemaster"

export default class CheckListType {
    // List CheckListTypes
    async ListCheckListType(req, res, next) {
        try {
            var ResponseBody = {}
            var PaginationInfo = req.body.paginationinfo

            const requiredPage = { pageno: PaginationInfo.pageno, skip: (PaginationInfo.pageno - 1) * PaginationInfo.pagelimit, pagelimit: PaginationInfo.pagelimit }
            var pipeline = []
            var sort = (Object.keys(PaginationInfo.sort).length !== 0 ? PaginationInfo.sort : { '_id': -1 })
            let projection = PaginationInfo.projection ? PaginationInfo.projection : {}
            let fieldorder = req.body.paginationinfo.isfieldorder ? req.body.paginationinfo.isfieldorder : 0

            pipeline = IISMethods.GetPipelineForFilter(PaginationInfo.filter)

            const searchtext = req.body.searchtext || ""
            if (searchtext !== "") {
                pipeline.push(...IISMethods.GetGlobalSearchFilter(new _CheckListType(), searchtext))
            }

            const resp = await MainDB.getmenual(TableName, new _CheckListType(), pipeline, requiredPage, sort, fieldorder, "", projection)

            ResponseBody.pagename = PageName
            ResponseBody.formname = FormName
            ResponseBody.fltpagecollection = FltPageCollection
            ResponseBody.status = 200
            ResponseBody.message = Config.getResponsestatuscode()['200']
            ResponseBody.data = resp.ResultData
            ResponseBody.currentpage = resp.currentpage
            ResponseBody.nextpage = resp.nextpage
            ResponseBody.totaldocs = resp.totaldocs;
            ResponseBody.fieldorder = resp.fieldorderdata
            ResponseBody.formfieldorderdata = resp.formfieldorderdata

            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

    // Insert CheckListType
    async InsertCheckListType(req, res, next) {
        try {
            const ResponseBody = {}

            const resp = await MainDB.executedata("i", new _CheckListType(), TableName, req.body)

            ResponseBody.status = resp.status
            ResponseBody.message = resp.message
            ResponseBody.data = resp.data

            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

    // Update relation
    async UpdateCheckListType(req, res, next) {
        try {

            const ObjectId = IISMethods.getobjectid()
            var ResponseBody = {}

            const pipeline = [{ $match: { '_id': ObjectId(req.body._id) } }]
            const record = await MainDB.getmenual(TableName, new _CheckListType(), pipeline)

            var RecordInfo = record.ResultData[0].recordinfo
            RecordInfo.updateuid = req.headers.uid
            RecordInfo.updateby = req.headers.personname
            RecordInfo.updatedate = IISMethods.getdatetimeisostr()
            req.body.recordinfo = RecordInfo

            const resp = await MainDB.executedata('u', new _CheckListType(), TableName, req.body)

            if (resp.status === 200) {
                // Update Dependency
                const updatePipeline = [
                    { checklisttypeid: req.body._id },
                    { $set: { checklisttype: req.body.checklisttype, } }
                ]
                const updateModelObj = {
                    tblchecklist:new _Checklist()
                }
                
                const tempArray = []
                for (const key in updateModelObj) {
                    tempArray.push(MainDB.UpdateMany(key, updateModelObj[key], updatePipeline))
                }
                await Promise.all(tempArray)
            }

            var ResponseBody = {}
            ResponseBody.status = resp.status
            ResponseBody.data = resp.data
            ResponseBody.message = resp.message

            req.ResponseBody = ResponseBody
            next()
        }
        catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

    // Delete relation
    async DeleteCheckListType(req, res, next) {
        try {
            const ResponseBody = {}

            //Dependency Check
            const customerObjModel = await MainDB.createmodel('tblchecklist', new _Checklist())

            var dependency = [
                [customerObjModel['objModel'], { checklisttypeid: req.body._id }]
            ]

            const resp = await MainDB.executedata('d', new _CheckListType(), TableName, req.body,true,dependency)

            ResponseBody.status = resp.status
            ResponseBody.message = resp.message

            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }


    async ListRecurrencetype(req, res, next) {
        try {
            var ResponseBody = {}
            var PaginationInfo = req.body.paginationinfo

            const requiredPage = { pageno: PaginationInfo.pageno, skip: (PaginationInfo.pageno - 1) * PaginationInfo.pagelimit, pagelimit: PaginationInfo.pagelimit }
            var pipeline = []
            var sort = (Object.keys(PaginationInfo.sort).length !== 0 ? PaginationInfo.sort : { '_id': -1 })
            let projection = PaginationInfo.projection ? PaginationInfo.projection : {}
            let fieldorder = req.body.paginationinfo.isfieldorder ? req.body.paginationinfo.isfieldorder : 0

            pipeline = IISMethods.GetPipelineForFilter(PaginationInfo.filter)

            const searchtext = req.body.searchtext || ""
            if (searchtext !== "") {
                pipeline.push(...IISMethods.GetGlobalSearchFilter(new _Recurrencetype(), searchtext))
            }

            const resp = await MainDB.getmenual("tblrecurrencetypemaster", new _Recurrencetype(), pipeline, requiredPage, sort, fieldorder, "", projection)

            ResponseBody.pagename = PageName
            ResponseBody.formname = FormName
            ResponseBody.fltpagecollection = FltPageCollection
            ResponseBody.status = 200
            ResponseBody.message = Config.getResponsestatuscode()['200']
            ResponseBody.data = resp.ResultData
            ResponseBody.currentpage = resp.currentpage
            ResponseBody.nextpage = resp.nextpage
            ResponseBody.totaldocs = resp.totaldocs;
            ResponseBody.fieldorder = resp.fieldorderdata
            ResponseBody.formfieldorderdata = resp.formfieldorderdata

            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

    // Insert Recurrencetype
    async InsertRecurrencetype(req, res, next) {
        try {
            const ResponseBody = {}

            const resp = await MainDB.executedata("i", new _Recurrencetype(), "tblrecurrencetypemaster", req.body)

            ResponseBody.status = resp.status
            ResponseBody.message = resp.message
            ResponseBody.data = resp.data

            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

}