import { IISMethods,MainDB, Config } from "../../../../config/Init.js"
import _Asset from "../../../../model/masters/Asset/Asset.js"
import _Items from '../../../../model/masters/Asset/Item.js'
import _Series from '../../../../model/masters/Series.js'
import _AssetCategory from "../../../../model/masters/Asset/Assetcategory.js"
import _Lost from '../../../../model/masters/LostAndfound/Lost.js'
import _Approve from '../../../../model/Approve.js'

const TableName = "tblasset"
const PageName = "asset"
const FormName = "asset"
const FltPageCollection = "asset"

export default class AssetMaster {
	// List Asset
	async ListAssetMaster(req, res, next) {
		try {
            var ResponseBody = {}
            var PaginationInfo =  req.body.paginationinfo

            const requiredPage = {pageno : PaginationInfo.pageno, skip : (PaginationInfo.pageno - 1) * PaginationInfo.pagelimit, pagelimit : PaginationInfo.pagelimit}
            var pipeline = []
            var sort = (Object.keys(PaginationInfo.sort).length !== 0 ? PaginationInfo.sort : {'_id' :-1})
            let projection = PaginationInfo.projection ? PaginationInfo.projection : {}
            let fieldorder = req.body.paginationinfo.isfieldorder ? req.body.paginationinfo.isfieldorder : 0

            const ObjectId = IISMethods.getobjectid()

            let extrapipeline = []

            // for available view
            if(PaginationInfo.filter.available){
                extrapipeline.push(
                    // { $addFields: { isavailable : 
                    //     { $cond: { 
                    //         if: { $gt: [ { $size: "$assignedto" }, 0 ] }, 
                    //         then: 1, 
                    //         else: 0 }} 
                    //     }},
                    { $match : { assetstatusid : new ObjectId(Config.assetstatus['Available']) } }
                    )
                delete PaginationInfo.filter.available
            }

            // FOR ASSIGNED VIEW
            if(PaginationInfo.filter.assigned){
                extrapipeline.push(
                    { $addFields: { isavailable : 
                        { $cond: { 
                            if: { $gt: [ { $size: "$assignedto" }, 0 ] }, 
                            then: 1, 
                            else: 0 }} 
                        }},
                    { $match : { isavailable : 1 } })
                delete PaginationInfo.filter.assigned
            }

            if(PaginationInfo.filter.itemcategoryid){
                let itempipeline = []
                itempipeline.push({$match:{isasset:1}})
                if(Array.isArray(PaginationInfo.filter.itemcategoryid) && PaginationInfo.filter.itemcategoryid.length){
                    let objid = PaginationInfo.filter.itemcategoryid.map((o)=> new ObjectId(o))
                    itempipeline=[{$match:{"itemcategoryid": {$in : objid }}},{$project:{_id:1}}]
                }else if(typeof PaginationInfo.filter.itemcategoryid === 'string'){
                    itempipeline=[{$match:{"itemcategoryid":new ObjectId(PaginationInfo.filter.itemcategoryid)}},{$project:{_id:1}}]
                }
                
                if(itempipeline.length){
                    const itemresp= await MainDB.getmenual('tblitems', new _Items(), itempipeline)
                    extrapipeline.push({$match:{itemgroupid:{$in:itemresp.ResultData.map(o=>new ObjectId(o._id))}}})
                }
                delete PaginationInfo.filter.itemcategoryid
            }
           
            pipeline = IISMethods.GetPipelineForFilter(PaginationInfo.filter)

            const searchtext = req.body.searchtext || ""
            if (searchtext !== "") {
                pipeline.push(...IISMethods.GetGlobalSearchFilter(new _Asset(), searchtext))
            }
                        
            const resp = await MainDB.getmenual(TableName, new _Asset(), pipeline, requiredPage, sort, fieldorder,"", projection)
              
            ResponseBody.pagename = PageName
            ResponseBody.formname = FormName
			ResponseBody.fltpagecollection = FltPageCollection
            ResponseBody.status = 200
            ResponseBody.message = Config.getResponsestatuscode()['200']
            ResponseBody.data = resp.ResultData
            ResponseBody.currentpage = resp.currentpage
            ResponseBody.nextpage = resp.nextpage   
            ResponseBody.totaldocs = resp.totaldocs
            ResponseBody.fieldorder = resp.fieldorderdata 
            ResponseBody.formfieldorderdata = resp.formfieldorderdata            

            req.ResponseBody = ResponseBody
            next()
		} catch (err) {
			req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
			next()
		}
	}

	// Insert Asset
	   //Insert
       async InsertAssetMaster(req, res, next)
       {
           try {
               var ResponseBody = {}
               const ObjectId = IISMethods.getobjectid()
   
               let ID = new ObjectId()
               req.body._id = ID
                                      
               let hasseries = false
               let resp
               let error = []
   
               //get series from series table
               //ITEM SERIES
               const assetSeriesPipeline = [{ $match: { seriestype: "assets", propertyid: new ObjectId(req.headers.propertyid) } }, { $limit: 1 }]
               const seriesResp = await MainDB.getmenual('tblseriesmaster', new _Series(), assetSeriesPipeline)
                  
               // Check assets series data available or not
               
               if (!seriesResp.ResultData.length || error.length) {
                   hasseries = true;
                   let message = [];
                   if (!seriesResp.ResultData.length) {
                       message.push('Item ' + Config.errmsg['addreqseries']);
                   }
                   if (error.length) {
                       message.push(...error.map(err => Config.errmsg[err] || err));
                   }
                   resp = {
                       status: 400,
                       message: message.join(' and '), // Concatenate messages
                       errors: error
                   };
               }
             
   
               //ITEM ENTRY
               if(!hasseries){
                   req.body.assetqrcode = IISMethods.generatecode(6)
                   let seriesId = await MainDB.getseriesno(new ObjectId(req.headers.propertyid), seriesResp.ResultData[0]._id, 'asset', new _Asset())
                   let maxid = await MainDB.getmaxid(seriesResp.ResultData[0]._id, 'asset', new _Asset())
   
                   req.body.assetid = seriesId
                   req.body.seriesid = seriesResp.ResultData[0]._id
                   req.body.maxid = maxid
                   resp = await MainDB.executedata('i', new _Asset(),TableName, req.body)
               }
   
               ResponseBody.status = resp.status
               ResponseBody.message = resp.message
               ResponseBody.errors = resp.errors
           
               req.ResponseBody = ResponseBody
               next() 
           }
           catch (err) {
               req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err}
               next()
           }
       }


    async UpdateAssetMaster(req, res, next){
        try{
            const ObjectId = IISMethods.getobjectid()
            var ResponseBody = {}

            const pipeline = [{$match : {'_id' : new ObjectId(req.body._id)}}]
            const record = await MainDB.getmenual(TableName, new _Asset(), pipeline)

            let timestamp = new Date().getTime()
            let message

            if(record.ResultData[0]){

                let historyUID = IISMethods.GetTimestamp()
                
                // record info Update data set 
                var RecordInfo = record.ResultData[0].recordinfo
                RecordInfo.updateuid = req.headers.uid
                RecordInfo.updateby = req.headers.personname
                RecordInfo.updatedate = IISMethods.getdatetimeisostr()
                req.body.recordinfo = RecordInfo

                let oldAssignedto = record.ResultData[0].assignedto
                let assineehistory = record.ResultData[0].assineehistory
                let oldassetstatusid = record.ResultData[0].assetstatusid.toString()
            
                let updatedperson = []

                let newpersons = []
                let removepersons = []

                // get old persons and new persons
                for(const iterator of req.body.assignedto){
                    if(!iterator.date){
                        iterator.date = IISMethods.getdatetimeisostr()
                    }
                    let isexist = oldAssignedto.find( o => o.assignedtoid.toString() == iterator.assignedtoid.toString())
                    if(!isexist){
                        newpersons.push(iterator)
                        updatedperson.push(iterator)
                    }else{
                        updatedperson.push(isexist)
                    }
                }

                for(const iterator of oldAssignedto){
                    let isexist = req.body.assignedto.find( o => o.assignedtoid.toString() == iterator.assignedtoid.toString())
                    if(!isexist){
                        removepersons.push(iterator)
                    }
                }

                let isanychange = (oldassetstatusid !== req.body.assetstatusid || newpersons.length || removepersons.length ) ? true : false 
                
                req.body.assetqrcode = ""

                if (!req.body.assetstatuschange || (req.body.assetstatuschange && req.body.assetstatuschange !== 1)) {
                    // Asset status updatation
                    if (req.body.retired) {
                  
                        req.body.assetstatusid = Config.assetstatus['Retired']
                        req.body.assetstatus = 'Retired'
                    } else if (req.body.replace) {
                        if (req.body.iscodegenerate) {
                            req.body.assetqrcode = IISMethods.generatecode(6)
                        }
                            req.body.assetstatusid = Config.assetstatus['In Replace']
                            req.body.assetstatus = 'In Replace'
                            req.body.id = historyUID

                            req.body.startdate = req.body.date,
                            req.body.enddate = req.body.expecteddate

                            req.body.repairreplacehistory?.push({
                                vendorid: req.body.vendorid,
                                vendor: req.body.vendor,
                                vendorstaffid:req.body.vendorstaffid,
                                vendorstaff:req.body.vendorstaff,
                                employeeid: req.body.employeeid,
                                employee: req.body.employee,
                                date: req.body.date,
                                expecteddate: req.body.expecteddate,
                                contactno: req.body.contactno,
                                contactpersonid: req.body.contactpersonid,
                                contactperson: req.body.contactperson,
                                id: historyUID,
                                isrepair: 2
                            })

                            // message = `${req.headers.personname} has been change status from ${record.ResultData[0].assetstatus} to ${req.body.assetstatus}`,
                            
                        } else if(req.body.repair){
                            if (req.body.iscodegenerate) {
                                req.body.assetqrcode = IISMethods.generatecode(6)
                            }
                        req.body.assetstatusid = Config.assetstatus['In Repair']
                        req.body.assetstatus = 'In Repair'
                        req.body.id = historyUID
                        req.body.startdate = req.body.date,
                        req.body.enddate = req.body.expecteddate
    
                        req.body.repairreplacehistory?.push({
                            vendorid : req.body.vendorid,
                            vendor : req.body.vendor,
                            vendorstaffid:req.body.vendorstaffid,
                            vendorstaff:req.body.vendorstaff,
                            date : req.body.date,
                            expecteddate : req.body.expecteddate,
                            contactno : req.body.contactno,
                            contactpersonid : req.body.contactpersonid,
                            contactperson : req.body.contactperson,
                            id : historyUID,
                            isrepair : 1
                        })
    
                    }else if(req.body.missing){
                        if(req.body.islost){

                            // let lostObj = {
                            //     propertyid: req.headers.propertyid,
                            //     property: req.headers.property,
                            //     customerid: req.headers.uid,
                            //     customer: req.headers.personname,
                            //     itemlostfound : record.ResultData[0].assetname,
                            //     itemlostfounddescription:req.body.missingreason,
                            //     lostpriorityid:Config.highlostpriorityid,
                            //     lostpriority:Config.highlostpriority,
                            //     wingid:record.ResultData[0].wingid,
                            //     wing:record.ResultData[0].wing,
                            //     floorid:record.ResultData[0].floorid,
                            //     floor:record.ResultData[0].floor,
                            //     unitid:record.ResultData[0].unitid,
                            //     unit:record.ResultData[0].unit,
                            //     areaid:record.ResultData[0].areaid,
                            //     area:record.ResultData[0].area,
                            // }
                            //  await MainDB.executedata("i", new _Lost(), "tbllost", lostObj)
                        }

                        req.body.assetstatusid = Config.assetstatus['Missing']
                        req.body.assetstatus = 'Missing'
                    }else if(req.body.isbroken){
                        req.body.assetstatusid = Config.assetstatus['Broken']
                        req.body.assetstatus = 'Broken'
                    }else if(req.body.sold){
                        if (req.body.iscodegenerate) {
                            req.body.assetqrcode = IISMethods.generatecode(6)
                        }
                        req.body.assetstatusid = Config.assetstatus['Sold']
                        req.body.assetstatus = 'Sold'
                    }else if(req.body.scraped){
                        if (req.body.iscodegenerate) {
                            req.body.assetqrcode = IISMethods.generatecode(6)
                        }
                        req.body.assetstatusid = Config.assetstatus['Scraped']
                        req.body.assetstatus = 'Scraped'
                    }
                    else if(isanychange){
                        // if(req.body.assignedto && req.body.assignedto.length){
        
                            req.body.assetstatusid = req.body.assetstatusid
                            req.body.assetstatus = req.body.assetstatus
        
                        // }else if(!req.body.assignedto.length){
                        //     req.body.assetstatusid = Config.assetstatus['Occupied']
                        //     req.body.assetstatus = 'Occupied'
                        // }else if(!req.body.assignedto.length){
                        //     req.body.assetstatusid = Config.assetstatus['Occupied']
                        //     req.body.assetstatus = 'Occupied'
                        // } else if(!req.body.assignedto.length){
                        //     req.body.assetstatusid = Config.assetstatus['Available']
                        //     req.body.assetstatus = 'Available'
                        // } 
                    }
                }

                let result = "";
                if (req.body.contactperson) {
                    result = req.body.contactperson
                } else if (req.body.vendorstaff) {
                    result = req.body.vendorstaff
                } else if (req.body.employee) {
                    result = req.body.employee
                } else {
                    result = ""
                }

                if(isanychange){

                    // store history of remove persons
                    if(removepersons.length){
    
                        for(const obj of removepersons){
                            assineehistory.push({
                                assigneeid : obj.assignedtoid,
                                assignee : obj.assignedto,
                                changebyid : req.headers.uid,
                                changeby : req.headers.personname,
                                assetstatusid : req.body.assetstatusid,
                                assetstatus : req.body.assetstatus,
                                backgroundcolor : req.body.backgroundcolor,
                                assignto : result,
                                historytype : 1,
                                assigneetype : 2,
                                date : IISMethods.getdatetimeisostr(),
                                conditionnameid  : req.body.conditionnameid,
                                conditionname  : req.body.conditionname,
                                message: `${req.headers.personname} has been change status from ${record.ResultData[0].assetstatus} to ${req.body.assetstatus}`,
                                cid : timestamp
                            })
                        }
                    }
    
                    // store history of new persons
                    if(newpersons.length){
                        for(const obj of newpersons){
    
                            assineehistory.push({
                                assigneeid : obj.assignedtoid,
                                assignee : obj.assignedto,
                                changebyid : req.headers.uid,
                                changeby : req.headers.personname,
                                assetstatusid : req.body.assetstatusid,
                                assetstatus : req.body.assetstatus,
                                backgroundcolor : req.body.backgroundcolor,
                                assignto : result,
                                historytype: 1,
                                assigneetype : 1,
                                date : IISMethods.getdatetimeisostr(),
                                conditionnameid  : req.body.conditionnameid,
                                conditionname  : req.body.conditionname,
                                message:`${req.headers.personname} has been change status from ${record.ResultData[0].assetstatus} to ${req.body.assetstatus}`,
                                cid : timestamp
                            })
                        }
                    }
                    

                    let statusChanged = req.body.assetstatusid != record.ResultData[0].assetstatusid.toString()

            
                    if((statusChanged && req.body.assetstatusid != Config.assetstatus['Allocated']) || req.body.assetstatuschange == 1){ 
    
                        assineehistory.push({
                            changebyid : req.headers.uid,
                            changeby : req.headers.personname,
                            assetstatusid : req.body.assetstatusid,
                            assetstatus : req.body.assetstatus,
                            backgroundcolor : req.body.backgroundcolor,
                            historytype : 3 ,
                            assignto : result,
                            date : IISMethods.getdatetimeisostr(),
                            conditionnameid  : req.body.conditionnameid,
                            conditionname  : req.body.conditionname,
                            message:`${req.headers.personname} has been change status from ${record.ResultData[0].assetstatus} to ${req.body.assetstatus}`,
                            cid : timestamp
                        })
    
                    }
    
                    req.body.assineehistory = assineehistory
    
                    // ---------------------- Activity History End--------------------
                }


                if (req.body.iscodegenerate) {
                    var { assetname, floor, floorid, unit, unitid, wingid, wing, assetstatusid, assetstatus } = record.ResultData[0]
                    const data = {
                        propertyid: req.headers.propertyid,
                        property: req.headers.property,
                        customerid: req.headers.uid,
                        customer: req.headers.personname,
                        name: assetname,
                        floor: floor,
                        floorid: floorid,
                        unit: unit,
                        unitid: unitid,
                        wing: wing,
                        wingid: wingid,
                        iscollectfromgate: req.body.iscollectfromgate,
                        assetid: req.body._id,
                        otp: req.body.assetqrcode,
                        approvetype: 4,
                        assetstatusid: assetstatusid,
                        assetstatus: assetstatus
                    }

                    await MainDB.InsertMany("tblapprovemaster", new _Approve(), data)
                }
              

                req.body.assignedto = updatedperson
                const resp = await MainDB.executedata('u', new _Asset(),TableName, req.body)
                console.log("🚀 ~ AssetMaster ~ UpdateAssetMaster ~ req.body:", JSON.stringify(req.body))
                
                ResponseBody.status = resp.status
                ResponseBody.data = resp.data
                ResponseBody.message = resp.message

            }else{
                ResponseBody.status = 401
                ResponseBody.message = "Asset Not Found"
            }

            req.ResponseBody = ResponseBody
            next()

        }
        catch(err){
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err}
            next()
        }
    }

	
    
    async DeleteAssetMaster(req, res, next) {
		try {
			const ResponseBody = {}

            const resp = await MainDB.executedata('d', new _Asset(), TableName, req.body)
   
			ResponseBody.status = resp.status
			ResponseBody.message = resp.message

			req.ResponseBody = ResponseBody
			next()
		} catch (err) {
			req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
			next()
		}
	}

}
