import { IISMethods,MainDB, Config } from "../../../../config/Init.js"
import _Items from "../../../../model/masters/Asset/Item.js"
import _Assets from '../../../../model/masters/Asset/Asset.js'
import _Series from '../../../../model/masters/Series.js'
import _AssetCategory from "../../../../model/masters/Asset/Assetcategory.js"

const TableName = "tblassetmaster"
const PageName = "assetmaster"
const FormName = "assetmaster"
const FltPageCollection = "assetmaster"

export default class ItemMaster {
	// List item
	async ListItemMaster(req, res, next) {
		try {
            var ResponseBody = {}
            var PaginationInfo =  req.body.paginationinfo

            const requiredPage = {pageno : PaginationInfo.pageno, skip : (PaginationInfo.pageno - 1) * PaginationInfo.pagelimit, pagelimit : PaginationInfo.pagelimit}
            var pipeline = []
            var sort = (Object.keys(PaginationInfo.sort).length !== 0 ? PaginationInfo.sort : {'_id' :-1})
            let projection = PaginationInfo.projection ? PaginationInfo.projection : {}
            let fieldorder = req.body.paginationinfo.isfieldorder ? req.body.paginationinfo.isfieldorder : 0


            pipeline = IISMethods.GetPipelineForFilter(PaginationInfo.filter)

            const searchtext = req.body.searchtext || ""
            if (searchtext !== "") {
                pipeline.push(...IISMethods.GetGlobalSearchFilter(new _Items(), searchtext))
            }
                        
            const resp = await MainDB.getmenual(TableName, new _Items(), pipeline, requiredPage, sort, fieldorder,"", projection)

            const assetResp = await MainDB.getmenual('tblasset', new _Assets(), [{$match : {}}])

            for(const obj of resp.ResultData){
                let totalassets = assetResp.ResultData.filter( o => o.itemgroupid.toString() == obj._id.toString())
                obj.available =  totalassets.filter( o => o.statusid.toString() == Config.assetstatus['Available']).length
                obj.allocated = totalassets.filter( o => o.statusid.toString() == Config.assetstatus['Allocated']).length
                obj.inrepair = totalassets.filter( o => o.statusid.toString() == Config.assetstatus['In Repair']).length
                obj.missing = totalassets.filter( o => o.statusid.toString() == Config.assetstatus['Missing']).length
                obj.retired = totalassets.filter( o => o.statusid.toString() == Config.assetstatus['Retired']).length
                obj.occupied = totalassets.filter( o => o.statusid.toString() == Config.assetstatus['Occupied']).length
                obj.inreplace = totalassets.filter( o => o.statusid.toString() == Config.assetstatus['In Replace']).length
                obj.totalassets = totalassets.length - obj.missing - obj.retired

            }
              
            ResponseBody.pagename = PageName
            ResponseBody.formname = FormName
			ResponseBody.fltpagecollection = FltPageCollection
            ResponseBody.status = 200
            ResponseBody.message = Config.getResponsestatuscode()['200']
            ResponseBody.data = resp.ResultData
            ResponseBody.currentpage = resp.currentpage
            ResponseBody.nextpage = resp.nextpage   
            ResponseBody.totaldocs = resp.totaldocs;
            ResponseBody.fieldorder = resp.fieldorderdata 
            ResponseBody.formfieldorderdata = resp.formfieldorderdata            

            req.ResponseBody = ResponseBody
            next()
		} catch (err) {
			req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
			next()
		}
	}

	// Insert Asset
    //Insert
    async InsertItems(req, res, next)
    {
        try {
            var ResponseBody = {}
            const ObjectId = IISMethods.getobjectid()

            let ID = new ObjectId()
            req.body._id = ID
                                   
            let hasseries = false
            let resp
            let error = []

            //get series from series table

            //ITEM SERIES
            const seriesPipeline = [{$match:{seriestypeid: new ObjectId(Config.seriestype['Item']),propertyid: new ObjectId(req.headers.propertyid)}}] 
            const seriesResp = await MainDB.getmenual('tblseriesmaster', new _Series(), seriesPipeline)
            console.log("🚀 ~ ItemMaster ~ seriesResp:", seriesResp)
            
            const assetSeriesPipeline = [{$match:{seriestypeid: new ObjectId(Config.seriestype['Asset']) }}] 
            const assetSeriesResp = await MainDB.getmenual('tblseriesmaster', new _Series(), assetSeriesPipeline)

            const iitemcategorypipeline = [{$match : {_id : new ObjectId(req.body.assetcategoryid)}}] 
            const itemcategoryresp = await MainDB.getmenual('tblassetcategroymaster', new _AssetCategory(), iitemcategorypipeline)
            
            // Check assets series data available or not
            
            if (!seriesResp.ResultData.length || error.length) {
                hasseries = true;
                let message = [];
                if (!seriesResp.ResultData.length) {
                    message.push('Item ' + Config.errmsg['addreqseries']);
                }
                if (error.length) {
                    message.push(...error.map(err => Config.errmsg[err] || err));
                }
                resp = {
                    status: 400,
                    message: message.join(' and '), // Concatenate messages
                    errors: error
                };
            }
            

            else if(req.body.beginningstock && req.body.beginningstock.length && !hasseries){

                
                let itemstockid = []
                let itemResp
                let count = 0
                let failedAssetInsertNumber=0
                for(const obj of req.body.beginningstock){
                    count = count + 1

                    if(count < 10000){
                        
                        // let branchData = branchResp.ResultData.find( o => o._id.toString() == obj.branchid)
                        
                        
                        obj.itemgroupid = req.body._id
                        obj.itemgroup = req.body.itemname

                        obj.propertyid = req.headers.propertyid
                        obj.property = req.headers.property
    
                        obj.statusid = Config.assetstatus['Available']
                        obj.status = 'Available'
    
                        obj.itemimage = req.body.itemimage
                        obj.itemdescription = req.body.itemdescription
    
                        obj.recordinfo = {
                            entryuid : req.headers.uid,
                            entryby : req.headers.personname,
                            entrydate : IISMethods.getdatetimeisostr(),
                            timestamp:IISMethods.GetTimestamp(),
                            isactive:1
                        }

                        if(obj.vendorid == ''){
                            delete obj.vendorid
                        }
                        // if (assetSeriesdata) {

                            // obj.seriesid = assetSeriesdata.seriesid


                            // if(obj.assetid){

                            //     // obj.maxid = obj.assetno

                            // }else{

                            //     let seriesId = await MainDB.getseriesno( new ObjectId(req.headers.propertyid),"",assetSeriesdata.seriesid,'Asset',new _Assets())
                            //     let maxid = await MainDB.getmaxid(assetSeriesdata.seriesid,'Asset', new _Assets())
            
                            //     obj.maxid = maxid
                            //     obj.assetid = seriesId
            
                            // }
                            // if(!itemstockid.includes(obj.itemgroupid)){
                            //     itemstockid.push(obj.itemgroupid)
                            //     itemResp = MainDB.executedata('i', new _BeginningAssetStock(),'tblbeginningsssetstock', obj)
                            // }
                        
                                let asset = await MainDB.executedata('i', new _Assets(),'tblasset', obj)
                                console.log("🚀 ~ ItemMaster ~ asset:", asset)
                                                 
                        // }else{
                        //     failedAssetInsertNumber++;
                        //     error.push({
                        //         itemGroup:obj.itemgroup,
                        //         category:subcategory.subcategory,
                        //         itemCategory:subcategory.itemcategory,
                        //         branchId : branchData._id,
                        //         companyId:branchData.companyid.toString(),
                        //         error :'Asset ' + Config.errmsg['reqseries']
                        //     })
                        //     resp = {
                        //         status : 400,
                        //         // message : `Some Assets not Added FailedAssetInsertCount=${failedAssetInsertNumber}, insertedAssetCount=${req.body.beginningstock.length-failedAssetInsertNumber}`,
                        //         message : `Some Assets not Added`,
                        //         errors : error
                        //     }
                        //     if(failedAssetInsertNumber===req.body.beginningstock.length){ //when none of the assets are added
                        //         hasseries = true
                        //     }
                        // }
                    }
                }
            }


            //ITEM ENTRY
            if(!hasseries){

                let itemSeriesdata = seriesResp.ResultData[0]
                console.log("🚀 ~ ItemMaster ~ itemSeriesdata:", itemSeriesdata)
                // let seriesId = MainDB.getseriesno( req.headers.propertyid,itemSeriesdata._id,'items',new _Items())
                // let maxid = MainDB.getmaxid(itemSeriesdata._id,'items', new _Items())

                // req.body.seriesid = itemSeriesdata._id
                // req.body.itemid = seriesId
                // req.body.maxid = maxid
                resp = await MainDB.executedata('i', new _Items(),TableName, req.body)
            }


            ResponseBody.status = resp.status
            ResponseBody.message = resp.message
            ResponseBody.errors = resp.errors
        
            req.ResponseBody = ResponseBody
            next() 
        }
        catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err}
            next()
        }
    }

	// Update Asset
	async UpdateItemsMaster(req, res, next) {
		 try {

            const ObjectId = IISMethods.getobjectid()
            var ResponseBody = {}

            const pipeline = [{ $match: { '_id': ObjectId(req.body._id) } }]
            const record = await MainDB.getmenual(TableName, new _Items(), pipeline)
            
            var RecordInfo = record.ResultData[0].recordinfo
            RecordInfo.updateuid = req.headers.uid
            RecordInfo.updateby = req.headers.personname
            RecordInfo.updatedate = IISMethods.getdatetimeisostr()
            req.body.recordinfo = RecordInfo

            const resp = await MainDB.executedata('u', new _Items(), TableName, req.body)

            var ResponseBody = {}

            ResponseBody.status = resp.status
            ResponseBody.data = resp.data
            ResponseBody.message = resp.message

            req.ResponseBody = ResponseBody
            next()
        }
        catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
	}

	// Delete Asset 
	async DeleteItemsMaster(req, res, next) {
		try {
			const ResponseBody = {}

            const resp = await MainDB.executedata('d', new _Items(), TableName, req.body)
   
			ResponseBody.status = resp.status
			ResponseBody.message = resp.message

			req.ResponseBody = ResponseBody
			next()
		} catch (err) {
			req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
			next()
		}
	}

}
