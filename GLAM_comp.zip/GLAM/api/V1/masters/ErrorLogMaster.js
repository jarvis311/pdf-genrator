import { IISMethods, Config } from "../../../config/Init.js"
import _ErrorLog from "../../../model/ErrorLog.js"

const TableName = "tblerrorlog"
const PageName = "Error Logs"
const FormName = "Error Logs"
const FltPageCollection = "errorlog"

export default class ErrorLog {
    // List ErrorLog
    async ListErrorLog(req, res, next) {
        try {
            const ResponseBody = {}

            const {
                searchtext = "",
                fromdate, todate,
                paginationinfo: {
                    projection = {}, 
                    pageno = 1,
                    pagelimit = 10,
                    filter = {},
                    sort = {},
                }
            } = req.body

            // delete filter.fromdate
            // delete filter.todate

            var pipeline = [{ $project: { _time: 0, __v: 0 } }]
            const requiredPage = { pageno: pageno, skip: (pageno - 1) * pagelimit, pagelimit: pagelimit }
            const sortData = Object.keys(sort).length !== 0 ? sort : { _id: -1 }

            pipeline.push(...IISMethods.getDateFilter({ fromdate, todate, filterkey: "time", timezone: req.headers.timezone }))

            // Global Search
            if (searchtext !== "") {
                pipeline.push(...IISMethods.GetGlobalSearchFilter(new _ErrorLog(), searchtext))
            }

            const resp = await MainDB.getmenual(TableName, new _ErrorLog(), pipeline, requiredPage, sortData, true, "", projection) 

            ResponseBody.status = 200
            ResponseBody.message = Config.getResponsestatuscode()["200"]
            ResponseBody.data = resp.ResultData
            ResponseBody.currentpage = resp.currentpage
            ResponseBody.nextpage = resp.nextpage
            ResponseBody.fieldorder = resp.fieldorderdata
            ResponseBody.pagename = PageName
            ResponseBody.formname = FormName
            ResponseBody.fltpagecollection = FltPageCollection
            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }
}