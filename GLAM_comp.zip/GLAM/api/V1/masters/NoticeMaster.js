import { IISMethods, MainDB,FieldConfig, Config } from "../../../config/Init.js"
import _Notice from '../../../model/masters/Notice.js'
import _Employee from '../../../model/Onboarding/Employee.js'
import _Customer from '../../../model/Onboarding/Customer.js'
import _Gatekeeper from '../../../model/Onboarding/GateKeeper.js'

const TableName = "tblnoticemaster"
const PageName = "notice"
const FormName = "Notice Master"
const FltPageCollection = "noticemaster"

export default class NoticeMaster {
    // List notice
    async ListNoticeMaster(req, res, next) {
        try {
            var ResponseBody = {}
            var PaginationInfo = req.body.paginationinfo
            const ObjectId = IISMethods.getobjectid()

            const requiredPage = { pageno: PaginationInfo.pageno, skip: (PaginationInfo.pageno - 1) * PaginationInfo.pagelimit, pagelimit: PaginationInfo.pagelimit }
            var pipeline = []
            var sort = (Object.keys(PaginationInfo.sort).length !== 0 ? PaginationInfo.sort : { '_id': -1 })
            let projection = PaginationInfo.projection ? PaginationInfo.projection : {}
            let fieldorder = req.body.paginationinfo.isfieldorder ? req.body.paginationinfo.isfieldorder : 0

            
            if (PaginationInfo.filter) {
                if (PaginationInfo.filter.hasOwnProperty('fromdate') || PaginationInfo.filter.hasOwnProperty('todate')) {


                    if (PaginationInfo.filter.hasOwnProperty('fromdate') && PaginationInfo.filter.hasOwnProperty('todate')) {
                        const fromdate = new Date(PaginationInfo.filter["fromdate"]);
                        const todate = new Date(PaginationInfo.filter["todate"]);
                        pipeline.push(...IISMethods.getDateFilter({ 'fromdate': fromdate, 'todate': todate, 'filterkey': 'noticedate', 'timezone': FieldConfig.timezone }));
                    } else if (PaginationInfo.filter.hasOwnProperty('fromdate')) {
                        const fromdate = new Date(PaginationInfo.filter["fromdate"]);

                        const filterkey = 'noticedate'
                        pipeline.push(
                            {
                                $addFields: {
                                    converteddate: {
                                        $dateFromString: {
                                            dateString: `\$${filterkey}`,
                                        },
                                    },
                                },
                            },
                            {
                                $addFields: {
                                    [`_${filterkey}`]: {
                                        $dateToString: {
                                            format: "%Y-%m-%d",
                                            date: "$converteddate",
                                            timezone: FieldConfig.timezone,
                                        },
                                    },
                                },
                            },
                        );


                        pipeline.push({
                            $match: {
                                [`_${filterkey}`]: {
                                    $gte: IISMethods.getDateFormats(new Date(fromdate))
                                },
                            },
                        })

                    } else if (PaginationInfo.filter.hasOwnProperty('todate')) {
                        const todate = new Date(PaginationInfo.filter["todate"]);
                        const filterkey = 'noticedate'
                        pipeline.push(
                            {
                                $addFields: {
                                    converteddate: {
                                        $dateFromString: {
                                            dateString: `\$${filterkey}`,
                                        },
                                    },
                                },
                            },
                            {
                                $addFields: {
                                    [`_${filterkey}`]: {
                                        $dateToString: {
                                            format: "%Y-%m-%d",
                                            date: "$converteddate",
                                            timezone: FieldConfig.timezone,
                                        },
                                    },
                                },
                            },
                        );


                        pipeline.push({
                            $match: {
                                [`_${filterkey}`]: {
                                    $lte: IISMethods.getDateFormats(new Date(todate))
                                },
                            },
                        })
                    }
                }

                // else if (fromdate) {
                //     var daterangepipeline = [{ "$match": { "fromdate": { $gte: fromdate } } }];
                // }
                // else if (todate) {
                //     var daterangepipeline = [{ "$match": { "todate": { $lte: todate } } }];
                // }

                delete PaginationInfo.filter["fromdate"]
                delete PaginationInfo.filter["todate"]

                pipeline.push(...IISMethods.GetPipelineForFilter(PaginationInfo.filter))
            }

            if(req.headers.propertyid){
                pipeline.push({$match:{propertyid:ObjectId(req.headers.propertyid)}})
            }

            const searchtext = req.body.searchtext || ""
            if (searchtext !== "") {
                pipeline.push(...IISMethods.GetGlobalSearchFilter(new _Notice(), searchtext))
            }

            const resp = await MainDB.getmenual(TableName, new _Notice(), pipeline, requiredPage, sort, fieldorder, "", projection)

            resp.ResultData?.forEach((obj) => {
                const timezoneWiseDate = IISMethods.getTimezoneWiseDate({ date: obj?.noticedate })
                const date = IISMethods.getFormatWiseDate(timezoneWiseDate, 25)
                obj.formatedate = date
            })

            ResponseBody.pagename = PageName
            ResponseBody.formname = FormName
            ResponseBody.fltpagecollection = FltPageCollection
            ResponseBody.status = 200
            ResponseBody.message = Config.getResponsestatuscode()['200']
            ResponseBody.data = resp.ResultData
            ResponseBody.totaldocs = resp.totaldocs
            ResponseBody.fieldorder = resp.fieldorderdata
            ResponseBody.formfieldorderdata = resp.formfieldorderdata

            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

    // Insert notice
    async InsertNoticeMaster(req, res, next) {
        try {
            const ResponseBody = {}
            const ObjectId = IISMethods.getobjectid()

            req.body.propertyid = req.headers.propertyid
            req.body.property = req.headers.property
            req.body.senderid = req.headers.uid
            req.body.sender = req.headers.personname  

            const resp = await MainDB.executedata("i", new _Notice(), TableName, req.body)

            if (resp.status == 200) {
                const unit = resp.data.unit?.map(obj => ObjectId(obj.unitid))

                let peronResp
                if (req.body.persontype == 2) {
                    let pipeline = [{ $match: { '_id':ObjectId(req.body.gatekeeperid) } }]
                     peronResp = await MainDB.getmenual("tblgatekeeper", new _Gatekeeper(), pipeline)
                } else {
                    let pipeline = [{ $match: { 'property.propertyid': ObjectId(req.headers.propertyid), 'property.unitid': { $in: unit } } }]
                     peronResp = await MainDB.getmenual("tblcustomer", new _Customer(), pipeline)
                }
                

                if (peronResp.ResultData.length) {
                    const toemails = peronResp.ResultData?.map((obj) =>obj.personemail)

                    // notification
                    if (req.body.alerttype && req.body.alerttype.some(alert => alert.alerttypeid.toString() == Config.alerttype['notificationid'])) {

                        let title = IISMethods.makeContent(Config.getNotificationTitles()['notice'], resp.data)

                        var payload = {
                            title: title,
                            body: {
                                ticketid: resp.data._id.toString(),
                                categoryid: resp.data.complaintcategoryid,
                                supportcategoryseries: resp.data.ticketid,
                                category: resp.data.supportcategory,
                                subject: resp.data.subject,
                                description: resp.data.description,
                                sender: resp.data.sender,
                                url: link
                            },
                            type: Config.notificationtype['notice'],
                            pagename: 'notice',
                        }

                        await MainDB.sendNotification({ tousers: notifypersonids, payload: payload, webpushnotify: true, subdomain: req.headers['domainname'] })
                    }

                    // mail send
                    if (req.body.alerttype && req.body.alerttype.some(alert => alert.alerttypeid.toString()  === Config.alerttype['emailid'])) {

                        let template = Config.getEmailTemplates()['notice']

                        let senddata = {
                            title: resp.data.title,
                            noticeid: resp.data.noticeid,
                            subject: resp.data.subject,
                            description: resp.data.description,
                            sender: resp.data.sender,
                            datetime: new Date(resp.data.recordinfo.entrydate).toString()
                        }

                        await MainDB.sendEmail({
                            from: process.env.EMAIL_FROM,
                            to: toemails,
                            subject: resp.data.title,
                            data: senddata,
                            templateid: template
                        })
                    }
                }
            }

            ResponseBody.status = resp.status
            ResponseBody.message = resp.message
            ResponseBody.data = resp.data

            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

    // Update notice
    async UpdateNoticeMaster(req, res, next) {
        try {

            const ObjectId = IISMethods.getobjectid()
            var ResponseBody = {}

            const pipeline = [{ $match: { '_id': ObjectId(req.body._id) } }]
            const record = await MainDB.getmenual(TableName, new _Notice(), pipeline)

            var RecordInfo = record.ResultData[0].recordinfo
            RecordInfo.updateuid = req.headers.uid
            RecordInfo.updateby = req.headers.personname
            RecordInfo.updatedate = IISMethods.getdatetimeisostr()
            req.body.recordinfo = RecordInfo

            const resp = await MainDB.executedata('u', new _Notice(), TableName, req.body)

            var ResponseBody = {}
            ResponseBody.status = resp.status
            ResponseBody.data = resp.data
            ResponseBody.message = resp.message

            req.ResponseBody = ResponseBody
            next()
        }
        catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

    // Delete notice 
    async DeleteNoticeMaster(req, res, next) {
        try {
            const ResponseBody = {}

            const resp = await MainDB.executedata('d', new _Notice(), TableName, req.body)

            ResponseBody.status = resp.status
            ResponseBody.message = resp.message

            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

}
