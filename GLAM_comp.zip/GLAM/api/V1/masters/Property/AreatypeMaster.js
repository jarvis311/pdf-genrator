import { IISMethods,MainDB, Config } from "../../../../config/Init.js"
import _AreaType from "../../../../model/masters/Property/AreaType.js"
import _Customer from '../../../../model/Onboarding/Customer.js'


const TableName = "tblareatypemaster"
const PageName = "areatype"
const FormName = "areatype"
const FltPageCollection = "areatypemaster"

export default class AreaType {
	// List areatype
	async ListAreatype(req, res, next) {
		try {
            var ResponseBody = {}
            var PaginationInfo =  req.body.paginationinfo

            const requiredPage = {pageno : PaginationInfo.pageno, skip : (PaginationInfo.pageno - 1) * PaginationInfo.pagelimit, pagelimit : PaginationInfo.pagelimit}
            var pipeline = []
            var sort = (Object.keys(PaginationInfo.sort).length !== 0 ? PaginationInfo.sort : {'_id' :-1})
            let projection = PaginationInfo.projection ? PaginationInfo.projection : {}
            let fieldorder = PaginationInfo.isfieldorder ? PaginationInfo.isfieldorder : 0

            pipeline = IISMethods.GetPipelineForFilter(PaginationInfo.filter)

            const searchtext = req.body.searchtext || ""
            if (searchtext !== "") {
                pipeline.push(...IISMethods.GetGlobalSearchFilter(new _AreaType(), searchtext))
            }
                        
            const resp = await MainDB.getmenual(TableName, new _AreaType(), pipeline, requiredPage, sort, fieldorder,"", projection)
              
            ResponseBody.pagename = PageName
            ResponseBody.formname = FormName
			ResponseBody.fltpagecollection = FltPageCollection
            ResponseBody.status = 200
            ResponseBody.message = Config.getResponsestatuscode()['200']
            ResponseBody.data = resp.ResultData
            ResponseBody.currentpage = resp.currentpage
            ResponseBody.nextpage = resp.nextpage   
            ResponseBody.totaldocs = resp.totaldocs;
            ResponseBody.fieldorder = resp.fieldorderdata 
            ResponseBody.formfieldorderdata = resp.formfieldorderdata            

            req.ResponseBody = ResponseBody
            next()
		} catch (err) {
			req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
			next()
		}
	}

	// Insert areatype
	async InsertAreatype(req, res, next) {
		try {
			const ResponseBody = {}
            
			const resp = await MainDB.executedata("i", new _AreaType(), TableName, req.body)

			ResponseBody.status = resp.status
			ResponseBody.message = resp.message
            ResponseBody.data = resp.data

			req.ResponseBody = ResponseBody
			next()
		} catch (err) {
			req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
			next()
		}
	}

	// Update areatype
	async UpdateAreatype(req, res, next) {
		 try {

            const ObjectId = IISMethods.getobjectid()
            var ResponseBody = {}

            const pipeline = [{ $match: { '_id': ObjectId(req.body._id) } }]
            const record = await MainDB.getmenual(TableName, new _AreaType(), pipeline)
            
            var RecordInfo = record.ResultData[0].recordinfo
            RecordInfo.updateuid = req.headers.uid
            RecordInfo.updateby = req.headers.personname
            RecordInfo.updatedate = IISMethods.getdatetimeisostr()
            req.body.recordinfo = RecordInfo

            const resp = await MainDB.executedata('u', new _AreaType(), TableName, req.body)

            if (resp.status === 200) {
                // Update Dependency
                const updatePipeline = [
                    { areatypeid: req.body._id },
                    { $set: { areatype: req.body.areatype, } }
                ]
                const updateModelObj = {
                    tblcustomer: new _Customer()
                }
                
                const tempArray = []
                for (const key in updateModelObj) {
                    tempArray.push(MainDB.UpdateMany(key, updateModelObj[key], updatePipeline))
                }
                await Promise.all(tempArray)
            }
            

            //    // Update Dependency
            // const updatePipeline = [
            //     {countryid: req.body._id},
            //     { $set: { country: req.body.country, } }
            // ]
            // const updateModelObj = {
            //     tblpersonmaster: new _Person(),
            //     tblcitymaster: new _City(),
            //     tblstatemaster: new _State(),
            // }
            // const tempArray = []
            // for (const key in updateModelObj) {
            //     if(key === "tblpersonmaster"){
            //         tempArray.push(MainDB.UpdateMany(key, updateModelObj[key],[{ countryid: req.body._id},{$set: {country: req.body.country,}}]))
            //         tempArray.push(MainDB.UpdateMany(key, updateModelObj[key],[{permanentaddresscountryid: req.body._id},{$set: {permanentaddresscountry: req.body.country,}}])
            //         )
            //     }
            //     tempArray.push(MainDB.UpdateMany(key, updateModelObj[key], updatePipeline))
            // }
            // await Promise.all(tempArray)

            var ResponseBody = {}
            ResponseBody.status = resp.status
            ResponseBody.data = resp.data
            ResponseBody.message = resp.message

            req.ResponseBody = ResponseBody
            next()
        }
        catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
	}

	// Delete area type 
	async DeleteAreatype(req, res, next) {
		try {
			const ResponseBody = {}

            const resp = await MainDB.executedata('d', new _AreaType(), TableName, req.body)
   
			ResponseBody.status = resp.status
			ResponseBody.message = resp.message

			req.ResponseBody = ResponseBody
			next()
		} catch (err) {
			req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
			next()
		}
	}

}
