import { IISMethods, MainDB, Config } from "../../../../config/Init.js"
import _City from "../../../../model/masters/City.js"
import _Pincode from '../../../../model/masters/PincodeMaster.js'
import { Propertycommon, PropertyWing, PropertyFloor, PropertyUnit, PropertyArea, PropertyGate, PropertyFacility, PropertyParkingSlot } from '../../../../model/masters/Property/PropertyMaster.js'
import _PropertyCommonDelete from '../../../../model/masters/Property_delete.js'
import AreaType from '../../../../model/masters/Property/AreaType.js'
import _Employee from '../../../../model/Onboarding/Employee.js'
import _Customer from '../../../../model/Onboarding/Customer.js'
import _Gatekeeper from '../../../../model/Onboarding/GateKeeper.js'
import _FacilityRating from '../../../../model/FacilityRating.js'
import _FacilityBooking from '../../../../model/FacilityBooking.js'
import _Vendor from '../../../../model/Onboarding/Vendor.js'
import _VendorStaff from '../../../../model/Onboarding/VendorStaff.js'
import _DailyHelp from '../../../../model/Onboarding/DailyHelp.js'

const TableName = "tblpropertymaster"
const PageName = "property"
const FormName = "property"
const FltPageCollection = "propertymaster"

export default class PropertyMaster {

    // List
    async ListProperty(req, res, next) {
        try {
            const ResponseBody = {}
            const ObjectId = IISMethods.getobjectid()

            const searchtext = req.body.searchtext || ""
            const { paginationinfo: { nextpageid = "", pageno = 1, pagelimit = "*", filter = {}, sort = {}, filter: { fulladdress = "" }, projection = {} }, allproperty = false } = req.body || {}

            const requiredPage = {
                nextpageid: nextpageid,
                pageno: pageno,
                skip: (pageno - 1) * pagelimit,
                pagelimit: pagelimit
            }
            const sortData = Object.keys(sort).length !== 0 ? sort : { propertyname: 1 }

            delete filter.personid
            const pipeline = IISMethods.GetPipelineForFilter(filter)
            let fieldorder = req.body.paginationinfo?.isfieldorder ? req.body.paginationinfo.isfieldorder : 0

            if (searchtext !== "") {
                pipeline.push(...IISMethods.GetGlobalSearchFilter(new Propertycommon(), searchtext))
            }

            const personid = req.headers.uid

            var isAdmin = await MainDB.IsSuperAdmin(req.headers.uid)

            //	if (req.headers.userroleid !== Config.getAdminutype() && typeof personid == "string" && !personid.startsWith("guest-")) {
            if (!isAdmin && typeof personid == "string" && !allproperty) {
                if (req.body.isgatekeeper == 1) {
                    const employeePipeline = [{ $match: { _id: ObjectId(personid) } }]
                    var userResp = await MainDB.getmenual("tblgatekeeper", new _Gatekeeper(), employeePipeline)
                } else if (req.body.iscustomer == 1) {
                    const employeePipeline = [{ $match: { _id: ObjectId(personid) } }]
                    var userResp = await MainDB.getmenual("tblcustomer", new _Customer(), employeePipeline)
                } else {
                    const employeePipeline = [{ $match: { _id: ObjectId(personid) } }]
                    var userResp = await MainDB.getmenual("tblemployee", new _Employee(), employeePipeline)
                }

                //********** assiged property or scheduler property changes *********
                const propertyArray = await IISMethods.getPersonPropertyIds(userResp.ResultData[0], true)

                //**********  assiged property or scheduler property changes **********
                pipeline.push({
                    $match: { _id: { $in: propertyArray } }
                })
            }

            const resp = await MainDB.getmenual(TableName, new Propertycommon(), pipeline, requiredPage, sortData, fieldorder, "", projection)

            ResponseBody.pagename = PageName
            ResponseBody.formname = FormName
            ResponseBody.fltpagecollection = FltPageCollection
            ResponseBody.status = 200
            ResponseBody.message = Config.getResponsestatuscode()["200"]
            ResponseBody.data = resp.ResultData
            ResponseBody.currentpage = resp.currentpage
            ResponseBody.nextpage = resp.nextpage
            ResponseBody.formfieldorderdata = resp.formfieldorderdata

            const Property = new Propertycommon()
            if (resp.fieldorderdata) {
                ResponseBody.fieldorder = resp.fieldorderdata
            } else {
                ResponseBody.fieldorder = Property.getFieldOrder()
            }

            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

    // Insert
    async InsertProperty(req, res, next) {
        try {
            const ResponseBody = {}
            const ObjectId = IISMethods.getobjectid()

            const property = req.body

            if (!req.body._id) {
                property._id = new ObjectId()
            }

            const pipeline = { _id: ObjectId(req.headers.uid) }
            const userResponse = await MainDB.FindOne("tblemployee", new _Employee(), pipeline)

            const employee = userResponse;

            // Generate Unique no
            const uniqueno = IISMethods.generateUniqueNo(req.body.propertyname, 3)
            property.uniqueno = uniqueno

            // Insert property
            if (employee) {
                property.employeeid = employee._id
                property.serviceanimal = 1

                const resp = await MainDB.executedata("i", new Propertycommon(), TableName, property)

                if (resp.status === 200) {
                    const updateEmployeePipeline = [
                        { "userrole.userroleid": ObjectId(Config.getAdminutype()) },
                        { $push: { property: { propertyid: property._id, property: property.propertyname } } }
                    ]
                    await MainDB.UpdateManyByFilter("tblemployee", new _Employee(), updateEmployeePipeline)

                    ResponseBody.status = resp.status
                    ResponseBody.message = resp.message
                } else {
                    ResponseBody.status = resp.status
                    ResponseBody.message = resp.message
                }
            } else {
                ResponseBody.status = 404
                ResponseBody.message = Config.getResponsestatuscode()["404"]
            }

            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

    //Update
    async UpdateProperty(req, res, next) {
        try {
            const ResponseBody = {}
            const ObjectId = IISMethods.getobjectid()

            const propertyPipeline = [{ $match: { _id: ObjectId(req.body._id) } }]
            const propertyResp = await MainDB.getmenual(TableName, new Propertycommon(), propertyPipeline)
            const propertyData = propertyResp.ResultData[0]

            if (propertyData) {

                // record info Update data set
                const RecordInfo = propertyData.recordinfo
                RecordInfo.updateuid = req.headers.uid
                RecordInfo.updateby = req.headers.personname
                RecordInfo.updatedate = IISMethods.getdatetimestr()
                req.body.recordinfo = RecordInfo

                const property = { ...req.body }

                //Dependency Check
                const employeeObjModel = await MainDB.createmodel('tblemployee', new _Employee())
                const customerObjModel = await MainDB.createmodel('tblcustomer', new _Customer())
                const gatekeeperObjModel = await MainDB.createmodel('tblgatekeeper', new _Gatekeeper())
                const vendorstaffObjModel = await MainDB.createmodel('tblvendorstaffmaster', new _VendorStaff())
                const vendorObjModel = await MainDB.createmodel('tblvendormaster', new _Vendor())
                const dailyhelpModel = await MainDB.createmodel('tbldailyhelpmaster', new _DailyHelp())

                var dependency = [
                    [employeeObjModel['objModel'], { 'property.propertyid': req.body._id }, "Employee"],
                    [customerObjModel['objModel'], { 'ownedproperties.propertyid': req.body._id }, "Customer"],
                    [gatekeeperObjModel['objModel'], { 'propertyid': req.body._id }, "Gatekeeper"],
                    [vendorstaffObjModel['objModel'], { 'propertyid': req.body._id }, "VendorStaff"],
                    [vendorObjModel['objModel'], { 'propertyid': req.body._id }, "Vendor"],
                    [dailyhelpModel['objModel'], { 'propertyid': req.body._id }, "Daily Help"]
                ]

                const resp = await MainDB.executedata("u", new Propertycommon(), TableName, property,true,dependency)

                if (resp.status === 200) {

                    let updatePipeline = [
                        { 'property.propertyid': ObjectId(req.body._id) },
                        {
                            $set: {
                                'property.$.property': req.body.propertyname
                            }
                        }
                    ]
                    const updateModelObj = {
                        tblemployee: new _Employee(),
                        tblgatekeeper: new _Gatekeeper(),
                        tblcustomer: new _Customer(),
                        tblvendormaster: new _Vendor(),
                        tblvendorstaffmaster: new _VendorStaff()
                    }
                    
                    const tempArray = []
                    for (const key in updateModelObj) {
                        if(key == "tblcustomer"){
                            updatePipeline = [
                                { 'ownedproperties.propertyid': ObjectId(req.body._id) },
                                {
                                    $set: {
                                        'ownedproperties.$.property': req.body.propertyname
                                    }
                                }
                            ]
                        }else if(key == "tblgatekeeper" || key == "tblvendormaster" || key == "tblvendorstaffmaster"){
                            updatePipeline = [
                                { 'propertyid': ObjectId(req.body._id) },
                                {
                                    $set: {
                                        'property': req.body.propertyname
                                    }
                                }
                            ] 
                        }
                        tempArray.push(MainDB.UpdateMany(key, updateModelObj[key], updatePipeline))
                    }
                    await Promise.all(tempArray)
                }

                ResponseBody.status = resp.status
                ResponseBody.message = resp.message

            } else {
                ResponseBody.status = 404
                ResponseBody.message = Config.getErrmsg()["notexist"]
            }

            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

    //Delete
    async DeleteProperty(req, res, next) {
        try {
            const ResponseBody = {}
            const ObjectId = IISMethods.getobjectid()

            const record = await MainDB.FindOne(TableName, new Propertycommon(), { _id: ObjectId(req.body._id) })

            if (record) {
                const resp = await MainDB.executedata("d", new Propertycommon(), TableName, req.body)
                ResponseBody.status = resp.status
                ResponseBody.message = resp.message
                ResponseBody.existdataPagename = resp.existdataPagename
                if (resp.status === 200) {
                    // Update Person
                    const employeeUpdatePipeline = [{ "property.propertyid": ObjectId(req.body._id) }, { $pull: { property: { propertyid: req.body._id } } }]
                    const gatekeeperUpdatePipeline = [{ "propertyid": ObjectId(req.body._id) }, { $pull: { property: { propertyid: req.body._id } } }]
                    const customerUpdatePipeline = [{ "ownedproperties.propertyid": ObjectId(req.body._id) }, { $pull: { property: { propertyid: req.body._id } } }]

                    delete record._id

                    await Promise.all([
                        MainDB.UpdateManyByFilter("tblemployee", new _Employee(), employeeUpdatePipeline),
                        MainDB.UpdateManyByFilter("tblgatekeeper", new _Gatekeeper(), gatekeeperUpdatePipeline),
                        MainDB.UpdateManyByFilter("tblcustomer", new _Customer(), customerUpdatePipeline),
                        MainDB.executedata("i", new _PropertyCommonDelete(), "tblproperty_delete", record._doc)
                    ])
                }
            } else {
                ResponseBody.status = 404
                ResponseBody.message = Config.getErrmsg()["notexist"]
            }

            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

    async updatePropertyAssign(req, res, next) {
        try {
            const ObjectId = IISMethods.getobjectid();
            const bulkOps = [];

            for (const obj of req.body.data) {

                const existingPropertyIds = obj.property.map(prop => prop.propertyid.toString());

                // Create property array while filtering out existing properties
                const propertyArray = req.body.propertyids
                    .filter(propertyData => !existingPropertyIds.includes(propertyData._id))
                    .map(propertyData => ({
                        propertyid: ObjectId(propertyData._id),
                        property: propertyData.propertyname,
                        isselected: 0
                    }));

                // Only proceed if there are new properties to add
                if (propertyArray.length > 0) {
                    bulkOps.push({
                        updateOne: {
                            filter: { _id: ObjectId(obj._id) },
                            update: {
                                $addToSet: {
                                    property: { $each: propertyArray }
                                }
                            }
                        }
                    })
                }
            }

            // Execute bulk operations if there are any
            if (bulkOps.length > 0) {
                await MainDB.BulkWrite("tblemployee", new _Employee(), bulkOps);
            }

            // Prepare and send the response
            const ResponseBody = {
                status: 200,
                pagename: "bulk policy",
                message: Config.errmsg["update"]
            };
            req.ResponseBody = ResponseBody;
            next();
        } catch (err) {
            // Handle any errors
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err: err.message };
            next();
        }
    }


    async updateOneProperty(req, res, next) {
        try {
            const ObjectId = IISMethods.getobjectid()

            let propertyPipeline = [{ $match: { _id: ObjectId(req.body.propertyid) } }]
            let propertyResponse = await MainDB.getmenual("tblpropertymaster", new Propertycommon(), propertyPipeline)
            let propertyData = propertyResponse.ResultData[0]

            let querypromiseArray = []

            for (const obj of req.body.data) {

                if (!obj.property) {
                    obj.property = []
                }

                const upipeline = [{ _id: obj._id }, { $set: { property: obj.property } }]
                let update = MainDB.Update("tblemployee", new _Employee(), upipeline);
                querypromiseArray.push(update)
            }

            Promise.resolve(querypromiseArray)

            let ResponseBody = {}
            ResponseBody.status = 200
            ResponseBody.pagename = "bulk policy"
            ResponseBody.message = Config.errmsg["update"]
            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }


    //List wing
    async ListWing(req, res, next) {
        try {
            const ResponseBody = {}

            let pipeline = []
            const ObjectId = IISMethods.getobjectid()

            const {
                searchtext = "",
                paginationinfo: { pageno = 1, pagelimit = 200, filter = {}, sort = {}, projection = {} }
            } = req.body || {}

            const requiredPage = {
                pageno: pageno,
                skip: (pageno - 1) * pagelimit,
                pagelimit: pagelimit
            }

            const sortData = Object.keys(sort).length !== 0 ? sort : { _id: -1 }
            let fieldorder = req.body.paginationinfo?.isfieldorder ? req.body.paginationinfo.isfieldorder : 0

            if (Object.keys(filter).length) {
                pipeline = pipeline.concat(IISMethods.GetPipelineForFilter(filter))
            }

            if (!filter.propertyid || !Object.keys(filter.propertyid).length) {
                // filter.propertyid = req.headers.propertyid
                pipeline.push({ $match: { propertyid: ObjectId(req.headers.propertyid) } });
            }

            if (searchtext !== "") {
                pipeline.push(...IISMethods.GetGlobalSearchFilter(new PropertyWing(), searchtext))
            }
            const resp = await MainDB.getmenual("tblpropertywing", new PropertyWing(), pipeline, requiredPage, sortData, fieldorder, "", projection)

            ResponseBody.pagename = "wing"
            ResponseBody.formname = "Wing"
            ResponseBody.fltpagecollection = "propertywing"
            ResponseBody.status = 200
            ResponseBody.message = Config.getResponsestatuscode()["200"]
            ResponseBody.data = resp.ResultData
            ResponseBody.fieldorder = resp.fieldorderdata
            ResponseBody.currentpage = resp.currentpage
            ResponseBody.nextpage = resp.nextpage
            ResponseBody.formfieldorderdata = resp.formfieldorderdata

            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

    //Add wing
    async AddWing(req, res, next) {
        try {
            const ResponseBody = {}

            const ObjectId = IISMethods.getobjectid()
            const pipelinedata = [{ $match: { _id: ObjectId(req.body.propertyid) } }]
            const record = await MainDB.getmenual(TableName, new Propertycommon(), pipelinedata)

            // get count of building
            if (record.ResultData.length > 0) {

                if (!req.body._id) {
                    let wingid = new ObjectId()
                    req.body._id = ObjectId(wingid)
                }

                let Wingobj = req.body
                Wingobj.isactive = 1

                const dependancyPipeline = { propertyid: ObjectId(req.body.propertyid), wingname: req.body.wingname }
                const checkresp = await MainDB.FindOne("tblpropertywing", new PropertyWing(), dependancyPipeline)

                if (!checkresp) {
                    const resp = await MainDB.executedata("i", new PropertyWing(), "tblpropertywing", Wingobj)
                    if (resp.status == 200) {

                        // Update Property
                        const buildingpipelinedata = [{ $match: { propertyid: ObjectId(req.body.propertyid) } }]
                        const buildingrecord = await MainDB.getmenual(
                            "tblpropertywing",
                            new PropertyWing(),
                            buildingpipelinedata
                        )

                        var Property_BuildingId = buildingrecord?.ResultData[0]?._id || ObjectId(Config.dummyObjid)
                        var Property_Building = buildingrecord?.ResultData[0]?.buildingname || ""
                        var Property_Hidebuilding = 1


                        if (buildingrecord.ResultData.length > 1) {
                            Property_BuildingId = ObjectId(Config.dummyObjid)
                            Property_Building = ""
                            Property_Hidebuilding = 0
                        }
                        let Property_Common = {
                            buildingid: Property_BuildingId,
                            building: Property_Building,
                            hidebuilding: Property_Hidebuilding,
                        }

                        await Promise.all([
                            MainDB.Update(TableName, new Propertycommon(), [{ _id: ObjectId(req.body.propertyid) }, { $set: Property_Common }]),
                        ])
                        // property update

                        ResponseBody.status = resp.status
                        ResponseBody.message = resp.message
                        ResponseBody.data = resp.data
                        ResponseBody.property = record.ResultData[0]
                    }
                } else {
                    ResponseBody.status = 401
                    ResponseBody.message = Config.getErrmsg()["isexist"]
                }
            } else {
                ResponseBody.status = 404
                ResponseBody.message = Config.getErrmsg()["nodatafound"]
            }
            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

    //Update wing
    async UpdateWing(req, res, next) {
        try {
            const ResponseBody = {}
            ResponseBody.status = 401
            ResponseBody.message = Config.getResponsestatuscode()["401"]

            const ObjectId = IISMethods.getobjectid()
            const pipelinedata = [{ $match: { _id: ObjectId(req.body._id) } }]
            const record = await MainDB.getmenual("tblpropertywing", new PropertyWing(), pipelinedata)
            if (record.ResultData.length > 0) {
                let Property = req.body

                var RecordInfo = record.ResultData[0].recordinfo;
                RecordInfo.updateuid = req.headers.uid
                RecordInfo.updateby = req.headers.personname
                RecordInfo.updatedate = IISMethods.getdatetimestr()

                Property.recordinfo = RecordInfo
                //Property.wingcount = record.ResultData[0].wingcount
                Property.floorcount = req.body.floorcount
                Property.areacount = req.body.areacount

                const dependancyPipeline = {
                    propertyid: ObjectId(req.body.propertyid),
                    wingname: req.body.wingname,
                    _id: { $ne: ObjectId(req.body._id) }
                }

                const checkresp = await MainDB.FindOne("tblpropertywing", new PropertyWing(), dependancyPipeline)

                if (!checkresp) {
                    const resp = await MainDB.executedata("u", new PropertyWing(), "tblpropertywing", Property)

                    // const pipeline = [{ _id: ObjectId(req.body.propertyid) }, { $set: Property_Common }]
                    // const buildingpipeline = [{ _id: ObjectId(Buildingobj._id) }, { $set: buildingdata }]
                    // await MainDB.Update(TableName, new PropertyCommon(), pipeline)

                    //active or deactive

                    const countbuildingpipeline = [{ $match: { propertyid: ObjectId(req.body.propertyid), isactive: 1 } }]
                    const buildingrecord = await MainDB.getmenual("tblpropertywing", new PropertyWing(), countbuildingpipeline)

                    var property_buildingid = buildingrecord?.ResultData[0]?._id
                    var Property_Buildingname = buildingrecord?.ResultData[0]?.buildingname
                    var hidebuilding = 1

                    if (buildingrecord.ResultData.length > 1) {
                        hidebuilding = 0
                        property_buildingid = ObjectId(Config.dummyObjid)
                        Property_Buildingname = ""
                    }
                    const hidepipeline = [
                        { _id: ObjectId(req.body.propertyid) },
                        { $set: { hidebuilding: hidebuilding, wingid: property_buildingid, wingname: Property_Buildingname } }
                    ]
                    await MainDB.Update("tblproperty", new Propertycommon(), hidepipeline)

                    // Update Dependency
                    let updatePipeline = [
                        { wingid: req.body._id },
                        {
                            $set: {
                                wingname: req.body.wingname
                            }
                        }
                    ]
                    const updateModelObj = {
                        tblpropertyfloor: new PropertyFloor(),
                        tblpropertyarea: new PropertyArea(),
                        tblpropertyunit: new PropertyUnit(),
                        tblproperty: new Propertycommon(),
                        tblemployee: new _Employee(),
                        tblcustomer: new _Customer(),
                        tblgatekeeper: new _Gatekeeper()
                    }
                    const tempArray = []
                    for (const key in updateModelObj) {
                        if (key == "tblproperty") {
                            updatePipeline = [
                                { wingid: req.body._id },
                                {
                                    $set: {
                                        wingname: req.body.wingname
                                    }
                                }
                            ]
                        }else if(key == "tblcustomer"){
                            updatePipeline = [
                                { 'ownedproperties.propertyid': ObjectId(req.body.propertyid), 'ownedproperties.wingid': ObjectId(req.body._id) },
                                {
                                    $set: {
                                        'ownedproperties.$.wing': req.body.wingname
                                    }
                                }
                            ]
                        }

                        tempArray.push(MainDB.UpdateMany(key, updateModelObj[key], updatePipeline))
                    }
                    await Promise.all(tempArray)

                    ResponseBody.data = resp.data
                    ResponseBody.status = resp.status
                    ResponseBody.message = resp.message
                    ResponseBody.property = record.ResultData[0]
                } else {
                    ResponseBody.status = 401
                    ResponseBody.message = Config.getErrmsg()["isexist"]
                }
            }

            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

    //Delete Building
    async DeleteWing(req, res, next) {
        try {
            const ResponseBody = {}
            const ObjectId = IISMethods.getobjectid()
            const buildingPipeline = { _id: ObjectId(req.body._id) }
            const buildingRes = await MainDB.FindOne("tblpropertywing", new PropertyWing(), buildingPipeline)

            //Dependency Check
            const dependencyObj = {
                tblpropertyfloor: new PropertyFloor(),
                tblpropertyarea: new PropertyArea(),
                // tblemployee: new _Employee(),
                 tblcustomer: new _Customer(),
                // tblgatekeeper: new _Gatekeeper()
            }

            // Dependency Array
            const dependency = []
            for (const key in dependencyObj) {
                const ObjModel = await MainDB.createmodel(key, dependencyObj[key])

                if(key == "tblcustomer"){
                    dependency.push([ObjModel["objModel"], { 'ownedproperties.wingid': req.body._id }, "Customer"])   
                }else{
                dependency.push([ObjModel["objModel"], { wingid: req.body._id }, Config.apipagename[key]])
                }
            }
            const resp = await MainDB.executedata("d", new PropertyWing(), "tblpropertywing", req.body, true, dependency)

            if (buildingRes && resp.status == 200) {
                // property update
                const buildingpipelinedata = [{ $match: { propertyid: ObjectId(buildingRes.propertyid) } }]
                const buildingrecord = await MainDB.getmenual("tblpropertywing", new PropertyWing(), buildingpipelinedata)

                var Property_BuildingId = buildingrecord?.ResultData[0]?._id || ObjectId(Config.dummyObjid)
                var Property_Building = buildingrecord?.ResultData[0]?.buildingname || ""
                var Property_HideBuilding = 1

                if (buildingrecord.ResultData.length > 1) {
                    Property_BuildingId = ObjectId(Config.dummyObjid)
                    Property_Building = ""
                    Property_HideBuilding = 0
                }

                let Property_Common = {
                    buildingid: Property_BuildingId,
                    building: Property_Building,
                    hidebuilding: Property_HideBuilding,
                }

                const Pipeline = [{ _id: ObjectId(buildingRes.propertyid) }, { $set: Property_Common }]
                await MainDB.Update(TableName, new Propertycommon(), Pipeline)
                // property update
            }

            ResponseBody.status = resp.status
            ResponseBody.message = resp.message
            ResponseBody.existdataPagename = resp.existdataPagename
            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

    //List Floor
    async ListFloor(req, res, next) {
        try {
            const ResponseBody = {}
            ResponseBody.status = 401
            ResponseBody.message = Config.getResponsestatuscode()["401"]
            // const searchtext = req.body.searchtext || ""
            let pipeline = []

            const ObjectId = IISMethods.getobjectid()

            const { searchtext = "", paginationinfo: { nextpageid = "", pageno = 1, pagelimit = 20, filter = {}, sort = {}, projection = {} } } = req.body || {}

            const requiredPage = { nextpageid: nextpageid, pageno: pageno, skip: (pageno - 1) * pagelimit, pagelimit: pagelimit }

            const sortData = Object.keys(sort).length !== 0 ? sort : { _id: -1 }
            let fieldorder = req.body.paginationinfo?.isfieldorder ? req.body.paginationinfo.isfieldorder : 0

            const wingid = filter.wingid

            if (Array.isArray(wingid)) {
                delete filter.wingid
            }

            let tempPipeline = { $match: { $and: [] } }
            if (Array.isArray(wingid) && wingid.length) {
                tempPipeline["$match"]["$and"].push({ wingid: { $in: wingid.map((id) => ObjectId(id)) } })
            }

            pipeline = pipeline.concat(IISMethods.GetPipelineForFilter(filter))
            if (tempPipeline["$match"]["$and"].length) pipeline.push(tempPipeline)

            //Global Search
            if (searchtext !== "") {
                pipeline.push(...IISMethods.GetGlobalSearchFilter(new PropertyFloor(), searchtext))
            }

            const resp = await MainDB.getmenual("tblpropertyfloor", new PropertyFloor(), pipeline, requiredPage, sortData, fieldorder, "", projection)

            ResponseBody.pagename = "floor"
            ResponseBody.formname = "floor"
            ResponseBody.fltpagecollection = "propertyfloor"
            ResponseBody.status = 200
            ResponseBody.message = Config.getResponsestatuscode()["200"]
            ResponseBody.data = resp.ResultData
            ResponseBody.fieldorder = resp.fieldorderdata
            ResponseBody.currentpage = resp.currentpage
            ResponseBody.nextpage = resp.nextpage
            ResponseBody.formfieldorderdata = resp.formfieldorderdata

            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

    //Add Floor
    async AddFloor(req, res, next) {
        try {
            const ResponseBody = {}
            const ObjectId = IISMethods.getobjectid()

            const floorPipeline = {
                propertyid: ObjectId(req.body.propertyid),
                wingid: ObjectId(req.body.wingid),
                floor: req.body.floor
            }
            const findFloorPromise = MainDB.FindOne("tblpropertyfloor", new PropertyFloor(), floorPipeline)

            const propertyPipeline = [{ $match: { _id: ObjectId(req.body.propertyid) } }]
            const getPropertyPromise = MainDB.getmenual(TableName, new Propertycommon(), propertyPipeline)

            const buildingPipeline = [{ $match: { _id: ObjectId(req.body.wingid) } }]
            const getBuildingPromise = MainDB.getmenual("tblpropertywing", new PropertyWing(), buildingPipeline)

            const [floor, property, building] = await Promise.all([findFloorPromise, getPropertyPromise, getBuildingPromise])

            if (!floor) {
                if (property.ResultData.length) {
                    if (building.ResultData.length) {
                        let floor = req.body
                        if (floor.floorplan) {
                            // const imagefile = IISMethods.getfilepath(req.headers.subdomainname, "imagefile")
                            // floor.floorplan = await IISMethods.uploadToS3(floor.floorplan, imagefile)
                        }
                        const floorResp = await MainDB.executedata("i", new PropertyFloor(), "tblpropertyfloor", floor)

                        if (floorResp.status == 200) {
                            // Change in tblpropertywing
                            const wingUpdatePipeline = [{ _id: req.body.wingid }, { $inc: { floorcount: 1 } }]

                            await Promise.all([
                                MainDB.Update("tblpropertywing", new PropertyWing(), wingUpdatePipeline)
                            ])
                        }

                        ResponseBody.status = floorResp.status
                        ResponseBody.message = floorResp.message

                    } else {
                        ResponseBody.status = 404
                        ResponseBody.message = Config.getErrmsg()["nodatafound"]
                    }
                } else {
                    ResponseBody.status = 404
                    ResponseBody.message = Config.getErrmsg()["nodatafound"]
                }
            } else {
                ResponseBody.status = 404
                ResponseBody.message = Config.getErrmsg()["isexist"]
            }

            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

    //Update floor
    async UpdateFloor(req, res, next) {
        try {
            const ResponseBody = {}
            ResponseBody.status = 401
            ResponseBody.message = Config.getResponsestatuscode()["401"]

            const ObjectId = IISMethods.getobjectid()
            const pipelinedata = [{ $match: { _id: ObjectId(req.body._id) } }]
            const record = await MainDB.getmenual("tblpropertyfloor", new PropertyFloor(), pipelinedata)
            if (record.ResultData.length > 0) {
                var RecordInfo = record.ResultData[0].recordinfo
                RecordInfo.updateuid = req.headers.uid
                RecordInfo.updateby = req.headers.personname
                RecordInfo.updatedate = IISMethods.getdatetimestr()

                let Property = req.body
                Property.recordinfo = RecordInfo
                Property.areacount = record.ResultData[0].areacount

                //exist condition for update floor dependency
                const dependancyPipeline = {
                    propertyid: ObjectId(req.body.propertyid),
                    wingid: ObjectId(req.body.wingid),
                    floor: req.body.floor,
                    _id: { $ne: ObjectId(req.body._id) }
                }

                const checkresp = await MainDB.FindOne("tblpropertyfloor", new PropertyFloor(), dependancyPipeline)

                if (!checkresp) {
                    const resp = await MainDB.executedata("u", new PropertyFloor(), "tblpropertyfloor", Property)


                    // Change in tblpropertyarea
                    if (record.ResultData[0].isactive !== req.body.isactive) {
                        if (req.body.isactive === 1) {
                            const newBuildingUpdatePipeline = [{ _id: record.ResultData[0].wingid }, { $inc: { floorcount: 1, areacount: record.ResultData[0].areacount } }]  // 

                            await Promise.all([
                                MainDB.Update("tblpropertywing", new PropertyWing(), newBuildingUpdatePipeline),
                            ])
                        } else {
                            const newBuildingUpdatePipeline = [{ _id: record.ResultData[0].wingid }, { $inc: { floorcount: -1, areacount: -record.ResultData[0].areacount } }]  // 

                            await Promise.all([
                                MainDB.Update("tblpropertywing", new PropertyWing(), newBuildingUpdatePipeline),
                            ])
                        }
                    }
                    let updatePipeline = [
                        { floorid: req.body._id },
                        {
                            $set: {
                                wingid: ObjectId(req.body.wingid),
                                wingname: req.body.wingname,
                                floor: req.body.floor
                            }
                        }
                    ]
                    const updateModelObj = {
                        tblpropertyunit: new PropertyUnit(),
                        tblpropertyarea: new PropertyArea(),
                        tblemployee: new _Employee(),
                        tblcustomer: new _Customer(),
                        tblgatekeeper: new _Gatekeeper()
                    }
                    const tempArray = []
                    for (const key in updateModelObj) {
                        if ( key == "tblcustomer") {
                            updatePipeline = [
                                { 'ownedproperties.propertyid': ObjectId(req.body.propertyid), 'ownedproperties.floorid': ObjectId(req.body._id) },
                                {
                                    $set: {
                                        'ownedproperties.$.floor': req.body.floor
                                    }
                                }
                            ]
                        }
                        tempArray.push(MainDB.UpdateMany(key, updateModelObj[key], updatePipeline))
                    }
                    await Promise.all(tempArray)

                    ResponseBody.data = resp.data
                    ResponseBody.status = resp.status
                    ResponseBody.message = resp.message
                } else {
                    ResponseBody.status = 400
                    ResponseBody.message = Config.getErrmsg()["isexist"]
                }
            }

            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

    //Delete floor
    async DeleteFloor(req, res, next) {
        try {
            const ResponseBody = {}
            ResponseBody.status = 401
            ResponseBody.message = Config.getResponsestatuscode()["401"]

            const ObjectId = IISMethods.getobjectid()
            const floorPipeline = { _id: ObjectId(req.body._id) }
            const floorRes = await MainDB.FindOne("tblpropertyfloor", new PropertyFloor(), floorPipeline)

            //Delete Dependency
            const dependencyObj = {
                tblpropertyunit: new PropertyUnit(),
                tblpropertyarea: new PropertyArea(),
                tblcustomer: new _Customer(),
                //	tblpropertyroomconfiguration: new PropertyRoomConfiguration(),
            }

            // Dependency Array
            const dependency = []
            for (const key in dependencyObj) {
                const ObjModel = await MainDB.createmodel(key, dependencyObj[key])

                if(key == "tblcustomer"){
                    dependency.push([ObjModel["objModel"], { "ownedproperties.floorid": req.body._id }, Config.apipagename[key]]) 
                }else{
                    dependency.push([ObjModel["objModel"], { floorid: req.body._id }, Config.apipagename[key]])
                }
            }

            //Delete
            const resp = await MainDB.executedata("d", new PropertyFloor(), "tblpropertyfloor", req.body, true, dependency)

            //Manage area count
            if (floorRes && resp.status == 200 && floorRes.isactive == 1) {
                // Change in tblpropertywing
                const buildingUpdatePipeline = [{ _id: floorRes.wingid }, { $inc: { floorcount: -1 } }]
                const updateBuildingPromise = MainDB.Update("tblpropertywing", new PropertyWing(), buildingUpdatePipeline)

                await Promise.all([updateBuildingPromise])
            }

            ResponseBody.status = resp.status
            ResponseBody.message = resp.message
            ResponseBody.existdataPagename = resp.existdataPagename

            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }


    //List unit
    async ListUnit(req, res, next) {
        try {
            const ResponseBody = {}
            // ResponseBody.status = 401
            // ResponseBody.message = Config.getResponsestatuscode()["401"]

            let pipeline = []
            const ObjectId = IISMethods.getobjectid()

            const {
                searchtext = "",
                paginationinfo: { pageno = 1, pagelimit = 20, filter = {}, nextpageid = "", sort = {}, projection = {} }
            } = req.body || {}

            const requiredPage = {
                nextpageid: nextpageid,
                pageno: pageno,
                skip: (pageno - 1) * pagelimit,
                pagelimit: pagelimit
            }

            const sortData = Object.keys(sort).length !== 0 ? sort : { _id: -1 }
            let fieldorder = req.body.paginationinfo?.isfieldorder ? req.body.paginationinfo.isfieldorder : 0


            const { floorid = [], wingid = [], unitid = [] } = filter

            if (Array.isArray(wingid)) {
                delete filter.wingid
            }
            if (Array.isArray(floorid)) {
                delete filter.floorid
            }


            let tempPipeline = { $match: { $and: [] } }
            if (Array.isArray(wingid) && wingid.length) {
                tempPipeline["$match"]["$and"].push({ wingid: { $in: wingid.map((id) => ObjectId(id)) } })
            }
            if (Array.isArray(floorid) && floorid.length) {
                tempPipeline["$match"]["$and"].push({ floorid: { $in: floorid.map((id) => ObjectId(id)) } })
            }


            pipeline = pipeline.concat(IISMethods.GetPipelineForFilter(filter))
            if (searchtext !== "") {
                pipeline.push(...IISMethods.GetGlobalSearchFilter(new PropertyArea(), searchtext))
            }
            if (tempPipeline["$match"]["$and"].length) pipeline.push(tempPipeline)


            const resp = await MainDB.getmenual("tblpropertyunit", new PropertyUnit(), pipeline, requiredPage, sortData, fieldorder, "", projection)

            const areatypeResp = await MainDB.getmenual("tblareatypemaster", new AreaType(), [{ $match: {} }])
            const areatypeData = areatypeResp?.ResultData


            ResponseBody.pagename = "unit"
            ResponseBody.formname = "unit"
            ResponseBody.fltpagecollection = "propertyunit"
            ResponseBody.status = 200
            ResponseBody.message = Config.getResponsestatuscode()["200"]
            ResponseBody.data = resp.ResultData
            ResponseBody.currentpage = resp.currentpage
            ResponseBody.nextpage = resp.nextpage
            ResponseBody.formfieldorderdata = resp.formfieldorderdata

            const Property = new PropertyArea()
            if (resp.fieldorderdata) {
                ResponseBody.fieldorder = resp.fieldorderdata
            } else {
                ResponseBody.fieldorder = Property.getFieldOrder()
            }

            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

    async ListavaliableUnit(req, res, next) {
        try {
            const ResponseBody = {}
            // ResponseBody.status = 401
            // ResponseBody.message = Config.getResponsestatuscode()["401"]

            let pipeline = []
            const ObjectId = IISMethods.getobjectid()

            const {
                searchtext = "",
                paginationinfo: { pageno = 1, pagelimit = 20, filter = {}, nextpageid = "", sort = {}, projection = {} }
            } = req.body || {}

            const requiredPage = {
                nextpageid: nextpageid,
                pageno: pageno,
                skip: (pageno - 1) * pagelimit,
                pagelimit: pagelimit
            }

            const sortData = Object.keys(sort).length !== 0 ? sort : { _id: -1 }
            let fieldorder = req.body.paginationinfo?.isfieldorder ? req.body.paginationinfo.isfieldorder : 0

            const { floorid = [], wingid = [], unitid = [] } = filter

            if (Array.isArray(wingid)) {
                delete filter.wingid
            }
            if (Array.isArray(floorid)) {
                delete filter.floorid
            }

            const CustomerPipeline = [{ $match: { "ownedproperties.floorid": ObjectId(req.body.paginationinfo?.filter?.floorid) } }]
            const customerResp = await MainDB.getmenual("tblcustomer", new _Customer(), CustomerPipeline)

            const unitids = customerResp.ResultData.flatMap(doc =>doc.ownedproperties.map(m => m.unitid))
            pipeline.push({ $match: { _id: { $ne: unitids } } })

            const resp = await MainDB.getmenual("tblpropertyunit", new PropertyUnit(), pipeline, requiredPage, sortData, fieldorder, "", projection)

            ResponseBody.pagename = "unit"
            ResponseBody.formname = "unit"
            ResponseBody.fltpagecollection = "propertyunit"
            ResponseBody.status = 200
            ResponseBody.message = Config.getResponsestatuscode()["200"]
            ResponseBody.data = resp.ResultData
            ResponseBody.currentpage = resp.currentpage
            ResponseBody.nextpage = resp.nextpage

            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }


    //Add Floor
    async AddUnit(req, res, next) {
        try {
            const ResponseBody = {}
            const ObjectId = IISMethods.getobjectid()

            const unitPipeline = {
                propertyid: ObjectId(req.body.propertyid),
                wingid: ObjectId(req.body.wingid),
                floorid: ObjectId(req.body.floorid),
                unitname: req.body.unitname
            }
            const findUnitPromise = MainDB.FindOne("tblpropertyunit", new PropertyUnit(), unitPipeline)

            const propertyPipeline = [{ $match: { _id: ObjectId(req.body.propertyid) } }]
            const getPropertyPromise = MainDB.getmenual(TableName, new Propertycommon(), propertyPipeline)

            const buildingPipeline = [{ $match: { _id: ObjectId(req.body.wingid) } }]
            const getBuildingPromise = MainDB.getmenual("tblpropertywing", new PropertyWing(), buildingPipeline)

            const floorPipeline = [{ $match: { _id: ObjectId(req.body.floorid) } }]
            const getfloorPromise = MainDB.getmenual("tblpropertyfloor", new PropertyFloor(), floorPipeline)

            const [unit, property, wing, floor] = await Promise.all([findUnitPromise, getPropertyPromise, getBuildingPromise, getfloorPromise])

            if (!unit) {
                if (property.ResultData.length) {
                    if (wing.ResultData.length) {
                        if (floor.ResultData.length) {
                            let unit = req.body
                            const unitResp = await MainDB.executedata("i", new PropertyUnit(), "tblpropertyunit", unit)


                            if (unitResp.status == 200) {
                                // Change in tblpropertytower
                                const wingUpdatePipeline = [{ _id: req.body.towerid }, { $inc: { unitcount: 1 } }]
                                const floorUpdatePipeline = [{ _id: req.body.floorid }, { $inc: { floorcount: 1 } }]
                                // await MainDB.Update("tblpropertytower", new PropertyTower(), buildingUpdatePipeline)

                                await Promise.all([
                                    MainDB.Update("tblpropertywing", new PropertyWing(), wingUpdatePipeline),
                                    MainDB.Update("tblpropertyfloor", new PropertyFloor(), floorUpdatePipeline)
                                ])
                            }

                            ResponseBody.status = unitResp.status
                            ResponseBody.message = unitResp.message

                        } else {
                            ResponseBody.status = 404
                            ResponseBody.message = Config.getErrmsg()["nodatafound"]
                        }
                    } else {
                        ResponseBody.status = 404
                        ResponseBody.message = Config.getErrmsg()["nodatafound"]
                    }
                } else {
                    ResponseBody.status = 404
                    ResponseBody.message = Config.getErrmsg()["nodatafound"]
                }
            } else {
                ResponseBody.status = 404
                ResponseBody.message = Config.getErrmsg()["isexist"]
            }

            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

    //Update floor
    async UpdateUnit(req, res, next) {
        try {
            const ResponseBody = {}
            ResponseBody.status = 401
            ResponseBody.message = Config.getResponsestatuscode()["401"]

            const ObjectId = IISMethods.getobjectid()
            const pipelinedata = [{ $match: { _id: ObjectId(req.body._id) } }]
            const record = await MainDB.getmenual("tblpropertyunit", new PropertyUnit(), pipelinedata)
            if (record.ResultData.length > 0) {
                var RecordInfo = record.ResultData[0].recordinfo
                RecordInfo.updateuid = req.headers.uid
                RecordInfo.updateby = req.headers.personname
                RecordInfo.updatedate = IISMethods.getdatetimestr()

                let Property = req.body
                Property.recordinfo = RecordInfo
                Property.areacount = record.ResultData[0].areacount
                //exist condition for update floor dependency

                const dependancyPipeline = {
                    propertyid: ObjectId(req.body.propertyid),
                    wingid: ObjectId(req.body.wingid),
                    floorid: ObjectId(req.body.floorid),
                    unitname: req.body.unitname,
                    _id: { $ne: ObjectId(req.body._id) }
                }

                const checkresp = await MainDB.FindOne("tblpropertyunit", new PropertyUnit(), dependancyPipeline)

                if (!checkresp) {
                    const resp = await MainDB.executedata("u", new PropertyUnit(), "tblpropertyunit", Property)

                    // if (resp.data.floorplan !== "") {
                    // 	resp.data.floorplan = IISMethods.getImageUrl(resp.data.floorplan)
                    // }


                    // Change in tblpropertyarea
                    if (record.ResultData[0].isactive !== req.body.isactive) {
                        if (req.body.isactive === 1) {
                            const wingUpdatePipeline = [{ _id: record.ResultData[0].wingid }, { $inc: { unitcount: 1, areacount: record.ResultData[0].areacount } }]  // 
                            const floorUpdatePipeline = [{ _id: record.ResultData[0].floorid }, { $inc: { unitcount: 1, areacount: record.ResultData[0].areacount } }]

                            await Promise.all([
                                MainDB.Update("tblpropertywing", new PropertyWing(), wingUpdatePipeline),
                                MainDB.Update("tblpropertyfloor", new PropertyFloor(), floorUpdatePipeline),
                            ])
                        } else {
                            const wingUpdatePipeline = [{ _id: record.ResultData[0].wingid }, { $inc: { unitcount: -1, areacount: -record.ResultData[0].areacount } }]  // 
                            const floorUpdatePipeline = [{ _id: record.ResultData[0].floorid }, { $inc: { unitcount: -1, areacount: -record.ResultData[0].areacount } }]  // 

                            await Promise.all([
                                MainDB.Update("tblpropertywing", new PropertyWing(), wingUpdatePipeline),
                                MainDB.Update("tblpropertyfloor", new PropertyFloor(), floorUpdatePipeline),
                            ])
                        }
                    }
                    let updatePipeline = [
                        { unitid: req.body._id },
                        {
                            $set: {
                                unitname: req.body.unitname
                            }
                        }
                    ]
                    const updateModelObj = {
                        tblpropertyarea: new PropertyArea(),
                        tblemployee: new _Employee(),
                        tblcustomer: new _Customer(),
                        tblgatekeeper: new _Gatekeeper()
                    }
                    const tempArray = []
                    for (const key in updateModelObj) {

                        if (key == "tblcustomer") {
                            updatePipeline = [
                                { 'ownedproperties.propertyid': ObjectId(req.body.propertyid), 'ownedproperties.unitid': ObjectId(req.body._id) },
                                {
                                    $set: {
                                        'ownedproperties.$.unit': req.body.unitname
                                    }
                                }
                            ]
                        }
                        tempArray.push(MainDB.UpdateMany(key, updateModelObj[key], updatePipeline))
                    }
                    await Promise.all(tempArray)

                    ResponseBody.data = resp.data
                    ResponseBody.status = resp.status
                    ResponseBody.message = resp.message
                } else {
                    ResponseBody.status = 400
                    ResponseBody.message = Config.getErrmsg()["isexist"]
                }
            }

            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

    //Delete unit
    async DeleteUnit(req, res, next) {
        try {
            const ResponseBody = {}
            ResponseBody.status = 401
            ResponseBody.message = Config.getResponsestatuscode()["401"]

            const ObjectId = IISMethods.getobjectid()
            const unitPipeline = { _id: ObjectId(req.body._id) }
            const unitRes = await MainDB.FindOne("tblpropertyunit", new PropertyUnit(), unitPipeline)

            //Delete Dependency
            const dependencyObj = {
                tblpropertyarea: new PropertyArea(),
                tblcustomer: new _Customer()
                //	tblpropertyroomconfiguration: new PropertyRoomConfiguration(),
            }

            // Dependency Array
            const dependency = []
            for (const key in dependencyObj) {
                const ObjModel = await MainDB.createmodel(key, dependencyObj[key])
                if (key == "tblcustomer") {
                    dependency.push([ObjModel["objModel"], { 'ownedproperties.unitid': req.body._id }, "Customer"])
                } else {
                    dependency.push([ObjModel["objModel"], { unitid: req.body._id }, Config.apipagename[key]])
                }
            }

            //Delete
            const resp = await MainDB.executedata("d", new PropertyUnit(), "tblpropertyunit", req.body, true, dependency)

            // Manage area count
            if (unitRes && resp.status == 200 && unitRes.isactive == 1) {
                // Change in tblpropertywing
                const unitUpdatePipeline = [{ _id: unitRes.wingid }, { $inc: { unitcount: -1 } }]
                const updateUnitPromise = MainDB.Update("tblpropertywing", new PropertyWing(), unitUpdatePipeline)

                const floorUpdatePipeline = [{ _id: unitRes.floorid }, { $inc: { unitcount: -1 } }]
                const updateFloorPromise = MainDB.Update("tblpropertyfloor", new PropertyFloor(), floorUpdatePipeline)

                await Promise.all([updateUnitPromise, updateFloorPromise])
            }

            ResponseBody.status = resp.status
            ResponseBody.message = resp.message
            ResponseBody.existdataPagename = resp.existdataPagename

            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

    //List Area
    async ListArea(req, res, next) {
        try {
            const ResponseBody = {}

            let pipeline = []
            const ObjectId = IISMethods.getobjectid()

            const {
                searchtext = "",
                paginationinfo: { pageno = 1, pagelimit = 20, filter = {}, nextpageid = "", sort = {}, projection = {} }
            } = req.body || {}
            let fieldorder = req.body.paginationinfo?.isfieldorder ? req.body.paginationinfo?.isfieldorder : 0

            const requiredPage = {
                nextpageid: nextpageid,
                pageno: pageno,
                skip: (pageno - 1) * pagelimit,
                pagelimit: pagelimit
            }

            const sortData = Object.keys(sort).length !== 0 ? sort : { _id: -1 }

            const { wingid = [], floorid = [] } = filter

            if (Array.isArray(wingid)) {
                delete filter.wingid
            }
            if (Array.isArray(floorid)) {
                delete filter.floorid
            }

            let tempPipeline = { $match: { $and: [] } }
            if (Array.isArray(wingid) && wingid.length) {
                tempPipeline["$match"]["$and"].push({ wingid: { $in: wingid.map((id) => ObjectId(id)) } })
            }
            if (Array.isArray(floorid) && floorid.length) {
                tempPipeline["$match"]["$and"].push({ floorid: { $in: floorid.map((id) => ObjectId(id)) } })
            }


            pipeline = pipeline.concat(IISMethods.GetPipelineForFilter(filter))
            if (searchtext !== "") {
                pipeline.push(...IISMethods.GetGlobalSearchFilter(new PropertyArea(), searchtext))
            }
            if (tempPipeline["$match"]["$and"].length) pipeline.push(tempPipeline)

            if (req.headers.propertyid) {
                pipeline.push({ $match: { propertyid: ObjectId(req.headers.propertyid) } })
            }

            const resp = await MainDB.getmenual("tblpropertyarea", new PropertyArea(), pipeline, requiredPage, sortData, fieldorder, "", projection)

            ResponseBody.pagename = "Area"
            ResponseBody.formname = "Area"
            ResponseBody.fltpagecollection = "propertyarea"
            ResponseBody.status = 200
            ResponseBody.message = Config.getResponsestatuscode()["200"]
            ResponseBody.data = resp.ResultData
            ResponseBody.currentpage = resp.currentpage
            ResponseBody.nextpage = resp.nextpage
            ResponseBody.formfieldorderdata = resp.formfieldorderdata

            const Property = new PropertyArea()
            if (resp.fieldorderdata) {
                ResponseBody.fieldorder = resp.fieldorderdata
            } else {
                ResponseBody.fieldorder = Property.getFieldOrder()
            }

            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

    //Add Area
    async AddArea(req, res, next) {
        try {
            const ResponseBody = {}
            ResponseBody.status = 401
            ResponseBody.message = Config.getResponsestatuscode()["401"]

            const ObjectId = IISMethods.getobjectid()
            const pipelinedata = [{ $match: { _id: ObjectId(req.body.propertyid) } }]

            const areaPipeline = {
                propertyid: ObjectId(req.body.propertyid),
                // wingid: ObjectId(req.body.wingid),
                // wingid: ObjectId(req.body.wingid),
                // floorid: ObjectId(req.body.floorid),
                area: req.body.area
            }

            const [record, area, areatype] = await Promise.all([
                MainDB.getmenual(TableName, new Propertycommon(), pipelinedata),
                MainDB.FindOne("tblpropertyarea", new PropertyArea(), areaPipeline),
                MainDB.FindOne("tblareatypemaster", new AreaType(), { _id: req.body.areatypeid })
            ])

            if (record.ResultData.length > 0) {
                if (!area) {
                    let Property = req.body;

                    Property.subcategoryid = ObjectId(Config.dummyObjid)
                    Property.subcategory = "No Service Available"
                    Property.subcategorycolor = Config.dummycolor
                    Property.type = areatype?.type


                    const [resp] = await Promise.all([
                        MainDB.executedata("i", new PropertyArea(), "tblpropertyarea", Property),
                    ])

                    ResponseBody.status = resp.status
                    ResponseBody.message = resp.message
                } else {
                    ResponseBody.status = 400
                    ResponseBody.message = Config.getErrmsg()["isexist"]
                }
            } else {
                ResponseBody.status = 400
                ResponseBody.message = Config.getErrmsg()["propertynotfound"]
            }

            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

    //Update Area
    async UpdateArea(req, res, next) {
        try {
            const ResponseBody = {}
            const ObjectId = IISMethods.getobjectid()

            ResponseBody.status = 401
            ResponseBody.message = Config.getResponsestatuscode()["401"]

            const pipelinedata = [{ $match: { _id: ObjectId(req.body._id) } }]
            const record = await MainDB.getmenual("tblpropertyarea", new PropertyArea(), pipelinedata)

            const areaPipeline = {
                propertyid: req.body.propertyid,
                wingid: req.body.wingid,
                floorid: req.body.floorid,
                area: req.body.area,
                _id: { $ne: req.body._id }
            }
            const area = await MainDB.FindOne("tblpropertyarea", new PropertyArea(), areaPipeline)

            if (record.ResultData.length) {
                if (!area) {
                    let Property = req.body

                    const RecordInfo = record.ResultData[0].recordinfo
                    RecordInfo.updateuid = req.headers.uid
                    RecordInfo.updateby = req.headers.personname
                    RecordInfo.updatedate = IISMethods.getdatetimestr()
                    req.body.recordinfo = RecordInfo


                    const resp = await MainDB.executedata("u", new PropertyArea(), "tblpropertyarea", Property)

                    // if (record.ResultData[0].isactive !== req.body.isactive) {
                    //     if (req.body.isactive === 1) {
                    //         const newBuildingUpdatePipeline = [{ _id: record.ResultData[0].wingid }, { $inc: { areacount: 1 } }]
                    //         const newFloorUpdatePipeline = [{ _id: record.ResultData[0].floorid }, { $inc: { areacount: 1 } }]

                    //         await Promise.all([
                    //             MainDB.Update("tblpropertywing", new PropertyWing(), newBuildingUpdatePipeline),
                    //             MainDB.Update("tblpropertyfloor", new PropertyFloor(), newFloorUpdatePipeline)
                    //         ])
                    //     } else {
                    //         const newBuildingUpdatePipeline = [{ _id: record.ResultData[0].wingid }, { $inc: { areacount: -1 } }]
                    //         const newFloorUpdatePipeline = [{ _id: record.ResultData[0].floorid }, { $inc: { areacount: -1 } }]

                    //         await Promise.all([
                    //             MainDB.Update("tblpropertywing", new PropertyWing(), newBuildingUpdatePipeline),
                    //             MainDB.Update("tblpropertyfloor", new PropertyFloor(), newFloorUpdatePipeline),
                    //         ])
                    //     }
                    // }


                    ResponseBody.data = resp.data
                    ResponseBody.status = resp.status
                    ResponseBody.message = resp.message
                } else {
                    ResponseBody.status = 400
                    ResponseBody.message = Config.getErrmsg()["isexist"]
                }
            }

            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

    //Delete Area
    async DeleteArea(req, res, next) {
        try {
            const ResponseBody = {}
            ResponseBody.status = 401
            ResponseBody.message = Config.getResponsestatuscode()["401"]

            const floorPipeline = { _id: req.body._id }
            const areaRes = await MainDB.FindOne("tblpropertyarea", new PropertyArea(), floorPipeline)

            //Delete
            const resp = await MainDB.executedata("d", new PropertyArea(), "tblpropertyarea", req.body)

            //Manage area count
            // if (areaRes && resp.status == 200 && areaRes.isactive == 1) {
            //     // Change in tblpropertywing
            //     const buildingUpdatePipeline = [{ _id: areaRes.wingid }, { $inc: { areacount: -1 } }]
            //     await MainDB.Update("tblpropertywing", new PropertyWing(), buildingUpdatePipeline)

            //     // Change in tblpropertyfloor
            //     const floorUpdatePipeline = [{ _id: areaRes.floorid }, { $inc: { areacount: -1 } }]
            //     await MainDB.Update("tblpropertyfloor", new PropertyFloor(), floorUpdatePipeline)
            // }

            ResponseBody.status = resp.status
            ResponseBody.message = resp.message
            ResponseBody.existdataPagename = resp.existdataPagename

            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }




    //List Facility
    async ListFacility(req, res, next) {
        try {
            const ResponseBody = {}

            let pipeline = []
            const ObjectId = IISMethods.getobjectid()

            const {
                searchtext = "",
                paginationinfo: { pageno = 1, pagelimit = 20, filter = {}, nextpageid = "", sort = {}, projection = {} }
            } = req.body || {}

            const requiredPage = {
                nextpageid: nextpageid,
                pageno: pageno,
                skip: (pageno - 1) * pagelimit,
                pagelimit: pagelimit
            }

            const sortData = Object.keys(sort).length !== 0 ? sort : { _id: -1 }

            if(req.headers.propertyid){
                pipeline.push({$match:{propertyid:ObjectId(req.headers.propertyid)}})
            }

            pipeline = pipeline.concat(IISMethods.GetPipelineForFilter(filter))
            if (searchtext !== "") {
                pipeline.push(...IISMethods.GetGlobalSearchFilter(new PropertyFacility(), searchtext))
            }

            const resp = await MainDB.getmenual("tblpropertyfacility", new PropertyFacility(), pipeline, requiredPage, sortData, true, "", projection)

            const ratingPipeline = [
                { $match: { 'propertyid': ObjectId(req.headers.propertyid) } },
                {
                    $group: {
                        _id: '$facilityid',
                        averageRating: { $avg: '$rating' }
                    }
                }
            ];
            const ratingResp = await MainDB.getmenual("tblfacilityrating", new _FacilityRating(), ratingPipeline);

            const ratingMap = ratingResp.ResultData.reduce((map, item) => {
                map[item._id.toString()] = item.averageRating
                return map
            }, {})

            for (const obj of resp.ResultData) {
                const averageRating = ratingMap[obj._id.toString()] || 0;
                obj.averageRating = parseFloat(averageRating).toFixed(2)
            }

            ResponseBody.pagename = "Facility"
            ResponseBody.formname = "Facility"
            ResponseBody.fltpagecollection = "Facility"
            ResponseBody.status = 200
            ResponseBody.message = Config.getResponsestatuscode()["200"]
            ResponseBody.data = resp.ResultData
            ResponseBody.currentpage = resp.currentpage
            ResponseBody.nextpage = resp.nextpage
            ResponseBody.formfieldorderdata = resp.formfieldorderdata

            const Property = new PropertyArea()
            if (resp.fieldorderdata) {
                ResponseBody.fieldorder = resp.fieldorderdata
            } else {
                ResponseBody.fieldorder = Property.getFieldOrder()
            }

            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

    //Add facility
    async AddFacility(req, res, next) {
        try {
            const ResponseBody = {}

            req.body.propertyid = req.headers.propertyid
            req.body.property = req.headers.property

            if (req.body.timeslot && req.body.timeslot.length) {

                //Filtering Out Booked Timestamps
                const timeslotArray = req.body.timeslot
                let isOverlap = false;

                for (let i = 0; i < timeslotArray.length - 1; i++) {
                    for (let j = i + 1; j < timeslotArray.length; j++) {
                        const startTime1 = new Date(timeslotArray[i].starttime)
                        const endTime1 = new Date(timeslotArray[i].endtime)
                        const startTime2 = new Date(timeslotArray[j].starttime)
                        const endTime2 = new Date(timeslotArray[j].endtime)

                        if (IISMethods.isTimeRangeOverlapping(startTime1, endTime1, startTime2, endTime2)) {
                            // Check if there is an overlap between timeslot i and timeslot j
                            isOverlap = true
                            break
                        }
                    }
                    if (isOverlap) break;
                }

                if (isOverlap) {
                    ResponseBody.status = 400
                    ResponseBody.message = Config.getErrmsg()["timeslotoverlap"]
                    
                    req.ResponseBody = ResponseBody
                    return next()
                }
            } 
            const resp = await MainDB.executedata("i", new PropertyFacility(), "tblpropertyfacility", req.body)

            ResponseBody.status = resp.status
            ResponseBody.message = resp.message
            

            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

    //Update facility
    async UpdateFacility(req, res, next) {
        try {
            
            const ResponseBody = {}
            const ObjectId = IISMethods.getobjectid()

            ResponseBody.status = 401
            ResponseBody.message = Config.getResponsestatuscode()["401"]

            const pipelinedata = [{ $match: { _id: ObjectId(req.body._id) } }]
            const record = await MainDB.getmenual("tblpropertyfacility", new PropertyFacility(), pipelinedata)

            if (record.ResultData.length) {

                const RecordInfo = record.ResultData[0].recordinfo
                RecordInfo.updateuid = req.headers.uid
                RecordInfo.updateby = req.headers.personname
                RecordInfo.updatedate = IISMethods.getdatetimestr()
                req.body.recordinfo = RecordInfo
                req.body.disableslot = record.ResultData[0].disableslot

                //for disable slot 1 is added disable slot and 2 is remove diable slot 
                if (req.body.hasOwnProperty('isdisableslot') && (req.body.isdisableslot == 1 || req.body.isdisableslot == 0)) {

                    const disableslot = req.body.manageslot   

                    const SlotCondition = disableslot?.map(slot => ({ "slot.starttime": { $lt: new Date(slot.endtime) }, "slot.endtime": { $gt: new Date(slot.starttime) } }))

                    const bookingpipeline = [
                        {
                            $match: {
                                facilityid: ObjectId(req.body.facilityid)
                            }
                        },
                        {
                            $unwind: "$slot"
                        },
                        {
                            $match: {
                                $or: SlotCondition
                            }
                        }
                    ]
                    const bookingResp = await MainDB.getmenual("tblfacilitybooking", new _FacilityBooking(), bookingpipeline)

                    // ResponseBody.pipeline = bookingpipeline

                    if (!bookingResp.ResultData?.length) {
                        if (req.body.hasOwnProperty('isdisableslot') && req.body.isdisableslot == 1) {
                            req.body.disableslot?.push(...disableslot)
                        } else if (req.body.hasOwnProperty('isdisableslot') && req.body.isdisableslot == 0) {
                            const currentslot = record.ResultData[0].disableslot
                            const enableSlot = currentslot?.filter(slot => !disableslot?.some(disable => disable.starttime == slot.starttime && disable.endtime == slot.endtime))
                            req.body.disableslot = enableSlot
                        }
                    } else {
                        ResponseBody.status = 400
                        ResponseBody.message = Config.errmsg['alreadybooked']
                        ResponseBody.data = bookingResp.ResultData

                        req.ResponseBody = ResponseBody
                        return next()
                    }
                }
            }

            const resp = await MainDB.executedata("u", new PropertyFacility(), "tblpropertyfacility", req.body)

            ResponseBody.data = resp.data
            ResponseBody.status = resp.status
            ResponseBody.message = resp.message

            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

    //Delete Facility
    async DeleteFacility(req, res, next) {
        try {
            const ResponseBody = {}
            ResponseBody.status = 401
            ResponseBody.message = Config.getResponsestatuscode()["401"]

            //Delete
            const resp = await MainDB.executedata("d", new PropertyFacility(), "tblpropertyfacility", req.body)

            ResponseBody.status = resp.status
            ResponseBody.message = resp.message

            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }



    //gate
    async ListGate(req, res, next) {
        try {
            const ResponseBody = {}

            let pipeline = []

            const {
                searchtext = "",
                paginationinfo: { nextpageid = "", pageno = 1, pagelimit = 20, filter = {}, sort = {}, projection = {} }
            } = req.body || {}

            const requiredPage = {
                nextpageid: nextpageid,
                pageno: pageno,
                skip: (pageno - 1) * pagelimit,
                pagelimit: pagelimit
            }

            const sortData = Object.keys(sort).length !== 0 ? sort : { _id: -1 }


            if (Object.keys(filter).length) {
                pipeline = pipeline.concat(IISMethods.GetPipelineForFilter(filter))
            }
            if (searchtext !== "") {
                pipeline.push(...IISMethods.GetGlobalSearchFilter(new PropertyGate(), searchtext))
            }
            const resp = await MainDB.getmenual("tblpropertygate", new PropertyGate(), pipeline, requiredPage, sortData, true, "", projection)

            ResponseBody.pagename = "gate"
            ResponseBody.formname = "Gate"
            ResponseBody.fltpagecollection = "propertybuilding gate"
            ResponseBody.status = 200
            ResponseBody.message = Config.getResponsestatuscode()["200"]
            ResponseBody.data = resp.ResultData
            ResponseBody.fieldorder = resp.fieldorderdata
            ResponseBody.currentpage = resp.currentpage
            ResponseBody.nextpage = resp.nextpage
            ResponseBody.formfieldorderdata = resp.formfieldorderdata

            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

    //Add gate
    async AddGate(req, res, next) {
        try {
            const ResponseBody = {}

            const ObjectId = IISMethods.getobjectid()
            const pipelinedata = [{ $match: { _id: ObjectId(req.body.propertyid) } }]
            const record = await MainDB.getmenual(TableName, new Propertycommon(), pipelinedata)

            // get count of building
            if (record.ResultData.length > 0) {
                let gateid = new ObjectId()
                req.body._id = ObjectId(gateid)
                let gateobj = req.body

                const dependancyPipeline = { propertyid: ObjectId(req.body.propertyid), gateno: req.body.gateno }
                const checkresp = await MainDB.FindOne("tblpropertygate", new PropertyGate(), dependancyPipeline)

                if (!checkresp) {
                    const resp = await MainDB.executedata("i", new PropertyGate(), "tblpropertygate", gateobj)
                    if (resp.status == 200) {

                        ResponseBody.status = resp.status
                        ResponseBody.message = resp.message
                        ResponseBody.data = resp.data
                    }
                } else {
                    ResponseBody.status = 401
                    ResponseBody.message = Config.getErrmsg()["isexist"]
                }
            }
            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }


    // Update Gate
    async UpdateGate(req, res, next) {
        try {

            const ObjectId = IISMethods.getobjectid()
            var ResponseBody = {}

            const pipeline = [{ $match: { '_id': ObjectId(req.body._id) } }]
            const record = await MainDB.getmenual("tblpropertygate", new PropertyGate(), pipeline)

            var RecordInfo = record.ResultData[0].recordinfo
            RecordInfo.updateuid = req.headers.uid
            RecordInfo.updateby = req.headers.personname
            RecordInfo.updatedate = IISMethods.getdatetimeisostr()
            req.body.recordinfo = RecordInfo

            const resp = await MainDB.executedata('u', new PropertyGate(), "tblpropertygate", req.body)

            var ResponseBody = {}
            ResponseBody.status = resp.status
            ResponseBody.data = resp.data
            ResponseBody.message = resp.message

            req.ResponseBody = ResponseBody
            next()
        }
        catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

    // Delete Gate 
    async DeleteGate(req, res, next) {
        try {
            const ResponseBody = {}

            const resp = await MainDB.executedata('d', new PropertyGate(), "PropertyGate", req.body)

            ResponseBody.status = resp.status
            ResponseBody.message = resp.message

            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }



    //Parkingslot
    async ListParkingSlot(req, res, next) {
        try {
            const ResponseBody = {}

            let pipeline = []

            const {
                searchtext = "",
                paginationinfo: { nextpageid = "", pageno = 1, pagelimit = 20, filter = {}, sort = {}, projection = {} }
            } = req.body || {}

            const requiredPage = {
                nextpageid: nextpageid,
                pageno: pageno,
                skip: (pageno - 1) * pagelimit,
                pagelimit: pagelimit
            }

            const sortData = Object.keys(sort).length !== 0 ? sort : { _id: -1 }


            if (Object.keys(filter).length) {
                pipeline = pipeline.concat(IISMethods.GetPipelineForFilter(filter))
            }
            if (searchtext !== "") {
                pipeline.push(...IISMethods.GetGlobalSearchFilter(new PropertyParkingSlot(), searchtext))
            }
            const resp = await MainDB.getmenual("tblpropertyparkingslot", new PropertyParkingSlot(), pipeline, requiredPage, sortData, true, "", projection)

            ResponseBody.pagename = "gate"
            ResponseBody.formname = "Gate"
            ResponseBody.fltpagecollection = "propertybuilding gate"
            ResponseBody.status = 200
            ResponseBody.message = Config.getResponsestatuscode()["200"]
            ResponseBody.data = resp.ResultData
            ResponseBody.fieldorder = resp.fieldorderdata
            ResponseBody.currentpage = resp.currentpage
            ResponseBody.nextpage = resp.nextpage
            ResponseBody.formfieldorderdata = resp.formfieldorderdata

            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

    //Add parkingslot
    async AddParkingSlot(req, res, next) {
        try {
            const ResponseBody = {}

            const ObjectId = IISMethods.getobjectid()
            const pipelinedata = [{ $match: { _id: ObjectId(req.body.propertyid) } }]
            const record = await MainDB.getmenual(TableName, new Propertycommon(), pipelinedata)

            // get count of building
            if (record.ResultData.length > 0) {
                let parkingslotid = new ObjectId()
                req.body._id = ObjectId(parkingslotid)
                let slotobj = req.body

                const dependancyPipeline = { propertyid: ObjectId(req.body.propertyid), parkingslot: req.body.parkingslot }
                const checkresp = await MainDB.FindOne("tblpropertyparkingslot", new PropertyParkingSlot(), dependancyPipeline)

                if (!checkresp) {
                    const resp = await MainDB.executedata("i", new PropertyParkingSlot(), "tblpropertyparkingslot", slotobj)
                    if (resp.status == 200) {

                        ResponseBody.status = resp.status
                        ResponseBody.message = resp.message
                        ResponseBody.data = resp.data
                    }
                } else {
                    ResponseBody.status = 401
                    ResponseBody.message = Config.getErrmsg()["isexist"]
                }
            }
            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }


    // Update parkingslot
    async UpdateParkingSlot(req, res, next) {
        try {

            const ObjectId = IISMethods.getobjectid()
            var ResponseBody = {}

            const pipeline = [{ $match: { '_id': ObjectId(req.body._id) } }]
            const record = await MainDB.getmenual("tblpropertyparkingslot", new PropertyGate(), pipeline)

            var RecordInfo = record.ResultData[0].recordinfo
            RecordInfo.updateuid = req.headers.uid
            RecordInfo.updateby = req.headers.personname
            RecordInfo.updatedate = IISMethods.getdatetimeisostr()
            req.body.recordinfo = RecordInfo

            const resp = await MainDB.executedata('u', new PropertyGate(), "tblpropertyparkingslot", req.body)

            var ResponseBody = {}
            ResponseBody.status = resp.status
            ResponseBody.data = resp.data
            ResponseBody.message = resp.message

            req.ResponseBody = ResponseBody
            next()
        }
        catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

    // Delete parking slot 
    async DeleteParkingSlot(req, res, next) {
        try {
            const ResponseBody = {}

            const resp = await MainDB.executedata('d', new PropertyGate(), "tblpropertyparkingslot", req.body)

            ResponseBody.status = resp.status
            ResponseBody.message = resp.message

            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }


}
