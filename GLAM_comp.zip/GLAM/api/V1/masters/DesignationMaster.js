import { IISMethods,MainDB, Config } from "../../../config/Init.js"
import _Designation from '../../../model/masters/Designation.js'
import _Customer from '../../../model/Onboarding/Customer.js'
import _GateKeeper from '../../../model/Onboarding/GateKeeper.js'
import _Employee from '../../../model/Onboarding/Employee.js'
import {Propertycommon} from '../../../model/masters/Property/PropertyMaster.js'
import _Dailyhelp from '../../../model/Onboarding/DailyHelp.js' 
import _Checklist from '../../../model/CheckList.js'


const TableName = "tbldesignationmaster"
const PageName = "designation"
const FormName = "Designation"
const FltPageCollection = "designationmaster"

export default class Designation {
	// List Designation
	async ListDesignation(req, res, next) {
		try {
            var ResponseBody = {}
            var PaginationInfo =  req.body.paginationinfo

            const requiredPage = {pageno : PaginationInfo.pageno, skip : (PaginationInfo.pageno - 1) * PaginationInfo.pagelimit, pagelimit : PaginationInfo.pagelimit}
            var pipeline = []
            var sort = (Object.keys(PaginationInfo.sort).length !== 0 ? PaginationInfo.sort : {'_id' :-1})
            let projection = PaginationInfo.projection ? PaginationInfo.projection : {}
            let fieldorder = req.body.paginationinfo.isfieldorder ? req.body.paginationinfo.isfieldorder : 0

            pipeline = IISMethods.GetPipelineForFilter(PaginationInfo.filter)

            const searchtext = req.body.searchtext || ""
            if (searchtext !== "") {
                pipeline.push(...IISMethods.GetGlobalSearchFilter(new _Designation(), searchtext))
            }
                        
            const resp = await MainDB.getmenual(TableName, new _Designation(), pipeline, requiredPage, sort, fieldorder,"", projection)
              
            ResponseBody.pagename = PageName
            ResponseBody.formname = FormName
			ResponseBody.fltpagecollection = FltPageCollection
            ResponseBody.status = 200
            ResponseBody.message = Config.getResponsestatuscode()['200']
            ResponseBody.data = resp.ResultData
            ResponseBody.currentpage = resp.currentpage
            ResponseBody.nextpage = resp.nextpage   
            ResponseBody.totaldocs = resp.totaldocs;
            ResponseBody.fieldorder = resp.fieldorderdata 
            ResponseBody.formfieldorderdata = resp.formfieldorderdata            

            req.ResponseBody = ResponseBody
            next()
		} catch (err) {
			req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
			next()
		}
	}

	// Insert Designation
	async InsertDesignation(req, res, next) {
		try {
			const ResponseBody = {}
            
			const resp = await MainDB.executedata("i", new _Designation(), TableName, req.body)

			ResponseBody.status = resp.status
			ResponseBody.message = resp.message
            ResponseBody.data = resp.data

			req.ResponseBody = ResponseBody
			next()
		} catch (err) {
			req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
			next()
		}
	}

	// Update Designation
	async UpdateDesignation(req, res, next) {
		 try {

            const ObjectId = IISMethods.getobjectid()
            var ResponseBody = {}

            const pipeline = [{ $match: { '_id': ObjectId(req.body._id) } }]
            const record = await MainDB.getmenual(TableName, new _Designation(), pipeline)
            
            var RecordInfo = record.ResultData[0].recordinfo
            RecordInfo.updateuid = req.headers.uid
            RecordInfo.updateby = req.headers.personname
            RecordInfo.updatedate = IISMethods.getdatetimeisostr()
            req.body.recordinfo = RecordInfo

            const resp = await MainDB.executedata('u', new _Designation(), TableName, req.body)

            
            if (resp.status === 200) {
                // Update Dependency
                const updatePipeline = [
                    { designationid: req.body._id },
                    { $set: { designation: req.body.designation, } }
                ]
                const updateModelObj = {
                    tblpropertymaster : new Propertycommon(),
                    tblemployee : new _Employee(),
                    // tblcustomer :new _Customer(),
                    tblgatekeeper :new _GateKeeper(),
                    // tblchecklist :new _Checklist(),
                    // tbldailyhelp:new _Dailyhelp()
                }
                
                const tempArray = []
                for (const key in updateModelObj) {
                    tempArray.push(MainDB.UpdateMany(key, updateModelObj[key], updatePipeline))
                }
                await Promise.all(tempArray)
            }


            var ResponseBody = {}
            ResponseBody.status = resp.status
            ResponseBody.data = resp.data
            ResponseBody.message = resp.message

            req.ResponseBody = ResponseBody
            next()
        }
        catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
	}

	// Delete Designation 
	async DeleteDesignation(req, res, next) {
		try {
			const ResponseBody = {}

            //Dependency Check
            // const gatekeeperObjModel = await MainDB.createmodel('tblgatekeeper', new _GateKeeper())
            // const employeeObjModel = await MainDB.createmodel('tblemployee', new _Employee())
            // const propertyObjModel = await MainDB.createmodel('tblpropertymaster', new _GateKeeper())


            // var dependency = [
            //     [employeeObjModel['objModel'], { designationid: req.body._id },"Employee"],
            // ]

            const resp = await MainDB.executedata('d', new _Designation(), TableName, req.body)
   
			ResponseBody.status = resp.status
			ResponseBody.message = resp.message

			req.ResponseBody = ResponseBody
			next()
		} catch (err) {
			req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
			next()
		}
	}

}   
