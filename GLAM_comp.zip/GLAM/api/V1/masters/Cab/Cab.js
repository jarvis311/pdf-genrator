import { IISMethods, MainDB, Config } from "../../../../config/Init.js"
import _CabMaster from "../../../../model/masters/Cab/Cab.js"
import _CabLog from '../../../../model/masters/Cab/CabLog.js'

const TableName = "tblcabmaster"
const PageName = "cabmaster"
const FormName = "cabmaster"
const FltPageCollection = "cabmaster"

export default class Cab {
    // List CabMaster
    async ListCabMaster(req, res, next) {
        try {
            var ResponseBody = {}
            var PaginationInfo = req.body.paginationinfo

            const requiredPage = { pageno: PaginationInfo.pageno, skip: (PaginationInfo.pageno - 1) * PaginationInfo.pagelimit, pagelimit: PaginationInfo.pagelimit }
            var pipeline = []
            var sort = (Object.keys(PaginationInfo.sort).length !== 0 ? PaginationInfo.sort : { '_id': -1 })
            let projection = PaginationInfo.projection ? PaginationInfo.projection : {}
            let fieldorder = req.body.paginationinfo.isfieldorder ? req.body.paginationinfo.isfieldorder : 0

            pipeline = IISMethods.GetPipelineForFilter(PaginationInfo.filter)

            const searchtext = req.body.searchtext || ""
            if (searchtext !== "") {
                pipeline.push(...IISMethods.GetGlobalSearchFilter(new _CabMaster(), searchtext))
            }

            const resp = await MainDB.getmenual(TableName, new _CabMaster(), pipeline, requiredPage, sort, fieldorder, "", projection)

            ResponseBody.pagename = PageName
            ResponseBody.formname = FormName
            ResponseBody.fltpagecollection = FltPageCollection
            ResponseBody.status = 200
            ResponseBody.message = Config.getResponsestatuscode()['200']
            ResponseBody.data = resp.ResultData
            ResponseBody.currentpage = resp.currentpage
            ResponseBody.nextpage = resp.nextpage
            ResponseBody.totaldocs = resp.totaldocs;
            ResponseBody.fieldorder = resp.fieldorderdata
            ResponseBody.formfieldorderdata = resp.formfieldorderdata

            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

    // Insert CabMaster
    async InsertCabMaster(req, res, next) {
        try {
            const ResponseBody = {}
            //get allow day listing 
            req.body.propertyid = req.headers.propertyid
            req.body.property = req.headers.property

            // if (req.body.startdate && req.body.enddate) {
            //     const Allowtime = IISMethods.generateDateTimeRange({ startdate: req.body.startdate, enddate: req.body.enddate })
            //     req.body.allowtime = Allowtime

                const resp = await MainDB.executedata("i", new _CabMaster(), TableName, req.body)

                ResponseBody.status = resp.status
                ResponseBody.message = resp.message
                ResponseBody.data = resp.data
            // } else {
            //     ResponseBody.status = 400
            //     ResponseBody.message = "Please provide start date and end date"
            // }

            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

    // Update CabMaster
    async UpdateCabMaster(req, res, next) {
        try {

            const ObjectId = IISMethods.getobjectid()
            var ResponseBody = {}

            const pipeline = [{ $match: { '_id': ObjectId(req.body._id) } }]
            const record = await MainDB.getmenual(TableName, new _CabMaster(), pipeline)

            var RecordInfo = record.ResultData[0].recordinfo
            RecordInfo.updateuid = req.headers.uid
            RecordInfo.updateby = req.headers.personname
            RecordInfo.updatedate = IISMethods.getdatetimeisostr()
            req.body.recordinfo = RecordInfo

            const resp = await MainDB.executedata('u', new _CabMaster(), TableName, req.body)

            if (resp.status == 200) {
                const cabLog = {
                    gatekeeperid: req.headers.uid,
                    gatekeeper: req.headers.personname,
                    cabid: req.body._id,
                    status: req.body.status,
                    collectdate: req.body.collectdate,
                    handoverdate: req.body.handoverdate,
                    iscollectfromgate: req.body.iscollectfromgate,
                    propertyid: req.headers.propertyid,
                    property: req.headers.property
                }
                await MainDB.executedata('i', new _CabLog(), "tblcablogmaster", cabLog)
            }
            // if (resp.status === 200) {
            //     // Update Dependency
            //     const updatePipeline = [
            //         { breedid: req.body._id },
            //         { $set: { breed: req.body.breed, } }
            //     ]
            //     const updateModelObj = {
            //         tblcustomer: new _Customer()
            //     }
                
            //     const tempArray = []
            //     for (const key in updateModelObj) {
            //         tempArray.push(MainDB.UpdateMany(key, updateModelObj[key], updatePipeline))
            //     }
            //     await Promise.all(tempArray)
            // }

            var ResponseBody = {}
            ResponseBody.status = resp.status
            ResponseBody.data = resp.data
            ResponseBody.message = resp.message

            req.ResponseBody = ResponseBody
            next()
        }
        catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }


      // manage cab
      async manageCab(req, res, next) {
        try {

            const ObjectId = IISMethods.getobjectid()
            var ResponseBody = {}

            const pipeline = [{ $match: { '_id': ObjectId(req.body._id) } }]
            const cabResp = await MainDB.getmenual(TableName, new _CabMaster(), pipeline)

            const cab = cabResp.ResultData[0]
            const currentdate = new Date()

            if (new Date(cab.startdate).toISOString().slice(0, 10) <= currentdate.toISOString().slice(0, 10) && new Date(cab.enddate).toISOString().slice(0, 10) >= currentdate.toISOString().slice(0, 10)) {

                const resp = await MainDB.executedata('u', new _CabMaster(), TableName, req.body)

                if (resp.status == 200) {
                    const cabLog = {
                        gatekeeperid: req.headers.uid,
                        gatekeeper: req.headers.personname,
                        cabid: req.body._id,
                        status: req.body.status,
                        collectdate: req.body.collectdate,
                        handoverdate: req.body.handoverdate,
                        iscollectfromgate: req.body.iscollectfromgate,
                        propertyid: req.headers.propertyid,
                        property: req.headers.property
                    }
                    await MainDB.executedata('i', new _CabLog(), "tblcablogmaster", cabLog)
                }

                ResponseBody.status = resp.status
                ResponseBody.data = resp.data
                ResponseBody.message = resp.message
            } else {
                ResponseBody.status = 400
                ResponseBody.data = "The cab's date does not align with the current date."
            }

            req.ResponseBody = ResponseBody
            next()
        }
        catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

    // Delete CabMaster
    async DeleteCabMaster(req, res, next) {
        try {
            const ResponseBody = {}

            const resp = await MainDB.executedata('d', new _CabMaster(), TableName, req.body)

            ResponseBody.status = resp.status
            ResponseBody.message = resp.message

            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

}
