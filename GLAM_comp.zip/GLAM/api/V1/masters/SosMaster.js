import { IISMethods,MainDB, Config,FieldConfig } from "../../../config/Init.js"
import _SOS from "../../../model/masters/Sos.js"
import _Vendor from '../../../model/Onboarding/Vendor.js'

const TableName = "tblsosmaster"
const PageName = "sos"
const FormName = "sos"
const FltPageCollection = "sosmaster"

export default class SOS {
	// List SOS
	async ListSOS(req, res, next) {
		try {
            var ResponseBody = {}
            var PaginationInfo =  req.body.paginationinfo

            const requiredPage = {pageno : PaginationInfo.pageno, skip : (PaginationInfo.pageno - 1) * PaginationInfo.pagelimit, pagelimit : PaginationInfo.pagelimit}
            var pipeline = []
            var sort = (Object.keys(PaginationInfo.sort).length !== 0 ? PaginationInfo.sort : {'_id' :-1})
            let projection = PaginationInfo.projection ? PaginationInfo.projection : {}
            let fieldorder = req.body.paginationinfo.isfieldorder ? req.body.paginationinfo.isfieldorder : 0

            const searchtext = req.body.searchtext || ""
            if (searchtext !== "") {
                pipeline.push(...IISMethods.GetGlobalSearchFilter(new _SOS(), searchtext))
            }
            if (PaginationInfo.filter) {
                if (PaginationInfo.filter.hasOwnProperty('fromdate') || PaginationInfo.filter.hasOwnProperty('todate')) {


                    if (PaginationInfo.filter.hasOwnProperty('fromdate') && PaginationInfo.filter.hasOwnProperty('todate')) {
                        const fromdate = new Date(PaginationInfo.filter["fromdate"]);
                        const todate = new Date(PaginationInfo.filter["todate"]);
                        pipeline.push(...IISMethods.getDateFilter({ 'fromdate': fromdate, 'todate': todate, 'filterkey': 'createdate', 'timezone': FieldConfig.timezone, isequal:true}));
                    } else if (PaginationInfo.filter.hasOwnProperty('fromdate')) {
                        const fromdate = new Date(PaginationInfo.filter["fromdate"]);

                        const filterkey = 'createdate'
                        pipeline.push(
                            {
                                $addFields: {
                                    converteddate: {
                                        $dateFromString: {
                                            dateString: `\$${filterkey}`,
                                        },
                                    },
                                },
                            },
                            {
                                $addFields: {
                                    [`_${filterkey}`]: {
                                        $dateToString: {
                                            format: "%Y-%m-%d",
                                            date: "$converteddate",
                                            timezone: FieldConfig.timezone,
                                        },
                                    },
                                },
                            },
                        );


                        pipeline.push({
                            $match: {
                                [`_${filterkey}`]: {
                                    $gte: IISMethods.getDateFormats(new Date(fromdate))
                                },
                            },
                        })

                    } else if (PaginationInfo.filter.hasOwnProperty('todate')) {
                        const todate = new Date(PaginationInfo.filter["todate"]);
                        const filterkey = 'createdate'
                        pipeline.push(
                            {
                                $addFields: {
                                    converteddate: {
                                        $dateFromString: {
                                            dateString: `\$${filterkey}`,
                                        },
                                    },
                                },
                            },
                            {
                                $addFields: {
                                    [`_${filterkey}`]: {
                                        $dateToString: {
                                            format: "%Y-%m-%d",
                                            date: "$converteddate"
                                        },
                                    },
                                },
                            },
                        );


                        pipeline.push({
                            $match: {
                                [`_${filterkey}`]: {
                                    $lte: IISMethods.getDateFormats(new Date(todate))
                                },
                            },
                        })
                    }
                }

                // else if (fromdate) {
                //     var daterangepipeline = [{ "$match": { "fromdate": { $gte: fromdate } } }];
                // }
                // else if (todate) {
                //     var daterangepipeline = [{ "$match": { "todate": { $lte: todate } } }];
                // }

                delete PaginationInfo.filter["fromdate"]
                delete PaginationInfo.filter["todate"]

                pipeline.push(...IISMethods.GetPipelineForFilter(PaginationInfo.filter))
            }            
            const resp = await MainDB.getmenual(TableName, new _SOS(), pipeline, requiredPage, sort, fieldorder,"", projection)
              
            ResponseBody.pagename = PageName
            ResponseBody.formname = FormName
			ResponseBody.fltpagecollection = FltPageCollection
            ResponseBody.status = 200
            ResponseBody.message = Config.getResponsestatuscode()['200']
            ResponseBody.data = resp.ResultData
            ResponseBody.currentpage = resp.currentpage
            ResponseBody.nextpage = resp.nextpage   
            ResponseBody.fieldorder = resp.fieldorderdata 
            ResponseBody.totaldocs = resp.totaldocs;
            ResponseBody.formfieldorderdata = resp.formfieldorderdata            

            req.ResponseBody = ResponseBody
            next()
		} catch (err) {
			req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
			next()
		}
	}

	// Insert SOS
	async InsertSOS(req, res, next) {
		try {
			const ResponseBody = {}

            req.body.personid = req.headers.uid
            req.body.person =  req.headers.personname
            const apptype = req.headers.apptype

            if (apptype == 1) {
                req.body.apptype = "Admin"
            } else if (apptype == 2) {
                req.body.apptype = "Gatekeeper"
            } else {
                req.body.apptype = "Customer"
            }

			const resp = await MainDB.executedata("i", new _SOS(), TableName, req.body)

            // if(req.headers.apptype == 1){
            //     ResponseBody.status = resp.status
            //     ResponseBody.message = "SOS alert sent successfully. Assistance is on the way."
            // }else if(req.headers.apptype == 2){
            //     ResponseBody.status = resp.status
            //     ResponseBody.message = "SOS alert sent successfully. Assistance is on the way."
            // }else if(req.headers.apptype == 3){
            //     ResponseBody.status = resp.status
            //     ResponseBody.message = "SOS alert sent successfully. Assistance is on the way."
            // }else{
            //     ResponseBody.status = resp.status
            //     ResponseBody.message = resp.message
            // }

			ResponseBody.status = resp.status
            ResponseBody.message = "SOS alert sent successfully. Assistance is on the way."

            ResponseBody.data = resp.data

			req.ResponseBody = ResponseBody
			next()
		} catch (err) {
			req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
			next()
		}
	}

	// Update SOS
	async UpdateSOS(req, res, next) {
		 try {

            const ObjectId = IISMethods.getobjectid()
            var ResponseBody = {}

            const pipeline = [{ $match: { '_id': ObjectId(req.body._id) } }]
            const record = await MainDB.getmenual(TableName, new _SOS(), pipeline)
            
            var RecordInfo = record.ResultData[0].recordinfo
            RecordInfo.updateuid = req.headers.uid
            RecordInfo.updateby = req.headers.personname
            RecordInfo.updatedate = IISMethods.getdatetimeisostr()
            req.body.recordinfo = RecordInfo

            const resp = await MainDB.executedata('u', new _SOS(), TableName, req.body)

            var ResponseBody = {}
            ResponseBody.status = resp.status
            ResponseBody.data = resp.data
            ResponseBody.message = resp.message

            req.ResponseBody = ResponseBody
            next()
        }
        catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
	}

	// Delete SOS 
	async DeleteSOS(req, res, next) {
		try {
			const ResponseBody = {}

            const resp = await MainDB.executedata('d', new _SOS(), TableName, req.body)
   
			ResponseBody.status = resp.status
			ResponseBody.message = resp.message

			req.ResponseBody = ResponseBody
			next()
		} catch (err) {
			req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
			next()
		}
	}

}
