import { IISMethods, MainDB, Config } from "../../../../config/Init.js"
import _Parcel from "../../../../model/masters/Parcel/Parcel.js"
import ParcelLog from '../../../../model/masters/Parcel/ParcelLog.js'

const TableName = "tblparcelmaster"
const PageName = "parcelmaster"
const FormName = "parcelmaster"
const FltPageCollection = "parcelmaster"

export default class ParcelMaster {
    // List Parcel
    async ListParcelMaster(req, res, next) {
        try {
            var ResponseBody = {}
            var PaginationInfo = req.body.paginationinfo

            const requiredPage = { pageno: PaginationInfo.pageno, skip: (PaginationInfo.pageno - 1) * PaginationInfo.pagelimit, pagelimit: PaginationInfo.pagelimit }
            var pipeline = []
            var sort = (Object.keys(PaginationInfo.sort).length !== 0 ? PaginationInfo.sort : { '_id': -1 })
            let projection = PaginationInfo.projection ? PaginationInfo.projection : {}
            let fieldorder = req.body.paginationinfo.isfieldorder ? req.body.paginationinfo.isfieldorder : 0


            pipeline = IISMethods.GetPipelineForFilter(PaginationInfo.filter)

            const searchtext = req.body.searchtext || ""
            if (searchtext !== "") {
                pipeline.push(...IISMethods.GetGlobalSearchFilter(new _Parcel(), searchtext))
            }

            const resp = await MainDB.getmenual(TableName, new _Parcel(), pipeline, requiredPage, sort, fieldorder, "", projection)

            ResponseBody.pagename = PageName
            ResponseBody.formname = FormName
            ResponseBody.fltpagecollection = FltPageCollection
            ResponseBody.status = 200
            ResponseBody.message = Config.getResponsestatuscode()['200']
            ResponseBody.data = resp.ResultData
            ResponseBody.currentpage = resp.currentpage
            ResponseBody.nextpage = resp.nextpage
            ResponseBody.totaldocs = resp.totaldocs;
            ResponseBody.fieldorder = resp.fieldorderdata
            ResponseBody.formfieldorderdata = resp.formfieldorderdata

            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

    // Insert Parcel
    async InsertParcelMaster(req, res, next) {
        try {
            const ResponseBody = {}

            req.body.propertyid = req.headers.propertyid
            req.body.property = req.headers.property

            //get allow day listing for parcel
            // const Allowtime = IISMethods.generateDateTimeRange({ startdate: req.body.startdate, enddate: req.body.enddate}) 
            // req.body.allowtime = Allowtime

            const resp = await MainDB.executedata("i", new _Parcel(), TableName, req.body)

            ResponseBody.status = resp.status
            ResponseBody.message = resp.message
            ResponseBody.data = resp.data

            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

    // Update Parcel
    async UpdateParcelMaster(req, res, next) {
        try {

            const ObjectId = IISMethods.getobjectid()
            var ResponseBody = {}

            const pipeline = [{ $match: { '_id': ObjectId(req.body._id) } }]
            const record = await MainDB.getmenual(TableName, new _Parcel(), pipeline)

            var RecordInfo = record.ResultData[0]?.recordinfo
            RecordInfo.updateuid = req.headers.uid
            RecordInfo.updateby = req.headers.personname
            RecordInfo.updatedate = IISMethods.getdatetimeisostr()
            req.body.recordinfo = RecordInfo

            const resp = await MainDB.executedata('u', new _Parcel(), TableName, req.body)

            if(resp.status == 200){
                const parcelLog = {
                    gatekeeperid: req.headers.uid,
                    gatekeeper: req.headers.personname,
                    parcelid: req.body._id,
                    status: req.body.status,
                    collectdate: req.body.collectdate,
                    handoverdate: req.body.handoverdate,
                    iscollectfromgate: req.body.iscollectfromgate,
                    propertyid: req.headers.propertyid,
                    property:req.headers.property
                }
                await MainDB.executedata('i', new ParcelLog(), "tblparcellogmaster", parcelLog)
            }

            var ResponseBody = {}

            ResponseBody.status = resp.status
            ResponseBody.data = resp.data
            ResponseBody.message = resp.message

            req.ResponseBody = ResponseBody
            next()
        }
        catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }


    // manage Parcel
    async manageParcel(req, res, next) {
        try {

            const ObjectId = IISMethods.getobjectid()
            var ResponseBody = {}
            console.log("calling 2....",req.body)

            const pipeline = [{ $match: { '_id': ObjectId(req.body._id) } }]
            const parcelResp = await MainDB.getmenual(TableName, new _Parcel(), pipeline)

            const parcel = parcelResp.ResultData[0]

            const currentdate = new Date()

            if (new Date(parcel.parceldate).toISOString().slice(0, 10) == currentdate.toISOString().slice(0, 10)) {

                const resp = await MainDB.executedata('u', new _Parcel(), TableName, req.body)

                if (resp.status == 200) {
                    const parcelLog = {
                        gatekeeperid: req.headers.uid,
                        gatekeeper: req.headers.personname,
                        parcelid: req.body._id,
                        status: req.body.status,
                        collectdate: req.body.collectdate,
                        handoverdate: req.body.handoverdate,
                        iscollectfromgate: req.body.iscollectfromgate,
                        propertyid: req.headers.propertyid,
                        property: req.headers.property
                    }
                    await MainDB.executedata('i', new ParcelLog(), "tblparcellogmaster", parcelLog)
                }

                ResponseBody.status = resp.status
                ResponseBody.data = resp.data
                ResponseBody.message = resp.message
            } else {
                ResponseBody.status = 400
                ResponseBody.data = "The parcel's date does not align with the current date."
            }

            req.ResponseBody = ResponseBody
            next()
        }
        catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }
    
    // Delete Parcel
    async DeleteParcelMaster(req, res, next) {
        try {
            const ResponseBody = {}

            const resp = await MainDB.executedata('d', new _Parcel(), TableName, req.body)

            ResponseBody.status = resp.status
            ResponseBody.message = resp.message

            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

}
