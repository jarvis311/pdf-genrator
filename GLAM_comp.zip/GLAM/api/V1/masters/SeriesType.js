import { IISMethods, MainDB, Config } from "../../../config/Init.js"
import SeriesType from "../../../model/SeriesType.js"
import _Series from '../../../model/masters/Series.js'

const TableName = "tblseriestypemaster"
const PageName = "seriestypemaster"
const FormName = "seriestypemaster"
const FltPageCollection = "seriestypemaster"

export default class SeriesTypeMaster {
    // List seriestype
    async ListSeriesType(req, res, next) {
        try {
            var ResponseBody = {}
            var PaginationInfo = req.body.paginationinfo

            const requiredPage = { pageno: PaginationInfo.pageno, skip: (PaginationInfo.pageno - 1) * PaginationInfo.pagelimit, pagelimit: PaginationInfo.pagelimit }
            var pipeline = []
            var sort = (Object.keys(PaginationInfo.sort).length !== 0 ? PaginationInfo.sort : { '_id': -1 })
            let projection = PaginationInfo.projection ? PaginationInfo.projection : {}
            let fieldorder = req.body.paginationinfo.isfieldorder ? req.body.paginationinfo.isfieldorder : 0

            pipeline = IISMethods.GetPipelineForFilter(PaginationInfo.filter)

            const searchtext = req.body.searchtext || ""
            if (searchtext !== "") {
                pipeline.push(...IISMethods.GetGlobalSearchFilter(new SeriesType(), searchtext))
            }

            const resp = await MainDB.getmenual(TableName, new SeriesType(), pipeline, requiredPage, sort, fieldorder, "", projection)

            ResponseBody.pagename = PageName
            ResponseBody.formname = FormName
            ResponseBody.fltpagecollection = FltPageCollection
            ResponseBody.status = 200
            ResponseBody.message = Config.getResponsestatuscode()['200']
            ResponseBody.data = resp.ResultData
            ResponseBody.currentpage = resp.currentpage
            ResponseBody.nextpage = resp.nextpage
            ResponseBody.fieldorder = resp.fieldorderdata
            ResponseBody.totaldocs = resp.totaldocs;
            ResponseBody.formfieldorderdata = resp.formfieldorderdata

            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

    // Insert SeriesType
    async InsertSeriesType(req, res, next) {
        try {
            const ResponseBody = {}

            const resp = await MainDB.executedata("i", new SeriesType(), TableName, req.body)

            ResponseBody.status = resp.status
            ResponseBody.message = resp.message
            ResponseBody.data = resp.data

            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

    // Update SeriesType
    async UpdateSeriesType(req, res, next) {
        try {

            const ObjectId = IISMethods.getobjectid()
            var ResponseBody = {}

            const pipeline = [{ $match: { '_id': ObjectId(req.body._id) } }]
            const record = await MainDB.getmenual(TableName, new SeriesType(), pipeline)

            var RecordInfo = record.ResultData[0]?.recordinfo ?? {}
            RecordInfo.updateuid = req.headers.uid
            RecordInfo.updateby = req.headers.personname
            RecordInfo.updatedate = IISMethods.getdatetimeisostr()
            req.body.recordinfo = RecordInfo

            const resp = await MainDB.executedata('u', new SeriesType(), TableName, req.body)

            var ResponseBody = {}
            ResponseBody.status = resp.status
            ResponseBody.data = resp.data
            ResponseBody.message = resp.message

            req.ResponseBody = ResponseBody
            next()
        }
        catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

    // Delete seriestype 
    async DeleteSeriesType(req, res, next) {
        try {
            const ResponseBody = {}

            //Dependency Check
            const seriesObjModel = await MainDB.createmodel('tblseriesmaster', new _Series())

            var dependency = [
                [seriesObjModel['objModel'], { seriestypeid: req.body._id }, "Series"],
            ]

            const resp = await MainDB.executedata('d', new SeriesType(), TableName, req.body, true, dependency)

            ResponseBody.status = resp.status
            ResponseBody.message = resp.message

            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

}
