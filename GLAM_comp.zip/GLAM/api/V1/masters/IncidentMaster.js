import { IISMethods,MainDB, Config } from "../../../config/Init.js"
import _Incident from '../../../model/masters/Incident.js'

const TableName = "tblincidentmaster"
const PageName = "incident"
const FormName = "Incident Master"
const FltPageCollection = "incidentmaster"

export default class IncidentMaster {
	// List incident
	async ListIncidentMaster(req, res, next) {
		try {
            var ResponseBody = {}
            var PaginationInfo =  req.body.paginationinfo
            const ObjectId = IISMethods.getobjectid()

            const requiredPage = {pageno : PaginationInfo.pageno, skip : (PaginationInfo.pageno - 1) * PaginationInfo.pagelimit, pagelimit : PaginationInfo.pagelimit}
            var pipeline = []
            var sort = (Object.keys(PaginationInfo.sort).length !== 0 ? PaginationInfo.sort : {'_id' :-1})
            let projection = PaginationInfo.projection ? PaginationInfo.projection : {}
            let fieldorder = req.body.paginationinfo.isfieldorder ? req.body.paginationinfo.isfieldorder : 0

            pipeline = IISMethods.GetPipelineForFilter(PaginationInfo.filter)

            if(req.headers.propertyid){
                pipeline.push({$match:{propertyid:ObjectId(req.headers.propertyid)}})
            }

            const searchtext = req.body.searchtext || ""
            if (searchtext !== "") {
                pipeline.push(...IISMethods.GetGlobalSearchFilter(new _Incident(), searchtext))
            }
                        
            const resp = await MainDB.getmenual(TableName, new _Incident(), pipeline, requiredPage, sort, fieldorder,"", projection)
              
            ResponseBody.pagename = PageName
            ResponseBody.formname = FormName
			ResponseBody.fltpagecollection = FltPageCollection
            ResponseBody.status = 200
            ResponseBody.message = Config.getResponsestatuscode()['200']
            ResponseBody.data = resp.ResultData 
            ResponseBody.totaldocs = resp.totaldocs
            ResponseBody.fieldorder = resp.fieldorderdata 
            ResponseBody.formfieldorderdata = resp.formfieldorderdata            

            req.ResponseBody = ResponseBody
            next()
		} catch (err) {
			req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
			next()
		}
	}

	// Insert Incident
	async InsertIncidentMaster(req, res, next) {
		try {
			const ResponseBody = {}
            
            req.body.propertyid = req.headers.propertyid
            req.body.property = req.headers.property
            req.body.senderid = req.headers.uid
            req.body.sender = req.headers.personname
            
			const resp = await MainDB.executedata("i", new _Incident(), TableName, req.body)

			ResponseBody.status = resp.status
			ResponseBody.message = resp.message
            ResponseBody.data = resp.data

			req.ResponseBody = ResponseBody
			next()
		} catch (err) {
			req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
			next()
		}
	}

	// Update Incident
	async UpdateIncidentMaster(req, res, next) {
		 try {

            const ObjectId = IISMethods.getobjectid()
            var ResponseBody = {}

            const pipeline = [{ $match: { '_id': ObjectId(req.body._id) } }]
            const record = await MainDB.getmenual(TableName, new _Incident(), pipeline)
            
            var RecordInfo = record.ResultData[0].recordinfo
            RecordInfo.updateuid = req.headers.uid
            RecordInfo.updateby = req.headers.personname
            RecordInfo.updatedate = IISMethods.getdatetimeisostr()
            req.body.recordinfo = RecordInfo

            const resp = await MainDB.executedata('u', new _Incident(), TableName, req.body)

            var ResponseBody = {}
            ResponseBody.status = resp.status
            ResponseBody.data = resp.data
            ResponseBody.message = resp.message

            req.ResponseBody = ResponseBody
            next()
        }
        catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
	}

	// Delete Incident 
	async DeleteIncidentMaster(req, res, next) {
		try {
			const ResponseBody = {}

            const resp = await MainDB.executedata('d', new _Incident(), TableName, req.body)
   
			ResponseBody.status = resp.status
			ResponseBody.message = resp.message

			req.ResponseBody = ResponseBody
			next()
		} catch (err) {
			req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
			next()
		}
	}

}
