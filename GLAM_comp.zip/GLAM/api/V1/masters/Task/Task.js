import { IISMethods, MainDB, Config } from "../../../../config/Init.js"
import _Alerts from "../../../../model/masters/Alerts.js"
import _Day from '../../../../model/masters/Day.js'
import _TaskDefault from '../../../../model/masters/Task/TaskDefault.js'
import _Task from '../../../../model/masters/Task/Task.js'
import _TaskStatus from '../../../../model/masters/Task/Taskstatus.js'
import _Checklist from '../../../../model/CheckList.js'
import { Propertycommon } from "../../../../model/masters/Property/PropertyMaster.js"
import { config } from "dotenv"

const TableName = "tbltaskscheduler"
const PageName = "taskscheduler"
const FormName = "taskscheduler"
const FltPageCollection = "taskscheduler"

export default class TaskMaster {

    async ListDayMaster(req, res, next) {
        try {
            var ResponseBody = {}
            var PaginationInfo = req.body.paginationinfo

            const requiredPage = { pageno: PaginationInfo.pageno, skip: (PaginationInfo.pageno - 1) * PaginationInfo.pagelimit, pagelimit: PaginationInfo.pagelimit }
            var pipeline = []
            var sort = (Object.keys(PaginationInfo.sort).length !== 0 ? PaginationInfo.sort : { '_id': -1 })
            let projection = PaginationInfo.projection ? PaginationInfo.projection : {}
            let fieldorder = req.body.paginationinfo.isfieldorder ? req.body.paginationinfo.isfieldorder : 0


            pipeline = IISMethods.GetPipelineForFilter(PaginationInfo.filter)

            const searchtext = req.body.searchtext || ""
            if (searchtext !== "") {
                pipeline.push(...IISMethods.GetGlobalSearchFilter(new _Day(), searchtext))
            }

            const resp = await MainDB.getmenual("tbldaymaster", new _Day(), pipeline, requiredPage, sort, fieldorder, "", projection)

            ResponseBody.status = 200
            ResponseBody.message = Config.getResponsestatuscode()['200']
            ResponseBody.data = resp.ResultData
            ResponseBody.currentpage = resp.currentpage
            ResponseBody.nextpage = resp.nextpage
            ResponseBody.totaldocs = resp.totaldocs;
            ResponseBody.fieldorder = resp.fieldorderdata
            ResponseBody.formfieldorderdata = resp.formfieldorderdata

            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

    async TaskSchedulerScript(req, res, next) {
        try {
            const ResponseBody = {}
            ResponseBody.status = 401
            ResponseBody.message = Config.getResponsestatuscode()["401"]

            const ObjectId = IISMethods.getobjectid()
            // if (Config.servermode != "dev") {
            //     userpipiline = [{ $match: { subdomainname: "instanceit" } }]
            // }
            const currentdate = new Date()

            const defaultTaskPipeline = [
                {
                    $addFields: {
                        expirydate: {
                            $dateToString: {
                                format: "%Y-%m-%d",
                                date: "$enddate",
                                timezone: "Asia/Kolkata"
                            }
                        }
                    }
                },
                {
                    $match: {
                        $or: [
                            {
                                expirydate: { $gte: IISMethods.getDateFormats(currentdate, 1, true) }
                            },
                            {
                                expirydate: null
                            }
                        ],
                        // _id : ObjectId("634d3ba33cfdb94a2f9d0133")
                    }
                }
            ]

            const defaultTaskRecord = await MainDB.getmenual(TableName, new _TaskDefault(), defaultTaskPipeline)
            console.log("🚀 ~ TaskSchedulerScript ~ defaultTaskRecord:", defaultTaskRecord)
            // let maxid = await MainDB.getmaxid(seriesData._id, "taskassign", new Task())

            if (defaultTaskRecord.ResultData.length > 0) {
                //Get property wise all task
                for (var scheduleTask of defaultTaskRecord.ResultData) {

                    if (IISMethods.getDateFormats(currentdate, 1, true) >= IISMethods.getDateFormats(scheduleTask.startdate, 1, true)) {
                        const taskdefaultid = ObjectId()

                        let TaskArray = []
                        let defaultExpiryDate = ""
                        if (scheduleTask.enddate) {
                            defaultExpiryDate = IISMethods.getDateFormats(scheduleTask.enddate, 1, true)
                        }

                        let taskDetails = []

                        taskDetails.push({
                            categoryid: scheduleTask.categoryid,
                            category: scheduleTask.category
                        })


                        let assignpersonidarray = []
                        if (scheduleTask.assignperson) {
                            assignpersonidarray = scheduleTask.assignperson
                        }

                        let finaltaskdetailsarray = []
                        for (let data of assignpersonidarray) {
                            for (let obj of taskDetails) {
                                obj.assignpersonid = ObjectId(data.assignpersonid)
                                obj.assignperson = data.assignperson

                                finaltaskdetailsarray.push({ ...obj })
                            }
                        }

                        if (finaltaskdetailsarray.length > 0) {
                            taskDetails = finaltaskdetailsarray
                        }
                        let TaskAssign = { ...scheduleTask }
                        delete TaskAssign.assignperson

                        let isAddData = 0;
                        let isValidWeekDay = 1;

                        const nextdate = new Date(); // Initialize once and reuse
                        if (TaskAssign.recurrencetypeid.toString() === Config.tasktype.Weekly) {
                            const days = scheduleTask.selecteddays || [];
                            const currentDay = nextdate.getDay(); // 0 (Sunday) - 6 (Saturday)

                            // Check if the current day is included in the selected days
                            if (!days.includes(currentDay)) {
                                isValidWeekDay = 0;
                            }
                        } else if (TaskAssign.recurrencetypeid.toString() === Config.tasktype.Monthly) {
                            const days = scheduleTask.selecteddates || [];
                            const currentDate = nextdate.getDate(); // 1 - 31

                            // Check if the current date is included in the selected dates
                            if (!days.includes(currentDate)) {
                                isValidWeekDay = 0;
                            }
                        } else if (TaskAssign.recurrencetypeid.toString() === Config.tasktype.Custom) {
                            const days = scheduleTask.dates || [];
                            const customDate = IISMethods.getDateFormats(nextdate, 1, true);

                            // Check if the custom formatted date is included in the specified dates
                            if (!days.includes(customDate)) {
                                isValidWeekDay = 0;
                            }
                        } else if (TaskAssign.recurrencetypeid.toString() === Config.tasktype.Daily) {
                            isValidWeekDay = 1
                        }else{
                            isValidWeekDay = 0
                        }

                        if ((!defaultExpiryDate || defaultExpiryDate >= IISMethods.getDateFormats(currentdate, 1, true)) && isValidWeekDay == 1) {
                            isAddData = 1
                        }

                        if (isAddData == 1) {
                            // const taskcode = await MainDB.getseriesno(ObjectId(seriesData.companyid),ObjectId(seriesData.propertyid),ObjectId(seriesData._id),"taskassign",new _Task(),"",maxid)
                            // TaskAssign.seriesid = seriesData._id
                            // TaskAssign.taskcode = taskcode ? taskcode : ""
                            // TaskAssign.maxid = maxid
                            // maxid++

                            TaskAssign.recordinfo = {
                                entryuid: scheduleTask.recordinfo.entryuid,
                                entryby: scheduleTask.recordinfo.entryby,
                                entrydate: IISMethods.getDateFormats(new Date(), 14, true),
                                timestamp: IISMethods.getDateFormats(new Date(), 12, true),
                                updateuid: scheduleTask.recordinfo.updateuid,
                                updateby: scheduleTask.recordinfo.updateby,
                                updatedate: IISMethods.getDateFormats(new Date(), 14, true)
                            }

                            TaskAssign.taskdefaultid = taskdefaultid
                            TaskAssign._id = ObjectId()
                            TaskAssign.assignbypersonid = scheduleTask.recordinfo.entryuid
                            TaskAssign.assignbyperson = scheduleTask.recordinfo.entryby
                            TaskAssign.assignpersons = scheduleTask.assignperson
                            TaskAssign.propertyid = scheduleTask.propertyid
                            TaskAssign.property = scheduleTask.property

                            let defaultExpiryDate = ""
                            if (scheduleTask.enddate) {
                                defaultExpiryDate = IISMethods.getDateFormats(scheduleTask.enddate, 1, true)
                            }
            

                            const checklistPipeline = [{ $match: { _id: ObjectId(scheduleTask.checklistid) } }]
                            const checklistResp = await MainDB.getmenual("tblchecklist", new _Checklist(), checklistPipeline)

                            if (checklistResp.ResultData.length) {
                                TaskAssign.checklists = checklistResp.ResultData[0].checklists
                            }

                            if (scheduleTask.assignperson && scheduleTask.assignperson.length && !scheduleTask.assignperson) {
                                TaskAssign.assignpersons = scheduleTask.assignperson

                                if (scheduleTask.assignperson.length == 1) {
                                    TaskAssign.assignpersonid = scheduleTask.assignperson[0].assignpersonid
                                    TaskAssign.assignperson = scheduleTask.assignperson[0].assignperson
                                    TaskAssign.assignpersons = []
                                }
                            }


                            if (!TaskAssign.assignperson) {
                                TaskAssign.acceptedtasktime = null
                                TaskAssign.ishidestartbtn = 3
                                TaskAssign.taskstatuscolor = Config.taskstatus.unassigned.taskstatuscolor
                                TaskAssign.taskstatusid = Config.taskstatus.unassigned.taskstatusid
                                TaskAssign.taskstatus = Config.taskstatus.unassigned.taskstatus

                            } else {
                                TaskAssign.acceptedtasktime = new Date()
                                TaskAssign.ishidestartbtn = 0
                                TaskAssign.taskstatuscolor = Config.taskstatus.open.taskstatuscolor
                                TaskAssign.taskstatusid = Config.taskstatus.open.taskstatusid
                                TaskAssign.taskstatus = Config.taskstatus.open.taskstatus
                            }

                            TaskAssign.showtaskdate = new Date()
                            TaskAssign.startdate = new Date()
                            TaskAssign.tasktime = new Date()

                            TaskAssign.log = [
                                {
                                    statusid: TaskAssign.taskstatusid,
                                    status: TaskAssign.taskstatus,
                                    backgroundcolor: TaskAssign.taskstatuscolor,
                                    personid: TaskAssign.assignbypersonid,
                                    person: TaskAssign.assignbyperson,
                                    logdatetime: new Date(),
                                    assignedto: TaskAssign.assignpersons,
                                    logtype: 1
                                }
                            ]

                            TaskArray.push({ ...TaskAssign })
                        }


                        if (TaskArray.length > 0) {
                            for (var obj of TaskArray) {
                                obj._id = ObjectId()

                                //Start: Insert TaskStatusLog Data
                                await MainDB.InsertTaskStatusLog(obj,currentdate)
                                //End: Insert TaskStatusLog Data


                                // if(obj.categoryid.toString() == Config.taskcategory.reading){
                                //     obj.readingitems?.map(reading=>{
                                //         reading.readingtype = 0 
                                //         reading.reading = 0
                                //         reading.color = Config.dummycolor
                                //         return reading
                                //     })
                                //     obj.bordercolor = FieldConfig.readingcolor.white
                                //     obj.addreadingtask = 1

                                //     IISMethods.emitRoomWiseSocket({
                                //         to: [`${req.headers.subdomainname}reading${obj.propertyid?.toString()}`],
                                //         on: Config.getSocketTriggers()["readingdata"],
                                //         data: obj
                                //     })
                                // } 

                                // Start: task add log
                                let reqData = {
                                    taskid: obj._id,
                                    userid: ObjectId(req.headers.uid),
                                    username: req.headers.personname,
                                    datetime: new Date(),
                                    actionid: Config.dummyObjid,
                                    action_name: obj.taskstatus,
                                    comment: "",
                                    hkcomments: "",
                                    taskstatustype: obj.taskstatustype,
                                    taskstatusid: ObjectId(obj.taskstatusid),
                                    taskstatus: obj.taskstatus,
                                    logtype: 1,
                                    flag: 0,
                                    recordinfo: {
                                        entryuid: req.headers.uid,
                                        entryby: req.headers.username,
                                        entrydate: new Date().toISOString().replace(/T/, " ").replace(/\..+/, ""),
                                        timestamp: new Date().getTime()
                                    }
                                }
                                await MainDB.addTaskLogs(reqData)

                                if (obj.comment) {
                                    let reqData = {
                                        taskid: obj._id,
                                        userid: ObjectId(req.headers.uid),
                                        username: req.headers.personname,
                                        datetime: new Date(),
                                        actionid: Config.dummyObjid,
                                        action_name: obj.taskstatus,
                                        taskstatustype: obj.taskstatustype,
                                        taskstatusid: ObjectId(Config.dummyObjid),
                                        taskstatus: obj.taskstatus,
                                        logtype: 1,
                                        flag: 0,
                                        recordinfo: {
                                            entryuid: req.headers.uid,
                                            entryby: req.headers.username,
                                            entrydate: IISMethods.getdatetimeisostr(),
                                            timestamp: new Date().getTime()
                                        }
                                    }
                                    await MainDB.addTaskLogs(reqData)
                                }

                                if (Array.isArray(obj.images) && obj.images.length) {
                                    const reqData = {
                                        taskid: obj._id,
                                        userid: ObjectId(req.headers.uid),
                                        username: req.headers.username,
                                        datetime: new Date(),
                                        actionid: Config.dummyObjid,
                                        action_name: "Attachments Added",
                                        taskstatustype: "",
                                        taskstatusid: ObjectId(Config.dummyObjid),
                                        taskstatus: "",
                                        logtype: 1,
                                        flag: 0,
                                        recordinfo: {
                                            entryuid: req.headers.uid,
                                            entryby: req.headers.username,
                                            entrydate: IISMethods.getCustomDatetimestr(),
                                            timestamp: new Date().getTime()
                                        }
                                    }
                                    await MainDB.addTaskLogs(reqData)
                                }
                            }

                            const takResp = await MainDB.InsertMany("tbltask", new _Task(), TaskArray)

                        }
                    }
                }

            }
             ResponseBody.status = 200
             ResponseBody.message = "Success!"
            return ResponseBody
        } catch (err) {
            console.log("🚀 ~ TaskSchedulerScript ~ err:", err)
            const ResponseBody = {}
            ResponseBody.status = 500
            ResponseBody.message = Config.getResponsestatuscode()["500"]
            return ResponseBody
        }
    }

    async ListTask(req, res, next) {
        try {
            var ResponseBody = {}
            const ObjectId = IISMethods.getobjectid()

            var PaginationInfo = req.body.paginationinfo

            const requiredPage = { pageno: PaginationInfo.pageno, skip: (PaginationInfo.pageno - 1) * PaginationInfo.pagelimit, pagelimit: PaginationInfo.pagelimit }
            var pipeline = []
            var sort = (Object.keys(PaginationInfo.sort).length !== 0 ? PaginationInfo.sort : { '_id': -1 })
            let projection = PaginationInfo.projection ? PaginationInfo.projection : {}
            let fieldorder = req.body.paginationinfo.isfieldorder ? req.body.paginationinfo.isfieldorder : 0

            pipeline = IISMethods.GetPipelineForFilter(PaginationInfo.filter)

            const searchtext = req.body.searchtext || ""
            if (searchtext !== "") {
                pipeline.push(...IISMethods.GetGlobalSearchFilter(new _Task(), searchtext))
            }

            const userrolewiseperson = await MainDB.getPersonByUserroleHierarchyWithPersonData(req.headers.uid,req.headers.propertyid)
            objuids.push(userrolewiseperson)
   
            var isAdmin = await MainDB.IsAdmin(req.headers.uid)

            if (!isAdmin) {
                objuids.push(new ObjectId(req.headers.uid))
            } else {
                objuids = await MainDB.getSuperAdminWisePersonIds(req.headers.propertyid)
            }

            pipeline.push({
                $match: {
                    $or: [
                        {
                            $and: [
                                { 'assignpersons.assignpersonid': { $in: objuids } },
                                { propertyid: ObjectId(req.headers.propertyid) }
                            ]
                        },
                        {
                            $and: [
                                { 'recordinfo.entryuid': req.headers.uid },
                                { propertyid: ObjectId(req.headers.propertyid) }
                            ]
                        }
                    ]
                }
            })

            const resp = await MainDB.getmenual("tbltask", new _Task(), pipeline, requiredPage, sort, fieldorder, "", projection)

            ResponseBody.pagename = PageName
            ResponseBody.formname = FormName
            ResponseBody.fltpagecollection = FltPageCollection
            ResponseBody.status = 200
            ResponseBody.message = Config.getResponsestatuscode()['200']
            ResponseBody.data = resp.ResultData
            ResponseBody.currentpage = resp.currentpage
            ResponseBody.nextpage = resp.nextpage
            ResponseBody.totaldocs = resp.totaldocs;
            ResponseBody.fieldorder = resp.fieldorderdata
            ResponseBody.formfieldorderdata = resp.formfieldorderdata

            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

    async InsertTask(req, res, next) {
        try {
            const ResponseBody = {}

            const resp = await MainDB.executedata("i", new _Task(), "tbltask", req.body)

            ResponseBody.status = resp.status
            ResponseBody.message = resp.message
            ResponseBody.data = resp.data

            req.ResponseBody = ResponseBody
            next()

        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

    async UpdateTask(req, res, next) {
        try {

            const ObjectId = IISMethods.getobjectid()
            var ResponseBody = {}

            const pipeline = [{ $match: { '_id': ObjectId(req.body._id) } }]
            const taskResp = await MainDB.getmenual("tbltask", new _Task(), pipeline)

            var RecordInfo = taskResp.ResultData[0].recordinfo
            RecordInfo.updateuid = req.headers.uid
            RecordInfo.updateby = req.headers.personname
            RecordInfo.updatedate = IISMethods.getdatetimeisostr()
            req.body.recordinfo = RecordInfo

            const recordlog = taskResp.ResultData[0]?.log ?? []
            
            let issuccess = 1

            if (req.body.checklists && req.body.checklists.length && req.body.taskstatusid === Config.taskstatus.complete.taskstatusid) {
                const hasIncompleteMandatory = req.body.checklists.some(obj => obj.ismandatory && !obj.iscompleted)
                if (hasIncompleteMandatory) {
                    issuccess = 0
                }
            }

            if(issuccess){
                recordlog.push(
                    {
                        statusid: req.body.taskstatusid,
                        status: req.body.taskstatus,
                        backgroundcolor: req.body.taskstatuscolor,
                        personid: req.headers.uid,
                        person: req.headers.personname,
                        logdatetime: new Date(),
                        logtype: 2
                    }
                )
                req.body.log = recordlog
                
                const resp = await MainDB.executedata('u', new _Task(), "tbltask", req.body)
    
                var ResponseBody = {}
    
                ResponseBody.status = resp.status
                ResponseBody.data = resp.data
                ResponseBody.message = resp.message
            }else{
                ResponseBody.status = 400
                ResponseBody.message = Config.errmsg['notchecklist']
            }
           

            req.ResponseBody = ResponseBody
            next()
        }
        catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

    async ListSchedule(req, res, next) {
        try {
            var ResponseBody = {}
            var PaginationInfo = req.body.paginationinfo

            const requiredPage = { pageno: PaginationInfo.pageno, skip: (PaginationInfo.pageno - 1) * PaginationInfo.pagelimit, pagelimit: PaginationInfo.pagelimit }
            var pipeline = []
            var sort = (Object.keys(PaginationInfo.sort).length !== 0 ? PaginationInfo.sort : { '_id': -1 })
            let projection = PaginationInfo.projection ? PaginationInfo.projection : {}
            let fieldorder = req.body.paginationinfo.isfieldorder ? req.body.paginationinfo.isfieldorder : 0

            pipeline = IISMethods.GetPipelineForFilter(PaginationInfo.filter)

            const searchtext = req.body.searchtext || ""
            if (searchtext !== "") {
                pipeline.push(...IISMethods.GetGlobalSearchFilter(new _TaskDefault(), searchtext))
            }

            const resp = await MainDB.getmenual("tbltaskscheduler", new _TaskDefault(), pipeline, requiredPage, sort, fieldorder, "", projection)

            ResponseBody.pagename = PageName
            ResponseBody.formname = FormName
            ResponseBody.fltpagecollection = FltPageCollection
            ResponseBody.status = 200
            ResponseBody.message = Config.getResponsestatuscode()['200']
            ResponseBody.data = resp.ResultData
            ResponseBody.currentpage = resp.currentpage
            ResponseBody.nextpage = resp.nextpage
            ResponseBody.totaldocs = resp.totaldocs;
            ResponseBody.fieldorder = resp.fieldorderdata
            ResponseBody.formfieldorderdata = resp.formfieldorderdata

            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

    async ScheduleTaskAdd(req, res, next) {
        try {
            const ResponseBody = {}
            const ObjectId = IISMethods.getobjectid()
            const systemdate = req.headers.systemdate
            const timezone = req.headers.timezone
            const timezoneSystemDate = IISMethods.getTimezoneDate({ date: systemdate, timezone, isdatewithtime: true, isutc: false })

            req.body.assignbypersonid = req.headers.uid
            req.body.assignbyperson = req.headers.username
            req.body.propertyid = req.headers.propertyid
            req.body.property = req.headers.property
            req.body.startdate = req.body.startdate ? req.body.startdate : systemdate
            req.body.showtaskdate = new Date(req.body.startdate)
            const currentdate = new Date()

            if (IISMethods.getDateFormats(currentdate, 1, true) == IISMethods.getDateFormats(req.body.startdate, 1, true)) {
                const taskdefaultid = ObjectId()

                let TaskArray = []
                let defaultExpiryDate = ""
                if (req.body.enddate) {
                    defaultExpiryDate = IISMethods.getDateFormats(req.body.enddate, 1, true)
                }

                let taskDetails = []

                taskDetails.push({
                    categoryid: req.body.categoryid,
                    category: req.body.category
                })


                let assignpersonidarray = []
                if (req.body.assignperson) {
                    assignpersonidarray = req.body.assignperson
                }

                let finaltaskdetailsarray = []
                for (let data of assignpersonidarray) {
                    for (let obj of taskDetails) {
                        obj.assignpersonid = ObjectId(data.assignpersonid)
                        obj.assignperson = data.assignperson

                        finaltaskdetailsarray.push({ ...obj })
                    }
                }

                if (finaltaskdetailsarray.length > 0) {
                    taskDetails = finaltaskdetailsarray
                }
                let TaskAssign = { ...req.body }
                delete TaskAssign.assignperson

                let isAddData = 0;
                let isValidWeekDay = 1;

                const nextdate = new Date(); // Initialize once and reuse
                if (TaskAssign.recurrencetypeid === Config.tasktype.Weekly) {
                    const days = req.body.selecteddays || [];
                    const currentDay = nextdate.getDay(); // 0 (Sunday) - 6 (Saturday)

                    // Check if the current day is included in the selected days
                    if (!days.includes(currentDay)) {
                        isValidWeekDay = 0;
                    }
                } else if (TaskAssign.recurrencetypeid === Config.tasktype.Monthly) {
                    const days = req.body.selecteddates || [];
                    const currentDate = nextdate.getDate(); // 1 - 31

                    // Check if the current date is included in the selected dates
                    if (!days.includes(currentDate)) {
                        isValidWeekDay = 0;
                    }
                } else if (TaskAssign.recurrencetypeid === Config.tasktype.Custom) {
                    const days = req.body.dates || [];
                    const customDate = IISMethods.getDateFormats(nextdate, 1, true);

                    // Check if the custom formatted date is included in the specified dates
                    if (!days.includes(customDate)) {
                        isValidWeekDay = 0;
                    }
                } else if (TaskAssign.recurrencetypeid === Config.tasktype.Daily) {
                    isValidWeekDay = 1
                }

                if ((!defaultExpiryDate || defaultExpiryDate >= IISMethods.getDateFormats(systemdate, 1, true)) && isValidWeekDay == 1) {
                    isAddData = 1
                }

                if (isAddData == 1) {
                    // const taskcode = await MainDB.getseriesno(ObjectId(seriesData.companyid),ObjectId(seriesData.propertyid),ObjectId(seriesData._id),"taskassign",new _Task(),"",maxid)
                    // TaskAssign.seriesid = seriesData._id
                    // TaskAssign.taskcode = taskcode ? taskcode : ""
                    // TaskAssign.maxid = maxid
                    // maxid++

                    TaskAssign.recordinfo = {
                        entryuid: req.headers.uid,
                        entryby: req.headers.username,
                        entrydate: IISMethods.getDateFormats(new Date(systemdate), 14, true),
                        timestamp: IISMethods.getDateFormats(new Date(systemdate), 12, true),
                        updateuid: req.headers.uid,
                        updateby: req.headers.username,
                        updatedate: IISMethods.getDateFormats(new Date(systemdate), 14, true)
                    }

                    TaskAssign.taskdefaultid = taskdefaultid
                    TaskAssign._id = ObjectId()
                    TaskAssign.assignbypersonid = req.headers.uid
                    TaskAssign.assignbyperson = req.headers.personname
                    TaskAssign.assignpersons = req.body.assignperson
                    TaskAssign.propertyid = req.headers.propertyid
                    TaskAssign.property = req.headers.property

                    const checklistPipeline = [{ $match: { _id: ObjectId(req.body.checklistid) } }]
                    const checklistResp = await MainDB.getmenual("tblchecklist", new _Checklist(), checklistPipeline)

                    if (checklistResp.ResultData.length) {
                        TaskAssign.checklists = checklistResp.ResultData[0].checklists
                    }

                    if (req.body.assignperson && req.body.assignperson.length && !req.body.assignperson) {
                        TaskAssign.assignpersons = req.body.assignperson

                        if (req.body.assignperson.length == 1) {
                            TaskAssign.assignpersonid = req.body.assignperson[0].assignpersonid
                            TaskAssign.assignperson = req.body.assignperson[0].assignperson
                            TaskAssign.assignpersons = []
                        }
                    }


                    if (!TaskAssign.assignperson) {
                        TaskAssign.acceptedtasktime = null
                        TaskAssign.ishidestartbtn = 3
                        TaskAssign.taskstatuscolor = Config.taskstatus.unassigned.taskstatuscolor
                        TaskAssign.taskstatusid = Config.taskstatus.unassigned.taskstatusid
                        TaskAssign.taskstatus = Config.taskstatus.unassigned.taskstatus
                    } else {
                        TaskAssign.acceptedtasktime = new Date()
                        TaskAssign.ishidestartbtn = 0
                        TaskAssign.taskstatuscolor = Config.taskstatus.open.taskstatuscolor
                        TaskAssign.taskstatusid = Config.taskstatus.open.taskstatusid
                        TaskAssign.taskstatus = Config.taskstatus.open.taskstatus
                    }

                    TaskAssign.showtaskdate = new Date()
                    TaskAssign.startdate = new Date()
                    TaskAssign.tasktime = new Date()

                    TaskAssign.log = [
                        {
                            statusid: TaskAssign.taskstatusid,
                            status: TaskAssign.taskstatus,
                            backgroundcolor: TaskAssign.taskstatuscolor,
                            personid: req.headers.uid,
                            person: req.headers.personname,
                            logdatetime: new Date(),
                            assignedto: TaskAssign.assignpersons,
                            logtype: 1
                        }
                    ]

                    TaskArray.push({ ...TaskAssign })
                }


                if (TaskArray.length > 0) {
                    for (var obj of TaskArray) {
                        obj._id = ObjectId()

                        //Start: Insert TaskStatusLog Data
                        await MainDB.InsertTaskStatusLog(obj, systemdate)
                        //End: Insert TaskStatusLog Data
  
                        // Start: task add log
                        let reqData = {
                            taskid: obj._id,
                            userid: ObjectId(req.headers.uid),
                            username: req.headers.personname,
                            datetime: new Date(),
                            actionid: Config.dummyObjid,
                            action_name: obj.taskstatus,
                            comment: "",
                            hkcomments: "",
                            taskstatustype: obj.taskstatustype,
                            taskstatusid: ObjectId(obj.taskstatusid),
                            taskstatus: obj.taskstatus,
                            logtype: 1,
                            flag: 0,
                            recordinfo: {
                                entryuid: req.headers.uid,
                                entryby: req.headers.username,
                                entrydate: new Date(systemdate).toISOString().replace(/T/, " ").replace(/\..+/, ""),
                                timestamp: new Date(systemdate).getTime()
                            }
                        }
                        await MainDB.addTaskLogs(reqData)

                        if (obj.comment) {
                            let reqData = {
                                taskid: obj._id,
                                userid: ObjectId(req.headers.uid),
                                username: req.headers.personname,
                                datetime: new Date(),
                                actionid: Config.dummyObjid,
                                action_name: obj.taskstatus,
                                taskstatustype: obj.taskstatustype,
                                taskstatusid: ObjectId(Config.dummyObjid),
                                taskstatus: obj.taskstatus,
                                logtype: 1,
                                flag: 0,
                                recordinfo: {
                                    entryuid: req.headers.uid,
                                    entryby: req.headers.username,
                                    entrydate: IISMethods.getCustomDatetimestr(systemdate),
                                    timestamp: new Date(systemdate).getTime()
                                }
                            }
                            await MainDB.addTaskLogs(reqData)
                        }

                        if (Array.isArray(obj.images) && obj.images.length) {
                            const reqData = {
                                taskid: obj._id,
                                userid: ObjectId(req.headers.uid),
                                username: req.headers.username,
                                datetime: new Date(),
                                actionid: Config.dummyObjid,
                                action_name: "Attachments Added",
                                taskstatustype: "",
                                taskstatusid: ObjectId(Config.dummyObjid),
                                taskstatus: "",
                                logtype: 1,
                                flag: 0,
                                recordinfo: {
                                    entryuid: req.headers.uid,
                                    entryby: req.headers.username,
                                    entrydate: IISMethods.getCustomDatetimestr(systemdate),
                                    timestamp: new Date(systemdate).getTime()
                                }
                            }
                            await MainDB.addTaskLogs(reqData)
                        }
                    }

                    const takResp = await MainDB.InsertMany("tbltask", new _Task(), TaskArray)

                    // if (takResp.status == 200) {
                    //     for (var obj of TaskArray) {
                    //         const a = await MainDB.AlltaskLog({
                    //             taskid: obj._id,
                    //             type: "manually",
                    //             action: "add",
                    //             reqbody: Defaultreqbody,
                    //             taskdata: obj
                    //         })
                    //         // const analyticsdata = await MainDB.analyticssocket({
                    //         //     headers: req.headers,
                    //         //     propertyid: obj.propertyid,
                    //         //     buildingid: obj.buildingid,
                    //         //     wingid: obj.wingid,
                    //         //     categoryid: obj.categoryid,
                    //         //     assignmentforid: obj.assignmentforid
                    //         // })

                    //         // IISMethods.emitRoomWiseSocket({
                    //         //     to: [`${req.headers.subdomainname}analytics${obj.propertyid.toString()}`],
                    //         //     on: Config.getSocketTriggers()["frontdeskanalytics"],
                    //         //     data: analyticsdata
                    //         // })
                    //     }
                    // }

                    //PARTH
                    // IISMethods.emitRoomWiseSocket({
                    //     to: [`${req.headers.subdomainname}${req.body.propertyid}`],
                    //     on: Config.getSocketTriggers()["taskdataupdate"],
                    //     data: SocketData.socketdata
                    // })
                    if (takResp.status == 200) {
                        // await MainDB.InsertMany("tblnotification", new _Notification(), notificationArray)
                        const resp = await MainDB.executedata("i", new _TaskDefault(), "tbltaskscheduler", req.body)
                        ResponseBody.status = resp.status
                        ResponseBody.message = resp.message
                    } else {
                        ResponseBody.status = takResp.status
                        ResponseBody.message = takResp.message
                    }
                } else {

                    const resp = await MainDB.executedata("i", new _TaskDefault(), "tbltaskscheduler", req.body)
                    ResponseBody.status = resp.status
                    ResponseBody.message = resp.message
                    // ResponseBody.status = 200
                    // ResponseBody.message = Config.getErrmsg()["tasknotfound"]
                }


            } else {
                const resp = await MainDB.executedata("i", new _TaskDefault(), "tbltaskscheduler", req.body)
                ResponseBody.status = resp.status
                ResponseBody.message = resp.message
            }

            req.ResponseBody = ResponseBody; next()
        } catch (err) {

            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }; next()
        }
    }

    // Update Schdule Task
    async ScheduleTaskUpdate(req, res, next) {
        try {
            const ResponseBody = {}
            const ObjectId = IISMethods.getobjectid()

            const pipeline = [{ $match: { '_id': ObjectId(req.body._id) } }]
            const record = await MainDB.getmenual(TableName, new _TaskDefault(), pipeline)

            var RecordInfo = record.ResultData[0].recordinfo
            RecordInfo.updateuid = req.headers.uid
            RecordInfo.updateby = req.headers.personname
            RecordInfo.updatedate = IISMethods.getdatetimeisostr()
            req.body.recordinfo = RecordInfo

            const resp = await MainDB.executedata("u", new _TaskDefault(), "tbltaskscheduler", req.body)

            ResponseBody.status = resp.status
            ResponseBody.message = resp.message
            ResponseBody.data = resp.data

            req.ResponseBody = ResponseBody;
            next()
        } catch (err) {

            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }; next()
        }
    }


    // Delete Schedule Task
    async ScheduleTaskDelete(req, res, next) {
        try {
            const ResponseBody = {}
            const resp = await MainDB.executedata("d", new _TaskDefault(), "tbltaskscheduler", req.body)

            ResponseBody.status = resp.status
            ResponseBody.message = resp.message

            req.ResponseBody = ResponseBody; next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }; next()
        }
    }


    //Update
    // async UpdateTask(req, res, next) {
    //     try {
    //         const ResponseBody = {}
    //         ResponseBody.status = 401
    //         ResponseBody.message = Config.getResponsestatuscode()["401"]

    //         const Defaultreqbody = req.body

    //         const ObjectId = IISMethods.getobjectid()

    //         const systemdate = req.headers.systemdate
    //         const timezone = req.headers.timezone || FieldConfig.timezone

    //         const DF = new _EmployeeRewardPoint()

    //         let userpipeline = [{ $match: { _id: ObjectId(req.headers.uid) } }]

    //         var userResp = await MainDB.getmenual("tblpersonmaster", new _Person(), userpipeline)

    //         if (userResp.ResultData.length) {
    //             var userResult = userResp.ResultData[0]

    //             let pipeline = [{ $match: { _id: ObjectId(req.body._id) } }]
    //             var record = await MainDB.getmenual(TableName, new _Task(), pipeline)

    //             if (record.ResultData.length > 0) {
    //                 let result = record.ResultData[0]

    //                 if (req.body.comment) {
    //                     const comment = req.body.comment
    //                     const TaskLogPipeline = [
    //                         {
    //                             $match: { taskid: ObjectId(result._id) }
    //                         },
    //                         {
    //                             $sort: {
    //                                 _id: -1
    //                             }
    //                         }
    //                     ]
    //                     var TaskLogResp = await MainDB.getmenual("tbltasklog", new TaskLog(), TaskLogPipeline)
    //                     let FindComment = TaskLogResp.ResultData.find((obj) => obj.comment == comment)
    //                     if (!FindComment) {
    //                         let commentlog = 0
    //                         if (comment) commentlog = 1;
    //                         // let commentLogStatus = null
    //                         // if(commentlog){
    //                         //     const TaskLogPipeline =  [{ $match: { status : "Comment"} }]
    //                         //     const commentStatusResp = await MainDB.getmenual("tbltaskstatusmaster", new TaskStatus(), TaskLogPipeline);
    //                         //     commentLogStatus = commentStatusResp.ResultData[0] || null;
    //                         // }
    //                         //*************Start Task Log*************//
    //                         var reqData = {
    //                             taskid: req.body._id,
    //                             userid: ObjectId(req.headers.uid),
    //                             username: req.headers.username,
    //                             datetime: new Date(),// Parth ~ 2024-06-05 ~ 02:55 PM ~ Add New Date
    //                             actionid: Config.dummyObjid,
    //                             action_name: commentlog ? "" : TaskLogResp.ResultData[0]?.action_name,
    //                             action_name: "",
    //                             comment: comment,
    //                             hkcomments: req.body.hkcomments,
    //                             taskstatustype: commentlog ? "" : TaskLogResp.ResultData[0]?.taskstatustype,
    //                             taskstatusid: commentlog ? Config.dummyObjid : ObjectId(TaskLogResp.ResultData[0]?.taskstatusid),
    //                             taskstatus: commentlog ? "" : TaskLogResp.ResultData[0]?.taskstatus,
    //                             logtype: 1,
    //                             commentlog: commentlog,
    //                             svg: commentlog ? Config.commentsvg : TaskLogResp.ResultData[0]?.svg,
    //                             flag: 0,
    //                             recordinfo: {
    //                                 entryuid: req.headers.uid,
    //                                 entryby: req.headers.username,
    //                                 entrydate: IISMethods.getCustomDatetimestr(systemdate),
    //                                 timestamp: new Date(systemdate).getTime()
    //                             }
    //                         }
    //                         await MainDB.addTaskLogs(reqData)
    //                         //*************End Task Log*************//
    //                     }
    //                 }

    //                 let dataOfReservedone = []

    //                 if (req.body.accepttask == 1 && result.assignperson) {
    //                     ResponseBody.status = 400
    //                     ResponseBody.message = Config.getErrmsg()["alreadyaccepted"]
    //                 } else if (req.body.isacceptedtask == 1 && result.verifyperson) {
    //                     ResponseBody.status = 400
    //                     ResponseBody.message = Config.getErrmsg()["alreadyaccepted"]
    //                 } else if (req.body.categoryid == Config.taskcategory.maintenance && (Array.isArray(req.body.productdata) && req.body.productdata.length)) {
    //                     if (req.body.assignmentforid == Config.amenitiescategoryroom && (req.body.isoutoforder == 1 || req.body.isoutofinventory == 1)) {
    //                         let reservationArrPromise = []
    //                         for (const room of req.body.productdata) {

    //                             let checkindate = IISMethods.getTimezoneWiseDate({ date: req.body.fromoutoforderdate, timezone })
    //                             let checkoutdate = IISMethods.getTimezoneWiseDate({ date: req.body.tooutoforderdate, timezone })

    //                             if (req.body.isoutofinventory == 1) {
    //                                 checkindate = IISMethods.getTimezoneWiseDate({ date: req.body.fromoutofinventorydate, timezone })
    //                                 checkoutdate = IISMethods.getTimezoneWiseDate({ date: req.body.tooutofinventorydate, timezone })
    //                             }

    //                             const filterObj = {
    //                                 roomnoid: ObjectId(room.arearoomnoid),
    //                                 ischeckout: 0,
    //                                 iscancel: 0,
    //                                 ischeckout: 0,
    //                                 $expr: {
    //                                     $or: [
    //                                         // ischeckinbetween
    //                                         {
    //                                             $and: [
    //                                                 { $lt: ["$_checkindate", IISMethods.getFormatWiseDate(checkindate)] },
    //                                                 { $gt: ["$_checkoutdate", IISMethods.getFormatWiseDate(checkindate)] }
    //                                             ]
    //                                         },
    //                                         // ischeckoutbetween
    //                                         {
    //                                             $and: [
    //                                                 { $lt: ["$_checkindate", IISMethods.getFormatWiseDate(checkoutdate)] },
    //                                                 { $gt: ["$_checkoutdate", IISMethods.getFormatWiseDate(checkoutdate)] }
    //                                             ]
    //                                         },
    //                                         // isreservationbetween
    //                                         {
    //                                             $and: [
    //                                                 { $gte: ["$_checkindate", IISMethods.getFormatWiseDate(checkindate)] },
    //                                                 { $lte: ["$_checkoutdate", IISMethods.getFormatWiseDate(checkoutdate)] }
    //                                             ]
    //                                         },
    //                                         {
    //                                             $and: [
    //                                                 { $eq: ["$_checkindate", IISMethods.getFormatWiseDate(checkindate)] },
    //                                                 { $eq: ["$_checkindate", IISMethods.getFormatWiseDate(checkoutdate)] }
    //                                             ]
    //                                         },
    //                                         {
    //                                             $and: [
    //                                                 { $eq: ["$_checkoutdate", IISMethods.getFormatWiseDate(checkindate)] },
    //                                                 { $eq: ["$_checkoutdate", IISMethods.getFormatWiseDate(checkoutdate)] }
    //                                             ]
    //                                         }
    //                                     ]
    //                                 }
    //                             }
    //                             const reservationPipeline = [
    //                                 {
    //                                     $addFields: {
    //                                         _checkindate: {
    //                                             $dateToString: {
    //                                                 format: "%Y-%m-%d",
    //                                                 date: "$checkindate",
    //                                                 timezone: timezone
    //                                             }
    //                                         },
    //                                         _checkoutdate: {
    //                                             $dateToString: {
    //                                                 format: "%Y-%m-%d",
    //                                                 date: "$checkoutdate",
    //                                                 timezone: timezone
    //                                             }
    //                                         }
    //                                     }
    //                                 },
    //                                 {
    //                                     $match: filterObj
    //                                 },
    //                                 { $project: { roomno: 1 } }
    //                             ]
    //                             reservationArrPromise.push(MainDB.getmenual("tblreservation", new Reservation(), reservationPipeline))
    //                         }
    //                         const reservation = await Promise.all(reservationArrPromise)
    //                         dataOfReservedone = reservation.flatMap((entry) => entry.ResultData)
    //                         if (dataOfReservedone.length && (req.body.isoutoforder == 1 || req.body.isoutofinventory == 1)) {
    //                             const message = req.body.isoutoforder == 1 ? "out of Order" : "out of Inventory"
    //                             ResponseBody.status = 409
    //                             ResponseBody.message = `you can't put this room ${message} because room ${dataOfReservedone.map((obj) => obj.roomno).join(", ")} is already occupied by the guest`
    //                         }
    //                     }
    //                 } else {
    //                     let categoryPipeline = [
    //                         {
    //                             $match: {
    //                                 _id: ObjectId(result.categoryid)
    //                             }
    //                         }
    //                     ]

    //                     var categoryResp = await MainDB.getmenual("tbltaskcategory", new TaskCategory(), categoryPipeline)
    //                     var categoryResult = categoryResp.ResultData[0]

    //                     let TaskAssign = { ...req.body }

    //                     TaskAssign.categoryid = req.body.categoryid ? ObjectId(req.body.categoryid) : ObjectId(result.categoryid)

    //                     //Add Images
    //                     var imagesArray = []
    //                     var oldimagearray = result.images
    //                     if (oldimagearray.length > 0) {
    //                         imagesArray = oldimagearray
    //                     }
    //                     var imagecount = req.body.imagecount
    //                     var isrequiredphoto = req.body.isrequiredphoto
    //                     var isinspectionphoto = req.body.isinspectionphoto

    //                     // for (let j = 0; j < imagecount; j++) {
    //                     if (Array.isArray(req.body.images)) {
    //                         let imageslog = [];
    //                         for (const objimage of req.body.images) {  // 11-03-24 Abhi Shah // ! Changed formdata to body
    //                             // let image = IISMethods.getfilepath(req.headers.subdomainname, req.files["image" + j].name)
    //                             // var imagepath = await IISMethods.uploadToS3(req.files["image" + j], image)
    //                             let image = IISMethods.getfilepath(req.headers.subdomainname, objimage)
    //                             var imagepath = await IISMethods.uploadToS3(objimage, image)
    //                             var imagepathjson = {
    //                                 isrequiredphoto: isrequiredphoto,
    //                                 isinspectionphoto: isinspectionphoto,
    //                                 uploadedbypersonid: ObjectId(req.headers.uid),
    //                                 uploadedbypersonname: userResult.personname,
    //                                 image: imagepath,
    //                                 entrydate: new Date(systemdate)
    //                             }
    //                             imagesArray.push(imagepathjson)
    //                             imageslog.push({  // 21-03-24 Abhi Shah
    //                                 "image": imagepath
    //                             });

    //                             TaskAssign.images = imagesArray
    //                         }

    //                         const TaskLogPipeline = [
    //                             {
    //                                 $match: { taskid: ObjectId(result._id) }
    //                             },
    //                             {
    //                                 $sort: {
    //                                     _id: -1
    //                                 }
    //                             }
    //                         ]
    //                         var TaskLogResp = await MainDB.getmenual("tbltasklog", new TaskLog(), TaskLogPipeline)

    //                         var reqData = {
    //                             taskid: req.body._id,
    //                             userid: ObjectId(req.headers.uid),
    //                             username: req.headers.username,
    //                             datetime: new Date(),// Parth ~ 2024-06-05 ~ 02:55 PM ~ Add New Date
    //                             actionid: Config.dummyObjid,
    //                             action_name: "Attachments Added",
    //                             taskstatustype: "",// Vivek ~ 2024-05-07 ~ 11:56 AM
    //                             taskstatusid: Config.dummyObjid,// Vivek ~ 2024-05-07 ~ 11:56 AM
    //                             taskstatus: "",// Vivek ~ 2024-05-07 ~ 11:56 AM
    //                             // taskstatustype: TaskLogResp.ResultData[0]?.taskstatustype,
    //                             // taskstatusid: ObjectId(TaskLogResp.ResultData[0]?.taskstatusid),
    //                             // taskstatus: TaskLogResp.ResultData[0]?.taskstatus,
    //                             logtype: 1,
    //                             imageslog: imageslog,
    //                             svg: Config.attachmentsvg,
    //                             flag: 0,
    //                             recordinfo: {
    //                                 entryuid: req.headers.uid,
    //                                 entryby: req.headers.username,
    //                                 entrydate: IISMethods.getCustomDatetimestr(systemdate),
    //                                 timestamp: new Date(systemdate).getTime()
    //                             }
    //                         }
    //                         await MainDB.addTaskLogs(reqData)
    //                     }

    //                     var RecordInfo = result.recordinfo
    //                     RecordInfo.updateuid = req.headers.uid
    //                     RecordInfo.updateby = req.headers.username
    //                     RecordInfo.updatedate = IISMethods.getCustomDatetimestr(systemdate)

    //                     let roomcategoryidarray = [ObjectId(Config.dummyObjid)]
    //                     let roomtypeidarray = [ObjectId(Config.dummyObjid)]
    //                     let roomestimationResp = []
    //                     // Get All Room
    //                     const roomResp = await MainDB.getmenual("tblpropertyroomconfiguration", new PropertyRoomConfiguration(), [{ $match: { _id: ObjectId(req.body.roomnoid) } }])
    //                     const roomResult = roomResp.ResultData
    //                     roomcategoryidarray = roomResult.map((obj) => ObjectId(obj.roomcategoryid))
    //                     roomtypeidarray = roomResult.map((obj) => ObjectId(obj.roomtypeid))

    //                     //Get room wise estimation data
    //                     roomestimationResp = await MainDB.getmenual("tblroomestimation", new RoomEstimationMaster(), [
    //                         {
    //                             $match: {
    //                                 propertyid: ObjectId(req.body.propertyid),
    //                                 roomcategoryid: { $in: roomcategoryidarray },
    //                                 roomtypeid: { $in: roomtypeidarray },
    //                             }
    //                         }
    //                     ])
    //                     //Get room wise estimation data

    //                     TaskAssign.recordinfo = RecordInfo
    //                     if (req.body.readingitems) {
    //                         TaskAssign.readingitems = JSON.parse(req.body.readingitems)
    //                     }
    //                     var taskstatusname = ""
    //                     if (req.body.departments) {
    //                         TaskAssign.departments = JSON.parse(req.body.departments)
    //                     }

    //                     if (req.body.assignperson && !TaskAssign.assignperson) {
    //                         TaskAssign.assignpersons = JSON.parse(TaskAssign.assignpersons)

    //                         if (TaskAssign.assignpersons.length == 1) {
    //                             TaskAssign.assignpersonid = TaskAssign.assignpersons[0].assignpersonid
    //                             TaskAssign.assignperson = TaskAssign.assignpersons[0].assignperson
    //                             TaskAssign.assignpersons = []
    //                         }
    //                     }

    //                     if (TaskAssign.assignpersonid && TaskAssign.assignperson) {
    //                         let userpipeline = [{ $match: { _id: ObjectId(TaskAssign.assignpersonid) } }]

    //                         var userResp = await MainDB.getmenual("tblpersonmaster", new _Person(), userpipeline)

    //                         if (req.body.accepttask == 1 || result.assignpersonid != TaskAssign.assignpersonid) {

    //                             if (req.headers.uid != TaskAssign.assignpersonid) {
    //                                 TaskAssign.assignbypersonid = ObjectId(req.headers.uid)
    //                                 TaskAssign.assignbyperson = req.headers.username
    //                             }

    //                             // if (req.body.assignpersonid == result.assignbypersonid.toString()) {
    //                             //     TaskAssign.assignbypersonid = ObjectId(Config.dummyObjid)
    //                             //     TaskAssign.assignbyperson = ""
    //                             // }

    //                             TaskAssign.ishidestartbtn = 0
    //                             TaskAssign.tasktime = new Date()
    //                             TaskAssign.acceptedtasktime = new Date()
    //                             taskstatusname = "Open"
    //                             var taskcategorytype = Config.newTaskStatusType[result.categoryid]?.open

    //                             //Harsh V. 19/05/2023
    //                             // if (result.reservationid.toString() != Config.dummyObjid) {
    //                             //     var guestReservationExist = 1
    //                             // }

    //                             //Harsh V. 31/05/2023
    //                             if (req.body.ischeckoutrequest) {

    //                                 // Update Task Data
    //                                 await MainDB.updateGuestCheckoutTask({
    //                                     reservation: result.reservationid.toString(),
    //                                     systemDate: systemdate,
    //                                     timezone: timezone,
    //                                     taskresult: result
    //                                 })
    //                             }

    //                             // !---- Harsh V - 15/06/2023 
    //                             if (result.categoryid?.toString() == Config.taskcategory.frontdesk && (result.subcategoryid?.toString() == Config.latecheckoutsubcategoryid || result.subcategoryid?.toString() == Config.checkoutsubcategoryid)) {
    //                                 if (result.reservationid.toString() != Config.dummyObjid) {
    //                                     //List reservation to get roomnoid for guest experience socket   
    //                                     const reservationPipeline = { _id: ObjectId(result.reservationid) }
    //                                     const reservationResp = await MainDB.FindOne('tblreservation', new Reservation(), reservationPipeline)

    //                                     //Store roomnoid 
    //                                     let roomnoId = Config.dummyObjid
    //                                     if (reservationResp) roomnoId = reservationResp.roomnoid ? reservationResp.roomnoid : Config.dummyObjid

    //                                     let guestExpSocketData = {}
    //                                     if (result.subcategoryid?.toString() == Config.latecheckoutsubcategoryid) { //latecheckout 
    //                                         guestExpSocketData.guestlatecheckoutrequest = 1, guestExpSocketData.guestlatecheckoutmessage = Config.errmsg.latecheckoutreqaccepted
    //                                     } else if (result.subcategoryid?.toString() == Config.checkoutsubcategoryid) { //checkout 
    //                                         guestExpSocketData.guestcheckoutrequest = 1, guestExpSocketData.checkoutrequeststatus = 2, guestExpSocketData.guestcheckoutmessage = Config.errmsg.checkoutreqaccepted, guestExpSocketData.isguestexpcheckout = reservationResp?.isguestexpcheckout, guestExpSocketData.isguestcheckout = reservationResp?.isguestcheckout
    //                                     }
    //                                 }
    //                             }
    //                             // ----! 
    //                         }
    //                     } else {
    //                         if (req.body.removeassigneeperson && req.body.removeassigneeperson != "0") {
    //                             TaskAssign.assignpersonid = ObjectId(Config.dummyObjid)
    //                             TaskAssign.assignperson = ""
    //                             taskstatusname = "Unassigned"
    //                             var taskcategorytype = Config.newTaskStatusType[result.categoryid]?.unassigned
    //                             TaskAssign.ishidestartbtn = 3
    //                             TaskAssign.acceptedtasktime = null
    //                         }
    //                     }

    //                     if (taskstatusname) {
    //                         TaskAssign.taskstatuscolor = Config.dummycolor
    //                         TaskAssign.taskstatusid = ObjectId(Config.dummyObjid)

    //                         TaskAssign.taskstatus = taskstatusname
    //                         TaskAssign.taskstatustype = taskcategorytype

    //                         //Get Task Status details
    //                         let taskstatusPipeline = [
    //                             {
    //                                 $match: {
    //                                     taskcategoryid: ObjectId(result.categoryid),
    //                                     statustype: taskcategorytype
    //                                 }
    //                             }
    //                         ]

    //                         var taskstatusResp = await MainDB.getmenual("tbltaskstatusmaster", new TaskStatus(), taskstatusPipeline)
    //                         if (taskstatusResp.ResultData.length > 0) {
    //                             let taskstatusResult = taskstatusResp.ResultData[0]
    //                             TaskAssign.taskstatuscolor = taskstatusResult.backgroundcolor
    //                             TaskAssign.taskstatusid = ObjectId(taskstatusResult._id)
    //                             TaskAssign.taskstatus = taskstatusResult.status
    //                             TaskAssign.taskstatustype = taskstatusResult.statustype
    //                             if (req.body.accepttask == 1 || result.assignpersonid != TaskAssign.assignpersonid) {
    //                                 //*************Start Task Log*************//
    //                                 let commentlog = 0
    //                                 if (TaskAssign.comment) commentlog = 1;

    //                                 // let commentLogStatus = null
    //                                 // if(commentlog){
    //                                 //     const TaskLogPipeline =  [{ $match: { status : "Comment"} }]
    //                                 //     const commentStatusResp = await MainDB.getmenual("tbltaskstatusmaster", new TaskStatus(), TaskLogPipeline);
    //                                 //     commentLogStatus = commentStatusResp.ResultData[0] || null;
    //                                 // }

    //                                 var reqData = {
    //                                     taskid: req.body._id,
    //                                     userid: ObjectId(req.headers.uid),
    //                                     username: req.headers.username,
    //                                     datetime: new Date(),// Parth ~ 2024-06-05 ~ 02:55 PM ~ Add New Date
    //                                     actionid: Config.dummyObjid,
    //                                     action_name: commentlog ? "" : taskstatusResult.status,
    //                                     comment: TaskAssign.comment,
    //                                     hkcomments: TaskAssign.hkcomments,
    //                                     taskstatustype: commentlog ? "" : taskstatusResult.statustype,
    //                                     taskstatusid: commentlog ? Config.dummyObjid : ObjectId(taskstatusResult._id),
    //                                     taskstatus: commentlog ? "" : taskstatusResult.status,
    //                                     logtype: 1,
    //                                     commentlog: commentlog,
    //                                     svg: commentlog ? Config.commentsvg : taskstatusResult.statussvg,
    //                                     flag: 0,
    //                                     recordinfo: {
    //                                         entryuid: req.headers.uid,
    //                                         entryby: req.headers.username,
    //                                         entrydate: IISMethods.getCustomDatetimestr(new Date(systemdate)),
    //                                         timestamp: new Date(systemdate).getTime()
    //                                     }
    //                                 }
    //                                 await MainDB.addTaskLogs(reqData)
    //                                 // await MainDB.executedata("i", new _TaskLog(), "tbltasklog", reqData)
    //                                 //*************End Task Log*************//

    //                                 // *******Update Task Status Log Data*******
    //                                 await MainDB.getTaskStatusLogData(req.body._id, result.taskstatusid, taskstatusResult._id, new Date())
    //                                 // *******Update Task Status Log Data*******
    //                             }
    //                         }
    //                     }

    //                     if (req.body.isacceptedtask == 1) {
    //                         let userpipeline = [{ $match: { _id: ObjectId(req.headers.uid) } }]
    //                         var userResp = await MainDB.getmenual("tblpersonmaster", new _Person(), userpipeline)
    //                         if (userResp.ResultData.length) {
    //                             if (req.headers.uid != TaskAssign.assignpersonid) {
    //                                 TaskAssign.verifypersonid = ObjectId(req.headers.uid)
    //                                 TaskAssign.verifyperson = userResp.ResultData[0].personname
    //                             }
    //                         }
    //                         TaskAssign.tasktime = new Date()
    //                         TaskAssign.verifyacceptedtasktime = new Date()
    //                         TaskAssign.verifyishidestartbtn = 6

    //                     }

    //                     if (req.body.priorityid) {
    //                         //Add Priority
    //                         var priorityPipeline = [
    //                             {
    //                                 $match: {
    //                                     _id: ObjectId(req.body.priorityid)
    //                                 }
    //                             }
    //                         ]

    //                         var priorityResp = await MainDB.getmenual("tblpriority", new Priority(), priorityPipeline, "", "", true, MainDB)
    //                         if (priorityResp.ResultData.length > 0) {
    //                             TaskAssign.priorityid = ObjectId(req.body.priorityid)
    //                             TaskAssign.priority = priorityResp.ResultData[0].name
    //                             TaskAssign.prioritycolor = priorityResp.ResultData[0].color
    //                         }
    //                     }

    //                     TaskAssign.subcategoryid = req.body.subcategoryid ? req.body.subcategoryid : result.subcategoryid
    //                     TaskAssign.categoryid = req.body.categoryid ? req.body.categoryid : result.categoryid //Harsh V - 16/08/2023 

    //                     var isUpdate = 1
    //                     var isExistTask = 0

    //                     if (req.body.checklistids) {
    //                         TaskAssign.checklistids = JSON.parse(req.body.checklistids)
    //                     }

    //                     if (req.body.subcategoryid) {
    //                         if (TaskAssign.categoryid == Config.taskcategory.housekeeper) {
    //                             if (result.roomno || result.area) {
    //                                 let taskCleanPipeline = [];

    //                                 if (result.roomno) {
    //                                     taskCleanPipeline.push({
    //                                         $match: {
    //                                             roomnoid: ObjectId(result.roomnoid)
    //                                         }
    //                                     })
    //                                 } else {
    //                                     taskCleanPipeline.push({
    //                                         $match: {
    //                                             areaid: ObjectId(result.areaid)
    //                                         }
    //                                     })
    //                                 }

    //                                 taskCleanPipeline.push([
    //                                     {
    //                                         $match: {
    //                                             _id: { $ne: ObjectId(req.body._id) },
    //                                             categoryid: ObjectId(Config.taskcategory.housekeeper),
    //                                             propertyid: ObjectId(req.body.propertyid),
    //                                             $or: [
    //                                                 {
    //                                                     iscompleted: { $ne: 1 }
    //                                                 },
    //                                                 {
    //                                                     iscompleted: { $eq: 1 },
    //                                                     $or: [
    //                                                         {
    //                                                             dualauthentication: 1
    //                                                         },
    //                                                         {
    //                                                             dualauthenticationwithphoto: 1
    //                                                         }
    //                                                     ],
    //                                                     istaskservicetag: 0,
    //                                                     isverify: { $ne: 1 }
    //                                                 }
    //                                             ]
    //                                         }
    //                                     },
    //                                     {
    //                                         $addFields: {
    //                                             _startdate: {
    //                                                 $dateToString: {
    //                                                     format: "%Y-%m-%d",
    //                                                     date: "$startdate",
    //                                                     timezone: timezone
    //                                                 }
    //                                             }
    //                                         }
    //                                     },
    //                                     {
    //                                         $match: {
    //                                             _startdate: { $eq: IISMethods.getDateFormats(systemdate, 1, true) },
    //                                         }
    //                                     }
    //                                 ])


    //                                 var taskCleanResp = await MainDB.getmenual("tbltaskassign", new _Task(), taskCleanPipeline)
    //                                 var taskCleanResult = taskCleanResp.ResultData

    //                                 if (TaskAssign.subcategoryid == Config.taskevent.checkin || TaskAssign.subcategoryid == Config.taskevent.checkout) {
    //                                     isExistTask = 2 // Not add to Checkin or checkout task
    //                                 } else if (taskCleanResult.length > 0) {
    //                                     isExistTask = 1 // Clean status Task already exist
    //                                 }
    //                             }
    //                         }

    //                         // const checklistLogs = await MainDB.FindOne("tbltaskchecklist", new TaskCheckList(), {
    //                         //     taskid: ObjectId(req.body._id),
    //                         //     flag: {$ne:0},
    //                         // })
    //                         if (
    //                             (/*checklistLogs ||*/ result.taskstarttime || result.taskprogresstime || result.iscompleted == 1) &&
    //                             (req.body.subcategoryid != result.subcategoryid.toString() && TaskAssign.categoryid == Config.taskcategory.housekeeper) &&
    //                             isExistTask == 0
    //                         ) {
    //                             isUpdate = 0
    //                         } else {
    //                             var tasksubcategorypipeline = [{ $match: { _id: ObjectId(req.body.subcategoryid) } }]
    //                             const tasksubcategoryResp = await MainDB.getmenual(
    //                                 "tbltasksubcategory",
    //                                 new TaskSubCategory(),
    //                                 tasksubcategorypipeline
    //                             )

    //                             if (tasksubcategoryResp.ResultData.length > 0) {
    //                                 TaskAssign.taskeventid = tasksubcategoryResp.ResultData[0].taskeventid
    //                                 TaskAssign.taskevent = tasksubcategoryResp.ResultData[0].taskevent
    //                                 TaskAssign.subcategoryid = req.body.subcategoryid
    //                                 TaskAssign.subcategory = req.body.subcategory
    //                                 TaskAssign.subcategorycolor = tasksubcategoryResp.ResultData[0].backgroundcolor
    //                                 TaskAssign.subcategorysvg = tasksubcategoryResp.ResultData[0].svg
    //                                 TaskAssign.subcategoryminutes = tasksubcategoryResp.ResultData[0].minutes || 0
    //                                 TaskAssign.subcategoryinspectionminutes = tasksubcategoryResp.ResultData[0].inspectionminutes || 0
    //                             }
    //                             if (roomestimationResp?.ResultData?.length && roomResult && TaskAssign?.categoryid?.toString() == Config.taskcategory.housekeeper) {
    //                                 //******************changes in estimation of task for room wise estimation changes****************//
    //                                 // get estimation using combination of roomtype, room category and servicetype/task sub category
    //                                 let RoomObject = roomResult.find((roomobj) => roomobj._id.toString() == data.roomnoid?.toString())
    //                                 let roomestimationobject = roomestimationResp.ResultData.find((roomestobj) => roomestobj?.roomtypeid?.toString() == TaskAssign?.roomtypeid?.toString() && RoomObject?.roomcategoryid?.toString() == roomestobj.roomcategoryid.toString() && roomestobj.serviceid.toString() == TaskAssign.subcategoryid.toString())
    //                                 TaskAssign.subcategoryminutes = roomestimationobject?.assigneemaximumestimation ? roomestimationobject.assigneemaximumestimation : 0
    //                                 TaskAssign.subcategoryinspectionminutes = roomestimationobject?.inspectormaximumestimation ? roomestimationobject.inspectormaximumestimation : 0
    //                                 // get estimation using combination of roomtype, room category and servicetype/task sub category
    //                                 //******************changes in estimation of task for room wise estimation changes****************//
    //                             }
    //                             if (req.body.subcategoryid != result.subcategoryid && !TaskAssign.taskstarttime) {
    //                                 if (result.categoryid == Config.taskcategory.housekeeper) {
    //                                     let convertMinsToHrsMins = IISMethods.convertMinsToHrsMins(TaskAssign.subcategoryminutes, false)
    //                                     TaskAssign.estimatehours = convertMinsToHrsMins.h
    //                                     TaskAssign.estimateminutes = convertMinsToHrsMins.m

    //                                     let inspectionConvertMinsToHrsMins = IISMethods.convertMinsToHrsMins(TaskAssign.subcategoryinspectionminutes, false)
    //                                     TaskAssign.inspectionestimatehours = inspectionConvertMinsToHrsMins.h
    //                                     TaskAssign.inspectionestimateminutes = inspectionConvertMinsToHrsMins.m
    //                                 }
    //                             }
    //                         }
    //                     }

    //                     if (req.body.showbeforefixtasktime) {
    //                         TaskAssign.showtaskdate = new Date(TaskAssign.showbeforefixtasktime)
    //                     } else if ((TaskAssign.showbeforetaskhours || TaskAssign.showbeforetaskminutes) && TaskAssign.startdate) {
    //                         beforetaskminutes = parseInt(TaskAssign.showbeforetaskhours) * 60 + parseInt(TaskAssign.showbeforetaskminutes)

    //                         var showbeforedate = new Date(TaskAssign.startdate)
    //                         showbeforedate.setMinutes(showbeforedate.getMinutes() - parseInt(beforetaskminutes))
    //                         if (IISMethods.getDateFormats(showbeforedate, 1, true).toString() > IISMethods.getDateFormats(systemdate, 1, true).toString()) {
    //                             TaskAssign.showtaskdate = showbeforedate
    //                         }
    //                     } else {
    //                         TaskAssign.showtaskdate = systemdate
    //                     }

    //                     if (req.body.products && req.body.products.length > 0) {
    //                         TaskAssign.products = JSON.parse(req.body.products)
    //                     }

    //                     if (req.body.issue && req.body.issue.length > 0) {
    //                         TaskAssign.issue = JSON.parse(req.body.issue)
    //                     }

    //                     delete TaskAssign.taskactions
    //                     if (isUpdate) {

    //                         //Update Checklists
    //                         let isAlreadyUpdateChecklist = 0
    //                         if (req.body.subcategoryid && req.body.subcategoryid != result.subcategoryid && !TaskAssign.taskstarttime) {

    //                             await MainDB.InsertTaskChecklistData(
    //                                 categoryResult.showsubchecklist,
    //                                 TaskAssign,
    //                                 TaskAssign.checklistids,
    //                                 result
    //                             )
    //                             isAlreadyUpdateChecklist = 1
    //                         }

    //                         if (!isAlreadyUpdateChecklist && req.body.subcategoryid && req.body.checklistids) {
    //                             await MainDB.InsertTaskChecklistData(
    //                                 categoryResult.showsubchecklist,
    //                                 TaskAssign,
    //                                 TaskAssign.checklistids,
    //                                 result
    //                             )
    //                         }

    //                         // Start: Update latecheckouttime time in resevation table
    //                         if (req.body.latecheckouttime && result.roomno) {
    //                             await MainDB.updateLateCheckout(result.reservationid, req.body.latecheckouttime, result.roomnoid)
    //                         }
    //                         // End: Update latecheckouttime time in resevation table

    //                         // Start: Update Specialtasks

    //                         if (categoryResult.showspecialtasks && ((req.body.specialtasks && req.body.specialtasks.length > 0) || (req.body.subcategoryid && req.body.subcategoryid != result.subcategoryid))) {
    //                             // req.body.specialtasks = Array.isArray(req.body.specialtasks) && req.body.specialtasks.length ? JSON.parse(req.body.specialtasks) : []  // Abhi Shah ~ 2024-06-21 ~ 10:38 AM
    //                             let specialSubCategoryId = req.body.subcategoryid ? req.body.subcategoryid : result.subcategoryid
    //                             let specialSubCategory = req.body.subcategory ? req.body.subcategory : result.subcategory
    //                             req.body.specialtasks.map(special => {
    //                                 special.taskcategoryid = result.categoryid
    //                                 special.taskcategory = result.category
    //                                 special.tasksubcategoryid = specialSubCategoryId
    //                                 special.tasksubcategory = specialSubCategory
    //                                 return special
    //                             })
    //                             // TaskAssign.specialtasks = req.body.specialtasks
    //                             // let incompletedSpecialtasks = req.body.specialtasks.filter((specialtaskobj) => specialtaskobj.iscompleted == 0)

    //                             if (result.roomno) {
    //                                 let specialtasksData = await MainDB.getIncompletedSpecialTaskData(
    //                                     "room",
    //                                     result.roomnoid,
    //                                     req.body.specialtasks
    //                                 )
    //                                 TaskAssign.specialtasks = IISMethods.specialTaskFilterData(specialtasksData, result.categoryid, specialSubCategoryId)
    //                                 await MainDB.updateRoomData(result.roomnoid, {
    //                                     specialtasks: specialtasksData
    //                                 })
    //                             } else if (result.area) {
    //                                 let specialtasksData = await MainDB.getIncompletedSpecialTaskData(
    //                                     "area",
    //                                     result.areaid,
    //                                     req.body.specialtasks
    //                                 )
    //                                 TaskAssign.specialtasks = IISMethods.specialTaskFilterData(specialtasksData, result.categoryid, specialSubCategoryId)
    //                                 await MainDB.updateAreaData(result.areaid, { specialtasks: specialtasksData })
    //                             }
    //                         }
    //                         // End: Update Specialtasks

    //                         // Start: Update Room
    //                         if (req.body.isoutoforder == 0 && result.isoutoforder !== req.body.isoutoforder) {
    //                             req.body.fromoutoforderdate = null
    //                             req.body.tooutoforderdate = null
    //                             req.body.isoutoforder = 0
    //                         }
    //                         if (categoryResult.showoutoforderfromandtodate && result.roomno && req.body.isoutoforder) {
    //                             const outofroom = {
    //                                 propertyid: req.headers.propertyid,
    //                                 propertyname: req.headers.propertyname,
    //                                 roomnoid: result.roomnoid,
    //                                 roomno: result.roomno,
    //                                 fromdate: req.body.fromoutoforderdate,
    //                                 todate: req.body.tooutoforderdate,
    //                                 description: req.body.outoforderdesc,
    //                                 isoutofroom: req.body.isoutoforder
    //                             }
    //                             await MainDB.updateOutOfRoomData(outofroom, timezone)
    //                             // await MainDB.updateRoomData(result.roomnoid, {
    //                             //     fromoutoforderdate: req.body.fromoutoforderdate,
    //                             //     tooutoforderdate: req.body.tooutoforderdate,
    //                             //     isoutoforder: req.body.isoutoforder,
    //                             //     outoforderdesc: req.body.outoforderdesc
    //                             // })
    //                             const roomnoarr = [{
    //                                 "roomno": result.roomno.toString()
    //                             }]
    //                             const pmsdata = {
    //                                 roomnoarray: roomnoarr,
    //                                 isoutoforder: req.body.isoutoforder
    //                             }
    //                             IISMethods.emitRoomWiseSocket({
    //                                 to: [`${req.headers.subdomainname}${req.headers.propertyid}nextappmsconnect`],
    //                                 on: Config.getSocketTriggers()["changeoutoforderstatus"],
    //                                 data: pmsdata
    //                             })

    //                             await MainDB.addPMSEvent({ subdomainname: req.headers.subdomainname, propertyid: req.headers.propertyid, eventname: Config.getSocketTriggers()["changeoutoforderstatus"], eventdata: pmsdata })
    //                         } else if (categoryResult?.showoutoforderfromandtodate && result.area) {
    //                             const outofroom = {
    //                                 propertyid: req.headers.propertyid,
    //                                 propertyname: req.headers.propertyname,
    //                                 areaid: result.areaid,
    //                                 area: result.area,
    //                                 fromdate: req.body.fromoutoforderdate,
    //                                 todate: req.headers.tooutoforderdate,
    //                                 description: req.body.outoforderdesc,
    //                                 isoutofroom: req.body.isoutoforder
    //                             }
    //                             await MainDB.updateOutOfAreaData(outofroom, timezone)
    //                             // await MainDB.updateAreaData(result.areaid, { 
    //                             //     fromoutoforderdate: req.body.fromoutoforderdate,
    //                             //     tooutoforderdate: req.body.tooutoforderdate,
    //                             //     outoforderdesc : req.body.outoforderdesc,
    //                             //     isoutoforder : req.body.isoutoforder
    //                             // })
    //                         }

    //                         if (req.body.isoutofinventory == 0 && result.isoutofinventory !== req.body.isoutofinventory) {
    //                             req.body.fromoutofinventorydate = null
    //                             req.body.tooutofinventorydate = null
    //                             req.body.isoutofinventory = 0
    //                         }
    //                         if (categoryResult.showoutofinventoryfromandtodate && result.roomno && req.body.isoutofinventory) {  // ? Abhi Shah ~ 2024-11-15 ~ 03:52 PM

    //                             const outofroom = {
    //                                 propertyid: req.headers.propertyid,
    //                                 propertyname: req.headers.propertyname,
    //                                 roomnoid: result.roomnoid,
    //                                 roomno: result.roomno,
    //                                 fromdate: req.body.fromoutofinventorydate,
    //                                 todate: req.body.tooutofinventorydate,
    //                                 description: req.body.outofinventorydesc,
    //                                 isoutofroom: req.body.isoutofinventory ? 3 : 0
    //                             }
    //                             await MainDB.updateOutOfRoomData(outofroom, timezone)
    //                             // await MainDB.updateRoomData(result.roomnoid, {
    //                             //     fromoutofinventorydate: req.body.fromoutofinventorydate,
    //                             //     tooutofinventorydate: req.body.tooutofinventorydate,
    //                             //     isoutofinventory: req.body.isoutofinventory,
    //                             //     outofinventorydesc: req.body.outofinventorydesc
    //                             // })

    //                             const roomnoarr = [{
    //                                 "roomno": result.roomno.toString()
    //                             }]
    //                             const pmsdata = {
    //                                 roomnoarray: roomnoarr,
    //                                 isoutofinventory: req.body.isoutofinventory
    //                             }
    //                             IISMethods.emitRoomWiseSocket({
    //                                 to: [`${req.headers.subdomainname}${req.headers.propertyid}nextappmsconnect`],
    //                                 on: Config.getSocketTriggers()["changeoutofinventorystatus"],
    //                                 data: pmsdata
    //                             })

    //                             await MainDB.addPMSEvent({ subdomainname: req.headers.subdomainname, propertyid: req.headers.propertyid, eventname: Config.getSocketTriggers()["changeoutofinventorystatus"], eventdata: pmsdata })
    //                         }
    //                         // End: Update Room

    //                         let guestExpAlias = "" //For guestexpnotify socket use - Harsh V - 21/06/2023 
    //                         let notificationCategoryId = Config.dummyObjid //Harsh V -19/09/2023 
    //                         //Start: Update Room Action
    //                         var roomActionId = ""
    //                         if (TaskAssign.categoryid == Config.taskcategory.housekeeper) {
    //                             roomActionId = FieldConfig.roomaction.housekeeping
    //                             guestExpAlias = FieldConfig.guestexperiencealias.housekeeping // Harsh V - 21/06/2023 
    //                             notificationCategoryId = FieldConfig.notificationcategory.housekeeping //Harsh V -19/09/2023 

    //                         } else if (TaskAssign.categoryid == Config.taskcategory.deposit) {
    //                             roomActionId = FieldConfig.roomaction.deposit
    //                             //Update Reservation deposit amount
    //                             if (TaskAssign.carddeposit || TaskAssign.cashdeposit || TaskAssign.debitcarddeposit) { // Vivek ~ 2024-03-19 ~ 10:16 AM
    //                                 var updateReservation = [
    //                                     { _id: ObjectId(result.reservationid) },
    //                                     { $set: { carddeposit: TaskAssign.carddeposit, cashdeposit: TaskAssign.cashdeposit, debitcarddeposit: TaskAssign.debitcarddeposit } }
    //                                 ]
    //                                 await MainDB.Update("tblreservation", new Reservation(), updateReservation)
    //                             }
    //                             notificationCategoryId = FieldConfig.notificationcategory.deposit //Harsh V -19/09/2023 

    //                         } else if (TaskAssign.categoryid == Config.taskcategory.request) {
    //                             roomActionId = FieldConfig.roomaction.request
    //                             guestExpAlias = FieldConfig.guestexperiencealias.guestrequest // Harsh V - 21/06/2023 
    //                             notificationCategoryId = FieldConfig.notificationcategory.request //Harsh V -19/09/2023 

    //                         } else if (TaskAssign.categoryid == Config.taskcategory.maintenance) {
    //                             roomActionId = FieldConfig.roomaction.maintenance
    //                             guestExpAlias = FieldConfig.guestexperiencealias.maintanance // Harsh V - 21/06/2023 
    //                             notificationCategoryId = FieldConfig.notificationcategory.maintenance //Harsh V -19/09/2023 

    //                         } else if (TaskAssign.categoryid == Config.taskcategory.deepcleaning) {
    //                             roomActionId = FieldConfig.roomaction.deepcleanning
    //                             notificationCategoryId = FieldConfig.notificationcategory.deepcleaning //Harsh V -19/09/2023 

    //                         } else if (TaskAssign.categoryid == Config.taskcategory.premaintanance) {
    //                             roomActionId = FieldConfig.roomaction.premaintenance
    //                             notificationCategoryId = FieldConfig.notificationcategory.premaintanance //Harsh V -19/09/2023 

    //                         } //|---- Harsh V 07/06/2023 
    //                         else if (TaskAssign.categoryid == Config.taskcategory.frontdesk && TaskAssign.subcategoryid.toString() == Config.frontdeskalertsubcategory) {
    //                             roomActionId = FieldConfig.roomaction.frontdeskalert
    //                             notificationCategoryId = FieldConfig.notificationcategory.frontdesk //Harsh V -19/09/2023 

    //                         } else if (TaskAssign.categoryid == Config.taskcategory.frontdesk && TaskAssign.subcategoryid.toString() == Config.latecheckoutsubcategoryid) {
    //                             roomActionId = FieldConfig.roomaction.latecheckout
    //                             guestExpAlias = FieldConfig.guestexperiencealias.latecheckout // Harsh V - 21/06/2023 
    //                             notificationCategoryId = FieldConfig.notificationcategory.frontdesk //Harsh V -19/09/2023 

    //                         } else if (TaskAssign.categoryid == Config.taskcategory.frontdesk && TaskAssign.subcategoryid.toString() == Config.extandstaysubcategoryid) {
    //                             roomActionId = FieldConfig.roomaction.extendstay
    //                             guestExpAlias = FieldConfig.guestexperiencealias.extendstay // Harsh V - 21/06/2023 
    //                             notificationCategoryId = FieldConfig.notificationcategory.frontdesk //Harsh V -19/09/2023 

    //                         } else if (TaskAssign.categoryid == Config.taskcategory.frontdesk && TaskAssign.subcategoryid.toString() == Config.checkoutsubcategoryid) {
    //                             roomActionId = FieldConfig.roomaction.checkout
    //                             guestExpAlias = FieldConfig.guestexperiencealias.checkout
    //                             notificationCategoryId = FieldConfig.notificationcategory.frontdesk //Harsh V -19/09/2023 

    //                         } else if (TaskAssign?.categoryid == Config.taskcategory.other) {
    //                             notificationCategoryId = IISMethods.getTaskNotificationCategory(TaskAssign) //Harsh V -30/12/2023
    //                         } else if (TaskAssign?.categoryid == Config.taskcategory.daily) {
    //                             notificationCategoryId = IISMethods.getTaskNotificationCategory(TaskAssign) //Harsh V -30/12/2023
    //                         }

    //                         TaskAssign.roomno = req.body.roomno ? req.body.roomno : result.roomno
    //                         TaskAssign.roomnoid = req.body.roomnoid ? req.body.roomnoid : result.roomnoid
    //                         TaskAssign.hkcomments = req.body.hkcomments ? req.body.hkcomments : ""

    //                         if (roomActionId && TaskAssign.roomno && result.iscompleted != 1) {
    //                             TaskAssign.roomactionid = roomActionId
    //                             var startdate = TaskAssign.startdate ? TaskAssign.startdate : result.startdate
    //                             await MainDB.pushRoomAction(roomActionId, [TaskAssign.roomnoid], startdate, systemdate)
    //                         }
    //                         if (TaskAssign.reservationid != Config.dummyObjid && TaskAssign.categoryid.toString() == Config.taskcategory.housekeeper) {
    //                             var updateReservation = [
    //                                 { _id: ObjectId(TaskAssign.reservationid) },
    //                                 {
    //                                     $set: {
    //                                         hkcomments: TaskAssign.hkcomments
    //                                     }
    //                                 }
    //                             ]
    //                             await MainDB.Update("tblreservation", new Reservation(), updateReservation)
    //                         }

    //                         // tushar 19-05-2023
    //                         let fdsocekettaskRoomIds = []
    //                         let fdsocekettaskAreaIds = []
    //                         let viewtype = 0
    //                         if (result.assignmentforid.toString() == Config.amenitiescategoryroom.toString()) {
    //                             fdsocekettaskRoomIds = [result.roomnoid.toString()]
    //                             viewtype = 1
    //                         } else if (result.assignmentforid.toString() == Config.amenitiescategoryarea.toString()) {
    //                             fdsocekettaskAreaIds = [result.areaid.toString()]
    //                             viewtype = 2
    //                         }

    //                         const frontdata = await MainDB.frontdeskOptimmized(req.headers, result.reservationid, fdsocekettaskRoomIds.toString())

    //                         let fdSocketData = {
    //                             actionid: [
    //                                 {
    //                                     actionid: FieldConfig.roomaction.todaysview,
    //                                     roomids: fdsocekettaskRoomIds,
    //                                     areaids: fdsocekettaskAreaIds,
    //                                 },
    //                                 {
    //                                     actionid: roomActionId?.toString(),
    //                                     roomids: fdsocekettaskRoomIds,
    //                                     areaids: fdsocekettaskAreaIds,
    //                                 }
    //                             ],
    //                             viewtype: viewtype,
    //                             data: frontdata || ""
    //                         }

    //                         IISMethods.emitRoomWiseSocket({
    //                             to: [`${req.headers.subdomainname}frontdesk${result.propertyid?.toString()}`],
    //                             on: Config.getSocketTriggers()["frontdeskrefresh"],
    //                             data: fdSocketData
    //                         })

    //                         const resp = await MainDB.executedata("u", new _Task(), TableName, TaskAssign)

    //                         // GTB 03-05-2024 need update task first if socket emit before task update it will return old data
    //                         const SocketData = IISMethods.getTaskTabData(TaskAssign, req.headers.uid, record.ResultData[0])
    //                         SocketData.socketdata[0].updateuid = req.headers.uid
    //                         if (req.body.emitsocket != "0") {
    //                             //PARTH
    //                             IISMethods.emitRoomWiseSocket({
    //                                 to: [`${req.headers.subdomainname}${req.body.propertyid}`],
    //                                 on: Config.getSocketTriggers()["taskdataupdate"],
    //                                 data: SocketData.socketdata
    //                             })
    //                         }

    //                         //18-04-2023  paras
    //                         if (resp.status == 200) {
    //                             const a = await MainDB.AlltaskLog({
    //                                 taskid: resp.data._id,
    //                                 type: "manually",
    //                                 action: "update",
    //                                 reqbody: Defaultreqbody,
    //                                 taskdata: resp.data
    //                             })
    //                             /********************* Employee Point *********************/
    //                             //taskbase Point
    //                             req.body.taskpoint = true
    //                             await DF.AddEmployeePoints([req.headers.uid], "taskbase", req)

    //                             /********************* End Employee Point *********************/
    //                         }

    //                         // Notification setting
    //                         if (resp.status == 200) {
    //                             let obj = { ...resp.data._doc }

    //                             //|----- Harsh V - 23/06/2023 - Emit Reading Socket  
    //                             if (obj.categoryid.toString() == Config.taskcategory.reading) {
    //                                 let redcolor = 0
    //                                 obj.readingitems?.map(reading => {
    //                                     if ((reading.readingtype == 0 || reading.readingtype == 2)) {
    //                                         reading.color = Config.dummycolor
    //                                     } else if (reading.readingtype == 1) {
    //                                         reading.color = FieldConfig.readingcolor.red
    //                                         redcolor = 1
    //                                     } else {
    //                                         reading.color = FieldConfig.readingcolor.red
    //                                         redcolor = 1
    //                                     }
    //                                     return reading
    //                                 })
    //                                 obj.bordercolor = FieldConfig.readingcolor.white
    //                                 if (redcolor) {
    //                                     obj.bordercolor = FieldConfig.checklistcolor.red
    //                                 }
    //                                 obj.addreadingtask = 0
    //                                 //PARTH
    //                                 IISMethods.emitRoomWiseSocket({
    //                                     to: [`${req.headers.subdomainname}reading${obj.propertyid?.toString()}`],
    //                                     on: Config.getSocketTriggers()["readingdata"],
    //                                     data: obj
    //                                 })
    //                             } // 23/06/2023 -----|  

    //                             var userids = []
    //                             var notificationTitle = ""
    //                             var notificationIntervalDetails = []
    //                             let notificationArray = []
    //                             let notiCategoryAlias = "" //Harsh V - 21/09/2023 
    //                             if (
    //                                 obj.assignpersonid.toString() &&
    //                                 obj.assignpersonid.toString() != Config.dummyObjid &&
    //                                 (result.assignpersonid.toString() == Config.dummyObjid || result.assignpersonid.toString() != obj.assignpersonid.toString())
    //                             ) {
    //                                 const personData = await MainDB.getPersonUserroleData([ObjectId(obj.assignpersonid)])

    //                                 //!---- Harsh V - 21/07/2023 notification interval changes 
    //                                 userids = await MainDB.getPersonToAllowNotification(
    //                                     personData,
    //                                     IISMethods.getTaskNotificationCategory(obj),
    //                                     FieldConfig.notificationalias.open,
    //                                     true,
    //                                     obj?.propertyid?.toString() || Config.dummyObjid
    //                                 )
    //                                 // const notificationMessage = userids?.notificationmessage || "" //Harsh V - 10/01/2024 notification message master changes  
    //                                 notificationIntervalDetails = userids?.intervaldetails
    //                                 userids = userids?.allownotificationpersonids
    //                                 //Harsh V - 21/07/2023 ---!

    //                                 notificationTitle = `${req.headers.username} assigned task to you.`
    //                                 // if(notificationMessage) notificationTitle = notificationMessage  //Harsh V - 10/01/2024 notification message master changes  
    //                                 notiCategoryAlias = FieldConfig.notificationalias.open //Harsh V - 21/09/2023 
    //                                 //Harsh V. - 19/05/2023
    //                                 if (obj.reservationid.toString() != Config.dummyObjid) {
    //                                     userids.push(obj.reservationid.toString())
    //                                 }
    //                             } else if (
    //                                 (!obj.assignpersonid.toString() || obj.assignpersonid.toString() == Config.dummyObjid) &&
    //                                 result.assignpersonid.toString() != Config.dummyObjid
    //                             ) {
    //                                 var userids = []
    //                                 var personIds = []

    //                                 //paras 24-04-2023
    //                                 if (obj.assignpersons?.length) {
    //                                     personIds = await obj?.assignpersons
    //                                         .filter((object) => object?.assignpersonid.toString() != req.headers.uid)
    //                                         .map((o) => ObjectId(o?.assignpersonid))
    //                                 }
    //                                 else if (obj?.designations?.length) {
    //                                     personIds = await MainDB.getDesignationWisePersonIds(
    //                                         req.headers.uid,
    //                                         [],
    //                                         obj.designations ? obj.designations : [],
    //                                         false,
    //                                         obj.propertyid
    //                                     )
    //                                 } else {
    //                                     personIds = await MainDB.getDepartmentWisePersonIds(
    //                                         req.headers.uid,
    //                                         [],
    //                                         obj.departments ? obj.departments : [],
    //                                         false,
    //                                         obj.propertyid
    //                                     )
    //                                 }

    //                                 const personData = await MainDB.getPersonUserroleData(personIds)

    //                                 //!---- Harsh V - 21/07/2023 notification interval changes 
    //                                 userids = await MainDB.getPersonToAllowNotification(
    //                                     personData,
    //                                     IISMethods.getTaskNotificationCategory(obj),
    //                                     FieldConfig.notificationalias.unassigned,
    //                                     true,
    //                                     obj?.propertyid?.toString() || Config.dummyObjid
    //                                 )
    //                                 // const notificationMessage = userids?.notificationmessage || "" //Harsh V - 10/01/2024 notification message master changes  

    //                                 notificationIntervalDetails = userids?.intervaldetails
    //                                 userids = userids?.allownotificationpersonids
    //                                 //Harsh V - 21/07/2023 ---!

    //                                 notificationTitle = `Unassigned task by ${req.headers.username}.`
    //                                 // if(notificationMessage) notificationTitle = notificationMessage  //Harsh V - 10/01/2024 notification message master changes  

    //                                 notiCategoryAlias = FieldConfig.notificationalias.unassigned //Harsh V - 21/09/2023 

    //                                 //Harsh V. - 19/05/2023
    //                                 if (obj.reservationid.toString() != Config.dummyObjid) {
    //                                     userids.push(obj.reservationid.toString())
    //                                 }
    //                             }

    //                             //Harsh V. - 22/05/2023
    //                             userids = userids?.filter((uid) => uid != req.headers.uid) || []

    //                             const tokens = await MainDB.getDeviceTokens({
    //                                 userids, //14/08/2023
    //                                 moduletypeid: [Config.moduletype["app"], Config.moduletype["web"], Config.moduletype['guestexperience']],
    //                                 checkrights: {
    //                                     branchid: obj.propertyid,
    //                                     pagealias: {
    //                                         app: IISMethods.getPageAlias(obj.categoryid, obj.tasktypeid),
    //                                         web: 'tasks',
    //                                     },
    //                                     rights: []
    //                                 },
    //                                 groupby: true
    //                             })

    //                             // |---- Harsh V 21/06/2023
    //                             if (result.reservationid?.toString() != Config.dummyObjid && guestExpAlias != "") {
    //                                 //Reservation to get roomnoid for guest experience socket   
    //                                 const reservationPipeline = { _id: ObjectId(result.reservationid) }
    //                                 const reservationResp = await MainDB.FindOne('tblreservation', new Reservation(), reservationPipeline)

    //                                 if (reservationResp) {
    //                                     const guestResRoomNoId = reservationResp.roomnoid.toString()

    //                                     // Socket For Guest Notify
    //                                     IISMethods.emitRoomWiseSocket({
    //                                         to: [`${req.headers.subdomainname}${reservationResp._id?.toString()}`],
    //                                         on: Config.getSocketTriggers()["guestexpnotify"],
    //                                         data: { alias: guestExpAlias, isguestexpnotify: tokens.guest.token.length ? 1 : 0 }
    //                                     })
    //                                 }
    //                             } //----|


    //                             if (tokens.other.token.length > 0 || tokens.guest.token.length > 0) {
    //                                 var details = IISMethods.getTaskNotificationBody(obj)

    //                                 let title = notificationTitle
    //                                 let body = details

    //                                 //***** Dynamic title body ****** 
    //                                 const titleBodyParams = { tasktitle: body, taskdetails: body, assignbyperson: req.headers.username }
    //                                 const titleBodyObj = await MainDB.genereateNotificationTitleBody({ titleBodyParams, notificationAlias: notiCategoryAlias, notificationCategoryid: notificationCategoryId })

    //                                 title = titleBodyObj?.title ? titleBodyObj?.title : title
    //                                 body = titleBodyObj?.body ? titleBodyObj?.body : body
    //                                 //***** Dynamic title body ****** 

    //                                 const notificationData = {
    //                                     pagename: req.headers.pagename,
    //                                     _id: obj._id.toString(),
    //                                     noticategoryalias: notiCategoryAlias, //Harsh V - 21/09/2023 
    //                                     noticategoryid: notificationCategoryId, //Harsh V - 21/09/2023   
    //                                     image: "",
    //                                     title: title,
    //                                     categoryid: obj.categoryid.toString(),
    //                                     tasktype: obj.tasktype.toString(),
    //                                     time: new Date(systemdate).toISOString(),
    //                                     // description: obj.description || obj.specialtask || obj.comment || "",
    //                                     description: details,
    //                                     flag: "1",
    //                                     propertyid: obj.propertyid ? obj.propertyid.toString() : "",
    //                                     buildingid: obj.buildingid ? obj.buildingid.toString() : "",
    //                                     wingid: obj.wingid ? obj.wingid.toString() : "",
    //                                     roomactionid: roomActionId ? roomActionId : Config.dummyObjid,
    //                                 }
    //                                 const notificationObj = {
    //                                     notificationtype: 0,
    //                                     task: obj.subcategory,
    //                                     notificationcategoryid: notificationCategoryId,
    //                                     taskid: obj._id.toString(),
    //                                     taskcategoryid: obj.categoryid.toString(),
    //                                     tasktype: obj.tasktype,
    //                                     imageflag: 0,
    //                                     image_or_alphabet: "",
    //                                     clickflag: 1,
    //                                     title: title,
    //                                     // description: obj.description || obj.specialtask || obj.comment || "",
    //                                     description: details,
    //                                     time: new Date(systemdate),
    //                                     notificationdata: {}, // Harsh V 21/07/2023
    //                                     recordinfo: obj.recordinfo
    //                                 }

    //                                 if (obj.assignperson === "") {
    //                                     notificationObj.acceptflag = 0
    //                                 } else {
    //                                     notificationObj.acceptflag = 1
    //                                 }

    //                                 if (obj.roomno) {
    //                                     notificationData.room_or_area = obj.roomno.toString()
    //                                     notificationData.roomtype = obj.roomtype
    //                                     notificationData.roomnoid = obj.roomnoid.toString()
    //                                     notificationData.room_or_area_flag = "1"
    //                                     notificationObj.type = 0
    //                                     notificationObj.room_or_area = obj.roomno
    //                                     notificationObj.roomtype = obj.roomtype
    //                                 } else if (obj.area) {
    //                                     notificationData.room_or_area = obj.area
    //                                     notificationData.roomtype = obj.areatype
    //                                     notificationData.roomnoid = obj.areaid.toString()
    //                                     notificationData.room_or_area_flag = "2"
    //                                     notificationObj.type = 1
    //                                     notificationObj.room_or_area = obj.area
    //                                     notificationObj.roomtype = obj.areatype
    //                                 } else {
    //                                     notificationData.room_or_area = ""
    //                                     notificationData.roomtype = ""
    //                                     notificationData.room_or_area_flag = "3"
    //                                     notificationObj.type = 2
    //                                     notificationObj.room_or_area = ""
    //                                     notificationObj.roomtype = ""
    //                                 }

    //                                 //Harsh V. - 19/05/2023 
    //                                 if (req.body.accepttask == "1") {
    //                                     title = req.headers.username + " has accepted the task"
    //                                     // IISMethods.sendPushNotification(tokens, title, body, notificationData)
    //                                 }

    //                                 //!---- Harsh V - 21/07/2023 notification interval changes 
    //                                 notificationObj.categorywiseinternvaldetails = notificationIntervalDetails
    //                                 notificationObj.notificationdata = notificationData
    //                                 notificationObj.notificationdata.body = body
    //                                 //Harsh V - 21/07/2023 notification interval changes ----! 

    //                                 notificationObj.userids = tokens.other.userids
    //                                 notificationArray.push({ ...notificationObj })
    //                                 IISMethods.sendPushNotification(tokens.other.token, title, body, notificationData)

    //                                 if (tokens.guest.token.length) {
    //                                     notificationObj.userids = tokens.guest.userids
    //                                     title = IISMethods.getGuestTaskNotificationTitle(obj, 2)

    //                                     //|----- Harsh V - 08/08/2023 For guest experience notification 
    //                                     let yourStr = ""
    //                                     if (obj.recordinfo?.entryuid == Config.dummyObjid) yourStr = `Your `

    //                                     let categoryStr = obj.category?.toLowerCase() //16/08/2023 
    //                                     if (obj.categoryid == Config.taskcategory.request) categoryStr = "" //Harsh V - 25/08/2023

    //                                     if (req.body.accepttask == "1") {
    //                                         title = `Your ${categoryStr} request has been assigned to ${obj.assignperson}.` // 14/08/2023 
    //                                         // title = `${yourStr} ${categoryStr}request has been accepted by ${obj.assignperson} and will be processed soon.`
    //                                     }
    //                                     // -----| 

    //                                     notificationData.title = title
    //                                     notificationObj.title = title
    //                                     // notificationObj.description = IISMethods.getTaskNotificationBody(obj) //Harsh V - 08/08/2023
    //                                     notificationObj.description = "" //Harsh V - 25/08/2023
    //                                     body = "" //Harsh V - 25/08/2023 

    //                                     //!---- Harsh V - 25/07/2023 remove intervaldetails in guest notification object - notification interval changes 
    //                                     notificationObj.categorywiseinternvaldetails = []
    //                                     notificationObj.notificationdata = {}

    //                                     notificationArray.push({ ...notificationObj })
    //                                     IISMethods.sendPushNotification(tokens.guest.token, title, body, notificationData)
    //                                 }
    //                             }

    //                             await MainDB.InsertMany(
    //                                 "tblnotification",
    //                                 new _Notification(),
    //                                 notificationArray
    //                             )
    //                         }

    //                         ResponseBody.data = resp.data
    //                         ResponseBody.status = resp.status
    //                         ResponseBody.message = resp.message
    //                     } else {
    //                         ResponseBody.status = 400
    //                         if (isExistTask == 1) {
    //                             ResponseBody.message = Config.errmsg.subcategoryisalreadyaddedintheanothertask
    //                         } else if (isExistTask == 2) {
    //                             ResponseBody.message = Config.errmsg.cantaddcheckinorcheckoutsubcategory
    //                         } else {
    //                             ResponseBody.message = Config.errmsg.youcannotupdatesubcategory
    //                         }
    //                     }
    //                 }
    //             }
    //         }
    //         req.ResponseBody = ResponseBody; next()
    //     } catch (err) {

    //         req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }; next()
    //     }
    // }

}
