
import { Config,MainDB , IISMethods} from '../../../../config/Init.js'
import _SurveyType from '../../../../model/masters/Survey/SurveyType.js'

const TableName = 'tblsurveytype'
const PageName = "surveytype"
const FormName = "surveytype"

export default class SurveyType{

    // START Survey Type
    //List
    async ListSurveyType(req, res, next)
    {
        try {

            var ResponseBody = {}
            var PaginationInfo = req.body.paginationinfo

            const requiredPage = { pageno: PaginationInfo.pageno, skip: (PaginationInfo.pageno - 1) * PaginationInfo.pagelimit, pagelimit: PaginationInfo.pagelimit }
            var pipeline = []
            var sort = (Object.keys(PaginationInfo.sort).length !== 0 ? PaginationInfo.sort : { '_id': -1 })
            let projection = PaginationInfo.projection ? PaginationInfo.projection : {}

            pipeline = IISMethods.GetPipelineForFilter(PaginationInfo.filter)

            const searchtext = req.body.searchtext || ""
            if (searchtext !== "") {
                pipeline.push(...IISMethods.GetGlobalSearchFilter(new _SurveyType(), searchtext))
            }

            const resp = await MainDB.getmenual(TableName, new _SurveyType(), pipeline, requiredPage, sort, true, "", projection)

            ResponseBody.pagename = PageName
            ResponseBody.formname = FormName
            ResponseBody.status = 200
            ResponseBody.message = Config.getResponsestatuscode()['200']
            ResponseBody.data = resp.ResultData
            ResponseBody.currentpage = resp.currentpage
            ResponseBody.nextpage = resp.nextpage
            ResponseBody.totaldocs = resp.totaldocs
            ResponseBody.fieldorder = resp.fieldorderdata
            ResponseBody.formfieldorderdata = resp.formfieldorderdata

            req.ResponseBody = ResponseBody
            next()
        }
        catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err}
            next()
        }
    }

    // End Survey Type
}