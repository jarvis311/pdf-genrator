import { IISMethods, Config, MainDB } from '../../../../config/Init.js'
import _SurveyForm from '../../../../model/masters/Survey/SurveyForm.js'
import _Survey from '../../../../model/masters/Survey/Survey.js'

const TableName = "tblsurveyform"
const PageName = "surveyform"
const FormName = "Surveyform"
const FltPageCollection = "surveyform"


export default class SurveyForm {

    // START SurveyForm 

    //List
    async ListSurveyForm(req, res, next) {
        try {
            var ResponseBody = {}
            var PaginationInfo = req.body.paginationinfo
            const ObjectId = IISMethods.getobjectid()
            const requiredPage = { pageno: PaginationInfo.pageno, skip: (PaginationInfo.pageno - 1) * PaginationInfo.pagelimit, pagelimit: PaginationInfo.pagelimit }
            var pipeline = []
            var sort = (Object.keys(PaginationInfo.sort).length !== 0 ? PaginationInfo.sort : { '_id': -1 })
            let projection = PaginationInfo.projection ? PaginationInfo.projection : {}

            pipeline = IISMethods.GetPipelineForFilter(PaginationInfo.filter)

            const searchtext = req.body.searchtext || ""
            if (searchtext !== "") {
                pipeline.push(...IISMethods.GetGlobalSearchFilter(new _SurveyForm(), searchtext))
            }

            if(req.headers.propertyid){
                pipeline.push({$match:{propertyid:ObjectId(req.headers.propertyid)}})
            }

            const resp = await MainDB.getmenual(TableName, new _SurveyForm(), pipeline, requiredPage, sort, true, "", projection)

            ResponseBody.pagename = PageName
            ResponseBody.formname = FormName
            ResponseBody.fltpagecollection = FltPageCollection
            ResponseBody.status = 200
            ResponseBody.message = Config.getResponsestatuscode()['200']
            ResponseBody.data = resp.ResultData
            ResponseBody.currentpage = resp.currentpage
            ResponseBody.nextpage = resp.nextpage
            ResponseBody.totaldocs = resp.totaldocs;
            ResponseBody.fieldorder = resp.fieldorderdata
            ResponseBody.formfieldorderdata = resp.formfieldorderdata

            req.ResponseBody = ResponseBody
            next()
        }
        catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

    //Insert
    async InsertSurveyForm(req, res, next) {
        try {
            var ResponseBody = {}
            const ObjectId = IISMethods.getobjectid()

            let ID = new ObjectId()

            // for (const mainobj of req.body.formjson) {
            //     for (const obj of mainobj.formfields) {
            //         if (obj.questionimage !== "") {
            //            let path = await IISMethods.movefileS3(obj.questionimage, req.headers.subdomainname + '/' + 'survey/' + ID + '/' + req.body.surveyform+ IISMethods.GetTimestamp() + '_Survey'   )
            //            obj.questionimage = path
            //         }
            //         for (const ansobj of obj.answers) {
            //             if (ansobj.answerimage !== "") {
            //                 let path = await IISMethods.movefileS3(ansobj.answerimage, req.headers.subdomainname + '/' + 'survey/' + ID + '/' + req.body.surveyform+ IISMethods.GetTimestamp() +  '_Survey' )        
            //                 ansobj.answerimage = path
            //             }
            //         }
            //     }
            //     if(mainobj.submitlink){
            //         mainobj.submitlink = await IISMethods.fileUploadOnHtmlEditor(mainobj.submitlink , req.headers.subdomainname + '/' + 'surveyformsubmitlink/',false,"",false)
            //     }  
            // }

            // if(req.body.description){
            //     req.body.description = await IISMethods.fileUploadOnHtmlEditor(req.body.description , req.headers.subdomainname + '/' + 'surveyformdescription/',false,"",false)
            // }

            req.body._id = ID
            const resp = await MainDB.executedata('i', new _SurveyForm(), TableName, req.body)
            ResponseBody.status = resp.status
            ResponseBody.message = resp.message
            req.ResponseBody = ResponseBody
            next()
        }
        catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

    //Update
    async UpdateSurveyForm(req, res, next) {
        try {
            var ResponseBody = {}
            let ObjectId = IISMethods.getobjectid()

            const pipelinedata = [{ $match: { '_id': new ObjectId(req.body._id) } }]
            const record = await MainDB.getmenual(TableName, new _SurveyForm(), pipelinedata)

            // if(req.body.description){
            //     req.body.description = await IISMethods.fileUploadOnHtmlEditor(req.body.description , req.headers.subdomainname + '/' + 'surveyformdescription/',true,record.ResultData[0].description,false)
            // }

            // let allsubmitlinkcombination  //??
            // for (const mainobj of record.ResultData[0].formjson) {
            //     mainobj.submitlink
            // }


            // for (const mainobj of req.body.formjson) {
            //     for (const obj of mainobj.formfields) {
            //         if (obj.questionimage && obj.questionimage !== "" && obj.questionimage !== undefined) {
            //             let path = await IISMethods.movefileS3(obj.questionimage, req.headers.subdomainname + '/' + 'survey/' + req.body._id + '/' + req.body.surveyform+ IISMethods.GetTimestamp()+ '_Survey'   )
            //             obj.questionimage = path
            //         }
            //         for (const ansobj of obj.answers) {
            //             if (ansobj.answerimage && ansobj.answerimage !== undefined && ansobj.answerimage !== "") {
            //                 let path = await IISMethods.movefileS3(ansobj.answerimage, req.headers.subdomainname + '/' + 'survey/' + req.body._id + '/' + req.body.surveyform+ IISMethods.GetTimestamp() +  '_Survey' )        
            //                 ansobj.answerimage = path
            //             }
            //         }
            //     }
            //     if(mainobj.submitlink){    //fileUploadOnHtmlEditor -- remaining
            //         mainobj.submitlink = await IISMethods.fileUploadOnHtmlEditor(mainobj.submitlink , req.headers.subdomainname + '/' + 'surveyformsubmitlink/')      //only old img link not delete
            //     }  
            // }

            // for (const mainobj of record.ResultData[0].formjson) {
            //     for (const obj of mainobj.formfields) {
            //         if ( obj.questionimage !== undefined && obj.questionimage !== "") {
            //            await IISMethods.deletefileS3(obj.questionimage.replace(Config.s3baseurl, ""))
            //            obj.questionimage = ""
            //         }
            //         for (const ansobj of obj.answers) {
            //             if (ansobj.answerimage !== undefined && ansobj.answerimage !== "") {
            //                 await IISMethods.deletefileS3(ansobj.answerimage.replace(Config.s3baseurl, ""))
            //                 ansobj.answerimage = ""
            //             }
            //         }
            //     }
            // }



            var RecordInfo = record.ResultData[0].recordinfo
            RecordInfo.updateuid = req.headers.uid
            RecordInfo.updateby = req.headers.personname
            RecordInfo.updatedate = IISMethods.getdatetimeisostr()
            req.body.recordinfo = RecordInfo

            const resp = await MainDB.executedata('u', new _SurveyForm(), TableName, req.body)

            ResponseBody.status = resp.status
            ResponseBody.data = resp.data
            ResponseBody.message = resp.message
            req.ResponseBody = ResponseBody
            next()
        }
        catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

    //Delete
    async DeleteSurveyForm(req, res, next) {
        try {
            var ResponseBody = {}
            let ObjectId = IISMethods.getobjectid()

            const pipelinedata = [{ $match: { '_id': new ObjectId(req.body._id) } }]
            const record = await MainDB.getmenual(TableName, new _SurveyForm(), pipelinedata)

            const survey = await MainDB.createmodel('tblsurvey', new _Survey())
            // const PerfomanceReview = await MainDB.createmodel('tblperformancereview', new _PerformanceReview())

            var dependency = [
                [survey['objModel'], { 'surveyformid': req.body._id }, "Survey"],
                // [ PerfomanceReview['objModel'], {'surveyformid' : req.body._id} ,"Performance Review"],
            ]
            const resp = await MainDB.executedata('d', new _SurveyForm(), TableName, req.body, true, dependency)

            if (resp.status == 200) {
                // for (const mainobj of record.ResultData[0].formjson) {
                //     for (const obj of mainobj.formfields) {
                //         if (obj.questionimage && obj.questionimage !== "") {

                //             await IISMethods.deletefileS3(obj.questionimage.replace(Config.s3baseurl, ""))
                //            obj.questionimage = ""
                //         }
                //         for (const ansobj of obj.answers) {
                //             if (ansobj.answerimage && ansobj.answerimage !== "") {
                //                 await IISMethods.deletefileS3(ansobj.answerimage.replace(Config.s3baseurl, ""))
                //                 ansobj.answerimage = ""
                //             }
                //         }
                //     }
                //     if(mainobj.submitlink){
                //         await IISMethods.fileUploadOnHtmlEditor(mainobj.submitlink , "",false,"",true)    
                //     }
                // }
                // await IISMethods.fileUploadOnHtmlEditor(record.ResultData[0].description , "",false,"",true)    
            }

            ResponseBody.status = resp.status
            ResponseBody.message = resp.message
            req.ResponseBody = ResponseBody
            next()
        }
        catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

    // End SurveyForm 
}