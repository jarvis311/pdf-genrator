import {IISMethods, Config, MainDB} from '../../../../config/Init.js'
import _Survey from '../../../../model/masters/Survey/Survey.js'
import _Customer from '../../../../model/Onboarding/Customer.js'
import _SurveyForm from '../../../../model/masters/Survey/SurveyForm.js'
import _SurveyRecords from '../../../../model/masters/Survey/SurveyRecords.js'


const TableName = "tblsurvey"
const PageName = "=survey"
const FormName = "Survey"
const FltPageCollection = "survey"

export default class Survey{

    // START Survey
    //List
    async ListSurvey(req, res, next)
    {
        try {
           
            var ResponseBody = {}
            var PaginationInfo = req.body.paginationinfo

            const requiredPage = { pageno: PaginationInfo.pageno, skip: (PaginationInfo.pageno - 1) * PaginationInfo.pagelimit, pagelimit: PaginationInfo.pagelimit }
            var pipeline = []
            var sort = (Object.keys(PaginationInfo.sort).length !== 0 ? PaginationInfo.sort : { '_id': -1 })
            let projection = PaginationInfo.projection ? PaginationInfo.projection : {}

            pipeline = IISMethods.GetPipelineForFilter(PaginationInfo.filter)

            const searchtext = req.body.searchtext || ""
            if (searchtext !== "") {
                pipeline.push(...IISMethods.GetGlobalSearchFilter(new _Survey(), searchtext))
            }

            const resp = await MainDB.getmenual(TableName, new _Survey(), pipeline, requiredPage, sort, true, "", projection)

            ResponseBody.pagename = PageName
            ResponseBody.formname = FormName
            ResponseBody.fltpagecollection = FltPageCollection
            ResponseBody.status = 200
            ResponseBody.message = Config.getResponsestatuscode()['200']
            ResponseBody.data = resp.ResultData
            ResponseBody.currentpage = resp.currentpage
            ResponseBody.nextpage = resp.nextpage
            ResponseBody.totaldocs = resp.totaldocs;
            ResponseBody.fieldorder = resp.fieldorderdata
            ResponseBody.formfieldorderdata = resp.formfieldorderdata

            req.ResponseBody = ResponseBody
            next()
        }
        catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err}
            next()
        }
    }

    //Insert
    async InsertSurvey(req, res, next) {
        try {
            var ResponseBody = {}
            const ObjectId = IISMethods.getobjectid()
            let ID = new ObjectId()

            let pipeline = [{$match : {_id : new ObjectId(req.body.surveyformid)}}]
            const formresp = await MainDB.getmenual('tblsurveyform', new _SurveyForm(), pipeline)
            req.body.formjson = formresp.ResultData[0] && formresp.ResultData[0].formjson
            req.body.description = formresp.ResultData[0] && formresp.ResultData[0].description
                        
            req.body._id = ID

            const resp = await MainDB.executedata('i', new _Survey(),TableName, req.body)
                        
            ResponseBody.status = resp.status
            ResponseBody.message = resp.message
            req.ResponseBody = ResponseBody
            next()
        }
        catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err}
            next()
        }
    }

    //Update
    async UpdateSurvey(req, res, next) {
        try {
            var ResponseBody = {}
            let ObjectId = IISMethods.getobjectid()

            let surveyrecordspipeline = [{ $match: { surveyid: new ObjectId(req.body._id) } }]
            let surveyrecordsresp = await MainDB.getmenual('tblsurveyrecords', new _SurveyRecords(), surveyrecordspipeline)

            if (!surveyrecordsresp.ResultData.length) {

                const pipelinedata = [{ $match: { '_id': new ObjectId(req.body._id) } }]
                const record = await MainDB.getmenual(TableName, new _Survey(), pipelinedata)

                var RecordInfo = record.ResultData[0].recordinfo
                RecordInfo.updateuid = req.headers.uid
                RecordInfo.updateby = req.headers.personname
                RecordInfo.updatedate = IISMethods.getdatetimeisostr()
                req.body.recordinfo = RecordInfo

                let pipeline = [{ $match: { _id: new ObjectId(req.body.surveyformid) } }]
                const formresp = await MainDB.getmenual('tblsurveyform', new _SurveyForm(), pipeline)

                req.body.formjson = formresp.ResultData[0] && formresp.ResultData[0].formjson
                req.body.description = formresp.ResultData[0] && formresp.ResultData[0].description

                const resp = await MainDB.executedata('u', new _Survey(), TableName, req.body)

                ResponseBody.status = resp.status
                ResponseBody.data = resp.data
                ResponseBody.message = resp.message
            }else{
                ResponseBody.status = 400
                ResponseBody.message = "Cannont Edit Survey Form Already Submitted"
            }
            req.ResponseBody = ResponseBody
            next()
        }
        catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

    //Delete
    async DeleteSurvey(req, res, next){
        try{
            var ResponseBody = {}

            // const rewardconfigurationmaster = await MainDB.createmodel('tblrewardconfigurationmaster', new _RewardConfiguration())
            // var dependency = [[ rewardconfigurationmaster['objModel'], {'surveyid' : req.body._id} ,"Reward Configuration"]]
            const resp = await MainDB.executedata('d', new _Survey(),TableName,req.body)
            
            ResponseBody.status = resp.status
            ResponseBody.message = resp.message                
            req.ResponseBody = ResponseBody
            next()
        }
        catch(err){
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err}
            next()
        }
    }

    

    async GetSurvey(req, res, next)
    {
        try {
           
            var ResponseBody = {}
            var PaginationInfo = req.body.paginationinfo
            let ObjectId = IISMethods.getobjectid()

            let customerid = ``
            if(PaginationInfo.filter.customerid){
                customerid = PaginationInfo.filter.customerid
                req.headers.uid = customerid
                delete PaginationInfo.filter.customerid 
            }

            let projectid = ``
            if(PaginationInfo.filter.projectid){
                projectid = PaginationInfo.filter.projectid
                delete PaginationInfo.filter.projectid 
            }
            
            const requiredPage = {pageno : PaginationInfo.pageno, skip : (PaginationInfo.pageno - 1) * PaginationInfo.pagelimit, pagelimit : PaginationInfo.pagelimit}
            var pipeline = []
            var sort = (Object.keys(PaginationInfo.sort).length !== 0 ? PaginationInfo.sort : {'_id' : 1})
            
            pipeline = IISMethods.GetPipelineForFilter(PaginationInfo.filter)

            const personpipeline = [{$match:{'_id':new ObjectId(req.headers.uid)}},{$project : {'departmentid' : 1}}]
            var person = await MainDB.getmenual('tblcustomer', new _Customer(), personpipeline)
            let persondata = person.ResultData[0]

            let adddata = [{'assigntosize' : 0},{'surveyformfor' : Config.surveyformfor['employee']}] 
            let department = undefined
            if (persondata && persondata.departmentid) {
                department = persondata.departmentid && persondata.departmentid.toString()       
                adddata.push({'department.departmentid': new ObjectId(department) , },)         
            }
            
            pipeline.push(
                {'$addFields' : {"assigntosize": {$size: "$assignedto"}}},
                {$match : {$or : [
                    {'customerid' : new ObjectId(req.headers.uid), 'surveyformfor' : Config.surveyformfor['customer']},
                    {'assignedto.personid': new ObjectId(req.headers.uid), 'surveyformfor' : Config.surveyformfor['employee'] },
                    {$and : adddata},
                ]}})

            const resp = await MainDB.getmenual(TableName, new _Survey(), pipeline, requiredPage, sort, true)

            let recordpipeline = [{$match : {'personid' :new ObjectId(req.headers.uid), 'surveyid' :new ObjectId(PaginationInfo.filter._id)}}]
            const recordresp = await MainDB.getmenual('tblsurveyrecords', new _SurveyRecords(), recordpipeline)

            if (customerid) {
                let person = await MainDB.getPersonData(new ObjectId(customerid), {'personname' : 1}) 
                if(person){
                    ResponseBody.persondata = person
                }else{
                    ResponseBody.persondata = {}
                }
            }
            if (projectid) {
                const projectPipeline = [{ $sort: { '_id': 1 } },{$match : {_id : new ObjectId(projectid)}},{$project : {"projectname" : 1}}]
                const projectResp = await MainDB.getmenual('tblprojectmaster', new _Project(), projectPipeline)                
                if(projectResp.ResultData && projectResp.ResultData.length){
                    ResponseBody.projectResp = projectResp.ResultData[0]
                }else{
                    ResponseBody.projectResp = {}
                }
            }


            if (resp.ResultData[0]) {

                if(!resp.ResultData[0].duedate || (resp.ResultData[0].duedate && new Date(resp.ResultData[0].duedate.substring(0,10)) >= new Date(new Date().toISOString().substring(0,10)))){

                    if(resp.ResultData[0].submitlimit && (recordresp.ResultData.length + 1 ) <= resp.ResultData[0].submitlimit){

                        ResponseBody.data = resp.ResultData
                    }else{
                        ResponseBody.limitexceeded = true
                    }
                }else{
                    ResponseBody.expired = true
                }
            }else{
                ResponseBody.data = []
            }

            if (!req.headers.masterlisting || (req.headers.masterlisting && req.headers.masterlisting == 'false')) {
                const Survey = new _Survey()
                if(resp.fieldorderdata){
                    ResponseBody.fieldorder = resp.fieldorderdata
                } else{
                    ResponseBody.fieldorder = Survey.getFieldOrder()
                }
            }

            ResponseBody.pagename = "Survey"
            ResponseBody.status = 200
            ResponseBody.message = Config.getResponsestatuscode()['200']
            
            ResponseBody.currentpage = resp.currentpage
            ResponseBody.nextpage = resp.nextpage
            req.ResponseBody = ResponseBody
            next()
        }
        catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err}
            next()
        }
    }

    async SurveyResponse(req, res, next){
        try {
            var ResponseBody = {}
            
            let ObjectId = IISMethods.getobjectid()

            let pipeline = [{$match : {surveyid : new ObjectId(req.body.surveyid)}}]
            let resp = await MainDB.getmenual('tblsurveyrecords', new _SurveyRecords(), pipeline)

            let surveypipeline = [{$match : {_id : new ObjectId(req.body.surveyid)}}]
            let surveyresp = await MainDB.getmenual(TableName, new _Survey(), surveypipeline)
            
            let activestatus = "Active"
            if (surveyresp.ResultData[0]) {
                if (new Date(surveyresp.ResultData[0].duedate.slice(0,10)) <= new Date(new Date().toISOString().slice(0,10))) {
                    activestatus = "Deactivate"
                }
            }

            ResponseBody.status = 200
            ResponseBody.message = Config.getResponsestatuscode()['200']
            ResponseBody.data = {
                data : resp.ResultData,
                responses : resp.ResultData.length,
                activestatus : activestatus
            }
            req.ResponseBody = ResponseBody
            next()
        }
        catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err}
            next()
        }
    }

    /// responses Data
    async SurveyAnalyticsResponse(req, res, next){
        try{
            var ResponseBody = {}

            const ObjectId = IISMethods.getObjectId()
            var PaginationInfo = req.body.paginationinfo
            // let surveyformid = PaginationInfo.filter.surveyformid
            let surveyid = PaginationInfo.filter.surveyid
            let personid = PaginationInfo.filter.personid
            let currentdate = new Date().toISOString()
            
            let surveypipeline = [{$match : {_id : new ObjectId(surveyid)}}]
            const surveyresp = await MainDB.getmenual(TableName, new _Survey(), surveypipeline)

            let formdata = surveyresp.ResultData[0] 
            
            let pipeline = [{$sort : {_id : 1}},{$match : {'surveyid' : new ObjectId(surveyid)}}]
            if (personid && personid !== "") {
                pipeline.push({$match  : {'personid' : new ObjectId(personid)}})
            }
            const resp = await MainDB.getmenual('tblsurveyrecords', new _SurveyRecords(), pipeline)

            
            formdata.responsecount = 0
            formdata.status = 0
            if (formdata.duedate && new Date(formdata.duedate.slice(0,10)) <= new Date(currentdate.slice(0,10))) {
                formdata.status = 1
            }

            let tempData
            let toperson = []
            
            for (const iterator of resp.ResultData) {
                if (!toperson.includes(iterator.personid.toString())) {
                    toperson.push(iterator.personid.toString())                    
                }

                formdata.responsecount += 1

                for (let i = 0; i < iterator.formjson.length; i++) { // main obj formjson

                    for (let j = 0; j < iterator.formjson[i].formfields.length; j++) { // sub obj formfields

                        let iteraterindex = iterator.formjson[i].formfields[j] // index of submited data
                        let formdataindex = formdata.formjson[i].formfields[j] // index of survey form data

                        if(formdataindex.type == 'likert'){

                            if(formdataindex.likertanalysis == undefined){
                                formdataindex.likertanalysis = []
                                for (const key in iteraterindex.answers) {
                                    let data = {}
                                    
                                    for (const key of formdataindex.options) {
                                        data[key] = 0
                                    }

                                    formdataindex.likertanalysis.push({[iteraterindex.answers[key].answer] : {data, personsanswers : [], labels : [], series : [] }})
                                }
                            }

                            if (formdataindex.likertanalysis != undefined && iteraterindex.answers.length) {
                                for(const obj of iteraterindex.answers){
                                    if(obj.personanswer != undefined){
                                        let optionIndex = formdataindex.likertanalysis.findIndex((o) => o.hasOwnProperty(obj.answer))
                                        formdataindex.likertanalysis[optionIndex][obj.answer].data[obj.personanswer] += 1
                                        formdataindex.likertanalysis[optionIndex][obj.answer].personsanswers.push({person : iterator.person, personanswer : obj.personanswer })
                                    }
                                }
                            }


                        }else{
                            // structure for graph
                            if (formdataindex.data == undefined) { 
                                formdataindex.data = {} 
                            
                                for (const key in iteraterindex.answers) {
                                    formdataindex.data[iteraterindex.answers[key].answer] = 0
                                }
                            }
    
                            /// count plus
                            // if (formdataindex.data) {
                            //     formdataindex.data[iteraterindex.personanswer] = formdataindex.data[iteraterindex.personanswer]  + 1
                            // }
                            if (formdataindex.data != undefined && iteraterindex.personanswer != undefined) {
                                if(Array.isArray(iteraterindex.personanswer)){
                                    for (const iterator of iteraterindex.personanswer) {
                                        formdataindex.data[iterator] = formdataindex.data[iterator]  + 1                                    
                                    }
                                }else{
                                    formdataindex.data[iteraterindex.personanswer] = formdataindex.data[iteraterindex.personanswer]  + 1
                                }
                            }
    
                            // if perosnarray not found add and push data
                            if (formdataindex.personsanswers == undefined) { formdataindex.personsanswers = [] }
    
                            if(Array.isArray(iteraterindex.personanswer)){
                                let personanswer
                                if(iteraterindex.type == 'uploadfile'){
                                    personanswer = iteraterindex.personanswer
                                }else{
                                    personanswer = iteraterindex.personanswer.join(', ')
                                }
                                formdataindex.personsanswers.push({
                                    person : iterator.person, 
                                    // ofperson : iterator.ofperson, 
                                    personanswer
                                })
                            }else{
                                formdataindex.personsanswers.push({
                                    person : iterator.person, 
                                    // ofperson : iterator.ofperson, 
                                    personanswer : iteraterindex.personanswer 
                                })
                            }
                        }

                        
                    }
                }

            }

            for (const mainobj of formdata.formjson) {
                for (const iterator of mainobj.formfields) {
                    if(iterator.type == 'likert'){
                        if(iterator.likertanalysis){
                            iterator.likertanalysis.map((option,i)=>{
                                for (const key in option[iterator.answers[i].answer].data) {
                                    option[iterator.answers[i].answer].series.push(option[iterator.answers[i].answer].data[key])
                                    option[iterator.answers[i].answer].labels.push(key)
                                }
                            })
                            iterator.nodata = false
                        }else{
                            iterator.nodata = true
                        }
                    }else{
                        /// labels array
                        if (iterator.labels == undefined) { iterator.labels = [] }
                        /// series array
                        if (iterator.series == undefined) { iterator.series = [] }
    
                        for (const key in iterator.data) {
                            iterator.series.push(iterator.data[key])
                            iterator.labels.push(key)
                        }
                    }
                }
            }
    
            // perosn list ------------------------------------
            // let personpipeline =  [{$sort:{'_id': 1}},{$project : {'personname' : 1,'isactive': 1,'iscustomer':1, 'departmentid' : 1, 'reportingtoid' : 1, 'reportingto' : 1}},{$match:{'isactive':1,'iscustomer':{$ne:1}}}]
            // const personResp = await MainDB.getmenual('tblcustomer', new _Customer(), personpipeline)
            
            // let toperson = []
            
            // if (formdata.surveyformfor && formdata.surveyformfor == Config.surveyformfor['employee']) {

            //     // person wise
            //     if (formdata.assignedto && formdata.assignedto.length) {
            //         for (const obj of formdata.assignedto) {
            //             toperson.push(obj.personid.toString())
            //         }
            //     }else if(formdata.department && formdata.department.length){// department wise
            //         for (const el of personResp.ResultData) {
            //             let find = formdata.department.find((o) => el.departmentid && o.departmentid.toString() == el.departmentid.toString())   
            //             if (find) {
            //                 toperson.push(el._id.toString())
            //             }
            //         }
            //     }

            // }else if(formdata.surveyformfor && formdata.surveyformfor == Config.surveyformfor['customer']){
                
            //     // customer wise
            //     if (formdata.customer && formdata.customer.length) {
            //         for (const data of formdata.customer) {
            //             toperson.push(data.customerid.toString())
            //         }
            //     }
            // }
            // perosn list ------------------------------------

            formdata.persons = toperson
            ResponseBody.data = formdata
            
            ResponseBody.status = 200
            ResponseBody.message = Config.getResponsestatuscode()['200']
            req.ResponseBody = ResponseBody
            next()
        }
        catch(err){
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err}
            next()
        }
    }

    //Insert
    async InsertSurveyRecords(req, res, next){
        try {
            var ResponseBody = {}
            const ObjectId = IISMethods.getobjectid()

            let ID = new ObjectId()

            // for(const section of req.body.formjson){
            //     for(const question of section.formfields){
            //         // if(question.type == 'signature'){
            //         //     if(question.personanswer && question.personanswer.length){
            //         //         question.personanswer = await IISMethods.movefileS3(question.personanswer, req.headers.subdomainname + '/survey/' + ID + '/' + req.body.person+ IISMethods.GetTimestamp() + '_Signature' )
            //         //     }
            //         // }
            //     }
            // }

            // if(req.body.exitapplication){
            //     let exitapplicationid = req.body.exitapplicationid
            //     let stageid = req.body.stageid
    
            //     const pipeline = [{ $match: { '_id': new ObjectId(exitapplicationid)} }]
            //     const record = await MainDB.getmenual('tblexitapplication', new _ExitApplication(), pipeline)
                
            //     // flow update
            //     for (const iterator of record.ResultData[0]?.exitflow) {
            //         if (iterator._id.toString() == stageid) {
            //             iterator.surveysubmit = 1
            //         }
            //     }
                
            //     let allfroms = record.ResultData[0]?.surveyresponse ? record.ResultData[0].surveyresponse : []

            //     allfroms.push({date : new Date().toISOString() , formjson : req.body.formjson, stageid : stageid,})
            //     record.ResultData[0].surveyresponse = allfroms
                
            //     const resp = await MainDB.executedata('u', new _ExitApplication(), 'tblexitapplication', record.ResultData[0])
    
            //     ResponseBody.status = resp.status
            //     ResponseBody.message = resp.status == 200 ? "survey submit sucessfully" : resp.message
            // }else{

                if (req.body.customerid || req.body.personid) {
                    let ids = req.body.customerid ? req.body.customerid : req.body.personid
                    let person = await MainDB.getPersonData(new ObjectId(ids), {'personname' : 1}) 
                    if(person){
                        req.body.person = person.personname
                    }
                }

                // const resp = await MainDB.executedata('i', new _SurveyRecords(),'tblsurveyrecords', req.body)

                // let valid = false

                // const pipeline = [{ $match: { '_id': new ObjectId(req.body.surveyid)} }]
                // const record = await MainDB.getmenual('tblsurvey', new _Survey(), pipeline)

                // if(record.ResultData[0]){
                //     if(record.ResultData[0].customerid && record.ResultData[0].customerid.toString() == req.body.personid){
                //         valid = true
                //     }else{
                //         let find = record.ResultData[0].assignedto.find((o)=> o.personid.toString() == req.body.personid)
                //         if(find){
                //             valid = true
                //         }
                //     }
                // }

                let valid = true

                // if(surveyresp.ResultDat[0]){

                //     if()

                // }else{
                //     ResponseBody.status = 401
                //     ResponseBody.message = "Due date"
                // }

                if(valid){

                    const resp = await MainDB.executedata('i', new _SurveyRecords(),'tblsurveyrecords', req.body)
    
                    if(resp.status == 200){


                        var newpipeline = [{$match: {_id: resp.data.surveyid}}]
                        const surveyresp = await MainDB.getmenual(TableName, new _Survey(), newpipeline)
    
                        // if(surveyresp.ResultData[0]?.responseaccesspersons.length){
                        //     // send message persons
                        //     let tousers = []
        
                        //     for(const person of surveyresp.ResultData[0].responseaccesspersons){
                        //         tousers.push(person.personid.toString())
                        //     }
        
                        //     let data = {
                        //         surveyform : surveyresp.ResultData[0].surveyform,
                        //         personname : req.body.person
                        //     }
                        //     let title = IISMethods.makeContent(Config.getNotificationTitles()['surveysubmit'],data)
        
                        //     var payload = {
                        //         title,
                        //         body: {
                        //             title,
                        //         },
                        //         type: Config.getNotificationType()['surveysubmit'],
                        //         pagename : 'survey',
                        //     }
                        //     await MainDB.sendNotification({tousers:tousers,payload:payload,webpushnotify:true,subdomain:req.headers['subdomainname']})
                        // }
                    }
        
                    ResponseBody.status = resp.status
                    ResponseBody.message = resp.message

                }


            // }

            req.ResponseBody = ResponseBody
            next()
        }
        catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err}
            next()
        }
    }


    // survey email send api
    async SurveyEmailSend(req, res, next){
        try {
            
            let personid = req.body.personid
            let ObjectId = IISMethods.getObjectId()
            // perosn
            let personpipeline =  [{$sort:{'_id': 1}},{$project : {'personname' : 1,'isactive': 1,'iscustomer':1, 'departmentid' : 1}},{$match:{'isactive':1,'iscustomer':{$ne:1}}}]
            const personResp = await MainDB.getmenual('tblcustomer', new _Customer(), personpipeline)

            let surveypipeline = [{$match : {_id : new ObjectId(req.body.surveyid)}}]
            let surveyresp = await MainDB.getmenual(TableName, new _Survey(), surveypipeline)

            let survey =  surveyresp.ResultData[0]
            var toperson = []

            if (survey) {

                if (personid) {
                    let personfind = personResp.ResultData.find((o) => o._id.toString() == personid)
                    // email template
                    let template = Config.getEmailTemplates()['survey']
                    let senddata = {
                        person: personfind && personfind.personname ? personfind.personname : '',
                        duedate: survey.duedate.slice(0, 10),
                        //Ruchir Mail Changes
                        url : IISMethods.encrypturl(survey.url),
                        surveyform: survey.surveyform,
                        surveytype: survey.surveytype,
                        requestedpersonid : req.headers.uid,
                        title : "Survey"
                    }
                    await MainDB.sendMail('',[personid],template,'',senddata)

                    if (surveyresp.ResultData[0].assignedto) {
                        for (let iterator of surveyresp.ResultData[0].assignedto) {
                            if (iterator.personid.toString() == personid) {
                                if (iterator.date && iterator.date.length) {
                                    iterator.date.push(new Date().toISOString())
                                }else{
                                    iterator.date = [new Date().toISOString()]
                                }
                                
                            }
                        }
                        const resp = await MainDB.executedata('u', new _Survey(),TableName, surveyresp.ResultData[0])
                    }
                    
                    const updatepipeline = [{_id : new ObjectId(req.body.surveyid), 'assignedto.personid' : new ObjectId(personid) }, {$set : { date : new Date().toISOString() }}]
                    let resp = await MainDB.Update(TableName, new _Survey(), updatepipeline)
                    
                }else{
                    if (survey.surveyformfor && survey.surveyformfor == Config.surveyformfor['employee']) {
                        
                        // person wise
                        if (survey.assignedto && survey.assignedto.length) {
        
                            for (const formdata of survey.assignedto) {
                                if (!toperson.includes(formdata.personid.toString())) {
                                    
                                    // email template
                                    let template = Config.getEmailTemplates()['survey']
                                    let senddata = {
                                        person: formdata.person,
                                        duedate: survey.duedate.slice(0, 10),
                                        //Ruchir Mail Changes
                                        url: IISMethods.encrypturl(survey.url),
                                        surveyform: survey.surveyform,
                                        surveytype : survey.surveytype,
                                        requestedpersonid : req.headers.uid,
                                        title : "Survey"

                                    }
                                    await MainDB.sendMail('',[formdata.personid.toString()],template,'',senddata)
                                    
                                    toperson.push(formdata.personid.toString())
                                    
                                    if (formdata.date && formdata.date.length) {
                                        formdata.date.push(new Date().toISOString())
                                    }else{
                                        formdata.date = [new Date().toISOString()]
                                    }
                                }
                            }
        
                            const resp = await MainDB.executedata('u', new _Survey(),TableName, survey)
                            
                        }else if(survey.department && survey.department.length){// department wise
        
                            for (const el of personResp.ResultData) {
        
                                let find = survey.department.find((o) =>  el.departmentid && o.departmentid.toString() == el.departmentid.toString())

                                if (find && !toperson.includes(el._id.toString())) {
                                    let template = Config.getEmailTemplates()['survey']
                                    let senddata = {
                                        person: el.person,
                                        duedate: survey.duedate.slice(0, 10),
                                        //Ruchir Mail Changes
                                        url: IISMethods.encrypturl(survey.url),
                                        surveyform: survey.surveyform,
                                        surveytype: survey.surveytype,
                                        requestedpersonid : req.headers.uid,
                                        title : "Survey"

                                    }
                                    await MainDB.sendMail('',[el._id.toString()],template,'',senddata)
        
                                    toperson.push(el._id.toString())
                                }
                            }
        
                        }

                    } else if (survey.surveyformfor && survey.surveyformfor == Config.surveyformfor['customer']) {

                        // if (survey.customer && survey.customer.length) { // customer wise

                        //     for (const formdata of survey.customer) {
                        //         if (!toperson.includes(formdata.customerid.toString())) {

                        // email template
                        let template = Config.getEmailTemplates()['clientfeedback']
                        let senddata = {
                            person: survey.customer,
                            duedate: survey.duedate.slice(0, 10),
                            //Ruchir Mail Changes
                            url: IISMethods.encrypturl(survey.url), 
                            surveyform: survey.surveyform,
                            surveytype: survey.surveytype,
                            requestedpersonid: req.headers.uid,
                            title: "Client Feedback"
                        }
                        await MainDB.sendMail('', [survey.customerid.toString()], template, '', senddata)

                        //         toperson.push(formdata.customerid.toString())
                        //     }
                        // }

                        // }

                    }
                }
                
            }

            var ResponseBody = {}
            ResponseBody.data = toperson
            ResponseBody.status = 200
            ResponseBody.message = Config.getResponsestatuscode()['200']           
            req.ResponseBody = ResponseBody
            next()
        }
        catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err}
            next()
        }
    }

    // End Survey 
}