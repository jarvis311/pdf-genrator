import { IISMethods,MainDB, Config } from "../../../config/Init.js"
import _Guest from "../../../model/masters/Guest.js"
import _Approve from '../../../model/Approve.js'

const TableName = "tblguestmaster"
const PageName = "guest"
const FormName = "guest"
const FltPageCollection = "guestmaster"

export default class GuestMaster {
	// List guest
	async ListGuestMaster(req, res, next) {
		try {
            var ResponseBody = {}
            var PaginationInfo =  req.body.paginationinfo

            const requiredPage = {pageno : PaginationInfo.pageno, skip : (PaginationInfo.pageno - 1) * PaginationInfo.pagelimit, pagelimit : PaginationInfo.pagelimit}
            var pipeline = []
            var sort = (Object.keys(PaginationInfo.sort).length !== 0 ? PaginationInfo.sort : {'_id' :-1})
            let projection = PaginationInfo.projection ? PaginationInfo.projection : {}
            let fieldorder = req.body.paginationinfo.isfieldorder ? req.body.paginationinfo.isfieldorder : 0


            pipeline = IISMethods.GetPipelineForFilter(PaginationInfo.filter)

            const searchtext = req.body.searchtext || ""
            if (searchtext !== "") {
                pipeline.push(...IISMethods.GetGlobalSearchFilter(new _Guest(), searchtext))
            }
                        
            const resp = await MainDB.getmenual(TableName, new _Guest(), pipeline, requiredPage, sort, fieldorder,"", projection)

              
            ResponseBody.pagename = PageName
            ResponseBody.formname = FormName
			ResponseBody.fltpagecollection = FltPageCollection
            ResponseBody.status = 200
            ResponseBody.message = Config.getResponsestatuscode()['200']
            ResponseBody.data = resp.ResultData
            ResponseBody.currentpage = resp.currentpage

            ResponseBody.nextpage = resp.nextpage   
            ResponseBody.totaldocs = resp.totaldocs;
            ResponseBody.fieldorder = resp.fieldorderdata 
            ResponseBody.formfieldorderdata = resp.formfieldorderdata            

            req.ResponseBody = ResponseBody
            next()
		} catch (err) {
			req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
			next()
		}
	}

	// Insert guest
	async InsertGuestMaster(req, res, next) {
		try {
			const ResponseBody = {}
                        
            const preapproveGuest = []
            const {startdate, enddate, starttime, endtime, weekdays} = req.body

            const daysMapping = {
                'Sun': 0,
                'Mon': 1,
                'Tue': 2,
                'Wed': 3,
                'Thu': 4,
                'Fri': 5,
                'Sat': 6
            };
        
            // Convert days of the week to numbers for easy comparison
            const days = weekdays.map(day => daysMapping[day]);
        
            const startDateObj = new Date(startdate);
            const endDateObj = new Date(enddate);
            const finalArray = [];
        
            // Parse start and end time for hour and minute extraction
            const { hours: startHour, minutes: startMinute } = IISMethods.parseTime(starttime);
            const { hours: endHour, minutes: endMinute } = IISMethods.parseTime(endtime);
        
            // Iterate through each date from startdate to enddate
            for (let currentDate = new Date(startDateObj); currentDate <= endDateObj; currentDate.setDate(currentDate.getDate() + 1)) {
                if (days.includes(currentDate.getDay())) {
                    // Set the start time for the current date
                    const formattedStartDate = new Date(currentDate);
                    formattedStartDate.setHours(startHour, startMinute, 0, 0);
        
                    // Set the end time for the current date
                    const formattedEndDate = new Date(currentDate);
                    formattedEndDate.setHours(endHour, endMinute, 59, 999);
        
                    // Push the formatted date object to the final array
                    finalArray.push({
                        startdate: formattedStartDate.toISOString(),
                        enddate: formattedEndDate.toISOString()
                    });
                }
            }


            for (let Obj of req.body.guest) {
                const data = {
                    propertyid: req.headers.propertyid,
                    property: req.headers.property,
                    customerid: req.headers.uid,
                    customer: req.headers.personname,
                    guestname: Obj.guestname,
                    mobilenumber: Obj.mobilenumber,
                    allowtime: finalArray,
                    startdate: req.body.startdate,
                    enddate: req.body.enddate,
                    floor: req.body.floor,
                    floorid: req.body.floorid,
                    unit: req.body.unit,
                    unitid: req.body.unitid,
                    wing: req.body.wing,
                    wingid: req.body.wingid,
                    guesttype: 1,
                    iscollectfromgate: req.body.iscollectfromgate,
                    weeks:weekdays,
                    starttime:starttime,
                    endtime:endtime,
                    // deliverycompany:req.body.deliverycompany,
                    // deliverycompanyid:req.body.deliverycompanyid,
                    otp: IISMethods.generatecode(6),
                    approvetype:1
                }
                preapproveGuest.push(data)
            }

            let resp = await MainDB.InsertMany(TableName, new _Guest(), preapproveGuest)

            if (resp.status == 200) {
                await MainDB.InsertMany("tblapprovemaster", new _Approve(), preapproveGuest)
            }

			ResponseBody.status = resp.status
			ResponseBody.message = resp.message

			req.ResponseBody = ResponseBody
			next()
		} catch (err) {
			req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
			next()
		}
	}

	// Update guest
	async UpdateGuestMaster(req, res, next) {
		 try {

            const ObjectId = IISMethods.getobjectid()
            var ResponseBody = {}

            const pipeline = [{ $match: { '_id': ObjectId(req.body._id) } }]
            const record = await MainDB.getmenual(TableName, new _Guest(), pipeline)
            
            var RecordInfo = record.ResultData[0].recordinfo
            RecordInfo.updateuid = req.headers.uid
            RecordInfo.updateby = req.headers.personname
            RecordInfo.updatedate = IISMethods.getdatetimeisostr()
            req.body.recordinfo = RecordInfo

            const resp = await MainDB.executedata('u', new _Guest(), TableName, req.body)

            var ResponseBody = {}
            ResponseBody.status = resp.status
            ResponseBody.data = resp.data
            ResponseBody.message = resp.message

            req.ResponseBody = ResponseBody
            next()
        }
        catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
	}

	// Delete guest 
	async DeleteGuestMaster(req, res, next) {
		try {
			const ResponseBody = {}

            const resp = await MainDB.executedata('d', new _Guest(), TableName, req.body)
   
			ResponseBody.status = resp.status
			ResponseBody.message = resp.message

			req.ResponseBody = ResponseBody
			next()
		} catch (err) {
			req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
			next()
		}
	}

}
