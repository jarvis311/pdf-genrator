import { IISMethods,MainDB, Config } from "../../../config/Init.js"
import _State from "../../../model/masters/State.js"
import _Pincode from '../../../model/masters/PincodeMaster.js'
import _City from '../../../model/masters/City.js'
import {Propertycommon} from '../../../model/masters/Property/PropertyMaster.js'
import _Customer from '../../../model/Onboarding/Customer.js'
import _Gatekeeper from '../../../model/Onboarding/GateKeeper.js'
import _Employee from '../../../model/Onboarding/Employee.js'

const TableName = "tblstatemaster"
const PageName = "state"
const FormName = "state"
const FltPageCollection = "statemaster"

export default class StateMaster {
	// List state
	async ListState(req, res, next) {
		try {
            var ResponseBody = {}
            var PaginationInfo =  req.body.paginationinfo

            const requiredPage = {pageno : PaginationInfo.pageno, skip : (PaginationInfo.pageno - 1) * PaginationInfo.pagelimit, pagelimit : PaginationInfo.pagelimit}
            var pipeline = []
            var sort = (Object.keys(PaginationInfo.sort).length !== 0 ? PaginationInfo.sort : {'_id' :-1})
            let projection = PaginationInfo.projection ? PaginationInfo.projection : {}
            let fieldorder = req.body.paginationinfo.isfieldorder ? req.body.paginationinfo.isfieldorder : 0

            pipeline = IISMethods.GetPipelineForFilter(PaginationInfo.filter)

            const searchtext = req.body.searchtext || ""
            if (searchtext !== "") {
                pipeline.push(...IISMethods.GetGlobalSearchFilter(new _State(), searchtext))
            }
                        
            const resp = await MainDB.getmenual(TableName, new _State(), pipeline, requiredPage, sort, fieldorder,"", projection)
              
            ResponseBody.pagename = PageName
            ResponseBody.formname = FormName
			ResponseBody.fltpagecollection = FltPageCollection
            ResponseBody.status = 200
            ResponseBody.message = Config.getResponsestatuscode()['200']
            ResponseBody.data = resp.ResultData
            ResponseBody.currentpage = resp.currentpage
            ResponseBody.nextpage = resp.nextpage   
            ResponseBody.fieldorder = resp.fieldorderdata 
            ResponseBody.totaldocs = resp.totaldocs;
            ResponseBody.formfieldorderdata = resp.formfieldorderdata            

            req.ResponseBody = ResponseBody
            next()
		} catch (err) {
			req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
			next()
		}
	}

	// Insert State
	async InsertState(req, res, next) {
		try {
			const ResponseBody = {}
            
			const resp = await MainDB.executedata("i", new _State(), TableName, req.body)

			ResponseBody.status = resp.status
			ResponseBody.message = resp.message
            ResponseBody.data = resp.data

			req.ResponseBody = ResponseBody
			next()
		} catch (err) {
			req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
			next()
		}
	}

	// Update State
	async UpdateState(req, res, next) {
		 try {

            const ObjectId = IISMethods.getobjectid()
            var ResponseBody = {}

            const pipeline = [{ $match: { '_id': ObjectId(req.body._id) } }]
            const record = await MainDB.getmenual(TableName, new _State(), pipeline)
            
            var RecordInfo = record.ResultData[0].recordinfo
            RecordInfo.updateuid = req.headers.uid
            RecordInfo.updateby = req.headers.personname
            RecordInfo.updatedate = IISMethods.getdatetimeisostr()
            req.body.recordinfo = RecordInfo

             //Dependency Check
             const cityObjModel = await MainDB.createmodel('tblcitymaster', new _City())
             const pincodeObjModel = await MainDB.createmodel('tblpincodemaster', new _Pincode())
             const propertyObjModel = await MainDB.createmodel('tblproperty', new Propertycommon())
             const customerObjModel = await MainDB.createmodel('tblcustomer', new _Customer())
             const employeeObjModel = await MainDB.createmodel('tblemployee', new _Employee())
             const gatekeeperObjModel = await MainDB.createmodel('tblgatekeeper', new _Gatekeeper())

             var dependency = [
                 [cityObjModel['objModel'], { stateid: req.body._id }, "City"],
                 [pincodeObjModel['objModel'], { stateid: req.body._id }, "Pincode"],
                 [propertyObjModel['objModel'], { stateid: req.body._id }, "Property"],
                 [customerObjModel['objModel'], { stateid: req.body._id }, "Customer"],
                 [employeeObjModel['objModel'], { stateid: req.body._id }, "Employee"],
                 [gatekeeperObjModel['objModel'], { stateid: req.body._id }, "Gatekeeper"],
             ]

             const resp = await MainDB.executedata('u', new _State(), TableName, req.body, true, dependency)

             if (resp.status == 200) {

                 // Update Dependency
                 const updatePipeline = [
                     { stateid: req.body._id },
                     { $set: { state: req.body.state, } }
                 ]
                 const updateModelObj = {
                     tblcitymaster: new _City(),
                     tblpropertymaster: new Propertycommon(),
                     tblemployee: new _Employee(),
                     tblcustomer: new _Customer(),
                     tblgatekeeper: new _Gatekeeper()
                 }
                 const tempArray = []
                 for (const key in updateModelObj) {
                     tempArray.push(MainDB.UpdateMany(key, updateModelObj[key], updatePipeline))
                 }
                 await Promise.all(tempArray)
             }

            var ResponseBody = {}
            ResponseBody.status = resp.status
            ResponseBody.data = resp.data
            ResponseBody.message = resp.message

            req.ResponseBody = ResponseBody
            next()
        }
        catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
	}

	// Delete state 
	async DeleteState(req, res, next) {
		try {
			const ResponseBody = {}

            //Dependency Check
            const cityObjModel = await MainDB.createmodel('tblcitymaster', new _City())
            const pincodeObjModel = await MainDB.createmodel('tblpincodemaster', new _Pincode())
            const propertyObjModel = await MainDB.createmodel('tblproperty', new Propertycommon())
            const customerObjModel = await MainDB.createmodel('tblcustomer', new _Customer())
            const employeeObjModel = await MainDB.createmodel('tblemployee', new _Employee())
            const gatekeeperObjModel = await MainDB.createmodel('tblgatekeeper', new _Gatekeeper())
   
            var dependency = [
                   [cityObjModel['objModel'], { stateid: req.body._id },"City"],
                   [pincodeObjModel['objModel'], { stateid: req.body._id },"Pincode"],
                   [propertyObjModel['objModel'], { stateid: req.body._id },"Property"],
                   [customerObjModel['objModel'], { stateid: req.body._id },"Customer"],
                   [employeeObjModel['objModel'], { stateid: req.body._id },"Employee"],
                   [gatekeeperObjModel['objModel'], { stateid: req.body._id },"Gatekeeper"],
               ]

            const resp = await MainDB.executedata('d', new _State(), TableName, req.body, true, dependency)
   
			ResponseBody.status = resp.status
			ResponseBody.message = resp.message

			req.ResponseBody = ResponseBody
			next()
		} catch (err) {
			req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
			next()
		}
	}

}
