import { sendResponse } from '../../../config/apiconfig.js'
import { IISMethods, Config, MainDB } from "../../../config/Init.js"
import _Complaint from '../../../model/Complaint/Complaint.js'
import _ComplaintLog from '../../../model/Complaint/ComplaintLog.js'
import _ComplaintFlow from '../../../model/Complaint/ComplaintFlow.js'
import _Customer from '../../../model/Onboarding/Customer.js'
import _ComplaintStageFlow from '../../../model/Complaint/ComplaintStageFlow.js'
import _ComplaintStage from '../../../model/Complaint/ComplaintStage.js'
import _Employee from '../../../model/Onboarding/Employee.js'


export default class ComplaintAcceptNotify {

    async ComplaintAcceptNotify() {
        try {
            //FETCHED NOT ACCEPTED TICKETS
            console.log("calling 1")

            let pipeline = [{ $match: { 'accepted': 0 ,'isskip':0} }]
            let resp = await MainDB.getmenual('tblcomplaint', new _Complaint(), pipeline)

            if (resp.ResultData.length) {

                //COMPLAINT TICKET FLOW
                let flowpipeline = [{ $sort: { '_id': 1 } }]
                let flowresp = await MainDB.getmenual('tblcomplaintflow', new _ComplaintFlow(), flowpipeline)


                const personpipeline = [{ $match: { 'isactive': 1 } }, { $project: { "departmentid": 1, "department": 1, "designation": 1, "designationid": 1 } }]
                const personresp = await MainDB.getmenual('tblemployee', new _Employee(), personpipeline)

                //FOR ALL TICKETS
                for (const iterator of resp.ResultData) {

                    let findflow = flowresp.ResultData.find((o) => o.complaintcategoryid.toString() == iterator.complaintcategoryid.toString() && o.propertyid.toString() == iterator.propertyid.toString())

                    if (findflow && iterator.timestamp) {

                        let entry = new Date(iterator.timestamp).toISOString()
                        let dif = new Date() - new Date(entry)

                        let mindif = dif / 60000 //2
                        let accepttime = 0
                        let index = 0
                        
                        //FOR complaint ACCEPT
                        for (const flow of findflow.complaintflow) {
                            //IF ACCEPT TIME ADDED
                            if (flow.accepttime) {
                                accepttime += flow.accepttime

                                //IF ACCEPT TIME AND DIFFERENCE OF ADDED AND CURRENT TIME IS SAME SEND 
                                if (parseFloat(mindif.toFixed()) == accepttime) {

                                    //NEXT NODE
                                    let newflow = findflow.complaintflow[index + 1]

                                    let personids = []
                                    let assignedtos = []


                                    if (newflow && newflow.assignedperson && newflow.assignedperson.length) {
                                        for (const assigny of newflow.assignedperson) {
                                            personids.push(assigny.assignedpersonid.toString())
                                            assignedtos.push({
                                                assignedtoid: assigny.assignedpersonid,
                                                assignedto: assigny.assignedperson
                                            })
                                        }
                                    }

                                    const assignperson = assignedtos.map(obj => obj.assignedto)
                                    const notaccepted = iterator.log.filter(({ logtype }) => logtype === 0 || logtype === 2).flatMap(({ assignedto }) => assignedto.map(person => person.assignedto));

                                    const log = [{
                                        statusid:iterator.statusid,
                                        status: iterator.status,
                                        assignedto:assignedtos,
                                        logdatetime: IISMethods.getdatetimeisostr(),
                                        logtype:2,
                                        message:`The ticket has been assigned to ${assignperson} with a status of "${iterator.status}". However, ${notaccepted} has not accepted the ticket.` ,
                                    }]

                                    if (assignedtos.length) {
                                        const updatePipeline = [{ _id: iterator._id }, { $push: { assignedto: assignedtos , log: log } }]
                                        await MainDB.Update("tblcomplaint", new _Complaint(), updatePipeline)
                                       // console.log("🚀 ~ ComplaintAcceptNotify ~ ComplaintAcceptNotify ~ updatePipeline:", JSON.stringify(updatePipeline))
                                    }

                                    // if (assignedtos.length) {
                                    //     const updatePipeline = {
                                    //         $push: {
                                    //             assignedto: { $each: assignedtos }, 
                                    //             log: { $each: log },
                                    //         },
                                    //     };
                                    //    const d = await MainDB.Update("tblcomplaint",new _Complaint(),{ _id: iterator._id },updatePipeline )
                                    //    console.log("🚀 ~ ComplaintAcceptNotify ~ ComplaintAcceptNotify ~ updatePipeline:", updatePipeline)
                                    //    console.log("🚀 ~ ComplaintAcceptNotify ~ ComplaintAcceptNotify ~ d:", d)
                                    // }

                                    if (personids.length) {
                                        let link = ``

                                        //SEND NOTIFICATION --------------------------------------------------
                                        if (newflow.alerttype && newflow.alerttype.some(alert => alert.alerttypeid.toString() == Config.alerttype['notificationid'])) {
                                            let title = IISMethods.makeContent(Config.getNotificationTitles()['supportticket'], iterator)

                                            // let title = Config.getNotificationTitles()['supportticket']
                                            const payload = {
                                                title: title,
                                                body: {
                                                    ticketid: iterator._id.toString(),
                                                    categoryid: iterator.complaintcategoryid,
                                                    category: iterator.supportcategory,
                                                    supportcategoryseries: iterator.ticketid,
                                                    subject: iterator.subject,
                                                    description: iterator.description,
                                                    owner: iterator.owner,
                                                    //Ruchir encryption changes
                                                    url: link
                                                },
                                                type: Config.notificationtype['supportticket'],
                                                pagename: 'supportticket',
                                            }
                                           // await MainDB.sendNotification({ tousers: personids, payload: payload, webpushnotify: true })
                                        }

                                        // SEND MAIL --------------------------------------------------
                                        if (newflow.alerttype && newflow.alerttype.some(alert => alert.alerttypeid.toString() == Config.alerttype['emailid'])) {

                                            let template = Config.getEmailTemplates()['complaint']

                                            let senddata = {
                                                complaintcategory: iterator.complaintcategory,
                                                ticketid: iterator.ticketid,
                                                subject: iterator.subject,
                                                description: iterator.description,
                                                owner: iterator.owner,
                                                priority: iterator.priority,
                                                notsloved: "",
                                                datetime: IISMethods.getDateFormats(iterator.recordinfo.entrydate, 14),
                                                //Ruchir encryption changes
                                                url: link
                                            }

                                            const emailto = await MainDB.EmployeeEmails(personids)

                                            await MainDB.sendEmail({
                                                from: process.env.EMAIL_FROM,
                                                to: emailto,
                                                subject: iterator.subject,
                                                data: senddata,
                                                templateid: template
                                            })
                                        }

                                    }
                                }
                            }
                            index += 1
                        }
                    }
                }
            }
        }
        catch (err) {
            console.log(err)
        }
    }

}
