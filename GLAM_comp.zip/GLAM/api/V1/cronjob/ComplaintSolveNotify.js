import { sendResponse } from '../../../config/apiconfig.js'
import {IISMethods,Config, MainDB} from "../../../config/Init.js"
import _DBConfig from "../../../config/DBConfig.js"
import _Complaint from '../../../model/Complaint/Complaint.js'
import _ComplaintLog from '../../../model/Complaint/ComplaintLog.js'
import _ComplaintFlow from '../../../model/Complaint/ComplaintFlow.js'
import _Customer from '../../../model/Onboarding/Customer.js'
import _ComplaintStageFlow from '../../../model/Complaint/ComplaintStageFlow.js'
import _ComplaintStage from '../../../model/Complaint/ComplaintStage.js'

export default class ComplaintSolveNotify {

    async ComplaintTicketSolveNotify() {
        try {
            console.log("calling ticket 1")
            // Fetch stages that are incomplete
            const stagePipeline = [
                { $sort: { '_id': 1 } },
                { $match: { 'iscomplete': 0 } }
            ];
            const stageResponse = await MainDB.getmenual('tblcomplaintstage', new _ComplaintStage(), stagePipeline);
    
            // Get IDs of non-solved stages
            const openStageIds = stageResponse.ResultData.map(stage => stage._id);
    
            // Fetch tickets that are not solved and not skipped
            const ticketPipeline = [
                {
                    $match: {
                        'statusid': { $in: openStageIds },
                        'isskip': 0,
                        'accepted': 1
                    }
                }
            ];
            const ticketResponse = await MainDB.getmenual('tblcomplaint', new _Complaint(), ticketPipeline);
    
            if (ticketResponse.ResultData.length) {
                // Fetch complaint flow
                const flowPipeline = [{ $sort: { '_id': 1 } }];
                const flowResponse = await MainDB.getmenual('tblcomplaintflow', new _ComplaintFlow(), flowPipeline);
    
                const currentDate = new Date();
    
                for (const ticket of ticketResponse.ResultData) {
                    const assignedPerson = ticket.assignedto;
                    console.log("Current Assigned Person:", JSON.stringify(assignedPerson));
    
                    // Find corresponding flow
                    const matchedFlow = flowResponse.ResultData.find(flow => 
                        flow.complaintcategoryid.toString() === ticket.complaintcategoryid.toString() &&
                        flow.propertyid.toString() === ticket.propertyid.toString()
                    );
    
                    console.log("Matched Flow:", JSON.stringify(matchedFlow));
    
                    if (matchedFlow && ticket.acceptedtimestamp) {
                        const acceptedTime = new Date(ticket.acceptedtimestamp);
                        const timeDifference = currentDate - acceptedTime;
                        const elapsedMinutes = timeDifference / 60000;
    
                        let cumulativeSolveTime = 0;
    
                        for (let i = 0; i < matchedFlow.complaintflow.length; i++) {
                            const flowStep = matchedFlow.complaintflow[i];
    
                            if (flowStep.solvetime) {
                                cumulativeSolveTime += flowStep.solvetime;
    
                                if (elapsedMinutes >= cumulativeSolveTime) {
                                    const nextFlowStep = matchedFlow.complaintflow[i + 1];
    
                                    if (nextFlowStep && nextFlowStep.assignedperson?.length) {
                                        const assignedTo = nextFlowStep.assignedperson.map(person => ({
                                            assignedtoid: person.assignedpersonid,
                                            assignedto: person.assignedperson
                                        }));
    
                                        const logEntry = {
                                            statusid: ticket.statusid,
                                            status: ticket.status,
                                            assignedto: assignedTo,
                                            logdatetime: IISMethods.getdatetimeisostr(),
                                            logtype: 3,
                                            message: `The ticket has not been resolved yet. It is assigned to ${assignedTo.map(a => a.assignedto).join(', ')}, and the current status is "${ticket.status}".`
                                        };
    
                                        // Update ticket with new assignment and log entry
                                        const updatePipeline = [
                                            { _id: ticket._id },
                                            { $push: { assignedto: assignedTo, log: logEntry } }
                                        ];
                                        await MainDB.Update("tblcomplaint", new _Complaint(), updatePipeline);
    
                                        // Notification handling
                                        const personIds = nextFlowStep.assignedperson.map(person => person.assignedpersonid.toString());
    
                                        if (nextFlowStep.alerttype) {
                                            const notificationAlert = nextFlowStep.alerttype.find(alert => alert.alerttypeid.toString() === Config.alerttype.notificationid);
                                            if (notificationAlert) {
                                                const title = IISMethods.makeContent(Config.getNotificationTitles().supportticketnotsolve, ticket);
                                                const payload = {
                                                    title,
                                                    body: {
                                                        ticketid: ticket._id.toString(),
                                                        categoryid: ticket.complaintcategoryid,
                                                        category: ticket.supportcategory,
                                                        supportcategoryseries: ticket.ticketid,
                                                        subject: ticket.subject,
                                                        description: ticket.description,
                                                        owner: ticket.owner
                                                    },
                                                    type: Config.notificationtype.supportticket,
                                                    pagename: 'supportticket'
                                                };
                                                await MainDB.sendNotification({
                                                    tousers: personIds,
                                                    payload,
                                                    webpushnotify: true
                                                });
                                            }
    
                                            const emailAlert = nextFlowStep.alerttype.find(alert => alert.alerttypeid.toString() === Config.alerttype.emailid);
                                            if (emailAlert) {
                                                const emailTemplate = Config.getEmailTemplates().complaint;
                                                const emailData = {
                                                    complaintcategory: ticket.complaintcategory,
                                                    ticketid: ticket.ticketid,
                                                    subject: ticket.subject,
                                                    description: ticket.description,
                                                    owner: ticket.owner,
                                                    priority: ticket.priority,
                                                    notsolved: "is not solved yet",
                                                    datetime: IISMethods.getDateFormats(ticket.recordinfo.entrydate, 14)
                                                };
                                                const emailRecipients = await MainDB.EmployeeEmails(personIds);
                                                await MainDB.sendEmail({
                                                    from: process.env.EMAIL_FROM,
                                                    to: emailRecipients,
                                                    subject: ticket.subject,
                                                    data: emailData,
                                                    templateid: emailTemplate
                                                });
                                            }
                                        }
                                    }
                                    break;
                                }
                            }
                        }
                    }
                }
            }
        } catch (error) {
            console.error("Error in ComplaintTicketSolveNotify:", error);
        }
    }
    

}
