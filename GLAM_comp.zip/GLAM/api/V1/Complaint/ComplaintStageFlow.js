import {IISMethods, Config, MainDB} from '../../../config/Init.js'
import _ComplaintStageFlow from '../../../model/Complaint/ComplaintStageFlow.js'
import _Complaint from '../../../model/Complaint/Complaint.js'


const TableName = "tblcomplaintstageflow"
const PageName = "complaintstageflow"
const FormName = "complaintstageflow"
const FltPageCollection = "complaintstageflow"

export default class ComplaintStageFlow{

    // START Support Ticket Stage Flow
    //List
    async ListComplaintStageFlow(req, res, next)
    {
        try {
            var PaginationInfo = req.body.paginationinfo

            const requiredPage = {pageno : PaginationInfo.pageno, skip : (PaginationInfo.pageno - 1) * PaginationInfo.pagelimit, pagelimit : PaginationInfo.pagelimit}
            var pipeline = []
            var sort = (Object.keys(PaginationInfo.sort).length !== 0 ? PaginationInfo.sort : {'_id' : -1})
            let projection = PaginationInfo.projection ? PaginationInfo.projection : {}
            let fieldorder = PaginationInfo.isfieldorder ? PaginationInfo.isfieldorder : 0

            pipeline = IISMethods.GetPipelineForFilter(PaginationInfo.filter)

            const searchtext = req.body.searchtext || ""
            if (searchtext !== "") {
                pipeline.push(...IISMethods.GetGlobalSearchFilter(new _ComplaintStageFlow(), searchtext))
            }
            
            const resp = await MainDB.getmenual(TableName, new _ComplaintStageFlow(), pipeline, requiredPage, sort, fieldorder,"",projection)

            var ResponseBody = {}
            ResponseBody.pagename = PageName
            ResponseBody.formname = FormName
			ResponseBody.fltpagecollection = FltPageCollection
            ResponseBody.status = 200
            ResponseBody.message = Config.getResponsestatuscode()['200']
            ResponseBody.data = resp.ResultData
            ResponseBody.currentpage = resp.currentpage
            ResponseBody.nextpage = resp.nextpage
            ResponseBody.totaldocs = resp.totaldocs
            ResponseBody.fieldorder = resp.fieldorderdata   
            ResponseBody.formfieldorderdata = resp.formfieldorderdata      

            req.ResponseBody = ResponseBody
            next() 
        }
        catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err}
            next()
        }
    }

    //Insert
    async InsertComplaintStageFlow(req, res, next)
    {
        try {
                                   
            const resp = await MainDB.executedata('i', new _ComplaintStageFlow(),TableName, req.body)

            var ResponseBody = {}
            ResponseBody.status = resp.status
            ResponseBody.message = resp.message
           
            req.ResponseBody = ResponseBody
            next() 
        }
        catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err}
            next()
        }
    }

    //Insert Multiple (COPY)
    async InsertMultipleComplaintStageFlow(req, res, next)
    {
        try {
            const ObjectId = IISMethods.getobjectid()

            //prepare data
            var data = []
            var toids = []
                                   
            const pipeline = [{$match:{'complaintcategoryid':new ObjectId(req.body.fromid)}}]
            const fetchResp = await MainDB.getmenual(TableName, new _ComplaintStageFlow(),  pipeline)

            var resp = {}

            if(fetchResp.ResultData.length != 0){
                req.body.copyto.forEach( copytoobj => {
                    if(copytoobj.complaintcategoryid != req.body.fromid){

                        toids.push(new ObjectId(copytoobj.complaintcategoryid))
                        let newdata = fetchResp.ResultData[0]
                        delete newdata._id
                        data.push({
                            ...newdata,
                            complaintcategoryid : copytoobj.complaintcategoryid,
                            supportcategory : copytoobj.supportcategory,
                            recordinfo:req.body.recordinfo
                        })

                    }
                })

                // delete data
                const delpipeline = {'complaintcategoryid':{$in:toids}}
                resp = await MainDB.DeleteMany(TableName,new _ComplaintStageFlow(),delpipeline)

                if(resp.status == 200){
                    resp = await MainDB.InsertMany(TableName,new _ComplaintStageFlow(),data)
                }
            }else{
                resp.status = 404
                resp.message = "Data not Exists from where you are coping data"
            }


            var ResponseBody = {}
            ResponseBody.status = resp.status
            ResponseBody.message = resp.message
           
            req.ResponseBody = ResponseBody
            next() 
        }
        catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err}
            next()
        }
    }

    //Update
    async UpdateComplaintStageFlow(req, res, next){
        try{

            const ObjectId = IISMethods.getobjectid()

            const pipeline = [{$match : {'_id' :new ObjectId(req.body._id)}}]
            const  record = await MainDB.getmenual(TableName, new _ComplaintStageFlow(), pipeline)
            
            // record info Update data set 
            var RecordInfo = record.ResultData[0].recordinfo
            RecordInfo.updateuid = req.headers.uid
            RecordInfo.updateby = req.headers.personname
            RecordInfo.updatedate = IISMethods.getdatetimeisostr()
            req.body.recordinfo = RecordInfo
        
            const resp = await MainDB.executedata('u', new _ComplaintStageFlow(),TableName, req.body)
            
            var ResponseBody = {}
            ResponseBody.status = resp.status
            ResponseBody.data = resp.data
            ResponseBody.message = resp.message

            req.ResponseBody = ResponseBody
            next() 
        }
        catch(err){
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err}
            next()
        }
    }

    
    //Delete
    async DeleteComplaintStageFlow(req, res, next){
        try{
            const resp = await MainDB.executedata('d', new _ComplaintStageFlow(),TableName,req.body) 
            
            var ResponseBody = {}
            ResponseBody.status = resp.status
            ResponseBody.message = resp.message

            req.ResponseBody = ResponseBody
            next() 
        }
        catch(err){
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err}
            next()
        }
    }

    async StageFlowTicketStatus(req, res, next){
        try{
            const ObjectId = IISMethods.getobjectid()

            const Pipeline =[{$match : {'complaintcategoryid' : new ObjectId(req.body.complaintcategoryid) }}]
            const resp = await MainDB.getmenual(TableName, new _ComplaintStageFlow(), Pipeline)

            const StageFlow = resp.ResultData[0].Complaintstageflow
            let statusIds = []
            let data = []

            //status with review required 
            StageFlow.forEach(function (flow) {
                if(flow.stageid){
                    statusIds.push(new ObjectId(flow.stageid))
                }
            })

        
            const ticketpipeline = [{$match : {'complaintcategoryid' :new ObjectId(req.body.complaintcategoryid) , 'statusid' : {$in:statusIds}}}]
            const ticketresp = await MainDB.getmenual('tblcomplaint', new _Complaint(), ticketpipeline)

            statusIds.forEach(function(ele){
                let tickets = ticketresp.ResultData.filter(o=> o.statusid.toString() == ele.toString() )
                data.push({
                    statusid : ele,
                    count : tickets.length
                })
            })

            var ResponseBody = {}
            ResponseBody.status = 200
            ResponseBody.message = Config.getResponsestatuscode()['200']
            ResponseBody.data = data
            
            req.ResponseBody = ResponseBody
            next() 
        }
        catch(err){
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err}
            next()
        }
    }
    // End Support Ticket Stage Flow
}