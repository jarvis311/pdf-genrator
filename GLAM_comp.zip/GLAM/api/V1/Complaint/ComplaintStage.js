import {IISMethods, Config, MainDB} from '../../../config/Init.js'
import _ComplaintStage from '../../../model/Complaint/ComplaintStage.js'
import _Complaint from '../../../model/Complaint/Complaint.js'
import _ComplaintStageFlow from '../../../model/Complaint/ComplaintStageFlow.js'

const TableName = "tblcomplaintstage"
const PageName = "complaintstage"
const FormName = "complaintstage"
const FltPageCollection = "complaintstage"

export default class ComplaintStage{

    // START complaint Stage

    //List
    async ListComplaintStage(req, res, next)
    {
        try {

            var PaginationInfo = req.body.paginationinfo

            const requiredPage = {pageno : PaginationInfo.pageno, skip : (PaginationInfo.pageno - 1) * PaginationInfo.pagelimit, pagelimit : PaginationInfo.pagelimit}
            var pipeline = []
            var sort = (Object.keys(PaginationInfo.sort).length !== 0 ? PaginationInfo.sort : {'_id' : -1})
            let projection = PaginationInfo.projection ? PaginationInfo.projection : {}
            let fieldorder = PaginationInfo.isfieldorder ? PaginationInfo.isfieldorder : 0

            pipeline = IISMethods.GetPipelineForFilter(PaginationInfo.filter)

            const searchtext = req.body.searchtext || ""
            if (searchtext !== "") {
                pipeline.push(...IISMethods.GetGlobalSearchFilter(new _ComplaintStage(), searchtext))
            }
            
            const resp = await MainDB.getmenual(TableName, new _ComplaintStage(), pipeline, requiredPage, sort, fieldorder,"",projection)

            var ResponseBody = {}
                        
            ResponseBody.pagename = PageName
            ResponseBody.formname = FormName
			ResponseBody.fltpagecollection = FltPageCollection
            ResponseBody.status = 200
            ResponseBody.message = Config.getResponsestatuscode()['200']
            ResponseBody.data = resp.ResultData
            ResponseBody.currentpage = resp.currentpage
            ResponseBody.nextpage = resp.nextpage
            ResponseBody.totaldocs = resp.totaldocs
            ResponseBody.fieldorder = resp.fieldorderdata   
            ResponseBody.formfieldorderdata = resp.formfieldorderdata      

            req.ResponseBody = ResponseBody
            next() 
        }
        catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err}
            next()
        }
    }


    //Insert
    async InsertComplaintStage(req, res, next)
    {
        try {
            let ResponseBody = {}
            
            const stagepipeline = [{$sort : {_id : 1}}]
            let stagerecord = await MainDB.getmenual(TableName, new _ComplaintStage(), stagepipeline)                
            
            let completefind
            if (req.body.iscomplete == 1) {
                completefind = stagerecord.ResultData.find((o) => o.iscomplete == 1)
            }
            
            if (!completefind) {
                let uniquefind = stagerecord.ResultData.find((o) => o.stage.toLowerCase() == req.body.stage.toLowerCase())

                if (!uniquefind) {
                    const resp = await MainDB.executedata('i', new _ComplaintStage(),TableName, req.body)
        
                    ResponseBody.status = resp.status
                    ResponseBody.message = resp.message                    
                }else{
                    ResponseBody.status = 400
                    ResponseBody.message = "Stage already exist"
                }
            }else{
                ResponseBody.status = 400
                ResponseBody.message = Config.errmsg['ticketstageuse']                
            }
           
            req.ResponseBody = ResponseBody
            next() 
        }
        catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err}
            next()
        }
    }


    //Update
    async UpdateComplaintStage(req, res, next){
        try{

            const ObjectId = IISMethods.getobjectid()
            var ResponseBody = {}

             
            const stagepipeline = [{$sort : {_id : 1}}]
            let stagerecord = await MainDB.getmenual(TableName, new _ComplaintStage(), stagepipeline)   
                        
            let completefind
            if (req.body.iscomplete == 1) {
                completefind = stagerecord.ResultData.find((o) => o.iscomplete == 1)
            }
            
            if (!completefind) {
                let uniquefind = stagerecord.ResultData.find((o) => o.stage.toLowerCase() == req.body.stage.toLowerCase() && o._id.toString() != req.body._id)

                if (!uniquefind) {
                    const pipeline = [{$match : {'_id' :new ObjectId(req.body._id)}}]
                    const  record = await MainDB.getmenual(TableName, new _ComplaintStage(), pipeline)
                    
                    // record info Update data set 
                    var RecordInfo = record.ResultData[0].recordinfo
                    RecordInfo.updateuid = req.headers.uid
                    RecordInfo.updateby = req.headers.personname
                    RecordInfo.updatedate = IISMethods.getdatetimeisostr()
                    req.body.recordinfo = RecordInfo
                
                    const resp = await MainDB.executedata('u', new _ComplaintStage(),TableName, req.body)

                    if (resp.status === 200) {
                        // Update Dependency
                        const updatePipeline = [
                            { complainttypeid: req.body._id },
                            { $set: { complainttype: req.body.complainttype, } }
                        ]
                        const updateModelObj = {
                            tblcomplaint: new _Complaint()
                        }

                        const tempArray = []
                        for (const key in updateModelObj) {
                            tempArray.push(MainDB.UpdateMany(key, updateModelObj[key], updatePipeline))
                        }
                        await Promise.all(tempArray)
                    }

                    ResponseBody.status = resp.status
                    ResponseBody.data = resp.data
                    ResponseBody.message = resp.message
                }else{
                    ResponseBody.status = 400
                    ResponseBody.message = "Stage already exist"
                }
            }else{
                ResponseBody.status = 400
                ResponseBody.message = Config.errmsg['ticketstageuse']                
            }

            req.ResponseBody = ResponseBody
            next() 
        }
        catch(err){
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err}
            next()
        }
    }

    
    //Delete
    async DeleteComplaintStage(req, res, next){
        try{
            const ComplaintStageFlowmodel = await MainDB.createmodel('tblcomplaintstageflow',new _ComplaintStageFlow())
            const ComplaintModel = await MainDB.createmodel('tblcomplaint',new _Complaint())

            var dependancy = [
                [ComplaintStageFlowmodel['objModel'],{'Complaintstageflow.stageid' : req.body._id}],
                [ComplaintModel['objModel'],{'statusid' : req.body._id}],
            ]  
            const resp = await MainDB.executedata('d', new _ComplaintStage(),TableName,req.body, true , dependancy) 
            
            var ResponseBody = {}
            ResponseBody.status = resp.status
            ResponseBody.message = resp.message

            req.ResponseBody = ResponseBody
            next() 
        }
        catch(err){
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err}
            next()
        }
    }

    // End complaintstage Master
}