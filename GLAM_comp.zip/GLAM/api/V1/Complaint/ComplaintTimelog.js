import { IISMethods, Config, MainDB } from '../../../config/Init.js'
import { sendResponse } from '../../../config/apiconfig.js'

import _TimeLog from '../../../model/TimeLog.js'
import _complaint from '../../../model/Complaint/Complaint.js'
import _complaintFlow from '../../../model/Complaint/ComplaintFlow.js'
import _complaintCategory from '../../../model/Complaint/ComplaintCategory.js'

const TableName = "tbltimelog"

export default class complaintTimelog {

    // End Support Ticket TimeLog Master

    //List
    async ListcomplaintTimelog(req, res, next) {
        try {

            var PaginationInfo = req.body.paginationinfo

            const requiredPage = { pageno: PaginationInfo.pageno, skip: (PaginationInfo.pageno - 1) * PaginationInfo.pagelimit, pagelimit: PaginationInfo.pagelimit }
            var pipeline = []
            var sort = (Object.keys(PaginationInfo.sort).length !== 0 ? PaginationInfo.sort : { '_id': -1 })
            let projection = PaginationInfo.projection ? PaginationInfo.projection : {}

            pipeline = IISMethods.GetPipelineForFilter(PaginationInfo.filter)
            const searchtext = req.body.searchtext || ""
            if (searchtext !== "") {
                pipeline.push(...IISMethods.GetGlobalSearchFilter(new _TimeLog(), searchtext))
            }

            pipeline.push({ $match: { 'type': 2 } })
            const resp = await MainDB.getmenual(TableName, new _TimeLog(), pipeline, requiredPage, sort, true, projection)

            var ResponseBody = {}
            ResponseBody.pagename = "Complaint TimeLog"
            ResponseBody.status = 200
            ResponseBody.message = Config.getResponsestatuscode()['200']
            ResponseBody.totaldocs = resp.totaldocs
            ResponseBody.data = resp.ResultData
            ResponseBody.currentpage = resp.currentpage
            ResponseBody.nextpage = resp.nextpage

            req.ResponseBody = ResponseBody
            next()
        }
        catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

    //Insert
    async InsertcomplaintTimelog(req, res, next) {
        try {
            var ResponseBody = {}
            let ObjectId = IISMethods.getobjectid()
            var manualAddRequest = req.body.manual == 1 ? true : false
            let ID = new ObjectId()

            const pipeline = [{ $match: { 'personid': new ObjectId(req.body.personid) } }, { $match: { running: true } }]
            const record = await MainDB.getmenual(TableName, new _TimeLog(), pipeline)

            if (record.ResultData.length === 0 || req.body.manual == 1) {

                const TimeLogPipeline = [{ $match: { $or: [{ 'complaintid': new ObjectId(req.body.complaintid) }, { 'running': true, 'personid': new ObjectId(req.body.personid) }] } }]
                const TimeLogResp = await MainDB.getmenual('tbltimelog', new _TimeLog(), TimeLogPipeline)

                 //ADDING TIMELOG MANUALLY
                 if(manualAddRequest){

                    let isadmin = await MainDB.IsAdmin(req.headers.uid)
                    // let allTimelog = TimeLogResp.ResultData.filter((o) => o.taskid && o.taskid.toString() == req.body.taskid)
                    let manualtimevalid = true

                    const alltimelogpipeline = [{$match : {'personid':new ObjectId(req.body.personid)}},{$project : {"timehistory" : 1}}] 
                    const alltimelogresp = await MainDB.getmenual('tbltimelog',new _TimeLog(), alltimelogpipeline)

                    let filterdata = alltimelogresp.ResultData 
                                            
                    // manual timelog over lap validation
                    for (const iterator of filterdata) { 
        
                        let timehistoryArr = IISMethods.createTimeLogData(iterator ,true)
                        
                        for (const iterator of timehistoryArr) {
                                
                            let valid = IISMethods.isOverlapDate(iterator[0].time,  iterator[1].time,  req.body.time[0],  req.body.time[1])
                            if (valid) {
                                manualtimevalid = false
                                break;
                            }                            
                        }

                        if(manualtimevalid == false){
                            break;
                        }         
                    }

                    if (manualtimevalid) {

                            const timelogdata = TimeLogResp.ResultData.find((o) => o.taskid && o.taskid.toString() == req.body.taskid && req.body.personid == o.personid.toString())

                            let recordHistory = {
                                time: new Date().toISOString(),
                                menualid : ID,
                                action : 1,
                                menualpersonid : req.headers.uid,
                                menualperson : req.headers.personname,
                                menualreasonid : req.body.menualreasonid,
                                menualreason : req.body.menualreason,
                            }

                            var addResp     

                            if (timelogdata) {

                                req.body._id = timelogdata._id
                                req.body.timehistory = timelogdata.timehistory
                                req.body.endtime = req.body.time[1]
                                req.body.starttime = timelogdata.starttime 
                                req.body.type = 2

                                if (timelogdata.menualtimeloghistory == undefined || timelogdata.menualtimeloghistory.length == 0) {
                                    timelogdata.menualtimeloghistory = []                            
                                }

                                if (isadmin) {
                                    req.body.timehistory.push(
                                        {
                                            time: req.body.time[0],
                                            menualid : ID,
                                            menualreasonid: req.body.menualreasonid,
                                            menualreason : req.body.menualreason,
                                            deleted : 0,
                                            type: 2,
                                            status : 1,
                                            requestedbyid : req.headers.uid,
                                            requestedby : req.headers.personname,
                                        },
                                        {
                                            time: req.body.time[1],
                                            menualid : ID,
                                            menualreasonid: req.body.menualreasonid,
                                            menualreason : req.body.menualreason,
                                            deleted : 0,
                                            type: 2,
                                            status : 1,
                                            requestedbyid : req.headers.uid,
                                            requestedby : req.headers.personname,
                                        })  
                                        
                                    let duration = new Date(req.body.time[1]) - new Date(req.body.time[0])
                                    req.body.duration = timelogdata.duration + duration 

                                }else{

                                    req.body.timehistory.push(
                                        {
                                            time: req.body.time[0],
                                            menualid : ID,
                                            menualreasonid : req.body.menualreasonid,
                                            menualreason : req.body.menualreason,
                                            deleted : 0,
                                            type: 2,
                                            status : 0,
                                            requestedbyid : req.headers.uid,
                                            requestedby : req.headers.personname,
                                        },
                                        {
                                            time: req.body.time[1],
                                            menualid : ID,
                                            menualreasonid : req.body.menualreasonid,
                                            menualreason : req.body.menualreason,
                                            deleted : 0,
                                            type: 2,
                                            status : 0,
                                            requestedbyid : req.headers.uid,
                                            requestedby : req.headers.personname,
                                        }
                                    )

                                    recordHistory.action = 0

                                }

                                timelogdata.menualtimeloghistory.push(recordHistory)
                                req.body.menualtimeloghistory = timelogdata.menualtimeloghistory
                                addResp = await MainDB.executedata('u',  new _TimeLog() ,TableName, req.body)

                            }else{

                                req.body.timehistory = []
                                req.body.menualtimeloghistory = [] 

                                if (isadmin) {

                                    req.body.timehistory.push(
                                        {
                                            time: req.body.time[0],
                                            menualid : ID,
                                            menualtime : new Date().toISOString(),
                                            menualreasonid : req.body.menualreasonid,
                                            menualreason : req.body.menualreason,
                                            deleted : 0,
                                            type: 1,
                                            status : 1,
                                            requestedbyid : req.headers.uid,
                                            requestedby : req.headers.personname,
                                        },
                                        {
                                            time: req.body.time[1],
                                            menualid : ID,
                                            menualtime : new Date().toISOString(),
                                            menualreasonid : req.body.menualreasonid,
                                            menualreason : req.body.menualreason,
                                            deleted : 0,
                                            type: 2,
                                            status : 1,
                                            requestedbyid : req.headers.uid,
                                            requestedby : req.headers.personname,
                                        }
                                    )

                                    let duration = new Date(req.body.time[1]) - new Date(req.body.time[0])
                                    req.body.duration = duration
                                        
                                }else{

                                    req.body.timehistory.push(
                                        {
                                            time: req.body.time[0],
                                            menualid : ID, 
                                            menualtime : new Date().toISOString(),
                                            menualreasonid : req.body.menualreasonid,
                                            menualreason : req.body.menualreason,
                                            deleted : 0,
                                            type: 1,
                                            status : 0,
                                            requestedbyid : req.headers.uid,
                                            requestedby : req.headers.personname,
                                        },
                                        {
                                            time: req.body.time[1],
                                            menualid : ID,
                                            menualtime : new Date().toISOString(),
                                            menualreasonid : req.body.menualreasonid,
                                            menualreason : req.body.menualreason,
                                            deleted : 0,
                                            type: 2,
                                            status : 0,
                                            requestedbyid : req.headers.uid,
                                            requestedby : req.headers.personname,
                                        }
                                    ) 
                                    
                                    recordHistory.action = 0
                                    
                                }

                                req.body.menualtimeloghistory.push(recordHistory)
                                req.body.type = 2

                                addResp = await MainDB.executedata('i', new _TimeLog() ,TableName, req.body)

                            }

                            ResponseBody.status = addResp.status ? addResp.status : 400
                            ResponseBody.message = addResp.message
                            ResponseBody.data = addResp.data

                    }else{
                        ResponseBody.status = 400
                        ResponseBody.message = Config.errmsg['timeinuse']
                    }

                }else{
                    
                        const TimeLogPipeline = [{$match : {$or:[{'taskid' : new ObjectId(req.body.taskid)},{'running':true,}]}}]
                        const TimeLogResp = await MainDB.getmenual('tbltimelog',new _TimeLog(), TimeLogPipeline)
                        const taskTimelog = TimeLogResp.ResultData.find((o) => o.taskid && o.taskid.toString() == req.body.taskid && o.running == true)

                        //if running timer on this task or person's timer on other task
                        if (taskTimelog && req.headers.uid !== taskTimelog.personid.toString()) {

                            //not self timer, other person timer on same task
                            ResponseBody.status = 400
                            ResponseBody.message = taskTimelog.person+"'s"+ " timer already running"
                            ResponseBody.data = taskTimelog
                            
                        }else{
                            req.body.starttime = IISMethods.getdatetimeisostr()
                            req.body.midtime = IISMethods.getdatetimeisostr()
                            req.body.type = 2
                            req.body.timehistory = [
                                {
                                    time: req.body.starttime,
                                    menualid: "",
                                    type: 1,
                                    menualid: '',
                                    menualreason: '',
                                    deleted: 0
                                }
                            ]
            
                            const resp = await MainDB.executedata('i', new _TimeLog(), TableName, req.body)
            
                            const ticketpipeline = [{ $match: { '_id': new ObjectId(req.body.taskid) } }]
                            const ticketrecord = await MainDB.getmenual('tblcomplaint', new _complaint(), ticketpipeline)
            
                            const timelogpipeline = [{ $match: { 'taskid': new ObjectId(req.body.taskid) } }]
                            const timelogrecord = await MainDB.getmenual(TableName, new _TimeLog(), timelogpipeline)
            
                            if (resp.status == 200) {

                                //SET FLAG ACCEPTED ON TICKET
                                if(!ticketrecord.ResultData[0]?.acceptedtime){

                                    let updatedata = {_id: ticketrecord.ResultData[0]._id, accepted : 1,acceptedtime:IISMethods.getdatetimeisostr()}
                                    MainDB.executedata('u', new _complaint(), 'tblcomplaint', updatedata)

                                    let entryDate = ticketrecord.ResultData[0].recordinfo.entrydate
                                    let dif = new Date() - new Date(entryDate)
                                    let mindif = IISMethods.toFixedFloat(dif/60000) 
                    
                                    let flowpipeline = [{$match : {'complaintcategoryid' :new ObjectId(ticketrecord.ResultData[0].complaintcategoryid)}}]
                                    let flowresp = await MainDB.getmenual('tblcomplaintflow', new _complaintFlow(), flowpipeline)
                                        
                                    let acceptedPerson   
                                    let acceptedPersontime = 0  
                                    for (const i of flowresp.ResultData) {
                                        for (const o of i.supportticketflow) {
                                            let find = o.assignedpersons.find((assignedPerson) => assignedPerson.assignedpersonid.toString() === req.headers.uid)
                                            
                                            if(o.accepttime){
                                                acceptedPersontime = acceptedPersontime + o.accepttime
                                            }
                                            if(find){
                                                acceptedPerson= o
                                                break;
                                            }
                                        }
                                    }
                                }

                                let message = `Timer Started on Ticket : ${resp.data.taskseries}`
                                ResponseBody.message = message

                            }else{
                                ResponseBody.message = resp.message
                            }

                            ResponseBody.status = resp.status
                            ResponseBody.data = resp.data
                            ResponseBody.ticket = ticketrecord.ResultData[0]
                            ResponseBody.timelogs = timelogrecord.ResultData

                        }
                }

            } else {

                ResponseBody.status = 400
                ResponseBody.message = Config.errmsg['runningtimer']
                ResponseBody.model = true
                ResponseBody.data = record.ResultData && record.ResultData[0] ? record.ResultData[0] : {}
                ResponseBody.taskdata = {}

                if (record.ResultData[0]) {

                  if (record.ResultData[0].type == 2) {
                        const ticketpipeline = [{ $match: { '_id': new ObjectId(req.body.taskid.toString()) } }]
                        const ticketrecord = await MainDB.getmenual('tblcomplaint', new _complaint(), ticketpipeline)
                        ResponseBody.taskdata = ticketrecord.ResultData && ticketrecord.ResultData[0] ? ticketrecord.ResultData[0] : {}
                    } 
                }
            }

            req.ResponseBody = ResponseBody
            next()
        }
        catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

    //Update
    async UpdatecomplaintTimelog(req, res, next) {
        try {
            let DF = new _DataFunctions()

            var ResponseBody = {}
            const ObjectId = IISMethods.getobjectid()
            req.body.type = 2
            req.body.timer_billingtype = "Non Billable"
            req.body.projectid = Config.defaulttrainingprojectid
            req.body.moduleid = Config.defaulttrainingmoduleid
            let now = IISMethods.getdatetimeisostr()

            const pipeline = [{$match : {'_id' : new ObjectId(req.body._id)}}]
            const record = await MainDB.getmenual(TableName, new _TimeLog(), pipeline)

            if(record.ResultData[0].timerstate != req.body.timerstate){
        
                    let timelogvalid = false

                    if(req.body.running == true){

                        //CHECK IF SELF TIMER RUNNING
                        const runningpipeline = [{$match: { 'personid': new ObjectId(req.headers.uid)}}, {$match:{ running: true } }, { $match: { '_id': { $ne: new ObjectId(req.body._id) } } }]
                        const runningrecord = await MainDB.getmenual(TableName, new _TimeLog(), runningpipeline)

                        if (runningrecord.ResultData.length === 0) {

                            const TimeLogPipeline = [{$match : {$or:[{'taskid' : new ObjectId(req.body.taskid)},{'running':true}]}}]
                            const TimeLogResp = await MainDB.getmenual(TableName , new _TimeLog(), TimeLogPipeline)
                            const taskTimelog = TimeLogResp.ResultData.find((o) =>  o.taskid && o.taskid.toString() == req.body.taskid &&  o.running == true)

                            if (req.body.running == true && taskTimelog) {
                                ResponseBody.status = 400
                                ResponseBody.message = taskTimelog.person+"'s"+ " timer already running"
                                ResponseBody.data = taskTimelog
                                timelogvalid = false
                            } 
                            else if (req.body.running == false && req.body.timerstate == "stop") {

                                    // if self task timer is on
                                    let selftasktimelog = TimeLogResp.ResultData.find((o) => o.personid.toString() == req.headers.uid && o.taskid.toString() == req.body.taskid)
                                    if (selftasktimelog) {
                                        timelogvalid = true
                                    }else{
                                        // else
                                        ResponseBody.status = 400
                                        ResponseBody.message = "task timer not started yet"
                                        timelogvalid = false
                                    }                    
                                // }
                            } 
                            else{
                                timelogvalid = true
                            }
                            
                            
                        } else {
                            ResponseBody.status = 400
                            ResponseBody.message = Config.errmsg['runningtimer']
                            ResponseBody.data = runningrecord.ResultData && runningrecord.ResultData[0] ? runningrecord.ResultData[0] : {}
                            ResponseBody.model = true
                            ResponseBody.taskdata = {}

                            if (runningrecord.ResultData[0]) {
                             if (runningrecord.ResultData[0].type == 2) {

                                    const ticketpipeline = [{ $match: { '_id': new ObjectId(runningrecord.ResultData[0].taskid.toString()) } }]
                                    const ticketrecord = await MainDB.getmenual('tblcomplaint', new _complaint(), ticketpipeline)
                                    ResponseBody.taskdata = ticketrecord.ResultData && ticketrecord.ResultData[0] ? ticketrecord.ResultData[0] : {}

                                } 
                            }
                        }

                    }else{
                        //valid
                        timelogvalid = true
                    }


                    if (timelogvalid) {

                        const pipeline = [{ $match: { '_id': new ObjectId(req.body._id) } }]
                        const record = await MainDB.getmenual(TableName, new _TimeLog(), pipeline)

                        // record info Update data set 
                        var RecordInfo = record.ResultData[0].recordinfo
                        RecordInfo.updateuid = req.headers.uid
                        RecordInfo.updateby = req.headers.personname
                        RecordInfo.updatedate = IISMethods.getdatetimeisostr()

                        req.body.recordinfo = RecordInfo
                        req.body.timehistory = record.ResultData[0].timehistory

                        var currentDateTime = IISMethods.getdatetimeisostr()

                        if (req.body.timerstate == 'pause' || req.body.timerstate == 'stop') {
                            if (record.ResultData[0].running == true) {
                                req.body.duration = record.ResultData[0].duration + (new Date(currentDateTime) - new Date(req.body.midtime))
                            }
                        }

                        if (req.body.timerstate == 'play') {
                            req.body.midtime = currentDateTime
                        } else if (req.body.timerstate == 'pause') {
                            req.body.endtime = currentDateTime
                        } else if (req.body.timerstate == 'stop') {
                            req.body.endtime = currentDateTime
                        }

                        if (req.body.timehistory) {
                            let timeObj = {
                                time: req.body.timerstate.toLowerCase() == 'pause' || req.body.timerstate.toLowerCase() == 'stop' ? req.body.endtime : req.body.midtime,
                            }

                            if (req.body.timerstate.toLowerCase() == 'stop') {
                                timeObj.type = 3
                            } else {
                                let newtimehistory = req.body.timehistory

                                if (newtimehistory[newtimehistory.length - 1].type == 3) {
                                    timeObj.type = 1
                                } else {
                                    timeObj.type = 2
                                }

                            }

                            req.body.timehistory.push(timeObj)
                        }

                        const resp = await MainDB.executedata('u', new _TimeLog(), TableName, req.body)

                        if (resp.status == 200) {
                            const ticketpipeline = [{ $match: { '_id': new ObjectId(req.body.taskid) } }]
                            const ticketrecord = await MainDB.getmenual('tblcomplaint', new _complaint(), ticketpipeline)

                            const timelogpipeline = [{ $match: { 'taskid': new ObjectId(req.body.taskid) } }, { $match: { 'type': 2 } }]
                            const timelogrecord = await MainDB.getmenual(TableName, new _TimeLog(), timelogpipeline)

                            ResponseBody.ticket = ticketrecord.ResultData[0]
                            ResponseBody.timelogs = timelogrecord.ResultData

                        }

                        if (resp.status == 200) {
                            let message = ``
                            if(req.body.timerstate == 'pause'){
                                message = `Timer Paused on Ticket : ${resp.data.taskseries}`                            
                            }
                            if(req.body.timerstate == 'play'){
                                message = `Timer Started on Ticket : ${resp.data.taskseries}`
                            }
                            if (req.body.timerstate == 'stop') {
                                //ruchir 4-3-24
                                //Sending chat message of completion of support ticket on chat
                                    let Chat = new _Chat()
                                    const ticketpipeline = [{ $match: { '_id': new ObjectId(req.body.taskid.toString()) } }]
                                    const ticketrecord = await MainDB.getmenual('tblsupportticket', new _complaint(), ticketpipeline)

                                    let flowpipeline = [{ $match: { 'supportcategoryid': new ObjectId(ticketrecord.ResultData[0].supportcategoryid) } }]
                                    let flowresp = await MainDB.getmenual('tblcomplaintflow', new _complaintFlow(), flowpipeline)
                                    let firstflow = flowresp.ResultData[0].supportticketflow[0]


                                    let userconnectionpipeline = [{ $match: { 'frompersonid': new ObjectId(req.headers.uid), 'topersonid': ticketrecord.ResultData[0].ownerid } }]
                                    const userconnectionresp = await MainDB.getmenual("tbluserconnection", new _UserConnection(), userconnectionpipeline)
                                    let cid = ''
                                    if (userconnectionresp.ResultData[0] && userconnectionresp.ResultData[0].cid) {
                                        cid = userconnectionresp.ResultData[0].cid
                                    }
                                    let newreq = {
                                        body: {
                                            cid: cid,
                                            groupid: ticketrecord.ResultData[0].ownerid.toString(),
                                            isgroup: 0,
                                            message: "Your Support ticket" + ticketrecord.ResultData[0].subject + "has been resolved",
                                            type: 1,
                                            priority: ticketrecord.ResultData[0].priority,
                                            personid: req.headers.uid,
                                            topersonusername: ticketrecord.ResultData[0].owner,
                                            mentions: [],
                                            stars: [],
                                            files: [],
                                            reaction: [],
                                            repliedtoid: "",
                                            replytomessage: "",
                                            replytopriority: "",
                                            replytotype: "",
                                            replytorecordinfo: null,
                                            new: 0,
                                            recordinfo: {
                                                entryuid: req.headers.uid,
                                                entryby: req.headers.personname,
                                                entrydate: new Date().toISOString(),
                                                timestamp: IISMethods.GetTimestamp(),
                                                isactive: 1
                                            },
                                            functioncall: true
                                        },
                                        headers: req.headers
                                    }
                                    let demo = await Chat.InsertChat(newreq, {}, sendResponse)
        
                                message = `Timer Stopped on Ticket : ${resp.data.taskseries}`
                            }
                            ResponseBody.message = message                            
                        }else{
                            ResponseBody.message = resp.message
                        }
                        ResponseBody.status = resp.status
                        ResponseBody.data = resp.data
                    }                
                
            }else{

                ResponseBody.status = 401
                ResponseBody.message = "timer already on same state"

            }

            req.ResponseBody = ResponseBody
            next()
        }
        catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

    //Delete
    async DeletecomplaintTimelog(req, res, next) {
        try {

            const resp = await MainDB.executedata('d', new _TimeLog(), TableName, req.body)

            var ResponseBody = {}
            ResponseBody.status = resp.status
            ResponseBody.message = resp.message

            req.ResponseBody = ResponseBody
            next()
        }
        catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }


    async UpdateMenualcomplaintTimeLog(req, res, next) {
        try {

            const ObjectId = IISMethods.getobjectid()
            var ResponseBody = {}

            let menualid = req.body.menualid
            let time = req.body.time

            const pipeline = [{ $match: { '_id': new ObjectId(req.body._id) } }]
            const record = await MainDB.getmenual(TableName, new _TimeLog(), pipeline)

            if (record.ResultData[0]) {
                // project data
                let complaintcategorypipeline = [{ $sort: { _id: 1 } }, { $project: { iscompleted: 1 } }, { $match: { '_id': new ObjectId(record.ResultData[0].projectid) } }]
                const supportcategory = await MainDB.getmenual('tblcomplaintcategory', new _complaintCategory(), complaintcategorypipeline)

                if (supportcategory.ResultData[0] && supportcategory.ResultData[0].iscompleted != 1) {

                    let iterator = record.ResultData[0].timehistory
                    let manualtimevalid = true

                    // manual timelog over lap validation
                    const filteredLog = iterator.timehistory ? iterator.timehistory.filter(o => !o.menualid && o.deleted != 1) : []

                    let newArr = []
                    filteredLog.map((log, index) => {
                        if (log.type == 3) {
                            log.iscomplete = true

                            let count = 0
                            let tempIndex = index
                            do {
                                --tempIndex
                                if (filteredLog[tempIndex]?.type == 2) {
                                    ++count
                                }
                            }
                            while (filteredLog[tempIndex]?.type != 1)

                            // if (lenght of objects of type 2) previous type 3 object is in odd add tempobj and consider as complete log
                            if (count > 0 && count % 2 == 1) {
                            } else {
                                newArr.push(log)
                            }
                        }
                        else {
                            newArr.push(log)
                        }
                    })

                    let timehistoryArr = []
                    newArr.map((object, index) => {
                        if (index % 2 == 0) {
                            let temp
                            if (newArr[index + 1]) {
                                temp = [newArr[index], newArr[index + 1]]
                            }

                            if (temp) {
                                timehistoryArr.push(temp)
                            }
                        }
                    })

                    const manualLogs = iterator.timehistory ? iterator.timehistory.filter(o => o.menualid && o.menualid !== menualid && o.deleted != 1 && o.status == 1) : []
                    // newArr = newArr.concat(manualLogs)
                    manualLogs.map((object, index) => {
                        if (index % 2 == 0) {
                            let temp
                            if (manualLogs[index + 1]) {
                                temp = [manualLogs[index], manualLogs[index + 1]]
                            }
                            else {
                                temp = [manualLogs[index]]
                            }
                            if (temp) {
                                timehistoryArr.push(temp)
                            }
                        }
                    })

                    for (const iterator of timehistoryArr) {
                        let valid = IISMethods.isOverlapDate(iterator[0].time, iterator[1].time, req.body.time[0], req.body.time[1])
                        if (valid) {
                            manualtimevalid = false
                        }
                    }

                    if (manualtimevalid) {
                        record.ResultData[0].duration = req.body.duration

                        var RecordInfo = record.ResultData[0].recordinfo
                        RecordInfo.updateuid = req.headers.uid
                        RecordInfo.updateby = req.headers.personname
                        RecordInfo.updatedate = IISMethods.getdatetimeisostr()
                        req.body.recordinfo = RecordInfo

                        var a = []

                        for (const hobj of record.ResultData[0].timehistory) {
                            if (menualid == hobj.menualid) {
                                a.push(hobj)
                            }
                        }

                        a[0].time = time[0]
                        a[1].time = time[1]
                        var b = []

                        if (record.ResultData[0].menualtimeloghistory == undefined || record.ResultData[0].menualtimeloghistory.length == 0) {
                            record.ResultData[0].menualtimeloghistory = []
                        }

                        record.ResultData[0].menualtimeloghistory.push(
                            {
                                time: new Date().toISOString(),
                                menualid: menualid,
                                action: 2,
                                menualpersonid: req.headers.uid,
                                menualperson: req.headers.personname,
                                menualreasonid: req.body.menualreasonid,
                                menualreason: req.body.menualreason,
                            }
                        )

                        record.ResultData[0].timehistory = record.ResultData[0].timehistory.map((item) => {
                            if (item.menulid == menualid) {
                                if (!b.length) {
                                    b.push(" ")
                                    return a[0]
                                } else {
                                    return a[1]
                                }
                            } else {
                                return item
                            }
                        })


                        var resp = await MainDB.executedata('u', new _TimeLog(), TableName, record.ResultData[0])
                        ResponseBody.status = resp.status
                        ResponseBody.message = resp.message
                        ResponseBody.data = resp.data
                    } else {
                        ResponseBody.status = 400
                        ResponseBody.message = Config.errmsg['timeinuse']
                    }
                } else {
                    ResponseBody.status = 400
                    ResponseBody.message = Config.errmsg['supportcategorynotfound']
                }
            } else {
                ResponseBody.status = 401
                ResponseBody.message = "Timelog not found"
            }

            req.ResponseBody = ResponseBody
            next()
        }
        catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

    //Delete MenualTimeLog
    async DeleteMenualcomplaintTimeLog(req, res , next){
        try{

            const ObjectId = IISMethods.getObjectId()

            let menualid = req.body.menualid
            const pipeline = [{$match : {'_id' : new ObjectId(req.body._id)}}]
            const record = await MainDB.getmenual(TableName, new _TimeLog(), pipeline)

            var RecordInfo = record.ResultData[0].recordinfo
            RecordInfo.updateuid = req.headers.uid
            RecordInfo.updateby = req.headers.personname
            RecordInfo.updatedate = IISMethods.getdatetimeisostr()
            req.body.recordinfo = RecordInfo

            var a = []
            let deleteManualLog = []

            for (const hobj of record.ResultData[0].timehistory) {
                if(menualid !== hobj.menualid){
                    a.push(hobj)
                }
                else {
                    deleteManualLog.push(hobj)

                    hobj.deleted = 1
                    a.push(hobj)

                }
            }

            // record.ResultData[0].duration = record.ResultData[0].duration - (new Date(deleteManualLog[1].time).getTime() - new Date(deleteManualLog[0].time).getTime()) // juhil

            record.ResultData[0].timehistory = a

            //??
            let length = record.ResultData[0].timehistory.length
            if (record.ResultData[0].timehistory && record.ResultData[0].timehistory.length >= 2) {
                record.ResultData[0].timehistory[0].type = 1
                record.ResultData[0].timehistory[length - 1].type = 2                
            }

            if (record.ResultData[0].menualtimeloghistory == undefined || record.ResultData[0].menualtimeloghistory.length == 0) {
                record.ResultData[0].menualtimeloghistory = []                            
            }

            record.ResultData[0].menualtimeloghistory.push(
                {
                    time: new Date().toISOString(),
                    menualid : menualid,
                    action : 3,
                    menualpersonid : req.headers.uid,
                    menualperson : req.headers.personname,
                    menualreasonid : req.body.menualreasonid,
                    menualreason : req.body.menualreason,
                }
            )

            var resp = await MainDB.executedata('u',  new _TimeLog(), TableName, record.ResultData[0])
            
            var ResponseBody = {}
            ResponseBody.status = resp.status
            ResponseBody.message = resp.message
            ResponseBody.data = resp.data
            req.ResponseBody = ResponseBody
            next()
        }
        catch(err){
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err}
            next()
        }
    }

    async ApproveMenualcomplaintTimeLog(req, res, next){
        try{

            // let DF = new _DataFunctions()
            const ObjectId = IISMethods.getObjectId()
            var ResponseBody = {}

            let menualid = req.body.menualid
            let status = req.body.status
            let updatedid = req.body.updateid 

            const requestpipeline = [{$match : {'_id' : new ObjectId(updatedid)}}]
            const requestrecord = await MainDB.getmenual('tblsupporttickettimelogrequests', new _complaintTimelogRequest(), requestpipeline)
            let requestdata = requestrecord.ResultData[0] 

            if (updatedid && requestdata) {
                requestdata.status = status
                await MainDB.executedata('u',  new _complaintTimelogRequest(), 'tblsupporttickettimelogrequests', requestdata)                
            }

            const pipeline = [{$match : {'_id' : new ObjectId(req.body._id)}}]
            const record = await MainDB.getmenual(TableName, new _TimeLog(), pipeline)

            let deleterequest = req.body.deleterequest
            let editrequest = req.body.editrequest

            var RecordInfo = record.ResultData[0].recordinfo
            RecordInfo.updateuid = req.headers.uid
            RecordInfo.updateby = req.headers.personname
            RecordInfo.updatedate = IISMethods.getdatetimeisostr()
            req.body.recordinfo = RecordInfo
            
            let menualtimes = record.ResultData[0].timehistory.filter((o) => o.menualid == menualid)
            menualtimes.sort(function(a, b) {
                return Date.parse(b.time) - Date.parse(a.time)
            })

            let duration = 0
            let manualtime = 0
            if (requestdata) {
                duration = new Date(requestdata.newendtime) - new Date(requestdata.newstarttime)
                manualtime = new Date(menualtimes[0].time) - new Date(menualtimes[1].time)
            }else{
                duration = new Date(menualtimes[0].time) - new Date(menualtimes[1].time)
            }

            if (status == 1) {
                if (deleterequest) {
                    record.ResultData[0].duration = record.ResultData[0].duration - duration                    
                }else{
                    record.ResultData[0].duration = record.ResultData[0].duration - manualtime
                    record.ResultData[0].duration = record.ResultData[0].duration + duration
                }
                
                if (record.ResultData[0].menualtimeloghistory == undefined || record.ResultData[0].menualtimeloghistory.length == 0) {
                    record.ResultData[0].menualtimeloghistory = []                            
                }
                record.ResultData[0].menualtimeloghistory.push(
                    {
                        time: new Date().toISOString(),
                        menualid : req.body.menualid,
                        action : deleterequest ? 3 : editrequest ? 2 : 1,
                        menualpersonid : req.headers.uid,
                        menualperson : req.headers.personname,
                        menualreasonid : req.body.menualreasonid,
                        menualreason : req.body.menualreason,
                        rejectreason : req.body.rejectreason,
                    }
                )
            }

            let clonedata1 =  {
                time: "",
                type: 1,
                menualid: menualid,
                menualreasonid: req.body.menualreasonid,
                menualreason: req.body.menualreason,
                deleted: deleterequest,
                edited: 0,
                deleterequest: deleterequest,
                editrequest : editrequest,
                editeddetails: [],
                status: 2,
                approvaldate: new Date().toISOString(),
                approvingpersonid: req.headers.uid,
                approvingperson: req.headers.personname,
                rejectreason: req.body.rejectreason,
                updateid: updatedid,
                updated : 1
            }
            let clonedata2 =  {
                time: "",
                type: 1,
                menualid: menualid,
                menualreasonid: req.body.menualreasonid,
                menualreason: req.body.menualreason,
                deleted: 0,
                edited: 0,
                deleterequest: deleterequest,
                editrequest : editrequest,
                editeddetails: [],
                status: 2,
                approvaldate: new Date().toISOString(),
                approvingpersonid: req.headers.uid,
                approvingperson: req.headers.personname,
                rejectreason: req.body.rejectreason,
                updateid: updatedid,
                updated: 1,
            }

            let index = 1
            for (const hobj of record.ResultData[0].timehistory) {
                if(menualid == hobj.menualid){
                    // if approve
                    if (status == 1) {
                        if (requestdata) {
                            if (hobj._id.toString() == requestdata.firsthistoryid) {
                                hobj.time = requestdata.newstarttime                            
                            }
                            if (hobj._id.toString() == requestdata.secondhistoryid) {
                                hobj.time = requestdata.newendtime                            
                            }
                        }
                        
                        if (deleterequest) {
                            hobj.deleted = 1
                            hobj.deleterequest = deleterequest
                        }
                        if (editrequest) {
                            hobj.edit = 1
                            hobj.editrequest = editrequest
                        }
                        hobj.approvaldate = new Date().toISOString()
                        hobj.approvingpersonid = req.headers.uid
                        hobj.approvingperson = req.headers.personname
                        hobj.rejectreason = ""
                        hobj.status = status                        
                    }
                    // if reject
                    else if(status == 2){

                        if (deleterequest) {
                            hobj.deleted = 0
                            hobj.deleterequest = 0
                            clonedata1.deleted = 1
                            clonedata1.deleterequest = deleterequest
                            clonedata2.deleted = 1
                            clonedata2.deleterequest = deleterequest
                        }
                        if (editrequest) {
                            hobj.edit = 0
                            hobj.editrequest = 0
                            clonedata1.edit = 1
                            clonedata1.editrequest = editrequest
                            clonedata2.edit = 1
                            clonedata2.editrequest = editrequest
                        }

                        // if timelog edit or delete
                        if(requestdata && requestdata.newstarttime && requestdata.newendtime){

                            clonedata1.menualreasonid = hobj.menualreasonid
                            clonedata1.menualreason = hobj.menualreason
                            clonedata2.menualreasonid = hobj.menualreasonid
                            clonedata2.menualreason = hobj.menualreason

                            hobj.menualid = ""
                            hobj.menualreasonid = ""
                            hobj.menualreason = ""
                            hobj.status = 0
                            hobj.rejectreason = ""
                            hobj.approvaldate = ""
                            hobj.approvingpersonid = ""
                            hobj.approvingperson = ""
                            hobj.updated = 0
                            hobj.updateid = ""
    
                            if (index == 1) {
                                clonedata1.time = requestdata.newstarttime
                                clonedata1.type = hobj.type
                            }else if (index == 2) {
                                clonedata2.time = requestdata.newendtime
                                clonedata2.type = hobj.type
                            }
                            // console.log({index});
                            // console.log({clonedata});
                            // clonehistory.push(clonedata)
                            // console.log(clonehistory);
                            index += 1
                        }
                        // manual timelog 
                        else{
                            hobj.approvaldate = new Date().toISOString()
                            hobj.approvingpersonid = req.headers.uid
                            hobj.approvingperson = req.headers.personname
                            hobj.rejectreason = req.body.rejectreason
                            hobj.status = status         
                        }

                    }
                }
            }

            if (status == 2 && requestdata && record.ResultData[0].timehistory) {
                record.ResultData[0].timehistory.push(clonedata1)
                record.ResultData[0].timehistory.push(clonedata2)
            }

            var resp = await MainDB.executedata('u',  new _TimeLog(), TableName, record.ResultData[0])

            //points

            ResponseBody.status = 200
            ResponseBody.message = resp.message
            ResponseBody.data = resp.data   

            req.ResponseBody = ResponseBody
            next()
        }
        catch(err){
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err}
            next()
        }
    }

    async ReviewcomplaintTimelogRequestv2(req, res, next){
        try {
            
            var PaginationInfo =  req.body.paginationinfo
            const ObjectId = IISMethods.getObjectId()

            var sort = (Object.keys(PaginationInfo.sort).length !== 0 ? PaginationInfo.sort : {'_id' : 1 } )

            let canmanage = req.userauth?.rights.canmanage
            
            let pipeline = [{$project : {'timehistory' : 1,'type':1, 'running' : 1, 'taskid' : 1, 'personid' :1, 'person' : 1,'projectid' : 1,'recordinfo' :1}}]

            if (PaginationInfo.filter.supportcategoryid) {
                pipeline.push({$match:{'projectid': new ObjectId(PaginationInfo.filter.supportcategoryid)}})
            }


            pipeline.push(
                {
                    '$unwind': {'path': '$timehistory'}
                }, 
                {
                  '$match': {
                    'type' : 2,
                    'timehistory.menualid': {
                      '$exists': true
                    }
                  }
                }, 
                {
                  '$match': {
                    'timehistory.menualid': {
                      '$ne': ''
                    }
                  }
                },
                {
                    '$group': {
                      '_id': '$_id', 
                      'taskseries': {'$first': '$taskseries'}, 
                      'recordinfo': {'$first': '$recordinfo'}, 
                      'taskid': {'$first': '$taskid'}, 
                      'personid': {'$first': '$personid'}, 
                      'projectid': {'$first': '$projectid'}, 
                      'person': {'$first': '$person'}, 
                      'timehistory': {'$push': '$timehistory'}
                    }
                }
            )
            let timelog = new _TimeLog()

            const resp = await MainDB.getmenual(TableName, new _TimeLog(), pipeline, {} , {}, true ,{} , {pagename:'tblsupporttickettimelog',staticOrder:timelog.getcomplaintTimeFieldOrder()})


            let manualids = []
            let data = []

            let requiredSupportCategoryObjid = []
            let requiredSupportCategoryid = []
            let requiredTasksObjid = []
            let requiredTasksid = []
            let requiredReqObjid = []
            let requiredReqid = []

            //ALL TIMELOGS

            resp.ResultData.forEach(function(iterator){

                //TIME HISTORY
                if(iterator.timehistory){
                    iterator.timehistory.forEach(function(log){
                        //IF MENUAL
                        if (log.menualid != "" && log.menualid && !manualids.includes(log.menualid)) {
                            let menualtimes = iterator.timehistory ? iterator.timehistory.filter((o) => o.menualid == log.menualid) : []
                            if (menualtimes.length && menualtimes[0] && menualtimes[1] && menualtimes[0].status != undefined && menualtimes[1].status != undefined) {
                                
                                if(!requiredSupportCategoryid.includes(iterator.projectid.toString())){
                                    requiredSupportCategoryid.push(iterator.projectid.toString())
                                    requiredSupportCategoryObjid.push(new ObjectId(iterator.projectid.toString()))
                                }
                                if(!requiredTasksid.includes(iterator.taskid.toString())){
                                    requiredTasksid.push(iterator.taskid.toString())
                                    requiredTasksObjid.push(new ObjectId(iterator.taskid.toString()))
                                }
                                if(menualtimes[0].updateid){
                                    if(!requiredReqid.includes(menualtimes[0].updateid)){
                                        requiredReqid.push(menualtimes[0].updateid)
                                        requiredReqObjid.push(new ObjectId(menualtimes[0].updateid))
                                    }
                                }
                            }
                        }
                    })
                }
            })

            console.log("requiredTasksid",requiredTasksid);
            

            let supportticketpipeline = [{$match:{'_id':{$in:requiredTasksObjid}}}] //{$project : {'title' : 1, "taskid": 1,'moduleid' :1, 'module' :1}}
            const supportticketdata = await MainDB.getmenual('tblsupportticket', new _complaint(), supportticketpipeline)

            let supportcategorypipeline = [{$match:{'_id':{$in:requiredSupportCategoryObjid}}},{$project : {'name' : 1}}]
            const supportcategorydata = await MainDB.getmenual('tblsupportcategorymaster', new _complaintCategory(), supportcategorypipeline)

            const requestpipeline = [{$match:{'_id':{$in:requiredReqObjid}}}]
            const requestrecord = await MainDB.getmenual('tblsupporttickettimelogrequests', new _complaintTimelogRequest(), requestpipeline)

            //ALL TIMELOGS
            for (const iterator of resp.ResultData) {

                //TIME HISTORY
                if(iterator.timehistory){

                    for (const log of iterator.timehistory) {

                        //IF MENUAL
                        if (log.menualid != "" && log.menualid && !manualids.includes(log.menualid)) {

                            let menualtimes = iterator.timehistory ? iterator.timehistory.filter((o) => o.menualid == log.menualid) : []

                            if (menualtimes.length && menualtimes[0] && menualtimes[1] && menualtimes[0].status != undefined && menualtimes[1].status != undefined) {
    
                                let requestfind = requestrecord.ResultData.find((o) => menualtimes[0].updateid && o._id.toString() == menualtimes[0].updateid)
                                let supportticketfind = supportticketdata.ResultData.find((o) => o._id.toString() == iterator.taskid.toString())
                                let supportcategoryfind = supportcategorydata.ResultData.find((o) => o._id.toString() == iterator.projectid.toString())
    
                                console.log("iterator.taskid.toString()",iterator.taskid.toString());
                                if(supportticketfind){
                                    console.log("supportticketfind",supportticketfind?._id.toString());
                                }
                                

                                menualtimes.sort(function(a, b) {
                                    return Date.parse(a.time) - Date.parse(b.time)
                                })

                                let duration = 0
                                if (requestfind) {
                                    menualtimes[0].time = requestfind.newstarttime
                                    menualtimes[1].time = requestfind.newendtime
                                    duration = new Date(requestfind.newendtime) - new Date(requestfind.newstarttime)
                                }else{
                                    duration = new Date(menualtimes[1].time) - new Date(menualtimes[0].time)
                                }
    
                                data.push({
                                    _id : menualtimes[0].updateid,
                                    personid : iterator.personid,
                                    person : iterator.person,
                                    duration : IISMethods.getMiliSecToHours(duration),
                                    manualtimes : menualtimes,
                                    timelog : iterator,
                                    task : supportticketfind,
                                    supportcategory : supportcategoryfind,
                                    status : menualtimes[0].status,
                                    deleterequest : requestfind ? requestfind.deleterequest : menualtimes[0].deleterequest ? menualtimes[0].deleterequest : 0,
                                    editrequest :requestfind ? requestfind.editrequest :  menualtimes[0].editrequest ? menualtimes[0].editrequest : 0,
                                    updated : menualtimes[0].updated ? menualtimes[0].updated : 0,
                                    updateid : menualtimes[0].updateid,
                                    recordinfo : {
                                        entryuid : menualtimes[0].requestedbyid ? menualtimes[0].requestedbyid : "",
                                        entryby : menualtimes[0].requestedby ? menualtimes[0].requestedby : "",
                                        entrydate : menualtimes[0].time ? menualtimes[0].time : ""
                                    }
                                })
                                manualids.push(log.menualid)
                            }
                        }
                    }
                }
            }

            // RIGHTS FOR EMPLOYEES
            let RA = {}
            let rightWiseData = []

            const personPipeline = [{$sort:{_id:-1}},{$match:{'iscustomer':{$ne:1}}}]
            const personResp = await MainDB.getmenual('tblpersonmaster', new _Person(), personPipeline)

            let isadmin = await MainDB.IsAdmin(req.headers.uid)
            for(const o of data){
                
                //IF NOT ADMIN, NOT PM, MY APPROVER DATA
                if(!isadmin && canmanage == 0 ){

                    let reportTo = []
                    let reportright = 0

                    if(RA[o.personid.toString()]){
                        reportTo = RA[o.personid.toString()].reportTo
                    }else{
                        reportTo = await MainDB.getmyReportTo(o.personid.toString(),personResp.ResultData)
                        RA[o.personid.toString()] = {
                            reportTo : reportTo,
                        }
                    }
                    if(reportTo.includes(req.headers.uid)){
                        reportright = 1
                    }

                    if(reportright){
                        rightWiseData.push(o)
                    }                    
                    o.reportright = reportright
                }

                if(isadmin || canmanage == 1 ){

                    o.reportright = 1
                    // o.approveright = 1
                    rightWiseData.push(o)
              
                }
            }
            
            /// filters ---------------------------------------------------------------------
            // for person
            if (PaginationInfo.filter.person) {
                // const regex = new RegExp(".*" + PaginationInfo.filter.person.replace(/[-\/\\^$*+?.()|[\]{}]/g, "\\$&") + ".*")
                // const matchedSites = rightWiseData.filter(({person}) => person.match(regex));
                // const matchedSites = rightWiseData.filter((o) => o.person.toLowerCase() == PaginationInfo.filter.person.toLowerCase());
                const matchedSites = rightWiseData.filter(({ person }) => person.match(new RegExp(PaginationInfo.filter.person, "gi")))
                rightWiseData = matchedSites
            }
            // supportcategory
            if (PaginationInfo.filter.supportcategoryid) {
                const projectfilter = rightWiseData.filter((o) => o.supportcategory._id.toString() == PaginationInfo.filter.supportcategoryid);
                rightWiseData = projectfilter
            }
            // status
            if (PaginationInfo.filter.status !== undefined  && PaginationInfo.filter.status !== "" ) {
                const statusfilter = rightWiseData.filter((o) => o.status === PaginationInfo.filter.status);
                rightWiseData = statusfilter
            }
            // // module
            // if (PaginationInfo.filter.moduleid) {
            //     const modulefilter = rightWiseData.filter((o) => o.task.moduleid.toString() == PaginationInfo.filter.moduleid);
            //     rightWiseData = modulefilter
            // }

            // if (PaginationInfo.filter._id) {
            //     const matchedSites = rightWiseData.filter((o) => o._id.toString() == PaginationInfo.filter._id)
            //     rightWiseData = matchedSites
            // }
            /// filters ---------------------------------------------------------------------
            
            /// sorting ---------------------------------------------------------------------
            for (const key in sort) {
                if (sort[key] == 1) {
                    rightWiseData.sort(function (a, b) {                        
                        return  b[key] > a[key] ? 1 : -1 || b[key] - a[key] || new Date(b[key]) - new Date(a[key])
                    })
                }else{
                    rightWiseData.sort(function (b, a) {
                        return  b[key] < a[key] ? -1 : 1 || b[key] - a[key] || new Date(b[key]) - new Date(a[key])
                    })
                }
            }
            /// sorting ---------------------------------------------------------------------

            // pagination
            let pagelimit = PaginationInfo.pagelimit
            let pageno = PaginationInfo.pageno - 1

            let paginateddata = IISMethods.PaginationArr(rightWiseData, pagelimit, pageno)

            let ResponseBody = {}
            ResponseBody.pagename = "Review Support Ticket Timelog Request"
            ResponseBody.status = 200
            ResponseBody.message = Config.getResponsestatuscode()['200']
            
            if (paginateddata.data) {
                ResponseBody.data = paginateddata.data
            } else {
                ResponseBody.data = []
            }
            ResponseBody.currentpage = PaginationInfo.pageno
            ResponseBody.nextpage = paginateddata.page    
            //totaldocs pending

            req.ResponseBody = ResponseBody
            next() 
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err}
            next()
        }
    }

    async UpdatecomplaintTimeLogHistory(req, res, next){
        try{
            let ObjectId = IISMethods.getObjectId()
            let ResponseBody = {}
            let menualid = new ObjectId()

            let isadmin = await MainDB.IsAdmin(req.headers.uid)

            const pipeline = [{$match : {'_id' : new ObjectId(req.body._id)}}]
            const  record = await MainDB.getmenual('tbltimelog', new _TimeLog(), pipeline)
            
            let allTimelog = record.ResultData
            let deleterequest = req.body.deleterequest
            let editrequest = req.body.editrequest
            let timelogvalid = true
            let pendingreqdeleted = false

            record.ResultData[0].menualtimeloghistory = record.ResultData[0] && record.ResultData[0].menualtimeloghistory ? record.ResultData[0].menualtimeloghistory : []

            // MANUAL TIMELOG OVER LAP VALIDATION
            for (const iterator of allTimelog) {

                const filteredLog = iterator.timehistory ?  iterator.timehistory.filter(o => !o.menualid && o.deleted != 1) : []

                let newArr = []
                filteredLog.map((log, index) => {
                    if(log.type == 3){
                        log.iscomplete = true

                        let count = 0
                        let tempIndex = index
                        do {
                            --tempIndex
                            if(filteredLog[tempIndex]?.type == 2){
                                ++count
                            }
                        }
                        while (filteredLog[tempIndex]?.type != 1)
                        
                        // if (lenght of objects of type 2) previous type 3 object is in odd add tempobj and consider as complete log
                        if(count > 0 && count % 2 == 1){
                        }else {
                            newArr.push(log)
                        }
                    }
                    else {
                        newArr.push(log)
                    }
                })

                let timehistoryArr = []
                newArr.map((object, index) => {
                    if(index % 2 == 0){
                        let temp
                        if(newArr[index + 1]){
                            temp = [newArr[index], newArr[index + 1]]
                        }

                        if(temp && temp[0]._id.toString() != req.body.firsthistoryid && temp[0]._id.toString() != req.body.secondhistoryid){
                            timehistoryArr.push(temp)
                        }
                    }
                })

                const manualLogs = iterator.timehistory ? iterator.timehistory.filter(o => o.menualid != '' && o.deleted != 1 && o.status == 1) : []
                // newArr = newArr.concat(manualLogs)
                manualLogs.map((object, index) => {
                    if(index % 2 == 0){
                        let temp
                        if(manualLogs[index + 1]){
                            temp = [manualLogs[index], manualLogs[index + 1]]
                        }
                        else {
                            temp = [manualLogs[index]]
                        }
                        if(temp && temp[1]._id.toString() != req.body.firsthistoryid && temp[1]._id.toString() != req.body.secondhistoryid){
                            timehistoryArr.push(temp)
                        }
                    }
                })

                for (const iterator of timehistoryArr) {
                    let valid = IISMethods.isOverlapDate(iterator[0].time,  iterator[1].time,  req.body.autodate[0],  req.body.autodate[1])
                    if (valid) {
                        timelogvalid = false
                    }                            
                }
            }
            
            let oldtimelogrequestid = ''
            let oldstartdate = ''
            let oldenddate = ''

            //IF NOT OVERLAPPING
            if (timelogvalid) {

                var RecordInfo = {}
                
                if (record.ResultData[0] && record.ResultData[0].recordinfo) {
                    RecordInfo = record.ResultData[0].recordinfo
                    RecordInfo.updateuid = req.headers.uid
                    RecordInfo.updateby = req.headers.personname
                    RecordInfo.updatedate = IISMethods.getdatetimeisostr()
                }
                record.ResultData[0].recordinfo = RecordInfo
                
                // FOR TIME LOG REQUEST
                let timelogrequestid = new ObjectId()
               
                let recordHistory = {
                    time: new Date().toISOString(),
                    menualid : menualid,
                    action : 0,
                    menualpersonid : req.headers.uid,
                    menualperson : req.headers.personname,
                    menualreasonid : req.body.menualreasonid,
                    menualreason : req.body.menualreason,
                }
                
                for (const iterator of record.ResultData[0].timehistory) {


                    //firsthistoryid => ID OF ONE OF TWO OBJECTS FOR START AND END (FIRST OBJ ID)
                    if (iterator._id.toString() == req.body.firsthistoryid) {

                        if(iterator.menualid && iterator.status === 0 && deleterequest){
                            pendingreqdeleted = true
                        }else{

                            oldstartdate = iterator.time
                            oldtimelogrequestid = iterator.updateid
    
                            //IF ADMIN, SET PASSESED TIME DIRECTLY ELSE SET PASSED TIME DIRECTLY IF NOT DELETE OR EDIT REQUEST
                            if (isadmin) {
                                iterator.time = req.body.autodate[0]
                            }else{
                                iterator.time = deleterequest || editrequest ? iterator.time : req.body.autodate[0]
                            }
    
                            iterator.edited = deleterequest || editrequest ? 0 : 1
                            iterator.editeddetails = iterator.editeddetails && iterator.editeddetails.length ? iterator.editeddetails : []
                            iterator.editeddetails.push({
                                editpersonid : req.headers.uid,
                                editperson : req.headers.personname,
                                time : new Date().toISOString()
                            })
    
                            //MANUAL GENERATED ID
                            iterator.menualid = menualid
                            iterator.menualreasonid = req.body.menualreasonid
                            iterator.menualreason = req.body.menualreason
    
                            //FOR EDIT
                            if (editrequest) {
                                if (isadmin) {
                                    recordHistory.status = 1
                                    recordHistory.edit = 1
                                    record.ResultData[0].menualtimeloghistory.push(recordHistory)
                                    iterator.status = 1
                                    iterator.deleterequest = 0
                                    iterator.deleted = 0
                                }else{
                                    iterator.status = 0
                                    iterator.updated = 1
                                    iterator.updateid = timelogrequestid
                                }
                            }
                           
                            //FOR DELETE
                            if (deleterequest) {
                                if (isadmin) {
                                    recordHistory.status = 1
                                    recordHistory.deleterequest = 1
                                    record.ResultData[0].menualtimeloghistory.push(recordHistory)
                                    iterator.deleted = 1
                                    iterator.deleterequest = 1
                                    iterator.status = 1
                                    iterator.edit = 0
                                    iterator.editrequest = 0
                                }else{
                                    iterator.status = 0
                                    iterator.updated = 2
                                    iterator.updateid = timelogrequestid
                                }
                            }
    

                        }


                    }
                    
                    //secondhistoryid => ID OF ONE OF TWO OBJECTS FOR START AND END (SECOND OBJ ID)
                    if (iterator._id.toString() == req.body.secondhistoryid) {
                        if (isadmin) {
                            iterator.time = req.body.autodate[1]
                        }else{                        
                            iterator.time = deleterequest || editrequest ? iterator.time : req.body.autodate[1]
                        }
                        oldenddate = iterator.time
                        iterator.edited = deleterequest || editrequest ? 0 : 1
                        iterator.editeddetails = iterator.editeddetails && iterator.editeddetails.length ? iterator.editeddetails : []
                        iterator.editeddetails.push({
                            editpersonid : req.headers.uid,
                            editperson : req.headers.personname,
                            time : new Date().toISOString()
                        })
                        iterator.menualid = menualid
                        iterator.menualreasonid = req.body.menualreasonid
                        iterator.menualreason = req.body.menualreason
                        
                        if (editrequest) {
                            if (isadmin) {
                                recordHistory.status = 1
                                recordHistory.edit = 1
                                record.ResultData[0].menualtimeloghistory.push(recordHistory)
                                iterator.status = 1
                                iterator.deleterequest = 0
                                iterator.deleted = 0
                            }else{
                                iterator.status = 0
                                iterator.updated = 1 // for edit
                                iterator.updateid = timelogrequestid
                            }
                        }
                       
                        if (deleterequest) {
                            if (isadmin) {
                                recordHistory.status = 1
                                recordHistory.deleterequest = 1
                                record.ResultData[0].menualtimeloghistory.push(recordHistory)
                                iterator.deleted = 1
                                iterator.deleterequest = 1
                                iterator.status = 1
                                iterator.edit = 0
                                iterator.editrequest = 0
                            }else{
                                iterator.status = 0
                                iterator.updated = 2 // for delete
                                iterator.updateid = timelogrequestid
                            }
                        }
                    }
                }
    
                if(pendingreqdeleted == false){

                    // FOR TIMELOG REQUEST
                    if (editrequest || deleterequest ) {
                        let timelogrequestdata = {
                            _id : timelogrequestid,
                            timelogid : record.ResultData[0]._id,
                            taskid :  record.ResultData[0].taskid,
                            taskseries :  record.ResultData[0].taskseries,
                            menualid : menualid,
                            menualreasonid : req.body.menualreasonid,
                            menualreason : req.body.menualreason,
                            menualpersonid : req.headers.uid,
                            menualperson : req.headers.personname,
                            newstarttime :  req.body.autodate[0],
                            newendtime :  req.body.autodate[1],
                            editrequest : editrequest,
                            deleterequest : deleterequest,
                            oldstarttime : oldstartdate,
                            oldendtime : oldenddate,
                            firsthistoryid : req.body.firsthistoryid,
                            secondhistoryid : req.body.secondhistoryid,
                        }
                        var timelogrequestresp = await MainDB.executedata('i',  new _complaintTimelogRequest() ,'tblsupporttickettimelogrequests', timelogrequestdata)
                        await MainDB.executedata('d',  new _complaintTimelogRequest() ,'tblsupporttickettimelogrequests', {_id : oldtimelogrequestid})
                    }

                    if (isadmin) {
                        if (deleterequest) {
                            let oldduration = new Date(oldenddate) - new Date(oldstartdate)
                            record.ResultData[0].duration = record.ResultData[0].duration - oldduration
                        }
                        if (req.body.autodate[1] && req.body.autodate[0] && !deleterequest) {
                            let newduration = new Date(req.body.autodate[1]) - new Date(req.body.autodate[0])
                            let oldduration = new Date(oldenddate) - new Date(oldstartdate)
                            record.ResultData[0].duration = record.ResultData[0].duration - oldduration
                            record.ResultData[0].duration = record.ResultData[0].duration + newduration
                        }
                    }
        
                    var resp = await MainDB.executedata('u',  new _TimeLog() ,TableName, record.ResultData[0])
                    
                    //mail

                        
                    ResponseBody.status = resp.status
                    ResponseBody.message = resp.message
                    ResponseBody.data = resp.data

                }else{

                    ResponseBody.status = 401
                    ResponseBody.message = "Can not delete Pending requests"

                }

                
            }else{
                ResponseBody.status = 400
                ResponseBody.message = Config.getErrmsg()['overlapdate']                
            }

            req.ResponseBody = ResponseBody
            next()

        }
        catch(err){
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err}
            next()
        }
    }

    // End Support Ticket TimeLog Master
}