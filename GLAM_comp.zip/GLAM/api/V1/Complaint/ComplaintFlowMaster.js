import {IISMethods, Config,MainDB} from '../../../config/Init.js'
import _ComplaintFlow from '../../../model/Complaint/ComplaintFlow.js'
import _SupportCategory from '../../../model/Complaint/ComplaintStage.js'
import _Complaint from '../../../model/Complaint/Complaint.js'

const TableName = "tblcomplaintflow"

export default class ComplaintFlow{

    // START Complaint Flow
    //List
    async ListComplaintFlow(req, res, next)
    {
        try {

            var PaginationInfo = req.body.paginationinfo

            const requiredPage = {pageno : PaginationInfo.pageno, skip : (PaginationInfo.pageno - 1) * PaginationInfo.pagelimit, pagelimit : PaginationInfo.pagelimit}
            var pipeline = []
            var sort = (Object.keys(PaginationInfo.sort).length !== 0 ? PaginationInfo.sort : {'_id' : -1})
            let projection = PaginationInfo.projection ? PaginationInfo.projection : {}
            let fieldorder = PaginationInfo.isfieldorder ? PaginationInfo.isfieldorder : 0

            pipeline = IISMethods.GetPipelineForFilter(PaginationInfo.filter)
            
            const searchtext = req.body.searchtext || ""
            if (searchtext !== "") {
                pipeline.push(...IISMethods.GetGlobalSearchFilter(new _ComplaintFlow(), searchtext))
            }
            const ObjectId = IISMethods.getobjectid()
            
            if(req.headers.propertyid){
                pipeline.push({$match:{propertyid:ObjectId(req.headers.propertyid)}})
            }
            const resp = await MainDB.getmenual(TableName, new _ComplaintFlow(), pipeline, requiredPage, sort, fieldorder,"",projection)

            var ResponseBody = {}
                        
            ResponseBody.pagename = "Complaint Flow"
            ResponseBody.status = 200
            ResponseBody.message = Config.getResponsestatuscode()['200']
            ResponseBody.totaldocs = resp.totaldocs
            ResponseBody.data = resp.ResultData[0]
            ResponseBody.currentpage = resp.currentpage
            ResponseBody.nextpage = resp.nextpage
            ResponseBody.fieldorder = resp.fieldorderdata
            ResponseBody.formfieldorderdata = resp.formfieldorderdata

            req.ResponseBody = ResponseBody
            next() 
        }
        catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err}
            next()
        }
    }


    async ListPropertyComplaintFlow(req, res, next)
    {
        try {

            var PaginationInfo = req.body.paginationinfo

            const requiredPage = {pageno : PaginationInfo.pageno, skip : (PaginationInfo.pageno - 1) * PaginationInfo.pagelimit, pagelimit : PaginationInfo.pagelimit}
            var pipeline = []
            var sort = (Object.keys(PaginationInfo.sort).length !== 0 ? PaginationInfo.sort : {'_id' : -1})
            let projection = PaginationInfo.projection ? PaginationInfo.projection : {}
            let fieldorder = PaginationInfo.isfieldorder ? PaginationInfo.isfieldorder : 0

            pipeline = IISMethods.GetPipelineForFilter(PaginationInfo.filter)
            
            const searchtext = req.body.searchtext || ""
            if (searchtext !== "") {
                pipeline.push(...IISMethods.GetGlobalSearchFilter(new _ComplaintFlow(), searchtext))
            }
            const ObjectId = IISMethods.getobjectid()
            
            if(req.headers.propertyid){
                pipeline.push({$match:{propertyid:ObjectId(req.headers.propertyid)}})
            }
            const resp = await MainDB.getmenual(TableName, new _ComplaintFlow(), pipeline, requiredPage, sort, fieldorder,"",projection)

            var ResponseBody = {}
                        
            ResponseBody.pagename = "Complaint Flow"
            ResponseBody.status = 200
            ResponseBody.message = Config.getResponsestatuscode()['200']
            ResponseBody.totaldocs = resp.totaldocs
            ResponseBody.data = resp.ResultData
            ResponseBody.currentpage = resp.currentpage
            ResponseBody.nextpage = resp.nextpage
            ResponseBody.fieldorder = resp.fieldorderdata
            ResponseBody.formfieldorderdata = resp.formfieldorderdata

            req.ResponseBody = ResponseBody
            next() 
        }
        catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err}
            next()
        }
    }

    //Insert
    async InsertComplaintFlow(req, res, next)
    {
        try {
            const ObjectId = IISMethods.getobjectid()
            var ResponseBody = {}

            let stageisempty = false
            for (const iterator of req.body.complaintflow ) {
                if(iterator.position && (!iterator.assignedperson || (iterator.assignedperson && iterator.assignedperson.length == 0))){
                    stageisempty = true
                    break;
                }
            } 
            let resp

            if(stageisempty == false){
                if(!req.body._id){
                     resp = await MainDB.executedata('i', new _ComplaintFlow(),TableName, req.body)
                }else{
                    
                    const pipeline = [{ $match: { '_id': new ObjectId(req.body._id) } }]
                    const record = await MainDB.getmenual(TableName, new _ComplaintFlow(), pipeline)

                    // record info Update data set 
                    var RecordInfo = record.ResultData[0].recordinfo
                    RecordInfo.updateuid = req.headers.uid
                    RecordInfo.updateby = req.headers.personname
                    RecordInfo.updatedate = IISMethods.getdatetimeisostr()
                    req.body.recordinfo = RecordInfo         

                    resp = await MainDB.executedata('u', new _ComplaintFlow(),TableName, req.body)
                }

                ResponseBody.status = resp.status
                ResponseBody.data = resp.data
                ResponseBody.message = resp.message

            }else{
                ResponseBody.status = 400
                ResponseBody.message = "One of the Node is Empty!"
            }      
           
            req.ResponseBody = ResponseBody
            next() 
        }
        catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err}
            next()
        }
    }

    async ListComplaintFlowAssignperson(req,res,next){
        try{
            var ResponseBody = {}

            var PaginationInfo = req.body.paginationinfo

            const requiredPage = {pageno : PaginationInfo.pageno, skip : (PaginationInfo.pageno - 1) * PaginationInfo.pagelimit, pagelimit : PaginationInfo.pagelimit}
            var pipeline = []
            var sort = (Object.keys(PaginationInfo.sort).length !== 0 ? PaginationInfo.sort : {'_id' : -1})
            let projection = PaginationInfo.projection ? PaginationInfo.projection : {}

            pipeline = IISMethods.GetPipelineForFilter(PaginationInfo.filter)

            const searchtext = req.body.searchtext || ""
            if (searchtext !== "") {
                pipeline.push(...IISMethods.GetGlobalSearchFilter(new _ComplaintFlow(), searchtext))
            }
            
            const resp = await MainDB.getmenual(TableName, new _ComplaintFlow(), pipeline, requiredPage, sort, true,"",projection)
            console.log("🚀 ~ ComplaintFlow ~ ListComplaintFlowAssignperson ~ resp:", resp)

            const allAssignedPersons = resp.ResultData[0]?.complaintflow?.flatMap(flow => 
                flow.assignedperson.map(person => ({
                  assignedpersonid: person.assignedpersonid,
                  assignedperson: person.assignedperson,
                  _id: person._id,
                  isskip:1
                }))
              )
            var ResponseBody = {}
            
            ResponseBody.pagename = "Complaint Flow"
            ResponseBody.status = 200
            ResponseBody.message = Config.getResponsestatuscode()['200']
            ResponseBody.data =allAssignedPersons

            req.ResponseBody = ResponseBody
            next() 
        }catch(err){
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err}
            next()
        }
    }

    //Insert Multiple (COPY)
    async InsertMultipleComplaintFlow(req, res, next)
    {
        try {
            const ObjectId = IISMethods.getObjectId()

            //prepare data
            var data = []
            var toids = []
                                   
            const pipeline = [{$match:{'complaintcategoryid':new ObjectId(req.body.fromid)}}]
            const fetchResp = await MainDB.getmenual(TableName, new _ComplaintFlow(),  pipeline)

            var resp = {}

            if(fetchResp.ResultData.length != 0){
                req.body.copyto.forEach( copytoobj => {
                    if(copytoobj.supportcategoryid != req.body.fromid){

                        toids.push(new ObjectId(copytoobj.supportcategoryid))
                        let newdata = fetchResp.ResultData[0]
                        delete newdata._id
                        data.push({
                            ...newdata,
                            supportcategoryid : copytoobj.supportcategoryid,
                            supportcategory : copytoobj.supportcategory,
                            recordinfo:req.body.recordinfo
                        })

                    }
                })

                // delete data
                const delpipeline = {'complaintcategoryid':{$in:toids}}
                resp = await MainDB.DeleteMany(TableName,new _ComplaintFlow(),delpipeline)

                if(resp.status == 200){
                    resp = await MainDB.InsertMany(TableName,new _ComplaintFlow(),data)
                }
            }else{
                resp.status = 404
                resp.message = "Data not Exists from where you are coping data"
            }


            var ResponseBody = {}
            ResponseBody.status = resp.status
            ResponseBody.message = resp.message
           
            req.ResponseBody = ResponseBody
            next() 
        }
        catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err}
            next()
        }
    }

    //Update
    async UpdateComplaintFlow(req, res, next){
        try{
            
            const ObjectId = IISMethods.getobjectid()
            var ResponseBody = {}

            const pipeline = [{$match : {'_id' : new ObjectId(req.body._id)}}]
            const  record = await MainDB.getmenual(TableName, new _ComplaintFlow(), pipeline)
            
            // record info Update data set 
            var RecordInfo = record.ResultData[0].recordinfo
            RecordInfo.updateuid = req.headers.uid
            RecordInfo.updateby = req.headers.personname
            RecordInfo.updatedate = IISMethods.getdatetimeisostr()
            req.body.recordinfo = RecordInfo
        
            let stageisempty = false
            for (const iterator of req.body.Complaintflow) {
                if(iterator.position && (!iterator.assignedperson || (iterator.assignedperson && iterator.assignedperson.length == 0))){
                    stageisempty = true
                    break
                }
            } 

            if(stageisempty == false){
                const resp = await MainDB.executedata('u', new _ComplaintFlow(),TableName, req.body)
                ResponseBody.status = resp.status
                ResponseBody.data = resp.data
                ResponseBody.message = resp.message
            }else{
                ResponseBody.status = 400
                ResponseBody.message = "One of the Node is Empty!"
            }            

            req.ResponseBody = ResponseBody
            next() 
        }
        catch(err){
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err}
            next()
        }
    }

    //Delete
    async DeleteComplaintFlow(req, res, next){
        try{

            const ObjectId = IISMethods.getObjectId()

            const pipeline  = [{$match : { "_id" : new ObjectId(req.body._id)}}]
            const Complaintflowresp = await SubDBPool[req.headers["subdomainname"]].getmenual(TableName, new _ComplaintFlow , pipeline)

            const Complaintflowrespdata = Complaintflowresp.ResultData[0]

            const ComplaintObjModel = await MainDB.createmodel('tblComplaint', new _Complaint())
            var dependency = [ [ ComplaintObjModel['objModel'], {supportcategoryid : Complaintflowrespdata.supportcategoryid} , "Complaint"] ] 

            const resp = await MainDB.executedata('d', new _ComplaintFlow(),TableName,req.body,true,dependency) 
            
            var ResponseBody = {}
            ResponseBody.status = resp.status
            ResponseBody.message = resp.message

            req.ResponseBody = ResponseBody
            next() 
        }
        catch(err){
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err}
            next()
        }
    }

    // End Complain Flow
}