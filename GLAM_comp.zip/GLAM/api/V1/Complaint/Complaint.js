
import { IISMethods, Config, MainDB } from '../../../config/Init.js'
import _ComplaintLog from '../../../model/Complaint/ComplaintLog.js'
import _ComplaintFlow from '../../../model/Complaint/ComplaintFlow.js'
import _Customer from '../../../model/Onboarding/Customer.js'
import _ComplaintStageFlow from '../../../model/Complaint/ComplaintStageFlow.js'
import _ComplaintStage from '../../../model/Complaint/ComplaintStage.js'
import _Complaint from '../../../model/Complaint/Complaint.js'
import _Series from '../../../model/masters/Series.js'
import _ComplaintCategory from '../../../model/Complaint/ComplaintCategory.js'
import _TimeLog from '../../../model/TimeLog.js'
import _ComplaintChat from '../../../model/Complaint_Chat/ComplaintChat.js'

const TableName = "tblcomplaint"
const PageName = "complaint"
const FormName = "complaint"
const FltPageCollection = "complaint"

export default class Complaint {

    // START Complaint
    //List
    async ListComplaint(req, res, next) {
        try {
            var ResponseBody = {}
            const ObjectId = IISMethods.getobjectid()

            var PaginationInfo = req.body.paginationinfo

            const requiredPage = { pageno: PaginationInfo.pageno, skip: (PaginationInfo.pageno - 1) * PaginationInfo.pagelimit, pagelimit: PaginationInfo.pagelimit }
            var pipeline = []

            var sort = (Object.keys(PaginationInfo.sort).length !== 0 ? PaginationInfo.sort : { '_id': -1 })
            let projection = PaginationInfo.projection ? PaginationInfo.projection : {}
            let fieldorder = PaginationInfo.isfieldorder ? PaginationInfo.isfieldorder : 0

            pipeline.push(...IISMethods.GetPipelineForFilter(PaginationInfo.filter))

            const searchtext = req.body.searchtext || ""
            if (searchtext !== "") {
                pipeline.push(...IISMethods.GetGlobalSearchFilter(new _Complaint(), searchtext))
            }

            const objuids = []

            const userrolewiseperson = await MainDB.getPersonByUserroleHierarchyWithPersonData(req.headers.uid,req.headers.propertyid)
            objuids.push(userrolewiseperson)
   
            var isAdmin = await MainDB.IsAdmin(req.headers.uid)

            if (!isAdmin) {
                objuids.push(new ObjectId(req.headers.uid))
            } else {
                objuids = await MainDB.getSuperAdminWisePersonIds(req.headers.propertyid)
            }

            pipeline.push({
                $match: {
                    $or: [
                        {
                            $and: [
                                { 'assignedto.assignedtoid': { $in: objuids } },
                                { propertyid: ObjectId(req.headers.propertyid) }
                            ]
                        },
                        {
                            $and: [
                                { 'recordinfo.entryuid': req.headers.uid },
                                { propertyid: ObjectId(req.headers.propertyid) }
                            ]
                        }
                    ]
                }
            })

            const resp = await MainDB.getmenual(TableName, new _Complaint(), pipeline, requiredPage, sort, fieldorder, "", projection)

            const userId = req.headers.uid; // Logged-in user's ID
            const complaintIds = resp.ResultData.map(complaint => ObjectId(complaint._id));

            // Calculate unseen message counts for all complaints in a single query
            const unseenPipeline = [
                {
                    $match: {
                        complaintid: { $in: complaintIds },
                    },
                },
                {
                    $addFields: {
                        isUnseen: {
                            $not: {
                                $in: [userId, { $ifNull: ["$seenpersons.personid", []] }],
                            },
                        },
                    },
                },
                {
                    $match: {
                        isUnseen: true,
                    },
                },
                {
                    $group: {
                        _id: "$complaintid",
                        unseenCount: { $sum: 1 },
                    },
                },
            ];

            const unseenResult = await MainDB.getmenual("tblcomplaintchat", new _ComplaintChat(), unseenPipeline)

            // Map unseen counts to complaints
            const unseenMap = unseenResult.ResultData?.reduce((acc, item) => {
                acc[item._id.toString()] = item.unseenCount
                return acc;
            }, {})

            //  // Add unseen message count to each complaint
            resp.ResultData.forEach(complaint => {
                complaint.unseenmessagecount = unseenMap[complaint._id.toString()] || 0
            })

            ResponseBody.pagename = PageName
            ResponseBody.formname = FormName
            ResponseBody.fltpagecollection = FltPageCollection
            ResponseBody.status = 200
            ResponseBody.message = Config.getResponsestatuscode()['200']
            ResponseBody.data = resp.ResultData
            ResponseBody.currentpage = resp.currentpage
            ResponseBody.nextpage = resp.nextpage
            ResponseBody.totaldocs = resp.totaldocs
            ResponseBody.fieldorder = resp.fieldorderdata
            ResponseBody.formfieldorderdata = resp.formfieldorderdata
            req.ResponseBody = ResponseBody
            next()
        }
        catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }


    async InsertComplaint(req, res, next) {
        try {
            const ObjectId = IISMethods.getobjectid()
            const Id = new ObjectId()

            // GET SERIES FROM SERIES TABLE
            const seriesPipeline = [{ $match: { seriestype: "complaint", propertyid: new ObjectId(req.headers.propertyid) } }, { $limit: 1 }]
            const seriesResp = await MainDB.getmenual('tblseriesmaster', new _Series(), seriesPipeline)

            let resp = {
                status: 400,
                message: Config.errmsg['reqseries'],
            }

            if (seriesResp.ResultData.length) {

                //GET FLOW INFORMATION
                let flowpipeline = [{ $match: { 'complaintcategoryid': ObjectId(req.body.complaintcategoryid), 'propertyid': ObjectId(req.headers.propertyid) } }]
                let flowresp = await MainDB.getmenual('tblcomplaintflow', new _ComplaintFlow(), flowpipeline)

                const personpipeline = [{ $match: { 'isactive': 1 } }, { $project: { "personname": 1, "designation": 1, "designationid": 1, "property": 1 } }]
                const personresp = await MainDB.getmenual('tblcustomer', new _Customer(), personpipeline)


                req.body.statusid = Config.getUnAssignedStatus()
                req.body.status = "UnAssigned"


                req.body._id = Id

                let assignedto = []
                let ticketdurationinmin = 0
                let assigntoids = []

                let index = 0
                let notifypersonids = []
                let notifypersons = []

                //ESCALATION FLOW - FIND ASSIGNEE

                if ((flowresp.ResultData[0] && flowresp.ResultData[0].complaintflow && flowresp.ResultData[0].complaintflow.length) || req.body.isskip == 1) {

                    let flow = flowresp.ResultData[0]?.complaintflow[0]

                    //escalation skip particular employee assign
                    if (req.body.employeeid && req.body.isskip == 1) {
                        flow = {
                            assignedperson: [
                                {
                                    assignedpersonid: req.body.employeeid,
                                    assignedperson: req.body.employee
                                }
                            ],
                            alerttype: [
                                {
                                    alerttypeid: new ObjectId("67050f25c3d30d868b4a0820"),
                                    alerttype: "email",
                                }
                            ],
                        }
                    }

                    if (ticketdurationinmin == 0) {
                        ticketdurationinmin = flow.solvetime
                    }

                    if (flow.assignedperson.length) {
                        if (!assigntoids.includes(flow.assignedperson[0].assignedpersonid.toString())) {
                            for (const iterator of flow.assignedperson) {
                                assignedto.push({
                                    assignedtoid: iterator.assignedpersonid.toString(),
                                    assignedto: iterator.assignedperson
                                })
                                assigntoids.push(iterator.assignedpersonid.toString())
                            }
                        }
                    } else {
                        //department person assign
                        if (flow.assignedperson && !flow.assignedperson.length) {

                            let personsdata = personresp.ResultData.filter((o) => (flow.propertyid && o.propertyid && flow.propertyid.toString() == o.propertyid.toString()) || (flow.propertyid && o.propertyid && flow.propertyid.toString() == o.propertyid.toString()))
                            // console.log("personsdata.length",personsdata.length);
                            if (personsdata.length) {

                                let personsdata = personresp.ResultData.filter((o) => (flow.departmentid && o.departmentid && flow.departmentid.toString() == o.departmentid.toString()) || (flow.designationid && o.designationid && flow.designationid.toString() == o.designationid.toString()))
                                if (personsdata.length) {
                                    for (const iterator of personsdata) {
                                        if (!assigntoids.includes(iterator._id.toString())) {
                                            assignedto.push({
                                                assignedtoid: iterator._id.toString(),
                                                assignedto: iterator.personname
                                            })
                                            assigntoids.push(iterator._id.toString())
                                        }
                                    }

                                }
                            }
                        }
                    }

                    if (index == 0) {
                        notifypersonids = JSON.parse(JSON.stringify([...assigntoids])) //assigntoids
                        notifypersons = JSON.parse(JSON.stringify([...assignedto])) //assignedto
                    }

                    index++

                }

                req.body.assignedto = assignedto && assignedto.length ? assignedto : []
                req.body.timestamp = IISMethods.GetTimestamp()

                let convertmintohrmin = IISMethods.convertMinsToHrsMins(ticketdurationinmin)
                req.body.workhours = convertmintohrmin.h || 0
                req.body.workminutes = convertmintohrmin.m || 0

                let seriesId = await MainDB.getseriesno(new ObjectId(req.headers.propertyid), seriesResp.ResultData[0]._id, 'complaint', new _Complaint())
                let maxid = await MainDB.getmaxid(seriesResp.ResultData[0]._id, 'complaint', new _Complaint())

                req.body.seriesid = seriesResp.ResultData[0]._id
                req.body.maxid = maxid
                req.body.ticketid = seriesId

                req.body.propertyid = req.headers.propertyid
                req.body.property = req.headers.property
                req.body.ownerid = req.headers.uid
                req.body.owner = req.headers.personname

                let assignperson = assignedto.map(o => o.assignedto)

                req.body.log = [
                    {
                        statusid: req.body.statusid,
                        status: req.body.status,
                        personid: req.headers.uid,
                        logtype: 1,
                        assignedto: assignedto,
                        person: req.headers.personname,
                        backgroundcolor: req.body.backgroundcolor,
                        logdatetime: IISMethods.getdatetimeisostr(),
                        message: `The ticket has been assigned to ${assignperson} and status is ${req.body.status}`
                    }
                ]

                resp = await MainDB.executedata('i', new _Complaint(), TableName, req.body)

                if (resp.status == 200) {

                    await MainDB.addComplaintStatusLogs([req.body._id], req.body.statusid)

                    // INSERT LOG OF COMPLAINT TICKET
                    req.body.complaintid = req.body._id
                    delete req.body._id
                    req.body.supportticket = req.body.subject
                    req.body.logdatetime = IISMethods.getdatetimeisostr()
                    await MainDB.executedata('i', new _ComplaintLog(), 'tblcomplaintlog', req.body)

                    // notification & whatsapp & mail ---------------------
                    if (req.body.complaintcategoryid) {

                        let flowpipeline = [{ $match: { 'complaintcategoryid': ObjectId(req.body.complaintcategoryid), 'propertyid': ObjectId(req.headers.propertyid) } }]
                        let flowresp = await MainDB.getmenual('tblcomplaintflow', new _ComplaintFlow(), flowpipeline)

                        if (flowresp.ResultData[0] && flowresp.ResultData[0].complaintflow && flowresp.ResultData[0].complaintflow[0]) {

                            let firstflow = flowresp.ResultData[0].complaintflow[0]

                            // if (notifypersonids.length) {

                            let link = ''

                            // notification
                            // if (firstflow.alerttype && firstflow.alerttype.some(alert => alert.alerttypeid.toString() == Config.alerttype['notificationid'])) {
                            //     let title = IISMethods.makeContent(Config.getNotificationTitles()['supportticket'], resp.data)

                            //     var payload = {
                            //         title: title,
                            //         body: {
                            //             ticketid: resp.data._id.toString(),
                            //             categoryid: resp.data.complaintcategoryid,
                            //             supportcategoryseries: resp.data.ticketid,
                            //             category: resp.data.supportcategory,
                            //             subject: resp.data.subject,
                            //             description: resp.data.description,
                            //             owner: resp.data.owner,
                            //             url: link
                            //         },
                            //         type: Config.notificationtype['supportticket'],
                            //         pagename: 'supportticket',
                            //     }

                            //     await MainDB.sendNotification({ tousers: notifypersonids, payload: payload, webpushnotify: true, subdomain: req.headers['domainname'] })
                            // }

                            // mail send
                            if (firstflow.alerttype && firstflow.alerttype.some(alert => alert.alerttypeid.toString() === Config.alerttype['emailid'])) {

                                let template = Config.getEmailTemplates()['complaint']

                                let senddata = {
                                    complaintcategory: resp.data.complaintcategory,
                                    ticketid: resp.data.ticketid,
                                    subject: resp.data.subject,
                                    description: resp.data.description,
                                    owner: resp.data.owner,
                                    priority: resp.data.priority,
                                    notsloved: "",
                                    datetime: new Date(resp.data.recordinfo.entrydate).toString(),
                                    url: link,
                                }

                                const emailto = await MainDB.EmployeeEmails(notifypersonids)

                                await MainDB.sendEmail({
                                    from: process.env.EMAIL_FROM,
                                    to: emailto,
                                    subject: resp.data.subject,
                                    data: senddata,
                                    templateid: template
                                })
                            }
                            // }

                        }
                    }
                    // notification & whatsapp & mail ---------------------
                }
            }

            var ResponseBody = {}
            ResponseBody.status = resp.status
            ResponseBody.message = resp.status == 200 ? "Ticket Created" : resp.message

            req.ResponseBody = ResponseBody
            next()
        }
        catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

    //Update
    async UpdateComplaint(req, res, next) {
        try {

            const ObjectId = IISMethods.getobjectid()
            let valid = true
            let message = ""
            var ResponseBody = {}

            const pipeline = [{ $match: { '_id': new ObjectId(req.body._id) } }]
            const record = await MainDB.getmenual(TableName, new _Complaint(), pipeline)
        
            // if (req.body.hasOwnProperty('accepted')) {
            //     delete req.body.accepted
            // }

            const timelogpipeline = [{ $match: { 'taskid': new ObjectId(req.body._id) } }]
            const timelogrecord = await MainDB.getmenual('tbltimelog', new _TimeLog(), timelogpipeline)


            if ((timelogrecord.ResultData.length !== 0) && (record.ResultData[0].accepted !== 0)) {
                if (req.body.complaintcategoryid !== record.ResultData[0].complaintcategoryid.toString()) {
                    valid = false
                    message = "You Can Not Update Category"
                }
                if (req.body.subject.toLowerCase() !== record.ResultData[0].subject.toLowerCase()) {
                    valid = false
                    message = "You Can Not Update Subject"
                }
                if ((req.body.complaintcategoryid !== record.ResultData[0].complaintcategoryid.toString()) && (req.body.subject.toLowerCase() !== record.ResultData[0].subject.toLowerCase())) {
                    valid = false
                    message = "You Can Not Update Subject And Category"
                }
            }

            if (valid == true) {

                // RECORD INFO UPDATE DATA SET 
                var RecordInfo = record.ResultData[0].recordinfo
                RecordInfo.updateuid = req.headers.uid
                RecordInfo.updateby = req.headers.personname
                RecordInfo.updatedate = IISMethods.getdatetimeisostr()
                req.body.recordinfo = RecordInfo
                // const currentorder = record.ResultData[0]?.order
               
                // if (req.body.order < currentorder) {
                //     if (!(currentorder === 7 || (req.body.order === 3 && currentorder === 4))) {
                //         ResponseBody.status = 400
                //         ResponseBody.message = 'Backtracking is not allowed'
                
                //         req.ResponseBody = ResponseBody
                //         return next()
                //     }
                // }

                let recordLog = record.ResultData[0].log || []

                req.body.log = recordLog

                let assigndata = req.body.assignedto ? req.body.assignedto : []
                let assignedpersonid = []

                if (assigndata && assigndata.length) {
                    assigndata.forEach(function (o) {
                        assignedpersonid.push(o.assignedtoid.toString())
                    })
                }

                let message = `${req.headers.personname} has changed the status to ${req.body.status}.`


                if (req.body.statusid == Config.getReopenStatus()) {

                    const categorypipeline = [{ $match: { '_id': ObjectId(req.body.complaintcategoryid) } }];
                    const categoryrecord = await MainDB.getmenual('tblcomplaintcategorymaster', new _ComplaintCategory(), categorypipeline);

                    if (categoryrecord.ResultData.length !== 0) {
                        const reopentime = categoryrecord.ResultData[0].reopenwindowduration // reopenwindowduration in minutes
                        const statuslog = record.ResultData[0].log

                        const completestatuslog = statuslog.filter(log => log.statusid.toString() === Config.getCompletedStatus()).sort((a, b) => new Date(b.logdatetime) - new Date(a.logdatetime))

                        if (completestatuslog.length !== 0) {
                            let logDate = new Date(completestatuslog[0].logdatetime)
                            const currentDate = new Date(); // Get the current date and time

                            // Calculate the difference in minutes between currentDate and logDate
                            const differenceInMinutes = (currentDate - logDate) / (1000 * 60)

                            if (differenceInMinutes < reopentime) {
                                // Add the reopen window duration to the log date for the new due date
                                logDate.setMinutes(logDate.getMinutes() + reopentime)
                                req.body.duedate = new Date()
                                message += `\nReason: ${req.body.reopenreason || "No reason provided"}.`
                            } else {
                                ResponseBody.status = 406
                                ResponseBody.message = Config.getErrmsg()['notreopen']

                                req.ResponseBody = ResponseBody
                                return next()
                            }
                        }
                    }
                }

                if (req.body.statusid == Config.getCompletedStatus()) {
                    message += `\nReason: ${req.body.completereason || "No reason provided"}.`
                }

                if (req.body.accepted == 1) {
                    req.body.acceptedtime = IISMethods.getdatetimeisostr()
                    req.body.acceptedtimestamp = IISMethods.GetTimestamp()
                }
                
                recordLog.push({
                    statusid: req.body.statusid,
                    status: req.body.status,
                    personid: req.headers.uid,
                    person: req.headers.personname,
                    backgroundcolor: req.body.backgroundcolor,
                    assignedto: [
                        {
                            assignedtoid: req.headers.uid,
                            assignedto: req.headers.personname
                        }
                    ],
                    logdatetime: IISMethods.getdatetimeisostr(),
                    logtype: 1,
                    message: message
                })

                const resp = await MainDB.executedata('u', new _Complaint(), TableName, req.body)

                let oldassignee = record.ResultData[0].assignedto.map((o) => o.assignedtoid.toString())
                let send = assignedpersonid.length !== 0 ? assignedpersonid.filter((o) => !oldassignee.includes(o)) : []
                // let sendchat = send.length !== 0 ? assigndata.filter((o) => send.includes(o.assignedtoid.toString())) : []

                // resp.data.accepttime = req.body.accepttime
                // INSERT LOG OF COMPLAINT
                let reqbodyid = ""

                if (resp.status == 200) {

                    await MainDB.addComplaintStatusLogs([req.body._id], record.ResultData[0].statusid)

                    //if change category
                    if (resp.data.complaintcategoryid.toString() !== record.ResultData[0].complaintcategoryid.toString()) {

                        let flowpipeline = [{ $match: { "complaintcategoryid": resp.data.complaintcategoryid } }]
                        let flowresp = await MainDB.getmenual('tblcomplaintflow', new _ComplaintFlow(), flowpipeline)

                        let assignedto = []
                        let ticketdurationinmin = 0

                        //ESCALATION FLOW - FIND ASSIGNEE
                        if (flowresp.ResultData[0] && flowresp.ResultData[0].complaintflow && flowresp.ResultData[0].complaintflow.length) {
                            for (const flow of flowresp.ResultData[0].complaintflow) {
                                if (ticketdurationinmin == 0) {
                                    ticketdurationinmin = flow.solvetime
                                }
                                if (flow.assignedperson.length) {
                                    for (const obj of flow.assignedperson) {
                                        assignedto.push({
                                            assignedtoid: obj.assignedpersonid.toString(),
                                            assignedto: obj.assignedperson
                                        })
                                    }
                                }
                            }
                        }

                        let convertmintohrmin = IISMethods.convertMinsToHrsMins(ticketdurationinmin)
                        let workhours = convertmintohrmin.h || 0
                        let workminutes = convertmintohrmin.m || 0

                        let date = IISMethods.getdatetimeisostr()
                        let updaterecordinfo = req.body.recordinfo
                        updaterecordinfo.entrydate = date

                        let data = {
                            _id: req.body._id,
                            recordinfo: updaterecordinfo,
                            assignedto: assignedto && assignedto.length ? assignedto : [],
                            workhours: workhours,
                            workminutes: workminutes
                        }

                        const updateticket = await MainDB.executedata('u', new _Complaint(), TableName, data)

                        // if(updateticket.status == 200){
                        //     //update entrydate
                        //     req.body.recordinfo.entrydate = date

                        //     //delete notification for oldassignee
                        //     const pipeline = [{$match : {'body.ticketid' : req.body._id}}]
                        //     const resp = await MainDB.getmenual('tblnotification', new _Notification(), pipeline)

                        //     for (const iterator of resp.ResultData) {
                        //         await MainDB.executedata('d', new _Notification(), 'tblnotification', iterator)
                        //     }
                        // }
                    }

                    req.body.supportticketid = req.body._id

                    reqbodyid = req.body._id
                    delete req.body._id
                    req.body.supportticket = req.body.subject
                    req.body.logdatetime = IISMethods.getdatetimeisostr()
                    MainDB.executedata('i', new _ComplaintLog(), 'tblcomplaintlog', req.body)

                    //status change send mail to owner
                    if (record.ResultData[0].statusid.toString() !== resp.data.statusid.toString()) {

                        let dateformat = 1
                        const personpipeline = [{ $match: { '_id': new ObjectId(resp.data.ownerid.toString()) } }, { $project: { 'dateformat': 1 } }]
                        const personresp = await MainDB.getmenual('tblcustomer', new _Customer(), personpipeline)
                        if (personresp.ResultData[0]) {
                            dateformat = personresp.ResultData[0].dateformat ? personresp.ResultData[0].dateformat : 1
                        }

                        let template = Config.getEmailTemplates()['complaint']
                        let link = `${req.headers.origin}/complaint`
                        let date = IISMethods.getdatetimeisostr()
                        let senddata = {
                            ticketid: resp.data.ticketid,
                            person: resp.data.owner,
                            updateby: req.headers.personname,
                            subject: resp.data.subject,
                            companylogo: Config.glam,
                            link: link,
                            stage: resp.data.status,
                            previosustage: record.ResultData[0].status,
                            time: IISMethods.getDateFormats(date, dateformat) + " " + IISMethods.getDateFormats(date, 15)
                        }
                        await MainDB.sendMail('', [resp.data.ownerid.toString()], template, '', senddata)
                    }
                }

                // NOTIFICATION & WHATSAPP & MAIL ---------------------------------------------------------------

                //First Node Unassignee and new assignee add
                if (resp.status == 200 && resp.data.complaintcategoryid && record.ResultData[0].statusid.toString() == Config.getUnAssignedStatus() && send.length) {

                    let flowpipeline = [{ $match: { 'complaintcategoryid': resp.data.complaintcategoryid } }]
                    let flowresp = await MainDB.getmenual('tblcomplaintflow', new _ComplaintFlow(), flowpipeline)

                    if (flowresp.ResultData[0] && flowresp.ResultData[0].complaintflow && flowresp.ResultData[0].complaintflow[0]) {

                        let firstflow = flowresp.ResultData[0].complaintflow[0]

                        if (!firstflow.assignedperson.length && send.length !== 0) {

                            let link = ''

                            // notification
                            if (firstflow.alerttype && firstflow.alerttype.some(alert => alert === Config.alerttype['notificationid'])) {
                                let title = IISMethods.makeContent(Config.getNotificationTitles()['complaint'], resp.data)
                                var payload = {
                                    title: title,
                                    body: {
                                        _id: resp.data._id.toString(),
                                        complaintcategoryid: resp.data.complaintcategoryid,
                                        supportcategory: resp.data.supportcategory,
                                        subject: resp.data.subject,
                                        description: resp.data.description,
                                        owner: resp.data.owner,
                                    },
                                    type: Config.notificationtype['complaint'],
                                    pagename: 'complaint',
                                }

                                await MainDB.sendNotification({ tousers: send, payload: payload, webpushnotify: true, subdomain: req.headers['subdomainname'] })
                            }

                            // mail send
                            if (firstflow.alerttype && firstflow.alerttype.some(alert => alert === Config.alerttype['emailid'])) {
                                let template = Config.getEmailTemplates()['complaint']

                                let senddata = {
                                    complaintcategory: resp.data.complaintcategory,
                                    ticketid: resp.data.ticketid,
                                    subject: resp.data.subject,
                                    description: resp.data.description,
                                    owner: resp.data.owner,
                                    priority: resp.data.priority,
                                    notsloved: "",
                                    datetime: IISMethods.getDateFormats(resp.data.recordinfo.entrydate, 14),
                                    url: link,
                                }
                                const emailto = await MainDB.EmployeeEmails(notifypersonids)
                                await MainDB.sendEmail({
                                    from: process.env.EMAIL_FROM,
                                    to: emailto,
                                    subject: resp.data.subject,
                                    data: senddata,
                                    templateid: template
                                })
                            }
                        }
                    }
                }
                // notification & chat & whatsapp & mail ---------------------------------------------------------------


                //TODO: CHNAGE LOGIC!!!!!!!!!!!!!
                const stagePipeline = [{ $match: { '_id': new ObjectId(req.body.statusid), 'iscomplete': 1 } }]
                const stageresp = await MainDB.getmenual('tblcomplaintstage', new _ComplaintStage(), stagePipeline)

                // SEND OWNER TO RATING FORM WHEN TICKET SOLVE
                // if (resp.status == 200) {

                //     let completestatus

                //     if (stageresp.ResultData && stageresp.ResultData.length) {

                //         let timelog = timelogrecord.ResultData.find((o) => o.personid.toString() == req.headers.uid)
                //         let projecttion = { 'profilepic': 1, 'personname': 1 }
                //         let find = await MainDB.getPersonData(new ObjectId(req.headers.uid), projecttion)
                //         let send = {
                //             _id: req.body.supportticketid,
                //             supportcategory: req.body.supportcategory,
                //             subject: req.body.subject,
                //             description: req.body.description,
                //             attachment: req.body.attachment,
                //             serialid: req.body.serialid,
                //             ticketid: req.body.ticketid,
                //             status: req.body.status,
                //             actionperson: find.personname,
                //             actionpersonprofilepic: find.profilepic,
                //             duration: timelog ? timelog.duration : 0
                //         }
                //         IISMethods.emitSocket([req.body.ownerid], Config.getSocketTriggers()['supportticketclose'], send, req.headers['subdomainname'])
                //         console.log("send", send);

                //     }


                //     let flowstagepipeline = [{ $match: {} }]
                //     let flowstageresp = await MainDB.getmenual('tblcomplaintstageflow', new _ComplaintStageFlow(), flowstagepipeline)

                //     for (const o of flowstageresp.ResultData[0].complaintflow) {
                //         if (o.id.toString() == req.body.statusid?.toString()) {
                //             if (o.iscomplete == 1) {
                //                 completestatus = o.stageid
                //             }
                //         }
                //     }

                //     if (completestatus) {

                //         let entryDate = req.body.recordinfo.entrydate
                //         let dif = new Date() - new Date(entryDate)
                //         let mindif = IISMethods.toFixedFloat(dif / 60000)

                //         let flowpipeline = [{ $match: { 'complaintcategoryid': new ObjectId(req.body.complaintcategoryid) } }]
                //         let flowresp = await MainDB.getmenual('tblcomplaintflow', new _ComplaintStage(), flowpipeline)

                //         let solvedPerson
                //         let solvedPersonTime = 0

                //         let categorypipeline = [{ $match: { "_id": new ObjectId(req.body.complaintcategoryid) } }]
                //         let categoryresp = await MainDB.getmenual('tblcomplaintcategory', new _ComplaintCategory(), categorypipeline)

                //         let isprojectcategory = categoryresp.ResultData.length ? true : false
                //         let projectpersons = []

                //         const personpipeline = [{ $match: { 'iscustomer': { $ne: 1 } } }, { $project: { "personname": 1, "departmentid": 1, "department": 1, "designation": 1, "designationid": 1 } }]
                //         const personresp = await MainDB.getmenual('tblcustomer', new _Customer(), personpipeline)


                //         for (const i of flowresp.ResultData) {
                //             for (const o of i.complaintflow) {

                //                 let find
                //                 let persons = []

                //                 if (!o.assignedperson.length) {

                //                     let personsdata = personresp.ResultData.filter((iterator) => (o.departmentid && iterator.departmentid && o.departmentid.toString() == iterator.departmentid.toString()) || (o.designationid && iterator.designationid && o.designationid.toString() == iterator.designationid.toString()))

                //                     if (isprojectcategory) {

                //                         persons = personsdata.filter((o) => projectpersons.includes(o._id.toString()))
                //                         find = persons.find((o) => o._id.toString() == req.headers.uid.toString())
                //                         persons = persons.map((o) => o._id.toString())

                //                     } else {
                //                         find = personsdata.find((o) => o._id.toString() == req.headers.uid.toString())
                //                         persons = personsdata.map((o) => o._id.toString())
                //                     }

                //                 } else {

                //                     find = o.assignedperson.find(assignedPerson => assignedPerson.assignedpersonid.toString() === req.headers.uid.toString());
                //                 }

                //                 solvedPersonTime = solvedPersonTime + o.solvetime

                //                 if (find) {
                //                     solvedPerson = o
                //                     break;
                //                 }

                //             }
                //         }


                //         //flow
                //         //A--B---C ---- D => C
                //         //diff = 30
                //         //10---20----40
                //         //A--B => check for C
                //         // let latesolvedPerson
                //         // let solvet = 0

                //         // for (const i of flowresp.ResultData) {
                //         //     for (const o of i.complaintflow) {


                //         //         let find = o.assignedpersons.find((e) => e.assignedpersonid.toString() === req.headers.uid.toString());
                //         //         solvet =+ o.solvetime
                //         //         if(find){
                //         //             latesolvedPerson= o
                //         //             break;
                //         //         }
                //         //         if(!find &&  mindif >= solvet){


                //         //             let arrperson = o.assignedpersons.map(k => k.assignedpersonid.toString())
                //         //             await DF.AddEmployeePoints(req.headers['subdomainname'], arrperson, Config.praiseAndKnockType['notontimesolvesupportticket'],{ticketid: reqbodyid.toString() , ticketseries : req.body.ticketid, duration : dif})

                //         //         }
                //         //     }
                //         // }
                //         // if(latesolvedPerson && solvet && solvet <=  mindif){
                //         //     await DF.AddEmployeePoints(req.headers['subdomainname'], [req.headers.uid], Config.praiseAndKnockType['notontimesolvesupportticket'],{ticketid: reqbodyid.toString() , ticketseries : req.body.ticketid, duration : dif})
                //         // }
                //     }
                // }
                let respData
                if (resp && resp.data) {
                    respData = { ...resp.data._doc, accepttime: req.body.accepttime }
                }
                ResponseBody.status = resp.status
                ResponseBody.data = respData
                ResponseBody.message = resp.message

            } else {
                ResponseBody.status = 400
                ResponseBody.message = message
            }
            req.ResponseBody = ResponseBody
            next()
        }
        catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }


    //Delete
    async DeleteComplaint(req, res, next) {
        try {

            var ResponseBody = {}
            let ObjectId = IISMethods.getobjectid()
            const timelogpipeline = [{ $match: { 'taskid': new ObjectId(req.body._id) } }]
            const timelogrecord = await MainDB.getmenual('tbltimelog', new _TimeLog(), timelogpipeline)

            if (timelogrecord.ResultData && timelogrecord.ResultData.length == 0) {
                const resp = await MainDB.executedata('d', new _Complaint, TableName, req.body)

                // if (resp.status == 200 && req.body.supportcategoryid && req.body.supportcategoryid != "") {
                //     let pipeline = [{$match : {'body._id' : req.body._id}}]
                //     let resp = await MainDB.getmenual('tblnotification', new _Notification(), pipeline)

                //     for (const iterator of resp.ResultData) {
                //         await MainDB.executedata('d', new _Notification(), 'tblnotification', iterator)
                //     }
                // }

                ResponseBody.status = resp.status
                ResponseBody.message = resp.message
            } else {
                ResponseBody.status = 400
                ResponseBody.message = "can't delete Complaint"
            }

            req.ResponseBody = ResponseBody
            next()
        }
        catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

    // complaint rating
    async RatingComplaint(req, res, next) {
        try {
            const resp = await MainDB.executedata('u', new _Complaint(), TableName, req.body)

            var ResponseBody = {}
            ResponseBody.status = resp.status

            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

    // End Support Ticket
}