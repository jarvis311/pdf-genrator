import { IISMethods, Config, MainDB } from "../../../../config/Init.js"
import _ComplaintChat from "../../../../model/Complaint_Chat/ComplaintChat.js"
import _ComplaintChatHistory from "../../../../model/Complaint_Chat/ComplaintChatHistory.js"
import _Complaint from "../../../../model/Complaint/Complaint.js"
import _Employee from "../../../../model/Onboarding/Employee.js"
import _GateKeeper from '../../../../model/Onboarding/GateKeeper.js'
import _Customer from '../../../../model/Onboarding/Customer.js'

const TableName = "tblcomplaintchat"
export default class ComplaintChat {
    // List Complaint Chat
    async ListComplaintChat(req, res, next) {
        try {
            const ResponseBody = {}
            const ObjectId = IISMethods.getobjectid()

            const {
                searchtext = "",
                paginationinfo: { nextpageid = "", pageno = 1 , pagelimit = 10, filter = {}, sort = {}, projection = {} }
            } = req.body || {}

            const requiredPage = {
                nextpageid: nextpageid,
                pageno: pageno, 
                skip: (pageno - 1) * pagelimit,
                pagelimit: pagelimit
            }
            const complaintid = filter.complaintid || new ObjectId()
            let fieldorder = req.body.paginationinfo.isfieldorder ? req.body.paginationinfo.isfieldorder : 0

            const sortData = Object.keys(sort).length !== 0 ? sort : { _id: -1 }


            const pipeline = IISMethods.GetPipelineForFilter(filter)
            
            pipeline.push({ $addFields: { chattype: { $cond: { if: { $eq: ["$personid", ObjectId(req.headers.uid)] }, then: 1, else: 2 } } } }) // 1-Right, 2-Left

            const resp = await MainDB.getmenual(TableName, new _ComplaintChat(), pipeline, requiredPage, sortData, fieldorder, "", projection)

            resp?.ResultData?.forEach(async (obj) => {

                let alreadyseen = obj.seenpersons?.find((obj) => obj.personid?.toString() == req.headers.uid)

                if (!alreadyseen) {
                    let seenpersondetails = {
                        personid: ObjectId(req.headers.uid),
                        personname: req.headers.personname
                    }

                    //If no receiverside user in tblvcrequestusres push it into vcrequestusers
                    const upadtepipeline = [{ _id: new ObjectId(obj._id) }, { $push: { seenpersons: seenpersondetails } }]
                    const a = await MainDB.Update(TableName, new _ComplaintChat(), upadtepipeline)
                }
                obj.totalpersonseen = obj.seenpersons?.length
            })

            //_id chat 
            //  both chat
            //  10 data ek array mari uid

            const complaintPipeline = [{ $match: { _id: ObjectId(complaintid) } }]
            let dataResp = await MainDB.getmenual("tblcomplaint", new _Complaint(), complaintPipeline)


            let label = ""
            if (dataResp.ResultData?.length) {
                
                const complaintChatHistoryPipeline = { complaintid: new ObjectId(dataResp.ResultData[0]._id), personid: new ObjectId(req.headers.uid) }
                const complaintChatHistoryResp = await MainDB.FindOne("tblcomplaintchathistory", new _ComplaintChatHistory(), complaintChatHistoryPipeline)

                if (!complaintChatHistoryResp) {
                    // Insert complaint chat history
                    const complaintChatHistory = {
                        complaintid: dataResp.ResultData[0]._id.toString(),
                        personid: req.headers.uid,
                        propertyid: dataResp.ResultData[0].propertyid,
                        time: new Date()
                    }

                    await MainDB.executedata("i", new _ComplaintChatHistory(), "tblcomplaintchathistory", complaintChatHistory)
                } else {
                    // Update history time
                    const updateHistoryPipeline = [{ _id: complaintChatHistoryResp._id }, { $set: { time: new Date() } }]
                    await MainDB.Update("tblcomplaintchathistory", new _ComplaintChatHistory(), updateHistoryPipeline)
                }
                
                //lable for task chat 
                label = dataResp.ResultData[0].unitname
            }

            ResponseBody.pagename = "complaint"
            ResponseBody.status = 200
            ResponseBody.message = !resp.ResultData.length ? Config.getErrmsg()["nodatafound"] : resp.message
            ResponseBody.label = label
            ResponseBody.data = resp.ResultData
            ResponseBody.currentpage = resp.currentpage
            ResponseBody.nextpage = resp.nextpage

            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

    // Insert Complaint Chat
    async InsertComplaintChat(req, res, next) {
        try {
            const ResponseBody = {}
            const ObjectId = IISMethods.getobjectid()

            const chat = req.body

            const personPipeline = { _id: req.headers.uid }
            let person
            
            if (req.headers.apptype == 1) {
                person = await MainDB.FindOne("tblemployee", new _Employee(), personPipeline)
            } else if (req.headers.apptype == 2) {
                person = await MainDB.FindOne("tblgatekeeper", new _GateKeeper(), personPipeline)
            } else {
                person = await MainDB.FindOne("tblcustomer", new _Customer(), personPipeline)
            }


            let dataResp = await MainDB.getmenual("tblcomplaint", new _Complaint(), [
                { $match: { _id: ObjectId(chat.complaintid) } },
            ])
        

            const ComplaintData = dataResp.ResultData[0]

            if (person && ComplaintData) {
                // chat.mentions?.forEach((obj) => {
                //     obj.profilepic = obj.profilepic.replace(Config.s3baseurl, "")
                // })

                chat.personid = person._id
                chat.person = person.personname
                chat.designation = person.designation
                chat.profilepic = ""
                chat.reaction = []

                if (!chat.mentions) chat.mentions = []
                if (!chat.files) chat.files = []

                chat.seenpersondetails = {
                    personid: ObjectId(req.headers.uid),
                    personname: req.headers.personname
                }

                const resp = await MainDB.executedata("i", new _ComplaintChat(), TableName, chat)

                if (resp.status === 200) {

                    // ******************** SOCKET. *****************************/
                    // chat.profilepic = chat.profilepic ? Config.s3baseurl + chat.profilepic : ""
                    resp.data.profilepic = chat.profilepic
                    // chat.files.forEach((obj) => {
                    //     obj.url = Config.s3baseurl + obj.url
                    // })
                    resp.data.files = chat.files

                    // Socket For Complaint Chat
                    IISMethods.emitRoomWiseSocket({
                        to: [`godrejliving${chat.complaintid}`],
                        on: Config.getSocketTriggers()["messagereceive"],
                        data: resp.data
                    })
                    // ******************** SOCKET. *****************************/

                }

                ResponseBody.status = resp.status
                ResponseBody.message = resp.message
            } else {
                ResponseBody.status = 404
                ResponseBody.message = Config.getErrmsg()["personnotfound"]
            }

            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

    // Update Complaint Chat
    async UpdateComplaintChat(req, res, next) {
        try {
            const ResponseBody = {}

            // const TableName = "tblcomplaintchat"
            const pipeline = { _id: req.body._id }
            const complaintchat = await MainDB.FindOne(TableName, new _ComplaintChat(), pipeline)

            if (complaintchat) {
                const RecordInfo = complaintchat.recordinfo
                RecordInfo.updateuid = req.headers.uid
                RecordInfo.updateby = req.headers.personname
                RecordInfo.updatedate = IISMethods.getdatetimestr()
                req.body.recordinfo = RecordInfo

                req.body.isimportant = 0
                req.body.isurgent = 0

                const resp = await MainDB.executedata("u", new _ComplaintChat(), TableName, req.body)

                if (resp.status === 200) {
                    // Socket For Message Update
                    IISMethods.emitRoomWiseSocket({
                        to: [`godrejliving${resp.data.complaintid}`],
                        on: Config.getSocketTriggers()["messageupdate"],
                        data: resp.data
                    })
                }

                ResponseBody.data = resp.data
                ResponseBody.status = resp.status
                ResponseBody.message = resp.message
            } else {
                ResponseBody.status = 404
                ResponseBody.message = Config.getErrmsg()["notexist"]
            }

            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

    // Add/Remove reaction
    async ComplaintChatReaction(req, res, next) {
        try {
            const ResponseBody = {}
            const ObjectId = IISMethods.getobjectid()

            let pipeline

            if (req.body.add == 1) {
                req.body.reaction.reactorid = req.headers.uid

                pipeline = [{ _id: ObjectId(req.body._id) }, { $push: { reactions: req.body.reaction } }]
            } else {
                pipeline = [{ _id: ObjectId(req.body._id) }, { $pull: { reactions: { reactionid: req.body.reaction.reactionid } } }]
            }

            const resp = await MainDB.Update(TableName, new _ComplaintChat(), pipeline)

            if (resp.status == 200) {
                const complaintchatPipeline = { _id: req.body._id }
                const complaintchatResp = await MainDB.FindOne(TableName, new _ComplaintChat(), complaintchatPipeline)

                // Socket For Message Update
                IISMethods.emitRoomWiseSocket({
                    to: [`godrejliving${complaintchatResp.complaintid}`],
                    on: Config.getSocketTriggers()["messageupdate"],
                    data: complaintchatResp
                })

            }

            ResponseBody.status = resp.status
            ResponseBody.message = resp.message

            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }
}
