import {IISMethods, Config, MainDB} from '../../../config/Init.js'
import _ComplaintComments from '../../../model/Complaint/ComplaintComments.js'

const TableName = "tblcomplaintcomments"
const PageName = "complaintcomments"
const FormName = "Complaint Comments"
const FltPageCollection = "complaintcomments"

export default class ComplaintComments{

    // START ComplaintComments
    //List
    async ListComplaintComments(req, res, next)
    {
        try {

            var PaginationInfo = req.body.paginationinfo

            const requiredPage = {pageno : PaginationInfo.pageno, skip : (PaginationInfo.pageno - 1) * PaginationInfo.pagelimit, pagelimit : PaginationInfo.pagelimit}
            var pipeline = []
            var sort = (Object.keys(PaginationInfo.sort).length !== 0 ? PaginationInfo.sort : {'_id' : -1})
            let projection = PaginationInfo.projection ? PaginationInfo.projection : {}
            let fieldorder = PaginationInfo.isfieldorder ? PaginationInfo.isfieldorder : 0

            pipeline = IISMethods.GetPipelineForFilter(PaginationInfo.filter)

            const searchtext = req.body.searchtext || ""
            if (searchtext !== "") {
                pipeline.push(...IISMethods.GetGlobalSearchFilter(new _ComplaintComments(), searchtext))
            }
            
            const resp = await MainDB.getmenual(TableName, new _ComplaintComments(), pipeline, requiredPage, sort, fieldorder,"",projection)

            var ResponseBody = {}
            ResponseBody.pagename = PageName
            ResponseBody.formname = FormName
			ResponseBody.fltpagecollection = FltPageCollection
            ResponseBody.status = 200
            ResponseBody.message = Config.getResponsestatuscode()['200']
            ResponseBody.data = resp.ResultData
            ResponseBody.currentpage = resp.currentpage
            ResponseBody.nextpage = resp.nextpage
            ResponseBody.totaldocs = resp.totaldocs
            ResponseBody.fieldorder = resp.fieldorderdata   
            ResponseBody.formfieldorderdata = resp.formfieldorderdata      

            req.ResponseBody = ResponseBody
            next() 
        }
        catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err}
            next()
        }
    }


    //Insert
    async InsertComplaintComments(req, res, next)
    {
        try {
            req.body.comment_time = IISMethods.getdatetimeisostr()
                                   
            const resp = await MainDB.executedata('i', new _ComplaintComments(),TableName, req.body)

            var ResponseBody = {}
            ResponseBody.status = resp.status
            ResponseBody.message = resp.message
           
            req.ResponseBody = ResponseBody
            next() 
        }
        catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err}
            next()
        }
    }


    //Update
    async UpdateComplaintComments(req, res, next){
        try{

            const ObjectId = IISMethods.getobjectid()

            const pipeline = [{$match : {'_id' :new ObjectId(req.body._id)}}]
            const  record = await MainDB.getmenual(TableName, new _ComplaintComments(), pipeline)
            
            // record info Update data set 
            var RecordInfo = record.ResultData[0].recordinfo
            RecordInfo.updateuid = req.headers.uid
            RecordInfo.updateby = req.headers.personname
            RecordInfo.updatedate = IISMethods.getdatetimeisostr()
            req.body.recordinfo = RecordInfo
        
            const resp = await MainDB.executedata('u', new _ComplaintComments(),TableName, req.body)
            
            var ResponseBody = {}
            ResponseBody.status = resp.status
            ResponseBody.data = resp.data
            ResponseBody.message = resp.message

            req.ResponseBody = ResponseBody
            next() 
        }
        catch(err){
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err}
            next()
        }
    }

    
    //Delete
    async DeleteComplaintComments(req, res, next){
        try{

            const resp = await MainDB.executedata('d', new _ComplaintComments(),TableName,req.body) 
            
            var ResponseBody = {}
            ResponseBody.status = resp.status
            ResponseBody.message = resp.message

            req.ResponseBody = ResponseBody
            next() 
        }
        catch(err){
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err}
            next()
        }
    }

    // End complaintcomments Master
}