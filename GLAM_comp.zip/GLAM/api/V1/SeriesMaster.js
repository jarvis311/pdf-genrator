//seriesmaster old code
import { IISMethods, Config,MainDB } from "../../config/Init.js"
import _Series from "../../model/masters/Series.js"

const TableName = "tblseriesmaster"
const PageName = "Series Master"
const FormName = "Series Master"
const FltPageCollection = "seriesmaster"

export default class SeriesMaster {
    // List
    async ListSeries(req, res, next) {
        try {
            var ResponseBody = {}
            var pipeline = []
            const { searchtext = "", paginationinfo: { pageno = 1, nextpageid = "", pagelimit = 20, filter = {}, sort = {}, projection = {} } } = req.body || {}

            const requiredPage = {
                pageno: pageno,
                nextpageid: nextpageid,
                skip: (pageno - 1) * pagelimit,
                pagelimit: pagelimit
            }
            const sortData = Object.keys(sort).length !== 0 ? sort : { _id: -1 }
            pipeline = IISMethods.GetPipelineForFilter(filter)

            const ObjectId = IISMethods.getobjectid()
            let fieldorder = req.body.paginationinfo.isfieldorder ? req.body.paginationinfo.isfieldorder : 0

            if (req.headers.propertyid) {
                pipeline.push({ $match: { propertyid: ObjectId(req.headers.propertyid) } })
            }

            if (searchtext !== "") {
                pipeline.push(...IISMethods.GetGlobalSearchFilter(new _Series(), searchtext))
            }

            const resp = await MainDB.getmenual(TableName, new _Series(), pipeline, requiredPage, sortData,fieldorder, true, "", projection)

            ResponseBody.pagename = PageName
            ResponseBody.formname = FormName
            ResponseBody.fltpagecollection = FltPageCollection
            ResponseBody.status = 200
            ResponseBody.message = Config.getResponsestatuscode()["200"]
            ResponseBody.data = resp.ResultData
            ResponseBody.currentpage = resp.currentpage
            ResponseBody.nextpage = resp.nextpage   
            ResponseBody.totaldocs = resp.totaldocs;
            ResponseBody.fieldorder = resp.fieldorderdata 
            ResponseBody.formfieldorderdata = resp.formfieldorderdata      
            
            req.ResponseBody = ResponseBody; next()
        } catch (err) {


            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }; next()
        }
    }

    //Insert
    async InsertSeries(req, res, next) {
        try {
            const ResponseBody = {}
            const ObjectId = IISMethods.getobjectid()

            req.body.propertyid = req.headers.propertyid
            req.body.property = req.headers.property

            if (!req.body.propertyid) {
                req.body.propertyid = Config.dummyObjid
                req.body.property = ""
            }

            // check if series exists
            let pipeline = [
                {
                    $match: {
                        propertyid: ObjectId(req.body.propertyid),
                        seriestypeid: ObjectId(req.body.seriestypeid)
                    }
                }
            ]
      
            const findResp = await MainDB.getmenual(TableName, new _Series(), pipeline)

            if (!req.body.reset) {
                req.body.reset = ""
            }

            if (!findResp.ResultData.length) {
                const resp = await MainDB.executedata("i", new _Series(), TableName, req.body)

                ResponseBody.status = resp.status
                ResponseBody.message = resp.message
            } else {
                ResponseBody.status = 400
                ResponseBody.message = Config.getErrmsg()["isexist"]
            }

            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

    // Update
    async UpdateSeries(req, res, next) {
        try {
            const ResponseBody = {}
            const ObjectId = IISMethods.getobjectid()

            if (!req.body.propertyid) {
                req.body.propertyid = Config.dummyObjid
                req.body.property = ""
            }

            // let pipeline = [{ $match: { _id: ObjectId(req.body._id) } }]
            let pipeline = []
            pipeline = [
                {
                    $match: {
                        propertyid: ObjectId(req.body.propertyid),
                        seriestypeid: ObjectId(req.body.seriestypeid),
                        _id: { $ne: ObjectId(req.body._id) }
                    }
                }
            ]
            if (!req.body.propertyid) {
                pipeline = [
                    {
                        $match: {
                            seriestypeid: ObjectId(req.body.seriestypeid),
                            _id: { $ne: ObjectId(req.body._id) }
                        }
                    }
                ]
            }
            const record = await MainDB.getmenual(TableName, new _Series(), pipeline)

            if (!record.ResultData.length) {
                let updpipeline = [{ $match: { _id: ObjectId(req.body._id) } }]
                const updrecord = await MainDB.getmenual(TableName, new _Series(), updpipeline)

                // record info Update data set
                const RecordInfo = updrecord.ResultData[0].recordinfo
                RecordInfo.updateuid = req.headers.uid
                RecordInfo.updateby = req.headers.personname
                RecordInfo.updatedate = IISMethods.getdatetimestr()
                req.body.recordinfo = RecordInfo

                let Series = req.body
                Series.propertyid = req.body.propertyid ? req.body.propertyid : Config.dummyObjid
                Series.property = req.body.property ? req.body.property : ""

                const resp = await MainDB.executedata("u", new _Series(), TableName, Series)

                ResponseBody.data = resp.data
                ResponseBody.status = resp.status
                ResponseBody.message = resp.message
            } else {
                ResponseBody.status = 400
                ResponseBody.message = Config.getErrmsg()["isexist"]
            }

            req.ResponseBody = ResponseBody; next()
        } catch (err) {


            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }; next()
        }
    }

    //Delete
    async DeleteSeries(req, res, next) {
        try {
            const ResponseBody = {}
            const ObjectId = IISMethods.getobjectid()

            // //Dependency Check
            // const dependencyObj = {
            //     tblpurchase: new PurchaseMaster()
            // }

            // const dependency = []

            // for (const key in dependencyObj) {
            //     const ObjModel = await MainDB.createmodel(key, dependencyObj[key])
            //     dependency.push([ObjModel["objModel"], { seriesid: ObjectId(req.body._id) }, Config.apipagename[key]])
            // }

            const resp = await MainDB.executedata("d", new _Series(), TableName, req.body)

            ResponseBody.status = resp.status
            ResponseBody.message = resp.message
            ResponseBody.existdataPagename = resp.existdataPagename

            req.ResponseBody = ResponseBody; next()
        } catch (err) {


            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }; next()
        }
    }

    // End Series Master
}
