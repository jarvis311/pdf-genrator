import { IISMethods, Config } from "../../config/Init.js"
import _Emaillog from '../../model/EmailLog.js';

export default class Emaillog{

    // START Emaillog

    //List Emaillog
    async ListEmaillog(req, res, next){
        try {

            var PaginationInfo = req.body.paginationinfo

            const requiredPage = {pageno : PaginationInfo.pageno, skip : (PaginationInfo.pageno - 1) * PaginationInfo.pagelimit, pagelimit : PaginationInfo.pagelimit};

            var pipeline = [];
            var sort = (Object.keys(PaginationInfo.sort).length !== 0 ? PaginationInfo.sort : {'datetime' : -1})

            let personid = ''
            if(PaginationInfo.filter.personid){
                personid = PaginationInfo.filter.personid
                delete PaginationInfo.filter.personid
            }

            let applicationid = ''
            if(PaginationInfo.filter["applicationid"]){
                applicationid = PaginationInfo.filter["applicationid"]
                delete PaginationInfo.filter["applicationid"]
            }
           
            pipeline = IISMethods.GetPipelineForFilter(PaginationInfo.filter)

            if(applicationid){
                pipeline.push({$match:{'data.applicationid':applicationid}})
            }

            if (personid && personid != "") {
                pipeline.push({$match: { "data.to" : personid }})
            }

            let projection = PaginationInfo.projection

            const resp = await MainDB.getmenual('tblemaillog', new _Emaillog(), pipeline, requiredPage, sort, false, "", projection)

            var ResponseBody = {}
            ResponseBody.pagename = "Email List"
            ResponseBody.status = 200
            ResponseBody.message = Config.getResponsestatuscode()['200']
            ResponseBody.data = resp.ResultData
            ResponseBody.currentpage = resp.currentpage
            ResponseBody.nextpage = resp.nextpage

            req.ResponseBody = ResponseBody
            next()
        }
        catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err}
            next()
        }
    }

    //List FailEmail
    // async ListFailEmail(req, res, next){
    //     try {

    //         var PaginationInfo = req.body.paginationinfo

    //         const requiredPage = {pageno : PaginationInfo.pageno, skip : (PaginationInfo.pageno - 1) * PaginationInfo.pagelimit, pagelimit : PaginationInfo.pagelimit}
    //         var sort = (Object.keys(PaginationInfo.sort).length !== 0 ? PaginationInfo.sort : {'_id' : -1})
    //         let projection = PaginationInfo.projection ? PaginationInfo.projection : {}
           
    //         let personid = ''
    //         if(PaginationInfo.filter.personid){
    //             personid = PaginationInfo.filter.personid
    //             delete PaginationInfo.filter.personid
    //         }

    //         let applicationid = ''
    //         if(PaginationInfo.filter.applicationid){
    //             applicationid = PaginationInfo.filter.applicationid
    //             delete PaginationInfo.filter.applicationid
    //         }

    //         var pipeline = []
    //         pipeline = IISMethods.GetPipelineForFilter(PaginationInfo.filter)

    //         if (personid && personid != "") {
    //             pipeline.push({$match: { "data.emailto" : personid }})
    //         }

    //         if (applicationid && applicationid != "") {
    //             pipeline.push({$match: { "data.data.applicationid" : applicationid }})
    //         }
            
    //         const resp = await MainDB.getmenual('tblfailmailrecord', new _FailMailRecord(), pipeline, requiredPage, sort, projection)

    //         var ResponseBody = {}
    //         ResponseBody.pagename = "Fail Email List"
    //         ResponseBody.status = 200
    //         ResponseBody.message = Config.getResponsestatuscode()['200']
    //         ResponseBody.data = resp.ResultData
    //         ResponseBody.currentpage = resp.currentpage
    //         ResponseBody.nextpage = resp.nextpage

    //         req.ResponseBody = ResponseBody
    //         next()
    //     }
    //     catch (err) {
    //         req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err}
    //         next()
    //     }
    // }
}