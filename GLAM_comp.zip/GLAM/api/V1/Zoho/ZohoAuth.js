import { Config, IISMethods, MainDB } from "../../../config/Init.js"
import _ZohoServicesModel from "../../../model/Zoho/ZohoServicesModel.js"

// const TableName = "tblzohoservicemaster"
const PageName = "Zoho Auth"
const FormName = "Zoho Auth"
// const FltPageCollection = "zohoservicemaster"

export default class ZohoAuth {
    // Zoho Access token
    async ListZohoAccessToken(req, res, next) {
        try {
            const ResponseBody = {}
            const ObjectId = IISMethods.getobjectid()

            // const PropertyResp = await MainDB.getmenual("tblzohoservicemaster", new _ZohoServicesModel(), pipeline, requiredPage, sortData, true, "", projection)
            const ZohoAccessTokenResp = await MainDB.getZohoAccessToken()

            ResponseBody.pagename = PageName
            ResponseBody.formname = FormName
            ResponseBody.status = 200
            ResponseBody.message = Config.getResponsestatuscode()["200"]
            ResponseBody.data = ZohoAccessTokenResp
            // ResponseBody.currentpage = resp.currentpage
            // ResponseBody.nextpage = resp.nextpage

            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }
}