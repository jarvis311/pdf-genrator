import { Config, IISMethods, MainDB } from "../../../config/Init.js"
import _ZohoServicesModel from "../../../model/Zoho/ZohoServicesModel.js"

const TableName = "tblzohoservicemaster"
const PageName = "Zoho Services"
const FormName = "Zoho Services"
const FltPageCollection = "zohoservicemaster"

export default class ZohoServices {
    // List Zoho Services
    async ListZohoServices(req, res, next) {
        try {
            const ResponseBody = {}
            const ObjectId = IISMethods.getobjectid()

            const {
                searchtext = "",
                paginationinfo: { nextpageid = "", pageno = 1, pagelimit = 10, filter = {}, sort = {}, projection = {} }
            } = req.body || {}

            const requiredPage = {
                nextpageid: nextpageid,
                pageno: pageno,
                skip: (pageno - 1) * pagelimit,
                pagelimit: pagelimit
            }

            const sortData = Object.keys(sort).length !== 0 ? sort : { _id: 1 }

            const pipeline = IISMethods.GetPipelineForFilter(filter)

            if (searchtext !== "") {
                pipeline.push(...IISMethods.GetGlobalSearchFilter(new _ZohoServicesModel(), searchtext))
            }

            const resp = await MainDB.getmenual(TableName, new _ZohoServicesModel(), pipeline, requiredPage, sortData, true, "", projection)

            ResponseBody.pagename = PageName
            ResponseBody.formname = FormName
            ResponseBody.fltpagecollection = FltPageCollection
            ResponseBody.status = 200
            ResponseBody.message = Config.getResponsestatuscode()["200"]
            ResponseBody.data = resp.ResultData
            ResponseBody.currentpage = resp.currentpage
            ResponseBody.nextpage = resp.nextpage

            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

    // Insert ZohoServices
    async InsertZohoServices(req, res, next) {
        try {
            const ResponseBody = {}

            const resp = await MainDB.executedata("i", new _ZohoServicesModel(), TableName, req.body)

            ResponseBody.status = resp.status
            ResponseBody.message = resp.message

            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

    // Update ZohoServices
    async UpdateZohoServices(req, res, next) {
        try {
            const ResponseBody = {}

            const pipeline = { _id: req.body._id }
            const zohoservice = await MainDB.FindOne(TableName, new _ZohoServicesModel(), pipeline)

            if (zohoservice) {
                // record info Update data set
                // const RecordInfo = zohoservice.recordinfo
                // RecordInfo.updateuid = req.headers.uid
                // RecordInfo.updateby = req.headers.personname
                // RecordInfo.updatedate = IISMethods.getdatetimestr()
                // req.body.recordinfo = RecordInfo

                const resp = await MainDB.executedata("u", new _ZohoServicesModel(), TableName, req.body)

                ResponseBody.status = resp.status
                ResponseBody.message = resp.message
                ResponseBody.data = resp.data
            } else {
                ResponseBody.status = 404
                ResponseBody.message = Config.getErrmsg()["notexist"]
            }

            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

    // Delete ZohoServices
    async DeleteZohoServices(req, res, next) {
        try {
            const ResponseBody = {}

            // // Dependency Check
            // const dependencyObj = {
            //     tblnotificationsettingmaster: new _NotificationSetting(),
            //     tbluserrights: new _Userrights()
            // }
            // // Dependency Array
            const dependency = []
            // for (const key in dependencyObj) {
            //     const ObjModel = await MainDB.createmodel(key, dependencyObj[key])

            //     if (key === "tblnotificationsettingmaster" || key === "tbluserrights") {
            //         dependency.push([ObjModel["objModel"], { userroleid: req.body._id }, Config.apipagename[key]])
            //     }
            // }

            const resp = await MainDB.executedata("d", new _ZohoServicesModel(), TableName, req.body)

            ResponseBody.status = resp.status
            ResponseBody.message = resp.message
            ResponseBody.existdataPagename = resp.existdataPagename

            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }
}