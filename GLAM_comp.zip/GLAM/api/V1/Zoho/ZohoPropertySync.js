import { Config, IISMethods, MainDB } from "../../../config/Init.js"
import _ZohoServicesModel from "../../../model/Zoho/ZohoServicesModel.js"

// const TableName = "tblzohoservicemaster"
const PageName = "Zoho roperty Sync"
const FormName = "Zoho Property Sync"
// const FltPageCollection = "zohoservicemaster"

export default class ZohoPropertySync {
    // List Zoho Property Sync
    async ListZohoPropertySync(req, res, next) {
        try {
            const ResponseBody = {}
            const ObjectId = IISMethods.getobjectid()

            const PropertyResp = await MainDB.getmenual("tblzohoservicemaster", new _ZohoServicesModel(), pipeline, requiredPage, sortData, true, "", projection)
            const resp = await MainDB.getmenual("tblzohoservicemaster", new _ZohoServicesModel(), pipeline, requiredPage, sortData, true, "", projection)

            ResponseBody.pagename = PageName
            ResponseBody.formname = FormName
            ResponseBody.status = 200
            ResponseBody.message = Config.getResponsestatuscode()["200"]
            ResponseBody.data = resp.ResultData
            ResponseBody.currentpage = resp.currentpage
            ResponseBody.nextpage = resp.nextpage

            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

    // Success Zoho Property Sync
    async SuccessZohoPropertySync(req, res, next) {
        try {
            let userid = req.params.userid
            console.log("🚀 ~ file: ZohoPropertySync.js:39 ~ ZohoPropertySync ~ SuccessZohoPropertySync ~ userid:", userid)

            let code = req.query.code
            console.log("🚀 ~ file: ZohoPropertySync.js:39 ~ ZohoPropertySync ~ SuccessZohoPropertySync ~ req:", code)

            const ResponseBody = {}
            const ObjectId = IISMethods.getobjectid()

            if (code) {
                ResponseBody.status = 200
                ResponseBody.message = Config.getResponsestatuscode()["200"]
                ResponseBody.data = code
            } else {
                ResponseBody.status = 401
                ResponseBody.message = Config.getResponsestatuscode()["401"]
                ResponseBody.data = "Please re sync the data."
            }

            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }
}