import { IISMethods, Config, MainDB } from '../../../config/Init.js'
import _Employee from '../../../model/Onboarding/Employee.js'
import _TwoFARequestToken from "../../../model/2_Factor_Auth/2FARequestToken.js"
import _PersonChangeLog from "../../../model/PersonChangeLog.js"
import _Device from '../../../model/APP/Device.js'
import _Tokenexpiry from '../../../model/Tokenexpiry.js'

const TableName = 'tblemployee';
const PageName = 'employee';
const FormName = 'Employee';
const FltPageCollection = 'employee'

export default class EmployeeMaster {
    //List
    async ListEmployee(req, res, next) {

        try {
            var ResponseBody = {}
            var PaginationInfo = req.body.paginationinfo
            const ObjectId = IISMethods.getobjectid()

            const requiredPage = { pageno: PaginationInfo.pageno, skip: (PaginationInfo.pageno - 1) * PaginationInfo.pagelimit, pagelimit: PaginationInfo.pagelimit }
            var pipeline = []
            var sort = (Object.keys(PaginationInfo.sort).length !== 0 ? PaginationInfo.sort : { '_id': -1 })
            let projection = PaginationInfo.projection ? PaginationInfo.projection : {}
            let fieldorder = PaginationInfo.isfieldorder ? PaginationInfo.isfieldorder : 0

            pipeline = IISMethods.GetPipelineForFilter(PaginationInfo.filter)

            if (req.headers.propertyid) {
                pipeline.push({ $match: { 'property.propertyid': ObjectId(req.headers.propertyid) } })
            }

            const searchtext = req.body.searchtext || ""
            if (searchtext !== "") {
                pipeline.push(...IISMethods.GetGlobalSearchFilter(new _Employee(), searchtext))
            }
            pipeline.push({ $match: { isdelete: 0 } })

            const resp = await MainDB.getmenual(TableName, new _Employee(), pipeline, requiredPage, sort, fieldorder, "", projection)

            ResponseBody.pagename = PageName
            ResponseBody.formname = FormName
            ResponseBody.fltpagecollection = FltPageCollection
            ResponseBody.status = 200
            ResponseBody.message = Config.getResponsestatuscode()['200']
            ResponseBody.data = resp.ResultData
            ResponseBody.currentpage = resp.currentpage
            ResponseBody.nextpage = resp.nextpage
            ResponseBody.totaldocs = resp.totaldocs;
            ResponseBody.fieldorder = resp.fieldorderdata
            ResponseBody.formfieldorderdata = resp.formfieldorderdata

            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

    //Insert
    async InsertEmployee(req, res, next) {
        try {
            const ResponseBody = {}
            ResponseBody.status = 401
            ResponseBody.message = Config.getResponsestatuscode()["401"]

            let EmployeeMaster = req.body
             dummy = 10
            // req.body.qrcode = IISMethods.generateRandomString(24)
            // req.body.passcode = IISMethods.generateOTP(6)
            EmployeeMaster.password = IISMethods.GetMD5(req.body.password)
            EmployeeMaster.isactive = 1
            EmployeeMaster.sdelete = 0
            EmployeeMaster.recordinfo = {
                entryuid: req.headers.uid,
                entryby: req.headers.personname,
                entrydate: IISMethods.getdatetimestr(),
                timestamp: IISMethods.GetTimestamp(),
                isactive: 1
            }
            EmployeeMaster.personname = req.body.firstname + ' ' + req.body.lastname

            const resp = await MainDB.executedata('i', new _Employee(), TableName, EmployeeMaster)

            ResponseBody.status = resp.status
            ResponseBody.message = resp.message

            req.ResponseBody = ResponseBody; next()
        }
        catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err };
            next()
        }
    }


    //Update
    async UpdateEmployee(req, res, next) {
        try {
            const ResponseBody = {}
            ResponseBody.status = 401
            ResponseBody.message = Config.getResponsestatuscode()["401"]

            delete req.body.password

            const ObjectId = IISMethods.getobjectid();
            const pipelinedata = [{ $match: { '_id': ObjectId(req.body._id) } }]
            const record = await MainDB.getmenual(TableName, new _Employee(), pipelinedata)
            if (record.ResultData.length > 0) {
                const RecordInfo = {}
                RecordInfo.entryuid = record.ResultData[0].recordinfo.entryuid
                RecordInfo.entryby = record.ResultData[0].recordinfo.entryby
                RecordInfo.entrydate = record.ResultData[0].recordinfo.entrydate

                RecordInfo.updateuid = req.headers.uid
                RecordInfo.updateby = req.headers.personname
                RecordInfo.updatedate = IISMethods.getdatetimestr()

                let EmployeeMaster = req.body
                EmployeeMaster.personname = req.body.firstname + ' ' + req.body.lastname
                EmployeeMaster.recordinfo = RecordInfo

                if (req.body.password) {
                    EmployeeMaster.password = record.ResultData[0].password
                }

                let isupdate = 1

                if (req.headers.uid == record.ResultData[0]?._id?.toString() && (req.body.isactive == 0 || req.body.isterminated == 1)) {
                    isupdate = 0
                }

                if (isupdate == 1) {
                    //Dependency Check
                    const employeeObjModel = await MainDB.createmodel('tblemployee', new _Employee())

                    var dependency = [
                        [employeeObjModel['objModel'], { 'reportingto': req.body._id }, "Employee"],
                    ]

                    const resp = await MainDB.executedata('u', new _Employee(), TableName, EmployeeMaster,true,dependency)

                    if (resp.status === 200) {

                        if (req.body.isactive == 0 || req.body.isterminated == 1) {
                            // Remove Token
                            const delTokenPipeline = { uid: req.body._id }
                            await MainDB.DeleteMany("tblexpiry", new _Tokenexpiry(), delTokenPipeline)
                        }

                        // Update Dependency
                        const updatePipeline = [
                            { reportingtoid: req.body._id },
                            { $set: { reportingto: req.body.reportingto, } }
                        ]
                        const updateModelObj = {
                            tblemployee: new _Employee()
                        }

                        const tempArray = []
                        for (const key in updateModelObj) {
                            tempArray.push(MainDB.UpdateMany(key, updateModelObj[key], updatePipeline))
                        }
                        await Promise.all(tempArray)
                    }

                    ResponseBody.data = resp.data
                    ResponseBody.status = resp.status
                    ResponseBody.message = resp.message
                } else {
                    ResponseBody.status = 400
                    ResponseBody.message = req.body.isterminated == 1 ? Config.getErrmsg()["selfterminated"] : Config.getErrmsg()["selfdeactive"]
                }
        } else {
            ResponseBody.status = 200
            ResponseBody.message = Config.getErrmsg()['notexist']
        }

        req.ResponseBody = ResponseBody; next()
    }
    catch(err) {

        req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }; next()
    }
}


    //Delete
    async DeleteEmployee(req, res, next) {
        try {
            const ResponseBody = {}
            ResponseBody.status = 401
            ResponseBody.message = Config.getResponsestatuscode()["401"]

            const ObjectId = IISMethods.getobjectid();
            const record = await MainDB.FindOne(TableName, new _Employee(), { _id: new ObjectId(req.body._id), isdelete: 0 })
            if (record) {
                const pipelinedata = [{ _id: new ObjectId(req.body._id) }, { $set: { isdelete: 1, isactive: 0 } }]
                const resp = await MainDB.Update(TableName, new _Employee(), pipelinedata)
                ResponseBody.status = resp.status
                ResponseBody.message = Config.getErrmsg()['delete']
            } else {
                ResponseBody.status = 200
                ResponseBody.message = Config.getErrmsg()['notexist']
            }

            req.ResponseBody = ResponseBody; next()
        }
        catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }; next()
        }
    }



    //List
    async ListReportingPerson(req, res, next) {
        try {
            const ResponseBody = {}
            ResponseBody.status = 401
            ResponseBody.message = Config.getResponsestatuscode()["401"]
            const ObjectId = IISMethods.getobjectid()

            var PaginationInfo = req.body.paginationinfo
            // const project = req.body.paginationinfo.project ? req.body.paginationinfo.project : {}
            const projection = req.body.paginationinfo.projection ? req.body.paginationinfo.projection : {}

            const requiredPage = {
                pageno: PaginationInfo.pageno,
                skip: (PaginationInfo.pageno - 1) * PaginationInfo.pagelimit,
                pagelimit: PaginationInfo.pagelimit
            }
            var pipeline = []
            var sort = Object.keys(PaginationInfo.sort).length !== 0 ? PaginationInfo.sort : { _id: -1 }

            var PaginationInfoFilter = Object.assign(req.body.paginationinfo.filter, { isdelete: 0, isterminated: 0 })
            if (Object.keys(PaginationInfoFilter).length) {
                pipeline = IISMethods.GetPipelineForAndFilter(PaginationInfoFilter)
            }

            const personid = req.body.personid ? req.body.personid : req.headers.uid
            const personPipeline = [{ $match: { _id: ObjectId(personid) } }]
            const personResp = await MainDB.getmenual(TableName, new _Employee(), personPipeline)
            const personData = personResp.ResultData[0]

            const reportingpersonIds = personData.reportingtos?.map((obj) => obj.reportingtoid.toString())
            if (Array.isArray(reportingpersonIds) && reportingpersonIds.length) {
                const allReporterIds = await Promise.all(reportingpersonIds.map(obj => MainDB.getAllReporter(obj)));
                const reportingIds = allReporterIds.flat().filter(Boolean).map(ele => ObjectId(ele._id));
                pipeline.push({
                    $match: {
                        _id: { $in: reportingIds }
                    }
                })
            }

            const resp = await MainDB.getmenual(TableName, new _Employee(), pipeline, requiredPage, sort, true, "", projection)


            ResponseBody.pagename = PageName
            ResponseBody.formname = FormName
            ResponseBody.fltpagecollection = FltPageCollection
            ResponseBody.status = 200
            ResponseBody.message = Config.getResponsestatuscode()["200"]
            ResponseBody.count = resp.ResultData.length
            ResponseBody.data = resp.ResultData
            ResponseBody.currentpage = resp.currentpage
            ResponseBody.nextpage = resp.nextpage

            const StaffReg = new _Employee()
            if (resp.fieldorderdata) {
                ResponseBody.fieldorder = resp.fieldorderdata
            } else {
                ResponseBody.fieldorder = StaffReg.getFieldOrder()
            }

            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }


}

