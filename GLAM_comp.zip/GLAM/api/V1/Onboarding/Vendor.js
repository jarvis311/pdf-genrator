import { IISMethods, MainDB, Config } from "../../../config/Init.js"
import _Vendor from "../../../model/Onboarding/Vendor.js"
import _VendorStaff from '../../../model/Onboarding/VendorStaff.js'

const TableName = "tblvendormaster"
const PageName = "vendor"
const FormName = "Vendor Master"
const FltPageCollection = "vendormaster"

export default class VendorMaster {
    // List Vendor

    async ListVendorMaster(req, res, next) {
        try {
            var ResponseBody = {}
            var PaginationInfo = req.body.paginationinfo
            const ObjectId = IISMethods.getobjectid()
            const requiredPage = { pageno: PaginationInfo.pageno, skip: (PaginationInfo.pageno - 1) * PaginationInfo.pagelimit, pagelimit: PaginationInfo.pagelimit }
            var pipeline = []
            var sort = (Object.keys(PaginationInfo.sort).length !== 0 ? PaginationInfo.sort : { '_id': -1 })
            let projection = PaginationInfo.projection ? PaginationInfo.projection : {}
            let fieldorder = req.body.paginationinfo.isfieldorder ? req.body.paginationinfo.isfieldorder : 0

            pipeline = IISMethods.GetPipelineForFilter(PaginationInfo.filter)
            //only active records
            pipeline.push({ $match: { isdelete: 0 } })

            const searchtext = req.body.searchtext || ""
            if (searchtext !== "") {
                pipeline.push(...IISMethods.GetGlobalSearchFilter(new _Vendor(), searchtext))
            }

            if(req.headers.propertyid){
                pipeline.push({$match:{propertyid:ObjectId(req.headers.propertyid)}})
            }

            const resp = await MainDB.getmenual(TableName, new _Vendor(), pipeline, requiredPage, sort, fieldorder, "", projection)

            ResponseBody.pagename = PageName
            ResponseBody.formname = FormName
            ResponseBody.fltpagecollection = FltPageCollection
            ResponseBody.status = 200
            ResponseBody.message = Config.getResponsestatuscode()['200']
            ResponseBody.data = resp.ResultData
            ResponseBody.currentpage = resp.currentpage
            ResponseBody.nextpage = resp.nextpage
            ResponseBody.fieldorder = resp.fieldorderdata
            ResponseBody.formfieldorderdata = resp.formfieldorderdata
            ResponseBody.totaldocs = resp.totaldocs

            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

    // Insert Vendor
    async InsertVendorMaster(req, res, next) {
        try {
            req.body.personname = req.body.firstname + ' ' + req.body.lastname
            const ResponseBody = {}

            req.body.propertyid = req.headers.propertyid
            req.body.property = req.headers.property

            const resp = await MainDB.executedata("i", new _Vendor(), TableName, req.body)

            if (resp.status == 200) {
                const vendrostaff = {
                    vendorcompanyid: resp.data?._id,
                    vendorcompany: resp.data?.companyname,
                    firstname: resp.data?.firstname,
                    lastname: resp.data?.lastname,
                    roleid: Config.ownerroleid,
                    role: Config.ownerrole,
                    email:resp.data?.email,
                    contactno: resp.data?.contactno,
                    contactno_countrycode:resp.data?.contactno_countrycode,
                    alternatecontact: resp.data?.alternatecontact,
                    alternatecontact_countrycode:resp.data?.alternatecontact_countrycode,
                    addressline1: resp.data?.addressline1,
                    addressline2: resp.data?.addressline2,
                    postalcode: resp.data?.pincode,
                    stateid: resp.data?.stateid,
                    state:  resp.data?.state,
                    cityid: resp.data?.cityid,
                    city: resp.data?.city,
                    documents: resp.data?.documents,
                    propertyid: resp.data?.propertyid,
                    property: resp.data?.property,
                    staffname: resp.data?.personname
                  }
                await MainDB.executedata("i", new _VendorStaff(), "tblvendorstaffmaster", vendrostaff)
            }

            ResponseBody.status = resp.status
            ResponseBody.message = resp.message

            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

    // Update Vendor
    async UpdateVendorMaster(req, res, next) {
        try {

            const ObjectId = IISMethods.getobjectid()
            var ResponseBody = {}

            const pipeline = [{ $match: { '_id': ObjectId(req.body._id) } }]
            const record = await MainDB.getmenual(TableName, new _Vendor(), pipeline)

            var RecordInfo = record.ResultData[0].recordinfo
            RecordInfo.updateuid = req.headers.uid
            RecordInfo.updateby = req.headers.personname
            RecordInfo.updatedate = IISMethods.getdatetimeisostr()
            req.body.recordinfo = RecordInfo

            //Dependency Check
            const vendorObjModel = await MainDB.createmodel('tblvendor', new _Vendor())

            var dependency = [
                [vendorObjModel['objModel'], { vendorcompanyid: req.body._id }, "Customer"]
            ]

            const resp = await MainDB.executedata('u', new _Vendor(), TableName, req.body, true, dependency)

            if (resp.status === 200) {
                // Update Dependency
                const updatePipeline = [
                    { vendorcompanyid: req.body._id },
                    { $set: { vendorcompany: req.body.companyname, } }
                ]
                const updateModelObj = {
                    tblvendorstaffmaster: new _VendorStaff()
                }
                
                const tempArray = []
                for (const key in updateModelObj) {
                    tempArray.push(MainDB.UpdateMany(key, updateModelObj[key], updatePipeline))
                }
                await Promise.all(tempArray)
            }

            var ResponseBody = {}
            ResponseBody.status = resp.status
            ResponseBody.data = resp.data
            ResponseBody.message = resp.message

            req.ResponseBody = ResponseBody
            next()
        }
        catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

    // Delete Vendor
    async DeleteVendorMaster(req, res, next) {
        try {
            const ResponseBody = {}

            const ObjectId = IISMethods.getobjectid();
            const vendorstaff = await MainDB.FindOne("tblvendorstaffmaster", new _VendorStaff(), { vendorcompanyid: new ObjectId(req.body._id) })

            if(!vendorstaff.length){
                const record = await MainDB.FindOne(TableName, new _Vendor(), { _id: new ObjectId(req.body._id), isdelete: 0 })
                if (record) {
                    const pipelinedata = [{ _id: new ObjectId(req.body._id) }, { $set: { isdelete: 1 } }]
                    const resp = await MainDB.Update(TableName, new _Vendor(), pipelinedata)
                    ResponseBody.status = resp.status
                    ResponseBody.message = `Vendor ${Config.getErrmsg()['delete']}`
                } else {
                    ResponseBody.status = 200
                    ResponseBody.message = Config.getErrmsg()['notexist']
                }
            }else{
                ResponseBody.status = 200
                ResponseBody.message = `${Config.getErrmsg()['inuse']} Vendor`
            }

            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

}
