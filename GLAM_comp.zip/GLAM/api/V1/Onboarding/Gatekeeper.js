import { IISMethods, Config, MainDB } from '../../../config/Init.js'
import _GateKeeper from '../../../model/Onboarding/GateKeeper.js'
import _TwoFARequestToken from "../../../model/2_Factor_Auth/2FARequestToken.js"
import _PersonChangeLog from "../../../model/PersonChangeLog.js"
import _Device from '../../../model/APP/Device.js'
import _VisitorOTP from '../../../model/VisitorOtp.js'
import { Propertycommon, PropertyGate } from "../../../model/masters/Property/PropertyMaster.js"


const TableName = 'tblgatekeeper'
const PageName = 'gatekeeper'
const FormName = 'GateKeeper'
const FltPageCollection = 'tblgatekeeper'

export default class GateKepper {
    //List Gatekeeper
    async ListGateKeeper(req, res, next) {
        try {
            const ResponseBody = {}
            ResponseBody.status = 401
            ResponseBody.message = Config.getResponsestatuscode()["401"]

            var PaginationInfo = req.body.paginationinfo
            const projection = PaginationInfo.projection
            const ObjectId = IISMethods.getobjectid()

            const requiredPage = { pageno: PaginationInfo.pageno, skip: (PaginationInfo.pageno - 1) * PaginationInfo.pagelimit, pagelimit: PaginationInfo.pagelimit }
            var pipeline = []
            var sort = (Object.keys(PaginationInfo.sort).length !== 0 ? PaginationInfo.sort : { _id: -1 })

            let fieldorder = req.body.paginationinfo.isfieldorder ? req.body.paginationinfo.isfieldorder : 0

            pipeline = IISMethods.GetPipelineForFilter(PaginationInfo.filter)

            if (req.headers.propertyid) {
                pipeline.push({ $match: { propertyid: ObjectId(req.headers.propertyid), isdelete: 0 } })
            }

            const searchtext = req.body.searchtext || ""
            if (searchtext !== "") {
                pipeline.push(...IISMethods.GetGlobalSearchFilter(new _GateKeeper(), searchtext))
            }

            if (req.body.assignlist == 1) {
                pipeline.push({ $match: { _id: { $ne: ObjectId(req.headers.uid) } } })
            }

            const resp = await MainDB.getmenual(TableName, new _GateKeeper(), pipeline, requiredPage, sort, fieldorder, "", projection)

            ResponseBody.pagename = PageName
            ResponseBody.formname = FormName
            ResponseBody.fltpagecollection = FltPageCollection
            ResponseBody.status = 200
            ResponseBody.message = Config.getResponsestatuscode()['200']
            ResponseBody.data = resp.ResultData
            ResponseBody.currentpage = resp.currentpage
            ResponseBody.nextpage = resp.nextpage
            ResponseBody.formfieldorderdata = resp.formfieldorderdata
            ResponseBody.totaldocs = resp.totaldocs

            const gatekeeperRole = new _GateKeeper()
            if (resp.fieldorderdata) {
                ResponseBody.fieldorder = resp.fieldorderdata
            }
            else {
                ResponseBody.fieldorder = gatekeeperRole.getFieldOrder()
            }

            req.ResponseBody = ResponseBody;
            next()
        }
        catch (err) {


            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }; next()
        }
    }

    //Insert gatekeepr
    async InsertGateKeeper(req, res, next) {
        try {
            const ResponseBody = {}
            const ObjectId = IISMethods.getobjectid();

            ResponseBody.status = 401
            ResponseBody.message = Config.getResponsestatuscode()["401"]

            let Gatekeeper = req.body
            Gatekeeper.password = IISMethods.GetMD5(req.body.password)
            Gatekeeper.isactive = 1
            Gatekeeper.sdelete = 0
            Gatekeeper.recordinfo = {
                entryuid: req.headers.uid,
                entryby: req.headers.personname,
                entrydate: IISMethods.getdatetimestr(),
                timestamp: IISMethods.GetTimestamp(),
                isactive: 1
            }
            Gatekeeper.personname = req.body.firstname + ' ' + req.body.lastname

            if (req.body.gate?.length == 0) {
                const pipeline = [{ $match: { propertyid: ObjectId(req.body.propertyid) } }]
                const resp = await MainDB.getmenual("tblpropertygate", new PropertyGate(), pipeline)

                for (let obj of resp.ResultData) {
                    Gatekeeper.gate.push({ gateid: obj._id, gate: obj.gatename })
                }
            }

            const resp = await MainDB.executedata('i', new _GateKeeper(), TableName, Gatekeeper)

            ResponseBody.status = resp.status
            ResponseBody.message = resp.message

            req.ResponseBody = ResponseBody; next()
        }
        catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err };
            next()
        }
    }


    //Update gatekeeper
    async UpdateGateKeeper(req, res, next) {
        try {
            const ResponseBody = {}
            ResponseBody.status = 401
            ResponseBody.message = Config.getResponsestatuscode()["401"]

            try {
                const ObjectId = IISMethods.getobjectid();
                const pipelinedata = [{ $match: { '_id': ObjectId(req.body._id) } }]
                const record = await MainDB.getmenual(TableName, new _GateKeeper(), pipelinedata)
                if (record.ResultData.length > 0) {
                    const RecordInfo = {}
                    RecordInfo.entryuid = record.ResultData[0].recordinfo.entryuid
                    RecordInfo.entryby = record.ResultData[0].recordinfo.entryby
                    RecordInfo.entrydate = record.ResultData[0].recordinfo.entrydate

                    RecordInfo.updateuid = req.headers.uid
                    RecordInfo.updateby = req.headers.personname
                    RecordInfo.updatedate = IISMethods.getdatetimestr()

                    let Gatekeeper = req.body
                    Gatekeeper.personname = req.body.firstname + ' ' + req.body.lastname
                    Gatekeeper.recordinfo = RecordInfo

                    if (req.body.password) {
                        Gatekeeper.password = record.ResultData[0].password
                    }

                    const resp = await MainDB.executedata('u', new _GateKeeper(), TableName, Gatekeeper)

                    ResponseBody.data = resp.data
                    ResponseBody.status = resp.status
                    ResponseBody.message = resp.message
                } else {
                    ResponseBody.status = 200
                    ResponseBody.message = Config.getErrmsg()['notexist']
                }
            }
            catch (err) {

            }
            req.ResponseBody = ResponseBody; next()
        }
        catch (err) {

            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }; next()
        }
    }


    //Delete gatekeeper
    async DeleteGateKeeper(req, res, next) {
        try {
            const ResponseBody = {}
            ResponseBody.status = 401
            ResponseBody.message = Config.getResponsestatuscode()["401"]

            const ObjectId = IISMethods.getobjectid();
            const record = await MainDB.FindOne(TableName, new _GateKeeper(), { _id: new ObjectId(req.body._id), isdelete: 0 })
            if (record) {
                const pipelinedata = [{ _id: new ObjectId(req.body._id) }, { $set: { isdelete: 1 } }]
                const resp = await MainDB.Update(TableName, new _GateKeeper(), pipelinedata)
                ResponseBody.status = resp.status
                ResponseBody.message = `Gatekeeper ${Config.getErrmsg()['delete']}`
            } else {
                ResponseBody.status = 200
                ResponseBody.message = Config.getErrmsg()['notexist']
            }

            req.ResponseBody = ResponseBody; next()
        }
        catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }; next()
        }
    }


}

