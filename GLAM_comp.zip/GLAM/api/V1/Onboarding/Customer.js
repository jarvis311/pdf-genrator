import { IISMethods, Config, MainDB, FieldConfig } from '../../../config/Init.js'
import _Customer from '../../../model/Onboarding/Customer.js'
import _TwoFARequestToken from "../../../model/2_Factor_Auth/2FARequestToken.js"
import _PersonChangeLog from "../../../model/PersonChangeLog.js"
import _Device from '../../../model/APP/Device.js'
import _CustomerOTP from "../../../model/CustomerOTP.js"
import _Approve from '../../../model/Approve.js'

const TableName = 'tblcustomer'
const PageName = 'customer'
const FormName = 'Customer'
const FltPageCollection = 'customer'

export default class CustomerMaster {
    //List customer
    async ListCustomer(req, res, next) {
        try {
            const ResponseBody = {}
            ResponseBody.status = 401
            ResponseBody.message = Config.getResponsestatuscode()["401"]
            const ObjectId = IISMethods.getobjectid();

            var PaginationInfo = req.body.paginationinfo
            const projection = PaginationInfo.projection

            const requiredPage = { pageno: PaginationInfo.pageno, skip: (PaginationInfo.pageno - 1) * PaginationInfo.pagelimit, pagelimit: PaginationInfo.pagelimit }
            var pipeline = []
            var sort = (Object.keys(PaginationInfo.sort).length !== 0 ? PaginationInfo.sort : { _id: -1 })

            pipeline = IISMethods.GetPipelineForFilter(PaginationInfo.filter)
            let fieldorder = req.body.paginationinfo.isfieldorder ? req.body.paginationinfo.isfieldorder : 0

            if (req.headers.propertyid) {
                pipeline.push({ $match: { 'ownedproperties.propertyid': ObjectId(req.headers.propertyid), isdelete: 0 } })
            }

            pipeline.push({ $match: { isdelete: 0 } })

            const searchtext = req.body.searchtext || ""
            if (searchtext !== "") {
                pipeline.push(...IISMethods.GetGlobalSearchFilter(new _Customer(), searchtext))
            }

            const customerMaster = new _Customer()

            const resp = await MainDB.getmenual(TableName, new _Customer(), pipeline, requiredPage, sort, fieldorder, "", projection)
            ResponseBody.pagename = PageName
            ResponseBody.formname = FormName
            ResponseBody.fltpagecollection = FltPageCollection
            ResponseBody.status = 200
            ResponseBody.message = Config.getResponsestatuscode()['200']
            ResponseBody.data = resp.ResultData
            ResponseBody.currentpage = resp.currentpage
            ResponseBody.nextpage = resp.nextpage
            ResponseBody.totaldocs = resp.totaldocs;
            ResponseBody.fieldorder = resp.fieldorderdata
            ResponseBody.formfieldorderdata = resp.formfieldorderdata

            if (PaginationInfo.filter && PaginationInfo.filter.customertype == 2) {
                ResponseBody.fieldorder = customerMaster.getTenantFieldOrder();
                ResponseBody.formfieldorderdata = customerMaster.getTenantFormFieldOrder();
            } else if (PaginationInfo.filter.customertype == 1) {
                ResponseBody.fieldorder = customerMaster.getTenantFieldOrder();
                ResponseBody.formfieldorderdata = customerMaster.getFamilyMemberFormFieldOrder();
            }

            req.ResponseBody = ResponseBody
            next()
        }
        catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }; 
            next()
        }
    }

    //Insert
    async InsertCustomer(req, res, next) {
        try {
            const ResponseBody = {}
            ResponseBody.status = 401
            ResponseBody.message = Config.getResponsestatuscode()["401"]
            const ObjectId = IISMethods.getobjectid();

            let Customer = req.body
            Customer.isactive = 1
            Customer.isdelete = 0
            Customer.recordinfo = {
                entryuid: req.headers.uid,
                entryby: req.headers.personname,
                entrydate: IISMethods.getdatetimestr(),
                timestamp: IISMethods.GetTimestamp(),
                isactive: 1
            }
            Customer.personname = req.body.firstname + ' ' + req.body.lastname

            const customerPipeline = [{ $match: {} }, { $sort: { _id: -1 } }, { $limit: 10 }]
            const customerResp = await MainDB.getmenual("tblcustomer", new _Customer(), customerPipeline)

            const unitids = []
            const customerids = []

            if(!req.body.ownedproperties){
                const personPipeline = { _id: req.body.customerid }
                const person = await MainDB.FindOne("tblcustomer", new _Customer(), personPipeline)
                req.body.ownedproperties = person.ownedproperties
            }

            // if(!req.body.ownedproperties){
            //     // const unitwisecustomer = customerResp.ResultData.filter(obj => obj._idg())))
            //     // const unitwisecustomer = customerResp.ResultData.flatMap(doc => doc.ownedproperties.filter(m =>unitids.includes(m.unitid.toString())))
            //     req.body.ownedproperties = person.ownedproperties
            // }

            for (let Obj of req.body?.ownedproperties) {
                unitids.push(ObjectId(Obj.unitid))
                customerids.push(ObjectId(Obj.customerid))
            }

            // const customerPipeline = [
            //     {
            //         $match: {
            //             'ownedproperties.unitid': { $in: unitid },
            //             customertype: req.body.customertype
            //         }
            //     }
            // ]
            // const customerResp = await MainDB.getmenual("tblcustomer", new _Customer(), customerPipeline)

            // if(!customerResp.ResultData.length){
                if (req.body.customertype == 1) {
                    const personPipeline = { _id: req.body.customerid }
                    const person = await MainDB.FindOne("tblcustomer", new _Customer(), personPipeline)

                    for(let obj of person.ownedproperties){
                        obj.customerid = req.body.customerid
                        obj.customer = req.body.customer
                    }
                    Customer.ownedproperties = person.ownedproperties
                    Customer.cityid = person.cityid
                    Customer.nationalityid = person.nationalityid
                    Customer.addressline1 = person.addressline1
                    Customer.addressline2 = person.addressline2
                    Customer.countryid = person.countryid
                    Customer.stateid = person.stateid
                    Customer.pincode = person.pincode
                    Customer.country = person.country
                    Customer.state = person.state
                    Customer.city = person.city
                    Customer.pincodeid = person.pincodeid
                    Customer.nationality = person.nationality
    
                }
    
                const resp = await MainDB.executedata('i', new _Customer(), TableName, Customer)
              
          
                if (resp.status == 200) {
                    if (req.body.customertype == 2) {
                       
                        const tenant = [{
                            tenantid: resp.data._id,
                            tenant: req.body.personname,
                        }]
    
                        // Update key details
                        const keyPipeline = [
                            { _id: { $in: customerids } },
                            { $set: { tenant: tenant } },
                        ];
                        const d = await MainDB.UpdateMany("tblcustomer", new _Customer(), keyPipeline);
                    }
                } else if (req.body.customertype == 1) {
                    const familymember = [{
                        memberid: resp.data._id,
                        firstname: req.body.firstname,
                        lastname: req.body.lastname,
                        personname: req.body.personname,
                        contact: req.body.contact,
                        dateofbirth: req.body.dateofbirth,
                        contact_countrycode: req.body.contact_countrycode,
                        personemail: req.body.personemail,
                        relationid: req.body.relationid,
                        relation: req.body.relation,
                        genderid: req.body.genderid,
                        gender: req.body.gender,
                        profilepic: req.body.profilepic,
                        iskids: req.body.iskids,
                    }]
                    const updatePipeline = [{ _id: req.body.customerid }, { $push: { familymember: familymember } }]
                    await MainDB.Update("tblcustomer", new _Customer(), updatePipeline)
                }
    
                ResponseBody.status = resp.status

                if(ResponseBody.status == 200){
                    if(req.body.customertype == 0){
                        ResponseBody.message = "Customer inserted successfully."
                    }else if(req.body.customertype == 1){
                        ResponseBody.message = "FamilyMember inserted successfully."
                    }else if(req.body.customertype == 2){
                        ResponseBody.message = "Tenant inserted successfully." 
                    }
                }else{
                    ResponseBody.message = resp.message
                }
                           
            // }else{
            //     ResponseBody.status = 400
            //     ResponseBody.message = "The unit is already assigned to a different customer."
            // }
      
            req.ResponseBody = ResponseBody;
            next()
        }
        catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }; next()
        }
    }


    //Update
    async UpdateCustomer(req, res, next) {
        try {
            const ResponseBody = {}
            ResponseBody.status = 401
            ResponseBody.message = Config.getResponsestatuscode()["401"]

            try {
                const ObjectId = IISMethods.getobjectid();
                const pipelinedata = [{ $match: { '_id': ObjectId(req.body._id) } }]
                const record = await MainDB.getmenual(TableName, new _Customer(), pipelinedata)
                if (record.ResultData.length > 0) {
                    const RecordInfo = {}
                    RecordInfo.entryuid = record.ResultData[0].recordinfo.entryuid
                    RecordInfo.entryby = record.ResultData[0].recordinfo.entryby
                    RecordInfo.entrydate = record.ResultData[0].recordinfo.entrydate

                    RecordInfo.updateuid = req.headers.uid
                    RecordInfo.updateby = req.headers.personname
                    RecordInfo.updatedate = IISMethods.getdatetimestr()

                    delete req.body.password

                    let Customer = req.body
                    Customer.personname = req.body.firstname + ' ' + req.body.lastname
                    Customer.recordinfo = RecordInfo

                    const resp = await MainDB.executedata('u', new _Customer(), TableName, Customer)
   
                    if (resp.status == 200) {
                        if (req.body.customertype == 2) {
                            const customerids = []
                            for (let Obj of req.body.ownedproperties) {
                                customerids.push(Obj.customerid)
                            }
                            const tenant = [{
                                tenantid: resp.data._id,
                                tenant: req.body.personname,
                            }]

                            // Update key details
                            const keyPipeline = [
                                { _id: { $in: customerids } },
                                { $set: { tenant: tenant } },
                            ];
                            const d = await MainDB.UpdateMany("tblcustomer", new _Customer(), keyPipeline);
                        }
                    } else if (req.body.customertype == 1) {
                        const familymember = [{
                            memberid: resp.data._id,
                            firstname: req.body.firstname,
                            lastname: req.body.lastname,
                            personname: req.body.personname,
                            contact: req.body.contact,
                            dateofbirth: req.body.dateofbirth,
                            contact_countrycode: req.body.contact_countrycode,
                            personemail: req.body.personemail,
                            relationid: req.body.relationid,
                            relation: req.body.relation,
                            genderid: req.body.genderid,
                            gender: req.body.gender,
                            profilepic: req.body.profilepic,
                            iskids: req.body.iskids,
                        }]
                        const updatePipeline = [{ _id: req.body.customerid }, { $push: { familymember: familymember } }]
                        await MainDB.Update("tblcustomer", new _Customer(), updatePipeline)
                    }else if(req.body.customertype == 0){
                        const updatePipeline = [{ 'ownedproperties.customerid': req.body.customerid }, {"ownedproperties.$.customer":req.body.personname }]
                        await MainDB.Update("tblcustomer", new _Customer(), updatePipeline)
                    }


                    ResponseBody.data = resp.data
                    ResponseBody.status = resp.status

                    ResponseBody.status = resp.status

                    if(ResponseBody.status == 200){
                        if(req.body.customertype == 0){
                            ResponseBody.message = "Customer updated successfully."
                        }else if(req.body.customertype == 1){
                            ResponseBody.message = "FamilyMember updated successfully."
                        }else if(req.body.customertype == 2){
                            ResponseBody.message = "Tenant updated successfully." 
                        }
                    }else{
                        ResponseBody.message = resp.message
                    }
                    ResponseBody.message = resp.message
                } else {
                    ResponseBody.status = 200
                    ResponseBody.message = Config.getErrmsg()['notexist']
                }
            }
            catch (err) {

            }
            req.ResponseBody = ResponseBody; next()
        }
        catch (err) {

            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }; next()
        }
    }


    //Delete
    async DeleteCustomer(req, res, next) {
        try {
            const ResponseBody = {}
            ResponseBody.status = 401
            ResponseBody.message = Config.getResponsestatuscode()["401"]

            const ObjectId = IISMethods.getobjectid();
            const record = await MainDB.FindOne(TableName, new _Customer(), { _id: new ObjectId(req.body._id), isdelete: 0 })
            if (record) {
                const pipelinedata = [{ _id: new ObjectId(req.body._id) }, { $set: { isdelete: 1 } }]
                const resp = await MainDB.Update(TableName, new _Customer(), pipelinedata)
                ResponseBody.status = resp.status
                ResponseBody.message = Config.getErrmsg()['delete']
            } else {
                ResponseBody.status = 200
                ResponseBody.message = Config.getErrmsg()['notexist']
            }

            req.ResponseBody = ResponseBody; next()
        }
        catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }; next()
        }
    }


    //List
    async ListCustomerUnit(req, res, next) {
        try {
            const ResponseBody = {}
            ResponseBody.status = 401
            ResponseBody.message = Config.getResponsestatuscode()["401"]


            var PaginationInfo = req.body.paginationinfo
            const projection = PaginationInfo.projection

            const requiredPage = { pageno: PaginationInfo.pageno, skip: (PaginationInfo.pageno - 1) * PaginationInfo.pagelimit, pagelimit: PaginationInfo.pagelimit }
            var pipeline = []
            var sort = (Object.keys(PaginationInfo.sort).length !== 0 ? PaginationInfo.sort : { _id: -1 })

            // var PaginationInfoFilter = Object.assign(req.body.paginationinfo.filter)

            if (Object.keys(PaginationInfo.filter).length) {
                pipeline = IISMethods.GetPipelineForFilter(PaginationInfo.filter)
            }
            const searchtext = req.body.searchtext || ""
            if (searchtext !== "") {
                pipeline.push(...IISMethods.GetGlobalSearchFilter(new _Customer(), searchtext))
            }

            const resp = await MainDB.getmenual(TableName, new _Customer(), pipeline, requiredPage, sort, true, "", projection)

            ResponseBody.pagename = PageName
            ResponseBody.formname = FormName
            ResponseBody.fltpagecollection = FltPageCollection
            ResponseBody.status = 200
            ResponseBody.message = Config.getResponsestatuscode()['200']
            ResponseBody.data = resp.ResultData[0]?.ownedproperties
            ResponseBody.currentpage = resp.currentpage
            ResponseBody.nextpage = resp.nextpage
            ResponseBody.totaldocs = resp.totaldocs;
            ResponseBody.fieldorder = resp.fieldorderdata
            ResponseBody.formfieldorderdata = resp.formfieldorderdata


            req.ResponseBody = ResponseBody; next()
        }
        catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }; next()
        }
    }



    //List
    async ListCommittee(req, res, next) {
        try {
            const ResponseBody = {}
            ResponseBody.status = 401
            ResponseBody.message = Config.getResponsestatuscode()["401"]


            var PaginationInfo = req.body.paginationinfo
            const projection = PaginationInfo.projection

            const requiredPage = { pageno: PaginationInfo.pageno, skip: (PaginationInfo.pageno - 1) * PaginationInfo.pagelimit, pagelimit: PaginationInfo.pagelimit }
            var pipeline = []
            var sort = (Object.keys(PaginationInfo.sort).length !== 0 ? PaginationInfo.sort : { _id: -1 })

            // var PaginationInfoFilter = Object.assign(req.body.paginationinfo.filter)

            if (Object.keys(PaginationInfo.filter).length) {
                pipeline = IISMethods.GetPipelineForFilter(PaginationInfo.filter)
            }
            const searchtext = req.body.searchtext || ""
            if (searchtext !== "") {
                pipeline.push(...IISMethods.GetGlobalSearchFilter(new _Customer(), searchtext))
            }


            pipeline.push(
                {
                    $unwind: "$unit"
                },
                {
                    $group: {
                        _id: "$committeemembersid",
                        committeemember: { $first: "$committeemembers" },
                        unit: { $first: "$unit.unit" },
                        wing: { $first: "$unit.wing" },
                        floor: { $first: "$unit.floor" },
                        customer: { $push: "$$ROOT" }
                    }
                }
            )


            const resp = await MainDB.getmenual(TableName, new _Customer(), pipeline, requiredPage, sort, true, "", projection)

            ResponseBody.pagename = PageName
            ResponseBody.formname = FormName
            ResponseBody.fltpagecollection = FltPageCollection
            ResponseBody.status = 200
            ResponseBody.message = Config.getResponsestatuscode()['200']
            ResponseBody.data = resp.ResultData
            ResponseBody.currentpage = resp.currentpage
            ResponseBody.nextpage = resp.nextpage
            ResponseBody.totaldocs = resp.totaldocs;
            ResponseBody.fieldorder = resp.fieldorderdata
            ResponseBody.formfieldorderdata = resp.formfieldorderdata

            req.ResponseBody = ResponseBody; next()
        }
        catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }; next()
        }
    }


    async ListResidents(req, res, next) {
        try {
            const ResponseBody = {}
            ResponseBody.status = 401
            ResponseBody.message = Config.getResponsestatuscode()["401"]


            var PaginationInfo = req.body.paginationinfo
            const projection = PaginationInfo.projection

            const requiredPage = { pageno: PaginationInfo.pageno, skip: (PaginationInfo.pageno - 1) * PaginationInfo.pagelimit, pagelimit: PaginationInfo.pagelimit }
            var pipeline = []
            var sort = (Object.keys(PaginationInfo.sort).length !== 0 ? PaginationInfo.sort : { _id: -1 })

            // var PaginationInfoFilter = Object.assign(req.body.paginationinfo.filter)

            if (Object.keys(PaginationInfo.filter).length) {
                pipeline = IISMethods.GetPipelineForFilter(PaginationInfo.filter)
            }
            const searchtext = req.body.searchtext || ""
            if (searchtext !== "") {
                pipeline.push(...IISMethods.GetGlobalSearchFilter(new _Customer(), searchtext))
            }


            pipeline.push(
                {
                    $unwind: "$unit"
                },
                {
                    $group: {
                        _id: "$unit.unitid",
                        unit: { $first: "$unit.unit" },
                        wing: { $first: "$unit.wing" },
                        floor: { $first: "$unit.floor" },
                        customer: { $push: "$$ROOT" }
                    }
                }
            )


            const resp = await MainDB.getmenual(TableName, new _Customer(), pipeline, requiredPage, sort, true, "", projection)

            ResponseBody.pagename = PageName
            ResponseBody.formname = FormName
            ResponseBody.fltpagecollection = FltPageCollection
            ResponseBody.status = 200
            ResponseBody.message = Config.getResponsestatuscode()['200']
            ResponseBody.data = resp.ResultData
            ResponseBody.currentpage = resp.currentpage
            ResponseBody.nextpage = resp.nextpage
            ResponseBody.totaldocs = resp.totaldocs;
            ResponseBody.fieldorder = resp.fieldorderdata
            ResponseBody.formfieldorderdata = resp.formfieldorderdata


            req.ResponseBody = ResponseBody; next()
        }
        catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }; next()
        }
    }

    //List
    async ListResidentsPet(req, res, next) {
        try {
            const ResponseBody = {}
            ResponseBody.status = 401
            ResponseBody.message = Config.getResponsestatuscode()["401"]


            var PaginationInfo = req.body.paginationinfo
            const projection = PaginationInfo.projection

            const requiredPage = { pageno: PaginationInfo.pageno, skip: (PaginationInfo.pageno - 1) * PaginationInfo.pagelimit, pagelimit: PaginationInfo.pagelimit }
            var pipeline = []
            var sort = (Object.keys(PaginationInfo.sort).length !== 0 ? PaginationInfo.sort : { _id: -1 })


            if (Object.keys(PaginationInfo.filter).length) {
                pipeline = IISMethods.GetPipelineForFilter(PaginationInfo.filter)
            }


            pipeline.push(
                {
                    $unwind: "$property"
                },
                {
                    $group: {
                        _id: "$property.unitid",
                        unit: { $first: "$property.unit" },
                        wing: { $first: "$property.wing" },
                        customer: { $push: "$$ROOT" }
                    }
                }
            )


            const resp = await MainDB.getmenual(TableName, new _Customer(), pipeline, requiredPage, sort, true, "", projection)

            ResponseBody.pagename = PageName
            ResponseBody.formname = FormName
            ResponseBody.fltpagecollection = FltPageCollection
            ResponseBody.status = 200
            ResponseBody.message = Config.getResponsestatuscode()['200']
            ResponseBody.data = resp.ResultData
            ResponseBody.currentpage = resp.currentpage
            ResponseBody.nextpage = resp.nextpage


            const customerMaster = new _Customer()
            if (resp.fieldorderdata) {
                ResponseBody.fieldorder = resp.fieldorderdata
            }
            else {
                ResponseBody.fieldorder = customerMaster.getFieldOrder()
            }

            req.ResponseBody = ResponseBody; next()
        }
        catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }; next()
        }
    }



    // Insert guest
    async ApprovekidsMaster(req, res, next) {
        try {
            const ResponseBody = {}

            const preapproveGuest = []
            const { startdate, enddate, starttime, endtime, weekdays } = req.body

            const daysMapping = {
                'Sun': 0,
                'Mon': 1,
                'Tue': 2,
                'Wed': 3,
                'Thu': 4,
                'Fri': 5,
                'Sat': 6
            }

            //Convert days of the week to numbers for easy comparison
            const days = weekdays.map(day => daysMapping[day]);

            const startDateObj = new Date(startdate);
            const endDateObj = new Date(enddate);
            const finalArray = [];

            //Parse start and end time for hour and minute extraction
            const { hours: startHour, minutes: startMinute } = IISMethods.parseTime(starttime);
            const { hours: endHour, minutes: endMinute } = IISMethods.parseTime(endtime);

            //Iterate through each date from startdate to enddate
            for (let currentDate = new Date(startDateObj); currentDate <= endDateObj; currentDate.setDate(currentDate.getDate() + 1)) {
                if (days.includes(currentDate.getDay())) {
                    // Set the start time for the current date
                    const formattedStartDate = new Date(currentDate);
                    formattedStartDate.setHours(startHour, startMinute, 0, 0);

                    // Set the end time for the current date
                    const formattedEndDate = new Date(currentDate);
                    formattedEndDate.setHours(endHour, endMinute, 59, 999);

                    // Push the formatted date object to the final array
                    finalArray.push({
                        startdate: formattedStartDate.toISOString(),
                        enddate: formattedEndDate.toISOString()
                    });
                }
            }


            const data = {
                age: req.body.age,
                relation: req.body.relation,
                gender: req.body.gender,
                picture: req.body.profilepic,
                name: req.body.personname,
                propertyid: req.headers.propertyid,
                property: req.headers.property,
                customerid: req.headers.uid,
                customer: req.headers.personname,
                allowtime: finalArray,
                startdate: req.body.startdate,
                enddate: req.body.enddate,
                floor: req.body.floor,
                floorid: req.body.floorid,
                unit: req.body.unit,
                unitid: req.body.unitid,
                wing: req.body.wing,
                wingid: req.body.wingid,
                guesttype: 1,
                iscollectfromgate: req.body.iscollectfromgate,
                weeks: weekdays,
                starttime: starttime,
                endtime: endtime,
                otp: IISMethods.generatecode(6),
                approvetype: 2
            }

            await MainDB.InsertMany("tblapprovemaster", new _Approve(), data)

            ResponseBody.status = 200
            ResponseBody.message = "OK"

            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }
}

