import { IISMethods, Config } from '../../config/Init.js'


export default class FileUpload {

    async UploadFile(req, res, next) {
        try {
            const ResponseBody = {}
            ResponseBody.status = 401
            ResponseBody.message = Config.getResponsestatuscode()["401"]


            var documentsUrls = []

            for (const fileObj of req.body.files) {
                var path = await IISMethods.uploadToS3(fileObj.file, req.headers.subdomainname + '/' + fileObj.path)
                documentsUrls.push(path)
            }

            ResponseBody.status = 200
            ResponseBody.message = Config.getResponsestatuscode()["200"]
            ResponseBody.url = documentsUrls

            req.ResponseBody = ResponseBody; next()
        }
        catch (err) {
            

            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }; next()
        }

    }
}