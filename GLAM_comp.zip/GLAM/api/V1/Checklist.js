import { IISMethods, Config ,MainDB} from '../../config/Init.js'
import _Checklist from '../../model/CheckList.js'

const TableName = 'tblchecklist'
const PageName = 'Task Checklist'
const FormName = 'Task Checklist'
const FltPageCollection = 'checklist'

export default class Checklist {
    //List
    async ListChecklist(req, res, next) {
        try {
            const ResponseBody = {}
            ResponseBody.status = 401
            ResponseBody.message = Config.getResponsestatuscode()["401"]

            const ObjectId = IISMethods.getobjectid()
            // var PaginationInfo = req.body.paginationinfo
            // const searchtext = req.body.searchtext || ""
            // const requiredPage = { nextpageid: PaginationInfo.nextpageid, pageno: PaginationInfo.pageno, skip: (PaginationInfo.pageno - 1) * PaginationInfo.pagelimit, pagelimit: PaginationInfo.pagelimit }
            var pipeline = []
            // var sort = (Object.keys(PaginationInfo.sort).length !== 0 ? PaginationInfo.sort : { displayorder: 1 })

            const {
                searchtext = "",
                paginationinfo: { nextpageid = "", pageno = 1, pagelimit = 20, filter = {}, sort = {}, projection = {} }
            } = req.body || {}
            let fieldorder = req.body.paginationinfo.isfieldorder ? req.body.paginationinfo.isfieldorder : 0

            const requiredPage = {
                nextpageid: nextpageid,
                pageno: pageno,
                skip: (pageno - 1) * pagelimit,
                pagelimit: pagelimit
            }

            if(req.headers.propertyid){
                pipeline.push({$match:{propertyid:ObjectId(req.headers.propertyid)}})
            }

            const sortData = Object.keys(sort).length !== 0 ? sort : { "_id": -1 }

            pipeline = IISMethods.GetPipelineForAndFilter(filter)
            if (searchtext !== "") {
                pipeline.push(...IISMethods.GetGlobalSearchFilter(new _Checklist(), searchtext))
            }
            const resp = await MainDB.getmenual(TableName, new _Checklist(), pipeline, requiredPage, sortData, fieldorder, "", projection)

            ResponseBody.pagename = PageName
            ResponseBody.formname = FormName
            ResponseBody.fltpagecollection = FltPageCollection
            ResponseBody.status = 200
            ResponseBody.message = Config.getResponsestatuscode()['200']
            ResponseBody.data = resp.ResultData
            ResponseBody.currentpage = resp.currentpage
            ResponseBody.nextpage = resp.nextpage
            ResponseBody.totaldocs = resp.totaldocs;
            ResponseBody.fieldorder = resp.fieldorderdata
            ResponseBody.formfieldorderdata = resp.formfieldorderdata

            req.ResponseBody = ResponseBody; next()
        }
        catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }; next()
        }
    }

    //Insert
    async InsertChecklist(req, res, next) {
        try {
            const ResponseBody = {}
            ResponseBody.status = 401
            ResponseBody.message = Config.getResponsestatuscode()["401"]

            req.body.propertyid = req.headers.propertyid
            req.body.property = req.headers.property

            const resp = await MainDB.executedata('i', new _Checklist(), TableName, req.body)
            ResponseBody.status = resp.status
            ResponseBody.message = resp.message

            req.ResponseBody = ResponseBody; next()
        }
        catch (err) {

            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }; next()
        }
    }

    //Update
    async UpdateChecklist(req, res, next) {
        try {
            const ResponseBody = {}
            ResponseBody.status = 401
            ResponseBody.message = Config.getResponsestatuscode()["401"]

            const pipelinedata = { _id: req.body._id }
            const record = await MainDB.FindOne(TableName, new _Checklist(), pipelinedata)

            if (record) {

                const RecordInfo = record.recordinfo
                RecordInfo.updateuid = req.headers.uid
                RecordInfo.updateby = req.headers.personname
                RecordInfo.updatedate = IISMethods.getdatetimestr()
                req.body.recordinfo = RecordInfo

                const resp = await MainDB.executedata('u', new _Checklist(), TableName, req.body)

                ResponseBody.data = resp.data
                ResponseBody.status = resp.status
                ResponseBody.message = resp.message
            }
            else {
                ResponseBody.status = 404
                ResponseBody.message = Config.getErrmsg()["notexist"]
            }

            req.ResponseBody = ResponseBody; next()
        }
        catch (err) {


            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }; next()
        }
    }


    //Delete
    async DeleteChecklist(req, res, next) {
        try {
            const ResponseBody = {}
            ResponseBody.status = 401
            ResponseBody.message = Config.getResponsestatuscode()["401"]

            const resp = await MainDB.executedata('d', new _Checklist(), TableName, req.body, true)

            ResponseBody.status = resp.status
            ResponseBody.message = resp.message

            req.ResponseBody = ResponseBody; next()
        }
        catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err };
            next()
        }
    }

    //List-> Check list log details
    async ListChecklistLogDetails(req, res, next) {
        try {
            const ResponseBody = {}
            ResponseBody.status = 401
            ResponseBody.message = Config.getResponsestatuscode()["401"]

            var PaginationInfo = req.body.paginationinfo
            const projection = PaginationInfo.projection 

            const requiredPage = { pageno: PaginationInfo.pageno, skip: (PaginationInfo.pageno - 1) * PaginationInfo.pagelimit, pagelimit: PaginationInfo.pagelimit }
            var pipeline = []
            var sort = (Object.keys(PaginationInfo.sort).length !== 0 ? PaginationInfo.sort : { _id: -1 })

            pipeline = IISMethods.GetPipelineForAndFilter(PaginationInfo.filter)

            //Global Search
            const searchtext = req.body.searchtext || ""
            if (searchtext !== "") {
                pipeline.push(...IISMethods.GetGlobalSearchFilter(new TaskCheckListLogDetail(), searchtext))
            }

            const resp = await MainDB.getmenual("tbltaskchecklistlogdetails", new TaskCheckListLogDetail(), pipeline, requiredPage, sort, true, "", projection) 

            ResponseBody.pagename = "Checklist Log Details"
            ResponseBody.formname = "Checklist Log Details"
            ResponseBody.fltpagecollection = "taskchecklistlogdetails"
            ResponseBody.status = 200
            ResponseBody.message = Config.getResponsestatuscode()['200']
            ResponseBody.data = resp.ResultData
            ResponseBody.currentpage = resp.currentpage
            ResponseBody.nextpage = resp.nextpage

            req.ResponseBody = ResponseBody; next()
        }
        catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }; next()
        }
    }

    async ChecklistBulkCopy(req, res, next) {
        try {
            const ResponseBody = {}
            const ObjectId = IISMethods.getobjectid()

            const { frompropertyid, selecteddataflag = 0, selecteddata } = req.body
            const toData = req.body.data

            let insertData = []
            let totalCount = 0
            let successCount = 0
            let errorCount = 0

            const fromPipeline = [
                {
                    $match: {
                        propertyid: ObjectId(frompropertyid)
                    }
                }
            ]

            if (selecteddataflag) {
                fromPipeline.push({
                    $match: {
                        _id: { $in: selecteddata.map(obj => ObjectId(obj)) }
                    }
                })
            }
            const resp = await ManiDB.getmenual(TableName, new _Checklist(), fromPipeline)
            let respData = resp.ResultData

            if (respData.length) {

                let roomtypeIds = []
                let tasksubcategoryIds = []
                let itemIds = []
                let serviceIds = []
                let areaName = []

                respData.forEach(obj => {
                    obj.checklists?.forEach(obj2 => {
                        if (obj2.type === 0) {
                            itemIds.push(obj2.productid)
                        }
                        else if (obj2.type === 1) {
                            serviceIds.push(obj2.productid)
                        }
                        else if (obj2.type === 2) {
                            areaName.push(obj2.productname)
                        }
                    })

                    obj.roomtype?.forEach(obj2 => {
                        roomtypeIds.push(obj2.roomtypeid)
                    })

                    tasksubcategoryIds.push(obj.tasksubcategoryid)
                })

                //RoomType
                roomtypeIds = roomtypeIds.filter((x, i, a) => {
                    return a.indexOf(x) === i
                })
                //TaskSubCategory
                tasksubcategoryIds = tasksubcategoryIds.filter((x, i, a) => {
                    return a.indexOf(x) === i
                })
                //Item
                itemIds = itemIds.filter((x, i, a) => a.indexOf(x) === i)
                //Service
                serviceIds = serviceIds.filter((x, i, a) => {
                    return a.indexOf(x) === i
                })
                areaName = areaName.filter((x, i, a) => {
                    return a.indexOf(x) === i
                })
                // Code for Dependency

                const dependencyHeaders = req.headers
                const dependencyBody = req.body

                dependencyBody.selecteddataflag = 1

                dependencyBody.data = dependencyBody.data.filter(obj => obj.topropertynameid !== frompropertyid)


                //RoomType
                dependencyBody.selecteddata = roomtypeIds
                await ManiDB.getCopyMasterData("propertyroomtype", dependencyHeaders, dependencyBody)

                //TaskSubCategory
                dependencyBody.selecteddata = tasksubcategoryIds
                await ManiDB.getCopyMasterData("tasksubcategory", dependencyHeaders, dependencyBody)

                //Item
                dependencyBody.selecteddata = itemIds
                await ManiDB.getCopyMasterData("productmaster", dependencyHeaders, dependencyBody)

                //Service
                dependencyBody.selecteddata = serviceIds
                await ManiDB.getCopyMasterData("service", dependencyHeaders, dependencyBody)

                totalCount = (respData.length) * (toData.length)

                const propertyIds = toData.map(property => ObjectId(property.topropertynameid))

                const pipeline = [{ $match: { propertyid: { $in: propertyIds }, } }]
                const toResp = await ManiDB.getmenual(TableName, new _Checklist(), pipeline)
                let toRespData = toResp.ResultData

                const pipeline2 = [
                    {
                        $match: {
                            propertyid: { $in: propertyIds }
                        }
                    }
                ]
                const propertyAreaResp = await ManiDB.getmenual("tblpropertyarea", new PropertyArea(), pipeline2)
                const propertyAreaData = propertyAreaResp.ResultData

                const ProductMasterResp = await ManiDB.getmenual("tblproductmaster", new Product(), pipeline2)
                const productmasterData = ProductMasterResp.ResultData

                const roomtypeResp = await ManiDB.getmenual("tblpropertyroomtypesetting", new RoomTypeSetting(), pipeline2)
                const roomtypeData = roomtypeResp.ResultData

                const tasksubcategoryResp = await ManiDB.getmenual("tbltasksubcategory", new TaskSubCategory(), pipeline2)
                const tasksubcategoryData = tasksubcategoryResp.ResultData

                for (let property of toData) {

                    const currentPropertyArea = propertyAreaData.filter(obj => obj.propertyid.toString() === property.topropertynameid)
                    const currentPropertyProduct = productmasterData.filter(obj => obj.propertyid.toString() === property.topropertynameid)
                    const currentPropertyRoomType = roomtypeData.filter(obj => obj.propertyid.toString() === property.topropertynameid)
                    const currentPropertyTaskSubCategory = tasksubcategoryData.filter(obj => obj.propertyid.toString() === property.topropertynameid)

                    let flag = 0
                    //Check if there is any record with current propertyid
                    if ((toRespData.map(obj2 => obj2.propertyid.toString()).includes(property.topropertynameid))) {
                        flag = 1
                    }

                    const fromData = []

                    respData.forEach(obj => {

                        obj.topropertynameid = ObjectId(property.topropertynameid)
                        fromData.push(obj)

                    })


                    for (let obj of fromData) {

                        if (obj.topropertynameid.toString() === property.topropertynameid) {


                            const matchingObj = currentPropertyTaskSubCategory.find(obj2 => obj2.tasksubcategory === obj.tasksubcategory) // 24-10-23 Abhi Shah
                            if (matchingObj) {
                                obj.tasksubcategoryid = matchingObj._id;
                            }

                            // obj.tasksubcategoryid = currentPropertyTaskSubCategory.find(obj2 => obj2.tasksubcategory === obj.tasksubcategory)._id

                            obj.roomtype?.forEach(obj2 => {

                                const check = currentPropertyRoomType.find(obj3 => obj3.roomtype === obj2.roomtype)

                                if (check) {
                                    obj2.roomtypeid = check._id
                                }
                            })

                            obj.checklists?.forEach(obj2 => {

                                if (obj2.type === 0) {
                                    const check = currentPropertyProduct.find(obj3 => obj3.productname === obj2.productname && obj3.type === 0)

                                    if (check) {
                                        obj2.productid = check._id
                                        obj2.productcategoryid = check.productcategoryid
                                        obj2.productsubcategoryid = check.productsubcategoryid
                                    }
                                }
                                else if (obj2.type === 1) {
                                    const check = currentPropertyProduct.find(obj3 => obj3.productname === obj2.productname && obj3.type === 1)

                                    if (check) {
                                        obj2.productid = check._id
                                        obj2.productcategoryid = check.productcategoryid
                                        obj2.productsubcategoryid = check.productsubcategoryid
                                    }
                                }
                                else if (obj2.type === 2) {
                                    const check = currentPropertyArea.find(obj3 => obj3.area === obj2.productname)

                                    if (check) {
                                        obj2.productid = check._id
                                    }
                                }
                            })
                            const insertObj = { ...obj }

                            insertObj._id = new ObjectId()

                            insertObj.propertyid = insertObj.topropertynameid
                            insertObj.propertyname = property.topropertyname

                            insertObj.recordinfo = {
                                entryuid: req.headers.uid,
                                entryby: req.headers.personname,
                                entrydate: IISMethods.getdatetimestr(),
                                timestamp: new Date().getTime(),
                            }

                            insertData.push(insertObj)
                        }
                    }
                }

                let insertResp = await ManiDB.InsertMany(TableName, new _Checklist(), insertData)

                successCount = insertData.length
                errorCount = totalCount - successCount

                // let insertResp = {status : 200, message : "OK"}

                ResponseBody.status = insertResp.status
                ResponseBody.message = insertResp.status === 200 ? Config.getErrmsg()["copysuccess"] : insertResp.message
                ResponseBody.successdatacount = successCount
                ResponseBody.errordatacount = errorCount
            }
            else {
                ResponseBody.status = 400
                ResponseBody.message = Config.getErrmsg()["notexist"]
            }

            req.ResponseBody = ResponseBody; next()

        }
        catch (err) {


            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }; next()
        }
    }
}

