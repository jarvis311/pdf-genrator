import { IISMethods, Config,MainDB } from "../../config/Init.js"
import _FieldOrder from "../../config/FieldOrder.js"

const TableName = "tblfieldorder"

export default class FieldOrder {
    // START FieldOrder

    //Insert
    async InsertFieldOrder(req, res, next) {
        try {
            const ResponseBody = {}
            const ObjectId = IISMethods.getobjectid()

            const ObjModel = await MainDB.createmodel(TableName, new _FieldOrder())
            const fieldorderdata = await ObjModel["objModel"].findOne({ userid: req.headers.uid, pagename: req.body.pagename })

            if (fieldorderdata) {
                // Update
                const RecordInfo = fieldorderdata.recordinfo
                RecordInfo.updateuid = req.headers.uid
                RecordInfo.updateby = req.headers.personname
                RecordInfo.updatedate = IISMethods.getdatetimestr()
                req.body.recordinfo = RecordInfo

                req.body._id = fieldorderdata._id
                const resp = await MainDB.executedata("u", new _FieldOrder(), TableName, req.body)

                ResponseBody.data = resp.data
                ResponseBody.status = resp.status
                ResponseBody.message = resp.message
            } else {
                // Insert
                const resp = await MainDB.executedata("i", new _FieldOrder(), TableName, req.body)

                ResponseBody.status = resp.status
                ResponseBody.message = resp.message
            }

            req.ResponseBody = ResponseBody; next()
        } catch (err) {
            

            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }; next()
        }
    }

    // End FieldOrder
}
