import { IISMethods,MainDB, Config } from "../../../config/Init.js"
import _AppUpdate from "../../../model/masters/Configurations/AppUpdate.js";
import _Device from "../../../model/masters/Device.js";


export default class AppVersion {
	
    async AppVersion(req, res, next) {
        try {
            var ResponseBody = {
                message: Config.resstatuscode["500"],
                status: 500,
                data: {
                    isforcefully: 0,
                    isforcelogout: 0,
                    isappupdateavailable: 0
                }
            }
            const ObjectId = IISMethods.getobjectid()

            if (req.headers.useraction == 'adddevicedata') {
                const appversion = req.body.appversion;
                const devicemodelname = req.body.devicemodelname;
                const macaddress = req.body.macaddress;
                const ipaddress = req.connection.remoteAddress;
                let deviceid = req.body.deviceid;
                const osversion = req.body.osversion;
                const devicename = req.body.devicename;
                const browsername = req.body.browsername;
                const datetime = IISMethods.getdatetimeisostr();
                const timestamp = IISMethods.GetTimestamp();
                const os = req.headers['os']
                const uid = req.headers['uid']
                const useragent = req.headers['useragent']

                let phonetype = os === 'a' ? 1 : 2;

                const latestAppUpdatePipeline = [
                    { $match: { phonetype: phonetype } },
                    { $sort: { timestamp: -1 } }
                ]
                let latestAppUpdate = await MainDB.getmenual("tblappupdate", new _AppUpdate(), latestAppUpdatePipeline)
                latestAppUpdate = latestAppUpdate?.ResultData?.[0]

                let isappupdate = 0;
                if (latestAppUpdate && appversion < latestAppUpdate.vername) {
                    isappupdate = 1;
                    ResponseBody.message = "App update available.";
                    ResponseBody.data = {
                        isforcefully: latestAppUpdate.isforcefully,
                        isforcelogout: latestAppUpdate.isforcelogout,
                        isappupdateavailable: 1
                    }
                }

                let existingDevice = await MainDB.FindOne("tbldevice", new _Device(), { macaddress: macaddress })
                
                if (existingDevice) {
                    if (!deviceid) {
                        deviceid = existingDevice.deviceid;
                    }

                    const upddata = {
                        _id: existingDevice._id.toString(),
                        os,
                        appversion,
                        devicemodelname,
                        ipaddress,
                        osversion,
                        deviceid,
                        uid,
                        useragent,
                        browsername,
                        entry_date: datetime,
                        devicename
                    };

                    await MainDB.executedata("u", new _Device(), "tbldevice", upddata)

                    if (existingDevice.appversion < appversion) {
                        await MainDB.Update("tbldevice", new _Device(), [{ _id: existingDevice._id }, { $set: { appupdate: datetime } }])
                    }
                } else {
                    const insdata = {
                        uid: new ObjectId(uid),
                        os,
                        appversion,
                        devicemodelname,
                        macaddress,
                        ipaddress,
                        osversion,
                        deviceid,
                        useragent,
                        browsername,
                        timestamp: timestamp,
                        entry_date: datetime,
                        appupdate: datetime,
                        devicename
                    };
                    const deviceResp = await MainDB.executedata("i", new _Device(), "tbldevice", insdata)
                }

                ResponseBody.status = 200;
                ResponseBody.message = "Success";
                ResponseBody.blobstorageconnectionstring = Config.getBlobkey(),
                ResponseBody.blobstoragecontainername = Config.getContainer()

                if (isappupdate === 1) {
                    ResponseBody.status = 200
                    ResponseBody.data.isappupdateavailable = 1
                    ResponseBody.message = "App Update"
                }

            }
            ResponseBody.status = 200;
            req.ResponseBody = ResponseBody

            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.resstatuscode["500"], err }
            next()
        }
    }
}
