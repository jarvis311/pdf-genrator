import { IISMethods, Config, MainDB } from "../../../config/Init.js"
import _Device from "../../../model/APP/Device.js"
import _UserRights from "../../../model/masters/UserManagement/Userrights.js"

export default class Device {
	// Insert Device Token
	async InsertDeviceToken(req, res, next) {
		try {
			const ResponseBody = {}
			const ObjectId = IISMethods.getobjectid()

			const { deviceid = "", macaddress = "" } = req.body

			const devicePipeline = [{ $match: { deviceid: deviceid, platform: req.headers.platform, moduletypeid: Config.moduletype[req.headers.moduletype] } }]
			const deviceResp = await MainDB.getmenual("tbldevice", new _Device(), devicePipeline)
			const device = deviceResp.ResultData[0]

			if (device) {
				// For Web
				device.uid = req.headers.uid
				device.token = req.headers.token

				const resp = await MainDB.executedata("u", new _Device(), "tbldevice", device)

				ResponseBody.status = resp.status
				ResponseBody.message = resp.message
			} else {
				// For APP

				// Check if device exists
				const devicePipeline = [
					{
						$match: {
							uid: req.headers.uid,
							platform: req.headers.platform,
							moduletypeid: Config.moduletype[req.headers.moduletype],
							macaddress: macaddress
						}
					}
				]
				const deviceResp = await MainDB.getmenual("tbldevice", new _Device(), devicePipeline)
				const device = deviceResp.ResultData[0]

				if (device) {
					// Update data
					device.deviceid = deviceid
					device.appupdate = new Date()
					device.token = req.headers.token

					const resp = await MainDB.executedata("u", new _Device(), "tbldevice", device)

					ResponseBody.status = resp.status
					ResponseBody.message = resp.message
				} else {
					// Insert data
					const device = {
						uid: req.headers.uid,
						platform: req.headers.platform,
						moduletypeid: Config.moduletype[req.headers.moduletype],
						useragent: req.headers["user-agent"],
						os: req.body.os,
						osversion: req.body.osversion,
						ipaddress: req.headers["x-forwarded-for"] || req.connection.remoteAddress,
						macaddress: macaddress,
						deviceid: deviceid,
						devicemodelname: req.body.devicemodelname,
						appversion: req.body.appversion,
						token: req.headers.token
					}
					const resp = await MainDB.executedata("i", new _Device(), "tbldevice", device)

					ResponseBody.status = resp.status
					ResponseBody.message = resp.message
				}
			}

			ResponseBody.isforcefully = 0
			ResponseBody.isforcelogout = 0
			ResponseBody.isappupdate = 0

			// Check If Appliction is Update or Not
			// if (["chat", "app"].includes(req.headers.moduletype)) {
			// 	const releaseMasterPipeline = [
			// 		{
			// 			$match: {
			// 				platformid: ObjectId(Config.moduletype[req.headers.moduletype]),
			// 				osplatform: req.headers.platform,
			// 				isactive: 1
			// 			}
			// 		},
			// 		{ $sort: { _id: -1 } },
			// 		{ $limit: 1 }
			// 	]

			// 	const releaseMasterResp = await MainDB.getmenual("tblreleasemaster", new _ReleaseMaster(), releaseMasterPipeline)

			// 	if (releaseMasterResp.ResultData.length) {
			// 		if (parseInt(releaseMasterResp.ResultData[0].versioncode) > parseInt(req.body.appversion)) {
			// 			ResponseBody.message = Config.getErrmsg()["appupdate"]
			// 			ResponseBody.isforcefully = releaseMasterResp.ResultData[0].isforcefully
			// 			ResponseBody.isforcelogout = ResponseBody.isforcefully ? 1 : 0
			// 			ResponseBody.isappupdate = 1
			// 		}
			// 	}
			// }

			req.ResponseBody = ResponseBody
			next()
		} catch (err) {
			req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
			next()
		}
	}
}
