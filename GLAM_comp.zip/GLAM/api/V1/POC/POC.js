import { IISMethods, Config,  MainDB, PaginationInfo, FieldConfig } from "../../../config/Init.js"
import CryptoJS from "crypto-js"

export default class POC {

    async decryptpayloaddata(req, res, next) {
        try {
            const ResponseBody = {}
            // const tempkey = req.body.reqBody.split(".")[1]
            // const data = req.body.reqBody.split(".")[0]

            // const secretKey = CryptoJS.enc.Utf8.parse("38c1971c7a97c9728a0a6e6d8ab6ce3e")
            // let iv = CryptoJS.enc.Utf8.parse(tempkey)
            // const bytes = CryptoJS.AES.decrypt(data, secretKey, { iv: iv })
            // const decryptData = bytes.toString(CryptoJS.enc.Utf8)

            ResponseBody.data = req.body
            ResponseBody.status = 200
            ResponseBody.message = "Success"
            res.send(ResponseBody)
        } catch (e) {
            //node_Error(e)
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], e }
            next()
        }
    }
    async decryptresponseddata(req, res, next) {
        try {
            const ResponseBody = {}
            const tempkey = req.body.ResponseBody.split(".")[1]
            const data = req.body.ResponseBody.split(".")[0]

            const secretKey = CryptoJS.enc.Utf8.parse(process.env.ENCRYPTION_KEY)
            let iv = CryptoJS.enc.Utf8.parse(tempkey)
            const bytes = CryptoJS.AES.decrypt(data, secretKey, { iv: iv })
            const decryptData = bytes.toString(CryptoJS.enc.Utf8)

            ResponseBody.data = JSON.parse(JSON.parse(decryptData))
            ResponseBody.status = 200
            ResponseBody.message = "Success"
            res.send(ResponseBody)
        } catch (e) {
            //node_Error(e)
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], e }
            next()
        }
    }
    async encryptbodyData(req, res, next) {
        try {
            const ResponseBody = {}
            const uid = IISMethods.generateRandomString(16)

            const secretKey = CryptoJS.enc.Utf8.parse("vOVH6sdmpNWjRRIqCc7rdxs01lwHzfr3")
            const iv = CryptoJS.enc.Utf8.parse(uid)

            const encryptData = CryptoJS.AES.encrypt(JSON.stringify(req.body), secretKey, { iv: iv })

            ResponseBody.data = encryptData.toString() + "." + uid
            ResponseBody.status = 200
            ResponseBody.message = "Success"
            res.send(ResponseBody)
        } catch (e) {
            //node_Error(e)
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], e }
            next()
        }
    }

    async decryptresponseddata_new(req, res, next) {
        try {
            const ResponseBody = {}
            const tempkey = req.body.ResponseBody.split(".")[1]
            const data = req.body.ResponseBody.split(".")[0]

            const secretKey = CryptoJS.enc.Utf8.parse("vOVH6sdmpNWjRRIqCc7rdxs01lwHzfr3")
            let iv = CryptoJS.enc.Utf8.parse(tempkey)
            const bytes = CryptoJS.AES.decrypt(data, secretKey, { iv: iv })
            const decryptData = bytes.toString(CryptoJS.enc.Utf8)

            ResponseBody.data = JSON.parse(JSON.parse(decryptData))
            ResponseBody.status = 200
            ResponseBody.message = "Success"
            res.send(ResponseBody)
        } catch (e) {
            //node_Error(e)
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], e }
            next()
        }
    }
}
