import { Config, SubDBPool } from "../../config/Init.js"
// import _Person from "../../model/Person_new.js"

const TableName = "tblpersonmaster"

export default class HierarchyWisePerson {
    //List
    async HierarchyWisePersonList(req, res, next) {
        try {
            const ResponseBody = {}
            const PersonId = req.body.personid
            const PersonIds = await SubDBPool[req.headers["subdomainname"]].getPersonHierarchyId(PersonId)
            const Pipeline = [{ $match: { _id: { $in: PersonIds } } }]
            const resp = await SubDBPool[req.headers["subdomainname"]].getmenual(TableName, new _Person(), Pipeline)

            ResponseBody.status = 200
            ResponseBody.message = Config.getResponsestatuscode()["200"]
            ResponseBody.data = resp.ResultData

            req.ResponseBody = ResponseBody; next()
        } catch (err) {
            
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }; next()
        }
    }
}
