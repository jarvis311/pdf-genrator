// import { Config, SubDBPool } from "../../config/Init.js"
// import _Notification from "../../model/Person_new.js"

// const TableName = "tblpersonmaster"

// export default class PersonHierarchy {
//     //List
//     async ListPersonHierarchy(req, res, next) {
//         try {
//             const ResponseBody = {}
//             const PersonId = req.body.personid
//             const resp = await SubDBPool[req.headers["subdomainname"]].getPersonHierarchyId(PersonId)

//             // const pipeline = [{ $project: { reportingtoid: 1 } }]
//             // const resp = await SubDBPool[req.headers["subdomainname"]].getmenual(TableName, new _Notification(), pipeline)
//             // const PersonResp = resp.ResultData
//             // const PersonIdArray = []
//             // const PersonHierarchy = (reportingtoid) => {
//             //     PersonResp.forEach((person) => {
//             //         if (person._id.toString() == reportingtoid) {
//             //             PersonIdArray.push(person._id)
//             //             if (person.reportingtoid) {
//             //                 PersonHierarchy(person.reportingtoid)
//             //             }
//             //         }
//             //     })
//             // }
//             // PersonHierarchy(PersonId)

//             ResponseBody.status = 200
//             ResponseBody.message = Config.getResponsestatuscode()["200"]
//             ResponseBody.data = resp

//             req.ResponseBody = ResponseBody; next()
//         } catch (err) {
//             
//             req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }; next()
//         }
//     }
// }

import { IISMethods, Config, SubDBPool,SubDB, MainDB } from "../../config/Init.js"
import _DBConfig from "../../config/DBConfig.js"
import _TaskDefault from "../../model/task/TaskDefault.js" // "tbltaskdefault"
import _Task from "../../model/task/Task.js" // "tbltaskassign"
import _TaskActionLog from "../../model/task/TaskActionLog.js" // "tbltaskactionlog"
import _TaskLog from "../../model/task/TaskLog.js" // "tbltasklog"
import _TaskChat from "../../model/task/Task_Chat/TaskChat.js" // "tbltaskchat"
import _Reminder from "../../model/task/Reminder.js" // "tbltaskreminder"
import _TaskCheckListLog from "../../model/task/TaskCheckListLog.js" // "tbltaskchecklistlogs"
import _TaskCheckListLogDetail from "../../model/task/TaskCheckListLogDetail.js" // "tbltaskchecklistlogdetails"
import _TaskStartStopLog from "../../model/task/TaskStartStopLog.js" // "tbltaskstartstoplog"
import _EventBasedLog from "../../model/task/EventBasedLog.js" // "tbleventbasedtasklog"
import ProductPart from "../../model/task/ProductPart.js"
import ReplaceProduct from "../../model/task/ReplaceProduct.js"
import Reminder from "../../model/task/Reminder.js"
import TaskCheckList from "../../model/task/TaskCheckList.js"
import { PropertyRoomConfiguration,RoomTypeSetting } from "../../model/property_registration/Property.js"
import Notification from "../../model/task/Notification.js"
import Users from "../../model/Users.js"
import Reservation from "../../model/reservation/Reservation.js"
import _RoomType from "../../model/masters/Configurations/RoomType.js"

export default class PersonHierarchy {
    //List
    async ListPersonHierarchy(req, res, next) {
        try {
            const ResponseBody = {}

            var userpipiline = [{ $match: {} }]
            const ObjectId = IISMethods.getobjectid()
            if (req?.query?.subdomainname) {
                userpipiline = [{ $match: { subdomainname: req.query.subdomainname } }]
            } else {
                userpipiline = [{ $match: { subdomainname: 'glam' } }]
            }

            const userRecord = await MainDB.getmenual("tblusermaster", new Users(), userpipiline)

            for (var userData of userRecord.ResultData) {
                var customSubDomain = userData.subdomainname

                const isExist = SubDBPool[customSubDomain]

                if (!isExist) {
                    SubDB.setDBType("MONGODB")
                    SubDB.setDBHost(userData.dbhost)
                    SubDB.setDBPort(userData.dbport)
                    SubDB.setDBName(userData.dbname)
                    SubDB.setDBUser(userData.dbusername)
                    SubDB.setDBPass(userData.dbpassword)
                    SubDB.Connect()

                    SubDBPool[customSubDomain] = Object.assign(new _DBConfig(), SubDB)
                }

                const resp = await SubDBPool[customSubDomain].getmenual("tblroomtypemaster", new _RoomType(), [{$match:{_id:{$ne:0}}}])

                for(let obj of resp.ResultData){
                    let setData = {backgroundcolor:obj.backgroundcolor, textcolor:obj.textcolor }
                    let updateRoomPipeline = [{roomtypeid:ObjectId(obj._id)},{$set:setData}]
                    await SubDBPool[customSubDomain].Update("tblpropertyroomtypesetting", new RoomTypeSetting(), updateRoomPipeline)
                }

                ResponseBody.status = 200
                ResponseBody.message = Config.errmsg.delete
            }
            req.ResponseBody = ResponseBody; next()
        } catch (err) {
            

            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }; next()
        }
    }
}
