import { Config, MainDB, SubDBPool, IISMethods, FieldConfig } from "../../config/Init.js"
import _TaskStatusType from "../../model/submodel/TaskStatusType.js"

import _TaskStartStopLog from "../../model/task/TaskStartStopLog.js"
import _Task from "../../model/task/Task.js"
import TaskStatus from "../../model/masters/Configurations/TaskStatus.js"
import _TaskLog from "../../model/task/TaskLog.js"
import _ResolutionLog from "../../model/task/ResolutionLog.js"
// import _Person from "../../model/Person_new.js"
import _Notification from "../../model/task/Notification.js"
import _NotificatioSetting from "../../model/task/NotificationSetting.js"
import Reservation from "../../model/reservation/Reservation.js"
import TaskCheckListLog from "../../model/task/TaskCheckListLog.js"
import TaskSubCategory from "../../model/masters/Configurations/TaskSubCategory.js"
import TaskAction from "../../model/masters/Configurations/TaskAction.js"
import AreaType from "../../model/masters/Configurations/AreaType.js"
import { PropertyFloor, RoomTypeSetting } from "../../model/property_registration/Property.js"
import TaskFilter from "../../model/task/TaskFilter.js"

const TableName = "tbltaskstartstoplog"

export default class TaskProcessLog {

    async TaskProcessLogList(req, res, next) {
        //only this api use
        try {
            const ResponseBody = {}
            ResponseBody.status = 401
            ResponseBody.message = Config.getResponsestatuscode()["401"]

            const ObjectId = IISMethods.getobjectid()

            let personPipeline = [{ $match: { _id: ObjectId(req.headers.uid) } }]
            const personResp = await SubDBPool[req.headers["subdomainname"]].getmenual("tblpersonmaster", new _Person(), personPipeline)
            if (personResp.ResultData.length > 0) {
                var personResult = personResp.ResultData[0]
                let pipeline = [
                    {
                        $match: {
                            _id: ObjectId(req.body.taskid)
                        }
                    }
                ]
                var record = await SubDBPool[req.headers["subdomainname"]].getmenual("tbltaskassign", new _Task(), pipeline)
                if (record.ResultData.length > 0) {
                    let result = record.ResultData[0]

                    req.body.recordinfo = {
                        entryuid: req.headers.uid,
                        entryby: req.headers.personname,
                        entrydate: IISMethods.getdatetimestr(),
                        timestamp: IISMethods.GetTimestamp(),
                        isactive: 1,
                        updateuid: " ",
                        updateby: " ",
                        updatedate: " "
                    }
                    let oldmillisecond = result?.taskprogresstime ? parseInt(result?.taskprogresstime) : 0
                    var ishidestartbtn = 0
                    var lasttaskstarttime = ""
                    var taskstarttime = new Date()
                    var isstarttimer = 0

                    let verifyoldmillisecond = result?.verifytaskprogresstime ? parseInt(result?.verifytaskprogresstime) : 0
                    var verifylasttaskstarttime = ""
                    var verifyisstarttimer = 0
                    var isverify = result.isverify
                    var iscompleted = result.iscompleted
                    var isinspected = result.isinspected
                    var verifyishidestartbtn = 0

                    var clockinvalidationmessage = ""
                    var properyvalidationmessage = ""
                    var isStartTask = 1

                    req.body.stopbatterylevel = req.body.stopbatterylevel ? req.body.stopbatterylevel : 0

                    if (req.body.flag == 6) {
                        // verify inspected
                        if (isverify == 2) {
                            var statustype = Config.newTaskStatusType[result.categoryid]?.reinspection
                        } else {
                            var statustype = Config.newTaskStatusType[result.categoryid]?.inspected
                        }
                        req.body.stoptime = new Date()
                        verifyishidestartbtn = 2
                        isverify = 1
                        iscompleted = 1
                        isinspected = 0
                        clockinvalidationmessage = Config.errmsg.inspectclockinfirst
                        properyvalidationmessage = Config.errmsg.inspectswitchclockinproperty + result.propertyname + "."
                    } else if (req.body.flag == 5) {
                        //verify revisit
                        var statustype = Config.newTaskStatusType[result.categoryid]?.revisit
                        req.body.stoptime = new Date()
                        verifyishidestartbtn = 2
                        isverify = 2
                        iscompleted = 0
                        isinspected = 0
                        ishidestartbtn = 4
                        clockinvalidationmessage = Config.errmsg.completeclockinfirst
                        properyvalidationmessage = Config.errmsg.completeswitchclockinproperty + result.propertyname + "."
                    } else if (req.body.flag == 4) {
                        //verify pause
                        var statustype = Config.newTaskStatusType[result.categoryid]?.paused
                        req.body.stoptime = new Date()
                        verifyishidestartbtn = 8
                        clockinvalidationmessage = Config.errmsg.pauseclockinfirst
                        properyvalidationmessage = Config.errmsg.pauseswitchclockinproperty + result.propertyname + "."
                    } else if (req.body.flag == 3) {
                        //verify start
                        var statustype = Config.newTaskStatusType[result.categoryid]?.inprogress
                        req.body.starttime = new Date()
                        req.body.stoptime = null
                        verifyishidestartbtn = 7
                        verifylasttaskstarttime = new Date()
                        verifyisstarttimer = 1
                        clockinvalidationmessage = Config.errmsg.startclockinfirst
                        properyvalidationmessage = Config.errmsg.startswitchclockinproperty + result.propertyname + "."
                    } else if (req.body.flag == 2) {
                        //complete
                        var statustype = await SubDBPool[req.headers["subdomainname"]].getTaskCompletionStatus(result.subcategoryid, result.categoryid)

                        req.body.stoptime = new Date()
                        iscompleted = 1
                        ishidestartbtn = 2
                        verifyishidestartbtn = 8
                        clockinvalidationmessage = Config.errmsg.completeclockinfirst
                        properyvalidationmessage = Config.errmsg.completeswitchclockinproperty + result.propertyname + "."
                        var dualAuthPersons = []
                        if (result.dualauthentication == 1) {
                            if (result.dualauthenticationpersons.length) {
                                dualAuthPersons = result.dualauthenticationpersons.map((obj) => obj.personid.toString())
                            } else {
                                var departmentIds = result.dualauthenticationdepartment.map((obj) => obj.departmentid)
                                dualAuthPersons = await SubDBPool[req.headers["subdomainname"]].getDepartmentWisePersonIds(null, departmentIds)
                            }
                        } else if (result.dualauthenticationwithphoto == 1) {
                            if (result.dualauthenticationwithphotopersons.length) {
                                dualAuthPersons = result.dualauthenticationwithphotopersons.map((obj) => obj.personid.toString())
                            } else {
                                var departmentIds = result.dualauthenticationwithphotodepartment.map((obj) => obj.departmentid)
                                dualAuthPersons = await SubDBPool[req.headers["subdomainname"]].getDepartmentWisePersonIds(null, departmentIds)
                            }
                        }

                        if (dualAuthPersons.length) {
                            isinspected = 1
                        }


                    } else if (req.body.flag == 0) {
                        //pause
                        var statustype = Config.newTaskStatusType[result.categoryid]?.paused
                        req.body.stoptime = new Date()
                        ishidestartbtn = 4
                        clockinvalidationmessage = Config.errmsg.pauseclockinfirst
                        properyvalidationmessage = Config.errmsg.pauseswitchclockinproperty + result.propertyname + "."
                    } else {
                        //start
                        var statustype = Config.newTaskStatusType[result.categoryid]?.inprogress
                        req.body.starttime = new Date()
                        req.body.stoptime = null
                        ishidestartbtn = 1
                        lasttaskstarttime = new Date()
                        taskstarttime = new Date()
                        isstarttimer = 1
                        clockinvalidationmessage = Config.errmsg.startclockinfirst
                        properyvalidationmessage = Config.errmsg.startswitchclockinproperty + result.propertyname + "."

                        //Start: Check previous forcefully profile task is completed or not
                        if (result.assignmentforid.toString() == Config.amenitiescategoryroom) {
                            var taskstartdate = IISMethods.getDateFormats(result.startdate)
                            const reservationPipeline = [
                                {
                                    $addFields: {
                                        _checkindate: {
                                            $dateToString: {
                                                format: "%Y-%m-%d",
                                                date: "$checkindate"
                                            }
                                        },
                                        _checkoutdate: {
                                            $dateToString: {
                                                format: "%Y-%m-%d",
                                                date: "$checkoutdate"
                                            }
                                        }
                                    }
                                },
                                { $match: { _checkindate: { $lte: taskstartdate }, _checkoutdate: { $gte: taskstartdate }, roomnoid: ObjectId(result.roomnoid) } }
                            ]

                            const reservationRecord = await SubDBPool[req.headers["subdomainname"]].getmenual("tblreservation", new Reservation(), reservationPipeline)

                            if (reservationRecord.ResultData.length) {
                                var reservationData = reservationRecord.ResultData[0]

                                var checkindate = IISMethods.getDateFormats(reservationData.checkindate)
                                var checkoutdate = IISMethods.getDateFormats(reservationData.checkoutdate)

                                // var day = IISMethods.getDaysDifference(checkindate,taskstartdate)-1

                                // Get task
                                // var pastTaskDate = new Date(taskstartdate)
                                // pastTaskDate.setDate(pastTaskDate.getDate() - parseInt(day))
                                // pastTaskDate = IISMethods.getDateFormats(pastTaskDate)
                                const taskAssignPipeline = [
                                    {
                                        $addFields: {
                                            _startdate: {
                                                $dateToString: {
                                                    format: "%Y-%m-%d",
                                                    date: "$startdate"
                                                }
                                            }
                                        }
                                    },
                                    {
                                        $match: {
                                            _startdate: { $gte: checkindate, $lte: checkoutdate },
                                            roomnoid: ObjectId(result.roomnoid),
                                            taskprofileflag: 3,
                                            assignpersonid: ObjectId(result.assignpersonid)
                                        }
                                    }
                                ]

                                const taskAssignRecord = await SubDBPool[req.headers["subdomainname"]].getmenual("tbltaskassign", new _Task(), taskAssignPipeline)

                                if (taskAssignRecord.ResultData.length) {
                                    var taskAssignResult = taskAssignRecord.ResultData
                                    let objIndex = taskAssignResult.findIndex((obj) => obj._id.toString() == result._id.toString())
                                    var ind = 0
                                    for (var taskResult of taskAssignRecord.ResultData) {
                                        if (
                                            objIndex > ind &&
                                            taskResult.iscompleted != 1
                                            // !FieldConfig.completed.concat(FieldConfig.inspected, FieldConfig.reinspection).includes(taskResult.taskstatustype)
                                        ) {
                                            isStartTask = 0
                                        }
                                        ind++
                                    }
                                }
                            }
                        }

                        //End: Check previous forcefully profile task is completed or not
                    }

                    if (isStartTask) {
                        //Get task status data
                        var taskstatusPipeline = [{ $match: { taskcategoryid: ObjectId(result.categoryid), statustype: statustype } },
                        {
                            $sort: {
                                displayorder: 1
                            }
                        }]
                        const taskstatusResp = await SubDBPool[req.headers["subdomainname"]].getmenual("tbltaskstatusmaster", new TaskStatus(), taskstatusPipeline)

                        if (taskstatusResp.ResultData.length) {
                            var taskstatusid = ObjectId(taskstatusResp.ResultData[0]._id)
                            var taskstatus = taskstatusResp.ResultData[0].status
                            var taskstatustype = taskstatusResp.ResultData[0].statustype
                            var taskstatuscolor = taskstatusResp.ResultData[0].backgroundcolor
                            var taskstatussvg = taskstatusResp.ResultData[0].statussvg
                        } else {
                            var taskstatusid = ObjectId(Config.dummyObjid)
                            var taskstatus = statustype
                            var taskstatustype = statustype
                            var taskstatuscolor = Config.dummycolor
                            var taskstatussvg = ""
                        }

                        req.body.taskstatusid = taskstatusid
                        req.body.taskstatus = taskstatus
                        req.body.taskstatustype = taskstatustype
                        req.body.taskstatuscolor = taskstatuscolor

                        req.body.minutes = 0

                        // clock in - clock out condition
                        var clockoutdate = personResult.clockoutdate
                        var clockindate = personResult.clockindate
                        var lastclockinoutpropertyid = personResult.lastclockinoutpropertyid
                        var isclockin = 1
                        if (clockoutdate) {
                            isclockin = 0
                        } else if (!clockindate) {
                            isclockin = 0
                        }

                        if (isclockin == 1 && lastclockinoutpropertyid.toString() != result.propertyid.toString()) {
                            isclockin = 2
                        }

                        // clock in - clock out condition

                        //insert and updtae code 
                        let isvalid = 0
                        if (req.body.flag == 1 || req.body.flag == 3) {
                            if (req.body.flag == 3) {
                                var taskPipeline = [{ $match: { verifypersonid: ObjectId(req.headers.uid), verifyisstarttimer: 1 } }]
                            } else {
                                var taskPipeline = [{ $match: { assignpersonid: ObjectId(req.headers.uid), isstarttimer: 1 } }]
                            }

                            var taskResp = await SubDBPool[req.headers["subdomainname"]].getmenual("tbltaskassign", new _Task(), taskPipeline)

                            if (!taskResp.ResultData.length) {
                                var resp = await SubDBPool[req.headers["subdomainname"]].executedata("i", new _TaskStartStopLog(), TableName, req.body)
                                isvalid = 1
                            } else {
                                var resp = null
                                isvalid = -1
                            }
                        } else {
                            var pipeline_startstop = [
                                {
                                    $match: {
                                        taskid: new ObjectId(req.body.taskid),
                                        stoptime: null,
                                        "recordinfo.entryuid": req.headers.uid
                                    }
                                }
                            ]
                            const record = await SubDBPool[req.headers["subdomainname"]].getmenual(TableName, new _TaskStartStopLog(), pipeline_startstop)
                            //Update Stop time
                            if (record.ResultData.length > 0) {
                                req.body.recordinfo = {
                                    entryuid: record.ResultData[0].recordinfo.entryuid,
                                    entryby: record.ResultData[0].recordinfo.entryby,
                                    entrydate: record.ResultData[0].recordinfo.entrydate,
                                    timestamp: IISMethods.GetTimestamp(),
                                    isactive: 1,
                                    updateuid: req.headers.uid,
                                    updateby: req.headers.personname,
                                    updatedate: IISMethods.getdatetimestr()
                                }
                                req.body.starttime = record.ResultData[0].starttime
                                req.body.startlatitude = record.ResultData[0].startlatitude
                                req.body.startlongitude = record.ResultData[0].startlongitude
                                req.body.startbatterylevel = record.ResultData[0].startbatterylevel

                                // get minutes in task start and stop table
                                var pipelineStartStop = [
                                    {
                                        $match: {
                                            taskid: new ObjectId(req.body.taskid),
                                            stoptime: { $ne: null },
                                            "recordinfo.entryuid": req.headers.uid
                                        }
                                    }
                                ]
                                const recordStartStop = await SubDBPool[req.headers["subdomainname"]].getmenual(TableName, new _TaskStartStopLog(), pipelineStartStop)
                                var totalMinutes = 0
                                recordStartStop.ResultData.map((result) => {
                                    totalMinutes += parseInt(result.minutes)
                                })

                                var starttime = new Date(record.ResultData[0].starttime).getTime()
                                var endtime = new Date().getTime()

                                var diff = IISMethods.getTimeDifference(starttime, endtime)
                                var milliseconds = diff ? diff / 1000 : 0

                                req.body.milliseconds = parseInt(milliseconds)

                                var updatePipeline = [{ taskid: new ObjectId(req.body.taskid), stoptime: null, "recordinfo.entryuid": req.headers.uid }, { $set: req.body }]
                                var resp = await SubDBPool[req.headers["subdomainname"]].Update(TableName, new _TaskStartStopLog(), updatePipeline)

                                isvalid = 1
                            } else {
                                var resp = null
                                ResponseBody.status = 400
                                ResponseBody.message = Config.getErrmsg()["notexist"]
                            }
                        }

                        if (isclockin == 1) {

                            if (isvalid == 1) {

                                if (result.assignpersonid && result.assignpersonid != "") {
                                    let TaskLogPipeline = {
                                        userid: personResp.ResultData[0]._id,
                                        taskid: req.body.taskid
                                    }
                                    const TaskLogResp = await SubDBPool[req.headers["subdomainname"]].FindOne("tbltasklog", new _TaskLog(), TaskLogPipeline)
                                    if (!TaskLogResp) {
                                        let TaskStatusTypePipeline = {
                                            taskcategoryid: result.categoryid,
                                            taskstatustype: Config.newTaskStatusType[result.categoryid]?.open
                                        }
                                        const TaskStatusTypeResp = await MainDB.FindOne("tbltaskstatustype", new _TaskStatusType(), TaskStatusTypePipeline)
                                        taskstatustype = TaskStatusTypeResp.taskstatustype
                                        taskstatusid = TaskStatusTypeResp._id
                                        taskstatus = "Open"
                                    }
                                } else {
                                    let TaskLogPipeline = {
                                        userid: personResp.ResultData[0]._id,
                                        taskid: req.body.taskid
                                    }
                                    const TaskLogResp = await SubDBPool[req.headers["subdomainname"]].FindOne("tbltasklog", new _TaskLog(), TaskLogPipeline)
                                    if (!TaskLogResp) {
                                        let TaskStatusTypePipeline = {
                                            taskcategoryid: result.categoryid,
                                            taskstatustype: Config.newTaskStatusType[result.categoryid]?.unassigned
                                        }
                                        const TaskStatusTypeResp = await MainDB.FindOne("tbltaskstatustype", new _TaskStatusType(), TaskStatusTypePipeline)
                                        taskstatustype = TaskStatusTypeResp.taskstatustype
                                        taskstatusid = TaskStatusTypeResp._id
                                        taskstatus = "Unassigned"
                                    }
                                }
                                var reqData = {
                                    taskid: ObjectId(req.body.taskid),
                                    userid: ObjectId(personResp.ResultData[0]._id),
                                    username: personResp.ResultData[0].personname,
                                    datetime: new Date(),
                                    actionid: Config.dummyObjid,
                                    action_name: taskstatus,
                                    comment: "",
                                    taskstatustype: taskstatustype,
                                    taskstatusid: taskstatusid,
                                    taskstatus: taskstatus,
                                    logtype: 1,
                                    svg: taskstatussvg,
                                    flag: req.body.flag,
                                    recordinfo: req.body.recordinfo
                                }

                                await SubDBPool[req.headers["subdomainname"]].executedata("i", new _TaskLog(), "tbltasklog", reqData)

                                var setupdate = {}
                                setupdate.tasktime = new Date()
                                // If this task start first time then update the estimated
                                if (result.taskstatustype == Config.newTaskStatusType[result.categoryid]?.open && req.body.flag == 1) {
                                    var estimatetasktime = new Date()
                                    var minutes = 0
                                    if (result.estimatehours || result.estimateminutes) {
                                        minutes = result.estimatehours * 60 + result.estimateminutes
                                    } else if (result.subcategoryminute) {
                                        minutes = result.subcategoryminute
                                    }

                                    estimatetasktime.setMinutes(estimatetasktime.getMinutes() + parseInt(minutes))
                                    setupdate.estimatetasktime = estimatetasktime
                                }

                                if (req.body.flag == 3 || req.body.flag == 4 || req.body.flag == 5 || req.body.flag == 6) {
                                    // if (req.body.flag == 5 || req.body.flag == 6) {
                                    setupdate.inspectortask_completeddate = new Date()
                                    setupdate.taskstatusid = taskstatusid
                                    setupdate.taskstatus = taskstatus
                                    setupdate.taskstatustype = taskstatustype
                                    setupdate.taskstatuscolor = taskstatuscolor
                                    setupdate.isverify = isverify
                                    setupdate.iscompleted = iscompleted
                                    setupdate.isinspected = isinspected
                                    if (req.body.flag == 5) {
                                        setupdate.ishidestartbtn = ishidestartbtn
                                    }
                                    // }
                                    setupdate.verifyishidestartbtn = verifyishidestartbtn
                                    setupdate.verifytaskprogresstime = parseInt(req.body?.milliseconds ? req.body?.milliseconds : 0) + parseInt(verifyoldmillisecond)
                                    setupdate.verifylasttaskstarttime = verifylasttaskstarttime
                                    setupdate.verifyisstarttimer = verifyisstarttimer
                                } else {
                                    setupdate.taskstatusid = taskstatusid
                                    setupdate.taskstatus = taskstatus
                                    setupdate.taskstatustype = taskstatustype
                                    setupdate.taskstatuscolor = taskstatuscolor

                                    if (req.body.flag == 2) {
                                        setupdate.verifyishidestartbtn = verifyishidestartbtn
                                        setupdate.taskcompleteddate = new Date()
                                        setupdate.assigneetask_completeddate = new Date()
                                        setupdate.iscompleted = iscompleted
                                        setupdate.isinspected = isinspected

                                        //----------------------------------------------------------------------------------------------------------------------------
                                        setupdate.resolutionid = req.body.resolutionid
                                        setupdate.resolution = req.body.resolution
                                        setupdate.resolutionnotes = req.body.resolutionnotes

                                        const imageFiles = []
                                        let existingImages = result.images
                                        let existingResolutionImages = result.resolutionimages ? result.resolutionimages : []
                                        let imageLog = []

                                        if (req.files) {
                                            const allFile = req.files
                                            let objKeys = Object.keys(allFile);

                                            let count = 0
                                            let tempFile = []
                                            objKeys.forEach(async key => {
                                                tempFile[count] = IISMethods.uploadToS3(allFile[key], req.headers.subdomainname + "/" + "taskstartstop/" + Date.now())
                                                count++
                                            });
                                            const size = allFile.length
                                            tempFile = await Promise.all(tempFile)

                                            for (let i = 0; i < tempFile.length; i++) {
                                                existingImages.push({ uploadedbypersonid: req.headers.uid, uploadedbypersonname: req.headers.personname, image: tempFile[i] })
                                                existingResolutionImages.push({ image: tempFile[i] })
                                                imageLog.push({ image: tempFile[i] })
                                            }
                                        }
                                        setupdate.images = existingImages
                                        setupdate.resolutionimages = existingResolutionImages

                                        const resData = {
                                            taskid: req.body.taskid,
                                            userid: req.headers.uid,
                                            username: req.headers.personname,
                                            resolutionid: req.body.resolutionid,
                                            resolution: req.body.resolution,
                                            imagedata: imageLog,
                                            notes: req.body.resolutionnotes,
                                            recordinfo: req.body.recordinfo
                                        }
                                        await SubDBPool[req.headers["subdomainname"]].executedata("i", new _ResolutionLog(), "tblresolutionlog", resData)

                                        //----------------------------------------------------------------------------------------------------------------------------                                                     

                                    }

                                    setupdate.taskprogresstime = parseInt(req.body?.milliseconds ? req.body?.milliseconds : 0) + parseInt(oldmillisecond)
                                    setupdate.lasttaskstarttime = lasttaskstarttime
                                    setupdate.taskstarttime = taskstarttime
                                    setupdate.isstarttimer = isstarttimer
                                    setupdate.ishidestartbtn = ishidestartbtn
                                }

                                const taskPipeline = [{ _id: new ObjectId(req.body.taskid) }, { $set: setupdate }]
                                await SubDBPool[req.headers["subdomainname"]].Update("tbltaskassign", new _Task(), taskPipeline)

                                // var ishousekeeping_or_maintainance  = 0
                                // if (req.body.categoryid.toString() == Config.taskcategory.housekeeper.toString()) {
                                //     ishousekeeping_or_maintainance = 1
                                // }else if (req.body.categoryid.toString() == Config.taskcategory.maintenance.toString()) {
                                //     ishousekeeping_or_maintainance = 2
                                // }else if (req.body.categoryid.toString() == Config.taskcategory.other.toString()) {
                                //     ishousekeeping_or_maintainance = 3
                                // }

                                var tabid = 0
                                var tabname = ""
                                let socketdata = []
                                if (result.assignpersonid) {
                                    tabid = "1"
                                    tabname = "Task"
                                    socketdata.push({
                                        categoryid: req.body.categoryid,
                                        tabid: tabid,
                                        tabname: tabname
                                    })
                                }
                                if (!result.assignpersonid) {
                                    tabid = "2"
                                    tabname = "Unassigned Task"
                                    socketdata.push({
                                        categoryid: req.body.categoryid,
                                        tabid: tabid,
                                        tabname: tabname
                                    })
                                }
                                if ((req.headers.uid.toString() != result.assignpersonid.toString()) && (result.assignpersonid.toString() != Config.dummyObjid) && result.assignpersonid.toString()) {
                                    tabid = "3"
                                    tabname = "Assignby Me"
                                    socketdata.push({
                                        categoryid: req.body.categoryid,
                                        tabid: tabid,
                                        tabname: tabname
                                    })
                                }

                                /** Send Notification On Task Action */
                                let roomarea = ""
                                if (result.roomno) {
                                    roomarea = ` room ${result.roomno}.`
                                } else if (result.area) {
                                    roomarea = ` area ${result.area}.`
                                }

                                let roomActionId = ""
                                if (result.categoryid == Config.taskcategory.housekeeper) {
                                    roomActionId = FieldConfig.roomaction.housekeeping
                                } else if (result.categoryid == Config.taskcategory.deposit) {
                                    roomActionId = FieldConfig.roomaction.deposit
                                } else if (result.categoryid == Config.taskcategory.request) {
                                    roomActionId = FieldConfig.roomaction.request
                                } else if (result.categoryid == Config.taskcategory.maintenance) {
                                    roomActionId = FieldConfig.roomaction.maintenance
                                } else if (result.categoryid == Config.taskcategory.deepcleaning) {
                                    roomActionId = FieldConfig.roomaction.deepcleanning
                                } else if (result.categoryid == Config.taskcategory.premaintanance) {
                                    roomActionId = FieldConfig.roomaction.premaintenance
                                } else if (result.categoryid == Config.taskcategory.frontdesk) {
                                    roomActionId = FieldConfig.roomaction.frontdeskalert
                                }

                                const notificationData = {
                                    pagename: req.headers.pagename,
                                    _id: result._id.toString(),
                                    image: "",
                                    categoryid: result.categoryid.toString(),
                                    tasktype: result.tasktype,
                                    time: new Date().toISOString(),
                                    description: result.description || result.specialtask || result.comment || "",
                                    flag: "1",
                                    propertyid: result.propertyid ? result.propertyid.toString() : "",
                                    buildingid: result.buildingid ? result.buildingid.toString() : "",
                                    wingid: result.wingid ? result.wingid.toString() : "",
                                    roomactionid: roomActionId ? roomActionId : Config.dummyObjid
                                }

                                const notificationObj = {
                                    notificationtype: 0,
                                    task: result.subcategory,
                                    taskid: result._id.toString(),
                                    taskcategoryid: result.categoryid.toString(),
                                    tasktype: result.tasktype,
                                    acceptflag: 1,
                                    imageflag: 0,
                                    image_or_alphabet: "",
                                    clickflag: 1,
                                    description: result.description || result.specialtask || result.comment || "",
                                    time: new Date(),
                                    recordinfo: req.body.recordinfo
                                }

                                if (result.roomno) {
                                    notificationData.room_or_area = result.roomno
                                    notificationData.roomtype = result.roomtype
                                    notificationData.roomnoid = result.roomnoid.toString()
                                    notificationData.room_or_area_flag = "1"
                                    notificationObj.type = 0
                                    notificationObj.room_or_area = result.roomno
                                    notificationObj.roomtype = result.roomtype
                                } else if (result.area) {
                                    notificationData.room_or_area = result.area
                                    notificationData.roomtype = result.areatype
                                    notificationData.roomnoid = result.areaid.toString()
                                    notificationData.room_or_area_flag = "2"
                                    notificationObj.type = 1
                                    notificationObj.room_or_area = result.area
                                    notificationObj.roomtype = result.areatype
                                } else {
                                    notificationData.room_or_area = ""
                                    notificationData.roomtype = ""
                                    notificationData.room_or_area_flag = "3"
                                    notificationObj.type = 2
                                    notificationObj.room_or_area = ""
                                    notificationObj.roomtype = ""
                                }

                                // Notification On Flag base
                                if (req.body.flag == 0) {
                                    const title = `Task paused by you in ${roomarea}`
                                    const body = result.assignperson

                                    notificationData.title = title
                                    notificationObj.title = title

                                    const notificationArray = []

                                    const notificationAlias = MainDB.getNotificationAlias(result.categoryid)
                                    const notisettingResp = await SubDBPool[req.headers["subdomainname"]].getmenual("tblnotificationsetting", new _NotificatioSetting(), [
                                        {
                                            $match: { personid: result.assignpersonid, alias: notificationAlias.alias }
                                        },
                                        { $unwind: "$statusarray" },
                                        {
                                            $match: {
                                                "statusarray.statustype": Config.newTaskStatusType[result.categoryid]?.paused,
                                                "statusarray.isselected": 1
                                            }
                                        },
                                        { $group: { _id: "$personid" } }
                                    ])

                                    const userids = notisettingResp.ResultData.map((obj) => obj._id.toString())
                                    const tokens = await SubDBPool[req.headers["subdomainname"]].getDeviceTokens({
                                        userids,
                                        moduletypeid: [Config.moduletype[req.headers.moduletype], Config.moduletype["web"]]
                                    })

                                    if (tokens.length) {
                                        // userids.forEach((id) => {
                                        //     notificationObj.userid = id
                                        //     notificationArray.push(notificationObj)
                                        // })
                                        notificationObj.userids = userids
                                        notificationArray.push(notificationObj)

                                        // FIREBASE PUSH NOTIFICATION
                                        await IISMethods.sendPushNotification(tokens, title, body, notificationData)
                                        await SubDBPool[req.headers["subdomainname"]].InsertMany("tblnotification", new _Notification(), notificationArray)
                                    }
                                } else if (req.body.flag == 1) {
                                    const title = `Task started by you in ${roomarea}`
                                    const body = result.assignperson

                                    notificationData.title = title
                                    notificationObj.title = title

                                    const notificationArray = []

                                    const notificationAlias = MainDB.getNotificationAlias(result.categoryid)
                                    const notisettingResp = await SubDBPool[req.headers["subdomainname"]].getmenual("tblnotificationsetting", new _NotificatioSetting(), [
                                        {
                                            $match: { personid: result.assignpersonid, alias: notificationAlias.alias }
                                        },
                                        { $unwind: "$statusarray" },
                                        {
                                            $match: {
                                                "statusarray.statustype": Config.newTaskStatusType[result.categoryid]?.inprogress,
                                                "statusarray.isselected": 1
                                            }
                                        },
                                        { $group: { _id: "$personid" } }
                                    ])

                                    const userids = notisettingResp.ResultData.map((obj) => obj._id.toString())
                                    const tokens = await SubDBPool[req.headers["subdomainname"]].getDeviceTokens({
                                        userids,
                                        moduletypeid: [Config.moduletype[req.headers.moduletype], Config.moduletype["web"]]
                                    })

                                    if (tokens.length) {
                                        // userids.forEach((id) => {
                                        //     notificationObj.userid = id
                                        //     notificationArray.push(notificationObj)
                                        // })
                                        notificationObj.userids = userids
                                        notificationArray.push(notificationObj)

                                        // FIREBASE PUSH NOTIFICATION
                                        await IISMethods.sendPushNotification(tokens, title, body, notificationData)
                                        await SubDBPool[req.headers["subdomainname"]].InsertMany("tblnotification", new _Notification(), notificationArray)
                                    }
                                } else if (req.body.flag == 2) {
                                    // Complete Task

                                    //CheckList Log
                                    const getChecklistLogPipeline = { taskid: req.body.taskid }
                                    const getTaskChecklistLog = await SubDBPool[req.headers["subdomainname"]].FindOne(
                                        "tbltaskchecklistlogs",
                                        new TaskCheckListLog(),
                                        getChecklistLogPipeline
                                    )

                                    if (getTaskChecklistLog) {
                                        var updateTaskCheckListLogData = {
                                            _id: getTaskChecklistLog._id,
                                            checklists: result.checklists,
                                            recordinfo: {
                                                entryuid: getTaskChecklistLog.recordinfo.entryuid,
                                                entryby: getTaskChecklistLog.recordinfo.entryby,
                                                entrydate: getTaskChecklistLog.recordinfo.entrydate,
                                                timestamp: IISMethods.GetTimestamp(),
                                                isactive: 1,
                                                updateuid: req.headers.uid,
                                                updateby: req.headers.personname,
                                                updatedate: IISMethods.getdatetimestr()
                                            }
                                        }
                                        await SubDBPool[req.headers["subdomainname"]].executedata(
                                            "u",
                                            new TaskCheckListLog(),
                                            "tbltaskchecklistlogs",
                                            updateTaskCheckListLogData
                                        )
                                    } else {
                                        var insertTaskCheckListLogData = {
                                            taskid: result._id,
                                            assignpersonid: result.assignpersonid,
                                            assignperson: result.assignperson,
                                            checklists: result.checklists,
                                            verifypersonid: Config.dummyObjid,
                                            verifyperson: "",
                                            verifychecklists: [],
                                            recordinfo: {
                                                entryuid: req.headers.uid,
                                                entryby: req.headers.personname,
                                                entrydate: IISMethods.getdatetimestr(),
                                                timestamp: IISMethods.GetTimestamp(),
                                                isactive: 1,
                                                updateuid: " ",
                                                updateby: " ",
                                                updatedate: " "
                                            }
                                        }

                                        await SubDBPool[req.headers["subdomainname"]].executedata(
                                            "i",
                                            new TaskCheckListLog(),
                                            "tbltaskchecklistlogs",
                                            insertTaskCheckListLogData
                                        )
                                    }

                                    // Start: Only sent notification to Assignee person
                                    const _title = `Task completed by you in ${roomarea}`
                                    const _body = result.assignperson

                                    notificationData.title = _title
                                    notificationObj.title = _title

                                    const _notificationArray = []

                                    var _completed = await SubDBPool[req.headers["subdomainname"]].getTaskCompletionStatus(result.subcategoryid, result.categoryid)
                                    const _notificationAlias = MainDB.getNotificationAlias(result.categoryid)
                                    const _notisettingResp = await SubDBPool[req.headers["subdomainname"]].getmenual("tblnotificationsetting", new _NotificatioSetting(), [
                                        {
                                            $match: { personid: result.assignpersonid, alias: _notificationAlias.alias }
                                        },
                                        { $unwind: "$statusarray" },
                                        {
                                            $match: {
                                                "statusarray.statustype": _completed,
                                                "statusarray.isselected": 1
                                            }
                                        },
                                        { $group: { _id: "$personid" } }
                                    ])

                                    const _userids = _notisettingResp.ResultData.map((obj) => obj._id.toString())
                                    const _tokens = await SubDBPool[req.headers["subdomainname"]].getDeviceTokens({
                                        userids: _userids,
                                        moduletypeid: [Config.moduletype[req.headers.moduletype], Config.moduletype["web"]]
                                    })

                                    if (_tokens.length) {
                                        // _userids.forEach((id) => {
                                        //     notificationObj.userid = id
                                        //     _notificationArray.push(notificationObj)
                                        // })
                                        notificationObj.userids = _userids
                                        _notificationArray.push(notificationObj)

                                        // FIREBASE PUSH NOTIFICATION
                                        await IISMethods.sendPushNotification(_tokens, _title, _body, notificationData)
                                        await SubDBPool[req.headers["subdomainname"]].InsertMany("tblnotification", new _Notification(), _notificationArray)
                                    }

                                    // End: Only sent notification to Assignee person

                                    const title = `Task completed by ${result.assignperson} in ${roomarea}`
                                    const body = result.assignperson

                                    notificationData.title = title
                                    notificationObj.title = title

                                    let personIds = []

                                    // Firebase Push Notification For Complete Task
                                    if (result.notifyifdone) {
                                        if (result.notifyifdonepersons.length) {
                                            personIds.push(...result.notifyifdonepersons.map((obj) => obj.personid))
                                        } else if (result.notifyifdonedepartment.length) {
                                            const departmentIds = result.notifyifdonedepartment.map((obj) => obj.departmentid)

                                            const personPipeline = [{ $match: { "department.departmentid": { $in: departmentIds } } }, { $project: { _id: 1 } }]
                                            const personResp = await SubDBPool[req.headers["subdomainname"]].getmenual("tblpersonmaster", new _Person(), personPipeline)

                                            personIds.push(...personResp.ResultData.map((person) => person._id))
                                        }
                                    }

                                    // Firebase Push Notification For Dual Authentication Task
                                    if (result.dualauthentication) {
                                        if (result.dualauthenticationpersons.length) {
                                            personIds.push(...result.dualauthenticationpersons.map((obj) => obj.personid))
                                        } else if (result.dualauthenticationdepartment.length) {
                                            const departmentIds = result.dualauthenticationdepartment.map((obj) => obj.departmentid)

                                            const personPipeline = [{ $match: { "department.departmentid": { $in: departmentIds } } }, { $project: { _id: 1 } }]
                                            const personResp = await SubDBPool[req.headers["subdomainname"]].getmenual("tblpersonmaster", new _Person(), personPipeline)

                                            personIds.push(...personResp.ResultData.map((person) => person._id))
                                        }
                                    }

                                    // Firebase Push Notification For Dual Authentication with Photo Task
                                    if (result.dualauthenticationwithphoto) {
                                        if (result.dualauthenticationwithphotopersons.length) {
                                            personIds.push(...result.dualauthenticationwithphotopersons.map((obj) => obj.personid))
                                        } else if (result.dualauthenticationwithphotodepartment.length) {
                                            const departmentIds = result.dualauthenticationwithphotodepartment.map((obj) => obj.departmentid)

                                            const personPipeline = [{ $match: { "department.departmentid": { $in: departmentIds } } }, { $project: { _id: 1 } }]
                                            const personResp = await SubDBPool[req.headers["subdomainname"]].getmenual("tblpersonmaster", new _Person(), personPipeline)

                                            personIds.push(...personResp.ResultData.map((person) => person._id))
                                        }
                                    }

                                    personIds = personIds.filter((id, i) => personIds.indexOf(id) === i)

                                    var _completed = await SubDBPool[req.headers["subdomainname"]].getTaskCompletionStatus(result.subcategoryid, result.categoryid)
                                    const notificationAlias = MainDB.getNotificationAlias(result.categoryid)
                                    const notisettingResp = await SubDBPool[req.headers["subdomainname"]].getmenual("tblnotificationsetting", new _NotificatioSetting(), [
                                        {
                                            $match: { personid: { $in: personIds }, alias: notificationAlias.alias }
                                        },
                                        { $unwind: "$statusarray" },
                                        {
                                            $match: {
                                                "statusarray.statustype": _completed,
                                                "statusarray.isselected": 1
                                            }
                                        },
                                        { $group: { _id: "$personid" } }
                                    ])

                                    const userids = notisettingResp.ResultData.map((obj) => obj._id.toString())

                                    const notificationArray = []
                                    const tokens = await SubDBPool[req.headers["subdomainname"]].getDeviceTokens({
                                        userids,
                                        moduletypeid: [Config.moduletype[req.headers.moduletype], Config.moduletype["web"]]
                                    })

                                    if (tokens.length) {
                                        // userids.forEach((id) => {
                                        //     notificationObj.userid = id
                                        //     notificationArray.push(notificationObj)
                                        // })
                                        notificationObj.userids = userids
                                        notificationArray.push(notificationObj)

                                        // FIREBASE PUSH NOTIFICATION
                                        await IISMethods.sendPushNotification(tokens, title, body, notificationData)
                                    }

                                    if (notificationArray.length) {
                                        await SubDBPool[req.headers["subdomainname"]].InsertMany("tblnotification", new _Notification(), "tblnotification", notificationArray)
                                    }
                                } else if (req.body.flag == 3) {
                                    const title = `Task started by you in ${roomarea}`
                                    const body = result.verifyperson

                                    notificationData.title = title
                                    notificationObj.title = title

                                    const notificationArray = []

                                    const notificationAlias = MainDB.getNotificationAlias(result.categoryid)
                                    const notisettingResp = await SubDBPool[req.headers["subdomainname"]].getmenual("tblnotificationsetting", new _NotificatioSetting(), [
                                        {
                                            $match: { personid: result.verifypersonid, alias: notificationAlias.alias }
                                        },
                                        { $unwind: "$statusarray" },
                                        {
                                            $match: {
                                                "statusarray.statustype": Config.newTaskStatusType[result.categoryid].inprogress,
                                                "statusarray.isselected": 1
                                            }
                                        },
                                        { $group: { _id: "$personid" } }
                                    ])

                                    const userids = notisettingResp.ResultData.map((obj) => obj._id.toString())
                                    const tokens = await SubDBPool[req.headers["subdomainname"]].getDeviceTokens({
                                        userids,
                                        moduletypeid: [Config.moduletype[req.headers.moduletype], Config.moduletype["web"]]
                                    })

                                    if (tokens.length) {
                                        // userids.forEach((id) => {
                                        //     notificationObj.userid = id
                                        //     notificationArray.push(notificationObj)
                                        // })
                                        notificationObj.userids = userids
                                        notificationArray.push(notificationObj)

                                        // FIREBASE PUSH NOTIFICATION
                                        await IISMethods.sendPushNotification(tokens, title, body, notificationData)
                                        await SubDBPool[req.headers["subdomainname"]].InsertMany("tblnotification", new _Notification(), notificationArray)
                                    }
                                } else if (req.body.flag == 4) {
                                    const title = `Task paused by you in ${roomarea}`
                                    const body = result.verifyperson

                                    notificationData.title = title
                                    notificationObj.title = title

                                    const notificationArray = []

                                    const notificationAlias = MainDB.getNotificationAlias(result.categoryid)
                                    const notisettingResp = await SubDBPool[req.headers["subdomainname"]].getmenual("tblnotificationsetting", new _NotificatioSetting(), [
                                        {
                                            $match: { personid: result.verifypersonid, alias: notificationAlias.alias }
                                        },
                                        { $unwind: "$statusarray" },
                                        {
                                            $match: {
                                                "statusarray.statustype": Config.newTaskStatusType[result.categoryid].paused,
                                                "statusarray.isselected": 1
                                            }
                                        },
                                        { $group: { _id: "$personid" } }
                                    ])

                                    const userids = notisettingResp.ResultData.map((obj) => obj._id.toString())
                                    const tokens = await SubDBPool[req.headers["subdomainname"]].getDeviceTokens({
                                        userids,
                                        moduletypeid: [Config.moduletype[req.headers.moduletype], Config.moduletype["web"]]
                                    })

                                    if (tokens.length) {
                                        // userids.forEach((id) => {
                                        //     notificationObj.userid = id
                                        //     notificationArray.push(notificationObj)
                                        // })

                                        notificationObj.userids = userids
                                        notificationArray.push(notificationObj)

                                        // FIREBASE PUSH NOTIFICATION
                                        await IISMethods.sendPushNotification(tokens, title, body, notificationData)
                                        await SubDBPool[req.headers["subdomainname"]].InsertMany("tblnotification", new _Notification(), notificationArray)
                                    }
                                } else if (req.body.flag === 5) {
                                    // Revisit Task
                                    //Update Task Checklist log
                                    const getChecklistLogPipeline = { taskid: req.body.taskid }
                                    const getTaskChecklistLog = await SubDBPool[req.headers["subdomainname"]].FindOne(
                                        "tbltaskchecklistlogs",
                                        new TaskCheckListLog(),
                                        getChecklistLogPipeline
                                    )

                                    if (getTaskChecklistLog) {
                                        var updateTaskCheckListLogData = {
                                            _id: getTaskChecklistLog._id,
                                            verifypersonid: result.verifypersonid,
                                            verifyperson: result.verifyperson,
                                            verifychecklists: result.checklists,
                                            recordinfo: {
                                                entryuid: getTaskChecklistLog.recordinfo.entryuid,
                                                entryby: getTaskChecklistLog.recordinfo.entryby,
                                                entrydate: getTaskChecklistLog.recordinfo.entrydate,
                                                timestamp: IISMethods.GetTimestamp(),
                                                isactive: 1,
                                                updateuid: req.headers.uid,
                                                updateby: req.headers.personname,
                                                updatedate: IISMethods.getdatetimestr()
                                            }
                                        }
                                        await SubDBPool[req.headers["subdomainname"]].executedata(
                                            "u",
                                            new TaskCheckListLog(),
                                            "tbltaskchecklistlogs",
                                            updateTaskCheckListLogData
                                        )
                                    }

                                    const title = `Task reassigned by ${result.verifyperson} in ${roomarea}`
                                    const body = result.assignperson

                                    notificationData.title = title
                                    notificationObj.title = title

                                    const notificationArray = []

                                    const notificationAlias = MainDB.getNotificationAlias(result.categoryid)
                                    const notisettingResp = await SubDBPool[req.headers["subdomainname"]].getmenual("tblnotificationsetting", new _NotificatioSetting(), [
                                        {
                                            $match: { personid: result.assignpersonid, alias: notificationAlias.alias }
                                        },
                                        { $unwind: "$statusarray" },
                                        {
                                            $match: {
                                                "statusarray.statustype": Config.newTaskStatusType[result.categoryid].revisit,
                                                "statusarray.isselected": 1
                                            }
                                        },
                                        { $group: { _id: "$personid" } }
                                    ])

                                    const userids = notisettingResp.ResultData.map((obj) => obj._id.toString())
                                    const tokens = await SubDBPool[req.headers["subdomainname"]].getDeviceTokens({
                                        userids,
                                        moduletypeid: [Config.moduletype[req.headers.moduletype], Config.moduletype["web"]]
                                    })

                                    if (tokens.length) {
                                        // userids.forEach((id) => {
                                        //     notificationObj.userid = id
                                        //     notificationArray.push(notificationObj)
                                        // })
                                        notificationObj.userids = userids
                                        notificationArray.push(notificationObj)

                                        // FIREBASE PUSH NOTIFICATION
                                        await IISMethods.sendPushNotification(tokens, title, body, notificationData)

                                        await SubDBPool[req.headers["subdomainname"]].InsertMany("tblnotification", new _Notification(), notificationArray)
                                    }
                                } else if (req.body.flag === 6) {
                                    // Inspected Task
                                    //Update Task Checklist log
                                    const getChecklistLogPipeline = { taskid: req.body.taskid }
                                    const getTaskChecklistLog = await SubDBPool[req.headers["subdomainname"]].FindOne(
                                        "tbltaskchecklistlogs",
                                        new TaskCheckListLog(),
                                        getChecklistLogPipeline
                                    )

                                    if (getTaskChecklistLog) {
                                        var updateTaskCheckListLogData = {
                                            _id: getTaskChecklistLog._id,
                                            verifypersonid: result.verifypersonid,
                                            verifyperson: result.verifyperson,
                                            verifychecklists: result.checklists,
                                            recordinfo: {
                                                entryuid: getTaskChecklistLog.recordinfo.entryuid,
                                                entryby: getTaskChecklistLog.recordinfo.entryby,
                                                entrydate: getTaskChecklistLog.recordinfo.entrydate,
                                                timestamp: IISMethods.GetTimestamp(),
                                                isactive: 1,
                                                updateuid: req.headers.uid,
                                                updateby: req.headers.personname,
                                                updatedate: IISMethods.getdatetimestr()
                                            }
                                        }
                                        await SubDBPool[req.headers["subdomainname"]].executedata(
                                            "u",
                                            new TaskCheckListLog(),
                                            "tbltaskchecklistlogs",
                                            updateTaskCheckListLogData
                                        )
                                    }

                                    const title = `Task inspected by ${result.verifyperson} in ${roomarea}`
                                    const body = result.verifyperson

                                    notificationData.title = title
                                    notificationObj.title = title

                                    const notificationArray = []

                                    const notificationAlias = MainDB.getNotificationAlias(result.categoryid)
                                    const notisettingResp = await SubDBPool[req.headers["subdomainname"]].getmenual("tblnotificationsetting", new _NotificatioSetting(), [
                                        {
                                            $match: { personid: result.assignpersonid, alias: notificationAlias.alias }
                                        },
                                        { $unwind: "$statusarray" },
                                        {
                                            $match: {
                                                "statusarray.statustype": Config.newTaskStatusType[result.categoryid].inspected,
                                                "statusarray.isselected": 1
                                            }
                                        },
                                        { $group: { _id: "$personid" } }
                                    ])

                                    const userids = notisettingResp.ResultData.map((obj) => obj._id.toString())
                                    const tokens = await SubDBPool[req.headers["subdomainname"]].getDeviceTokens({
                                        userids,
                                        moduletypeid: [Config.moduletype[req.headers.moduletype], Config.moduletype["web"]]
                                    })

                                    if (tokens.length) {
                                        // userids.forEach((id) => {
                                        //     notificationObj.userid = id
                                        //     notificationArray.push(notificationObj)
                                        // })

                                        notificationObj.userids = userids
                                        notificationArray.push(notificationObj)

                                        // FIREBASE PUSH NOTIFICATION
                                        await IISMethods.sendPushNotification(tokens, title, body, notificationData)

                                        await SubDBPool[req.headers["subdomainname"]].InsertMany("tblnotification", new _Notification(), notificationArray)
                                    }
                                }
                                /** End of Notification On Task Action */
                                ResponseBody.status = resp.status
                                ResponseBody.message = resp.message
                            } else if (isvalid == -1) {
                                ResponseBody.status = 400
                                ResponseBody.message = Config.getErrmsg()["anothertaskrunning"]
                            }

                        } else {
                            if (isclockin == 2) {
                                ResponseBody.status = 400
                                ResponseBody.message = properyvalidationmessage
                            } else {
                                ResponseBody.status = 400
                                ResponseBody.message = clockinvalidationmessage
                            }

                        }
                    } else {
                        ResponseBody.status = 400
                        ResponseBody.message = Config.getErrmsg()["pendingtask"]
                    }

                    //insert and update code
                }
            }

            req.ResponseBody = ResponseBody; next()
        } catch (err) {
            
            const ResponseBody = {}
            ResponseBody.status = 500
            ResponseBody.message = Config.getResponsestatuscode()["500"]

            req.ResponseBody = ResponseBody; next()
        }
    }
    //List
    // async TaskProcessLogList(req, res, next) {
    //     try {
    //         const ResponseBody = {}

    //         const Pipeline = [
    //             {
    //                 $project: {
    //                     categoryid: 1,
    //                     taskstatusid: 1,
    //                     taskstatus: 1,
    //                     taskstatustype: 1
    //                 }
    //             }
    //         ]
    //         const resp = await SubDBPool[req.headers["subdomainname"]].getmenual(TableName, new _Task(), Pipeline)

    //         const TaskLogPipeline = [
    //             {
    //                 $project: {
    //                     taskid: 1,
    //                     userid: 1,
    //                     datetime: 1,
    //                     taskstatusid: 1,
    //                     taskstatustype: 1,
    //                     taskstatus: 1
    //                 }
    //             }
    //         ]
    //         const TaskLogResp = await SubDBPool[req.headers["subdomainname"]].getmenual("tbltasklog", new _TaskLog(), TaskLogPipeline)

    //         const TaskStatusTypePipeline = [{ $match: { taskcategoryid: { $type: 7 } } }]
    //         const TaskStatusTypeResp = await MainDB.getmenual("tbltaskstatustype", new _TaskStatusType(), TaskStatusTypePipeline)
    //         let TaskStatus = ""

    //         resp.ResultData.forEach((task) => {
    //             const FindTaskLog = TaskLogResp.ResultData.filter((tasklog) => tasklog.taskid.toString() === task._id.toString())
    //             if (FindTaskLog.length > 0) {
    //                 FindTaskLog.sort((a, b) => b.datetime.toString() - a.datetime.toString())

    //                 const FindTaskStatusType = TaskStatusTypeResp.ResultData.filter((taskstatustype) => taskstatustype.taskcategoryid == task.categoryid)

    //                 TaskStatus = FindTaskStatusType.find((taskstatustype) => taskstatustype._id == FindTaskLog[0].taskstatusid)
    //             }
    //         })

    //         ResponseBody.status = 200
    //         ResponseBody.message = Config.getResponsestatuscode()["200"]
    //         ResponseBody.data = TaskStatus

    //         req.ResponseBody = ResponseBody; next()
    //     } catch (err) {
    //         
    //         req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }; next()
    //     }
    // }

   
}



// let TaskstatusLogPipeline = [
//     {
//         $match: {
//             userid: ObjectId(personResp.ResultData[0]._id),
//             taskstatusid: ObjectId(taskstatusid)
//         }
//     },
//     {
//         $sort: { _id: -1 }
//     },
//     {
//         $limit: 1
//     }
// ]
// const TaskstatusLogResp = await SubDBPool[req.headers["subdomainname"]].getmenual("tbltasklog", new _TaskLog(), TaskstatusLogPipeline)

// const TaskStatusRecord = TaskstatusLogResp.ResultData[0]

// var TaskStatusPipeline = [{ $match: { taskcategoryid: ObjectId(TaskRecord.categoryid) } }]
// const TaskStatusResp = await MainDB.getmenual("tbltaskstatustype", new _TaskStatusType(), TaskStatusPipeline)
// var taskstatustype
// if (TaskStatusRecord.userid && TaskStatusRecord.userid.toString() == personResp.ResultData[0]._id.toString()) {
//     taskstatustype = TaskStatusResp.ResultData.find((taskstatus) => taskstatus.taskstatustype == "open")
// } else {
//     taskstatustype = TaskStatusResp.ResultData.find((taskstatus) => taskstatus.taskstatustype == "unassigned")
// }

// let StartTime = new Date(TaskStatusRecord.datetime).getTime()
// let EndTime = new Date().getTime()
// const TaskStatusLogTime = IISMethods.getTimeDifference(StartTime, EndTime)

// TaskRecord.taskstatuslog.forEach((taskstatus) => {
//     if (taskstatus.taskstatusid.toString() == taskstatusid.toString()) taskstatus.taskstatuslogtime = TaskStatusLogTime
// })

// await SubDBPool[req.headers["subdomainname"]].executedata("u", new _Task(), "tbltaskassign", TaskRecord)
// await SubDBPool[req.headers["subdomainname"]].executedata("i", new _TaskLog(), "tbltasklog", reqData)