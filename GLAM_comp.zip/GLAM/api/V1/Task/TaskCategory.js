import { MainDB, IISMethods, Config, FieldConfig } from "../../../config/Init.js"
import { _TaskCategory } from "../../../model/Task/TaskCategory.js"
import _CategoryConfiguration from "../../../model/Task/CategoryConfiguration.js"
import _Userrights from "../../../model/masters/UserManagement/Userrights.js"


const TableName = "tbltaskcategory"
const PageName = "Category"
const FormName = "Category"
const FltPageCollection = "taskcategory"
export default class TaskCategory {
    // START Task category
    async ListTaskCategory(req, res, next) {
        try {
            const ResponseBody = {}
            const ObjectId = IISMethods.getobjectid()

            const searchtext = req.body.searchtext || ""
            var PaginationInfo = req.body.paginationinfo
            var projection = PaginationInfo.projection
            var propertyid = PaginationInfo.filter.propertyid
            delete PaginationInfo.filter.propertyid

            let objalias = []
            let pipeline = []
            var isAdmin = await MainDB.IsAdmin(req.headers.uid)

            if (!isAdmin) {

                const personResp = await MainDB.getPersonData({apptype: req.headers.apptype, personid: [req.headers.uid]})
                const personUserRoleId = personResp[0]?.userrole?.map((userrole) => userrole.userroleid)

                if (req.headers.platform == 1) {

                    const userrightsByPersonPipeline = [
                        {
                            $match: {
                                moduletypeid: Config.moduletype["web"],
                                propertyid: propertyid,
                                personid: req.headers.uid
                            }
                        },
                        { $match: { $or: [{ allviewright: 1 }, { selfviewright: 1 }] } }
                    ]
                    const userrightsByPerson = await MainDB.getmenual("tbluserrights", new _Userrights(), userrightsByPersonPipeline)
                    objalias = userrightsByPerson.ResultData.map((taskalias) => taskalias.alias)
                    console.log("👉 ~ file: TaskCategory.js:49 ~ TaskCategory ~ ListTaskCategory ~ objalias:", objalias)

                    if (objalias.length) {
                        pipeline.push({ $match: { alias: { $in: objalias } } })
                    } else {
                        // User rights by userrole
                        const userrightsByUserrolePipeline = [
                            {
                                $match: {
                                    userroleid: { $in: personUserRoleId?.map((obj) => obj.toString()) },
                                    propertyid: propertyid,
                                    moduletypeid: Config.moduletype["web"]
                                }
                            },
                            { $match: { $or: [{ allviewright: 1 }, { selfviewright: 1 }] } }
                        ]
                        const userrightsByUserrole = await MainDB.getmenual("tbluserrights", new _Userrights(), userrightsByUserrolePipeline)
                        objalias = userrightsByUserrole.ResultData.map((taskalias) => taskalias.alias)
                        pipeline.push({ $match: { alias: { $in: objalias } } })
                    }
                } else if (req.headers.platform == 2) {
                    const userrightsByPersonPipeline = [
                        {
                            $match: {
                                moduletypeid: Config.moduletype["app"],
                                propertyid: propertyid,
                                personid: req.headers.uid,
                            }
                        },
                        { $match: { $or: [{ allviewright: 1 }, { selfviewright: 1 }] } }
                    ]
                    const userrightsByPerson = await MainDB.getmenual("tbluserrights", new _Userrights(), userrightsByPersonPipeline)
                    objalias = userrightsByPerson.ResultData.map((taskalias) => taskalias.alias)

                    if (objalias.length) {
                        pipeline.push({ $match: { alias: { $in: objalias } } })
                    } else {
                        // User rights by userrole
                        const userrightsByUserrolePipeline = [
                            {
                                $match: {
                                    userroleid: { $in: personUserRoleId.map((obj) => obj.toString()) },
                                    propertyid: propertyid,
                                    moduletypeid: Config.moduletype["app"],
                                }
                            },
                            { $match: { $or: [{ allviewright: 1 }, { selfviewright: 1 }] } }
                        ]
                        const userrightsByUserrole = await MainDB.getmenual("tbluserrights", new _Userrights(), userrightsByUserrolePipeline)
                        objalias = userrightsByUserrole.ResultData.map((taskalias) => taskalias.alias)
                        pipeline.push({ $match: { alias: { $in: objalias } } })
                    }
                }

            }


            const requiredPage = { pageno: PaginationInfo.pageno, skip: (PaginationInfo.pageno - 1) * PaginationInfo.pagelimit, pagelimit: PaginationInfo.pagelimit }

            var sort = Object.keys(PaginationInfo.sort).length !== 0 ? PaginationInfo.sort : { _id: -1 }
            if (searchtext !== "") {
                pipeline.push(...IISMethods.GetGlobalSearchFilter(new _TaskCategory(), searchtext))
            }

            if (Object.keys(PaginationInfo.filter).length) {
                pipeline = pipeline.concat(IISMethods.GetPipelineForFilter(PaginationInfo.filter))
            }

            const resp = await MainDB.getmenual(TableName, new _TaskCategory(), pipeline, requiredPage, sort, true, "", projection)

            const categoryconfigurationPipeline = [{ $match: { propertyid: ObjectId(req.body.propertyid), personid: ObjectId(req.headers.uid) } }]
            const categoryconfigurationResp = await MainDB.getmenual("tblcategoryconfiguration", new _CategoryConfiguration(), categoryconfigurationPipeline)

            const responseArray = []

            resp.ResultData.forEach((obj) => {
                if (req.body.taskalias == FieldConfig.taskalias.singleothertask) {
                    obj.showtasktypeforapp = 0
                    if (Config.taskcategory.daily == obj._id.toString()) {
                        obj.name = "Daily Task"
                    }
                } else if (req.body.taskalias == FieldConfig.taskalias.scheduleothertask) {
                    obj.showtasktypeforapp = 1
                }
                
                const categoryconfiguration = categoryconfigurationResp.ResultData.find((data) => data.categoryid.toString() === obj._id.toString())

                if (categoryconfiguration) {
                    categoryconfiguration.reminderhours = categoryconfiguration.reminderhours || 0
                    categoryconfiguration.reminderminutes = categoryconfiguration.reminderminutes || 0
                    categoryconfiguration.afterreminderhours = categoryconfiguration.afterreminderhours || 0//paras
                    categoryconfiguration.afterreminderminutes = categoryconfiguration.afterreminderminutes || 0//paras
                    categoryconfiguration.notifyifnotbufferhours = categoryconfiguration.notifyifnotbufferhours || 0
                    categoryconfiguration.notifyifnotbufferminutes = categoryconfiguration.notifyifnotbufferminutes || 0
                    categoryconfiguration.notifyifnotacceptedbufferhours = categoryconfiguration.notifyifnotacceptedbufferhours || 0
                    categoryconfiguration.notifyifnotacceptedbufferminutes = categoryconfiguration.notifyifnotacceptedbufferminutes || 0
                    categoryconfiguration.dualauthenticationbufferhours = categoryconfiguration.dualauthenticationbufferhours || 0
                    categoryconfiguration.dualauthenticationbufferminutes = categoryconfiguration.dualauthenticationbufferminutes || 0
                    categoryconfiguration.dualauthenticationwithphotobufferhours = categoryconfiguration.dualauthenticationwithphotobufferhours || 0
                    categoryconfiguration.dualauthenticationwithphotobufferminutes = categoryconfiguration.dualauthenticationwithphotobufferminutes || 0
                    categoryconfiguration.notifyifnotbuffertime = categoryconfiguration.notifyifnotbuffertime || ""
                    categoryconfiguration.notifyifnotacceptedbuffertime = categoryconfiguration.notifyifnotacceptedbuffertime || ""
                    categoryconfiguration.dualauthenticationbuffertime = categoryconfiguration.dualauthenticationbuffertime || ""
                    categoryconfiguration.dualauthenticationwithphotobuffertime = categoryconfiguration.dualauthenticationwithphotobuffertime || ""

                    categoryconfiguration.notifyifnotacceptedinspectorbufferhours = categoryconfiguration.notifyifnotacceptedinspectorbufferhours || 0
                    categoryconfiguration.notifyifnotacceptedinspectorbufferminutes = categoryconfiguration.notifyifnotacceptedinspectorbufferminutes || 0
                    categoryconfiguration.notifyifnotacceptedinspectorbuffertime = categoryconfiguration.notifyifnotacceptedinspectorbuffertime || ""

                    responseArray.push({ ...obj, categoryconfiguration })
                } else {
                    responseArray.push({ ...obj })
                }
            })

            ResponseBody.pagename = PageName
            ResponseBody.formname = FormName
            ResponseBody.fltpagecollection = FltPageCollection
            ResponseBody.status = 200
            ResponseBody.message = Config.getResponsestatuscode()["200"]
            ResponseBody.data = responseArray
            ResponseBody.currentpage = resp.currentpage
            ResponseBody.nextpage = resp.nextpage

            req.ResponseBody = ResponseBody; next()
        } catch (err) {

            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }; next()
        }
    }
    // End Task category
}
