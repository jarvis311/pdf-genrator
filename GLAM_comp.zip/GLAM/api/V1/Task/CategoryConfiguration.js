import { IISMethods, Config, MainDB } from "../../../config/Init.js"
import CategoryConfiguration from "../../../model/Task/CategoryConfiguration.js"

const TableName = "tblcategoryconfiguration"
const PageName = "Task Configuration"
const FormName = "Task Configuration"
const FltPageCollection = "categoryconfiguration"

export default class CategoryConfigurationMaster {
    // List CategoryConfiguration
    async ListCategoryConfiguration(req, res, next) {
        try {
            const ResponseBody = {}

            const {
                paginationinfo: { projection = {}, pageno = 1, pagelimit = 20, filter = {}, sort = {} }
            } = req.body || {}

            const requiredPage = {
                pageno: pageno,
                skip: (pageno - 1) * pagelimit,
                pagelimit: pagelimit
            }

            const sortData = Object.keys(sort).length !== 0 ? sort : { _id: -1 }

            const pipeline = IISMethods.GetPipelineForFilter(filter)
            let fieldorder = req.body.paginationinfo.isfieldorder ? req.body.paginationinfo.isfieldorder : 0

            const resp = await MainDB.getmenual(TableName, new CategoryConfiguration(), pipeline, requiredPage, sortData, fieldorder, "", projection)

            ResponseBody.pagename = PageName
            ResponseBody.formname = FormName
            ResponseBody.fltpagecollection = FltPageCollection
            ResponseBody.status = 200
            ResponseBody.message = Config.getResponsestatuscode()["200"]
            ResponseBody.data = resp.ResultData

            req.ResponseBody = ResponseBody; next()
        } catch (err) {
            
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }; next()
        }
    }

    // Insert CategoryConfiguration
    async InsertCategoryConfiguration(req, res, next) {
        try {
            const ResponseBody = {}

            const pipeline = {
                categoryid: req.body.categoryid,
                propertyid: req.body.propertyid
            }
            
            if (req.body.personid) {
                pipeline.personid = req.body.personid

            } else if (req.body.designationid) {
                pipeline.designationid = req.body.designationid
            }

            const CategoryConfigurationResp = await MainDB.FindOne(TableName, new CategoryConfiguration(), pipeline)

            if (!CategoryConfigurationResp) {
                const resp = await MainDB.executedata("i", new CategoryConfiguration(), TableName, req.body)

                ResponseBody.status = resp.status
                ResponseBody.message = resp.message
            } else {
                ResponseBody.status = 400
                ResponseBody.message = Config.getErrmsg()["isexist"]
            }

            req.ResponseBody = ResponseBody; next()
        } catch (err) {
            
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }; next()
        }
    }

    async UpdateCategoryConfiguration(req, res, next) {
        try {
            const ResponseBody = {}

            const pipeline = {
                categoryid: req.body.categoryid,
                propertyid: req.body.propertyid
            }
            if (req.body.personid !== Config.dummyObjid) {
                pipeline.personid = req.body.personid
            } else if (req.body.designationid !== Config.dummyObjid) {
                pipeline.designationid = req.body.designationid
            }

            const record = await MainDB.FindOne(TableName, new CategoryConfiguration(), pipeline)

            if (record) {

                req.body._id = record._id
                const RecordInfo = record.recordinfo
                RecordInfo.updateuid = req.headers.uid
                RecordInfo.updateby = req.headers.personname
                RecordInfo.updatedate = IISMethods.getdatetimestr()
                req.body.recordinfo = RecordInfo

                const resp = await MainDB.executedata("u", new CategoryConfiguration(), TableName, req.body)
                ResponseBody.data = resp.data
                ResponseBody.status = resp.status
                ResponseBody.message = resp.message
            } else {
                delete req.body._id
                const resp = await MainDB.executedata("i", new CategoryConfiguration(), TableName, req.body)

                ResponseBody.status = resp.status
                ResponseBody.message = resp.message
            }

            req.ResponseBody = ResponseBody; next()
        } catch (err) {

            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }; next()
        }
    }

    // Delete CategoryConfiguration
    async DeleteCategoryConfiguration(req, res, next) {
        try {
            const ResponseBody = {}

            const resp = await MainDB.executedata("d", new CategoryConfiguration(), TableName, req.body, true)

            ResponseBody.status = resp.status
            ResponseBody.message = resp.message

            req.ResponseBody = ResponseBody; next()
        } catch (err) {
            
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }; next()
        }
    }
}
