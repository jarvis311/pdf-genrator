import { IISMethods, Config } from "../../../config/Init.js"
import _PendingEmail from "../../../model/reservation/PendingEmail.js"
import _PendingEmailSentEmail from "../../../model/reservation/PendingEmailSentEmail.js"

export default class PendingEmailMaster {

    async ListPendingEmail(req, res, next) {
        try {
            const ResponseBody = {}
            let { paginationinfo: { pageno = 1, pagelimit = 10, filter = {}, sort = {}, projection = {} } } = req.body || {} 

            const requiredPage = { pageno: pageno, skip: (pageno - 1) * pagelimit, pagelimit: pagelimit }
            const sortData = Object.keys(sort).length !== 0 ? sort : { _id: -1 }

            var fromdate = IISMethods.getDateFormats(new Date(filter.fromdate), 1)
            var todate = IISMethods.getDateFormats(new Date(filter.todate), 1)
            let FolioEmailPipeline = [
                {
                    $addFields: {
                        _entrydate: {
                            $dateToString: {
                                format: "%Y-%m-%d",
                                date: "$entrydate"
                            }
                        }
                    }
                },
            ]
            if (filter.fromdate && filter.todate) {
                FolioEmailPipeline.push({
                    $match: {
                        _entrydate: { $gte: fromdate, $lte: todate },
                    }
                })
            }
            delete filter.fromdate
            delete filter.todate
            if (filter.sentemail != 1) {
                delete filter.sentemail
                FolioEmailPipeline.push({
                    $match: {
                        sentemail: { $ne: 1 }
                    }
                })
            }
            FolioEmailPipeline = FolioEmailPipeline.concat(IISMethods.GetPipelineForFilter(filter))
            const FolioEmailResp = await MainDB.getmenual("tblpendingemail", new _PendingEmail(), FolioEmailPipeline, requiredPage, sortData, false, "", projection) 

            ResponseBody.FolioEmailPipeline = FolioEmailPipeline
            ResponseBody.status = 200
            ResponseBody.message = Config.getResponsestatuscode()["200"]
            ResponseBody.data = FolioEmailResp.ResultData

            const PendingEmail = new _PendingEmail()
            if (req.body.paginationinfo.filter.sentemail == 1) {
                ResponseBody.fieldorder = PendingEmail.getCompletedFieldOrder()
            } else {
                ResponseBody.fieldorder = PendingEmail.getFieldOrder()
            }

            req.ResponseBody = ResponseBody; next()
        } catch (err) {

            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }; next()
        }
    }

    async UpdatePendingEmail(req, res, next) {
        try {
            const ObejctId = IISMethods.getobjectid()
            const ResponseBody = {}
            let InsertArray = []
            if (req.body.folioemaildata.length > 0) {
                if (parseInt(req.body.sentemail) == 1) {
                    for (let obj of req.body.folioemaildata) {
                        if (obj.sentemail == 1) {
                            obj.statusid = 2
                            obj.status = "pending"
                            obj.entrydate = new Date()

                            let RecordInfo = {}
                            RecordInfo.entryuid = req.headers.uid
                            RecordInfo.entryby = req.headers.personname
                            RecordInfo.entrydate = IISMethods.getdatetimestr()
                            RecordInfo.timestamp = IISMethods.GetTimestamp()
                            obj.recordinfo = RecordInfo

                            const UpdatePipeline = [
                                {
                                    _id: obj._id
                                },
                                {
                                    sentemail: 0,
                                    statusid: 2,
                                    status: "pending"
                                }
                            ]
                            const UpdateResp = await MainDB.UpdateMany("tblpendingemail", new _PendingEmail(), UpdatePipeline)

                            delete obj._id
                            obj._id = new ObejctId()
                            InsertArray.push(obj)

                        }
                    }
                } else if (parseInt(req.body.sentemail) == 0) {
                    for (let obj of req.body.folioemaildata) {
                        if (obj.sentemail == 1) {
                            obj.statusid = 3
                            obj.status = "completed"
                            obj.entrydate = new Date()
                            let RecordInfo = {}
                            RecordInfo.entryuid = req.headers.uid
                            RecordInfo.entryby = req.headers.personname
                            RecordInfo.entrydate = IISMethods.getdatetimestr()
                            RecordInfo.timestamp = IISMethods.GetTimestamp()
                            obj.recordinfo = RecordInfo

                            const UpdatePipeline = [
                                {
                                    _id: obj._id
                                },
                                {
                                    sentemail: 1,
                                    statusid: 3,
                                    status: "completed"
                                }
                            ]
                            const UpdateResp = await MainDB.Update("tblpendingemail", new _PendingEmail(), UpdatePipeline)

                            delete obj._id
                            obj._id = new ObejctId()
                            InsertArray.push(obj)
                        }
                    }
                }
                // for (let obj of req.body.folioemaildata) {
                //     if (obj.sentemail == 1) {
                //         obj.statusid = 3
                //         obj.status = "completed"
                //         obj.entrydate = new Date()

                //         let RecordInfo = {}
                //         RecordInfo.entryuid = req.headers.uid
                //         RecordInfo.entryby = req.headers.personname
                //         RecordInfo.entrydate = IISMethods.getdatetimestr()
                //         RecordInfo.timestamp = IISMethods.GetTimestamp()
                //         obj.recordinfo = RecordInfo

                //         const UpdatePipeline = [
                //             {
                //                 _id: obj._id
                //             },
                //             {
                //                 sentemail: 1,
                //                 statusid: 3,
                //                 status: "completed"
                //             }
                //         ]
                //         const UpdateResp = await MainDB.UpdateMany("tblpendingemail", new _PendingEmail(), UpdatePipeline)

                //         delete obj._id
                //         obj._id = new ObejctId()
                //         InsertArray.push(obj)

                //     } else if (obj.sentemail == 2) {
                //         obj.statusid = 2
                //         obj.status = "pending"
                //         obj.entrydate = new Date()
                //         let RecordInfo = {}
                //         RecordInfo.entryuid = req.headers.uid
                //         RecordInfo.entryby = req.headers.personname
                //         RecordInfo.entrydate = IISMethods.getdatetimestr()
                //         RecordInfo.timestamp = IISMethods.GetTimestamp()
                //         obj.recordinfo = RecordInfo

                //         const UpdatePipeline = [
                //             {
                //                 _id: obj._id
                //             },
                //             {
                //                 sentemail: 0,
                //                 statusid: 2,
                //                 status: "pending"
                //             }
                //         ]
                //         const UpdateResp = await MainDB.Update("tblpendingemail", new _PendingEmail(), UpdatePipeline)

                //         delete obj._id
                //         obj._id = new ObejctId()
                //         InsertArray.push(obj)
                //     }
                // }
                const Resp = await MainDB.InsertMany("tblpendingemailsentlog", new _PendingEmailSentEmail(), InsertArray)
                ResponseBody.status = Resp.status
                ResponseBody.message = Resp.message
            }
            req.ResponseBody = ResponseBody; next()
        } catch (err) {

            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }; next()
        }
    }

    async ListPendingEmailSentLog(req, res, next) {
        try {
            const ResponseBody = {}
            let { paginationinfo: { pageno = 1, pagelimit = 10, filter = {}, sort = {}, projection = {} } } = req.body || {} 

            const requiredPage = { pageno: pageno, skip: (pageno - 1) * pagelimit, pagelimit: pagelimit }
            const sortData = Object.keys(sort).length !== 0 ? sort : { _id: -1 }
            var fromdate = IISMethods.getDateFormats(new Date(filter.fromdate), 1)
            var todate = IISMethods.getDateFormats(new Date(filter.todate), 1)
            let FolioEmailPipeline = [
                {
                    $addFields: {
                        _entrydate: {
                            $dateToString: {
                                format: "%Y-%m-%d",
                                date: "$entrydate"
                            }
                        }
                    }
                },
                {
                    $match: {
                        _entrydate: { $gte: fromdate, $lte: todate },
                    }
                }
            ]
            delete filter.fromdate
            delete filter.todate
            const resp = await MainDB.getmenual("tblpendingemailsentlog", new _PendingEmailSentEmail(), FolioEmailPipeline, requiredPage, sortData, true, "", projection) 
            ResponseBody.status = 200
            ResponseBody.message = Config.getResponsestatuscode()["200"]
            ResponseBody.data = resp.ResultData
            if (resp.fieldorderdata) {
                ResponseBody.fieldorder = resp.fieldorderdata
            } else {
                const PendingEmail = new _PendingEmail()
                ResponseBody.fieldorder = PendingEmail.getFieldOrder()
            }
            req.ResponseBody = ResponseBody; next()
        } catch (err) {

            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }; next()
        }
    }
}