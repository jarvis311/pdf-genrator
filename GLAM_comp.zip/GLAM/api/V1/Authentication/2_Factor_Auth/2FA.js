import { MainDB, Config, IISMethods, FieldConfig } from "../../../../config/Init.js"
import _TwoFARequestToken from "../../../../model/2_Factor_Auth/2FARequestToken.js"
import _Employee from "../../../../model/Onboarding/Employee.js"
import _Customer from '../../../../model/Onboarding/Customer.js'
import _Gatekeeper from '../../../../model/Onboarding/GateKeeper.js'

// 2FA
import speakeasy from "speakeasy"

export default class TwoFA {
	// 2FA Enable
	async Enable2FA(req, res, next) {
		try {
			const ResponseBody = {}

			const personid = req.body.personid ? req.body.personid : req.headers.uid

			let person
			if (req.headers.pagename) {
				const personResp = await MainDB.getPersonData({ apptype: 0, personid: [personid], pagename: req.headers.pagename })
				person = personResp[0]
			}

			if (person) {
				if (!person.is2FAenable) {
					const twoFARequestToken = {
						personid: person._id,
						requestid: IISMethods.generateuuid(),
						twoFAmode: Config.twoFAMode
					}

					const resp = await MainDB.executedata("i", new _TwoFARequestToken(), "tbl2FArequesttoken", twoFARequestToken)

					if (resp.status == 200) {
						// 2FA Secret
						const secret_2FA = speakeasy.generateSecret({
							name: `${Config.twoFAName} ${person.firstname} ${person.lastname}`
						})

						// Add Temp Token
						const personObj = {
							_id: person._id,
							temp_2FA_secret: secret_2FA.base32
						}

						if (req.headers.pagename) {
							await MainDB.getPersonDataUpdate({ apptype: req.headers.apptype, pagename: req.headers.pagename, personObj: personObj })
						}

						ResponseBody.status = 200
						ResponseBody.message = Config.getResponsestatuscode()["200"]
						ResponseBody.data = {
							requestid: twoFARequestToken.requestid,
							otpauthURL: secret_2FA.otpauth_url
						}
					} else {
						ResponseBody.status = resp.status
						ResponseBody.message = resp.message
					}
				} else {
					ResponseBody.status = 400
					ResponseBody.message = Config.getErrmsg()["2FAalreadyenable"]
				}
			} else {
				ResponseBody.status = 404
				ResponseBody.message = Config.getErrmsg()["personnotfound"]
			}

			req.ResponseBody = ResponseBody
			next()
		} catch (err) {
			req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
			next()
		}
	}

	// Verify 2FA Enable
	async VerifyEnable2FA(req, res, next) {
		try {
			const ResponseBody = {}

			const personid = req.body.personid ? req.body.personid : req.headers.uid

			let person
			const projection = { _id: 1, is2FAenable: 1, temp_2FA_secret: 1, personname: 1, personemail: 1, contact: 1, alternatecontact: 1, profilepic: 1, property: 1, userrole: 1, isactive: 1, invalidlogincount: 1, department: 1, requestid: 1, is2FAenable: 1 }
			if (req.headers.pagename) {
				const personResp = await MainDB.getPersonData({ apptype: 0, personid: [personid], pagename: req.headers.pagename, projection: projection })
				person = personResp[0]

			}


			if (person) {
				if (!person.is2FAenable) {
					if (person.temp_2FA_secret) {
						const { requestid, twoFACode } = req.body

						if (requestid && twoFACode) {
							const validOTP = IISMethods.validate2FAOTP({ secret: person.temp_2FA_secret, otp: twoFACode })

							if (validOTP) {
								const personObj = {
									_id: person._id,
									is2FAenable: 1,
									temp_2FA_secret: "",
									secret_2FA: person.temp_2FA_secret
								}

								let resp
								if (req.headers.pagename) {
									resp = await MainDB.getPersonDataUpdate({ apptype: 0, pagename: req.headers.pagename, personObj: personObj })
								}

								if (resp.status === 200) {
									const twoFARequestTokenPipeline = [{ requestid: requestid, isexpired: 0 }, { isexpired: 1 }]
									await MainDB.UpdateByFilter(
										"tbl2FArequesttoken",
										new _TwoFARequestToken(),
										twoFARequestTokenPipeline
									)

									ResponseBody.status = 200
									ResponseBody.message = Config.getErrmsg()["2FAenable"]
								}
							} else {
								ResponseBody.status = 400
								ResponseBody.message = Config.getErrmsg()["2FAinvalidotp"]
							}
						} else {
							ResponseBody.status = 400
							ResponseBody.message = Config.getResponsestatuscode()["400"]
						}
					} else {
						ResponseBody.status = 400
						ResponseBody.message = Config.getErrmsg()["2FAnotreuqest"]
					}
				} else {
					ResponseBody.status = 400
					ResponseBody.message = Config.getErrmsg()["2FAalreadyenable"]
				}
			} else {
				ResponseBody.status = 404
				ResponseBody.message = Config.getErrmsg()["personnotfound"]
			}

			req.ResponseBody = ResponseBody
			next()
		} catch (err) {
			req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
			next()
		}
	}

	// Disable 2FA Enable
	async Disable2FA(req, res, next) {
		try {
			const ResponseBody = {}

			const personid = req.body.personid ? req.body.personid : req.headers.uid

			let person
			if (req.headers.pagename) {
				const personResp = await MainDB.getPersonData({ apptype: req.body.apptype, personid: [personid], pagename: req.headers.pagename })
				person = personResp[0]
			}

			if (person) {
				if (person.is2FAenable && person.secret_2FA) {
					const { twoFACode } = req.body

					const validOTP = IISMethods.validate2FAOTP({ secret: person.secret_2FA, otp: twoFACode })

					if (validOTP) {
						const personObj = {
							_id: person._id,
							is2FAenable: 0,
							temp_2FA_secret: "",
							secret_2FA: ""
						}

						if (req.headers.pagename) {
							await MainDB.getPersonDataUpdate({ apptype: 1, pagename: req.headers.pagename, personObj: personObj })
						}

						ResponseBody.status = 200
						ResponseBody.message = Config.getErrmsg()["2FAdisable"]
					} else {
						ResponseBody.status = 400
						ResponseBody.message = Config.getErrmsg()["2FAinvalidotp"]
					}
				} else {
					ResponseBody.status = 400
					ResponseBody.message = Config.getErrmsg()["2FAnotenabled"]
				}
			} else {
				ResponseBody.status = 404
				ResponseBody.message = Config.getErrmsg()["personnotfound"]
			}

			req.ResponseBody = ResponseBody
			next()
		} catch (err) {
			req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
			next()
		}
	}

	// Generate Recovery Code
	async GenerateRecoveryCode(req, res, next) {
		try {
			const ResponseBody = {}

			const personid = req.body.personid ? req.body.personid : req.headers.uid

			let person
			if (req.headers.pagename) {
				const personResp = await MainDB.getPersonData({ apptype: 0, personid: [personid], pagename: req.headers.pagename })
				person = personResp[0]
			}


			if (person) {
				if (person.is2FAenable && person.secret_2FA) {
					const recoveryCodes = IISMethods.generateRecoveryCodes()

					const personObj = {
						_id: person._id,
						recoverycodes: recoveryCodes
					}

					if (req.headers.pagename) {
						await MainDB.getPersonDataUpdate({ apptype: 0, pagename: req.headers.pagename, personObj: personObj })
					}

					ResponseBody.status = 200
					ResponseBody.message = Config.getResponsestatuscode()["200"]
					ResponseBody.data = recoveryCodes
				} else {
					ResponseBody.status = 400
					ResponseBody.message = Config.getErrmsg()["2FAnotenabled"]
				}
			} else {
				ResponseBody.status = 404
				ResponseBody.message = Config.getErrmsg()["personnotfound"]
			}

			req.ResponseBody = ResponseBody
			next()
		} catch (err) {
			req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
			next()
		}
	}

	// Verify Recovery Code
	async VerifyRecoveryCode(req, res, next) {
		try {
			const ResponseBody = {}

			const personid = req.body.personid ? req.body.personid : req.headers.uid

			let person
			if (req.headers.pagename) {
				const personResp = await MainDB.getPersonData({ apptype: 0, personid: [personid], pagename: req.headers.pagename })
				person = personResp[0]
			}


			if (person) {
				if (person.is2FAenable && person.secret_2FA) {
					const { recoverycode } = req.body

					if (recoverycode) {
						const validRecoveryCode = IISMethods.validateRecoveryCode({ recoveryCodes: person.recoverycodes, recoveryCode: recoverycode })

						if (validRecoveryCode) {
							const personObj = {
								_id: person._id,
								is2FAenable: 0,
								temp_2FA_secret: "",
								secret_2FA: "",
								recoverycodes: person.recoverycodes.filter((code) => code !== recoverycode)
							}

							if (req.headers.pagename) {
								await MainDB.getPersonDataUpdate({ apptype: 0, pagename: req.headers.pagename, personObj: personObj })
							}

							ResponseBody.status = 200
							ResponseBody.message = Config.getErrmsg()["2FAdisable"]
						} else {
							ResponseBody.status = 400
							ResponseBody.message = Config.getErrmsg()["2FAinvalidrecoverycode"]
						}
					} else {
						ResponseBody.status = 400
						ResponseBody.message = Config.getResponsestatuscode()["400"]
					}
				} else {
					ResponseBody.status = 400
					ResponseBody.message = Config.getErrmsg()["2FAnotenabled"]
				}
			} else {
				ResponseBody.status = 404
				ResponseBody.message = Config.getErrmsg()["personnotfound"]
			}

			req.ResponseBody = ResponseBody
			next()
		} catch (err) {
			req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
			next()
		}
	}


	// 2FA Login
	async login2FA(req, res, next) {
		try {
			console.log("calling me")
			const ResponseHeaders = {}
			const ResponseBody = {}

			const { personid, requestid, twoFACode } = req.body

			if (requestid && twoFACode) {
				// Check If Request ID is Valid
				const requestTokenPipeline = { requestid: requestid, isexpired: 0 }
				const requestToken = await MainDB.FindOne("tbl2FArequesttoken", new _TwoFARequestToken(), requestTokenPipeline)

				if (requestToken) {
					let person
					if (req.headers.pagename || req.headers.apptype) {
						const projection = { _id: 1, personname: 1, personemail: 1, contact: 1, alternatecontact: 1, profilepic: 1, property: 1, userrole: 1, isactive: 1, invalidlogincount: 1, department: 1, requestid: 1, is2FAenable: 1, secret_2FA: 1 }
						const personResp = await MainDB.getPersonData({ apptype: req.headers.apptype, personid: [personid], pagename: req.headers.pagename, projection: projection })
						person = personResp[0]
					}


					if (person) {
						if (!person.isactive) {
							// If Account not Active

							ResponseBody.status = 401
							ResponseBody.message = Config.getErrmsg()["deactivate"]

							req.ResponseBody = ResponseBody
							next()
						}

						if (person.is2FAenable && person.secret_2FA) {
							const validOTP = IISMethods.validate2FAOTP({ secret: person.secret_2FA, otp: twoFACode })

							if (validOTP) {
								const twoFARequestToken = {
									_id: requestToken._id,
									isexpired: 1
								}
								await MainDB.executedata("u", new _TwoFARequestToken(), "tbl2FArequesttoken", twoFARequestToken)

								const unqkey = IISMethods.generateuuid()
								const token = await MainDB.getjwt({
									uid: IISMethods.GetValueofObjectID(person._id),
									unqkey,
									iss: req.headers.issuer,
									useragent: req.headers["user-agent"],
									domainname: req.headers.domainname,
									aud: req.headers.host
								})

								ResponseHeaders.unqkey = unqkey
								ResponseHeaders.token = token
								delete person.password
								ResponseHeaders.domainname = "godrejliving"

								ResponseBody.status = 200
								ResponseBody.message = Config.getResponsestatuscode()["200"]
								ResponseBody.data = person
							} else {
								ResponseBody.status = 400
								ResponseBody.message = Config.getErrmsg()["2FAinvalidotp"]
							}
						} else {
							ResponseBody.status = 400
							ResponseBody.message = Config.getErrmsg()["2FAnotenabled"]
						}
					} else {
						ResponseBody.status = 404
						ResponseBody.message = Config.getErrmsg()["personnotfound"]
					}
				} else {
					ResponseBody.status = 401
					ResponseBody.message = Config.getErrmsg()["2FAnotsent"]
				}
			} else {
				ResponseBody.status = 403
				ResponseBody.message = Config.getResponsestatuscode()["403"]
			}

			req.ResponseHeaders = ResponseHeaders
			req.ResponseBody = ResponseBody
			next()
		} catch (err) {
			req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
			next()
		}
	}
}
