import { IISMethods, Config, MainDB } from "../../../config/Init.js"
import _PersonChangeLog from "../../../model/PersonChangeLog.js"
import _ForgotPasswordOTP from "../../../model/EmployeeOTP.js"
import _EmployeeOTP from "../../../model/EmployeeOTP.js"
import _Gatekeeper from '../../../model/Onboarding/GateKeeper.js'
import _GatekeeperOTP from '../../../model/GatekeeperOTP.js'
import _Employee from '../../../model/Onboarding/Employee.js'

export default class ForgotPassword {
    // Forgot Password Request
    async EmployeeForgotPasswordReq(req, res, next) {
        try {
            const ResponseBody = {}
            const ResponseHeaders = {}

            const { email = "" } = req.body
            
            const personPipeline = [
                { $addFields: { personemail: { $toLower: "$personemail" }, username: { $toLower: "$username" } } },
                { $match: { $or: [{ personemail: email.toLowerCase() }, { contact: email }, { username: email.toLowerCase() }] } }
            ]
            const personResp = await MainDB.getmenual("tblemployee", new _Employee(), personPipeline)
            const person = personResp.ResultData[0]

            // Check if person exists
            if (!person) {
                ResponseBody.status = 404
                ResponseBody.message = Config.getErrmsg()["usernotfound"]

                req.ResponseBody = ResponseBody
                return next()
            }

            // Check if person is active
            if (!person.isactive) {
                ResponseBody.status = 401
                ResponseBody.message = Config.getErrmsg()["deactivate"]

                req.ResponseBody = ResponseBody
                return next()
            }

            /*---------------------------------- OTP ----------------------------------*/
            const { otp, hashOTP } = IISMethods.generateOTP(6)

            const forgotpasswordOTPObj = {
                personid: person._id,
                email: person.personemail,
                otp: otp,
                type: 2,
                time: new Date()
            }
            
			await MainDB.executedata('i', new _EmployeeOTP(), 'tblemployeeotp', forgotpasswordOTPObj)
            /*---------------------------------- OTP ----------------------------------*/

            /*---------------------------------- Send Email ----------------------------------*/
            const emailTemplate = Config.emailtemplates.forgotpassword

            const emailData = {
                personname: person.personname,
                otp: otp
            }

            // Send Email
            await MainDB.sendEmail({
                subdomainname: req.headers["subdomainname"],
                from: process.env.EMAIL_FROM,
                to: [email],
                subject: emailTemplate.subject,
                data: emailData,
                templateid: emailTemplate
            })
            /*---------------------------------- Send Email ----------------------------------*/

            ResponseBody.status = 200
            ResponseBody.message = Config.getErrmsg()["otpsent"]
            ResponseBody.data = otp

            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

    // Forgot Password OTP Verify and reset
    async EmployeeForgotPasswordReset(req, res, next) {
        try {
            const ResponseBody = {}
            const ObjectId = IISMethods.getobjectid()

            if (!req.body.otp) {
                ResponseBody.status = 400
                ResponseBody.message = Config.getResponsestatuscode()["400"]

                req.ResponseBody = ResponseBody
                return next()
            }

			const personPipeline = [
				{ $addFields: { personemail: { $toLower: "$personemail" }, username: { $toLower: "$username" } } },
				{ $match: { $or: [{ personemail: req.body.email.toLowerCase() }, { contact: req.body.email }, { username: req.body.email.toLowerCase() }] } }
			]
			const personResp = await MainDB.getmenual("tblemployee", new _Employee(), personPipeline)
			const person = personResp.ResultData[0]

            // Check if person exists
            if (!person) {
                ResponseBody.status = 404
                ResponseBody.message = Config.getErrmsg()["usernotfound"]

                req.ResponseBody = ResponseBody
                return next()
            }

            // Check if person is active
            if (!person.isactive) {
                ResponseBody.status = 401
                ResponseBody.message = Config.getErrmsg()["deactivate"]

                req.ResponseBody = ResponseBody
                return next()
            }

            // Check OTP Expired
            // const forgotpasswordOTP = await global.redisclient.get(`Forgot Password OTP:${person._id}`)
            const otpPipeline = [
                {
                    $match: {
                        personid: ObjectId(person._id),
                        type: 2,
                        otp: req.body.otp,
                        isused: 0
                    }
                }
            ]
            const EmployeeOTPData = await MainDB.getmenual("tblemployeeotp", new _EmployeeOTP(), otpPipeline)


            if (!EmployeeOTPData.ResultData?.length) {
                ResponseBody.status = 400
                ResponseBody.message = Config.getErrmsg()["invalidotp"]

                req.ResponseBody = ResponseBody
                return next()
            }

            const data = EmployeeOTPData.ResultData[0]
            const processTime = IISMethods.getTimeDifference(EmployeeOTPData.ResultData[0].time, new Date())
            const deftime = Math.round(processTime / 1000) / 60

            if (deftime > Config.otpexpiredtime) {
                ResponseBody.status = 400
                ResponseBody.message = Config.getErrmsg()["otpexpired"]

                req.ResponseBody = ResponseBody
                return next()
            }

            // Verify OTP
            data.verify = 1

            // await global.redisclient.set(`Forgot Password OTP:${person._id}`, JSON.stringify(data), { EX: Config.otpexpiredtime * 60 })
			//await MainDB.executedata('u', new _EmployeeOTP(), 'tblemployeeotp', data)

            // Password Validation
            const passwordValid = IISMethods.PasswordValidation(req.body.newpassword)

             if (passwordValid) {
                 ResponseBody.status = 400
                 ResponseBody.message = passwordValid
 
                 req.ResponseBody = ResponseBody
 
                 return next()
             }
 
             const personpasswordhistoryPipeline = [{ $match: { userid: ObjectId(person._id), logtype: { $in: [5, 9] } } }, { $sort: { _id: -1 } }, { $limit: 4 }]
             const personpasswordhistoryResp = await MainDB.getmenual(
                 "tblpersonchangelog",
                 new _PersonChangeLog(),
                 personpasswordhistoryPipeline
             )
             const personpasswordhistory = personpasswordhistoryResp.ResultData
 
             let isError = 0
 
             if (personpasswordhistory.length) {
                 const matchPassword = personpasswordhistory.find((obj) => obj.userpassword === IISMethods.GetMD5(req.body.newpassword))
 
                 if (matchPassword) {
                     isError = 2
                 }
             } else {
                 if (person.password === IISMethods.GetMD5(req.body.newpassword)) {
                     isError = 1
                 }
             }
 
            //  if (!isError) {
                const personObj = {
                    _id: person._id,
                    password: IISMethods.GetMD5(req.body.newpassword),
                    isresetpassword: 0,
                    verify:1
                }

                const resp = await MainDB.executedata("u", new _Employee(), "tblemployee", personObj)

                if (resp.status === 200) {
                    // await global.redisclient.del(`Forgot Password OTP:${person._id}`)
                    const empotpupdate = {
                        _id: data._id,
                        isused: 1,
                     }
                    await MainDB.executedata('u', new _EmployeeOTP(), 'tblemployeeotp', empotpupdate)

                    // Person Change Log
                    await MainDB.addPersonChangeLog({ req, data: person, logtype: 9 })

                    ResponseBody.status = resp.status
                    ResponseBody.message = Config.getErrmsg()["passchanged"]
                } else {
                    ResponseBody.status = resp.status
                    ResponseBody.message = resp.message
                }
            // } else {
            //     if (isError === 1) {
            //         ResponseBody.status = 400
            //         ResponseBody.message = Config.getErrmsg()["lastpasswordsame"]
            //     } else if (isError === 2) {
            //         ResponseBody.status = 400
            //         ResponseBody.message = Config.getErrmsg()["last4passwordsame"]
            //     }
            // }

            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

    async GatekeeperForgotPasswordReq(req, res, next) {
        try {
            const ResponseBody = {}
            const ResponseHeaders = {}

            const { email = "" } = req.body
            
            const personPipeline = [
                { $addFields: { personemail: { $toLower: "$personemail" }, username: { $toLower: "$username" } } },
                { $match: { $or: [{ personemail: email.toLowerCase() }, { contact: email }, { username: email.toLowerCase() }] } }
            ]
            const personResp = await MainDB.getmenual("tblgatekeeper", new _Gatekeeper(), personPipeline)
            const person = personResp.ResultData[0]

            // Check if person exists
            if (!person) {
                ResponseBody.status = 404
                ResponseBody.message = Config.getErrmsg()["usernotfound"]

                req.ResponseBody = ResponseBody
                return next()
            }

            // Check if person is active
            if (!person.isactive) {
                ResponseBody.status = 401
                ResponseBody.message = Config.getErrmsg()["deactivate"]

                req.ResponseBody = ResponseBody
                return next()
            }

            /*---------------------------------- OTP ----------------------------------*/
            const { otp, hashOTP } = IISMethods.generateOTP(6)

            const forgotpasswordOTPObj = {
                personid: person._id,
                email: person.personemail,
                otp: otp,
                type: 2,
                time: new Date()
            }
            
			await MainDB.executedata('i', new _GatekeeperOTP(), 'tblgatekeeperotp', forgotpasswordOTPObj)
            /*---------------------------------- OTP ----------------------------------*/

            /*---------------------------------- Send Email ----------------------------------*/
            const emailTemplate = Config.emailtemplates.forgotpassword

            const emailData = {
                personname: person.personname,
                otp: otp
            }

            // Send Email
            await MainDB.sendEmail({
                subdomainname: req.headers["subdomainname"],
                from: process.env.EMAIL_FROM,
                to: [email],
                subject: emailTemplate.subject,
                data: emailData,
                templateid: emailTemplate
            })
            /*---------------------------------- Send Email ----------------------------------*/

            ResponseBody.status = 200
            ResponseBody.message = Config.getErrmsg()["otpsent"]
            ResponseBody.data = otp

            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

    // Forgot Password OTP Verify and reset
    async GatekeeperForgotPasswordReset(req, res, next) {
        try {
            const ResponseBody = {}
            const ObjectId = IISMethods.getobjectid()

            if (!req.body.otp) {
                ResponseBody.status = 400
                ResponseBody.message = Config.getResponsestatuscode()["400"]

                req.ResponseBody = ResponseBody
                return next()
            }

            
			const personPipeline = [
				{ $addFields: { personemail: { $toLower: "$personemail" }, username: { $toLower: "$username" } } },
				{ $match: { $or: [{ personemail: req.body.email.toLowerCase() }, { contact: req.body.email }, { username: req.body.email.toLowerCase() }] } }
			]
			const personResp = await MainDB.getmenual("tblgatekeeper", new _Gatekeeper(), personPipeline)
			const person = personResp.ResultData[0]

            // Check if person exists
            if (!person) {
                ResponseBody.status = 404
                ResponseBody.message = Config.getErrmsg()["usernotfound"]

                req.ResponseBody = ResponseBody
                return next()
            }

            // Check if person is active
            if (!person.isactive) {
                ResponseBody.status = 401
                ResponseBody.message = Config.getErrmsg()["deactivate"]

                req.ResponseBody = ResponseBody
                return next()
            }

            // Check OTP Expired
            // const forgotpasswordOTP = await global.redisclient.get(`Forgot Password OTP:${person._id}`)
            const otpPipeline = [
                {
                    $match: {
                        personid: ObjectId(person._id),
                        type: 2,
                        otp: req.body.otp,
                        isused: 0
                    }
                }
            ]
            const EmployeeOTPData = await MainDB.getmenual("tblgatekeeperotp", new _GatekeeperOTP(), otpPipeline)


            if (!EmployeeOTPData.ResultData?.length) {
                ResponseBody.status = 400
                ResponseBody.message = Config.getErrmsg()["invalidotp"]

                req.ResponseBody = ResponseBody
                return next()
            }

            const data = EmployeeOTPData.ResultData[0]
            const processTime = IISMethods.getTimeDifference(EmployeeOTPData.ResultData[0].time, new Date())
            const deftime = Math.round(processTime / 1000) / 60

            if (deftime > Config.otpexpiredtime) {
                ResponseBody.status = 400
                ResponseBody.message = Config.getErrmsg()["otpexpired"]

                req.ResponseBody = ResponseBody
                return next()
            }

            // Verify OTP
            data.verify = 1

            // await global.redisclient.set(`Forgot Password OTP:${person._id}`, JSON.stringify(data), { EX: Config.otpexpiredtime * 60 })
			//await MainDB.executedata('u', new _EmployeeOTP(), 'tblemployeeotp', data)

            // Password Validation
            const passwordValid = IISMethods.PasswordValidation(req.body.newpassword)

             if (passwordValid) {
                 ResponseBody.status = 400
                 ResponseBody.message = passwordValid
 
                 req.ResponseBody = ResponseBody
 
                 return next()
             }
 
             const personpasswordhistoryPipeline = [{ $match: { userid: ObjectId(person._id), logtype: { $in: [5, 9] } } }, { $sort: { _id: -1 } }, { $limit: 4 }]
             const personpasswordhistoryResp = await MainDB.getmenual(
                 "tblpersonchangelog",
                 new _PersonChangeLog(),
                 personpasswordhistoryPipeline
             )
             const personpasswordhistory = personpasswordhistoryResp.ResultData
 
             let isError = 0
 
             if (personpasswordhistory.length) {
                 const matchPassword = personpasswordhistory.find((obj) => obj.userpassword === IISMethods.GetMD5(req.body.newpassword))
 
                 if (matchPassword) {
                     isError = 2
                 }
             } else {
                 if (person.password === IISMethods.GetMD5(req.body.newpassword)) {
                     isError = 1
                 }
             }
 
             if (!isError) {
                const personObj = {
                    _id: person._id,
                    password: IISMethods.GetMD5(req.body.newpassword),
                    isresetpassword: 0,
                    verify:1
                }

                const resp = await MainDB.executedata("u", new _Gatekeeper(), "tblgatekeeper", personObj)

                if (resp.status === 200) {
                    // await global.redisclient.del(`Forgot Password OTP:${person._id}`)
                    const empotpupdate = {
                        _id: data._id,
                        isused: 1,
                     }
                    await MainDB.executedata('u', new _Gatekeeper(), 'tblgatekeeper', empotpupdate)

                    // Person Change Log
                    await MainDB.addPersonChangeLog({ req, data: person, logtype: 9 })

                    ResponseBody.status = resp.status
                    ResponseBody.message = Config.getErrmsg()["passchanged"]
                } else {
                    ResponseBody.status = resp.status
                    ResponseBody.message = resp.message
                }
            } else {
                if (isError === 1) {
                    ResponseBody.status = 400
                    ResponseBody.message = Config.getErrmsg()["lastpasswordsame"]
                } else if (isError === 2) {
                    ResponseBody.status = 400
                    ResponseBody.message = Config.getErrmsg()["last4passwordsame"]
                }
            }

            req.ResponseBody = ResponseBody
            next()
        } catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
            next()
        }
    }

}
