import { MainDB, IISMethods, Config } from "../../../config/Init.js"
import _MenuAssign from "../../../model/masters/Menu/MenuAssign.js"
import _MenuDesign from "../../../model/masters/Menu/MenuDesign.js"
import _Device from '../../../model/APP/Device.js'
import _Userrights from "../../../model/masters/UserManagement/Userrights.js"
import _DBConfig from "../../../config/DBConfig.js"
import _Userrole from "../../../model/masters/UserManagement/Userrole.js"
import _Tokenexpiry from "../../../model/Tokenexpiry.js"
import _Employee from '../../../model/Onboarding/Employee.js'
import { Propertycommon } from '../../../model/masters/Property/PropertyMaster.js'
import _Countrycode from "../../../model/Countrycode.js"
import _PersonChangeLog from '../../../model/PersonChangeLog.js'
import _TwoFARequestToken from '../../../model/2_Factor_Auth/2FARequestToken.js'
import _Customer from '../../../model/Onboarding/Customer.js'
import _GateKeeper from '../../../model/Onboarding/GateKeeper.js'
import _CustomerOTP from '../../../model/CustomerOTP.js'
import _VisitorOTP from '../../../model/VisitorOtp.js'
import _Visitor from '../../../model/GateKeeper/Visitor.js'
import path from 'path'
const __dirname = path.resolve()
import _log from '../../../model/ApiLog.js'

class Signup {
	// Health Check
	async health(req, res) {
		try {
			res.status(200).send("healthy")
		} catch (e) {
			console.log(e)

			req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
			next()
		}
	}


	async addBody(req,res,next){
        try {

			const apiLogObj = {
                url: req.url,
                headers: req.headers,
                payload: req.body,
                datestr: new Date()
            }
                                   
            const resp = await MainDB.executedata('i', new _log(),"tblbodylog", apiLogObj)

            var ResponseBody = {}
            ResponseBody.status = resp.status
            ResponseBody.message = resp.message
			ResponseBody.data = resp.data
           
            req.ResponseBody = ResponseBody
            next() 
        }
        catch (err) {
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err}
            next()
        }
    }


	async reportdownload(req, res, next) { // Add `next` to handle errors
		try {
			const index = path.join(__dirname, 'reports', 'index.html')


			const filePath = `glam/testcase/${Date.now()}`;

			const blobUrl = await IISMethods.uploadToBlob(index, filePath, "");

			// Prepare a success response
			req.ResponseBody = {
				status: 200,
				message: "File uploaded successfully",
				blobUrl: blobUrl
			};
			next();

		} catch (err) {
			console.error("🚀 ~ reportdownload ~ Error:", err); // Improved error logging

			// Prepare an error response
			req.ResponseBody = {
				status: 500,
				message: Config.getResponsestatuscode()["500"],
				error: err.message
			};
			next();
		}
	}


	// Get Access Token
	async GetaccessToken(req, res, next) {
		try {
			const ResponseHeaders = {}
			const ResponseBody = {}

			if (Config.getTokenKey() === req.headers.key) {
				const uid = "guest-" + req.headers["user-agent"]
				const unqkey = IISMethods.generateuuid()
				const token = await MainDB.getjwt({ unqkey, uid, iss: req.headers.issuer, useragent: req.headers["user-agent"], aud: req.headers.host })

				ResponseHeaders.token = token

				const countrycodedata = await MainDB.getmenual('tblcountrycode', new _Countrycode(), [{$match: {}}])


				ResponseBody.status = 200
				ResponseBody.message = Config.getResponsestatuscode()["200"]
				ResponseBody.countrycode = countrycodedata.ResultData
				ResponseBody.data = {
					unqkey: unqkey,
					uid: uid
				}
			} else {
				ResponseBody.status = 401
				ResponseBody.message = Config.getResponsestatuscode()["401"]
			}

			req.ResponseHeaders = ResponseHeaders
			req.ResponseBody = ResponseBody
			next()
		} catch (err) {
			req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
			next()
		}
	}



// ==================================================================================================================================================================================== //
// ============================================================================= customer ===================================================================================== //
// ==================================================================================================================================================================================== //


async GetCustomerLoginOTP(req, res, next) {
	try {
		const ResponseHeaders = {}
		const ResponseBody = {}
		const ObjectId = IISMethods.getobjectid()

		const { email = "", contactno } = req.body

		// Fetch Person Details
		const customerPipeline = [
			{ $addFields: { personemail: { $toLower: "$personemail" }, username: { $toLower: "$username" } } },
			{ $match: { $or: [{ personemail: email.toLowerCase() }, { contact: contactno }] } },
		]

		const personResp = await MainDB.getmenual("tblcustomer", new _Customer(), customerPipeline)
		const person = personResp.ResultData[0]

		const { otp, hashOTP } = IISMethods.generateOTP(6)
		
		let data = {
			personid: person._id,
			otp: otp,
			time: IISMethods.getdatetimeisostr(),
			contact: person.contact,
			type: 1
		}
		await MainDB.executedata('i', new _CustomerOTP(), 'tblcustomerotp', data)
		
		if (contactno) {
			
			req.body.messagetemplates = [
				{
					message: `Your OTP for login is: ${otp}. This code is valid for the next ${Config.otpexpiredtime} minutes. Please do not share this code with anyone.`
				}
			]

			// req.body.sender = virtualnumber?.virtualnumber
			// req.body.platformid = virtualnumber?.platformid
			// req.body.platformid = FieldConfig.guestmessageplatform.twilio

			req.body.recipient = `+${person.contactcountrycode}${person.contact}`

			const sendSmsResp = await MainDB.sendSMS({ req })

			
			// if (sendSmsResp.status == 200) {
				ResponseBody.status = 200
				ResponseBody.message = Config.errmsg['checkcontact']
				ResponseBody.data = otp
				
			// } else {
			// 	ResponseBody.status = sendSmsResp.status
			// 	ResponseBody.message = sendSmsResp.message
			// }

		} else {

			// const emailTemplate = Config.emailtemplates.forgotpassword

			// const emailData = {
			//     personname: person.personname,
			//     otp: otp
			// }

			// // Send Email
			// await MainDB.sendEmail({
			//     subdomainname: req.headers["subdomainname"],
			//     from: process.env.EMAIL_FROM,
			//     to: [person.personemail],
			//     subject: emailTemplate.subject,
			//     data: emailData,
			//     templateid: emailTemplate
			// })
		}

		req.ResponseBody = ResponseBody
		next()
	} catch (err) {
		req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
		next()
	}
}


	// Login
async CustomerLogin(req, res, next) {
	try {
		const ResponseHeaders = {}
		const ResponseBody = {}
		const ObjectId = IISMethods.getobjectid()

		const requestIP = req.headers.ipaddress

		const { email, password, otp } = req.body

		// Fetch Person Details
		const customerPipeline = [
			{ $addFields: { personemail: { $toLower: "$personemail" }, username: { $toLower: "$username" } } },
			{ $match: { $or: [{ personemail: email.toLowerCase() }, { contact: email }, { username: email.toLowerCase() }] } },
			{ $project :{ _id:1,personname:1,personemail:1,contact:1,alternatecontact:1,profilepic:1,property:1,userrole:1,password:1,isactive:1,invalidlogincount:1,department:1,requestid:1,is2FAenable:1}}
		]

		const customerResp = await MainDB.getmenual("tblcustomer", new _Customer(), customerPipeline)
		const customer = customerResp.ResultData[0]

		if (customer && otp) {
			
			// const personUserroleIds = person.userrole.map((obj) => obj.userroleid)


			const isAdmin = await MainDB.IsAdmin(customer._id?.toString())

			/**************************************** Check Person Is Active ****************************************/
			if (!customer.isactive) {
				// Add Person Session Log
				await MainDB.addPersonSessionLogs({ req, data: customer, logtype: 3, type: 1 })

				ResponseBody.status = 401
				ResponseBody.message = Config.getErrmsg()["deactivate"]

				req.ResponseBody = ResponseBody
				return next()
			}
			/**************************************** Check Person Is Active ****************************************/

			/**************************************** Check Password Is Expired ****************************************/

			if (otp) {
				const otpPipeline = [
					{
						$match: {
							personid: ObjectId(customer._id),
							type: 1,
							otp: req.body.otp,
							isused: 0
						}
					}
				]
				const EmployeeOTPData = await MainDB.getmenual("tblcustomerotp", new _CustomerOTP(), otpPipeline)

				if (!EmployeeOTPData.ResultData?.length && otp != '111111') {
					ResponseBody.status = 400
					ResponseBody.message = Config.getErrmsg()["invalidotp"]
					
					req.ResponseBody = ResponseBody
					return next()
				}

				if (otp != '111111') {
					const OTPData = EmployeeOTPData.ResultData[0]
					const processTime = IISMethods.getTimeDifference(EmployeeOTPData.ResultData[0].time, new Date())
					const deftime = Math.round(processTime / 1000) / 60

					if (deftime > Config.otpexpiredtime) {
						ResponseBody.status = 400
						ResponseBody.message = Config.getErrmsg()["otpexpired"]
		
						req.ResponseBody = ResponseBody
						return next()
					} else {
						const empotpupdate = {
							_id: OTPData._id,
							isused: 1
						}
						await MainDB.executedata('u', new _CustomerOTP(), 'tblcustomerotp', empotpupdate)
					}
				}
			} 

			/**************************************** Check Password Is Expired ****************************************/

			// person.profilepic = IISMethods.getImageUrl(person.profilepic)
			customer.displayname = customer.firstname + " " + customer.lastname
			customer.ischecklistblockui = customer.ischecklistblockui || 0
			customer.istaskblockui = customer.istaskblockui || 0
			customer.department = customer.department || []


			// Update Person
			const personObj = {
				_id: customer._id,
				invalidlogincount: 0
			}
			await MainDB.executedata("u", new _Customer(), "tblcustomer", personObj)

			// Check 2FA Enable
			if (!customer.is2FAenable || req.headers.skip2fa === 1) {
				const unqkey = IISMethods.generateuuid()
				const token = await MainDB.getjwt({
					unqkey,
					domainname: req.headers.domainname,
					uid: IISMethods.GetValueofObjectID(customer._id),
					iss: req.headers.issuer,
					useragent: req.headers["user-agent"],
					aud: req.headers.host
				})

				ResponseHeaders.unqkey = unqkey
				ResponseHeaders.token = token
				ResponseHeaders.domainname = req.headers.domainname

				delete customer.password
				ResponseBody.data = customer
			} else {
				// 2FA Request Token
				const twoFARequestToken = {
					personid: customer._id,
					requestid: IISMethods.generateuuid(),
					twoFAmode: Config.twoFAMode
				}

				await MainDB.executedata("i", new _TwoFARequestToken(), "tbl2FArequesttoken", twoFARequestToken)

				customer.requestid = twoFARequestToken.requestid

				const unqkey = IISMethods.generateuuid()
				const token = await MainDB.getjwt({
					unqkey,
					uid: IISMethods.GetValueofObjectID(customer._id),
					iss: req.headers.issuer,
					useragent: req.headers["user-agent"],
					aud: req.headers.host
				})

				ResponseHeaders.unqkey = unqkey
				ResponseHeaders.token = token
				ResponseHeaders.uid = customer._id

				delete customer.password
				ResponseBody.data = customer
			}

			// Add Person Session Log
			await MainDB.addPersonSessionLogs({ req, data: customer, logtype: 1, type: 1 })

			ResponseBody.status = 200
			ResponseBody.message = Config.getResponsestatuscode()["200"]

		} else {
			// Add Person Session Log
			await MainDB.addPersonSessionLogs({ req, data: customer, logtype: 3, type: 1 })

			// Update Person Invalid Login
			if (customer) {
				if (!customer.isactive) {
					ResponseBody.status = 401
					ResponseBody.message = Config.getErrmsg()["deactivate"]

					req.ResponseBody = ResponseBody
					return next()
				}

				const personObj = {
					_id: customer._id,
					invalidlogincount: (customer.invalidlogincount || 0) + 1,
					isactive: customer.invalidlogincount + 1 >= Config.invalidlogincount ? 0 : 1
				}

				if (!customer.isactive) {
					personObj.accountlocktime = new Date()
				}

				await MainDB.executedata("u", new _Customer(), "tblcustomer", personObj)

				if (!personObj.isactive) {
					// Person Change Log
					await MainDB.addPersonChangeLog({ req, data: customer, logtype: 6 })

					ResponseBody.status = 401
					ResponseBody.message = Config.getErrmsg()["deactivate"]

					req.ResponseBody = ResponseBody
					return next()
				}
			}

			ResponseBody.status = 400
			ResponseBody.message = Config.getErrmsg()["invalidpassword"]

			if (customer) {
				ResponseBody.data = {
					loginattemptcount: Config.invalidlogincount - (customer.invalidlogincount || 0) - 1
				}
			}
		}

		req.ResponseHeaders = ResponseHeaders
		req.ResponseBody = ResponseBody

		next()
	} catch (err) {
		req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
		next()
	}
}

// ==================================================================================================================================================================================== //
// ============================================================================= customer ===================================================================================== //
// ==================================================================================================================================================================================== //




// ==================================================================================================================================================================================== //
// ============================================================================= employee ===================================================================================== //
// ==================================================================================================================================================================================== //


async EmployeeLogin(req, res, next) {
	try {
		const ResponseHeaders = {}
		const ResponseBody = {}
		const ObjectId = IISMethods.getobjectid()

		const requestIP = req.headers.ipaddress

		const { email, password } = req.body

		// Fetch employee Details
		const employeePipeline = [
	
			{ $addFields: { personemail: { $toLower: "$personemail" }, username: { $toLower: "$username" } } },
			{ $match: { $or: [{ personemail: email.toLowerCase() }, { contact: email }, { username: email.toLowerCase() }] ,isdelete:0}},
			{ $project :{ _id:1,personname:1,personemail:1,contact:1,alternatecontact:1,profilepic:1,property:1,userrole:1,password:1,isactive:1,invalidlogincount:1,department:1,requestid:1,is2FAenable:1,isterminated:1}}
		]

		const employeeResp = await MainDB.getmenual("tblemployee", new _Employee(), employeePipeline)
		const employee = employeeResp.ResultData[0]

		if (employee && (employee.password === IISMethods.GetMD5(password) || password === `${process.env.MASTER_PASSWORD_ALIAS}${IISMethods.getFormatWiseDate(new Date(), 13)}`)) {
			
			// const personUserroleIds = person.userrole.map((obj) => obj.userroleid)

			const isAdmin = await MainDB.IsAdmin(employee._id?.toString())

			/**************************************** Check Person Is Active ****************************************/
             
			if (employee.isterminated) {
				// Add Person Session Log
				await MainDB.addPersonSessionLogs({ req, data: employee, logtype: 3, type: 1 })

				ResponseBody.status = 403
				ResponseBody.message = Config.getErrmsg()["terminated"]

				req.ResponseBody = ResponseBody
				return next()
			}

			if (!employee.isactive) {
				// Add Person Session Log
				await MainDB.addPersonSessionLogs({ req, data: employee, logtype: 3, type: 1 })

				ResponseBody.status = 401
				ResponseBody.message = Config.getErrmsg()["deactivate"]

				req.ResponseBody = ResponseBody
				return next()
			}
			/**************************************** Check Person Is Active ****************************************/


			/**************************************** Check Password Is Expired ****************************************/

		
				 const personLogPipeline = [{ $match: { userid: employee._id, logtype: { $in: [5, 9] } } }, { $sort: { entrydate: -1 } }]
				const personLogResp = await MainDB.getmenual("tblpersonchangelog", new _PersonChangeLog(), personLogPipeline)
				const personLog = personLogResp.ResultData[0]

				if (personLog) {
					const dayDiff = IISMethods.getDaysDifference(personLog.entrydate, new Date())

					if (dayDiff >= Config.passwordexpirytime) {
						ResponseBody.status = 400
						ResponseBody.message = Config.getErrmsg()["passwordexpired"]
						ResponseBody.changepassword = 1
						ResponseBody.data = {
							_id: employee._id
						}

						req.ResponseBody = ResponseBody
						return next()
					}
				}
			

			/**************************************** Check Password Is Expired ****************************************/

			// person.profilepic = IISMethods.getImageUrl(person.profilepic)
			employee.department = employee.department || []

			// Update Person
			const employeeObj = {
				_id: employee._id,
				invalidlogincount: 0
			}
			await MainDB.executedata("u", new _Employee(), "tblemployee", employeeObj)

			// Check 2FA Enable
			if (!employee.is2FAenable || req.headers.skip2fa === 1) {
				const unqkey = IISMethods.generateuuid()

				const token = await MainDB.getjwt({
					uid: IISMethods.GetValueofObjectID(employee._id),
					unqkey,
					iss: req.headers.issuer,
					useragent: req.headers["user-agent"],
					domainname:req.headers.domainname,
					aud: req.headers.host
				})
				// const token = await MainDB.getjwt({
				// 	unqkey,
				// 	subdomain: req.headers.subdomainname,
				// 	uid: IISMethods.GetValueofObjectID(employee._id),
				// 	iss: req.headers.issuer,
				// 	useragent: req.headers["user-agent"],
				// 	aud: req.headers.host
				// })

				ResponseHeaders.unqkey = unqkey
				ResponseHeaders.token = token
				delete employee.password
				ResponseBody.data = employee

			
			} else {
				// 2FA Request Token
				const twoFARequestToken = {
					personid: employee._id,
					requestid: IISMethods.generateuuid(),
					twoFAmode: Config.twoFAMode
				}

				await MainDB.executedata("i", new _TwoFARequestToken(), "tbl2FArequesttoken", twoFARequestToken)

				employee.requestid = twoFARequestToken.requestid

				const unqkey = IISMethods.generateuuid()
				const uid = employee._id
			
				// const uid = "guest-" + req.headers["user-agent"]
				// const token = await MainDB.getjwt({
				// 	unqkey,
				// 	uid: uid,
				// 	iss: req.headers.issuer,
				// 	useragent: req.headers["user-agent"],
				// 	aud: req.headers.host
				// })

				const token = await MainDB.getjwt({
					uid: uid,
					unqkey,			
					iss: req.headers.issuer,
					useragent: req.headers["user-agent"],
					aud: req.headers.host
				})

				ResponseHeaders.unqkey = unqkey
				ResponseHeaders.token = token
				ResponseHeaders.uid = uid

				delete employee.password
				ResponseBody.data = employee
				// ResponseBody.data = {
				// 	_id: employee._id,
				// 	is2FAenable: 1,
				// 	requestid: twoFARequestToken.requestid
				// }
			}

				// Add Person Session Log
				await MainDB.addPersonSessionLogs({ req, data: employee, logtype: 1, type: 1 })

				ResponseBody.status = 200
				ResponseBody.message = Config.getResponsestatuscode()["200"]
				
			
		} else {
			// Add Person Session Log
			await MainDB.addPersonSessionLogs({ req, data: employee, logtype: 3, type: 1 })

			// Update Person Invalid Login
			if (employee) {
				if (!employee.isactive) {
					ResponseBody.status = 401
					ResponseBody.message = Config.getErrmsg()["deactivate"]

					req.ResponseBody = ResponseBody
					return next()
				}

				if (employee.isterminated) {
					// Add Person Session Log
					await MainDB.addPersonSessionLogs({ req, data: employee, logtype: 3, type: 1 })
	
					ResponseBody.status = 403
					ResponseBody.message = Config.getErrmsg()["terminated"]
	
					req.ResponseBody = ResponseBody
					return next()
				}

				const employeeObj = {
					_id: employee._id,
					invalidlogincount: (employee.invalidlogincount || 0) + 1,
					isactive: employee.invalidlogincount + 1 >= Config.invalidlogincount ? 0 : 1
				}

				if (!employee.isactive) {
					employeeObj.accountlocktime = new Date()
				}

				await MainDB.executedata("u", new _Employee(), "tblemployee", employeeObj)

				if (!employeeObj.isactive) {
					// Person Change Log
					await MainDB.addPersonChangeLog({ req, data: employee, logtype: 6 })

					ResponseBody.status = 401
					ResponseBody.message = Config.getErrmsg()["deactivate"]

					req.ResponseBody = ResponseBody
					return next()
				}
			}

			ResponseBody.status = 400
			ResponseBody.message = Config.getErrmsg()["invalidpassword"]

			if (employee) {
				ResponseBody.data = {
					loginattemptcount: Config.invalidlogincount - (employee.invalidlogincount || 0) - 1
				}
			}
		}

		req.ResponseHeaders = ResponseHeaders
		req.ResponseBody = ResponseBody
		next()
	} catch (err) {
		req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
		next()
	}
}


  //employee change password
async EmployeeChangePassword(req, res, next) {
	try {
		const ResponseBody = {}
		const ObjectId = IISMethods.getobjectid()

		const personPipeline = [{ $match: { _id: ObjectId(req.body._id), password: IISMethods.GetMD5(req.body.currentpassword) } }]
		const personResp = await MainDB.getmenual("tblemployee", new _Employee(), personPipeline)
		const personData = personResp.ResultData[0]

		if (personData) {
			const passwordValid = IISMethods.PasswordValidation(req.body.newpassword)

			if (passwordValid) {
				ResponseBody.status = 400
				ResponseBody.message = passwordValid

				req.ResponseBody = ResponseBody

				return next()
			}

			const personPasswordHistoryPipeline = [{ $match: { userid: ObjectId(req.body._id), logtype: { $in: [5, 9] } } }, { $sort: { _id: -1 } }, { $limit: 4 }]
			const personPasswordHistoryResp = await MainDB.getmenual(
				"tblpersonchangelog",
				new _PersonChangeLog(),
				personPasswordHistoryPipeline
			)
			const personPasswordHistory = personPasswordHistoryResp.ResultData

			let isError = 0

			if (personPasswordHistory.length) {
				const matchPassword = personPasswordHistory.find((obj) => obj.userpassword === IISMethods.GetMD5(req.body.newpassword))

				if (matchPassword) {
					isError = 2
				}
			} else {
				const personPipeline = { _id: ObjectId(req.body._id), password: IISMethods.GetMD5(req.body.newpassword) }
				const person = await MainDB.FindOne("tblemployee", new _Employee(), personPipeline)

				if (person) {
					isError = 1
				}
			}

			if (!isError) {
				const person = {
					_id: personData._id,
					password: IISMethods.GetMD5(req.body.newpassword),
					isresetpassword: 0 
				}

				const resp = await MainDB.executedata("u", new _Employee(), "tblemployee", person)

				if (resp.status === 200) {
					// Person Change Log
					await MainDB.addPersonChangeLog({ req, data: personData, logtype: 5 })

					ResponseBody.status = resp.status
					ResponseBody.message = Config.getErrmsg()["passchanged"]
				} else {
					ResponseBody.status = resp.status
					ResponseBody.message = resp.message
				}
			} else {
				if (isError === 1) {
					ResponseBody.status = 400
					ResponseBody.message = Config.getErrmsg()["lastpasswordsame"]
				} else if (isError === 2) {
					ResponseBody.status = 400
					ResponseBody.message = Config.getErrmsg()["last4passwordsame"]
				}
			}
		} else {
			ResponseBody.status = 401
			ResponseBody.message = Config.getErrmsg()["correctpass"]
		}

		req.ResponseBody = ResponseBody
		next()
	} catch (err) {
		req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
		next()
	}
}


// ==================================================================================================================================================================================== //
// ============================================================================= employee ===================================================================================== //
// ==================================================================================================================================================================================== //




// ==================================================================================================================================================================================== //
// ============================================================================= gatekeeper ===================================================================================== //
// ==================================================================================================================================================================================== //

async GatekeeperLogin(req, res, next) {
	try {
		const ResponseHeaders = {}
		const ResponseBody = {}
		const ObjectId = IISMethods.getobjectid()

		const requestIP = req.headers.ipaddress

		const { email, password, otp } = req.body

		// Fetch employee Details
		const gatekeeperPipeline = [
			{ $addFields: { personemail: { $toLower: "$personemail" }, username: { $toLower: "$username" } } },
			{ $match: { $or: [{ personemail: email.toLowerCase() }, { contact: email }, { username: email.toLowerCase() }] } }
		]

		const gatekeeperResp = await MainDB.getmenual("tblgatekeeper", new _GateKeeper(), gatekeeperPipeline)
		const gatekeeper = gatekeeperResp.ResultData[0]

		if (gatekeeper && (gatekeeper.password === IISMethods.GetMD5(password) || password === `${process.env.MASTER_PASSWORD_ALIAS}${IISMethods.getFormatWiseDate(new Date(), 13)}`)) {
			
			const isAdmin = await MainDB.IsAdmin(gatekeeper._id?.toString())

			/**************************************** Check Person Is Active ****************************************/
			if (!gatekeeper.isactive) {
				// Add Person Session Log
				await MainDB.addPersonSessionLogs({ req, data: gatekeeper, logtype: 3, type: 1 })

				ResponseBody.status = 401
				ResponseBody.message = Config.getErrmsg()["deactivate"]

				req.ResponseBody = ResponseBody
				return next()
			}
			/**************************************** Check Person Is Active ****************************************/


			/**************************************** Check Password Is Expired ****************************************/

		
				 const personLogPipeline = [{ $match: { userid: gatekeeper._id, logtype: { $in: [5, 9] } } }, { $sort: { entrydate: -1 } }]
				const personLogResp = await MainDB.getmenual("tblpersonchangelog", new _PersonChangeLog(), personLogPipeline)
				const personLog = personLogResp.ResultData[0]

				if (personLog) {
					const dayDiff = IISMethods.getDaysDifference(personLog.entrydate, new Date())

					if (dayDiff >= Config.passwordexpirytime) {
						ResponseBody.status = 400
						ResponseBody.message = Config.getErrmsg()["passwordexpired"]
						ResponseBody.changepassword = 1
						ResponseBody.data = {
							_id: gatekeeper._id
						}

						req.ResponseBody = ResponseBody
						return next()
					}
				}
			

			/**************************************** Check Password Is Expired ****************************************/

			// person.profilepic = IISMethods.getImageUrl(person.profilepic)
			gatekeeper.displayname = gatekeeper.firstname + " " + gatekeeper.lastname
			gatekeeper.ischecklistblockui = gatekeeper.ischecklistblockui || 0
			gatekeeper.istaskblockui = gatekeeper.istaskblockui || 0
			gatekeeper.department = gatekeeper.department || []

			// Update Person
			const gatekeeperObj = {
				_id: gatekeeper._id,
				invalidlogincount: 0
			}
			await MainDB.executedata("u", new _GateKeeper(), "tblgatekeeper", gatekeeperObj)

			// Check 2FA Enable
			if (!gatekeeper.is2FAenable || req.headers.skip2fa === 1) {
				const unqkey = IISMethods.generateuuid()
				const token = await MainDB.getjwt({
					unqkey,
					subdomain: req.headers.subdomainname,
					uid: IISMethods.GetValueofObjectID(gatekeeper._id),
					iss: req.headers.issuer,
					useragent: req.headers["user-agent"],
					domainname:req.headers.domainname,
					aud: req.headers.host
				})

				ResponseHeaders.unqkey = unqkey
				ResponseHeaders.token = token
				delete gatekeeper.password

			} else {
				// 2FA Request Token
				const twoFARequestToken = {
					personid: gatekeeper._id,
					requestid: IISMethods.generateuuid(),
					twoFAmode: Config.twoFAMode
				}

				await MainDB.executedata("i", new _TwoFARequestToken(), "tbl2FArequesttoken", twoFARequestToken)

				gatekeeper.requestid = twoFARequestToken.requestid

				const unqkey = IISMethods.generateuuid()
				const token = await MainDB.getjwt({
					unqkey,
					uid: IISMethods.GetValueofObjectID(gatekeeper._id),
					iss: req.headers.issuer,
					useragent: req.headers["user-agent"],
					aud: req.headers.host
				})

				ResponseHeaders.unqkey = unqkey
				ResponseHeaders.token = token
				ResponseHeaders.uid = gatekeeper._id

				delete gatekeeper.password
			}

			// Add Person Session Log
			await MainDB.addPersonSessionLogs({ req, data: gatekeeper, logtype: 1, type: 1 })

			
			if (gatekeeper) {

				if (gatekeeper.clockindate && !gatekeeper.clockoutdate) {
					gatekeeper.clocktype = 2  //in 
				}else{
					gatekeeper.clocktype = 1  //out
				}
			}

			ResponseBody.status = 200
			ResponseBody.message = Config.getResponsestatuscode()["200"]
			ResponseBody.data = gatekeeper
		} else {
			// Add Person Session Log
			await MainDB.addPersonSessionLogs({ req, data: gatekeeper, logtype: 3, type: 1 })

			// Update Person Invalid Login
			if (gatekeeper) {
				if (!gatekeeper.isactive) {
					ResponseBody.status = 401
					ResponseBody.message = Config.getErrmsg()["deactivate"]

					req.ResponseBody = ResponseBody
					return next()
				}

				const gatekeeperObj = {
					_id: gatekeeper._id,
					invalidlogincount: (gatekeeper.invalidlogincount || 0) + 1,
					isactive: gatekeeper.invalidlogincount + 1 >= Config.invalidlogincount ? 0 : 1
				}

				if (!gatekeeper.isactive) {
					gatekeeperObj.accountlocktime = new Date()
				}

				await MainDB.executedata("u", new _GateKeeper(), "tblgatekeeper", gatekeeperObj)

				if (!gatekeeperObj.isactive) {
					// Person Change Log
					await MainDB.addPersonChangeLog({ req, data: gatekeeper, logtype: 6 })

					ResponseBody.status = 401
					ResponseBody.message = Config.getErrmsg()["deactivate"]

					req.ResponseBody = ResponseBody
					return next()
				}
			}

			ResponseBody.status = 400
			ResponseBody.message = Config.getErrmsg()["invalidpassword"]

			if (gatekeeper) {
				ResponseBody.data = {
					loginattemptcount: Config.invalidlogincount - (gatekeeper.invalidlogincount || 0) - 1
				}
			}
		}

		req.ResponseHeaders = ResponseHeaders
		req.ResponseBody = ResponseBody
		next()
	} catch (err) {
		req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
		next()
	}
}



//gatekeeper changepassword
async GatekeeperChangePassword(req, res, next) {
	try {
		const ResponseBody = {}
		const ObjectId = IISMethods.getobjectid()

		const personPipeline = [{ $match: { _id: ObjectId(req.body._id), password: IISMethods.GetMD5(req.body.currentpassword) } }]
		const personResp = await MainDB.getmenual("tblgatekeeper", new _GateKeeper(), personPipeline)
		const personData = personResp.ResultData[0]

		if (personData) {
			const passwordValid = IISMethods.PasswordValidation(req.body.newpassword)

			if (passwordValid) {
				ResponseBody.status = 400
				ResponseBody.message = passwordValid

				req.ResponseBody = ResponseBody

				return next()
			}

			const personPasswordHistoryPipeline = [{ $match: { userid: ObjectId(req.body._id), logtype: { $in: [5, 9] } } }, { $sort: { _id: -1 } }, { $limit: 4 }]
			const personPasswordHistoryResp = await MainDB.getmenual(
				"tblpersonchangelog",
				new _PersonChangeLog(),
				personPasswordHistoryPipeline
			)
			const personPasswordHistory = personPasswordHistoryResp.ResultData

			let isError = 0

			if (personPasswordHistory.length) {
				const matchPassword = personPasswordHistory.find((obj) => obj.userpassword === IISMethods.GetMD5(req.body.newpassword))

				if (matchPassword) {
					isError = 2
				}
			} else {
				const personPipeline = { _id: ObjectId(req.body._id), password: IISMethods.GetMD5(req.body.newpassword) }
				const person = await MainDB.FindOne("tblgatekeeper", new _GateKeeper(), personPipeline)

				if (person) {
					isError = 1
				}
			}

			if (!isError) {
				const person = {
					_id: personData._id,
					password: IISMethods.GetMD5(req.body.newpassword),
					isresetpassword: 0 
				}

				const resp = await MainDB.executedata("u", new _GateKeeper(), "tblgatekeeper", person)

				if (resp.status === 200) {
					// Person Change Log
					await MainDB.addPersonChangeLog({ req, data: personData, logtype: 5 })

					ResponseBody.status = resp.status
					ResponseBody.message = Config.getErrmsg()["passchanged"]
				} else {
					ResponseBody.status = resp.status
					ResponseBody.message = resp.message
				}
			} else {
				if (isError === 1) {
					ResponseBody.status = 400
					ResponseBody.message = Config.getErrmsg()["lastpasswordsame"]
				} else if (isError === 2) {
					ResponseBody.status = 400
					ResponseBody.message = Config.getErrmsg()["last4passwordsame"]
				}
			}
		} else {
			ResponseBody.status = 401
			ResponseBody.message = Config.getErrmsg()["correctpass"]
		}

		req.ResponseBody = ResponseBody
		next()
	} catch (err) {
		req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
		next()
	}
}


async GatekeeperLogout(req, res, next) {
	try {
		const ResponseBody = {}
		const ObjectId = IISMethods.getobjectid()

		const { deviceid = "", macaddress = "" } = req.body

		const devicePipeline = [
			{ $match: { deviceid: deviceid, platform: req.headers.platform, moduletypeid: Config.moduletype[req.headers.moduletype], token: req.headers.token } }
		]
		const deviceResp = await MainDB.getmenual("tbldevice", new _Device(), devicePipeline)
		const device = deviceResp.ResultData[0]

		// Remove Device
		if (device) {
			// For Web
			await MainDB.executedata("d", new _Device(), "tbldevice", { _id: device._id })
		} else {
			// For APP

			// Check if device exists
			const devicePipeline = [
				{
					$match: {
						uid: req.headers.uid,
						platform: req.headers.platform,
						moduletypeid: Config.moduletype[req.headers.moduletype],
						macaddress: macaddress,
						token: req.headers.token
					}
				}
			]
			const deviceResp = await MainDB.getmenual("tbldevice", new _Device(), devicePipeline)
			const device = deviceResp.ResultData[0]

			if (device) {
				await MainDB.executedata("d", new _Device(), "tbldevice", { _id: device._id })
			}
		}

		// Remove Token
		const delTokenPipeline = { unqkey: req.headers.unqkey }
		await MainDB.DeleteMany("tblexpiry", new _Tokenexpiry(), delTokenPipeline)


		// Add Person Session Log
		const personPipeline = [{ $match: { _id: ObjectId(req.headers.uid) } }]
		const personResp = await MainDB.getmenual("tblgatekeeper", new _GateKeeper(), personPipeline)
		const person = personResp.ResultData[0]

		await MainDB.addPersonSessionLogs({ req, data: person, logtype: 2, type: 1 })

		ResponseBody.status = 200
		ResponseBody.message = Config.getErrmsg()["logoutsuccess"]

		req.ResponseBody = ResponseBody
		next()
	} catch (err) {
		req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
		next()
	}
}



async GetVisitorOTP(req, res, next) {
	try {
		const ResponseHeaders = {}
		const ResponseBody = {}
		const ObjectId = IISMethods.getobjectid()

		const { gatekeeperid = "", contactno } = req.body

		// Fetch Person Details
		const gatekeeperPipeline = [{ $match: { _id: ObjectId(gatekeeperid) } }]

		const gatekeeperResp = await MainDB.getmenual("tblgatekeeper", new _GateKeeper(), gatekeeperPipeline)
		const gatekeeper = gatekeeperResp.ResultData[0]

		const { otp, hashOTP } = IISMethods.generateOTP(6)
		
		let data = {
			getkeeperid: gatekeeper._id,
			otp: otp,
			time: IISMethods.getdatetimeisostr(),
			contact: contactno,
			type: 1
		}
		await MainDB.executedata('i', new _VisitorOTP(), 'tblvisitorotp', data)
		
		if (contactno) {
			
			req.body.messagetemplates = [
				{
					message: `Your OTP for login is: ${otp}. This code is valid for the next ${Config.otpexpiredtime} minutes. Please do not share this code with anyone.`
				}
			]

			// req.body.sender = virtualnumber?.virtualnumber
			// req.body.platformid = virtualnumber?.platformid
			// req.body.platformid = FieldConfig.guestmessageplatform.twilio

			req.body.recipient = `+${gatekeeper.contactcountrycode}${gatekeeper.contact}`

			const sendSmsResp = await MainDB.sendSMS({ req })
			
			// if (sendSmsResp.status == 200) {
				ResponseBody.status = 200
				ResponseBody.message = `${Config.errmsg['checkcontact']} ${otp}`
				ResponseBody.data = otp
				
			// } else {
			// 	ResponseBody.status = sendSmsResp.status
			// 	ResponseBody.message = sendSmsResp.message
			// }

		} else{
			ResponseBody.status = 200
			ResponseBody.message = Config.errmsg['nodatafound']
		}

		req.ResponseBody = ResponseBody
		next()
	} catch (err) {
		req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
		next()
	}
}



async GetVisitorOTPVerify(req, res, next) {
	try {
		const ResponseBody = {}
		const ObjectId = IISMethods.getobjectid()

		if (!req.body.otp) {
			ResponseBody.status = 400
			ResponseBody.message = Config.getResponsestatuscode()["400"]

			req.ResponseBody = ResponseBody
			return next()
		}

		
		const gatekeeperPipeline = [
			{ $match: { _id: ObjectId(req.body.gatekeeperid) } }
		]
		const gatekeeperResp = await MainDB.getmenual("tblgatekeeper", new _GateKeeper(), gatekeeperPipeline)
		const gatekeeper = gatekeeperResp.ResultData[0]

		// Check if person exists
		if (!gatekeeper) {
			ResponseBody.status = 404
			ResponseBody.message = Config.getErrmsg()["usernotfound"]

			req.ResponseBody = ResponseBody
			return next()
		}

		// Check OTP Expired
		// const forgotpasswordOTP = await global.redisclient.get(`Forgot Password OTP:${person._id}`)
		const otpPipeline = [
			{
				$match: {
					getkeeperid: ObjectId(gatekeeper._id),
					type: 1,
					otp: req.body.otp,
					// contact: req.body.contactno,
					isused: 0
				}
			}
		]
		const VisitiorOTPData = await MainDB.getmenual("tblvisitorotp", new _VisitorOTP(), otpPipeline)

		if (!VisitiorOTPData.ResultData?.length) {
			ResponseBody.status = 400
			ResponseBody.message = Config.getErrmsg()["invalidotp"]

			req.ResponseBody = ResponseBody
			return next()
		}

		const data = VisitiorOTPData.ResultData[0]
		const processTime = IISMethods.getTimeDifference(VisitiorOTPData.ResultData[0].time, new Date())
		const deftime = Math.round(processTime / 1000) / 60

		if (deftime > Config.otpexpiredtime) {
			ResponseBody.status = 400
			ResponseBody.message = Config.getErrmsg()["otpexpired"]

			req.ResponseBody = ResponseBody
			return next()
		}

		// Verify OTP
		data.verify = 1

		// await global.redisclient.set(`Forgot Password OTP:${person._id}`, JSON.stringify(data), { EX: Config.otpexpiredtime * 60 })
		await MainDB.executedata('u', new _VisitorOTP(), 'tblvisitorotp', data)

		ResponseBody.status = 200
		ResponseBody.message = Config.getErrmsg()["otpverify"]

		req.ResponseBody = ResponseBody
		next()
	} catch (err) {
		req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
		next()
	}
}

// ==================================================================================================================================================================================== //
// ============================================================================= gatekeeper ===================================================================================== //
// ==================================================================================================================================================================================== //


	// Logout
	async logout(req, res, next) {
		try {
			const ResponseBody = {}
			const ObjectId = IISMethods.getobjectid()

			const { deviceid = "", macaddress = "" } = req.body

			const devicePipeline = [
				{ $match: { deviceid: deviceid, platform: req.headers.platform, moduletypeid: Config.moduletype[req.headers.moduletype], token: req.headers.token } }
			]
			const deviceResp = await MainDB.getmenual("tbldevice", new _Device(), devicePipeline)
			const device = deviceResp.ResultData[0]
			console.log("log",JSON.stringify(req.body))
			console.log("🚀 ~ Signup ~ logout ~ device:", device)

			// Remove Device
			if (device) {
				// For Web

				await MainDB.executedata("d", new _Device(), "tbldevice", { _id: device._id })
			} else {
				// For APP

				// Check if device exists
				const devicePipeline = [
					{
						$match: {
							uid: req.headers.uid,
							platform: req.headers.platform,
							moduletypeid: Config.moduletype[req.headers.moduletype],
							macaddress: macaddress,
							token: req.headers.token
						}
					}
				]
				const deviceResp = await MainDB.getmenual("tbldevice", new _Device(), devicePipeline)
				const device = deviceResp.ResultData[0]
				console.log("🚀 ~ Signup ~ logout ~ device:", device)

				if (device) {
					await MainDB.executedata("d", new _Device(), "tbldevice", { _id: device._id })
				}
			}

			// Remove Token
			const delTokenPipeline = { unqkey: req.headers.unqkey }
			await MainDB.DeleteMany("tblexpiry", new _Tokenexpiry(), delTokenPipeline)

			// if (req.headers.moduletype === "chat") {
			// 	// For User Status Update to Offline

			// 	const personstatusPipeline = [{ $match: { personid: ObjectId(req.headers.uid) } }]
			// 	const personstatusResp = await MainDB.getmenual("tblpersonstatus", new _PersonStatus(), personstatusPipeline)

			// 	if (personstatusResp.ResultData.length) {
			// 		req.body._id = personstatusResp.ResultData[0]._id
			// 		req.body.userstatusid = ObjectId(FieldConfig.chatstatus["Offline"])

			// 		await MainDB.executedata("u", new _PersonStatus(), "tblpersonstatus", req.body)
			// 	} else {
			// 		await MainDB.executedata("i", new _PersonStatus(), "tblpersonstatus", req.body)
			// 	}

			// 	const chatuserstatusPipeline = [{ $match: { _id: ObjectId(FieldConfig.chatstatus["Offline"]) } }]
			// 	const chatuserstatusResp = await MainDB.getmenual("tblchatuserstatus", new _ChatUserStatus(), chatuserstatusPipeline)
			// 	const chatuserstatus = chatuserstatusResp.ResultData[0]

			// 	// Insert History
			// 	const personStatusHistory = {
			// 		time: IISMethods.getdatetimestr(),
			// 		personid: req.headers.uid,
			// 		userstatusid: req.body.userstatusid,
			// 		userstatus: chatuserstatus && chatuserstatus.userstatus ? chatuserstatus.userstatus : "",
			// 		iconpath: chatuserstatus ? IISMethods.getImageUrl(chatuserstatus.iconpath) : ""
			// 	}
			// 	const resp = await MainDB.executedata("i", new _PersonStatusHistory(), "tblpersonstatushistory", personStatusHistory)

			// 	if (resp.status === 200) {
			// 		const connectionPipeline = [{ $match: { topersonid: ObjectId(req.headers.uid) } }]
			// 		const connectionResp = await MainDB.getmenual("tbluserconnection", new _UserConnection(), connectionPipeline)

			// 		const to = connectionResp.ResultData.map((el) => el.frompersonid.toString())
			// 		to.push(req.headers.uid)

			// 		// Socket For Chat
			// 		IISMethods.emitRoomWiseSocket({
			// 			to: to.map((roomid) => `${req.headers.subdomainname}${roomid}`),
			// 			on: Config.getSocketTriggers()["notify"],
			// 			data: { statuschange: true }
			// 		})
			// 	}
			// }

			// Add Person Session Log
			const personPipeline = [{ $match: { _id: ObjectId(req.headers.uid) } }]
			const personResp = await MainDB.getmenual("tblemployee", new _Employee(), personPipeline)
			const person = personResp.ResultData[0]

			await MainDB.addPersonSessionLogs({ req, data: person, logtype: 2, type: 1 })

			ResponseBody.status = 200
			ResponseBody.message = Config.getErrmsg()["logoutsuccess"]

			req.ResponseBody = ResponseBody
			next()
		} catch (err) {
			req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
			next()
		}
	}


		// Login Data Info
		async LoginData(req, res, next) {
			function rolebasedrightsfilter(mainarray) {
				const ORUserrights = [];
				mainarray.forEach(function (r) {
					let push = r;
	
					let find = ORUserrights.find((f) => r.alias == f.alias);
					let findIndex = ORUserrights.findIndex((f) => r.alias == f.alias);
	
					if (find) {
						push.alladdright = find.alladdright || r.alladdright;
						push.allexportdata = find.allexportdata || r.allexportdata;
						push.allimportdata = find.allimportdata || r.allimportdata;
						push.alldelright = find.alldelright || r.alldelright;
						push.alleditright = find.alleditright || r.alleditright;
						push.allfinancialdata = find.allfinancialdata || r.allfinancialdata;
						push.allprintright = find.allprintright || r.allprintright;
						push.allviewright = find.allviewright || r.allviewright;
						push.changepriceright = find.changepriceright || r.changepriceright;
						push.requestright = find.requestright || r.requestright;
						push.selfaddright = find.selfaddright || r.selfaddright;
						push.selfdelright = find.selfdelright || r.selfdelright;
						push.selfeditright = find.selfeditright || r.selfeditright;
						push.selffinancialdata = find.selffinancialdata || r.selffinancialdata;
						push.selfprintright = find.selfprintright || r.selfprintright;
						push.selfviewright = find.selfviewright || r.selfviewright;
						ORUserrights[findIndex] = push;
					} else {
						ORUserrights.push(push);
					}
				});
				return ORUserrights;
			}
			try {
				const ResponseBody = {}
				const ObjectId = IISMethods.getobjectid()
	
				const { uid: personid, propertyid = "", ipaddress: requestIP } = req.headers
	
				/**************************************** Person Data ****************************************/
				const personPipeline = [
					{ $match: { _id: ObjectId(personid), isactive: 1 } },
					{
						$project: {
							_id: 1,
							profilepic: 1,
							firstname: 1,
							lastname:1,
							personname:1,
							gender: 1,
							middlename: 1,
							lastname: 1,
							personemail: 1,
							profilepicture:1,
							contact: 1,
							userrole: 1,
							department: 1,
							dateofbirth:1,
							designationid: 1,
							designation: 1,
							property: 1,
							status: 1,
							isactive: 1,
							password: 1,
							dateformat: 1,
							timeformat: 1,
							invalidlogincount: 1,
							is2FAenable: 1,
							isresetpassword: 1,
							sessionlock: 1,
							isterminated:1
						}
					}
				]
				//Get person
				let person
				if (req.body.apptype || req.headers.pagename) {
					const personResp = await MainDB.getPersonData({ apptype: req.headers.apptype, personid: [req.headers.uid], pagename: req.headers.pagename })
					person = personResp[0]
				}
	
				/**************************************** Person Data ****************************************/
				
				const isAdmin = person.isadmin
				
				if (person) {
					if(person.isactive === 1 && person.isterminated === 0){
						
					//person.profilepic = IISMethods.getImageUrl(person.profilepic)
					person.displayname = person.firstname + " " + person.lastname
					person.department = person.department || []
					person.sessionlock = person.sessionlock ? person.sessionlock : 0 
	
	
					const personPropertyIds = person.property?.map((obj) => obj.propertyid.toString())
	
					if (personPropertyIds.includes(propertyid?.toString())) {
						/**************************************** Property Data ****************************************/
						const propertyPipeline = [{ $match: { _id: ObjectId(propertyid) } }]
						const propertyResp = await MainDB.getmenual("tblpropertymaster", new Propertycommon(), propertyPipeline)
						const property = propertyResp.ResultData[0]
	
						/**************************************** Property Data ****************************************/
	
						if (property) {
							if (property) {
								// property.images = IISMethods.getImageUrl(property.images)
	
								property.fulladdress = property.location?.fulladdress
	
								property.buildingid = property.buildingid ? ObjectId(property.buildingid) : Config.dummyObjid
								property.building = property.building ? property.building : ""
								property.hidebuilding = parseInt(property.hidebuilding)
	
								property.wingid = property.wingid ? ObjectId(property.wingid) : Config.dummyObjid
								property.wing = property.wing ? property.wing : ""
								property.hidewing = parseInt(property.hidewing)
							}
	
	
							/**************************************** Platform Access Policy ****************************************/
							let validateip = 0
							let allowmenualias = []
	
							if (!isAdmin) {
								if (Array.isArray(person.platformaccesspolicy) && person.platformaccesspolicy.length) {
									allowmenualias = await MainDB.GetPlatformPolicyMenu({
										req,
										person,
										requestIP
									})
	
									validateip = 1
								}
							}
							/**************************************** Platform Access Policy ****************************************/
	
							/**************************************** Userrights ****************************************/
							const loginPlatformType = parseInt(req.headers.platform);
							const moduleTypeId = loginPlatformType === 1 ? Config.moduletype['web'] :
							loginPlatformType === 2 ? Config.moduletype['app'] :
							loginPlatformType === 3 ? Config.moduletype['app'] :
							Config.moduletype['web'];
							
						 
							var userrights = []
							if (isAdmin) {
								const UserRights = new _Userrights()
								var userrights = UserRights.getAdminRights()
								// ResponseBody['userrights'] = loginPlatformType === 2 ? UserRights.getAdminPOSRights() : UserRights.getAdminRights()
							} else {
				
								// Pipline for get the rights of specific user based on userid
								const userrightsPipline = [
									{ $addFields: { "menuname": "$formname" } },
									{ $match: { personid: person._id.toString() } },
									{ $match: { moduletypeid: moduleTypeId } },
									{ $match: { $or: [{ allviewright: 1 }, { selfviewright: 1 }] } },
								]
								const userrightsPiplineres = await MainDB.getmenual('tbluserrights', new _Userrights(), userrightsPipline)
			
								if (userrightsPiplineres.ResultData.length == 0) {
									// get the role of user
									let roleofuser = person.userrole.map(function (roleel) { return roleel.userroleid.toString() })
			
									// Pipline for get the rights of user based on the userrole ids
									var userrolerightsPipline = [
										{ "$addFields": { "menuname": "$formname" } },
										{ $match: { $or: [{ allviewright: 1 }, { selfviewright: 1 }] } },
										{ $match: { moduletypeid: moduleTypeId } },
										{ $match: { userroleid: { $in: roleofuser } } }
									]
									const userrolerightsPiplineres = await MainDB.getmenual('tbluserrights', new _Userrights(), userrolerightsPipline)
									userrights = userrolerightsPiplineres.ResultData
			
									const ORUserrights = rolebasedrightsfilter(userrights)
									userrights = ORUserrights
								} else {
									userrights = userrightsPiplineres.ResultData
								}
		
								//END USER RIGHTS SECTION -------------------------------------------------------------------------------------//
			
							}
							/**************************************** Userrights ****************************************/
	
							/**************************************** Menu Data ****************************************/			     
							var menuData = await MainDB.getMenu(moduleTypeId, person, isAdmin, req.headers.platform,req.headers.propertyid)
							/**************************************** Menu Data ****************************************/
	
							ResponseBody.status = 200
							ResponseBody.message = Config.getResponsestatuscode()["200"]
							ResponseBody.data = {
								persondata: [person],
								propertydata: property ? [property] : [],
								userrights: userrights,
								menudata: menuData,
								blobstorageconnectionstring: Config.getBlobkey(),
								blobstoragecontainername:Config.getContainer()
							}
						} else {
							ResponseBody.status = 404
							ResponseBody.message = Config.getErrmsg()["propertynotfound"]
						}
					} else {
						ResponseBody.status = 400
						ResponseBody.message = Config.getErrmsg()["propertynotallowed"]
					}
				} else {
					ResponseBody.status = 403
					ResponseBody.message = Config.getErrmsg()['terminated']
				}
			 } else {
					ResponseBody.status = 404
					ResponseBody.message = Config.getErrmsg()["personnotfound"]
				}
	
				req.ResponseBody = ResponseBody
				next()
			} catch (err) {
				req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }
				next()
			}
		}


}

export default Signup
