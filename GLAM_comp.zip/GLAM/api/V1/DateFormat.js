import { IISMethods, MainDB, Config } from "../../config/Init.js"
import _DateFormat from "../../model/DateFormat.js"

export default class DateTypeSetting {
    
    async ListDateFormat(req, res, next) {
        try {
            var ResponseBody = {}
            
            const resp = await MainDB.getmenual("tbldateformat", new _DateFormat(), [{ $match: {} }])
            
            var systemdate = IISMethods.getTimezoneWiseDate({ timezone: req.headers.timezone })

            resp.ResultData.forEach((obj) => {
                const date = IISMethods.getFormatWiseDate(systemdate, obj.datewiseformat)
                obj.dateformat = date
            })

            ResponseBody.status = 200
            ResponseBody.message = Config.getResponsestatuscode()['200']
            ResponseBody.data = resp.ResultData

            req.ResponseBody = ResponseBody; next()
        }
        catch (err) {
            
            req.ResponseBody = { status: 500, message: Config.getResponsestatuscode()["500"], err }; next()
        }
    }

}