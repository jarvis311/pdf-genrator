import Queue from "bull"

const generateQueue = ({ queuename }) => {
    return new Queue(queuename, {
        redis: {
            // Redis connection configuration
            host: process.env.REDIS_HOST,
            port: process.env.REDIS_PORT,
            password: process.env.REDIS_PASS
        }
    })
}

const addJob = async ({ queue, queuename, data = {} }) => {
    const { err } = await queue.add({ name: queuename, ...data }, { removeOnComplete: true, removeOnFail: 10, maxStalledCount: 0 })
    
    if (err) {
        console.log("🚀 ~ addJob ~ err:", err)
    } 
}

export { generateQueue, addJob }
