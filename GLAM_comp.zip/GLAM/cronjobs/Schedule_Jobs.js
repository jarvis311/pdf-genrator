import { FieldConfig } from "../config/Init.js"
import { generateQueue, addJob } from "./BullQueue.js"
import cronJob from "node-schedule"


//=============================== Complaint ==========================================================//

import _ComplaintSolve from '../api/V1/cronjob/ComplaintSolveNotify.js'
const ApiComplaintSolve = new _ComplaintSolve()

const complaint_Queue = generateQueue({ queuename: FieldConfig.cronjobs.complaintsolve })
complaint_Queue.process(ApiComplaintSolve.ComplaintTicketSolveNotify)

cronJob.scheduleJob("* * * * *", async () => {
     await addJob({ queue: complaint_Queue, queuename: FieldConfig.cronjobs.complaintsolve })
})



import _ComplaintAccept from '../api/V1/cronjob/ComplaintAcceptNotify.js'
const ApiComplaintAccept = new _ComplaintAccept()

const complaintaccept_Queue = generateQueue({ queuename: FieldConfig.cronjobs.complaintaccept })
complaintaccept_Queue.process(ApiComplaintAccept.ComplaintAcceptNotify)

cronJob.scheduleJob("* * * * *", async () => {
     await addJob({ queue: complaintaccept_Queue, queuename: FieldConfig.cronjobs.complaintaccept })
})

//=============================== Complaint ==========================================================//



